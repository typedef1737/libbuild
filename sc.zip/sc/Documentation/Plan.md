# Plan

Краткий план работ по проекту Sc.

## Текущее состояние (анализ)

- **Sc** — C99-библиотека "Simple Core / Simple C": фундамент движка
  (память, строки, билдеры, списки, файлы/директории, пути, логирование,
  системная информация, CPU/threads, UI, Vulkan/Window-абстракция,
  result/error-хендлинг и др.).
- **Сборка**: masuka, конфигурации `debug` / `release` в `vince.masuka`,
  платформы `linux` / `windows`. Проект `Sc` (`Source/Sc.masuka`) собирается
  как `StaticLib` в `bin/{build}-{platform}`.
  Быстрая проверка сборки: `masuka -b debug` (или `Scripts/build_debug.bat`,
  который делает `masuka -b debug -p windows` из корня репозитория) —
  в данный момент собирается успешно (есть только warnings про
  deprecated CRT-функции: `fopen`, `localtime`).
- **Исходники**: `Source/Sc` — 30 файлов (.c/.h), `Source/Tests` — 22 файла,
  всего ~28.8k строк.
- **Тесты**: файлы в `Source/Tests` существуют (ScString, ScList, ScBuilder,
  ScDict, ScPath, ScRandom, ScUtf8, ScEcs и др. + агрегатор `ScAuto.c`
  и `TestSample.c` с точкой входа), но:
  - они **не подключены** ни к одному проекту в `.masuka`-файлах
    (`Source/Sc.masuka` собирает только ядро `Sc/Ai.c ... Sc/Ui.c`);
  - в workspace (`vince.masuka`) нет проекта-сэмпла, который бы собирал
    и запускал тесты, поэтому `masuka -t` / `masuka -r` нечего запускать.
- Из сборки ядра раньше исключались модули с внешними SDK-зависимостями:
  `Vk.c` (xcb/Vulkan) и `Vulkan.c` — до появления зависимостей в
  `Dependencies/`. `Gfx/Window.c` теперь собирается на обеих платформах
  (Linux: xcb/X11, Windows: WIN32/GDI — см. раздел «Gfx: Raster + Window»
  ниже), `Text/Font.c` + `Text/TrueType.c` нативные (без stb_truetype);
  тест `sc_auto_font()` всё ещё исключён (зашит linux-путь к шрифту).

## TODO:

- [ ] **Дописать тесты** — подробная инструкция ниже (раздел «Тесты: инструкция»).
      Текущее состояние на Windows: 19 тестовых файлов запускаются через
      `masuka -b debug -e test`, все зелёные, кроме `ScPath.c` — 2 функции
      падают из-за платформенной разницы `sc_path_combine`
      (Windows/PathCchCombineEx даёт `/home/dir\file.c`, тест ждёт `/`).
      Их надо сделать платформо-зависимыми или нормализовать сепараторы.
- [x] сделать sample для запуска тестов в виде проекта — **сделано**:
      `Source/Tests/Test.masuka` (проект `test`, Executable, зависит от `Sc`,
      source — все `Tests/*.c`). Запуск: `masuka -b debug -e test`.

## Сделано по инфраструктуре (2026-10-21)

- `Sc.masuka` переехал в `Source/Sc/` (source теперь — имена файлов,
  `provide-include: ".."`).
- `Test.masuka` создан в `Source/Tests/`.
- В `ScAuto.c`: зарегистрирован пропущенный `sc_auto_ai()`; `sc_auto_font()`
  временно исключён (Sc/Font.c зашивает linux-путь к шрифту; сами stb-зависимости
  больше не нужны — Font.c/TrueType.c нативные).
- Исправлен баг masuka: `-e <project>` после топологической сортировки
  проектов запускал не тот проект (`EntryIndex` считался до сортировки);
  теперь индекс перевычисляется по имени после `msk_projects_resolve`
  (`A:\Software\masuka\Source\Tools\Masuka.c`).
- Исправлен баг ядра Sc: `sc_path_get_random_temp_ext`/`sc_path_get_random_temp`
  были реализованы только под Linux. Добавлена Windows-версия (GetTempPathA),
  `sc_path_get_random` вынесен в общую секцию.
- Известное ограничение masuka на Windows: project-файлы в **корне** workspace
  молча отбрасываются (`sc_path_combine(".", "x.masuka")` -> `x.masuka` ->
  `sc_path_get_directory` == NULL), поэтому `Test.masuka` лежит в
  `Source/Tests/`, а не в корне.

## Gfx: Raster + Window (2026-10-22)

Программный рендерер вынесен из `Window.c` в общий платформо-независимый
модуль; `Window.c` собирается на обеих платформах (больше не исключён
из сборки).

- **`Gfx/Raster.h/.c`** — весь software renderer, ни одного `#if` на ОС:
  - `ScRaster`/`ScRasterBuffer`, двойная буферизация, аллокация обоих
    буферов сразу на MaxSize (resize без реаллокаций);
  - `sc_raster_init/resize/get_buffer/swap/set_pixel/clear_color/draw_line/free`;
  - формат: 32bpp, u32-цвет `0xAABBGGRR`, origin слева **внизу** (Y-вверх),
    совместимо с top-down DIB (GDI, biHeight < 0) и xcb_put_image;
  - фиксы относительно старого XCB-кода: клиппинг верхней границы в
    set_pixel (раньше — порча кучи), Брезенхэм вместо float-шага 2x,
    линейный clear.
- **`Gfx/Window.c`** — окно + события + blit готового кадра:
  - Linux (XCB): как раньше (окно, XKB-события, атомы), graphics-часть
    ужата до blit-бэкенда (pixmap/gc + `xcb_put_image` чанками Big
    Requests); рендеринг — через общий `ScRaster` (`sc_window_get_raster`);
  - Windows (WIN32/GDI, реализация новая): `RegisterClassExA`/
    `CreateWindowExA`, WndProc с полной трансляцией событий (клавиши,
    `WM_CHAR`, мышь, скролл, resize/move/close/focus/enter/hidden),
    Min/Max через `WM_GETMINMAXINFO`, headless/fullscreen/above/cursor,
    таблица VK_*→ScKey; вывод через `CreateDIBSection` (32bpp top-down)
    + `BitBlt`, WM_PAINT перерисовывает последний кадр;
  - `ScWindow.pGraphics` теперь `ScRaster*` (общий), платформенный
    blit-бэкенд — в `pBackend` рядом с backend-структурой окна
    (`pXcb + 1` / `pWin32 + 1`);
  - фиксы: `static prevX/prevY` в event-loop (общие на все окна) →
    поля backend-структур; `printf` → `sc_log_*`.
- **`Sc.masuka`**: `Gfx/Raster.c`, `Gfx/Ui.c`, `Gfx/Window.c` в source;
  windows-links += `user32`, `gdi32`; linux-links += xcb-библиотеки.
- **Тесты**: `Tests/Gfx/ScRaster.c` (8 функций, headless — окно не
  нужно), зарегистрирован `sc_auto_raster()`; оконный smoke на Windows
  проверен вручную (60 кадров с градиентом через GDI-blit, окно
  create/rename/destroy). Linux-путь (`xcb`) не проверялся — нет
  окружения; конфиг в `Sc.masuka` подготовлен.
- Старый API `sc_window_graphics_get_buffer/clear_color/draw_line`/
  `sc_window_buffer_set_pixel` удалён — теперь это `sc_raster_*`.

## Samples (2026-10-22)

- **`Samples/`** — сэмплы библиотеки. Конвенция: каждый сэмпл — своя
  папка `Samples/{Name}/` с двумя файлами: `{Name}.c` (main) и
  `{Name}.masuka` (project, Executable; source резолвится от папки
  сэмпла, include/bin — от корня workspace; зависимость `Sc` даёт
  Sc.lib и `-ISource`). Запуск: `masuka -b debug -e {name}`
  (имена проектов в нижнем регистре: `window`, `render`).
- **`Samples/Window/`** — окно без рендеринга (UseGraphics=0):
  конфиг с Min/MaxSize, OnEvent-коллбек печатает все события
  (клавиши, печать через KeyType, мышь/скролл, resize/move/focus),
  опрос aKeys (Esc — выход), set_title/set_position по ходу жизни.
- **`Samples/Render/`** — рендеринг в окно (UseGraphics=1):
  sc_window_get_raster → sc_raster_fill_rect/draw_rect/draw_line
  (сетка разноцветных прямоугольников 4x3 с белыми контурами,
  плавающий белый прямоугольник по орбите, рамка), двойная
  буферизация через sc_window_graphics_swap_buffers, буферы на
  MaxSize (resize без реаллокаций), FPS-счётчик (~870 fps на
  800x600, VMware/GDI). Окно центрируется на экране.
- Центрирование окна: `ScWindowConfig.Position = {0,0}` (по
  умолчанию) = центр экрана; работает на обеих платформах
  (WIN32: GetSystemMetrics до CreateWindowExA; XCB: размер
  screen до xcb_create_window).
- Заодно реализована отсутствовавшая `sc_mouse_key_to_string`
  (была объявлена в Window.h, не реализована — ловилось на линковке
  Window-сэмпла).
- `sc_raster_fill_rect`/`sc_raster_draw_rect` — новые примитивы
  (построчная заливка / контур с клиппингом); тесты в
  `Tests/Gfx/ScRaster.c` (10 функций, все зелёные).

## Тесты: инструкция

### Как устроено сейчас

- Фреймворк — `Source/Sc/Test.h` (реализация `Test.c`). Работает через
  глобальный реестр: `sc_test_file()` (файл) → `sc_test_func(...)` (функция)
  → `sc_test_*` (проверки: `sc_test_i32_equal`, `sc_test_string_equals`,
  `sc_test_condition`, `sc_test_f32_equal`, `sc_test_v2/v3/v4_equal`,
  `sc_test_quat_equal`, `sc_test_*_value` и др.).
- Каждый файл в `Source/Tests/` соответствует модулю ядра: внутри —
  `*_test()` функции + entry-point `sc_auto_<module>()`, который вызывает
  `sc_test_file()`, затем регистрирует все `*_test()` через `sc_test_func()`.
  Пример-образец: `Source/Tests/ScString.c`.
- Тесты зеркалят структуру `Source/Sc`: корневые модули — прямо в
  `Tests/`, подмодули — в подпапках (`Tests/Text/ScFont.c`,
  `Tests/Sound/ScQoa.c`).
- Агрегатор `Source/Tests/ScAuto.c` объявляет все `sc_auto_<module>()`
  как `extern` и вызывает их из `sc_auto()`. Точка входа —
  `TestSample.c` (`main` → `sc_auto()` → `sc_test_visualize(...)`).

### Шаг 1. Починить регистрацию существующих тестов

- `Source/Tests/ScAi.c` уже определяет `sc_auto_ai()`, но он **не подключён**:
  в `ScAuto.c` нет ни `extern void sc_auto_ai();`, ни вызова в `sc_auto()`.
  Добавить по образцу остальных (declaration сверху, вызов в `sc_auto()`).

### Шаг 2. Добавить недостающие тестовые файлы

Модули ядра (`Source/Sc/*.c`), для которых тестовых файлов в
`Source/Tests/` **нет** (по одному файлу на модуль, имя — `Sc<Module>.c`):

| Модуль ядра | Файл тестов | entry-point |
|---|---|---|
| `Json.c` | `Tests/ScJson.c` | `sc_auto_json()` |
| `Math.c` | `Tests/ScMath.c` | `sc_auto_math()` |
| `MathPrint.c` | `Tests/ScMathPrint.c` | `sc_auto_math_print()` |
| `Gltf.c` | `Tests/ScGltf.c` | `sc_auto_gltf()` |
| `Ui.c` | `Tests/ScUi.c` | `sc_auto_ui()` |
| `Types.c` | `Tests/ScTypes.c` | `sc_auto_types()` |
| `Sc.c` (ядро: files, paths, log, system info, profiler, cpu) | `Tests/ScCore.c` | `sc_auto_core()` |

Содержимое каждого файла — по образцу `ScString.c`:

```c
#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_json_parse_test()
{
    // ... проверки через sc_test_* ...
}

extern void
sc_auto_json()
{
    sc_test_file();

    sc_test_func(sc_json_parse_test());
    // ... остальные *_test()
}
```

Что покрывать (минимум):

- `Json` — parse простого объекта/массива, вложенность, числа/строки/bool,
  get по ключу, ошибочный ввод.
- `Math` — базовые векторные/матричные операции (создание, равенство,
  сложение/умножение через `sc_test_v2/v3/v4_equal`, `sc_test_f32_equal`).
- `MathPrint` — `sc_v2_to_string` / `sc_v3_to_string` / `sc_v4_to_string` /
  `sc_quat_to_string` + `sc_test_string_equals` на результат.
- `Gltf` — парсинг минимального .gltf/glb (можно inline-строкой или
  временным файлом через `sc_file_write`), проверка заголовка/чанков.
- `Ui` — базовые структуры/дефолтные конфиги без реального рендера.
- `Types` — что проверяемо без железа (создание/значения по умолчанию).
- `Sc.c` — `sc_file_read/write/append/compare` (на временных файлах в
  `bin/.test-tmp`, удалять за собой через `sc_file_remove`),
  `sc_path_*`-хелперы ядра (не дублируя `ScPath.c`), `sc_log_*`,
  `sc_profiler_start/end`.

Правила стиля:

- один файл тестов = один модуль ядра;
- каждая проверка — отдельный `{ ... }`-блок внутри `*_test()` (как в
  `ScString.c`), с `// DOCS:`-комментарием для неочевидных кейсов;
- тесты не зависят от абсолютных путей и внешних данных на диске —
  всё необходимое создаётся внутри теста во временных файлах;
- крайние случаи обязательны: пустая строка/файл, NULL, границы.

### Шаг 3. Зарегистрировать новые модули в агрегаторе

Для каждого нового файла — в `Source/Tests/ScAuto.c`:

1. `extern void sc_auto_<module>();` среди объявлений;
2. вызов `sc_auto_<module>();` в `sc_auto()`.

### Шаг 4. Проверить сборку и запуск

- Сборка: `masuka -b debug` (или `Scripts/build_debug.bat`) — новые файлы
  попадают в сборку через sample-проект тестов (второй пункт TODO),
  где `source` перечисляет `Tests/*.c`.
- Запуск: через sample (`masuka -e <test-project>`), после чего
  `sc_test_visualize` печатает сводку: все `sc_test_func` должны быть OK.
- Убедиться, что debug-сборка линкуется без new warnings
  (текущие 4 deprecated-CRT warnings — вне объёма этой задачи).

### Шаг 5 (опционально). Улучшения фреймворка

- `sc_test_v4_equal` сейчас сравнивает через `v3_equal` (баг в
  `Test.h`, строка ~131) — исправить на `v4_equal`.
- В `TestSample.c` закомментированные «долгие» тесты
  (`aLongPrintFuncs`) — актуализировать список под новые модули.
