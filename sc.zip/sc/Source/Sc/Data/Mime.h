#ifndef SC_MIME_H
#define SC_MIME_H

/*
  DOCS:
  MIME-типы поддерживаемых Sc форматов. Определение идёт двумя
  независимыми путями: по расширению файла (sc_mime_type_new) и по
  сигнатуре данных в памяти (sc_mime_type_new_from_data).

  Сигнатуры форматов:
    PNG  - 89 50 4E 47 0D 0A 1A 0A;
    JPEG - FF D8 FF (SOI + первый маркер);
    GIF  - "GIF87a" или "GIF89a";
    QOI  - "qoif";
    QOA  - "qoaf";
    GLB  - "glTF" (бинарный glTF). Текстовый .gltf - JSON, поэтому
           распознаётся по первому значимому символу '{'.
*/

#include "Sc/Types.h"

/* DOCS: Поддерживаемые MIME-типы. */
typedef enum
{
    ScMimeType_Undefined = 0,
    ScMimeType_Png,
    ScMimeType_Jpg,
    ScMimeType_Gif,
    ScMimeType_Qoi,
    ScMimeType_Qoa,
    ScMimeType_Gltf,
} ScMimeType;

ScMimeType sc_mime_type_new(const char* pPath, const void* pData, i32 dataSize);

/*
  DOCS: Определяет MIME-тип по расширению пути (.png, .jpg/.jpeg,
  .gif, .qoi, .qoa, .gltf/.glb).
  Регистр расширения lower case.
  Неизвестное расширение или NULL -> ScMimeType_Undefined.
*/
ScMimeType sc_mime_type_new_from_path(const char* pPath);

/*
  DOCS: Определяет MIME-тип по сигнатуре данных в памяти (PNG, JPEG,
  GIF, QOI, QOA, GLB/JSON glTF).
  NULL -> ScMimeType_Undefined.
*/
ScMimeType sc_mime_type_new_from_data(const void* pData, i32 dataSize);

#endif // SC_MIME_H
