#ifndef SC_ASSET_H
#define SC_ASSET_H

/*
   Prod-mode - загрузка ресурсов в формате sc_asset
   Dev-mode - загрузка ассетов во внешнем формате (png, jpg, qoi, gltf etc.)


   //////                               //
   //         Prod-mode format          //
   //                               //////

   |{MimeType}|{Hdrs}|{Datas}

   {MimeType} = |scas{major}{minor}| - 8 byte, string in ascii and utf-8
   {major} - u16 - major version
   {minor} - u16 - minor version
   {Hdrs} = |{ImageHdr}|{FontHdr}|{SoundHdr}|{ModelHdr}|
   {Datas} = |{ImageData}|{FontData}|{SoundData}|{ModelData}|

   {ImageHdr} = |{images_count}|{image_data_offset}|{image_data_size}|{hash-sum}|
   others are the same
   {images_count} = |i64|
   {image_data_offset} = |i64| - from file start as index (file+offset - start of the {ImageData})
   {image_data_size} = |i64| - size in bytes (file+offset+size - gives you a pointer to {FontData}

   {ImageData} = ||{images}|
   {images} = |{image_hdr}|{data}
   {image_hdr} = |{size}|
   {size} = |{i32}|
   {data} = |void*| - as image in qoi format

   Extras:
   - everything always in little endian
   - image_data_offset == 0, тогда игнорируем весь блок
   - {ImageHdr} всегда в полном составе, так как это метаданные по пакету
   - supported archs - x86_64
   - дата читается через memcpy(), читаем на размер и кладём в буфер void* потом кладём в ScList руками с записью count/capacity

   Example:
   |scas$@!%|

   [ image / text / sound / model ]

   _               |

   _           [ STORAGE ]

   _               |

   _           [ ENGINE ]


asset is both resource (loaded from package) and asset (loaded from disk)

asset_load_image() -> ScAssetId
ScAssetImageId     -> ScAssetId
ScStorageImageId   -> Engine/Game

create_in_dev_mode() {
  // in shipped game u dont need that:
  i64 modelId = sc_asset_load_model("ModelBlaBla");
  storga_model_monster_id = sc_resource_get_model(modelId)
  GmMonster(model: storga_model_monster_id)
}

create_in_prod_mode() {
  ScSavedState* pState = load_save_file(save_file_name);
  ScEcsWorld* pWorld = sc_deserializer(pState);
  sc_ecs_set_world(pWorld);
}

// dev mode
sc_asset_new();
// game mode
sc_asset_new_from_package(package_path);

*/

#include "Sc/Types.h"

typedef i64 ScAssetId;
#define ScInvalidAssetId (-1337)

void sc_asset_new();
void sc_asset_new_from_package(const char* pPath);
void sc_asset_destroy();

//////                               //
//    Dev mode loading assets ...    //
//                               //////

ScAssetId sc_asset_load_image(const char* pPath);
ScAssetId sc_asset_load_font(const char* pPath);
ScAssetId sc_asset_load_model(const char* pPath);
ScAssetId sc_asset_load_sound(const char* pPath);

//////                               //
//    Dev mode loading assets ...    //
//                               //////

void sc_asset_get_image(ScAssetId assetId, void* pData, i64 dataSize);
void sc_asset_get_font(ScAssetId assetId, void* pData, i64 dataSize);
void sc_asset_get_model(ScAssetId assetId, void* pData, i64 dataSize);
void sc_asset_get_sound(ScAssetId assetId, void* pData, i64 dataSize);

#endif // SC_ASSET_H
