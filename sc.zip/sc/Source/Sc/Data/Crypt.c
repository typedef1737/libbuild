#include "Sc/Data/Crypt.h"

#include "Sc/Sc.h"

#include <string.h>

/*
 BLAKE3 - Very fast, high quality, cryptographic hashing algorithm.
 Реализация портирована из эталонного C-кода BLAKE3:
 https://github.com/BLAKE3-team/BLAKE3

 Copyright (C) 2025 BLAKE3 team.
 BLAKE3 is released under CC0 1.0 Universal and Apache 2.0.
 */

#define SC_CRYPT_FLAG_CHUNK_START (1 << 0)
#define SC_CRYPT_FLAG_CHUNK_END (1 << 1)
#define SC_CRYPT_FLAG_PARENT (1 << 2)
#define SC_CRYPT_FLAG_ROOT (1 << 3)
#define SC_CRYPT_FLAG_KEYED_HASH (1 << 4)
#define SC_CRYPT_FLAG_DERIVE_KEY_CONTEXT (1 << 5)
#define SC_CRYPT_FLAG_DERIVE_KEY_MATERIAL (1 << 6)

static const u32 g_scCryptIv[8] = {
    0x6A09E667UL,
    0xBB67AE85UL,
    0x3C6EF372UL,
    0xA54FF53AUL,
    0x510E527FUL,
    0x9B05688CUL,
    0x1F83D9ABUL,
    0x5BE0CD19UL,
};

static const u8 g_scCryptMsgSchedule[7][16] = {
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 },
    { 2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8 },
    { 3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1 },
    { 10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6 },
    { 12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4 },
    { 9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7 },
    { 11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13 },
};

typedef struct
{
    u32 aInputCv[8];
    u64 Counter;
    u8 aBlock[SC_CRYPT_BLOCK_SIZE];
    u8 BlockLength;
    u8 Flags;
} ScCryptOutput;

static u32
sc_crypt_load32(const void* pData)
{
    const u8* p = (const u8*)pData;
    return ((u32)p[0]) | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

static void
sc_crypt_store32(void* pData, u32 value)
{
    u8* p = (u8*)pData;
    p[0] = (u8)value;
    p[1] = (u8)(value >> 8);
    p[2] = (u8)(value >> 16);
    p[3] = (u8)(value >> 24);
}

static void
sc_crypt_store_cv_words(u8 aOut[SC_CRYPT_HASH_SIZE], const u32 aCv[8])
{
    for (i32 i = 0; i < 8; ++i)
        sc_crypt_store32(aOut + 4 * i, aCv[i]);
}

static void
sc_crypt_load_key_words(const u8 aKey[SC_CRYPT_KEY_SIZE], u32 aKeyWords[8])
{
    for (i32 i = 0; i < 8; ++i)
        aKeyWords[i] = sc_crypt_load32(aKey + 4 * i);
}

static u32
sc_crypt_rotr32(u32 value, u32 count)
{
    return (value >> count) | (value << (32 - count));
}

static void
sc_crypt_g(u32 aState[16], i32 a, i32 b, i32 c, i32 d, u32 x, u32 y)
{
    aState[a] = aState[a] + aState[b] + x;
    aState[d] = sc_crypt_rotr32(aState[d] ^ aState[a], 16);
    aState[c] = aState[c] + aState[d];
    aState[b] = sc_crypt_rotr32(aState[b] ^ aState[c], 12);
    aState[a] = aState[a] + aState[b] + y;
    aState[d] = sc_crypt_rotr32(aState[d] ^ aState[a], 8);
    aState[c] = aState[c] + aState[d];
    aState[b] = sc_crypt_rotr32(aState[b] ^ aState[c], 7);
}

static void
sc_crypt_round(u32 aState[16], const u32 aMsg[16], i32 round)
{
    const u8* pSchedule = g_scCryptMsgSchedule[round];

    sc_crypt_g(aState, 0, 4, 8, 12, aMsg[pSchedule[0]], aMsg[pSchedule[1]]);
    sc_crypt_g(aState, 1, 5, 9, 13, aMsg[pSchedule[2]], aMsg[pSchedule[3]]);
    sc_crypt_g(aState, 2, 6, 10, 14, aMsg[pSchedule[4]], aMsg[pSchedule[5]]);
    sc_crypt_g(aState, 3, 7, 11, 15, aMsg[pSchedule[6]], aMsg[pSchedule[7]]);

    sc_crypt_g(aState, 0, 5, 10, 15, aMsg[pSchedule[8]], aMsg[pSchedule[9]]);
    sc_crypt_g(aState, 1, 6, 11, 12, aMsg[pSchedule[10]], aMsg[pSchedule[11]]);
    sc_crypt_g(aState, 2, 7, 8, 13, aMsg[pSchedule[12]], aMsg[pSchedule[13]]);
    sc_crypt_g(aState, 3, 4, 9, 14, aMsg[pSchedule[14]], aMsg[pSchedule[15]]);
}

static void
sc_crypt_compress_pre(u32 aState[16], const u32 aCv[8], const u8 aBlock[SC_CRYPT_BLOCK_SIZE], u8 blockLength, u64 counter, u8 flags)
{
    u32 aBlockWords[16];

    for (i32 i = 0; i < 16; ++i)
        aBlockWords[i] = sc_crypt_load32(aBlock + 4 * i);

    for (i32 i = 0; i < 8; ++i)
        aState[i] = aCv[i];

    for (i32 i = 0; i < 4; ++i)
        aState[8 + i] = g_scCryptIv[i];

    aState[12] = (u32)counter;
    aState[13] = (u32)(counter >> 32);
    aState[14] = (u32)blockLength;
    aState[15] = (u32)flags;

    for (i32 round = 0; round < 7; ++round)
        sc_crypt_round(aState, aBlockWords, round);
}

static void
sc_crypt_compress_in_place(u32 aCv[8], const u8 aBlock[SC_CRYPT_BLOCK_SIZE], u8 blockLength, u64 counter, u8 flags)
{
    u32 aState[16];

    sc_crypt_compress_pre(aState, aCv, aBlock, blockLength, counter, flags);

    for (i32 i = 0; i < 8; ++i)
        aCv[i] = aState[i] ^ aState[i + 8];
}

static void
sc_crypt_compress_xof(const u32 aCv[8], const u8 aBlock[SC_CRYPT_BLOCK_SIZE], u8 blockLength, u64 counter, u8 flags, u8 aOut[SC_CRYPT_BLOCK_SIZE])
{
    u32 aState[16];

    sc_crypt_compress_pre(aState, aCv, aBlock, blockLength, counter, flags);

    for (i32 i = 0; i < 8; ++i)
    {
        sc_crypt_store32(aOut + 4 * i, aState[i] ^ aState[i + 8]);
        sc_crypt_store32(aOut + 4 * (i + 8), aState[i + 8] ^ aCv[i]);
    }
}

static u32
sc_crypt_highest_one(u64 value)
{
#if defined(__GNUC__) || defined(__clang__)
    return 63u ^ (u32)__builtin_clzll(value);
#else
    u32 count = 0;
    if (value & 0xffffffff00000000ULL)
    {
        value >>= 32;
        count += 32;
    }
    if (value & 0x00000000ffff0000ULL)
    {
        value >>= 16;
        count += 16;
    }
    if (value & 0x000000000000ff00ULL)
    {
        value >>= 8;
        count += 8;
    }
    if (value & 0x00000000000000f0ULL)
    {
        value >>= 4;
        count += 4;
    }
    if (value & 0x000000000000000cULL)
    {
        value >>= 2;
        count += 2;
    }
    if (value & 0x0000000000000002ULL)
        count += 1;
    return count;
#endif
}

static u32
sc_crypt_popcnt(u64 value)
{
#if defined(__GNUC__) || defined(__clang__)
    return (u32)__builtin_popcountll(value);
#else
    u32 count = 0;
    while (value != 0)
    {
        count += 1;
        value &= value - 1;
    }
    return count;
#endif
}

static u64
sc_crypt_round_down_to_power_of_2(u64 value)
{
    return 1ULL << sc_crypt_highest_one(value | 1);
}

static void
sc_crypt_chunk_init(ScCryptChunkState* pState, const u32 aKey[8], u8 flags)
{
    memcpy(pState->aCv, aKey, SC_CRYPT_HASH_SIZE);
    pState->ChunkCounter = 0;
    memset(pState->aBuf, 0, SC_CRYPT_BLOCK_SIZE);
    pState->BufLength = 0;
    pState->BlocksCompressed = 0;
    pState->Flags = flags;
}

static void
sc_crypt_chunk_reset(ScCryptChunkState* pState, const u32 aKey[8], u64 chunkCounter)
{
    memcpy(pState->aCv, aKey, SC_CRYPT_HASH_SIZE);
    pState->ChunkCounter = chunkCounter;
    pState->BlocksCompressed = 0;
    memset(pState->aBuf, 0, SC_CRYPT_BLOCK_SIZE);
    pState->BufLength = 0;
}

static u64
sc_crypt_chunk_length(const ScCryptChunkState* pState)
{
    return (u64)SC_CRYPT_BLOCK_SIZE * pState->BlocksCompressed + pState->BufLength;
}

static u64
sc_crypt_chunk_fill_buf(ScCryptChunkState* pState, const u8* pData, u64 size)
{
    u64 take = SC_CRYPT_BLOCK_SIZE - pState->BufLength;

    if (take > size)
        take = size;

    if (take > 0)
        memcpy(pState->aBuf + pState->BufLength, pData, (size_t)take);

    pState->BufLength = (u8)(pState->BufLength + take);
    return take;
}

static u8
sc_crypt_chunk_start_flag(const ScCryptChunkState* pState)
{
    return pState->BlocksCompressed == 0 ? SC_CRYPT_FLAG_CHUNK_START : 0;
}

static void
sc_crypt_chunk_update(ScCryptChunkState* pState, const u8* pData, u64 size)
{
    if (pState->BufLength > 0)
    {
        u64 take = sc_crypt_chunk_fill_buf(pState, pData, size);
        pData += take;
        size -= take;

        if (size > 0)
        {
            sc_crypt_compress_in_place(pState->aCv, pState->aBuf, SC_CRYPT_BLOCK_SIZE, pState->ChunkCounter, pState->Flags | sc_crypt_chunk_start_flag(pState));
            pState->BlocksCompressed += 1;
            pState->BufLength = 0;
            memset(pState->aBuf, 0, SC_CRYPT_BLOCK_SIZE);
        }
    }

    while (size > SC_CRYPT_BLOCK_SIZE)
    {
        sc_crypt_compress_in_place(pState->aCv, pData, SC_CRYPT_BLOCK_SIZE, pState->ChunkCounter, pState->Flags | sc_crypt_chunk_start_flag(pState));
        pState->BlocksCompressed += 1;
        pData += SC_CRYPT_BLOCK_SIZE;
        size -= SC_CRYPT_BLOCK_SIZE;
    }

    sc_crypt_chunk_fill_buf(pState, pData, size);
}

static ScCryptOutput
sc_crypt_make_output(const u32 aInputCv[8], const u8 aBlock[SC_CRYPT_BLOCK_SIZE], u8 blockLength, u64 counter, u8 flags)
{
    ScCryptOutput output;

    memcpy(output.aInputCv, aInputCv, SC_CRYPT_HASH_SIZE);
    memcpy(output.aBlock, aBlock, SC_CRYPT_BLOCK_SIZE);
    output.BlockLength = blockLength;
    output.Counter = counter;
    output.Flags = flags;
    return output;
}

static ScCryptOutput
sc_crypt_chunk_output(const ScCryptChunkState* pState)
{
    u8 blockFlags = pState->Flags | sc_crypt_chunk_start_flag(pState) | SC_CRYPT_FLAG_CHUNK_END;
    return sc_crypt_make_output(pState->aCv, pState->aBuf, pState->BufLength, pState->ChunkCounter, blockFlags);
}

static ScCryptOutput
sc_crypt_parent_output(const u8 aBlock[SC_CRYPT_BLOCK_SIZE], const u32 aKey[8], u8 flags)
{
    return sc_crypt_make_output(aKey, aBlock, SC_CRYPT_BLOCK_SIZE, 0, flags | SC_CRYPT_FLAG_PARENT);
}

static void
sc_crypt_output_chaining_value(const ScCryptOutput* pOutput, u8 aOut[SC_CRYPT_HASH_SIZE])
{
    u32 aCvWords[8];

    memcpy(aCvWords, pOutput->aInputCv, SC_CRYPT_HASH_SIZE);
    sc_crypt_compress_in_place(aCvWords, pOutput->aBlock, pOutput->BlockLength, pOutput->Counter, pOutput->Flags);
    sc_crypt_store_cv_words(aOut, aCvWords);
}

static void
sc_crypt_output_root_bytes(const ScCryptOutput* pOutput, u64 seek, u8* pOut, u64 outSize)
{
    if (outSize == 0)
        return;

    u64 outputBlockCounter = seek / SC_CRYPT_BLOCK_SIZE;
    u64 offsetWithinBlock = seek % SC_CRYPT_BLOCK_SIZE;
    u8 aWideBuf[SC_CRYPT_BLOCK_SIZE];

    if (offsetWithinBlock > 0)
    {
        sc_crypt_compress_xof(pOutput->aInputCv, pOutput->aBlock, pOutput->BlockLength, outputBlockCounter, pOutput->Flags | SC_CRYPT_FLAG_ROOT, aWideBuf);

        u64 availableBytes = SC_CRYPT_BLOCK_SIZE - offsetWithinBlock;
        u64 bytes = outSize > availableBytes ? availableBytes : outSize;
        memcpy(pOut, aWideBuf + offsetWithinBlock, (size_t)bytes);
        pOut += bytes;
        outSize -= bytes;
        outputBlockCounter += 1;
    }

    while (outSize >= SC_CRYPT_BLOCK_SIZE)
    {
        sc_crypt_compress_xof(pOutput->aInputCv, pOutput->aBlock, pOutput->BlockLength, outputBlockCounter, pOutput->Flags | SC_CRYPT_FLAG_ROOT, pOut);
        pOut += SC_CRYPT_BLOCK_SIZE;
        outSize -= SC_CRYPT_BLOCK_SIZE;
        outputBlockCounter += 1;
    }

    if (outSize > 0)
    {
        sc_crypt_compress_xof(pOutput->aInputCv, pOutput->aBlock, pOutput->BlockLength, outputBlockCounter, pOutput->Flags | SC_CRYPT_FLAG_ROOT, aWideBuf);
        memcpy(pOut, aWideBuf, (size_t)outSize);
    }
}

static void
sc_crypt_hash_chunk(const u8* pData, u64 size, const u32 aKey[8], u64 chunkCounter, u8 flags, u8 aOut[SC_CRYPT_HASH_SIZE])
{
    ScCryptChunkState chunk;

    sc_crypt_chunk_init(&chunk, aKey, flags);
    chunk.ChunkCounter = chunkCounter;
    sc_crypt_chunk_update(&chunk, pData, size);

    ScCryptOutput output = sc_crypt_chunk_output(&chunk);
    sc_crypt_output_chaining_value(&output, aOut);
}

static u64
sc_crypt_compress_chunks(const u8* pData, u64 size, const u32 aKey[8], u64 chunkCounter, u8 flags, u8* pOut)
{
    u64 chunks = 0;

    while (size >= SC_CRYPT_CHUNK_SIZE)
    {
        sc_crypt_hash_chunk(pData, SC_CRYPT_CHUNK_SIZE, aKey, chunkCounter + chunks, flags, pOut + chunks * SC_CRYPT_HASH_SIZE);
        pData += SC_CRYPT_CHUNK_SIZE;
        size -= SC_CRYPT_CHUNK_SIZE;
        chunks += 1;
    }

    if (size > 0)
    {
        sc_crypt_hash_chunk(pData, size, aKey, chunkCounter + chunks, flags, pOut + chunks * SC_CRYPT_HASH_SIZE);
        chunks += 1;
    }

    return chunks;
}

static u64
sc_crypt_compress_parents(const u8* pChildren, u64 childrenCount, const u32 aKey[8], u8 flags, u8* pOut)
{
    u64 parents = 0;

    while (childrenCount - 2 * parents >= 2)
    {
        ScCryptOutput output = sc_crypt_parent_output(pChildren + 2 * parents * SC_CRYPT_HASH_SIZE, aKey, flags);
        sc_crypt_output_chaining_value(&output, pOut + parents * SC_CRYPT_HASH_SIZE);
        parents += 1;
    }

    if (childrenCount > 2 * parents)
    {
        memcpy(pOut + parents * SC_CRYPT_HASH_SIZE, pChildren + 2 * parents * SC_CRYPT_HASH_SIZE, SC_CRYPT_HASH_SIZE);
        return parents + 1;
    }

    return parents;
}

static u64
sc_crypt_left_subtree_len(u64 size)
{
    u64 fullChunks = (size - 1) / SC_CRYPT_CHUNK_SIZE;
    return sc_crypt_round_down_to_power_of_2(fullChunks) * SC_CRYPT_CHUNK_SIZE;
}

static u64
sc_crypt_compress_subtree_wide(const u8* pData, u64 size, const u32 aKey[8], u64 chunkCounter, u8 flags, u8* pOut)
{
    if (size <= SC_CRYPT_CHUNK_SIZE)
        return sc_crypt_compress_chunks(pData, size, aKey, chunkCounter, flags, pOut);

    u64 leftSize = sc_crypt_left_subtree_len(size);
    u64 rightSize = size - leftSize;
    const u8* pRight = pData + leftSize;
    u64 rightChunkCounter = chunkCounter + leftSize / SC_CRYPT_CHUNK_SIZE;

    u8 aCvArray[2 * 2 * SC_CRYPT_HASH_SIZE];
    u64 degree = leftSize > SC_CRYPT_CHUNK_SIZE ? 2 : 1;
    u8* pRightCvs = aCvArray + degree * SC_CRYPT_HASH_SIZE;

    u64 leftCount = sc_crypt_compress_subtree_wide(pData, leftSize, aKey, chunkCounter, flags, aCvArray);
    u64 rightCount = sc_crypt_compress_subtree_wide(pRight, rightSize, aKey, rightChunkCounter, flags, pRightCvs);

    if (leftCount == 1)
    {
        memcpy(pOut, aCvArray, 2 * SC_CRYPT_HASH_SIZE);
        return 2;
    }

    return sc_crypt_compress_parents(aCvArray, leftCount + rightCount, aKey, flags, pOut);
}

static void
sc_crypt_compress_subtree_to_parent_node(const u8* pData, u64 size, const u32 aKey[8], u64 chunkCounter, u8 flags, u8 aOut[2 * SC_CRYPT_HASH_SIZE])
{
    u8 aCvArray[2 * SC_CRYPT_HASH_SIZE];

    sc_crypt_compress_subtree_wide(pData, size, aKey, chunkCounter, flags, aCvArray);
    memcpy(aOut, aCvArray, 2 * SC_CRYPT_HASH_SIZE);
}

static void
sc_crypt_hasher_init_base(ScCryptHasher* pHasher, const u32 aKey[8], u8 flags)
{
    memcpy(pHasher->aKey, aKey, SC_CRYPT_HASH_SIZE);
    sc_crypt_chunk_init(&pHasher->Chunk, aKey, flags);
    pHasher->CvStackLength = 0;
}

static void
sc_crypt_hasher_merge_cv_stack(ScCryptHasher* pHasher, u64 totalSize)
{
    u64 postMergeStackLength = sc_crypt_popcnt(totalSize);

    while ((u64)pHasher->CvStackLength > postMergeStackLength)
    {
        u8* pParentNode = &pHasher->aCvStack[((u64)pHasher->CvStackLength - 2) * SC_CRYPT_HASH_SIZE];
        ScCryptOutput output = sc_crypt_parent_output(pParentNode, pHasher->aKey, pHasher->Chunk.Flags);
        sc_crypt_output_chaining_value(&output, pParentNode);
        pHasher->CvStackLength -= 1;
    }
}

static void
sc_crypt_hasher_push_cv(ScCryptHasher* pHasher, const u8 aCv[SC_CRYPT_HASH_SIZE], u64 chunkCounter)
{
    sc_crypt_hasher_merge_cv_stack(pHasher, chunkCounter);
    memcpy(&pHasher->aCvStack[pHasher->CvStackLength * SC_CRYPT_HASH_SIZE], aCv, SC_CRYPT_HASH_SIZE);
    pHasher->CvStackLength += 1;
}

static void
sc_crypt_hasher_update_base(ScCryptHasher* pHasher, const void* pData, u64 size)
{
    if (size == 0)
        return;

    const u8* pInput = (const u8*)pData;

    if (sc_crypt_chunk_length(&pHasher->Chunk) > 0)
    {
        u64 take = SC_CRYPT_CHUNK_SIZE - sc_crypt_chunk_length(&pHasher->Chunk);
        if (take > size)
            take = size;

        sc_crypt_chunk_update(&pHasher->Chunk, pInput, take);
        pInput += take;
        size -= take;

        if (size > 0)
        {
            ScCryptOutput output = sc_crypt_chunk_output(&pHasher->Chunk);
            u8 aChunkCv[SC_CRYPT_HASH_SIZE];
            sc_crypt_output_chaining_value(&output, aChunkCv);
            sc_crypt_hasher_push_cv(pHasher, aChunkCv, pHasher->Chunk.ChunkCounter);
            sc_crypt_chunk_reset(&pHasher->Chunk, pHasher->aKey, pHasher->Chunk.ChunkCounter + 1);
        }
        else
            return;
    }

    while (size > SC_CRYPT_CHUNK_SIZE)
    {
        u64 subtreeSize = sc_crypt_round_down_to_power_of_2(size);
        u64 countSoFar = pHasher->Chunk.ChunkCounter * SC_CRYPT_CHUNK_SIZE;

        while (((subtreeSize - 1) & countSoFar) != 0)
            subtreeSize /= 2;

        u64 subtreeChunks = subtreeSize / SC_CRYPT_CHUNK_SIZE;

        if (subtreeSize <= SC_CRYPT_CHUNK_SIZE)
        {
            ScCryptChunkState chunk;
            sc_crypt_chunk_init(&chunk, pHasher->aKey, pHasher->Chunk.Flags);
            chunk.ChunkCounter = pHasher->Chunk.ChunkCounter;
            sc_crypt_chunk_update(&chunk, pInput, subtreeSize);

            ScCryptOutput output = sc_crypt_chunk_output(&chunk);
            u8 aCv[SC_CRYPT_HASH_SIZE];
            sc_crypt_output_chaining_value(&output, aCv);
            sc_crypt_hasher_push_cv(pHasher, aCv, chunk.ChunkCounter);
        }
        else
        {
            u8 aCvPair[2 * SC_CRYPT_HASH_SIZE];
            sc_crypt_compress_subtree_to_parent_node(pInput, subtreeSize, pHasher->aKey, pHasher->Chunk.ChunkCounter, pHasher->Chunk.Flags, aCvPair);
            sc_crypt_hasher_push_cv(pHasher, aCvPair, pHasher->Chunk.ChunkCounter);
            sc_crypt_hasher_push_cv(pHasher, aCvPair + SC_CRYPT_HASH_SIZE, pHasher->Chunk.ChunkCounter + subtreeChunks / 2);
        }

        pHasher->Chunk.ChunkCounter += subtreeChunks;
        pInput += subtreeSize;
        size -= subtreeSize;
    }

    if (size > 0)
    {
        sc_crypt_chunk_update(&pHasher->Chunk, pInput, size);
        sc_crypt_hasher_merge_cv_stack(pHasher, pHasher->Chunk.ChunkCounter);
    }
}

void
sc_crypt_hasher_init(ScCryptHasher* pHasher)
{
    sc_assert_not_null(pHasher);

    sc_crypt_hasher_init_base(pHasher, g_scCryptIv, 0);
}

void
sc_crypt_hasher_init_keyed(ScCryptHasher* pHasher, const u8* pKey)
{
    sc_assert_not_null(pHasher);
    sc_assert_not_null(pKey);

    u32 aKeyWords[8];
    sc_crypt_load_key_words(pKey, aKeyWords);
    sc_crypt_hasher_init_base(pHasher, aKeyWords, SC_CRYPT_FLAG_KEYED_HASH);
}

void
sc_crypt_hasher_init_derive_key(ScCryptHasher* pHasher, const char* pContext)
{
    sc_assert_not_null(pHasher);
    sc_assert_not_null(pContext);

    ScCryptHasher contextHasher;
    sc_crypt_hasher_init_base(&contextHasher, g_scCryptIv, SC_CRYPT_FLAG_DERIVE_KEY_CONTEXT);
    sc_crypt_hasher_update(&contextHasher, pContext, (u64)strlen(pContext));

    u8 aContextKey[SC_CRYPT_KEY_SIZE];
    sc_crypt_hasher_finalize(&contextHasher, aContextKey, SC_CRYPT_KEY_SIZE);

    u32 aContextKeyWords[8];
    sc_crypt_load_key_words(aContextKey, aContextKeyWords);
    sc_crypt_hasher_init_base(pHasher, aContextKeyWords, SC_CRYPT_FLAG_DERIVE_KEY_MATERIAL);
}

void
sc_crypt_hasher_update(ScCryptHasher* pHasher, const void* pData, u64 size)
{
    sc_assert_not_null(pHasher);

    if (size > 0)
        sc_assert_not_null(pData);

    sc_crypt_hasher_update_base(pHasher, pData, size);
}

void
sc_crypt_hasher_finalize(const ScCryptHasher* pHasher, u8* pOut, u64 outSize)
{
    sc_crypt_hasher_finalize_seek(pHasher, 0, pOut, outSize);
}

void
sc_crypt_hasher_finalize_seek(const ScCryptHasher* pHasher, u64 seek, u8* pOut, u64 outSize)
{
    sc_assert_not_null(pHasher);

    if (outSize > 0)
        sc_assert_not_null(pOut);

    if (outSize == 0)
        return;

    if (pHasher->CvStackLength == 0)
    {
        ScCryptOutput output = sc_crypt_chunk_output(&pHasher->Chunk);
        sc_crypt_output_root_bytes(&output, seek, pOut, outSize);
        return;
    }

    ScCryptOutput output;
    u64 cvsRemaining;

    if (sc_crypt_chunk_length(&pHasher->Chunk) > 0)
    {
        cvsRemaining = pHasher->CvStackLength;
        output = sc_crypt_chunk_output(&pHasher->Chunk);
    }
    else
    {
        cvsRemaining = (u64)pHasher->CvStackLength - 2;
        output = sc_crypt_parent_output(&pHasher->aCvStack[cvsRemaining * SC_CRYPT_HASH_SIZE], pHasher->aKey, pHasher->Chunk.Flags);
    }

    while (cvsRemaining > 0)
    {
        cvsRemaining -= 1;

        u8 aParentBlock[SC_CRYPT_BLOCK_SIZE];
        memcpy(aParentBlock, &pHasher->aCvStack[cvsRemaining * SC_CRYPT_HASH_SIZE], SC_CRYPT_HASH_SIZE);
        sc_crypt_output_chaining_value(&output, &aParentBlock[SC_CRYPT_HASH_SIZE]);
        output = sc_crypt_parent_output(aParentBlock, pHasher->aKey, pHasher->Chunk.Flags);
    }

    sc_crypt_output_root_bytes(&output, seek, pOut, outSize);
}

void
sc_crypt_hasher_reset(ScCryptHasher* pHasher)
{
    sc_assert_not_null(pHasher);

    sc_crypt_chunk_reset(&pHasher->Chunk, pHasher->aKey, 0);
    pHasher->CvStackLength = 0;
}

void
sc_crypt_hash(const void* pData, u64 size, u8* pOut)
{
    if (size > 0)
        sc_assert_not_null(pData);

    sc_assert_not_null(pOut);

    ScCryptHasher hasher;
    sc_crypt_hasher_init(&hasher);
    sc_crypt_hasher_update(&hasher, pData, size);
    sc_crypt_hasher_finalize(&hasher, pOut, SC_CRYPT_HASH_SIZE);
}

void
sc_crypt_hash_keyed(const void* pData, u64 size, const u8* pKey, u8* pOut)
{
    if (size > 0)
        sc_assert_not_null(pData);

    sc_assert_not_null(pKey);
    sc_assert_not_null(pOut);

    ScCryptHasher hasher;
    sc_crypt_hasher_init_keyed(&hasher, pKey);
    sc_crypt_hasher_update(&hasher, pData, size);
    sc_crypt_hasher_finalize(&hasher, pOut, SC_CRYPT_HASH_SIZE);
}

void
sc_crypt_derive_key(const char* pContext, const void* pData, u64 size, u8* pOut)
{
    sc_assert_not_null(pContext);

    if (size > 0)
        sc_assert_not_null(pData);

    sc_assert_not_null(pOut);

    ScCryptHasher hasher;
    sc_crypt_hasher_init_derive_key(&hasher, pContext);
    sc_crypt_hasher_update(&hasher, pData, size);
    sc_crypt_hasher_finalize(&hasher, pOut, SC_CRYPT_HASH_SIZE);
}

void
sc_crypt_hash_xof(const void* pData, u64 size, u8* pOut, u64 outSize)
{
    if (size > 0)
        sc_assert_not_null(pData);

    if (outSize > 0)
        sc_assert_not_null(pOut);

    ScCryptHasher hasher;
    sc_crypt_hasher_init(&hasher);
    sc_crypt_hasher_update(&hasher, pData, size);
    sc_crypt_hasher_finalize(&hasher, pOut, outSize);
}
