#include "Asset.h"
#include "Sc/Sc.h"

typedef struct
{
    i32 RefCounter;

} ScAssetImage;

typedef struct
{
    i8* aRefCounters;
    void* aImages;
} ImageStorage;

typedef struct
{

} ScAsset;

static ScAsset g = {};

void
sc_asset_new()
{
    // void* aImages = NULL;
    // ScImageBuffer* pImgBuf = NULL;
    // aImages = sc_list_add_ext(aImages, pImgBuf, 80);
}

void sc_asset_new_from_package(const char* pPath);
void sc_asset_destroy();

ScAssetId sc_asset_load_image(const char* pPath)
{
    return ScInvalidAssetId;
}
ScAssetId sc_asset_load_font(const char* pPath);
ScAssetId sc_asset_load_model(const char* pPath);
ScAssetId sc_asset_load_sound(const char* pPath);

void sc_asset_get_image(ScAssetId assetId, void* pData, i64 dataSize);
void sc_asset_get_font(ScAssetId assetId, void* pData, i64 dataSize);
void sc_asset_get_model(ScAssetId assetId, void* pData, i64 dataSize);
void sc_asset_get_sound(ScAssetId assetId, void* pData, i64 dataSize);
