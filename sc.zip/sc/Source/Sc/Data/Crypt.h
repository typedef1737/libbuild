#ifndef SC_CRYPT_H
#define SC_CRYPT_H

#include "Sc/Types.h"

/*
 BLAKE3 - быстрый криптографический хеш
 (https://github.com/BLAKE3-team/BLAKE3). Реализация портирована из
 эталонного C-кода BLAKE3 и использует только portable-путь без SIMD.

 sc_crypt_hash - 32-байтный хеш, sc_crypt_hash_keyed - ключевой хеш,
 sc_crypt_derive_key - вывод ключа из контекста, sc_crypt_hash_xof -
 расширяемый вывод произвольной длины.

 pData может быть ScNull только при size == 0.
 pOut должен указывать минимум на SC_CRYPT_HASH_SIZE байт для обычного
 хеша и на outSize байт для XOF.
 */

#define SC_CRYPT_HASH_SIZE 32
#define SC_CRYPT_KEY_SIZE 32
#define SC_CRYPT_BLOCK_SIZE 64
#define SC_CRYPT_CHUNK_SIZE 1024
#define SC_CRYPT_MAX_DEPTH 54

typedef struct
{
    u32 aCv[8];
    u64 ChunkCounter;
    u8 aBuf[SC_CRYPT_BLOCK_SIZE];
    u8 BufLength;
    u8 BlocksCompressed;
    u8 Flags;
} ScCryptChunkState;

typedef struct
{
    u32 aKey[8];
    ScCryptChunkState Chunk;
    u8 CvStackLength;
    u8 aCvStack[(SC_CRYPT_MAX_DEPTH + 1) * SC_CRYPT_HASH_SIZE];
} ScCryptHasher;

/*
 sc_crypt_hash - 32-байтный BLAKE3 хеш буфера.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 pOut - output buffer, at least SC_CRYPT_HASH_SIZE bytes.
 */
void sc_crypt_hash(const void* pData, u64 size, u8* pOut);

/*
 sc_crypt_hash_keyed - ключевой BLAKE3 хеш.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 pKey - 32-byte key, SC_CRYPT_KEY_SIZE bytes.
 pOut - output buffer, at least SC_CRYPT_HASH_SIZE bytes.
 */
void sc_crypt_hash_keyed(const void* pData, u64 size, const u8* pKey, u8* pOut);

/*
 sc_crypt_derive_key - выводит 32-байтный ключ из контекста и данных.

 pContext - NUL-terminated context string.
 pData - key material.
 size - pData length, in bytes.
 pOut - output buffer, at least SC_CRYPT_HASH_SIZE bytes.
 */
void sc_crypt_derive_key(const char* pContext, const void* pData, u64 size, u8* pOut);

/*
 sc_crypt_hash_xof - BLAKE3 с расширяемым выводом.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 pOut - output buffer, at least outSize bytes.
 outSize - number of output bytes.
 */
void sc_crypt_hash_xof(const void* pData, u64 size, u8* pOut, u64 outSize);

/*
 sc_crypt_hasher_init - инициализирует потоковый хешер.
 sc_crypt_hasher_init_keyed - инициализирует ключевой хешер.
 sc_crypt_hasher_init_derive_key - инициализирует хешер вывода ключа.
 */
void sc_crypt_hasher_init(ScCryptHasher* pHasher);
void sc_crypt_hasher_init_keyed(ScCryptHasher* pHasher, const u8* pKey);
void sc_crypt_hasher_init_derive_key(ScCryptHasher* pHasher, const char* pContext);

/*
 sc_crypt_hasher_update - добавляет данные в хешер.
 sc_crypt_hasher_finalize - записывает outSize байт результата.
 sc_crypt_hasher_finalize_seek - то же, начиная со смещения seek.
 sc_crypt_hasher_reset - сбрасывает состояние в начальное.
 */
void sc_crypt_hasher_update(ScCryptHasher* pHasher, const void* pData, u64 size);
void sc_crypt_hasher_finalize(const ScCryptHasher* pHasher, u8* pOut, u64 outSize);
void sc_crypt_hasher_finalize_seek(const ScCryptHasher* pHasher, u64 seek, u8* pOut, u64 outSize);
void sc_crypt_hasher_reset(ScCryptHasher* pHasher);

#endif // SC_CRYPT_H
