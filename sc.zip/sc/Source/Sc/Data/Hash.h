#ifndef SC_HASH_H
#define SC_HASH_H

#include "Sc/Types.h"

/*
 64-битное хеширование произвольных буферов на основе rapidhash V3
 (https://github.com/Nicoshev/rapidhash) - быстрый и качественный
 некриптографический хеш, независимый от платформы и порядка байт.

 NOTE: не используйте для паролей, подписей и других задач, где нужна
 стойкость к подбору.

 sc_hash == sc_hash_micro при size <= 80;
 sc_hash == sc_hash_nano при size <= 48.

 pData может быть ScNull только при size == 0.
 */

/*
 SC_HASH_SEED_DEFAULT - seed по умолчанию (0ULL, как в эталонной rapidhash).
 */
#define SC_HASH_SEED_DEFAULT 0ULL

/*
 sc_hash - 64-битный хеш байтов pData[0..size).

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 Returns a 64-bit hash.
 */
u64 sc_hash(const void* pData, u64 size);

/*
 sc_hash с явным seed.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 seed - 64-bit seed used to alter the hash result predictably.
 Returns a 64-bit hash.
 */
u64 sc_hash_with_seed(const void* pData, u64 size, u64 seed);

/*
 sc_hash_micro - компактная версия, быстрее sc_hash на коротких входах
 (до ~512 байт). Совпадает с sc_hash при size <= 80.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 Returns a 64-bit hash.
 */
u64 sc_hash_micro(const void* pData, u64 size);

/*
 sc_hash_micro с явным seed.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 seed - 64-bit seed used to alter the hash result predictably.
 Returns a 64-bit hash.
 */
u64 sc_hash_micro_with_seed(const void* pData, u64 size, u64 seed);

/*
 sc_hash_nano - самая компактная версия, оптимальна до 48 байт.
 Совпадает с sc_hash при size <= 48.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 Returns a 64-bit hash.
 */
u64 sc_hash_nano(const void* pData, u64 size);

/*
 sc_hash_nano с явным seed.

 pData - Buffer to be hashed.
 size - pData length, in bytes.
 seed - 64-bit seed used to alter the hash result predictably.
 Returns a 64-bit hash.
 */
u64 sc_hash_nano_with_seed(const void* pData, u64 size, u64 seed);

#endif // SC_HASH_H
