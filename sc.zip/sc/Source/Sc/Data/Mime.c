#include "Sc/Data/Mime.h"

#include "Sc/Sc.h"
#include <string.h>

/*
  DOCS: Проверка, что данные начинаются с JSON-объекта (текстовый glTF).
  Ведущие пробельные символы пропускаются.
*/
static i32
sc_mime_is_json_object(const u8* aBytes)
{
    while (sc_char_is_whitespace(*aBytes))
        ++aBytes;
    return *aBytes == '{';
}

ScMimeType
sc_mime_type_new(const char* pPath, const void* pData, i32 dataSize)
{
    if (pData)
    {
        ScMimeType mimeFromData = sc_mime_type_new_from_data(pData, dataSize);
        if (mimeFromData != ScMimeType_Undefined)
            return mimeFromData;
    }
    if (pPath)
        return sc_mime_type_new_from_path(pPath);
    return ScMimeType_Undefined;
}

ScMimeType
sc_mime_type_new_from_path(const char* pPath)
{
    sc_assert_not_null(pPath);

    if (!pPath)
        return ScMimeType_Undefined;

    char* ptr = (char*)pPath;
    ++ptr;

    char firstChar = *ptr;

    switch (firstChar)
    {
    case 'p':
    {
        if (ptr[1] == 'n' && ptr[2] == 'g')
            return ScMimeType_Png;
        break;
    }
    case 'j':
    {
        if (ptr[1] == 'p')
        {
            if (ptr[2] == 'g')
                return ScMimeType_Jpg;
            else if (ptr[2] == 'e' && ptr[3] == 'g')
                return ScMimeType_Jpg;
        }
        break;
    }
    case 'g':
    {
        if (ptr[1] == 'i')
        {
            if (ptr[2] == 'f')
                return ScMimeType_Gif;
        }
        else if (ptr[1] == 'l')
        {
            if (ptr[2] == 't' && ptr[3] == 'f')
                return ScMimeType_Gltf;
            else if (ptr[2] == 'b')
                return ScMimeType_Gltf;
        }
        break;
    }
    case 'q':
    {
        if (ptr[1] == 'o')
        {
            if (ptr[2] == 'i')
                return ScMimeType_Qoi;
            else if (ptr[2] == 'a')
                return ScMimeType_Qoa;
        }
        break;
    }
    }

    return ScMimeType_Undefined;
}

ScMimeType
sc_mime_type_new_from_data(const void* pData, i32 dataSize)
{
    sc_assert_not_null(pData);

    if (!pData || dataSize < 8)
        return ScMimeType_Undefined;

    const u8* aBytes = (const u8*)pData;

    switch (aBytes[0])
    {
    case 0x89:
    {
        static const u8 aPngMagic[8] = { 137, 80, 78, 71, 13, 10, 26, 10 };
        if (memcmp(aBytes, aPngMagic, sizeof(aPngMagic)) == 0)
            return ScMimeType_Png;
        break;
    }
    case 0xff:
    {
        if (aBytes[1] == 0xd8 && aBytes[2] == 0xff)
            return ScMimeType_Jpg;
        break;
    }
    case 'G':
    {
        if (memcmp(aBytes, "GIF87a", 6) == 0 || memcmp(aBytes, "GIF89a", 6) == 0)
            return ScMimeType_Gif;
        break;
    }
    case 'q':
    {
        if (memcmp(aBytes, "qoif", 4) == 0)
            return ScMimeType_Qoi;
        else if (memcmp(aBytes, "qoaf", 4) == 0)
            return ScMimeType_Qoa;
        break;
    }
    case 'g':
    {
        if (memcmp(aBytes, "glTF", 4) == 0)
            return ScMimeType_Gltf;
        break;
    }
    case '{':
    case ' ':
    case '\t':
    case '\n':
    case '\v':
    {
        if (sc_mime_is_json_object(aBytes))
            return ScMimeType_Gltf;
        break;
    }
    }

    return ScMimeType_Undefined;
}
