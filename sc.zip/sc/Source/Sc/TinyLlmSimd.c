/*
  CPU-бэкенд TinyLlm.

  Скалярные ядра - эталон (и fallback для CPU без AVX2). AVX2-ядра
  собираются с target("avx2,fma") и выбираются один раз при инициализации
  по CPUID/XGETBV. Один бинарник работает на обеих категориях CPU.
*/

#include "TinyLlmSimd.h"

#include <math.h>
#include <stdlib.h>

#define SC_TINY_LLM_SIMD_LN_EPS 1e-5f

#if (defined(__clang__) || defined(__GNUC__)) && (defined(__x86_64__) || defined(_M_X64))
#define SC_TINY_LLM_SIMD_X86 1
#endif

#if defined(SC_TINY_LLM_SIMD_X86)
#if defined(_MSC_VER) || defined(_WIN32)
#include <intrin.h>
#else
#include <cpuid.h>
#endif
#include <immintrin.h>
#if defined(__clang__)
// DOCS: clang 18 и старше подключают pmmintrin/avxintrin/avx2intrin/
// fmaintrin из immintrin.h только при включённых -msse3/-mavx/-mavx2.
// Глобальные флаги здесь не нужны: AVX2-функции ниже помечены
// target("avx2,fma"). Поэтому нужные заголовки добираем явно
// (на новых clang это no-op из-за include guard).
#include <pmmintrin.h>
#include <avxintrin.h>
#include <avx2intrin.h>
#include <fmaintrin.h>
#endif
#if defined(__clang__) || defined(__GNUC__)
#define SC_TINY_LLM_SIMD_AVX2_TARGET __attribute__((target("avx2,fma")))
#endif
#endif

#if !defined(SC_TINY_LLM_SIMD_AVX2_TARGET)
#define SC_TINY_LLM_SIMD_AVX2_TARGET
#endif

/*
  ############################################
  DOCS: CPU features
  ############################################
*/

static void
_sc_tiny_llm_cpu_id(u32 leaf, u32 subleaf, u32 aOut[4])
{
    aOut[0] = 0;
    aOut[1] = 0;
    aOut[2] = 0;
    aOut[3] = 0;

#if defined(SC_TINY_LLM_SIMD_X86)
#if defined(_MSC_VER) || defined(_WIN32)
    int aInfo[4] = { 0, 0, 0, 0 };
    __cpuidex(aInfo, (int)leaf, (int)subleaf);
    aOut[0] = (u32)aInfo[0];
    aOut[1] = (u32)aInfo[1];
    aOut[2] = (u32)aInfo[2];
    aOut[3] = (u32)aInfo[3];
#else
    unsigned int a = 0, b = 0, c = 0, d = 0;
    __cpuid_count(leaf, subleaf, a, b, c, d);
    aOut[0] = (u32)a;
    aOut[1] = (u32)b;
    aOut[2] = (u32)c;
    aOut[3] = (u32)d;
#endif
#else
    (void)leaf;
    (void)subleaf;
#endif
}

static u64
_sc_tiny_llm_xgetbv0(void)
{
#if defined(SC_TINY_LLM_SIMD_X86)
#if defined(_MSC_VER) || defined(_WIN32)
    return (u64)_xgetbv(0);
#else
    u32 a = 0;
    u32 d = 0;
    __asm__ __volatile__("xgetbv" : "=a"(a), "=d"(d) : "c"(0));
    return ((u64)d << 32) | (u64)a;
#endif
#else
    return 0;
#endif
}

// DOCS: AVX2 + FMA + OS-состояние YMM (XCR0). Без OS-поддержки AVX2
// использовать нельзя даже при наличии бита в CPUID.
static i32
_sc_tiny_llm_cpu_has_avx2_fma(i32* pHasAvx2, i32* pHasFma)
{
    if (pHasAvx2)
        *pHasAvx2 = 0;
    if (pHasFma)
        *pHasFma = 0;

#if !defined(SC_TINY_LLM_SIMD_X86)
    return 0;
#else
    u32 aInfo[4];
    _sc_tiny_llm_cpu_id(0, 0, aInfo);
    if (aInfo[0] < 7)
        return 0;

    _sc_tiny_llm_cpu_id(1, 0, aInfo);
    i32 osxsave = (aInfo[2] >> 27) & 1;
    i32 avx = (aInfo[2] >> 28) & 1;
    i32 fma = (aInfo[2] >> 12) & 1;

    if (pHasFma)
        *pHasFma = fma;

    if (!osxsave || !avx)
        return 0;

    u64 xcr0 = _sc_tiny_llm_xgetbv0();
    if ((xcr0 & 0x6) != 0x6)
        return 0;

    _sc_tiny_llm_cpu_id(7, 0, aInfo);
    i32 avx2 = (aInfo[1] >> 5) & 1;

    if (pHasAvx2)
        *pHasAvx2 = avx2;

    // DOCS: Сам бэкенд требует и AVX2, и FMA (ядра используют fmadd).
    return avx2 && fma;
#endif
}

/*
  ############################################
  DOCS: Scalar kernels (reference)
  ############################################
*/

static void
_sc_tiny_llm_ln_forward_scalar(const f32* pX, f32* pY, f32* pXhat, f32* pInvStd,
    const f32* pGamma, const f32* pBeta, i32 T, i32 D)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * D;
        f32* y = pY + (i64)t * D;
        f32* xhat = pXhat + (i64)t * D;

        f32 mean = 0.0f;
        for (i32 d = 0; d < D; ++d)
            mean += x[d];
        mean /= (f32)D;

        f32 var = 0.0f;
        for (i32 d = 0; d < D; ++d)
        {
            f32 diff = x[d] - mean;
            var += diff * diff;
        }
        var /= (f32)D;

        f32 invStd = 1.0f / sqrtf(var + SC_TINY_LLM_SIMD_LN_EPS);
        pInvStd[t] = invStd;

        for (i32 d = 0; d < D; ++d)
        {
            f32 value = (x[d] - mean) * invStd;
            xhat[d] = value;
            y[d] = value * pGamma[d] + pBeta[d];
        }
    }
}

static void
_sc_tiny_llm_ln_backward_add_scalar(const f32* pDy, const f32* pXhat, const f32* pInvStd,
    const f32* pGamma, f32* pGammaGrad, f32* pBetaGrad, f32* pDx, i32 T, i32 D)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* dy = pDy + (i64)t * D;
        const f32* xhat = pXhat + (i64)t * D;
        f32* dx = pDx + (i64)t * D;

        f32 meanDy = 0.0f;
        f32 meanDyX = 0.0f;

        for (i32 d = 0; d < D; ++d)
        {
            f32 dxhat = dy[d] * pGamma[d];
            pGammaGrad[d] += dy[d] * xhat[d];
            pBetaGrad[d] += dy[d];
            meanDy += dxhat;
            meanDyX += dxhat * xhat[d];
        }

        meanDy /= (f32)D;
        meanDyX /= (f32)D;

        f32 invStd = pInvStd[t];
        for (i32 d = 0; d < D; ++d)
        {
            f32 dxhat = dy[d] * pGamma[d];
            dx[d] += invStd * (dxhat - meanDy - xhat[d] * meanDyX);
        }
    }
}

static void
_sc_tiny_llm_linear_forward_scalar(const f32* pX, const f32* pW, const f32* pB, f32* pY,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * K;
        f32* y = pY + (i64)t * N;

        for (i32 n = 0; n < N; ++n)
            y[n] = pB ? pB[n] : 0.0f;

        for (i32 k = 0; k < K; ++k)
        {
            f32 xv = x[k];
            const f32* w = pW + (i64)k * N;
            for (i32 n = 0; n < N; ++n)
                y[n] += xv * w[n];
        }
    }
}

static void
_sc_tiny_llm_linear_backward_weight_scalar(const f32* pX, const f32* pDy,
    f32* pDw, f32* pDb, i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * K;
        const f32* dy = pDy + (i64)t * N;

        for (i32 k = 0; k < K; ++k)
        {
            f32 xv = x[k];
            f32* dw = pDw + (i64)k * N;
            for (i32 n = 0; n < N; ++n)
                dw[n] += xv * dy[n];
        }

        if (pDb)
        {
            for (i32 n = 0; n < N; ++n)
                pDb[n] += dy[n];
        }
    }
}

static f32
_sc_tiny_llm_dot_scalar(const f32* pA, const f32* pB, i32 N)
{
    f32 sum = 0.0f;
    for (i32 i = 0; i < N; ++i)
        sum += pA[i] * pB[i];
    return sum;
}

static void
_sc_tiny_llm_linear_backward_input_scalar(const f32* pDy, const f32* pW, f32* pDx,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* dy = pDy + (i64)t * N;
        f32* dx = pDx + (i64)t * K;

        for (i32 k = 0; k < K; ++k)
        {
            const f32* w = pW + (i64)k * N;
            dx[k] = _sc_tiny_llm_dot_scalar(dy, w, N);
        }
    }
}

static void
_sc_tiny_llm_axpy_scalar(f32* pY, const f32* pX, f32 alpha, i32 N)
{
    for (i32 i = 0; i < N; ++i)
        pY[i] += alpha * pX[i];
}

/*
  ############################################
  DOCS: AVX2 + FMA kernels
  ############################################
*/

#if defined(SC_TINY_LLM_SIMD_X86)

static SC_TINY_LLM_SIMD_AVX2_TARGET f32
_sc_tiny_llm_hsum256(__m256 v)
{
    __m128 lo = _mm256_castps256_ps128(v);
    __m128 hi = _mm256_extractf128_ps(v, 1);
    __m128 sum = _mm_add_ps(lo, hi);
    sum = _mm_hadd_ps(sum, sum);
    sum = _mm_hadd_ps(sum, sum);
    return _mm_cvtss_f32(sum);
}

static SC_TINY_LLM_SIMD_AVX2_TARGET void
_sc_tiny_llm_ln_forward_avx2(const f32* pX, f32* pY, f32* pXhat, f32* pInvStd,
    const f32* pGamma, const f32* pBeta, i32 T, i32 D)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * D;
        f32* y = pY + (i64)t * D;
        f32* xhat = pXhat + (i64)t * D;

        i32 d = 0;
        __m256 vsum = _mm256_setzero_ps();
        for (; d + 8 <= D; d += 8)
            vsum = _mm256_add_ps(vsum, _mm256_loadu_ps(x + d));

        f32 sum = _sc_tiny_llm_hsum256(vsum);
        for (; d < D; ++d)
            sum += x[d];

        f32 mean = sum / (f32)D;
        __m256 vmean = _mm256_set1_ps(mean);

        d = 0;
        __m256 vvar = _mm256_setzero_ps();
        for (; d + 8 <= D; d += 8)
        {
            __m256 diff = _mm256_sub_ps(_mm256_loadu_ps(x + d), vmean);
            vvar = _mm256_fmadd_ps(diff, diff, vvar);
        }

        f32 var = _sc_tiny_llm_hsum256(vvar);
        for (; d < D; ++d)
        {
            f32 diff = x[d] - mean;
            var += diff * diff;
        }
        var /= (f32)D;

        f32 invStd = 1.0f / sqrtf(var + SC_TINY_LLM_SIMD_LN_EPS);
        pInvStd[t] = invStd;
        __m256 vinv = _mm256_set1_ps(invStd);

        d = 0;
        for (; d + 8 <= D; d += 8)
        {
            __m256 xv = _mm256_loadu_ps(x + d);
            __m256 xh = _mm256_mul_ps(_mm256_sub_ps(xv, vmean), vinv);
            _mm256_storeu_ps(xhat + d, xh);
            _mm256_storeu_ps(y + d,
                _mm256_fmadd_ps(xh, _mm256_loadu_ps(pGamma + d), _mm256_loadu_ps(pBeta + d)));
        }

        for (; d < D; ++d)
        {
            f32 value = (x[d] - mean) * invStd;
            xhat[d] = value;
            y[d] = value * pGamma[d] + pBeta[d];
        }
    }
}

static SC_TINY_LLM_SIMD_AVX2_TARGET void
_sc_tiny_llm_ln_backward_add_avx2(const f32* pDy, const f32* pXhat, const f32* pInvStd,
    const f32* pGamma, f32* pGammaGrad, f32* pBetaGrad, f32* pDx, i32 T, i32 D)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* dy = pDy + (i64)t * D;
        const f32* xhat = pXhat + (i64)t * D;
        f32* dx = pDx + (i64)t * D;

        i32 d = 0;
        __m256 vMeanDy = _mm256_setzero_ps();
        __m256 vMeanDyX = _mm256_setzero_ps();

        for (; d + 8 <= D; d += 8)
        {
            __m256 dyv = _mm256_loadu_ps(dy + d);
            __m256 xhv = _mm256_loadu_ps(xhat + d);
            __m256 gv = _mm256_loadu_ps(pGamma + d);
            __m256 dxh = _mm256_mul_ps(dyv, gv);

            _mm256_storeu_ps(pGammaGrad + d,
                _mm256_fmadd_ps(dyv, xhv, _mm256_loadu_ps(pGammaGrad + d)));
            _mm256_storeu_ps(pBetaGrad + d,
                _mm256_add_ps(_mm256_loadu_ps(pBetaGrad + d), dyv));

            vMeanDy = _mm256_add_ps(vMeanDy, dxh);
            vMeanDyX = _mm256_fmadd_ps(dxh, xhv, vMeanDyX);
        }

        f32 meanDy = _sc_tiny_llm_hsum256(vMeanDy);
        f32 meanDyX = _sc_tiny_llm_hsum256(vMeanDyX);
        for (; d < D; ++d)
        {
            f32 dxhat = dy[d] * pGamma[d];
            pGammaGrad[d] += dy[d] * xhat[d];
            pBetaGrad[d] += dy[d];
            meanDy += dxhat;
            meanDyX += dxhat * xhat[d];
        }

        meanDy /= (f32)D;
        meanDyX /= (f32)D;

        f32 invStd = pInvStd[t];
        __m256 vmd = _mm256_set1_ps(meanDy);
        __m256 vmdx = _mm256_set1_ps(meanDyX);
        __m256 vinv = _mm256_set1_ps(invStd);

        d = 0;
        for (; d + 8 <= D; d += 8)
        {
            __m256 dyv = _mm256_loadu_ps(dy + d);
            __m256 xhv = _mm256_loadu_ps(xhat + d);
            __m256 gv = _mm256_loadu_ps(pGamma + d);
            __m256 dxh = _mm256_mul_ps(dyv, gv);
            __m256 value = _mm256_sub_ps(_mm256_sub_ps(dxh, vmd), _mm256_mul_ps(xhv, vmdx));
            _mm256_storeu_ps(dx + d,
                _mm256_add_ps(_mm256_loadu_ps(dx + d), _mm256_mul_ps(vinv, value)));
        }

        for (; d < D; ++d)
        {
            f32 dxhat = dy[d] * pGamma[d];
            dx[d] += invStd * (dxhat - meanDy - xhat[d] * meanDyX);
        }
    }
}

static SC_TINY_LLM_SIMD_AVX2_TARGET void
_sc_tiny_llm_linear_forward_avx2(const f32* pX, const f32* pW, const f32* pB, f32* pY,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * K;
        f32* y = pY + (i64)t * N;

        i32 n = 0;
        if (pB)
        {
            for (; n + 8 <= N; n += 8)
                _mm256_storeu_ps(y + n, _mm256_loadu_ps(pB + n));
        }
        else
        {
            for (; n + 8 <= N; n += 8)
                _mm256_storeu_ps(y + n, _mm256_setzero_ps());
        }
        for (; n < N; ++n)
            y[n] = pB ? pB[n] : 0.0f;

        for (i32 k = 0; k < K; ++k)
        {
            __m256 xv = _mm256_set1_ps(x[k]);
            const f32* w = pW + (i64)k * N;

            n = 0;
            for (; n + 8 <= N; n += 8)
                _mm256_storeu_ps(y + n,
                    _mm256_fmadd_ps(xv, _mm256_loadu_ps(w + n), _mm256_loadu_ps(y + n)));

            f32 scalar = x[k];
            for (; n < N; ++n)
                y[n] += scalar * w[n];
        }
    }
}

static SC_TINY_LLM_SIMD_AVX2_TARGET void
_sc_tiny_llm_linear_backward_weight_avx2(const f32* pX, const f32* pDy,
    f32* pDw, f32* pDb, i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * K;
        const f32* dy = pDy + (i64)t * N;

        for (i32 k = 0; k < K; ++k)
        {
            __m256 xv = _mm256_set1_ps(x[k]);
            f32* dw = pDw + (i64)k * N;

            i32 n = 0;
            for (; n + 8 <= N; n += 8)
                _mm256_storeu_ps(dw + n,
                    _mm256_fmadd_ps(xv, _mm256_loadu_ps(dy + n), _mm256_loadu_ps(dw + n)));

            f32 scalar = x[k];
            for (; n < N; ++n)
                dw[n] += scalar * dy[n];
        }

        if (pDb)
        {
            i32 n = 0;
            for (; n + 8 <= N; n += 8)
                _mm256_storeu_ps(pDb + n,
                    _mm256_add_ps(_mm256_loadu_ps(pDb + n), _mm256_loadu_ps(dy + n)));

            for (; n < N; ++n)
                pDb[n] += dy[n];
        }
    }
}

static SC_TINY_LLM_SIMD_AVX2_TARGET f32
_sc_tiny_llm_dot_avx2(const f32* pA, const f32* pB, i32 N)
{
    i32 i = 0;
    __m256 s0 = _mm256_setzero_ps();
    __m256 s1 = _mm256_setzero_ps();
    __m256 s2 = _mm256_setzero_ps();
    __m256 s3 = _mm256_setzero_ps();

    for (; i + 32 <= N; i += 32)
    {
        s0 = _mm256_fmadd_ps(_mm256_loadu_ps(pA + i), _mm256_loadu_ps(pB + i), s0);
        s1 = _mm256_fmadd_ps(_mm256_loadu_ps(pA + i + 8), _mm256_loadu_ps(pB + i + 8), s1);
        s2 = _mm256_fmadd_ps(_mm256_loadu_ps(pA + i + 16), _mm256_loadu_ps(pB + i + 16), s2);
        s3 = _mm256_fmadd_ps(_mm256_loadu_ps(pA + i + 24), _mm256_loadu_ps(pB + i + 24), s3);
    }

    for (; i + 8 <= N; i += 8)
        s0 = _mm256_fmadd_ps(_mm256_loadu_ps(pA + i), _mm256_loadu_ps(pB + i), s0);

    s0 = _mm256_add_ps(_mm256_add_ps(s0, s1), _mm256_add_ps(s2, s3));

    f32 sum = _sc_tiny_llm_hsum256(s0);
    for (; i < N; ++i)
        sum += pA[i] * pB[i];

    return sum;
}

static SC_TINY_LLM_SIMD_AVX2_TARGET void
_sc_tiny_llm_linear_backward_input_avx2(const f32* pDy, const f32* pW, f32* pDx,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* dy = pDy + (i64)t * N;
        f32* dx = pDx + (i64)t * K;

        for (i32 k = 0; k < K; ++k)
            dx[k] = _sc_tiny_llm_dot_avx2(dy, pW + (i64)k * N, N);
    }
}

static SC_TINY_LLM_SIMD_AVX2_TARGET void
_sc_tiny_llm_axpy_avx2(f32* pY, const f32* pX, f32 alpha, i32 N)
{
    i32 i = 0;
    __m256 va = _mm256_set1_ps(alpha);

    for (; i + 8 <= N; i += 8)
        _mm256_storeu_ps(pY + i,
            _mm256_fmadd_ps(va, _mm256_loadu_ps(pX + i), _mm256_loadu_ps(pY + i)));

    for (; i < N; ++i)
        pY[i] += alpha * pX[i];
}

#endif // SC_TINY_LLM_SIMD_X86

/*
  ############################################
  DOCS: Dispatch table
  ############################################
*/

typedef struct
{
    void (*LnForward)(const f32*, f32*, f32*, f32*, const f32*, const f32*, i32, i32);
    void (*LnBackwardAdd)(const f32*, const f32*, const f32*, const f32*, f32*, f32*, f32*, i32, i32);
    void (*LinearForward)(const f32*, const f32*, const f32*, f32*, i32, i32, i32);
    void (*LinearBackwardWeight)(const f32*, const f32*, f32*, f32*, i32, i32, i32);
    void (*LinearBackwardInput)(const f32*, const f32*, f32*, i32, i32, i32);
    f32 (*Dot)(const f32*, const f32*, i32);
    void (*Axpy)(f32*, const f32*, f32, i32);
} ScTinyLlmSimdTable;

static const ScTinyLlmSimdTable cScalarTable = {
    .LnForward = _sc_tiny_llm_ln_forward_scalar,
    .LnBackwardAdd = _sc_tiny_llm_ln_backward_add_scalar,
    .LinearForward = _sc_tiny_llm_linear_forward_scalar,
    .LinearBackwardWeight = _sc_tiny_llm_linear_backward_weight_scalar,
    .LinearBackwardInput = _sc_tiny_llm_linear_backward_input_scalar,
    .Dot = _sc_tiny_llm_dot_scalar,
    .Axpy = _sc_tiny_llm_axpy_scalar,
};

#if defined(SC_TINY_LLM_SIMD_X86)
static const ScTinyLlmSimdTable cAvx2Table = {
    .LnForward = _sc_tiny_llm_ln_forward_avx2,
    .LnBackwardAdd = _sc_tiny_llm_ln_backward_add_avx2,
    .LinearForward = _sc_tiny_llm_linear_forward_avx2,
    .LinearBackwardWeight = _sc_tiny_llm_linear_backward_weight_avx2,
    .LinearBackwardInput = _sc_tiny_llm_linear_backward_input_avx2,
    .Dot = _sc_tiny_llm_dot_avx2,
    .Axpy = _sc_tiny_llm_axpy_avx2,
};
#endif

static ScTinyLlmSimdTable gTinyLlmSimd = {
    .LnForward = _sc_tiny_llm_ln_forward_scalar,
    .LnBackwardAdd = _sc_tiny_llm_ln_backward_add_scalar,
    .LinearForward = _sc_tiny_llm_linear_forward_scalar,
    .LinearBackwardWeight = _sc_tiny_llm_linear_backward_weight_scalar,
    .LinearBackwardInput = _sc_tiny_llm_linear_backward_input_scalar,
    .Dot = _sc_tiny_llm_dot_scalar,
    .Axpy = _sc_tiny_llm_axpy_scalar,
};

static ScTinyLlmCpuBackend gTinyLlmBackend = ScTinyLlmCpu_Scalar;
static i32 gTinyLlmSimdReady = 0;
static i32 gTinyLlmHasAvx2 = 0;
static i32 gTinyLlmHasFma = 0;
// DOCS: AVX2-бэкенд доступен только когда есть и AVX2, и FMA.
static i32 gTinyLlmBackendAvx2 = 0;

static void
_sc_tiny_llm_simd_select(ScTinyLlmCpuBackend backend)
{
    if (backend == ScTinyLlmCpu_Avx2)
    {
#if defined(SC_TINY_LLM_SIMD_X86)
        if (gTinyLlmBackendAvx2)
        {
            gTinyLlmSimd = cAvx2Table;
            gTinyLlmBackend = ScTinyLlmCpu_Avx2;
            return;
        }
#endif
        return;
    }

    gTinyLlmSimd = cScalarTable;
    gTinyLlmBackend = ScTinyLlmCpu_Scalar;
}

void
sc_tiny_llm_simd_init(void)
{
    if (gTinyLlmSimdReady)
        return;

    gTinyLlmHasAvx2 = 0;
    gTinyLlmHasFma = 0;
    gTinyLlmBackendAvx2 = 0;

    if (_sc_tiny_llm_cpu_has_avx2_fma(&gTinyLlmHasAvx2, &gTinyLlmHasFma) && gTinyLlmHasAvx2)
    {
        gTinyLlmBackendAvx2 = 1;
        _sc_tiny_llm_simd_select(ScTinyLlmCpu_Avx2);
    }
    else
        _sc_tiny_llm_simd_select(ScTinyLlmCpu_Scalar);

    gTinyLlmSimdReady = 1;
}

ScTinyLlmCpuBackend
sc_tiny_llm_simd_backend(void)
{
    sc_tiny_llm_simd_init();
    return gTinyLlmBackend;
}

const char*
sc_tiny_llm_simd_backend_name(void)
{
    sc_tiny_llm_simd_init();
    return gTinyLlmBackend == ScTinyLlmCpu_Avx2 ? "avx2+fma" : "scalar";
}

i32
sc_tiny_llm_simd_has_avx2(void)
{
    sc_tiny_llm_simd_init();
    return gTinyLlmHasAvx2;
}

i32
sc_tiny_llm_simd_has_fma(void)
{
    sc_tiny_llm_simd_init();
    return gTinyLlmHasFma;
}

i32
sc_tiny_llm_simd_force_backend(ScTinyLlmCpuBackend backend)
{
    sc_tiny_llm_simd_init();

    if (backend == ScTinyLlmCpu_Scalar)
    {
        _sc_tiny_llm_simd_select(ScTinyLlmCpu_Scalar);
        return 1;
    }

    if (backend == ScTinyLlmCpu_Avx2 && gTinyLlmBackendAvx2)
    {
        _sc_tiny_llm_simd_select(ScTinyLlmCpu_Avx2);
        return 1;
    }

    return 0;
}

/*
  ############################################
  DOCS: Public kernel entry points
  ############################################
*/

void
sc_tiny_llm_simd_ln_forward(const f32* pX, f32* pY, f32* pXhat, f32* pInvStd,
    const f32* pGamma, const f32* pBeta, i32 T, i32 D)
{
    sc_tiny_llm_simd_init();
    gTinyLlmSimd.LnForward(pX, pY, pXhat, pInvStd, pGamma, pBeta, T, D);
}

void
sc_tiny_llm_simd_ln_backward_add(const f32* pDy, const f32* pXhat, const f32* pInvStd,
    const f32* pGamma, f32* pGammaGrad, f32* pBetaGrad, f32* pDx, i32 T, i32 D)
{
    sc_tiny_llm_simd_init();
    gTinyLlmSimd.LnBackwardAdd(pDy, pXhat, pInvStd, pGamma, pGammaGrad, pBetaGrad, pDx, T, D);
}

void
sc_tiny_llm_simd_linear_forward(const f32* pX, const f32* pW, const f32* pB, f32* pY,
    i32 T, i32 K, i32 N)
{
    sc_tiny_llm_simd_init();
    gTinyLlmSimd.LinearForward(pX, pW, pB, pY, T, K, N);
}

void
sc_tiny_llm_simd_linear_backward_weight(const f32* pX, const f32* pDy,
    f32* pDw, f32* pDb, i32 T, i32 K, i32 N)
{
    sc_tiny_llm_simd_init();
    gTinyLlmSimd.LinearBackwardWeight(pX, pDy, pDw, pDb, T, K, N);
}

void
sc_tiny_llm_simd_linear_backward_input(const f32* pDy, const f32* pW, f32* pDx,
    i32 T, i32 K, i32 N)
{
    sc_tiny_llm_simd_init();
    gTinyLlmSimd.LinearBackwardInput(pDy, pW, pDx, T, K, N);
}

f32
sc_tiny_llm_simd_dot(const f32* pA, const f32* pB, i32 N)
{
    sc_tiny_llm_simd_init();
    return gTinyLlmSimd.Dot(pA, pB, N);
}

void
sc_tiny_llm_simd_axpy(f32* pY, const f32* pX, f32 alpha, i32 N)
{
    sc_tiny_llm_simd_init();
    gTinyLlmSimd.Axpy(pY, pX, alpha, N);
}

/*
  ############################################
  DOCS: Self-test: scalar vs AVX2
  ############################################
*/

static f32
_sc_tiny_llm_test_value(u32* pState)
{
    *pState = *pState * 1664525u + 1013904223u;
    return ((f32)((*pState >> 8) & 0xFFFFu) / 32767.5f) - 1.0f;
}

static void
_sc_tiny_llm_test_fill(f32* pData, i32 count, u32* pState, f32 base)
{
    for (i32 i = 0; i < count; ++i)
        pData[i] = base + 0.5f * _sc_tiny_llm_test_value(pState);
}

static i32
_sc_tiny_llm_test_close(const f32* pA, const f32* pB, i32 count, f32 tolerance)
{
    for (i32 i = 0; i < count; ++i)
    {
        f32 diff = pA[i] - pB[i];
        if (diff < 0.0f)
            diff = -diff;

        f32 scale = 1.0f + (pA[i] < 0.0f ? -pA[i] : pA[i]) + (pB[i] < 0.0f ? -pB[i] : pB[i]);
        if (diff > tolerance * scale)
            return 0;
    }

    return 1;
}


i32
sc_tiny_llm_simd_self_test(f32 tolerance)
{
    sc_tiny_llm_simd_init();

    // DOCS: На CPU без AVX2+FMA сравнивать нечего: бэкенд один, ошибки нет.
    if (!gTinyLlmBackendAvx2)
        return 1;

    const i32 T = 3;
    const i32 K = 37;
    const i32 N = 53;
    const i32 D = 37;

    i32 ctxCount = T * K;      // 111
    i32 outCount = T * N;      // 159
    i32 weightCount = K * N;   // 1961
    i32 lnCount = T * D;       // 111

    f32* pX = (f32*)malloc(sizeof(f32) * (i64)ctxCount);
    f32* pW = (f32*)malloc(sizeof(f32) * (i64)weightCount);
    f32* pB = (f32*)malloc(sizeof(f32) * (i64)N);
    f32* pDy = (f32*)malloc(sizeof(f32) * (i64)outCount);

    f32* pDx1 = (f32*)malloc(sizeof(f32) * (i64)ctxCount);
    f32* pDx2 = (f32*)malloc(sizeof(f32) * (i64)ctxCount);
    f32* pDw1 = (f32*)malloc(sizeof(f32) * (i64)weightCount);
    f32* pDw2 = (f32*)malloc(sizeof(f32) * (i64)weightCount);
    f32* pDb1 = (f32*)malloc(sizeof(f32) * (i64)N);
    f32* pDb2 = (f32*)malloc(sizeof(f32) * (i64)N);
    f32* pY1 = (f32*)malloc(sizeof(f32) * (i64)outCount);
    f32* pY2 = (f32*)malloc(sizeof(f32) * (i64)outCount);

    f32* pLnX = (f32*)malloc(sizeof(f32) * (i64)lnCount);
    f32* pLnY1 = (f32*)malloc(sizeof(f32) * (i64)lnCount);
    f32* pLnY2 = (f32*)malloc(sizeof(f32) * (i64)lnCount);
    f32* pXhat1 = (f32*)malloc(sizeof(f32) * (i64)lnCount);
    f32* pXhat2 = (f32*)malloc(sizeof(f32) * (i64)lnCount);
    f32* pInv1 = (f32*)malloc(sizeof(f32) * (i64)T);
    f32* pInv2 = (f32*)malloc(sizeof(f32) * (i64)T);
    f32* pGamma = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pBeta = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pGG1 = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pGG2 = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pBG1 = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pBG2 = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pGGBase = (f32*)malloc(sizeof(f32) * (i64)D);
    f32* pBGBase = (f32*)malloc(sizeof(f32) * (i64)D);

    i32 result = 0;

    if (!pX || !pW || !pB || !pDy || !pDx1 || !pDx2 || !pDw1 || !pDw2 || !pDb1 || !pDb2 ||
        !pY1 || !pY2 || !pLnX || !pLnY1 || !pLnY2 || !pXhat1 || !pXhat2 || !pInv1 || !pInv2 ||
        !pGamma || !pBeta || !pGG1 || !pGG2 || !pBG1 || !pBG2 || !pGGBase || !pBGBase)
        goto cleanup;

    u32 state = 0x12345678u;
    _sc_tiny_llm_test_fill(pX, ctxCount, &state, 0.0f);
    _sc_tiny_llm_test_fill(pW, weightCount, &state, 0.0f);
    _sc_tiny_llm_test_fill(pB, N, &state, 0.0f);
    _sc_tiny_llm_test_fill(pDy, outCount, &state, 0.0f);
    _sc_tiny_llm_test_fill(pGamma, D, &state, 1.0f);
    _sc_tiny_llm_test_fill(pBeta, D, &state, 0.0f);

    // DOCS: 1. Linear forward + bias.
    _sc_tiny_llm_linear_forward_scalar(pX, pW, pB, pY1, T, K, N);
#if defined(SC_TINY_LLM_SIMD_X86)
    _sc_tiny_llm_linear_forward_avx2(pX, pW, pB, pY2, T, K, N);
#else
    goto cleanup;
#endif
    if (!_sc_tiny_llm_test_close(pY1, pY2, outCount, tolerance))
        goto cleanup;

    // DOCS: 2. Linear backward: weight/bias gradients.
    for (i32 i = 0; i < weightCount; ++i)
    {
        pDw1[i] = 0.0f;
        pDw2[i] = 0.0f;
    }
    for (i32 i = 0; i < N; ++i)
    {
        pDb1[i] = 0.0f;
        pDb2[i] = 0.0f;
    }

    _sc_tiny_llm_linear_backward_weight_scalar(pX, pDy, pDw1, pDb1, T, K, N);
#if defined(SC_TINY_LLM_SIMD_X86)
    _sc_tiny_llm_linear_backward_weight_avx2(pX, pDy, pDw2, pDb2, T, K, N);
#endif
    if (!_sc_tiny_llm_test_close(pDw1, pDw2, weightCount, tolerance))
        goto cleanup;
    if (!_sc_tiny_llm_test_close(pDb1, pDb2, N, tolerance))
        goto cleanup;

    // DOCS: 3. Linear backward: input gradient.
    _sc_tiny_llm_linear_backward_input_scalar(pDy, pW, pDx1, T, K, N);
#if defined(SC_TINY_LLM_SIMD_X86)
    _sc_tiny_llm_linear_backward_input_avx2(pDy, pW, pDx2, T, K, N);
#endif
    if (!_sc_tiny_llm_test_close(pDx1, pDx2, ctxCount, tolerance))
        goto cleanup;

    // DOCS: 4. LayerNorm forward (D = 37: хвост вектора тоже проверяется).
    for (i32 i = 0; i < lnCount; ++i)
    {
        pLnX[i] = pX[i];
        pLnY1[i] = 0.0f;
        pLnY2[i] = 0.0f;
        pXhat1[i] = 0.0f;
        pXhat2[i] = 0.0f;
    }

    _sc_tiny_llm_ln_forward_scalar(pLnX, pLnY1, pXhat1, pInv1, pGamma, pBeta, T, D);
#if defined(SC_TINY_LLM_SIMD_X86)
    _sc_tiny_llm_ln_forward_avx2(pLnX, pLnY2, pXhat2, pInv2, pGamma, pBeta, T, D);
#endif
    if (!_sc_tiny_llm_test_close(pLnY1, pLnY2, lnCount, tolerance))
        goto cleanup;
    if (!_sc_tiny_llm_test_close(pXhat1, pXhat2, lnCount, tolerance))
        goto cleanup;
    if (!_sc_tiny_llm_test_close(pInv1, pInv2, T, tolerance))
        goto cleanup;

    // DOCS: 5. LayerNorm backward: dx и градиенты gamma/beta.
    _sc_tiny_llm_test_fill(pGGBase, D, &state, 0.0f);
    _sc_tiny_llm_test_fill(pBGBase, D, &state, 0.0f);

    for (i32 i = 0; i < D; ++i)
    {
        pGG1[i] = pGGBase[i];
        pGG2[i] = pGGBase[i];
        pBG1[i] = pBGBase[i];
        pBG2[i] = pBGBase[i];
    }
    for (i32 i = 0; i < ctxCount; ++i)
    {
        pDx1[i] = 0.0f;
        pDx2[i] = 0.0f;
    }

    _sc_tiny_llm_ln_backward_add_scalar(pDy, pXhat1, pInv1, pGamma,
        pGG1, pBG1, pDx1, T, D);
#if defined(SC_TINY_LLM_SIMD_X86)
    _sc_tiny_llm_ln_backward_add_avx2(pDy, pXhat1, pInv1, pGamma,
        pGG2, pBG2, pDx2, T, D);
#endif
    if (!_sc_tiny_llm_test_close(pDx1, pDx2, ctxCount, tolerance))
        goto cleanup;
    if (!_sc_tiny_llm_test_close(pGG1, pGG2, D, tolerance))
        goto cleanup;
    if (!_sc_tiny_llm_test_close(pBG1, pBG2, D, tolerance))
        goto cleanup;

    // DOCS: 6. dot + axpy (attention primitives).
    {
        f32 dotRef = _sc_tiny_llm_dot_scalar(pX, pW, K);
        f32 dotAvx = 0.0f;
#if defined(SC_TINY_LLM_SIMD_X86)
        dotAvx = _sc_tiny_llm_dot_avx2(pX, pW, K);
#endif
        f32 diff = dotRef - dotAvx;
        if (diff < 0.0f)
            diff = -diff;
        if (diff > tolerance * (1.0f + (dotRef < 0.0f ? -dotRef : dotRef)))
            goto cleanup;

        for (i32 i = 0; i < ctxCount; ++i)
        {
            pY1[i] = pX[i];
            pY2[i] = pX[i];
        }
        _sc_tiny_llm_axpy_scalar(pY1, pW, 0.75f, ctxCount);
#if defined(SC_TINY_LLM_SIMD_X86)
        _sc_tiny_llm_axpy_avx2(pY2, pW, 0.75f, ctxCount);
#endif
        if (!_sc_tiny_llm_test_close(pY1, pY2, ctxCount, tolerance))
            goto cleanup;
    }

    result = 1;

cleanup:
    free(pX);
    free(pW);
    free(pB);
    free(pDy);
    free(pDx1);
    free(pDx2);
    free(pDw1);
    free(pDw2);
    free(pDb1);
    free(pDb2);
    free(pY1);
    free(pY2);
    free(pLnX);
    free(pLnY1);
    free(pLnY2);
    free(pXhat1);
    free(pXhat2);
    free(pInv1);
    free(pInv2);
    free(pGamma);
    free(pBeta);
    free(pGG1);
    free(pGG2);
    free(pBG1);
    free(pBG2);
    free(pGGBase);
    free(pBGBase);

    return result;
}