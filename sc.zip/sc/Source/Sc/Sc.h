#ifndef SC_H
#define SC_H

#include "Types.h"
#include <stdarg.h>

/*
  Content:

  WIP - not complete, need more code to be complete.
  TEST - need more auto test;s in auto test sample project.
  READY - tested or validated.

READY:
  [sc_sleep] - sleep function;s.

TEST:
  [sc_utf8] - utf-8 functionality.
  [sc_parse] - parse string to base types.
  - TEST: sc_parse_skip_space
  - TEST: sc_parse_skip_until
  [sc_*_to_string] - base types to string convertion.
  [sc_char] - char api.
  [sc_string & WIP] - string api.
  [sc_string (object)] - string object api.
  [sc_format & TEST] - funcs for string formating %s %c %d %f .
  [sc_other] -
  [sc_list] - dynamic array implementation, like List<T> in C#, but faster and implemented in C99 (modern, cool, easy to use and fast enought to not worry about performance).
  [sc_dict / sc_dict_s / sc_dict_i & TEST] - Dictionary or HashTable with int and string key;s.
  - remove funct need;s some bug fixing
  [sc_grid] - grid[x][y][z]
  [sc_builder & TEST] - string builder.
  [sc_file & TEST] - read/write/get metadata of file.
  [sc_directory & WIP] - dir functions.
  [sc_path & WIP] - path api for get name, exts, etc
  - IMPL: for windows sc_path_get_random_temp
  - IMPL: for sc_path_get_random_temp_ext

  [sc_memory & WIP] - base allocator for EVERYTHING, also arena.
  [sc_arena & WIP] - arena allocator

  [sc_thread] - pthread && win thread abstraction, cross-platform
  [sc_mutex] - pmutex && win mutex abstraction, cross-platform
  [sc_condition]
  [sc_rwlock] - read/write lock.
  [sc_job & TEST] - job system

  [sc_profiler & TEST] - profiler for nanoseconds metric.
  [sc_date_time] - date time
  [sc_timer & TEST] - timer for once_in_seconds(5) events
  [sc_log] - logging, yeah.
  [sc_bitset] - bitset for 64, 128, 256, 512, 1024 bits, u can typedef new bitset if needed.
  [sc_random] - random number generator, crypt friendly if neeeded

  Patterns:

  [*] debug extension pattern (sc_string_get_length_ext_r/sc_string_get_length_ext_d)

  - define preprocessor for enabling checks
  #define SC_DEBUG_EXTENSION_PATTERN_DEBUG 1
  - define preprocessor for enabling (slow) but very detailed validation for functions
  #define SC_DEBUG_EXTENSION_PATTERN_DEEP_DEBUG 1


  Convention:

  lowercase for basic types: i32, f32, real, v2, v4, mat4
  pascal case for more complex types: ScTimer, ScString

  wo_alloc - means result is not allocated on a heap;
  _init - initialization of code, no value returned
  _new - construction function, return;s value.


  TODO:
  * Create struct ScCallingContext to pass __FILE__, __LINE__ for function-wrappers



WIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREAWIP AREA WIP AREA WIP AREA


  [Bitset.h] - bitset for huge bitsets
  [FpsCounter.h] - counter for fps, should be run inside app loop,
  pass function for geting app time to fps count and you can get fps
  [GlobalHelpers.h] - just some shit without group
  [RingQueue.h] - ring queue based on Array.h
  [SimpleSerializer.h] - for base types, f32, i32, v2, v3, v4, m2, m3, m4
  [SimpleImage.h] - rgba image, very inefficient
  [SimpleSocket.h] - abstraction over linux/windows Berkley sockets,
  cross-platform as all code in this SSL

*/

#if defined(SC_BUILD_DEBUG)

#if !defined(SC_DEBUG_EXTENSION_PATTERN_DEBUG)
#define SC_DEBUG_EXTENSION_PATTERN_DEBUG 1
#endif // !defined(SC_DEBUG_EXTENSION_PATTERN_DEBUG)

#if !defined(SC_DEBUG_EXTENSION_PATTERN_DEEP_DEBUG)
#define SC_DEBUG_EXTENSION_PATTERN_DEEP_DEBUG 0
#endif // !defined(SC_DEBUG_EXTENSION_PATTERN_DEBUG)

#endif // defined(SC_BUILD_DEBUG)

/*

  ###################################
  ###################################
  sc_sleep
  ###################################
  ###################################

*/

void sc_sleep_ms(i32 ms);

/*

  ###################################
  ###################################
  sc_utf8
  ###################################
  ###################################

*/

// DOCS: Get size in bytes of Unicde string
u64 sc_utf8_unicode_size(u32* aUnicodes, u64 length);
// DOCS: Get count of unicode character's encoded into utf8 string.
i64 sc_utf8_length(char* pInput);
// DOCS: Get size in bytes of utf8 string
u64 sc_utf8_size(char* pInput);
// DOCS: Encode codepoint as utf8 into pOutput buffer.
// Return number of bytes been encoded.
i32 sc_utf8_encode(char* pOutput, u32 codepoint);
// DOCS: Return unicode codepoint from pInput string, and writes
// number of bytes been decoded into pBytesCount if not NULL.
u32 sc_utf8_decode(char* pInput, i32* pBytesCount);
// DOCS: Writes unicode codepoints into already allocated array pUnicodeText.
// Also writes count of unicode symbols into pTextLength if not NULL.
void sc_utf8_get_unicode_text(i32* pUnicodeText, char* pUtf8Text, i64* pTextLength);

/*

  ###################################
  ###################################
  sc_parse
  ###################################
  ###################################

*/

#define sc_ptr_skip_until(ptr, ch, sc) \
    ({                                 \
        while (ch != sc)               \
        {                              \
            ++ptr;                     \
            ch = *ptr;                 \
        }                              \
    })
#define sc_ptr_skip_until_two(ptr, ch, sc1, sc2) \
    ({                                           \
        while (ch != sc1 && ch != sc2)           \
        {                                        \
            ++ptr;                               \
            ch = *ptr;                           \
        }                                        \
    })
#define sc_ptr_next(ptr, ch) ({ ++ptr; ch=*ptr; })
#define sc_ptr_next_n(ptr, ch, n) ({ ptr = ptr + n; ch=*ptr; })
#define sc_ptr_diff(ptr0, ptr1) ({ ((char*)ptr1) - ((char*)ptr0) + 1; })

typedef struct
{
    i64 IntValue;
    char* pInput;
    char* pOutput;
} ScParsedInt;

ScParsedInt sc_parse_int_while_int(char* pInput);
i64 sc_parse_int(char* pBuffer, i64 bufferLength);
f64 sc_parse_float(char* pBuffer, i64 bufferLength);
char* sc_parse_skip_space(char* pString);
char* sc_parse_skip_while(char* pString, char* aSymbols, i32 symbolsCount);

/*

  ###################################
  ###################################
  sc_*_to_string
  ###################################
  ###################################

*/

i64 sc_int_to_string(char* pBuffer, i64 bufferLength, i64 intValue);
i64 sc_float_to_string_ext(char* pBuffer, i64 bufferLength, f64 floatValue, f64 threshold);
i64 sc_float_to_string(char* pBuffer, i64 bufferLength, f64 floatValue);
i32 sc_v_to_string(char* pBuf, u64 bufSize, real* pArr, i32 arrCount, f64 accuracy);
i32 sc_v2_to_string(char* pBuf, u64 bufSize, v2 v, f64 accuracy);
i32 sc_v3_to_string(char* pBuf, u64 bufSize, v3 v, f64 accuracy);
i32 sc_v4_to_string(char* pBuf, u64 bufSize, v4 v, f64 accuracy);
i32 sc_quat_to_string(char* pBuf, u64 bufSize, quat q, f64 accuracy);

/*

  ###################################
  ###################################
  sc_char
  ###################################
  ###################################

*/

force_inline i32
sc_char_is_whitespace(char c)
{
    switch (c)
    {
    case ' ':
    case '\n':
    case '\r':
    case '\t':
    case '\v':
        return 1;
    default:
        return 0;
    }
}

force_inline i32
sc_char_is_upper(char c)
{
    switch (c)
    {
    case 'A':
    case 'B':
    case 'C':
    case 'D':
    case 'E':
    case 'F':
    case 'G':
    case 'H':
    case 'I':
    case 'J':
    case 'K':
    case 'L':
    case 'M':
    case 'N':
    case 'O':
    case 'P':
    case 'Q':
    case 'R':
    case 'S':
    case 'T':
    case 'U':
    case 'V':
    case 'W':
    case 'X':
    case 'Y':
    case 'Z':
        return 1;
    default:
        return 0;
    }
}

force_inline i32
sc_char_is_lower(char c)
{
    switch (c)
    {
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
    case 'g':
    case 'h':
    case 'i':
    case 'j':
    case 'k':
    case 'l':
    case 'm':
    case 'n':
    case 'o':
    case 'p':
    case 'q':
    case 'r':
    case 's':
    case 't':
    case 'u':
    case 'v':
    case 'w':
    case 'x':
    case 'y':
    case 'z':
        return 1;
    default:
        return 0;
    }
}

force_inline i32
sc_char_is_letter(char c)
{
    switch (c)
    {
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
    case 'g':
    case 'h':
    case 'i':
    case 'j':
    case 'k':
    case 'l':
    case 'm':
    case 'n':
    case 'o':
    case 'p':
    case 'q':
    case 'r':
    case 's':
    case 't':
    case 'u':
    case 'v':
    case 'w':
    case 'x':
    case 'y':
    case 'z':
    case 'A':
    case 'B':
    case 'C':
    case 'D':
    case 'E':
    case 'F':
    case 'G':
    case 'H':
    case 'I':
    case 'J':
    case 'K':
    case 'L':
    case 'M':
    case 'N':
    case 'O':
    case 'P':
    case 'Q':
    case 'R':
    case 'S':
    case 'T':
    case 'U':
    case 'V':
    case 'W':
    case 'X':
    case 'Y':
    case 'Z':
        return 1;
    default:
        return 0;
    }
}

force_inline i32
sc_char_is_integer(char c)
{
    switch (c)
    {
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
        return 1;
    default:
        return 0;
    }
}

force_inline char
sc_char_to_upper(char c)
{
    if (sc_char_is_lower(c))
        return (c - 'a' + 'A');
    return c;
}

force_inline char
sc_char_to_lower(char c)
{
    if (sc_char_is_upper(c))
        return (c - 'A' + 'a');
    return c;
}

/*

  ###################################
  ###################################
  sc_string
  ###################################
  ###################################

*/

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Находим длину строки (NULL-terminated).
#define sc_string_get_length(str) sc_string_get_length_ext_d(str, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_get_length(str) sc_string_get_length_ext_r(str)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Находим длину строки до разделителей (NULL-terminated).
#define sc_string_get_length_to_delimiters(str, del, delLen) sc_string_get_length_to_delimiters_ext_d(str, del, delLen, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_get_length_to_delimiters(str, del, delLen) sc_string_get_length_to_delimiters_ext_r(str, del, delLen)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Хешируем строку (стандартный djb2 hash).
#define sc_string_hash(str, len) sc_string_hash_ext_d(str, len, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_hash(str, len) sc_string_hash_ext_r(str, len)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Сравниваем две строки (NULL-terminated) полностью.
#define sc_string_compare(str0, str1) sc_string_compare_ext_d(str0, str1, #str0, #str1, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_compare(str0, str1) sc_string_compare_ext_r(str0, str1)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Сравниваем две строки по заданной длине.
#define sc_string_compare_ext(str0, str1, len) sc_string_compare_ext_ext_d(str0, str1, len, #str0, #str1, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_compare_ext(str0, str1, len) sc_string_compare_ext_ext_r(str0, str1, len)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Ищем первое вхождение символа в строке.
#define sc_string_index_of(str, ch) sc_string_index_of_ext_d(str, ch, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_index_of(str, ch) sc_string_index_of_ext_r(str, ch)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Ищем первое вхождение подстроки в строке.
#define sc_string_index_of_string(input, str) sc_string_index_of_string_ext_d(input, str, #input, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_index_of_string(input, str) sc_string_index_of_string_ext_r(input, str)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Ищем последнее вхождение символа в строке.
#define sc_string_last_index_of(str, ch) sc_string_last_index_of_ext_d(str, ch, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_last_index_of(str, ch) sc_string_last_index_of_ext_r(str, ch)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Вырезаем подстроку заданной длины.
#define sc_string_substring_length(input, inputLen, cutLen) sc_string_substring_length_ext_d(input, inputLen, cutLen, #input, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_substring_length(input, inputLen, cutLen) sc_string_substring_length_ext_r(input, inputLen, cutLen)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Копируем строку с выделением памяти.
#define sc_string_copy(str, strLen) sc_string_copy_ext_d(str, strLen, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_copy(str, strLen) sc_string_copy_ext_r(str, strLen)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Переводим строку в верхний регистр.
#define sc_string_to_upper(str, strLen) sc_string_to_upper_ext_d(str, strLen, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_to_upper(str, strLen) sc_string_to_upper_ext_r(str, strLen)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Переводим строку в нижний регистр.
#define sc_string_to_lower(str, strLen) sc_string_to_lower_ext_d(str, strLen, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_to_lower(str, strLen) sc_string_to_lower_ext_r(str, strLen)
#endif

i64 sc_string_get_length_ext_r(char* pStr);
u64 sc_string_get_length_to_delimiters_ext_r(char* pString, char aDelimeters[], u64 delimetersLength);
i64 sc_string_hash_ext_r(char* pString, i32 length);
i32 sc_string_compare_ext_r(char* pString0, char* pString1);
i32 sc_string_compare_ext_ext_r(char* pString0, char* pString1, i64 string0Length);
i64 sc_string_index_of_ext_r(char* pString, char character);
i64 sc_string_index_of_string_ext_r(char* pInput, char* pString);
i64 sc_string_last_index_of_ext_r(char* pString, char character);
char* sc_string_substring_length_ext_r(char* pInput, u64 inputLength, i32 lengthToCut);
char* sc_string_copy_ext_r(char* pString, i64 stringLength);
char* sc_string_to_upper_ext_r(char* pString, i64 stringLength);
char* sc_string_to_lower_ext_r(char* pString, i64 stringLength);

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

i64 sc_string_get_length_ext_d(char* pStr, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
u64 sc_string_get_length_to_delimiters_ext_d(char* pString, char aDelimeters[], u64 delimetersLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_hash_ext_d(char* pString, i32 length, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i32 sc_string_compare_ext_d(char* pString0, char* pString1, const char* pExpression0, const char* pExpression1, const char* pFile, i32 line, const char* pFunction);
i32 sc_string_compare_ext_ext_d(char* pString0, char* pString1, i64 string0Length, const char* pExpression0, const char* pExpression1, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_index_of_ext_d(char* pString, char character, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_index_of_string_ext_d(char* pInput, char* pString, const char* pExpression0, const char* pExpression1, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_last_index_of_ext_d(char* pString, char character, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_substring_length_ext_d(char* pInput, u64 inputLength, i32 lengthToCut, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_copy_ext_d(char* pString, i64 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_to_upper_ext_d(char* pString, i64 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_to_lower_ext_d(char* pString, i64 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);

/*

  ###################################
  ###################################
  sc_string (object)
  ###################################
  ###################################

*/

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Получение заголовка строкового объекта.
#define sc_string_header(pString) sc_string_header_ext_d(pString, #pString, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_header(pString) sc_string_header_ext_r(pString)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Получение длины строки строкового объекта.
#define sc_string_length(pString) sc_string_length_ext_d(pString, #pString, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_length(pString) sc_string_length_ext_r(pString)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Получение размера строки строкового объекта.
#define sc_string_size(pString) sc_string_size_ext_d(pString, #pString, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_size(pString) sc_string_size_ext_r(pString)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Создаём строковый объект.
#define sc_string_new(pString) sc_string_new_ext_d(pString, #pString, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_new(pString) sc_string_new_ext_r(pString)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Создаём новую строку с заданной длиной и размером буфера.
#define sc_string_new_ext(pString, length, size) sc_string_new_ext_ext_d(pString, length, size, #pString ", " #length ", " #size, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_new_ext(pString, length, size) sc_string_new_ext_ext_r(pString, length, size)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Создаём обрезанную копию строки (без пробелов по краям).
#define sc_string_new_trimed(pString) sc_string_new_trimed_ext_d(pString, #pString, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_new_trimed(pString) sc_string_new_trimed_ext_r(pString)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Уничтожаем строку, освобождаем память.
#define sc_string_destroy(pString) sc_string_destroy_ext_d(pString, #pString, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_destroy(pString) sc_string_destroy_ext_r(pString)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Получаем длину строки без учёта пробельных символов.
#define sc_string_get_length_wo_whitespaces_ext(pString, size) sc_string_get_length_wo_whitespaces_ext_ext_d(pString, size, #pString ", " #size, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_get_length_wo_whitespaces_ext(pString, size) sc_string_get_length_wo_whitespaces_ext_ext_r(pString, size)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Заменяем подстроку на другую подстроку.
#define sc_string_replace(pString, pOldValue, oldValueLength, pNewValue, newValueLength) sc_string_replace_ext_d(pString, pOldValue, oldValueLength, pNewValue, newValueLength, #pString, #pOldValue, #oldValueLength, #pNewValue, #newValueLength, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_replace(pString, pOldValue, oldValueLength, pNewValue, newValueLength) sc_string_replace_ext_r(pString, pOldValue, oldValueLength, pNewValue, newValueLength)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Заменяем подстроку на символ.
#define sc_string_replace_string_to_char(pString, pOldValue, oldValueLength, newValue) sc_string_replace_string_to_char_ext_d(pString, pOldValue, oldValueLength, newValue, #pString ", " #pOldValue ", " #oldValueLength ", " #newValue, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_replace_string_to_char(pString, pOldValue, oldValueLength, newValue) sc_string_replace_string_to_char_ext_r(pString, pOldValue, oldValueLength, newValue)
#endif

force_inline ScString*
sc_string_header_ext_r(char* pString)
{
    ScString* pHdr = (ScString*)(((char*)pString) - sizeof(ScString));
    return pHdr;
}

force_inline i64
sc_string_length_ext_r(char* pString)
{
    return sc_string_header_ext_r(pString)->Length;
}

force_inline i64
sc_string_size_ext_r(char* pString)
{
    return sc_string_header_ext_r(pString)->Size;
}

char* sc_string_new_ext_r(char* pString);
char* sc_string_new_ext_ext_r(char* pString, i64 length, i64 size);
char* sc_string_new_trimed_ext_r(char* pString);
void sc_string_destroy_ext_r(char* pString);
i64 sc_string_get_length_wo_whitespaces_ext_ext_r(char* pString, i64 size);
char* sc_string_replace_ext_r(char* pString, char* pOldValue, i64 oldValueLength, char* pNewValue, i64 newValueLength);
char* sc_string_replace_string_to_char_ext_r(char* pString, char* pOldValue, i64 oldValueLength, char newValue);

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

ScString* sc_string_header_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_length_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_size_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_new_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_new_ext_ext_d(char* pString, i64 length, i64 size, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_new_trimed_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
void sc_string_destroy_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i64 sc_string_get_length_wo_whitespaces_ext_ext_d(char* pString, i64 size, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_replace_ext_d(char* pString, char* pOldValue, i64 oldValueLength, char* pNewValue, i64 newValueLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_string_replace_string_to_char_ext_d(char* pString, char* pOldValue, i64 oldValueLength, char newValue, const char* pExpression, const char* pFile, i32 line, const char* pFunction);

/*

  ###################################
  ###################################
  sc_string_view (object)
  ###################################
  ###################################

*/

ScStringView sc_string_view_new(char* pData, i64 length);
ScStringView sc_string_view_new_ext(char* pData, i64 length, i64 size);

/*

  ###################################
  ###################################
  sc_format
  ###################################
  ###################################

*/

typedef struct
{
    i8 IsFinished;
    u64 Size;
    const char* pFormat;
} ScFormatResult;

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Форматирование строки с va_list (расширенная версия).
#define sc_format_ext(pBuf, bufSize, pFormat, valist) sc_format_ext_ext_d(pBuf, bufSize, pFormat, valist, #pBuf ", " #bufSize ", " #pFormat ", " #valist, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_format_ext(pBuf, bufSize, pFormat, valist) sc_format_ext_ext_r(pBuf, bufSize, pFormat, valist)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Форматирование строки.
#define sc_format(pBuf, bufSize, pFormat, ...) sc_format_ext_d(pBuf, bufSize, pFormat, #pBuf ", " #bufSize ", " #pFormat, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)
#else
#define sc_format(pBuf, bufSize, pFormat, ...) sc_format_ext_r(pBuf, bufSize, pFormat, ##__VA_ARGS__)
#endif

ScFormatResult sc_format_ext_ext_r(char* pBuf, u64 bufSize, const char* pFormat, va_list valist);
ScFormatResult sc_format_ext_r(char* pBuf, u64 bufSize, const char* pFormat, ...);

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

ScFormatResult sc_format_ext_ext_d(char* pBuf, u64 bufSize, const char* pFormat, va_list valist, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
ScFormatResult sc_format_ext_d(char* pBuf, u64 bufSize, const char* pFormat, const char* pExpression, const char* pFile, i32 line, const char* pFunction, ...);

/*

  ###################################
  ###################################
  sc_other
  ###################################
  ###################################

*/

force_inline i32
sc_i32_hash(i32 key)
{
    u32 ukey = (u32)key;
    ukey = ((ukey >> 16) ^ ukey) * 0x45d9f3b;
    ukey = ((ukey >> 16) ^ ukey) * 0x45d9f3b;
    ukey = (ukey >> 16) ^ ukey;
    return to_i32(key);
}

force_inline i64
sc_i64_hash(i64 key)
{
    u64 u = (u64)key;
    u = (~u) + (u << 21);
    u = u ^ (u >> 24);
    u = (u + (u << 3)) + (u << 8);
    u = u ^ (u >> 14);
    u = (u + (u << 2)) + (u << 4);
    u = u ^ (u >> 28);
    u = u + (u << 31);
    return (i64)u;
}

force_inline u64
sc_u64_hash(u64 key)
{
    u64 u = key;
    u = (~u) + (u << 21);
    u = u ^ (u >> 24);
    u = (u + (u << 3)) + (u << 8);
    u = u ^ (u >> 14);
    u = (u + (u << 2)) + (u << 4);
    u = u ^ (u >> 28);
    u = u + (u << 31);
    return u;
}

// DOCS: to test
force_inline u32
alt_hash(u32 a, u32 b)
{
    u64 x = ((u64)a << 32) | b;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    x = x ^ (x >> 31);
    return (u32)x;
}

i32 sc_get_int_digit(i64 intValue);
i64 sc_int_power(i64 intValue, i32 powerValue);
f64 sc_float_npow(i32 exponent);

/*

  ###################################
  ###################################
  sc_list
  ###################################
  ###################################

*/

typedef struct
{
    i64 Count;
    i64 Capacity;
    void* pData;
} ScListHeader;

force_inline ScListHeader*
sc_list_header(void* pList)
{
    sc_assert_not_null(pList);
    ScListHeader* pHdr = (ScListHeader*)(((char*)pList) - sizeof(ScListHeader));
    return pHdr;
}

force_inline i64
sc_list_count(void* pList)
{
    if (pList == ScNull)
        return 0;

    ScListHeader* pHdr = sc_list_header(pList);
    return pHdr->Count;
}

force_inline i64
sc_list_capacity(void* pList)
{
    if (pList == ScNull)
        return 0;

    ScListHeader* pHdr = sc_list_header(pList);
    return pHdr->Capacity;
}

#define sc_list_add(pList, ...)                        \
    ({                                                 \
        __typeof__(*pList) localItem = __VA_ARGS__;    \
        pList = sc_list_add_ext(                       \
            pList, (void*)&localItem, sizeof(*pList)); \
        pList;                                         \
    })

#define sc_list_add_list(pList, list)     \
    ({                                    \
        __typeof__(list) aList = (list);  \
        pList = sc_list_add_multiple_ext( \
            pList,                        \
            (void*)aList,                 \
            sizeof(aList[0]),             \
            sc_list_count(aList));        \
        pList;                            \
    })

#define sc_list_add_multiple(pList, pData, stride, count) \
    ({                                                    \
        pList = sc_list_add_multiple_ext(                 \
            pList, (void*)pData, stride, count);          \
        pList;                                            \
    })

// todo: test it
#define sc_list_remove(pList, item)                    \
    ({                                                 \
        __typeof__(*pList) localItem = item;           \
        pList = sc_list_remove_ext(                    \
            pList, (void*)&localItem, sizeof(*pList)); \
        pList;                                         \
    })

#define sc_list_remove_index(pList, index) \
    ({                                     \
        pList = sc_list_remove_index_ext(  \
            pList, index, sizeof(*pList)); \
        pList;                             \
    })

#define sc_list_pop(pList)                                \
    ({                                                    \
        sc_guard_not_null(pList);                         \
        __typeof__((pList)[0]) item = pList[0];           \
        pList = sc_list_pop_ext(pList, sizeof(pList[0])); \
        item;                                             \
    })

#define sc_list_reserve(pList, count)                              \
    ({                                                             \
        pList = sc_list_reserve_ext(pList, sizeof(*pList), count); \
    })

#define sc_list_clear(pList)                              \
    ({                                                    \
        pList = sc_list_clear_ext(pList, sizeof(*pList)); \
    })

// todo: refactor
#define sc_list_deep_copy(pList)                      \
    ({                                                \
        sc_list_deep_copy_ext(pList, sizeof(*pList)); \
    })

#define ScDefUni2(a, b) a##b
#define ScDefUni1(a, b) ScDefUni2(a, b)
#define ScDefUni(t) ScDefUni1(t, __LINE__)
#define ScDefTyp(t) __typeof__(t)
#define ScDefPtr(t) __typeof__(t)*

#define sc_list_for_each(pList, item) \
    ScDefPtr(pList[0]) item = pList;  \
    for (i32 index = 0;               \
        index < sc_list_count(pList); \
        ++index, ++item)

#define sc_list_select(pList, field)                   \
    ({                                                 \
        __typeof__((pList)[0].field)* aSel = NULL;     \
        for (i32 i = 0; i < sc_list_count(pList); ++i) \
            sc_list_add(aSel, pList[i].field);         \
        aSel;                                          \
    })

#define sc_list_index_of(pList, indexOfCondition)     \
    ({                                                \
        i64 result = -1;                              \
                                                      \
        if (pList != NULL)                            \
        {                                             \
            i64 cnt = sc_list_count(pList);           \
            for (i64 i = 0; i < cnt; ++i)             \
            {                                         \
                __typeof__(pList[0]) item = pList[i]; \
                if (indexOfCondition)                 \
                {                                     \
                    result = i;                       \
                    break;                            \
                }                                     \
            }                                         \
        }                                             \
                                                      \
        result;                                       \
    })

void sc_list_free(void* pList);
void* sc_list_add_ext(void* pList, void* pData, i32 stride);
void* sc_list_add_multiple_ext(void* pList, void* pData, i32 stride, i64 count);
void* sc_list_remove_ext(void* pList, void* pItem, i32 stride);
void* sc_list_remove_index_ext(void* pList, i32 ind, i32 stride);
void* sc_list_reserve_ext(void* pList, i32 stride, i64 count);
void* sc_list_clear_ext(void* pList, i32 stride);
void* sc_list_deep_copy_ext(void* pList, i32 stride);
void* sc_list_pop_ext(void* pList, i32 stride);

/*

  ###################################
  ###################################
  sc_dict / sc_dict_s / sc_dict_i
  ###################################
  ###################################

*/

#define SC_DICT_EMPTY_KEY SC_I64_MIN

typedef enum
{
    ScDictKeyType_String = 0,
    ScDictKeyType_Long,
} ScDictKeyType;

typedef struct
{
    i32 Count;
    i32 Capacity;
    u32 ItemSize;
    u32 ValueOffset;
    ScDictKeyType Type;
    i64 Index;
    i8* aFlags;
    void* aStorage;
} ScDictHeader;

force_inline ScDictHeader*
sc_dict_header(void* pDict)
{
    ScDictHeader* pHdr = (ScDictHeader*)(((char*)pDict) - sizeof(ScDictHeader));
    return pHdr;
}

force_inline i32
sc_dict_count(void* pDict)
{
    if (!pDict)
        return 0;
    return sc_dict_header(pDict)->Count;
}

force_inline i32
sc_dict_capacity(void* pDict)
{
    if (!pDict)
        return 0;
    return sc_dict_header(pDict)->Capacity;
}

force_inline i32
sc_dict_item_size(void* pDict)
{
    if (!pDict)
        return 0;
    return sc_dict_header(pDict)->ItemSize;
}

force_inline i32
sc_dict_index(void* pDict)
{
    if (!pDict)
        return -1;
    return sc_dict_header(pDict)->Index;
}

force_inline i32
sc_dict_should_grow(void* pDict)
{
    if (!pDict)
        return 1;
    ScDictHeader* pHdr = sc_dict_header(pDict);
    return pHdr->Count >= (pHdr->Capacity * 0.7);
}

// NOTE: Dangarous functions
#define sc_dict_s_get(dict, key)                         \
    ({                                                   \
        ScDictHeader* pHdr = sc_dict_header(dict);       \
        i64 ind = sc_dict_calc_ind_string(pHdr, key, 1); \
        dict[ind].Value;                                 \
    })
#define sc_dict_i_get(dict, key)                       \
    ({                                                 \
        ScDictHeader* pHdr = sc_dict_header(dict);     \
        i64 ind = sc_dict_calc_ind_long(pHdr, key, 1); \
        dict[ind].Value;                               \
    })

#define sc_dict_s_contains(dict, key)                      \
    ({                                                     \
        i64 result = 0;                                    \
        if (dict)                                          \
        {                                                  \
            ScDictHeader* pHdr = sc_dict_header(dict);     \
            i64 ind = sc_dict_calc_ind_string(pHdr,        \
                (char*)(key),                              \
                1);                                        \
            result = (ind != -1 && dict[ind].Key != NULL); \
        }                                                  \
        result;                                            \
    })
#define sc_dict_i_contains(dict, key)                        \
    ({                                                       \
        i64 result = 0;                                      \
        if (dict)                                            \
        {                                                    \
            ScDictHeader* pHdr = sc_dict_header(dict);       \
            i64 ind = sc_dict_calc_ind_long(pHdr, (key), 1); \
            result = (ind != -1 && dict[ind].Key == (key));  \
        }                                                    \
        result;                                              \
    })

#define sc_dict_s_add(dict, key, value)             \
    ({                                              \
        __typeof__(dict[0].Value) tv = value;       \
        dict = sc_dict_add_ext(                     \
            dict,                                   \
            (void*)key,                             \
            (void*)&tv,                             \
            sizeof(dict[0]),                        \
            ScOffsetOf(__typeof__(dict[0]), Value), \
            ScDictKeyType_String);                  \
    })
#define sc_dict_i_add(dict, key, value)             \
    ({                                              \
        __typeof__(dict[0].Key) tk = key;           \
        __typeof__(dict[0].Value) tv = value;       \
        dict = sc_dict_add_ext(                     \
            dict,                                   \
            &tk,                                    \
            &tv,                                    \
            sizeof(dict[0]),                        \
            ScOffsetOf(__typeof__(dict[0]), Value), \
            ScDictKeyType_Long);                    \
    })

#define sc_dict_s_remove(dict, key)           \
    ({                                        \
        dict = sc_dict_remove_key(dict, key); \
    })

#define sc_dict_i_remove(dict, key)           \
    ({                                        \
        __typeof__(dict[0].Key) tk = key;     \
        dict = sc_dict_remove_key(dict, &tk); \
    })

#define sc_dict_get_current(dict)                                   \
    ({                                                              \
        i64 ind = sc_dict_index(dict);                              \
        sc_assert(ind != -1 && "No current item is set for dict!"); \
        dict[ind].Value;                                            \
    })

void* sc_dict_init(u32 recordSize, u32 valueOffset, ScDictKeyType type, u32 startInd);
void sc_dict_free(void* pDict);
void sc_dict_clear(void* pDict);

void* sc_dict_grow_ext(void* pDict);
void* sc_dict_add_ext(void* pDict, void* pKey, void* pValue, u32 recordSize, u32 valueOffset, ScDictKeyType type);
void* sc_dict_remove_key(void* pDict, void* pKey);
i64 sc_dict_calc_ind_long(ScDictHeader* pHdr, i64 key, i8 isGetFunc);
i64 sc_dict_calc_ind_string(ScDictHeader* pHdr, char* pKey, i8 isGetFunc);
i64 sc_dict_calc_ind(void* hTable, void* pKey);

/*

  ###################################
  ###################################
  sc_grid
  ###################################
  ###################################

*/

typedef struct
{
    i32 X;
    i32 Y;
    i32 Z;
    i32 ItemSize;
    void* pData;
} ScGrid;

#define sc_grid_reserve(itemSize, x, y, z)   \
    ({                                       \
        ScGrid* pGrid = sc_grid_reserve_ext( \
            itemSize,                        \
            x,                               \
            y,                               \
            z);                              \
        pGrid;                               \
    })

ScGrid* sc_grid_reserve_ext(i32 itemSize, i32 x, i32 y, i32 z);
void sc_grid_set(ScGrid* pGrid, i32 x, i32 y, i32 z, void* pData);
void* sc_grid_get(ScGrid* pGrid, i32 x, i32 y, i32 z);
void sc_grid_free(ScGrid* pGrid);

/*

  ###################################
  ###################################
  sc_builder
  ###################################
  ###################################

*/

#define sc_builder_new_size 31
#define sc_builder_count(pSb) sc_list_count(pSb)
#define sc_builder_capacity(pSb) sc_list_capacity(pSb)

#define sc_builder_append_char(pSb, c) ({ pSb = sc_builder_append_char_ext(pSb, c); })
// FIX/TODO/todo: this code contains bug
#define sc_builder_append_string(pSb, str, len) ({ pSb = sc_builder_append_string_ext(pSb, str, len); })
#define sc_builder_append_format(pSb, format, ...) ({ pSb = sc_builder_append_format_ext(pSb, format, __VA_ARGS__); })

char* sc_builder_new();
void sc_builder_destroy(char* pSb);
char* sc_builder_append_char_ext(char* pSb, char c);
char* sc_builder_append_string_ext(char* pSb, char* pString, i64 stringLength);
char* sc_builder_append_format_ext(char* pSb, char* pFormat, ...);

/*

  ###################################
  ###################################
  sc_file
  ###################################
  ###################################

*/

typedef struct
{
    u64 LastAccessTime;
    u64 LastCreateTime;
    u64 LastModificationTime;
} ScFileTime;

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Удаляем файл по указанному пути.
#define sc_file_delete(pPath) sc_file_delete_ext_d(pPath, #pPath, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_delete(pPath) sc_file_delete_ext_r(pPath)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Получаем времена́ доступа, создания и изменения файла.
#define sc_file_get_time(pPath) sc_file_get_time_ext_d(pPath, #pPath, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_get_time(pPath) sc_file_get_time_ext_r(pPath)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Получаем размер файла в байтах.
#define sc_file_get_size(pPath) sc_file_get_size_ext_d(pPath, #pPath, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_get_size(pPath) sc_file_get_size_ext_r(pPath)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Читаем весь файл как строку.
#define sc_file_read(pFilePath) sc_file_read_ext_d(pFilePath, #pFilePath, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_read(pFilePath) sc_file_read_ext_r(pFilePath)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Читаем файл как строку, получая длину.
#define sc_file_read_ext(pFilePath, pLength) sc_file_read_ext_ext_d(pFilePath, pLength, #pFilePath ", " #pLength, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_read_ext(pFilePath, pLength) sc_file_read_ext_ext_r(pFilePath, pLength)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Записываем данные в файл (полная перезапись).
#define sc_file_write(pFilePath, pData, dataLength) sc_file_write_ext_d(pFilePath, pData, dataLength, #pFilePath ", " #pData ", " #dataLength, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_write(pFilePath, pData, dataLength) sc_file_write_ext_r(pFilePath, pData, dataLength)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Дописываем строку в конец файла.
#define sc_file_append_string(pFilePath, pData, dataLength) sc_file_append_string_ext_d(pFilePath, pData, dataLength, #pFilePath ", " #pData ", " #dataLength, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_append_string(pFilePath, pData, dataLength) sc_file_append_string_ext_r(pFilePath, pData, dataLength)
#endif

#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
// DOCS: Сравниваем два файла побайтово.
#define sc_file_compare(p0, p1) sc_file_compare_ext_d(p0, p1, #p0, #p1, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_file_compare(p0, p1) sc_file_compare_ext_r(p0, p1)
#endif

ScResult sc_file_delete_ext_r(const char* pPath);
ScFileTime sc_file_get_time_ext_r(const char* pPath);
u64 sc_file_get_size_ext_r(const char* pPath);
char* sc_file_read_ext_r(const char* pFilePath);
char* sc_file_read_ext_ext_r(const char* pFilePath, i64* pLength);
void sc_file_write_ext_r(const char* pFilePath, void* pData, u64 dataLength);
void sc_file_append_string_ext_r(const char* pFilePath, char* pData, u64 dataLength);
i32 sc_file_compare_ext_r(char* p0, char* p1);

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

ScResult sc_file_delete_ext_d(const char* pPath, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
ScFileTime sc_file_get_time_ext_d(const char* pPath, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
u64 sc_file_get_size_ext_d(const char* pPath, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_file_read_ext_d(const char* pFilePath, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
char* sc_file_read_ext_ext_d(const char* pFilePath, i64* pLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
void sc_file_write_ext_d(const char* pFilePath, void* pData, u64 dataLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
void sc_file_append_string_ext_d(const char* pFilePath, char* pData, u64 dataLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction);
i32 sc_file_compare_ext_d(char* p0, char* p1, const char* p0Expression, const char* p1Expression, const char* pFile, i32 line, const char* pFunction);

/*

  ###################################
  ###################################
  sc_directory
  ###################################
  ###################################

*/

typedef enum
{
    ScDirectoryItemType_None = 0,
    ScDirectoryItemType_File,
    ScDirectoryItemType_Directory,
    ScDirectoryItemType_Symlink
} ScDirectoryItemType;

typedef struct
{
    ScDirectoryItemType Type;
    char* pPath;
} ScDirectoryItem;

typedef struct
{
    i8 IsAbsolutePath;
    ScDirectoryItemType Type;
} ScDirectoryGetConfig;

ScResult sc_directory_create(const char* pPath);
ScResult sc_directory_create_recursive(const char* pPath);
// DOCS: Removes directory with all its content (files and subdirectories).
ScResult sc_directory_delete_recursive(const char* pPath);
// DOCS: Change current working directory.
ScResult sc_directory_set_current(const char* pPath);
// DOCS: Absolute path of the current working directory.
// DOCS: Returns raw allocated memory (sc_memory_free), NULL on error.
char* sc_directory_get_current();
ScDirectoryItem* sc_directory_get_items(const char* pPath, ScDirectoryGetConfig config);
char** sc_directory_get_files(const char* pPath, i32 isAbsolute);
char** sc_directory_get_directories(const char* pPath, i32 isAbsolute);
char** sc_directory_get_files(const char* pPath, i32 isAbsolute);

/*

  ###################################
  ###################################
  sc_path
  ###################################
  ###################################

*/

typedef enum
{
    ScPathItemType_Undefined = 0,
    ScPathItemType_File,
    ScPathItemType_Directory,
} ScPathItemType;

ScPathItemType sc_path(const char* pPath);
char* sc_path_get_home_directory_wo_alloc();
// DOCS: this("path/to/file.txt") -> ".txt"
char* sc_path_get_extension_wo_alloc(char* pPath);
// DOCS: this("path/to/file.txt") -> "file.txt"
char* sc_path_get_name_wo_alloc(char* pPath);
// DOCS: this("path/to/file.txt") -> "file"
char* sc_path_get_name_wo_extension(char* path);
// DOCS: this("path/to/file.txt") -> "file" (no mem-allocation)
ScStringView sc_path_get_name_view_wo_extension(char* path);
// DOCS: this("path/to/file.txt") -> "path/to"
char* sc_path_get_directory(char* pPath);
// DOCS: this("path/to", "file.txt") -> "path/to/file.txt"
char* sc_path_combine(char* pLeft, char* pRight);
// DOCS: Random string
char* sc_path_get_random(char* pBuf, u64 bufSize, i32 minLen, i32 maxLen);
// DOCS: Random file in temporary directory.
char* sc_path_get_random_temp();
char* sc_path_get_random_temp_ext(i64 min, i64 max);

/*

  ###################################
  ###################################
  sc_memory
  ###################################
  ###################################

*/

typedef struct
{
    i32 Line;
    i64 Size;
    const char* pFile;
    void* pData;
} ScMemoryRecord;

#if defined(SC_MEMORY_DEBUG)
#define sc_memory_allocate(size) sc_memory_debug_allocate((size), __FILE__, __FUNCTION__, __LINE__)
#define sc_memory_free(pMemory) sc_memory_debug_free(pMemory, __FILE__, __FUNCTION__, __LINE__)
#else
#define sc_memory_allocate(size) sc_memory_allocate_ext((size), __LINE__, __FILE__)
#define sc_memory_free(pMemory) sc_memory_free_ext(pMemory, __LINE__, __FILE__)
#endif // SC_MEMORY_DEBUG

void* sc_memory_allocate_ext(u64 size, i32 line, const char* pFile);
void sc_memory_free_ext(void* pMemory, i32 line, const char* pFile);

void* sc_memory_debug_allocate(u64 size, const char* pFile, const char* pFunction, i32 line);
void sc_memory_debug_free(void* pData, const char* pFile, const char* pFunction, i32 line);

void sc_memory_debug_validate_buffer_overflow();
void sc_memory_debug_validate_buffer_underflow();
void sc_memory_debug_validate_double_free();
void sc_memory_debug_validate_writing_to_free();
void sc_memory_debug_validate();

/*

  ###################################
  ###################################
  sc_arena
  ###################################
  ###################################

*/

typedef enum
{
    ScArenaFlag_None = 0,
    ScArenaFlag_DeepClean
} ScArenaFlag;

typedef struct
{
    u64 Size;
    i32 Line;
    ScArenaFlag Flag;
    const char* pFile;
} ScArenaConfig;

typedef struct
{
    i64 Id;
    ScArenaFlag Flag;
    // DOCS: Record about where allocation happens
    i32 Line;
    u64 Offset;
    u64 Size;
    const char* pFile;
    void* pData;
} ScArena;

#define sc_arena_new(...)                                \
    ({                                                   \
        ScArenaConfig conf = (ScArenaConfig)__VA_ARGS__; \
        conf.Line = __LINE__;                            \
        conf.pFile = __FILE__;                           \
        sc_arena_new_ext(conf);                          \
    })

ScArena* sc_arena_new_ext(ScArenaConfig config);
void sc_arena_destroy(ScArena* pArena);
void sc_arena_clear(ScArena* pArena);
void* sc_arena_allocate(ScArena* pArena, u64 size);
void sc_arena_bind(ScArena* pArena);
void sc_arena_unbind();
ScArena* sc_arena_get();

/*

  ###################################
  ###################################
  sc_thread
  ###################################
  ###################################

*/

typedef void* ScThread;
typedef void* (*ScThreadDelegate)(void* arg);

ScThread sc_thread_create(ScThreadDelegate threadFunction, u64 stackSize, void* pData);
ScThread sc_thread_create(ScThreadDelegate threadFunction, u64 stackSize, void* pData);
void sc_thread_attach(ScThread thread);
ScResult sc_thread_cancel(ScThread thread);

/*

  ###################################
  ###################################
  sc_mutex
  ###################################
  ###################################

*/

typedef void* ScMutex;

ScMutex sc_mutex_create();
ScResult sc_mutex_destroy(ScMutex pMutex);
ScResult sc_mutex_lock(ScMutex pMutex);
ScResult sc_mutex_unlock(ScMutex pMutex);
i32 sc_mutex_is_locked(ScMutex scMutex);

/*

  ###################################
  ###################################
  sc_condition
  ###################################
  ###################################

*/

typedef struct
{
    void* pHandle;
} ScCondition;

// typedef void* ScCondition;

ScCondition sc_condition_create(void);
void sc_condition_destroy(ScCondition condition);
void sc_condition_wait(ScCondition* pCondition, ScMutex scMutex);
void sc_condition_signal(ScCondition* pCondition);
void sc_condition_broadcast(ScCondition* pCondition);

/*

  ###################################
  ###################################
  sc_rwlock
  ###################################
  ###################################

*/

typedef struct ScRWLockInternal* ScRwLock;

ScRwLock sc_rwlock_create(void);
ScResult sc_rwlock_destroy(ScRwLock lock);
ScResult sc_rwlock_read_lock(ScRwLock lock);
ScResult sc_rwlock_read_unlock(ScRwLock lock);
ScResult sc_rwlock_write_lock(ScRwLock lock);
ScResult sc_rwlock_write_unlock(ScRwLock lock);
ScResult sc_rwlock_try_read_lock(ScRwLock lock);
ScResult sc_rwlock_try_write_lock(ScRwLock lock);

/*

  ###################################
  ###################################
  sc_job
  ###################################
  ###################################

*/

// NOTE: пока оставлю как указатель на функцию, думаю нам не потребуется что-то ещё, может передумаю.
typedef void (*ScJobAction)();

typedef struct
{
    i32 JobsCount;
} ScJobConfig;

void sc_job_init(ScJobConfig cfg);
void sc_job_new(ScJobAction jobAction);

/*

  ###################################
  ###################################
  sc_profiler
  ###################################
  ###################################

*/

typedef struct
{
#ifdef SC_PLATFORM_WINDOWS
    i64 Result;
#else // SC_PLATFORM_LINUX
    i64 Result;
#endif
} ScProfiler;

#define NsToS(ns) (ns / (1000 * 1000 * 1000))
#define NsToMs(ns) (ns / (1000 * 1000))
#define NsToMcs(ns) (ns / (1000))

#define NsToSFloat(ns) (to_f64(ns) / (1000 * 1000 * 1000))
#define NsToMsFloat(ns) (to_f64(ns) / (1000 * 1000))
#define NsToMcsFloat(ns) (to_f64(ns) / (1000))

typedef enum
{
    ScProfilerTimeType_Ns = 0,
    ScProfilerTimeType_Mcs,
    ScProfilerTimeType_Ms,
    ScProfilerTimeType_S,
} ScProfilerTimeType;

void sc_profiler_start(ScProfiler* pProfiler);
void sc_profiler_end(ScProfiler* pProfiler);
ScProfilerTimeType sc_profiler_get_time_type(ScProfiler* pProfiler);
i64 sc_profiler_get_nanoseconds(ScProfiler* pProfiler);
i64 sc_profiler_get_microseconds(ScProfiler* pProfiler);
i64 sc_profiler_get_milliseconds(ScProfiler* pProfiler);
i64 sc_profiler_get_seconds(ScProfiler* pProfiler);
f64 sc_profiler_get_microseconds_as_float(ScProfiler* pProfiler);
f64 sc_profiler_get_milliseconds_as_float(ScProfiler* pProfiler);
f64 sc_profiler_get_seconds_as_float(ScProfiler* pProfiler);
void sc_profiler_print(ScProfiler* pProfiler);
void sc_profiler_print_as_float(ScProfiler* pProfiler);
char* sc_profiler_get_string(ScProfiler* pProfiler);
char* sc_profiler_get_string_as_float(ScProfiler* pProfiler);

/*

  ###################################
  ###################################
  sc_date_time
  ###################################
  ###################################

*/

typedef struct
{
    u8 DayOfTheWeek;
    u8 Seconds;
    u8 Minutes;
    u8 Hours;

    u8 Day;
    u8 Month;
    u16 Year;
} ScDateTime;

i64 sc_date_time_now_seconds();
void sc_date_time_add_seconds(ScDateTime* pDt, f32 seconds);
extern ScDateTime sc_date_time_now();
const char* sc_date_time_to_string(ScDateTime dt);
const char* sc_date_time_to_date_string(ScDateTime dt);
const char* sc_date_time_to_time_string(ScDateTime dt);

/*

  ###################################
  ###################################
  sc_timer
  ###################################
  ###################################

*/

typedef struct
{
    f32 SecondsToWait;
} ScTimer;

ScTimer sc_timer_new(f32 secondsToWait);
i32 sc_timer_interval(ScTimer* pTimer, f32 timestep);
void sc_timer_reset(ScTimer* pTimer, f32 secondsToWait);

/*

  ###################################
  ###################################
  sc_log
  ###################################
  ###################################

*/

typedef enum
{
    ScLogLevel_Info,
    ScLogLevel_Debug, // Verbose
    ScLogLevel_Success,
    ScLogLevel_Warn,
    ScLogLevel_Error,
    ScLogLevel_Count
} ScLogLevel;

typedef struct
{
    ScLogLevel Level;
    const char* pFile;
    i32 Line;
    char* pMessage;
    u32 MessageSize;
    char* pFunction;
    ScDateTime DateTime;
} ScLogItem;

typedef enum
{
    ScLogFormat_None = 0,
    ScLogFormat_Level,
    ScLogFormat_File,
    ScLogFormat_Function,
    ScLogFormat_Function_Line,
    ScLogFormat_Line,
    ScLogFormat_Time,
    ScLogFormat_Message,
    ScLogFormat_File_Short,
    ScLogFormat_Count,
} ScLogFormat;

typedef void (*ScBackendDelegate)(ScLogItem item, ScLogFormat* aFormats, u32 formatsCount);

typedef struct
{
    ScBackendDelegate Action;
    u32 FormatsCount;
    ScLogFormat aFormats[ScLogFormat_Count];
} ScLogBackend;

typedef struct
{
    i32 BackendsCount;
    ScLogBackend* aBackends;
} ScLogConfig;

void sc_log_init(ScLogConfig config);
void sc_log_init_default();
void sc_log_deinit();
void sc_log_base(ScLogLevel type, const char* pFile, i32 line, const char* pFunction, const char* pFormat, ...);

ScLogBackend sc_log_get_terminal_backend();
ScLogBackend sc_log_get_file_backend();

#define sc_log_info(pFormat, ...)   \
    ({ sc_log_base(ScLogLevel_Info, \
           __FILE__,                \
           __LINE__,                \
           __FUNCTION__,            \
           pFormat,                 \
           ##__VA_ARGS__); })
#define sc_log_warn(pFormat, ...)   \
    ({ sc_log_base(ScLogLevel_Warn, \
           __FILE__,                \
           __LINE__,                \
           __FUNCTION__,            \
           pFormat,                 \
           ##__VA_ARGS__); })
#define sc_log_erro(pFormat, ...)    \
    ({ sc_log_base(ScLogLevel_Error, \
           __FILE__,                 \
           __LINE__,                 \
           __FUNCTION__,             \
           pFormat,                  \
           ##__VA_ARGS__); })
#define sc_log_succ(pFormat, ...)      \
    ({ sc_log_base(ScLogLevel_Success, \
           __FILE__,                   \
           __LINE__,                   \
           __FUNCTION__,               \
           pFormat,                    \
           ##__VA_ARGS__); })

const char* sc_log_level_to_color(ScLogLevel level);
const char* sc_log_level_to_string(ScLogLevel level);

/*

  ###################################
  ###################################
  sc_bitset
  ###################################
  ###################################

*/

// typedef u64 bitset64[1];
// typedef u64 bitset128[2];
// typedef u64 bitset256[4];
// typedef u64 bitset512[8];
// typedef u64 bitset1024[16];

typedef struct
{
    u64 Mask0[1];
} bitset64;

typedef struct
{
    u64 Mask[4];
} bitset256;

typedef struct
{
    u64 Mask[8];
} bitset512;

typedef struct
{
    u64 Mask[16];
} bitset1024;

#define sc_bitset_get_bit_index(bit) ((bit) / 64)
#define sc_bitset_get_bit_mask(bit) ((u64)1 << ((bit) % 64))

force_inline void
sc_bitset_validate(u16 bitSetSize, u16 bit)
{
#if defined(SC_BUILD_DEBUG)
    if (bit >= bitSetSize)
    {
        sc_log_warn("Bit: %d out of bound\n", bit);
        sc_assert_break();
    }
#endif // SC_BUILD_DEBUG
}

void sc_bitset_set_0(u64* pBitset, u16 bitSetSize, u16 bit);
void sc_bitset_set_1(u64* pBitset, u16 bitSetSize, u16 bit);
u8 sc_bitset_get(const u64* pBitset, u16 bitSetSize, u16 bit);
i32 sc_bitset_contains(u64* pBitset0, u16 bitset0Size, u64* pBitset1, u16 bitset1Size);
void sc_bitset_test();

/*

  ###################################
  ###################################
  sc_random
  ###################################
  ###################################

*/

u64 sc_random();
u64 sc_random_ext(u32 flags);

#endif // SC_H
