/*
  Микро-LLM: decoder-only transformer, float32, CPU, C99.

  Что реализовано:
  - LayerNorm + causal multi-head self-attention + FFN (GELU);
  - forward/backward для всех слоёв;
  - cross-entropy с маскированием prompt-позиций;
  - AdamW, warmup + cosine, клиппинг по глобальной норме;
  - KV-cache, greedy/top-k/top-p/temperature;
  - чекпоинты (config + weights + встроенный BPE);
  - early stopping с восстановлением лучших весов по val loss;
  - проверка аналитического градиента конечными разностями.

  Ограничения:
  - это не оптимизированный inference/training runtime: без BLAS,
    без многопоточности и без смешанной точности;
  - reference-BPE sc_ai_bpe_new остаётся O(merges * tokens); для больших
    корпусов используйте sc_ai_bpe_new_fast в Ai.c.
*/

#include "TinyLlm.h"
#include "Sc.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SC_TINY_LLM_LN_EPS 1e-5f

typedef struct
{
    ScAiParam Ln1G;
    ScAiParam Ln1B;
    ScAiParam QkvW;
    ScAiParam QkvB;
    ScAiParam ProjW;
    ScAiParam ProjB;
    ScAiParam Ln2G;
    ScAiParam Ln2B;
    ScAiParam Fc1W;
    ScAiParam Fc1B;
    ScAiParam Fc2W;
    ScAiParam Fc2B;

    f32* aLn1Y;
    f32* aLn1Xhat;
    f32* aLn1InvStd;
    f32* aQkv;
    f32* aAttnProbs;
    f32* aAttnCtx;
    f32* aLn2Y;
    f32* aLn2Xhat;
    f32* aLn2InvStd;
    f32* aFc1Pre;
    f32* aFc1Act;
} ScTinyLlmLayer;

struct ScTinyLlmModel
{
    ScTinyLlmModelConfig Cfg;

    ScTinyLlmLayer* aLayers;
    ScAiParam TokEmb;
    ScAiParam PosEmb;
    ScAiParam FinalLnG;
    ScAiParam FinalLnB;
    ScAiParam LmHeadW;
    ScAiParam LmHeadB;

    ScAiParam** aParams;
    i32 ParamCount;

    // forward caches
    f32* aX;
    f32* aTmp;
    f32* aScoreRow;
    f32* aFinalY;
    f32* aFinalXhat;
    f32* aFinalInvStd;
    f32* aLogits;
    f32* aProbRow;

    // backward scratch
    f32* dX;
    f32* dCur;
    f32* dNorm;
    f32* dAttnCtx;
    f32* dQkv;
    f32* dFc1Pre;
    f32* dFc1Act;
    f32* dProbRow;
    f32* dScoreRow;

    // current training window
    i32* aTokens;
    i32* aLabels;
    i32* aMask;

    // generation
    f32* aKCache;
    f32* aVCache;
    f32* aGenX;
    f32* aGenXhat;
    f32* aGenInvStd;
    f32* aGenQkv;
    f32* aGenAttnCtx;
    f32* aGenFc1;
    f32* aGenTmp;
    f32* aGenScoreRow;
    f32* aGenProbRow;
    f32* aGenLogits;
};

typedef struct
{
    f32 Prob;
    i32 Index;
} ScTinyLlmCandidate;

static f32*
_sc_tiny_llm_f32_new(i64 count)
{
    if (count <= 0)
        return NULL;

    f32* pData = sc_memory_allocate(sizeof(f32) * (u64)count);
    if (!pData)
        return NULL;

    for (i64 i = 0; i < count; ++i)
        pData[i] = 0.0f;

    return pData;
}

static i32*
_sc_tiny_llm_i32_new(i64 count)
{
    if (count <= 0)
        return NULL;

    i32* pData = sc_memory_allocate(sizeof(i32) * (u64)count);
    if (!pData)
        return NULL;

    for (i64 i = 0; i < count; ++i)
        pData[i] = 0;

    return pData;
}

static u64
_sc_tiny_llm_rng_next(u64* pState)
{
    u64 x = *pState;
    if (x == 0)
        x = 0x9e3779b97f4a7c15ULL;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *pState = x;
    return x;
}

static f32
_sc_tiny_llm_rng_f32(u64* pState)
{
    u64 value = _sc_tiny_llm_rng_next(pState) >> 40;
    return (f32)value / 16777216.0f;
}

static ScAiParam
_sc_tiny_llm_param_new(i64 count, f32 uniformLimit, u64* pSeed)
{
    ScAiParam param = {};
    param.Count = count;

    if (count <= 0)
        return param;

    param.pData = _sc_tiny_llm_f32_new(count);
    param.pGrad = _sc_tiny_llm_f32_new(count);
    param.pM = _sc_tiny_llm_f32_new(count);
    param.pV = _sc_tiny_llm_f32_new(count);

    if (!param.pData || !param.pGrad || !param.pM || !param.pV)
        return param;

    for (i64 i = 0; i < count; ++i)
        param.pData[i] = (_sc_tiny_llm_rng_f32(pSeed) * 2.0f - 1.0f) * uniformLimit;

    return param;
}

static void
_sc_tiny_llm_param_destroy(ScAiParam* pParam)
{
    if (!pParam)
        return;

    sc_memory_free(pParam->pData);
    sc_memory_free(pParam->pGrad);
    sc_memory_free(pParam->pM);
    sc_memory_free(pParam->pV);
    *pParam = (ScAiParam) {};
}

static void
_sc_tiny_llm_param_zero_grad(ScAiParam* pParam)
{
    if (!pParam || !pParam->pGrad)
        return;

    for (i64 i = 0; i < pParam->Count; ++i)
        pParam->pGrad[i] = 0.0f;
}

static void
_sc_tiny_llm_model_add_param(ScTinyLlmModel* pModel, ScAiParam* pParam)
{
    pModel->aParams[pModel->ParamCount++] = pParam;
}

static f32
_sc_tiny_llm_xavier_limit(i32 fanIn, i32 fanOut)
{
    if (fanIn <= 0 || fanOut <= 0)
        return 0.02f;
    return sqrtf(6.0f / (f32)(fanIn + fanOut));
}

static void
_sc_tiny_llm_zero_params_grad(ScTinyLlmModel* pModel)
{
    for (i32 i = 0; i < pModel->ParamCount; ++i)
        _sc_tiny_llm_param_zero_grad(pModel->aParams[i]);
}

static f32
_sc_tiny_llm_grad_norm(ScTinyLlmModel* pModel)
{
    f64 sum = 0.0;
    for (i32 p = 0; p < pModel->ParamCount; ++p)
    {
        ScAiParam* param = pModel->aParams[p];
        for (i64 i = 0; i < param->Count; ++i)
            sum += (f64)param->pGrad[i] * (f64)param->pGrad[i];
    }
    return (f32)sqrt(sum);
}

static void
_sc_tiny_llm_scale_grad(ScTinyLlmModel* pModel, f32 scale)
{
    for (i32 p = 0; p < pModel->ParamCount; ++p)
    {
        ScAiParam* param = pModel->aParams[p];
        for (i64 i = 0; i < param->Count; ++i)
            param->pGrad[i] *= scale;
    }
}

static void
_sc_tiny_llm_adamw_step(ScTinyLlmModel* pModel, f32 learningRate, i32 step, f32 invBatch, f32 weightDecay)
{
    const f32 beta1 = 0.9f;
    const f32 beta2 = 0.999f;
    const f32 epsilon = 1e-8f;
    f32 beta1Pow = 1.0f - powf(beta1, (f32)step);
    f32 beta2Pow = 1.0f - powf(beta2, (f32)step);

    for (i32 p = 0; p < pModel->ParamCount; ++p)
    {
        ScAiParam* param = pModel->aParams[p];
        for (i64 i = 0; i < param->Count; ++i)
        {
            f32 grad = param->pGrad[i] * invBatch;
            param->pM[i] = beta1 * param->pM[i] + (1.0f - beta1) * grad;
            param->pV[i] = beta2 * param->pV[i] + (1.0f - beta2) * grad * grad;

            f32 mHat = param->pM[i] / beta1Pow;
            f32 vHat = param->pV[i] / beta2Pow;
            f32 update = mHat / (sqrtf(vHat) + epsilon);

            if (weightDecay > 0.0f)
                update += weightDecay * param->pData[i];

            param->pData[i] -= learningRate * update;
            param->pGrad[i] = 0.0f;
        }
    }
}

static void
_sc_tiny_llm_ln_forward(const f32* pX, f32* pY, f32* pXhat, f32* pInvStd,
    const f32* pGamma, const f32* pBeta, i32 T, i32 D)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * D;
        f32* y = pY + (i64)t * D;
        f32* xhat = pXhat + (i64)t * D;

        f32 mean = 0.0f;
        for (i32 d = 0; d < D; ++d)
            mean += x[d];
        mean /= (f32)D;

        f32 var = 0.0f;
        for (i32 d = 0; d < D; ++d)
        {
            f32 diff = x[d] - mean;
            var += diff * diff;
        }
        var /= (f32)D;

        f32 invStd = 1.0f / sqrtf(var + SC_TINY_LLM_LN_EPS);
        pInvStd[t] = invStd;

        for (i32 d = 0; d < D; ++d)
        {
            f32 value = (x[d] - mean) * invStd;
            xhat[d] = value;
            y[d] = value * pGamma[d] + pBeta[d];
        }
    }
}

static void
_sc_tiny_llm_ln_backward_add(const f32* pDy, const f32* pXhat, const f32* pInvStd,
    const f32* pGamma, f32* pGammaGrad, f32* pBetaGrad, f32* pDx, i32 T, i32 D)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* dy = pDy + (i64)t * D;
        const f32* xhat = pXhat + (i64)t * D;
        f32* dx = pDx + (i64)t * D;

        f32 meanDy = 0.0f;
        f32 meanDyX = 0.0f;

        for (i32 d = 0; d < D; ++d)
        {
            f32 dxhat = dy[d] * pGamma[d];
            pGammaGrad[d] += dy[d] * xhat[d];
            pBetaGrad[d] += dy[d];
            meanDy += dxhat;
            meanDyX += dxhat * xhat[d];
        }

        meanDy /= (f32)D;
        meanDyX /= (f32)D;

        f32 invStd = pInvStd[t];
        for (i32 d = 0; d < D; ++d)
        {
            f32 dxhat = dy[d] * pGamma[d];
            dx[d] += invStd * (dxhat - meanDy - xhat[d] * meanDyX);
        }
    }
}

static f32
_sc_tiny_llm_gelu(f32 x)
{
    const f32 c = 0.7978845608028654f;
    return 0.5f * x * (1.0f + tanhf(c * (x + 0.044715f * x * x * x)));
}

static f32
_sc_tiny_llm_gelu_grad(f32 x)
{
    const f32 c = 0.7978845608028654f;
    f32 x2 = x * x;
    f32 x3 = x2 * x;
    f32 u = c * (x + 0.044715f * x3);
    f32 t = tanhf(u);
    f32 du = c * (1.0f + 3.0f * 0.044715f * x2);
    return 0.5f * (1.0f + t) + 0.5f * x * (1.0f - t * t) * du;
}

static void
_sc_tiny_llm_linear_forward(const f32* pX, const f32* pW, const f32* pB, f32* pY,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * K;
        f32* y = pY + (i64)t * N;
        for (i32 n = 0; n < N; ++n)
            y[n] = pB ? pB[n] : 0.0f;

        for (i32 k = 0; k < K; ++k)
        {
            f32 xv = x[k];
            const f32* w = pW + (i64)k * N;
            for (i32 n = 0; n < N; ++n)
                y[n] += xv * w[n];
        }
    }
}

static void
_sc_tiny_llm_linear_backward_weight(const f32* pX, const f32* pDy, ScAiParam* pW, ScAiParam* pB,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* x = pX + (i64)t * K;
        const f32* dy = pDy + (i64)t * N;

        for (i32 k = 0; k < K; ++k)
        {
            f32 xv = x[k];
            f32* dw = pW->pGrad + (i64)k * N;
            for (i32 n = 0; n < N; ++n)
                dw[n] += xv * dy[n];
        }

        if (pB)
        {
            for (i32 n = 0; n < N; ++n)
                pB->pGrad[n] += dy[n];
        }
    }
}

static void
_sc_tiny_llm_linear_backward_input(const f32* pDy, const f32* pW, f32* pDx,
    i32 T, i32 K, i32 N)
{
    for (i32 t = 0; t < T; ++t)
    {
        const f32* dy = pDy + (i64)t * N;
        f32* dx = pDx + (i64)t * K;

        for (i32 k = 0; k < K; ++k)
        {
            const f32* w = pW + (i64)k * N;
            f32 sum = 0.0f;
            for (i32 n = 0; n < N; ++n)
                sum += dy[n] * w[n];
            dx[k] = sum;
        }
    }
}

static f32
_sc_tiny_llm_attention_forward(ScTinyLlmModel* pModel, ScTinyLlmLayer* pLayer, i32 T)
{
    i32 D = pModel->Cfg.DModel;
    i32 H = pModel->Cfg.NumHeads;
    i32 Dh = D / H;
    f32 scale = 1.0f / sqrtf((f32)Dh);

    for (i32 h = 0; h < H; ++h)
    {
        i32 headOffset = h * Dh;
        for (i32 t = 0; t < T; ++t)
        {
            const f32* q = pLayer->aQkv + (i64)t * 3 * D + headOffset;
            f32* probs = pLayer->aAttnProbs + ((i64)h * T + t) * T;
            f32* score = pModel->aScoreRow;

            f32 maxScore = -1e30f;
            for (i32 s = 0; s <= t; ++s)
            {
                const f32* k = pLayer->aQkv + (i64)s * 3 * D + D + headOffset;
                f32 sum = 0.0f;
                for (i32 d = 0; d < Dh; ++d)
                    sum += q[d] * k[d];
                sum *= scale;
                score[s] = sum;
                if (sum > maxScore)
                    maxScore = sum;
            }

            f32 sumExp = 0.0f;
            for (i32 s = 0; s <= t; ++s)
            {
                f32 value = expf(score[s] - maxScore);
                probs[s] = value;
                sumExp += value;
            }
            if (sumExp <= 0.0f)
                sumExp = 1.0f;
            for (i32 s = 0; s <= t; ++s)
                probs[s] /= sumExp;

            f32* ctx = pLayer->aAttnCtx + (i64)t * D + headOffset;
            for (i32 d = 0; d < Dh; ++d)
                ctx[d] = 0.0f;

            for (i32 s = 0; s <= t; ++s)
            {
                const f32* v = pLayer->aQkv + (i64)s * 3 * D + 2 * D + headOffset;
                f32 p = probs[s];
                for (i32 d = 0; d < Dh; ++d)
                    ctx[d] += p * v[d];
            }
        }
    }

    return 0.0f;
}

static void
_sc_tiny_llm_attention_backward(ScTinyLlmModel* pModel, ScTinyLlmLayer* pLayer, i32 T)
{
    i32 D = pModel->Cfg.DModel;
    i32 H = pModel->Cfg.NumHeads;
    i32 Dh = D / H;
    f32 scale = 1.0f / sqrtf((f32)Dh);

    for (i64 i = 0; i < (i64)T * 3 * D; ++i)
        pModel->dQkv[i] = 0.0f;

    for (i32 h = 0; h < H; ++h)
    {
        i32 headOffset = h * Dh;
        for (i32 t = 0; t < T; ++t)
        {
            const f32* probs = pLayer->aAttnProbs + ((i64)h * T + t) * T;
            const f32* dctx = pModel->dAttnCtx + (i64)t * D + headOffset;
            f32* dprob = pModel->dProbRow;
            f32* dscore = pModel->dScoreRow;

            for (i32 s = 0; s <= t; ++s)
            {
                const f32* v = pLayer->aQkv + (i64)s * 3 * D + 2 * D + headOffset;
                f32 sum = 0.0f;
                for (i32 d = 0; d < Dh; ++d)
                    sum += dctx[d] * v[d];
                dprob[s] = sum;
            }

            f32 weighted = 0.0f;
            for (i32 s = 0; s <= t; ++s)
                weighted += probs[s] * dprob[s];

            for (i32 s = 0; s <= t; ++s)
                dscore[s] = probs[s] * (dprob[s] - weighted);

            const f32* q = pLayer->aQkv + (i64)t * 3 * D + headOffset;
            f32* dq = pModel->dQkv + (i64)t * 3 * D + headOffset;

            for (i32 s = 0; s <= t; ++s)
            {
                const f32* k = pLayer->aQkv + (i64)s * 3 * D + D + headOffset;
                f32* dk = pModel->dQkv + (i64)s * 3 * D + D + headOffset;
                f32* dv = pModel->dQkv + (i64)s * 3 * D + 2 * D + headOffset;
                f32 ds = dscore[s] * scale;
                f32 p = probs[s];

                for (i32 d = 0; d < Dh; ++d)
                {
                    dq[d] += ds * k[d];
                    dk[d] += ds * q[d];
                    dv[d] += p * dctx[d];
                }
            }
        }
    }
}

static void
_sc_tiny_llm_forward(ScTinyLlmModel* pModel, const i32* pTokens, i32 T)
{
    i32 D = pModel->Cfg.DModel;
    i32 V = pModel->Cfg.VocabCount;
    i32 F = pModel->Cfg.DFf;

    for (i32 t = 0; t < T; ++t)
    {
        i32 token = pTokens[t];
        if (token < 0 || token >= V)
            token = ScAiSpecialToken_Unk;

        const f32* tok = pModel->TokEmb.pData + (i64)token * D;
        const f32* pos = pModel->PosEmb.pData + (i64)t * D;
        f32* x = pModel->aX + (i64)t * D;
        for (i32 d = 0; d < D; ++d)
            x[d] = tok[d] + pos[d];
    }

    for (i32 l = 0; l < pModel->Cfg.NumLayers; ++l)
    {
        ScTinyLlmLayer* layer = pModel->aLayers + l;

        _sc_tiny_llm_ln_forward(pModel->aX, layer->aLn1Y, layer->aLn1Xhat, layer->aLn1InvStd,
            layer->Ln1G.pData, layer->Ln1B.pData, T, D);

        _sc_tiny_llm_linear_forward(layer->aLn1Y, layer->QkvW.pData, layer->QkvB.pData,
            layer->aQkv, T, D, 3 * D);

        _sc_tiny_llm_attention_forward(pModel, layer, T);

        _sc_tiny_llm_linear_forward(layer->aAttnCtx, layer->ProjW.pData, layer->ProjB.pData,
            pModel->aTmp, T, D, D);
        for (i64 i = 0; i < (i64)T * D; ++i)
            pModel->aX[i] += pModel->aTmp[i];

        _sc_tiny_llm_ln_forward(pModel->aX, layer->aLn2Y, layer->aLn2Xhat, layer->aLn2InvStd,
            layer->Ln2G.pData, layer->Ln2B.pData, T, D);

        _sc_tiny_llm_linear_forward(layer->aLn2Y, layer->Fc1W.pData, layer->Fc1B.pData,
            layer->aFc1Pre, T, D, F);
        for (i64 i = 0; i < (i64)T * F; ++i)
            layer->aFc1Act[i] = _sc_tiny_llm_gelu(layer->aFc1Pre[i]);

        _sc_tiny_llm_linear_forward(layer->aFc1Act, layer->Fc2W.pData, layer->Fc2B.pData,
            pModel->aTmp, T, F, D);
        for (i64 i = 0; i < (i64)T * D; ++i)
            pModel->aX[i] += pModel->aTmp[i];
    }

    _sc_tiny_llm_ln_forward(pModel->aX, pModel->aFinalY, pModel->aFinalXhat, pModel->aFinalInvStd,
        pModel->FinalLnG.pData, pModel->FinalLnB.pData, T, D);

    _sc_tiny_llm_linear_forward(pModel->aFinalY, pModel->LmHeadW.pData, pModel->LmHeadB.pData,
        pModel->aLogits, T, D, V);
}

static f32
_sc_tiny_llm_loss_and_dlogits(ScTinyLlmModel* pModel, i32 T, i32 writeDLogits, i32* pLossCount)
{
    i32 V = pModel->Cfg.VocabCount;
    f32 lossSum = 0.0f;
    i32 count = 0;

    for (i32 t = 0; t < T; ++t)
    {
        i32 target = pModel->aLabels[t];
        i32 isValid = target >= 0 && target < V && pModel->aMask[t];
        f32* logits = pModel->aLogits + (i64)t * V;
        f32* probs = pModel->aProbRow;

        if (!isValid)
        {
            if (writeDLogits)
            {
                for (i32 v = 0; v < V; ++v)
                    logits[v] = 0.0f;
            }
            continue;
        }

        f32 maxLogit = logits[0];
        for (i32 v = 1; v < V; ++v)
        {
            if (logits[v] > maxLogit)
                maxLogit = logits[v];
        }

        f32 sumExp = 0.0f;
        for (i32 v = 0; v < V; ++v)
        {
            f32 value = expf(logits[v] - maxLogit);
            probs[v] = value;
            sumExp += value;
        }

        if (sumExp <= 0.0f)
            sumExp = 1.0f;

        for (i32 v = 0; v < V; ++v)
            probs[v] /= sumExp;

        lossSum += -logf(probs[target] + 1e-8f);
        ++count;

        if (writeDLogits)
        {
            for (i32 v = 0; v < V; ++v)
                logits[v] = probs[v];
            logits[target] -= 1.0f;
        }
    }

    if (pLossCount)
        *pLossCount = count;

    return lossSum;
}

static void
_sc_tiny_llm_layer_backward(ScTinyLlmModel* pModel, ScTinyLlmLayer* pLayer, i32 T)
{
    i32 D = pModel->Cfg.DModel;
    i32 F = pModel->Cfg.DFf;
    i64 dSize = (i64)T * D;

    // dX currently holds dL/d(x_out). Copy to dCur: it will accumulate
    // gradients through the residual branches.
    for (i64 i = 0; i < dSize; ++i)
        pModel->dCur[i] = pModel->dX[i];

    // FC2: x_out = x_mid + fc2(fc1_act)
    _sc_tiny_llm_linear_backward_weight(pLayer->aFc1Act, pModel->dCur,
        &pLayer->Fc2W, &pLayer->Fc2B, T, F, D);
    _sc_tiny_llm_linear_backward_input(pModel->dCur, pLayer->Fc2W.pData,
        pModel->dFc1Act, T, F, D);
    for (i64 i = 0; i < (i64)T * F; ++i)
        pModel->dFc1Pre[i] = pModel->dFc1Act[i] * _sc_tiny_llm_gelu_grad(pLayer->aFc1Pre[i]);

    _sc_tiny_llm_linear_backward_weight(pLayer->aLn2Y, pModel->dFc1Pre,
        &pLayer->Fc1W, &pLayer->Fc1B, T, D, F);
    _sc_tiny_llm_linear_backward_input(pModel->dFc1Pre, pLayer->Fc1W.pData,
        pModel->dNorm, T, D, F);

    _sc_tiny_llm_ln_backward_add(pModel->dNorm, pLayer->aLn2Xhat, pLayer->aLn2InvStd,
        pLayer->Ln2G.pData, pLayer->Ln2G.pGrad, pLayer->Ln2B.pGrad, pModel->dCur, T, D);

    // Attention projection: x_mid = x_in + proj(attn_ctx)
    _sc_tiny_llm_linear_backward_weight(pLayer->aAttnCtx, pModel->dCur,
        &pLayer->ProjW, &pLayer->ProjB, T, D, D);
    _sc_tiny_llm_linear_backward_input(pModel->dCur, pLayer->ProjW.pData,
        pModel->dAttnCtx, T, D, D);

    _sc_tiny_llm_attention_backward(pModel, pLayer, T);

    _sc_tiny_llm_linear_backward_weight(pLayer->aLn1Y, pModel->dQkv,
        &pLayer->QkvW, &pLayer->QkvB, T, D, 3 * D);
    _sc_tiny_llm_linear_backward_input(pModel->dQkv, pLayer->QkvW.pData,
        pModel->dNorm, T, D, 3 * D);

    _sc_tiny_llm_ln_backward_add(pModel->dNorm, pLayer->aLn1Xhat, pLayer->aLn1InvStd,
        pLayer->Ln1G.pData, pLayer->Ln1G.pGrad, pLayer->Ln1B.pGrad, pModel->dCur, T, D);

    for (i64 i = 0; i < dSize; ++i)
        pModel->dX[i] = pModel->dCur[i];
}

static void
_sc_tiny_llm_backward(ScTinyLlmModel* pModel, const i32* pTokens, i32 T)
{
    i32 D = pModel->Cfg.DModel;
    i32 V = pModel->Cfg.VocabCount;

    _sc_tiny_llm_linear_backward_weight(pModel->aFinalY, pModel->aLogits,
        &pModel->LmHeadW, &pModel->LmHeadB, T, D, V);
    _sc_tiny_llm_linear_backward_input(pModel->aLogits, pModel->LmHeadW.pData,
        pModel->dNorm, T, D, V);

    for (i64 i = 0; i < (i64)T * D; ++i)
        pModel->dX[i] = 0.0f;

    _sc_tiny_llm_ln_backward_add(pModel->dNorm, pModel->aFinalXhat, pModel->aFinalInvStd,
        pModel->FinalLnG.pData, pModel->FinalLnG.pGrad, pModel->FinalLnB.pGrad, pModel->dX, T, D);

    for (i32 l = pModel->Cfg.NumLayers - 1; l >= 0; --l)
        _sc_tiny_llm_layer_backward(pModel, pModel->aLayers + l, T);

    for (i32 t = 0; t < T; ++t)
    {
        i32 token = pTokens[t];
        if (token < 0 || token >= V)
            token = ScAiSpecialToken_Unk;

        const f32* dx = pModel->dX + (i64)t * D;
        f32* dTok = pModel->TokEmb.pGrad + (i64)token * D;
        f32* dPos = pModel->PosEmb.pGrad + (i64)t * D;
        for (i32 d = 0; d < D; ++d)
        {
            dTok[d] += dx[d];
            dPos[d] += dx[d];
        }
    }
}

/*
  Быстрый forward одного токена с KV-cache. Используется только на инференсе.
*/
static i32
_sc_tiny_llm_forward_cached(ScTinyLlmModel* pModel, i32 token, i32 pos)
{
    i32 D = pModel->Cfg.DModel;
    i32 H = pModel->Cfg.NumHeads;
    i32 Dh = D / H;
    i32 F = pModel->Cfg.DFf;
    i32 V = pModel->Cfg.VocabCount;
    i32 ctxLen = pModel->Cfg.ContextLength;
    f32 scale = 1.0f / sqrtf((f32)Dh);

    if (pos < 0 || pos >= ctxLen)
        return 0;

    if (token < 0 || token >= V)
        token = ScAiSpecialToken_Unk;

    const f32* tok = pModel->TokEmb.pData + (i64)token * D;
    const f32* posEmb = pModel->PosEmb.pData + (i64)pos * D;
    f32* x = pModel->aGenX;
    for (i32 d = 0; d < D; ++d)
        x[d] = tok[d] + posEmb[d];

    for (i32 l = 0; l < pModel->Cfg.NumLayers; ++l)
    {
        ScTinyLlmLayer* layer = pModel->aLayers + l;

        _sc_tiny_llm_ln_forward(x, pModel->aGenTmp, pModel->aGenXhat, pModel->aGenInvStd,
            layer->Ln1G.pData, layer->Ln1B.pData, 1, D);

        _sc_tiny_llm_linear_forward(pModel->aGenTmp, layer->QkvW.pData, layer->QkvB.pData,
            pModel->aGenQkv, 1, D, 3 * D);

        f32* kCache = pModel->aKCache + ((i64)l * ctxLen + pos) * D;
        f32* vCache = pModel->aVCache + ((i64)l * ctxLen + pos) * D;
        for (i32 d = 0; d < D; ++d)
        {
            kCache[d] = pModel->aGenQkv[D + d];
            vCache[d] = pModel->aGenQkv[2 * D + d];
        }

        for (i32 d = 0; d < D; ++d)
            pModel->aGenAttnCtx[d] = 0.0f;

        for (i32 h = 0; h < H; ++h)
        {
            i32 off = h * Dh;
            const f32* q = pModel->aGenQkv + off;
            f32* score = pModel->aGenScoreRow;
            f32* probs = pModel->aGenProbRow;

            f32 maxScore = -1e30f;
            for (i32 s = 0; s <= pos; ++s)
            {
                const f32* k = pModel->aKCache + ((i64)l * ctxLen + s) * D + off;
                f32 sum = 0.0f;
                for (i32 d = 0; d < Dh; ++d)
                    sum += q[d] * k[d];
                sum *= scale;
                score[s] = sum;
                if (sum > maxScore)
                    maxScore = sum;
            }

            f32 sumExp = 0.0f;
            for (i32 s = 0; s <= pos; ++s)
            {
                f32 value = expf(score[s] - maxScore);
                probs[s] = value;
                sumExp += value;
            }
            if (sumExp <= 0.0f)
                sumExp = 1.0f;

            for (i32 s = 0; s <= pos; ++s)
                probs[s] /= sumExp;

            for (i32 s = 0; s <= pos; ++s)
            {
                const f32* v = pModel->aVCache + ((i64)l * ctxLen + s) * D + off;
                f32 p = probs[s];
                for (i32 d = 0; d < Dh; ++d)
                    pModel->aGenAttnCtx[off + d] += p * v[d];
            }
        }

        _sc_tiny_llm_linear_forward(pModel->aGenAttnCtx, layer->ProjW.pData, layer->ProjB.pData,
            pModel->aGenTmp, 1, D, D);
        for (i32 d = 0; d < D; ++d)
            x[d] += pModel->aGenTmp[d];

        _sc_tiny_llm_ln_forward(x, pModel->aGenTmp, pModel->aGenXhat, pModel->aGenInvStd,
            layer->Ln2G.pData, layer->Ln2B.pData, 1, D);

        _sc_tiny_llm_linear_forward(pModel->aGenTmp, layer->Fc1W.pData, layer->Fc1B.pData,
            pModel->aGenFc1, 1, D, F);
        for (i32 i = 0; i < F; ++i)
            pModel->aGenFc1[i] = _sc_tiny_llm_gelu(pModel->aGenFc1[i]);

        _sc_tiny_llm_linear_forward(pModel->aGenFc1, layer->Fc2W.pData, layer->Fc2B.pData,
            pModel->aGenTmp, 1, F, D);
        for (i32 d = 0; d < D; ++d)
            x[d] += pModel->aGenTmp[d];
    }

    _sc_tiny_llm_ln_forward(x, pModel->aGenTmp, pModel->aGenXhat, pModel->aGenInvStd,
        pModel->FinalLnG.pData, pModel->FinalLnB.pData, 1, D);

    _sc_tiny_llm_linear_forward(pModel->aGenTmp, pModel->LmHeadW.pData, pModel->LmHeadB.pData,
        pModel->aGenLogits, 1, D, V);

    return 1;
}

static u32
_sc_tiny_llm_argmax(const f32* pLogits, i32 count)
{
    i32 best = 0;
    for (i32 i = 1; i < count; ++i)
    {
        if (pLogits[i] > pLogits[best])
            best = i;
    }
    return (u32)best;
}

static int
_sc_tiny_llm_candidate_compare(const void* pA, const void* pB)
{
    const ScTinyLlmCandidate* a = (const ScTinyLlmCandidate*)pA;
    const ScTinyLlmCandidate* b = (const ScTinyLlmCandidate*)pB;
    if (a->Prob < b->Prob)
        return 1;
    if (a->Prob > b->Prob)
        return -1;
    return 0;
}

static u32
_sc_tiny_llm_sample(const f32* pLogits, i32 V, const ScTinyLlmGenerateConfig* pCfg,
    ScTinyLlmCandidate* aCandidates, u64* pRng)
{
    if (pCfg->Temperature <= 1e-5f)
        return _sc_tiny_llm_argmax(pLogits, V);

    f32 maxLogit = pLogits[0];
    for (i32 v = 1; v < V; ++v)
    {
        if (pLogits[v] > maxLogit)
            maxLogit = pLogits[v];
    }

    f32 sum = 0.0f;
    for (i32 v = 0; v < V; ++v)
    {
        f32 value = expf((pLogits[v] - maxLogit) / pCfg->Temperature);
        aCandidates[v].Prob = value;
        aCandidates[v].Index = v;
        sum += value;
    }

    if (sum <= 0.0f)
        return _sc_tiny_llm_argmax(pLogits, V);

    for (i32 v = 0; v < V; ++v)
        aCandidates[v].Prob /= sum;

    qsort(aCandidates, (size_t)V, sizeof(ScTinyLlmCandidate), _sc_tiny_llm_candidate_compare);

    i32 selected = V;
    if (pCfg->TopK > 0 && pCfg->TopK < selected)
        selected = pCfg->TopK;

    f32 topP = pCfg->TopP;
    if (topP > 0.0f && topP < 1.0f)
    {
        f32 cumulative = 0.0f;
        i32 pCut = selected;
        for (i32 i = 0; i < selected; ++i)
        {
            cumulative += aCandidates[i].Prob;
            if (cumulative >= topP)
            {
                pCut = i + 1;
                break;
            }
        }
        if (pCut < selected)
            selected = pCut;
    }

    if (selected <= 0)
        selected = 1;

    f32 selectedSum = 0.0f;
    for (i32 i = 0; i < selected; ++i)
        selectedSum += aCandidates[i].Prob;

    if (selectedSum <= 0.0f)
        return (u32)aCandidates[0].Index;

    f32 r = _sc_tiny_llm_rng_f32(pRng) * selectedSum;
    f32 accumulated = 0.0f;
    for (i32 i = 0; i < selected; ++i)
    {
        accumulated += aCandidates[i].Prob;
        if (r <= accumulated)
            return (u32)aCandidates[i].Index;
    }

    return (u32)aCandidates[selected - 1].Index;
}

ScTinyLlmModelConfig
sc_tiny_llm_model_config_default(i32 vocabCount)
{
    ScTinyLlmModelConfig cfg = {
        .NumLayers = 2,
        .DModel = 64,
        .NumHeads = 2,
        .DFf = 256,
        .ContextLength = 128,
        .VocabCount = vocabCount,
        .InitStd = 0.02f,
        .Seed = 0x5c0deULL,
    };
    return cfg;
}

ScTinyLlmModelConfig
sc_tiny_llm_model_config_preset(ScTinyLlmSize size, i32 vocabCount)
{
    ScTinyLlmModelConfig cfg = sc_tiny_llm_model_config_default(vocabCount);

    switch (size)
    {
    case ScTinyLlmSize_Medium:
        cfg.NumLayers = 4;
        cfg.DModel = 128;
        cfg.NumHeads = 4;
        cfg.DFf = 512;
        cfg.ContextLength = 256;
        break;

    case ScTinyLlmSize_Target:
        cfg.NumLayers = 6;
        cfg.DModel = 256;
        cfg.NumHeads = 8;
        cfg.DFf = 1024;
        cfg.ContextLength = 512;
        break;

    case ScTinyLlmSize_Micro:
    default:
        cfg.NumLayers = 2;
        cfg.DModel = 64;
        cfg.NumHeads = 2;
        cfg.DFf = 256;
        cfg.ContextLength = 128;
        break;
    }

    return cfg;
}

ScTinyLlmTrainConfig
sc_tiny_llm_train_config_default(void)
{
    ScTinyLlmTrainConfig cfg = {
        .Steps = 2000,
        .BatchSize = 8,
        .LearningRate = 3e-3f,
        .WeightDecay = 0.01f,
        .WarmupSteps = 100,
        .LossMask = ScTinyLlmLossMask_Prompt,
        .LogEvery = 10,
        .GradClip = 1.0f,
        .EvalEvery = 0,
        .EvalBatches = 20,
        .Patience = 5,
        .MinDelta = 1e-4f,
        .pCheckpointPath = NULL,
        .CheckpointEvery = 0,
        .RestoreBest = 1,
        .Seed = 0x5c0deULL,
    };
    return cfg;
}

ScTinyLlmGenerateConfig
sc_tiny_llm_generate_config_default(void)
{
    ScTinyLlmGenerateConfig cfg = {
        .MaxTokens = 100,
        .Temperature = 0.8f,
        .TopK = 40,
        .TopP = 0.95f,
        .Seed = 0x5c0deULL,
        .AppendSep = 1,
    };
    return cfg;
}

ScTinyLlmModel*
sc_tiny_llm_create(const ScTinyLlmModelConfig* pConfig)
{
    if (!pConfig)
        return NULL;

    ScTinyLlmModelConfig cfg = *pConfig;
    if (cfg.NumLayers <= 0)
        cfg.NumLayers = 2;
    if (cfg.DModel <= 0)
        cfg.DModel = 64;
    if (cfg.NumHeads <= 0)
        cfg.NumHeads = 2;
    if (cfg.DFf <= 0)
        cfg.DFf = cfg.DModel * 4;
    if (cfg.ContextLength <= 0)
        cfg.ContextLength = 128;
    if (cfg.VocabCount < (i32)ScAiSpecialToken_Sit + 1)
        cfg.VocabCount = (i32)ScAiSpecialToken_Sit + 1;
    if (cfg.InitStd <= 0.0f)
        cfg.InitStd = 0.02f;
    if (cfg.Seed == 0)
        cfg.Seed = 0x9e3779b97f4a7c15ULL;

    if (cfg.DModel % cfg.NumHeads != 0)
    {
        sc_log_erro("tiny-llm: DModel (%d) must be divisible by NumHeads (%d)\n",
            cfg.DModel, cfg.NumHeads);
        return NULL;
    }

    ScTinyLlmModel* pModel = sc_memory_allocate(sizeof(ScTinyLlmModel));
    if (!pModel)
        return NULL;

    memset(pModel, 0, sizeof(ScTinyLlmModel));
    pModel->Cfg = cfg;

    i32 L = cfg.NumLayers;
    i32 D = cfg.DModel;
    i32 V = cfg.VocabCount;
    i32 F = cfg.DFf;
    i32 T = cfg.ContextLength;
    i32 H = cfg.NumHeads;

    pModel->aLayers = sc_memory_allocate(sizeof(ScTinyLlmLayer) * (u64)L);
    pModel->aParams = sc_memory_allocate(sizeof(ScAiParam*) * (u64)(6 + L * 12));
    if (!pModel->aLayers || !pModel->aParams)
    {
        sc_tiny_llm_destroy(pModel);
        return NULL;
    }
    memset(pModel->aLayers, 0, sizeof(ScTinyLlmLayer) * (u64)L);

    u64 seed = cfg.Seed;
    f32 embLimit = cfg.InitStd;
    f32 qkvLimit = _sc_tiny_llm_xavier_limit(D, 3 * D);
    f32 projLimit = _sc_tiny_llm_xavier_limit(D, D);
    f32 fc1Limit = _sc_tiny_llm_xavier_limit(D, F);
    f32 fc2Limit = _sc_tiny_llm_xavier_limit(F, D);
    f32 lmLimit = _sc_tiny_llm_xavier_limit(D, V);

    pModel->TokEmb = _sc_tiny_llm_param_new((i64)V * D, embLimit, &seed);
    pModel->PosEmb = _sc_tiny_llm_param_new((i64)T * D, embLimit, &seed);
    pModel->FinalLnG = _sc_tiny_llm_param_new(D, 1.0f, &seed);
    pModel->FinalLnB = _sc_tiny_llm_param_new(D, 0.0f, &seed);
    pModel->LmHeadW = _sc_tiny_llm_param_new((i64)D * V, lmLimit, &seed);
    pModel->LmHeadB = _sc_tiny_llm_param_new(V, 0.0f, &seed);

    if (!pModel->TokEmb.pData || !pModel->PosEmb.pData || !pModel->LmHeadW.pData)
    {
        sc_tiny_llm_destroy(pModel);
        return NULL;
    }

    for (i32 d = 0; d < D; ++d)
        pModel->FinalLnG.pData[d] = 1.0f;

    _sc_tiny_llm_model_add_param(pModel, &pModel->TokEmb);
    _sc_tiny_llm_model_add_param(pModel, &pModel->PosEmb);
    _sc_tiny_llm_model_add_param(pModel, &pModel->FinalLnG);
    _sc_tiny_llm_model_add_param(pModel, &pModel->FinalLnB);
    _sc_tiny_llm_model_add_param(pModel, &pModel->LmHeadW);
    _sc_tiny_llm_model_add_param(pModel, &pModel->LmHeadB);

    i64 attnMatrixSize = (i64)H * T * T;

    for (i32 l = 0; l < L; ++l)
    {
        ScTinyLlmLayer* layer = pModel->aLayers + l;
        layer->Ln1G = _sc_tiny_llm_param_new(D, 0.0f, &seed);
        layer->Ln1B = _sc_tiny_llm_param_new(D, 0.0f, &seed);
        layer->QkvW = _sc_tiny_llm_param_new((i64)D * 3 * D, qkvLimit, &seed);
        layer->QkvB = _sc_tiny_llm_param_new(3 * D, 0.0f, &seed);
        layer->ProjW = _sc_tiny_llm_param_new((i64)D * D, projLimit, &seed);
        layer->ProjB = _sc_tiny_llm_param_new(D, 0.0f, &seed);
        layer->Ln2G = _sc_tiny_llm_param_new(D, 0.0f, &seed);
        layer->Ln2B = _sc_tiny_llm_param_new(D, 0.0f, &seed);
        layer->Fc1W = _sc_tiny_llm_param_new((i64)D * F, fc1Limit, &seed);
        layer->Fc1B = _sc_tiny_llm_param_new(F, 0.0f, &seed);
        layer->Fc2W = _sc_tiny_llm_param_new((i64)F * D, fc2Limit, &seed);
        layer->Fc2B = _sc_tiny_llm_param_new(D, 0.0f, &seed);

        for (i32 d = 0; d < D; ++d)
        {
            layer->Ln1G.pData[d] = 1.0f;
            layer->Ln2G.pData[d] = 1.0f;
        }

        layer->aLn1Y = _sc_tiny_llm_f32_new((i64)T * D);
        layer->aLn1Xhat = _sc_tiny_llm_f32_new((i64)T * D);
        layer->aLn1InvStd = _sc_tiny_llm_f32_new(T);
        layer->aQkv = _sc_tiny_llm_f32_new((i64)T * 3 * D);
        layer->aAttnProbs = _sc_tiny_llm_f32_new(attnMatrixSize);
        layer->aAttnCtx = _sc_tiny_llm_f32_new((i64)T * D);
        layer->aLn2Y = _sc_tiny_llm_f32_new((i64)T * D);
        layer->aLn2Xhat = _sc_tiny_llm_f32_new((i64)T * D);
        layer->aLn2InvStd = _sc_tiny_llm_f32_new(T);
        layer->aFc1Pre = _sc_tiny_llm_f32_new((i64)T * F);
        layer->aFc1Act = _sc_tiny_llm_f32_new((i64)T * F);

        _sc_tiny_llm_model_add_param(pModel, &layer->Ln1G);
        _sc_tiny_llm_model_add_param(pModel, &layer->Ln1B);
        _sc_tiny_llm_model_add_param(pModel, &layer->QkvW);
        _sc_tiny_llm_model_add_param(pModel, &layer->QkvB);
        _sc_tiny_llm_model_add_param(pModel, &layer->ProjW);
        _sc_tiny_llm_model_add_param(pModel, &layer->ProjB);
        _sc_tiny_llm_model_add_param(pModel, &layer->Ln2G);
        _sc_tiny_llm_model_add_param(pModel, &layer->Ln2B);
        _sc_tiny_llm_model_add_param(pModel, &layer->Fc1W);
        _sc_tiny_llm_model_add_param(pModel, &layer->Fc1B);
        _sc_tiny_llm_model_add_param(pModel, &layer->Fc2W);
        _sc_tiny_llm_model_add_param(pModel, &layer->Fc2B);
    }

    pModel->aX = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->aTmp = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->aScoreRow = _sc_tiny_llm_f32_new(T);
    pModel->aFinalY = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->aFinalXhat = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->aFinalInvStd = _sc_tiny_llm_f32_new(T);
    pModel->aLogits = _sc_tiny_llm_f32_new((i64)T * V);
    pModel->aProbRow = _sc_tiny_llm_f32_new(V);

    pModel->dX = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->dCur = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->dNorm = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->dAttnCtx = _sc_tiny_llm_f32_new((i64)T * D);
    pModel->dQkv = _sc_tiny_llm_f32_new((i64)T * 3 * D);
    pModel->dFc1Pre = _sc_tiny_llm_f32_new((i64)T * F);
    pModel->dFc1Act = _sc_tiny_llm_f32_new((i64)T * F);
    pModel->dProbRow = _sc_tiny_llm_f32_new(T);
    pModel->dScoreRow = _sc_tiny_llm_f32_new(T);

    pModel->aTokens = _sc_tiny_llm_i32_new(T);
    pModel->aLabels = _sc_tiny_llm_i32_new(T);
    pModel->aMask = _sc_tiny_llm_i32_new(T);

    pModel->aKCache = _sc_tiny_llm_f32_new((i64)L * T * D);
    pModel->aVCache = _sc_tiny_llm_f32_new((i64)L * T * D);
    pModel->aGenX = _sc_tiny_llm_f32_new(D);
    pModel->aGenXhat = _sc_tiny_llm_f32_new(D);
    pModel->aGenInvStd = _sc_tiny_llm_f32_new(1);
    pModel->aGenQkv = _sc_tiny_llm_f32_new(3 * D);
    pModel->aGenAttnCtx = _sc_tiny_llm_f32_new(D);
    pModel->aGenFc1 = _sc_tiny_llm_f32_new(F);
    pModel->aGenTmp = _sc_tiny_llm_f32_new(D);
    pModel->aGenScoreRow = _sc_tiny_llm_f32_new(T);
    pModel->aGenProbRow = _sc_tiny_llm_f32_new(T);
    pModel->aGenLogits = _sc_tiny_llm_f32_new(V);

    // Validate all allocations (cheap and catches OOM early).
    i32 isOk = pModel->aX && pModel->aTmp && pModel->aScoreRow &&
        pModel->aFinalY && pModel->aFinalXhat && pModel->aFinalInvStd &&
        pModel->aLogits && pModel->aProbRow &&
        pModel->dX && pModel->dCur && pModel->dNorm && pModel->dAttnCtx &&
        pModel->dQkv && pModel->dFc1Pre && pModel->dFc1Act &&
        pModel->dProbRow && pModel->dScoreRow &&
        pModel->aTokens && pModel->aLabels && pModel->aMask &&
        pModel->aKCache && pModel->aVCache &&
        pModel->aGenX && pModel->aGenXhat && pModel->aGenInvStd &&
        pModel->aGenQkv && pModel->aGenAttnCtx && pModel->aGenFc1 &&
        pModel->aGenTmp && pModel->aGenScoreRow && pModel->aGenProbRow &&
        pModel->aGenLogits;

    if (isOk)
    {
        for (i32 l = 0; l < L; ++l)
        {
            ScTinyLlmLayer* layer = pModel->aLayers + l;
            if (!layer->aLn1Y || !layer->aLn1Xhat || !layer->aLn1InvStd ||
                !layer->aQkv || !layer->aAttnProbs || !layer->aAttnCtx ||
                !layer->aLn2Y || !layer->aLn2Xhat || !layer->aLn2InvStd ||
                !layer->aFc1Pre || !layer->aFc1Act)
            {
                isOk = 0;
                break;
            }
        }
    }

    if (!isOk)
    {
        sc_tiny_llm_destroy(pModel);
        return NULL;
    }

    return pModel;
}

i64
sc_tiny_llm_param_count(ScTinyLlmModel* pModel)
{
    if (!pModel)
        return 0;

    i64 count = 0;
    for (i32 p = 0; p < pModel->ParamCount; ++p)
        count += pModel->aParams[p]->Count;
    return count;
}

// DOCS: Сохраняет/восстанавливает веса одним плоским буфером для early stopping.
static void
_sc_tiny_llm_params_save(ScTinyLlmModel* pModel, f32* pDst)
{
    i64 offset = 0;
    for (i32 p = 0; p < pModel->ParamCount; ++p)
    {
        ScAiParam* pParam = pModel->aParams[p];
        memcpy(pDst + offset, pParam->pData, sizeof(f32) * (u64)pParam->Count);
        offset += pParam->Count;
    }
}

static void
_sc_tiny_llm_params_restore(ScTinyLlmModel* pModel, const f32* pSrc)
{
    i64 offset = 0;
    for (i32 p = 0; p < pModel->ParamCount; ++p)
    {
        ScAiParam* pParam = pModel->aParams[p];
        memcpy(pParam->pData, pSrc + offset, sizeof(f32) * (u64)pParam->Count);
        offset += pParam->Count;
    }
}

void
sc_tiny_llm_destroy(ScTinyLlmModel* pModel)
{
    if (!pModel)
        return;

    if (pModel->aLayers)
    {
        for (i32 l = 0; l < pModel->Cfg.NumLayers; ++l)
        {
            ScTinyLlmLayer* layer = pModel->aLayers + l;
            _sc_tiny_llm_param_destroy(&layer->Ln1G);
            _sc_tiny_llm_param_destroy(&layer->Ln1B);
            _sc_tiny_llm_param_destroy(&layer->QkvW);
            _sc_tiny_llm_param_destroy(&layer->QkvB);
            _sc_tiny_llm_param_destroy(&layer->ProjW);
            _sc_tiny_llm_param_destroy(&layer->ProjB);
            _sc_tiny_llm_param_destroy(&layer->Ln2G);
            _sc_tiny_llm_param_destroy(&layer->Ln2B);
            _sc_tiny_llm_param_destroy(&layer->Fc1W);
            _sc_tiny_llm_param_destroy(&layer->Fc1B);
            _sc_tiny_llm_param_destroy(&layer->Fc2W);
            _sc_tiny_llm_param_destroy(&layer->Fc2B);

            sc_memory_free(layer->aLn1Y);
            sc_memory_free(layer->aLn1Xhat);
            sc_memory_free(layer->aLn1InvStd);
            sc_memory_free(layer->aQkv);
            sc_memory_free(layer->aAttnProbs);
            sc_memory_free(layer->aAttnCtx);
            sc_memory_free(layer->aLn2Y);
            sc_memory_free(layer->aLn2Xhat);
            sc_memory_free(layer->aLn2InvStd);
            sc_memory_free(layer->aFc1Pre);
            sc_memory_free(layer->aFc1Act);
        }
        sc_memory_free(pModel->aLayers);
    }

    _sc_tiny_llm_param_destroy(&pModel->TokEmb);
    _sc_tiny_llm_param_destroy(&pModel->PosEmb);
    _sc_tiny_llm_param_destroy(&pModel->FinalLnG);
    _sc_tiny_llm_param_destroy(&pModel->FinalLnB);
    _sc_tiny_llm_param_destroy(&pModel->LmHeadW);
    _sc_tiny_llm_param_destroy(&pModel->LmHeadB);

    sc_memory_free(pModel->aParams);
    sc_memory_free(pModel->aX);
    sc_memory_free(pModel->aTmp);
    sc_memory_free(pModel->aScoreRow);
    sc_memory_free(pModel->aFinalY);
    sc_memory_free(pModel->aFinalXhat);
    sc_memory_free(pModel->aFinalInvStd);
    sc_memory_free(pModel->aLogits);
    sc_memory_free(pModel->aProbRow);

    sc_memory_free(pModel->dX);
    sc_memory_free(pModel->dCur);
    sc_memory_free(pModel->dNorm);
    sc_memory_free(pModel->dAttnCtx);
    sc_memory_free(pModel->dQkv);
    sc_memory_free(pModel->dFc1Pre);
    sc_memory_free(pModel->dFc1Act);
    sc_memory_free(pModel->dProbRow);
    sc_memory_free(pModel->dScoreRow);

    sc_memory_free(pModel->aTokens);
    sc_memory_free(pModel->aLabels);
    sc_memory_free(pModel->aMask);

    sc_memory_free(pModel->aKCache);
    sc_memory_free(pModel->aVCache);
    sc_memory_free(pModel->aGenX);
    sc_memory_free(pModel->aGenXhat);
    sc_memory_free(pModel->aGenInvStd);
    sc_memory_free(pModel->aGenQkv);
    sc_memory_free(pModel->aGenAttnCtx);
    sc_memory_free(pModel->aGenFc1);
    sc_memory_free(pModel->aGenTmp);
    sc_memory_free(pModel->aGenScoreRow);
    sc_memory_free(pModel->aGenProbRow);
    sc_memory_free(pModel->aGenLogits);

    sc_memory_free(pModel);
}

/*
  ###################################
  dataset
  ###################################
*/

ScTinyLlmDataset
sc_tiny_llm_dataset_new(void)
{
    ScTinyLlmDataset dataset = {};
    return dataset;
}

void
sc_tiny_llm_dataset_destroy(ScTinyLlmDataset* pDataset)
{
    if (!pDataset)
        return;

    sc_list_for_each(pDataset->aExamples, pExample)
    {
        sc_list_free(pExample->aTokens);
    }
    sc_list_free(pDataset->aExamples);
    *pDataset = (ScTinyLlmDataset) {};
}

static i32
_sc_tiny_llm_dataset_add_ext(ScTinyLlmDataset* pDataset, ScAiBpe bpe, const char* pText, i64 length)
{
    if (!pDataset || !pText || length <= 0)
        return 0;

    i32* aTokens = sc_ai_bpe_tokenize((ScAiTokenizeConfig) {
        .pText = (char*)pText,
        .TextLength = length,
        .Bpe = bpe,
    });

    if (!aTokens)
        return 0;

    i64 count = sc_list_count(aTokens);
    if (count < 2)
    {
        sc_list_free(aTokens);
        return 0;
    }

    i32 sepIndex = -1;
    for (i64 i = 0; i < count; ++i)
    {
        if (aTokens[i] == ScAiSpecialToken_Sep)
            sepIndex = (i32)i;
    }

    ScTinyLlmExample example = {
        .aTokens = aTokens,
        .Count = count,
        .SepIndex = sepIndex,
    };

    sc_list_add(pDataset->aExamples, example);
    ++pDataset->Count;
    return 1;
}

i32
sc_tiny_llm_dataset_add(ScTinyLlmDataset* pDataset, ScAiBpe bpe, const char* pText)
{
    if (!pText)
        return 0;
    return _sc_tiny_llm_dataset_add_ext(pDataset, bpe, pText, sc_string_get_length((char*)pText));
}

i32
sc_tiny_llm_dataset_load_file(ScTinyLlmDataset* pDataset, ScAiBpe bpe, const char* pPath)
{
    if (!pDataset || !pPath)
        return 0;

    i64 size = 0;
    char* pData = sc_file_read_ext_ext_r(pPath, &size);
    if (!pData)
    {
        sc_log_erro("tiny-llm: failed to read dataset %s\n", pPath);
        return 0;
    }

    i64 start = 0;
    i32 added = 0;

    // DOCS: пропускаем UTF-8 BOM, иначе первая строка не распознается.
    if (size >= 3 && (u8)pData[0] == 0xEF && (u8)pData[1] == 0xBB && (u8)pData[2] == 0xBF)
        start = 3;

    for (i64 i = start; i <= size; ++i)
    {
        if (i == size || pData[i] == '\n')
        {
            i64 end = i;
            if (end > start && pData[end - 1] == '\r')
                --end;

            if (end > start && pData[start] != '#')
            {
                if (_sc_tiny_llm_dataset_add_ext(pDataset, bpe, pData + start, end - start))
                    ++added;
            }

            start = i + 1;
        }
    }

    sc_memory_free(pData);
    return added;
}

/*
  ###################################
  training helpers
  ###################################
*/

static i32
_sc_tiny_llm_fill_window(ScTinyLlmModel* pModel, const ScTinyLlmExample* pExample,
    i32 start, ScTinyLlmLossMask lossMask, i32* pT)
{
    i32 ctx = pModel->Cfg.ContextLength;
    i32 T = (i32)(pExample->Count - 1 - start);
    if (T > ctx)
        T = ctx;
    if (T <= 0)
        return 0;

    for (i32 t = 0; t < T; ++t)
    {
        i64 globalTarget = (i64)start + t + 1;
        pModel->aTokens[t] = pExample->aTokens[start + t];
        pModel->aLabels[t] = pExample->aTokens[globalTarget];

        i32 mask = 1;
        if (lossMask == ScTinyLlmLossMask_Prompt && pExample->SepIndex >= 0 &&
            globalTarget <= (i64)pExample->SepIndex)
        {
            mask = 0;
        }
        pModel->aMask[t] = mask;
    }

    *pT = T;
    return 1;
}

static f32
_sc_tiny_llm_lr_at(i32 step, const ScTinyLlmTrainConfig* pCfg)
{
    f32 base = pCfg->LearningRate;
    if (pCfg->WarmupSteps > 0 && step < pCfg->WarmupSteps)
        return base * ((f32)(step + 1) / (f32)pCfg->WarmupSteps);

    i32 total = pCfg->Steps > pCfg->WarmupSteps ? pCfg->Steps - pCfg->WarmupSteps : 1;
    i32 done = step - pCfg->WarmupSteps;
    if (done < 0)
        done = 0;
    if (done > total)
        done = total;

    f32 progress = (f32)done / (f32)total;
    f32 cosine = 0.5f * (1.0f + cosf(3.14159265358979323846f * progress));
    return base * (0.1f + 0.9f * cosine);
}

// DOCS: append "step,val_loss,val_ppl" в CSV. Заголовок пишется один раз
// при создании файла; при ошибке открытия — предупреждение, обучение не
// прерывается.
static void
_sc_tiny_llm_val_log_append(const char* pPath, i32 step, f32 valLoss)
{
    if (!pPath)
        return;

    i32 isFirstLine = 0;
    FILE* pProbe = fopen(pPath, "r");
    if (!pProbe)
        isFirstLine = 1;
    else
        fclose(pProbe);

    FILE* pFile = fopen(pPath, "a");
    if (!pFile)
    {
        sc_log_warn("tiny-llm: cannot open val log %s\n", pPath);
        return;
    }

    if (isFirstLine)
        fprintf(pFile, "step,val_loss,val_ppl\n");

    fprintf(pFile, "%d,%.6f,%.4f\n", step, valLoss, expf(valLoss));
    fclose(pFile);
}

f32
sc_tiny_llm_eval(ScTinyLlmModel* pModel, const ScTinyLlmDataset* pDataset,
    i32 batches, ScTinyLlmLossMask lossMask, u64 seed)
{
    if (!pModel || !pDataset || pDataset->Count <= 0 || batches <= 0)
        return 0.0f;

    f64 lossSum = 0.0;
    i64 tokenCount = 0;
    i32 ctx = pModel->Cfg.ContextLength;

    for (i32 b = 0; b < batches; ++b)
    {
        i64 exampleIndex = ((i64)b + (i64)(seed & 0x7fffffff)) % pDataset->Count;
        const ScTinyLlmExample* example = pDataset->aExamples + exampleIndex;
        i32 maxStart = (i32)(example->Count - 1 - ctx);
        if (maxStart < 0)
            maxStart = 0;
        i32 start = maxStart > 0 ? (i32)(((i64)b * ctx) % (maxStart + 1)) : 0;

        i32 T = 0;
        if (!_sc_tiny_llm_fill_window(pModel, example, start, lossMask, &T))
            continue;

        _sc_tiny_llm_forward(pModel, pModel->aTokens, T);
        i32 count = 0;
        lossSum += _sc_tiny_llm_loss_and_dlogits(pModel, T, 0, &count);
        tokenCount += count;
    }

    if (tokenCount <= 0)
        return 0.0f;

    return (f32)(lossSum / (f64)tokenCount);
}

i32
sc_tiny_llm_train(ScTinyLlmModel* pModel, ScAiBpe bpe, const ScTinyLlmDataset* pTrain,
    const ScTinyLlmDataset* pValidation, const ScTinyLlmTrainConfig* pConfig)
{
    if (!pModel || !pTrain || pTrain->Count <= 0 || !pConfig || pConfig->Steps <= 0)
        return 0;

    ScTinyLlmTrainConfig cfg = *pConfig;
    if (cfg.BatchSize <= 0)
        cfg.BatchSize = 1;
    if (cfg.LearningRate <= 0.0f)
        cfg.LearningRate = 1e-3f;
    if (cfg.Seed == 0)
        cfg.Seed = 0x9e3779b97f4a7c15ULL;

    u64 rng = cfg.Seed;
    i32 ctx = pModel->Cfg.ContextLength;
    i32 adamStep = 0;

    f32 bestVal = 1e30f;
    i32 badEvals = 0;
    i32 shouldStop = 0;

    // DOCS: снимок лучших весов для восстановления после early stopping.
    f32* pBestParams = NULL;
    if (cfg.RestoreBest && cfg.EvalEvery > 0 && pValidation && pValidation->Count > 0)
    {
        i64 totalParams = sc_tiny_llm_param_count(pModel);
        if (totalParams > 0)
        {
            pBestParams = sc_memory_allocate(sizeof(f32) * (u64)totalParams);
            if (!pBestParams)
                sc_log_warn("tiny-llm: cannot allocate best-weights buffer\n");
        }
    }

    f64 lossSum = 0.0;
    i64 lossTokens = 0;

    for (i32 step = 0; step < cfg.Steps && !shouldStop; ++step)
    {
        _sc_tiny_llm_zero_params_grad(pModel);
        i32 actualBatch = 0;
        f64 stepLoss = 0.0;
        i64 stepTokens = 0;

        for (i32 b = 0; b < cfg.BatchSize; ++b)
        {
            i64 exampleIndex = (i64)(_sc_tiny_llm_rng_next(&rng) % (u64)pTrain->Count);
            const ScTinyLlmExample* example = pTrain->aExamples + exampleIndex;
            i32 maxStart = (i32)(example->Count - 1 - ctx);
            if (maxStart < 0)
                maxStart = 0;
            i32 start = maxStart > 0 ? (i32)(_sc_tiny_llm_rng_next(&rng) % (u64)(maxStart + 1)) : 0;

            i32 T = 0;
            if (!_sc_tiny_llm_fill_window(pModel, example, start, cfg.LossMask, &T))
                continue;

            _sc_tiny_llm_forward(pModel, pModel->aTokens, T);
            i32 count = 0;
            stepLoss += _sc_tiny_llm_loss_and_dlogits(pModel, T, 1, &count);
            stepTokens += count;
            _sc_tiny_llm_backward(pModel, pModel->aTokens, T);
            ++actualBatch;
        }

        if (actualBatch <= 0)
            continue;

        f32 gradNorm = _sc_tiny_llm_grad_norm(pModel);
        if (cfg.GradClip > 0.0f && gradNorm > cfg.GradClip)
            _sc_tiny_llm_scale_grad(pModel, cfg.GradClip / gradNorm);

        f32 lr = _sc_tiny_llm_lr_at(step, &cfg);
        ++adamStep;
        _sc_tiny_llm_adamw_step(pModel, lr, adamStep, 1.0f / (f32)actualBatch, cfg.WeightDecay);

        lossSum += stepLoss;
        lossTokens += stepTokens;

        if (cfg.LogEvery > 0 && (step + 1) % cfg.LogEvery == 0)
        {
            f32 avgLoss = lossTokens > 0 ? (f32)(lossSum / (f64)lossTokens) : 0.0f;
            char logBuf[256] = {};
            snprintf(logBuf, sizeof(logBuf),
                "tiny-llm: step %d/%d loss %.4f lr %.6f grad %.3f\n",
                step + 1, cfg.Steps, avgLoss, lr, gradNorm);
            sc_log_info("%s", logBuf);
            lossSum = 0.0;
            lossTokens = 0;
        }

        if (cfg.EvalEvery > 0 && pValidation && pValidation->Count > 0 &&
            (step + 1) % cfg.EvalEvery == 0)
        {
            f32 valLoss = sc_tiny_llm_eval(pModel, pValidation, cfg.EvalBatches > 0 ? cfg.EvalBatches : 1,
                cfg.LossMask, cfg.Seed);
            f32 valPpl = expf(valLoss);
            char valBuf[256] = {};
            snprintf(valBuf, sizeof(valBuf),
                "tiny-llm: val step %d loss %.4f ppl %.2f\n", step + 1, valLoss, valPpl);
            sc_log_info("%s", valBuf);

            _sc_tiny_llm_val_log_append(cfg.pValLogPath, step + 1, valLoss);

            if (valLoss < bestVal - cfg.MinDelta)
            {
                bestVal = valLoss;
                badEvals = 0;
                if (pBestParams)
                    _sc_tiny_llm_params_save(pModel, pBestParams);
            }
            else
            {
                ++badEvals;
                if (cfg.Patience > 0 && badEvals >= cfg.Patience)
                {
                    sc_log_info("tiny-llm: early stop at step %d (best val %.4f)\n", step + 1, bestVal);
                    shouldStop = 1;
                }
            }
        }

        if (cfg.pCheckpointPath && cfg.CheckpointEvery > 0 &&
            (step + 1) % cfg.CheckpointEvery == 0)
        {
            if (sc_tiny_llm_save_checkpoint(pModel, bpe, cfg.pCheckpointPath))
                sc_log_info("tiny-llm: checkpoint saved to %s\n", cfg.pCheckpointPath);
        }
    }

    if (pBestParams && bestVal < 1e29f)
    {
        _sc_tiny_llm_params_restore(pModel, pBestParams);
        sc_log_info("tiny-llm: restored best weights (val %.4f)\n", bestVal);

        // DOCS: сохраняем именно лучшие веса, а не последний шаг.
        if (cfg.pCheckpointPath && cfg.CheckpointEvery > 0)
        {
            if (sc_tiny_llm_save_checkpoint(pModel, bpe, cfg.pCheckpointPath))
                sc_log_info("tiny-llm: best checkpoint saved to %s\n", cfg.pCheckpointPath);
        }
    }

    if (pBestParams)
        sc_memory_free(pBestParams);

    return 1;
}

/*
  ###################################
  generation
  ###################################
*/

char*
sc_tiny_llm_generate(ScTinyLlmModel* pModel, ScAiBpe bpe, const char* pPrompt,
    const ScTinyLlmGenerateConfig* pConfig)
{
    if (!pModel || !pPrompt)
        return sc_string_new_ext_ext_r("", 0, 0);

    ScTinyLlmGenerateConfig cfg = pConfig ? *pConfig : sc_tiny_llm_generate_config_default();
    if (cfg.MaxTokens <= 0)
        cfg.MaxTokens = 100;
    if (cfg.Seed == 0)
        cfg.Seed = 0x9e3779b97f4a7c15ULL;

    i32 ctx = pModel->Cfg.ContextLength;

    i32* aPrompt = NULL;
    sc_list_add(aPrompt, (i32)ScAiSpecialToken_Bos);

    i64 promptLength = sc_string_get_length((char*)pPrompt);
    if (promptLength > 0)
    {
        i32* aPromptTokens = sc_ai_bpe_tokenize((ScAiTokenizeConfig) {
            .pText = (char*)pPrompt,
            .TextLength = promptLength,
            .Bpe = bpe,
        });

        if (aPromptTokens)
        {
            for (i64 i = 0; i < sc_list_count(aPromptTokens); ++i)
            {
                i32 token = aPromptTokens[i];
                if (token == ScAiSpecialToken_Bos && sc_list_count(aPrompt) == 1)
                    continue;
                sc_list_add(aPrompt, token);
            }
            sc_list_free(aPromptTokens);
        }
    }

    if (cfg.AppendSep &&
        (sc_list_count(aPrompt) == 0 || aPrompt[sc_list_count(aPrompt) - 1] != ScAiSpecialToken_Sep))
        sc_list_add(aPrompt, (i32)ScAiSpecialToken_Sep);

    i64 totalPrompt = sc_list_count(aPrompt);

    // Оставляем хотя бы одну позицию для первого сгенерированного токена.
    i64 maxPrompt = ctx > 1 ? ctx - 1 : 1;
    i64 first = totalPrompt > maxPrompt ? totalPrompt - maxPrompt : 0;

    for (i64 i = 0; i < (i64)pModel->Cfg.NumLayers * ctx * pModel->Cfg.DModel; ++i)
    {
        pModel->aKCache[i] = 0.0f;
        pModel->aVCache[i] = 0.0f;
    }

    i32 pos = 0;
    for (i64 i = first; i < totalPrompt && pos < ctx; ++i, ++pos)
        _sc_tiny_llm_forward_cached(pModel, aPrompt[i], pos);

    if (pos <= 0)
    {
        sc_list_free(aPrompt);
        return sc_string_new_ext_ext_r("", 0, 0);
    }

    ScTinyLlmCandidate* aCandidates = sc_memory_allocate(sizeof(ScTinyLlmCandidate) * (u64)pModel->Cfg.VocabCount);
    if (!aCandidates)
    {
        sc_list_free(aPrompt);
        return sc_string_new_ext_ext_r("", 0, 0);
    }

    i32* aResult = NULL;
    u64 rng = cfg.Seed;

    for (i32 i = 0; i < cfg.MaxTokens && pos < ctx; ++i)
    {
        u32 token = _sc_tiny_llm_sample(pModel->aGenLogits, pModel->Cfg.VocabCount, &cfg, aCandidates, &rng);

        if (token == (u32)ScAiSpecialToken_Eos ||
            token == (u32)ScAiSpecialToken_Pad ||
            token == (u32)ScAiSpecialToken_Bos ||
            token == (u32)ScAiSpecialToken_Sep ||
            token == (u32)ScAiSpecialToken_Unk ||
            token == (u32)ScAiSpecialToken_Persona ||
            token == (u32)ScAiSpecialToken_Char ||
            token == (u32)ScAiSpecialToken_Emo ||
            token == (u32)ScAiSpecialToken_Sit)
        {
            break;
        }

        sc_list_add(aResult, (i32)token);

        if (pos >= ctx)
            break;
        _sc_tiny_llm_forward_cached(pModel, (i32)token, pos);
        ++pos;
    }

    char* pText = sc_ai_bpe_decode(bpe, aResult);

    sc_list_free(aResult);
    sc_list_free(aPrompt);
    sc_memory_free(aCandidates);

    return pText;
}

/*
  ###################################
  checkpoints
  ###################################
*/

static const char c_sc_tiny_llm_magic[4] = { 'S', 'C', 'T', 'L' };
static const u32 c_sc_tiny_llm_version = 1;

i32
sc_tiny_llm_save_checkpoint(ScTinyLlmModel* pModel, ScAiBpe bpe, const char* pPath)
{
    if (!pModel || !pPath)
        return 0;

    FILE* pFile = fopen(pPath, "wb");
    if (!pFile)
    {
        sc_log_erro("tiny-llm: cannot open checkpoint %s for writing\n", pPath);
        return 0;
    }

    i32 config[6] = {
        pModel->Cfg.NumLayers,
        pModel->Cfg.DModel,
        pModel->Cfg.NumHeads,
        pModel->Cfg.DFf,
        pModel->Cfg.ContextLength,
        pModel->Cfg.VocabCount,
    };

    i32 isOk = 1;
    isOk = isOk && fwrite(c_sc_tiny_llm_magic, 1, 4, pFile) == 4;
    isOk = isOk && fwrite(&c_sc_tiny_llm_version, sizeof(u32), 1, pFile) == 1;
    isOk = isOk && fwrite(config, sizeof(i32), 6, pFile) == 6;

    for (i32 p = 0; p < pModel->ParamCount && isOk; ++p)
    {
        ScAiParam* param = pModel->aParams[p];
        isOk = fwrite(&param->Count, sizeof(i64), 1, pFile) == 1;
        isOk = isOk && fwrite(param->pData, sizeof(f32), (size_t)param->Count, pFile) == (size_t)param->Count;
    }

    i64 bpeLength = 0;
    char* pBpeData = sc_ai_bpe_save_to_memory(bpe, &bpeLength);
    isOk = isOk && pBpeData != NULL;
    if (isOk)
    {
        isOk = fwrite(&bpeLength, sizeof(i64), 1, pFile) == 1;
        isOk = isOk && fwrite(pBpeData, 1, (size_t)bpeLength, pFile) == (size_t)bpeLength;
    }

    // NOTE: sc_ai_bpe_save_to_memory возвращает ScString, поэтому
    // освобождать нужно через sc_string_destroy, а не sc_memory_free.
    sc_string_destroy(pBpeData);
    fclose(pFile);

    if (!isOk)
    {
        sc_log_erro("tiny-llm: failed to write checkpoint %s\n", pPath);
        return 0;
    }

    return 1;
}

ScTinyLlmModel*
sc_tiny_llm_load_checkpoint(const char* pPath, ScAiBpe* pOutBpe)
{
    if (!pPath)
        return NULL;

    FILE* pFile = fopen(pPath, "rb");
    if (!pFile)
    {
        sc_log_erro("tiny-llm: cannot open checkpoint %s\n", pPath);
        return NULL;
    }

    char magic[4] = {};
    u32 version = 0;
    i32 config[6] = {};
    i32 isOk = 1;

    isOk = isOk && fread(magic, 1, 4, pFile) == 4;
    isOk = isOk && fread(&version, sizeof(u32), 1, pFile) == 1;
    isOk = isOk && fread(config, sizeof(i32), 6, pFile) == 6;
    isOk = isOk && memcmp(magic, c_sc_tiny_llm_magic, 4) == 0;
    isOk = isOk && version == c_sc_tiny_llm_version;

    if (!isOk)
    {
        sc_log_erro("tiny-llm: invalid checkpoint header %s\n", pPath);
        fclose(pFile);
        return NULL;
    }

    ScTinyLlmModelConfig cfg = sc_tiny_llm_model_config_default(config[5]);
    cfg.NumLayers = config[0];
    cfg.DModel = config[1];
    cfg.NumHeads = config[2];
    cfg.DFf = config[3];
    cfg.ContextLength = config[4];

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&cfg);
    if (!pModel)
    {
        fclose(pFile);
        return NULL;
    }

    for (i32 p = 0; p < pModel->ParamCount && isOk; ++p)
    {
        ScAiParam* param = pModel->aParams[p];
        i64 count = 0;
        isOk = fread(&count, sizeof(i64), 1, pFile) == 1;
        isOk = isOk && count == param->Count;
        if (isOk)
            isOk = fread(param->pData, sizeof(f32), (size_t)param->Count, pFile) == (size_t)param->Count;
    }

    i64 bpeLength = 0;
    if (isOk)
        isOk = fread(&bpeLength, sizeof(i64), 1, pFile) == 1;

    if (isOk && bpeLength > 0)
    {
        char* pBpeData = sc_memory_allocate((u64)bpeLength + 1);
        if (!pBpeData)
        {
            isOk = 0;
        }
        else
        {
            isOk = fread(pBpeData, 1, (size_t)bpeLength, pFile) == (size_t)bpeLength;
            pBpeData[bpeLength] = '\0';
            if (isOk && pOutBpe)
                *pOutBpe = sc_ai_bpe_load_from_memory(pBpeData, bpeLength);
            sc_memory_free(pBpeData);
        }
    }

    fclose(pFile);

    if (!isOk)
    {
        sc_tiny_llm_destroy(pModel);
        return NULL;
    }

    return pModel;
}

/*
  ###################################
  gradient check
  ###################################
*/

i32
sc_tiny_llm_grad_check(ScTinyLlmModel* pModel, const ScTinyLlmDataset* pDataset,
    i32 maxParams, f32 epsilon, f32 tolerance)
{
    if (!pModel || !pDataset || pDataset->Count <= 0)
        return 0;
    if (maxParams <= 0)
        maxParams = 1;
    if (epsilon <= 0.0f)
        epsilon = 1e-3f;
    if (tolerance <= 0.0f)
        tolerance = 1e-2f;

    const ScTinyLlmExample* example = pDataset->aExamples;
    i32 T = 0;
    // NOTE: для проверки градиента нужен ненулевой loss, поэтому маску
    // prompt здесь не применяем: иначе первые 8 токенов могут быть
    // полностью prompt-позициями.
    if (!_sc_tiny_llm_fill_window(pModel, example, 0, ScTinyLlmLossMask_None, &T))
        return 0;

    // NOTE: для конечных разностей берём короткое окно: float-лосс на
    // длинной последовательности накапливает слишком много шума.
    if (T > 8)
        T = 8;

    _sc_tiny_llm_zero_params_grad(pModel);
    _sc_tiny_llm_forward(pModel, pModel->aTokens, T);
    i32 count = 0;
    _sc_tiny_llm_loss_and_dlogits(pModel, T, 1, &count);
    _sc_tiny_llm_backward(pModel, pModel->aTokens, T);

    i32 checked = 0;
    i32 failed = 0;

    for (i32 p = 0; p < pModel->ParamCount; ++p)
    {
        ScAiParam* param = pModel->aParams[p];
        i32 limit = (i32)(param->Count < maxParams ? param->Count : maxParams);

        for (i32 i = 0; i < limit; ++i)
        {
            f32 original = param->pData[i];
            f32 analytic = param->pGrad[i];

            param->pData[i] = original + epsilon;
            _sc_tiny_llm_forward(pModel, pModel->aTokens, T);
            i32 c0 = 0;
            f32 lossPlus = _sc_tiny_llm_loss_and_dlogits(pModel, T, 0, &c0);

            param->pData[i] = original - epsilon;
            _sc_tiny_llm_forward(pModel, pModel->aTokens, T);
            i32 c1 = 0;
            f32 lossMinus = _sc_tiny_llm_loss_and_dlogits(pModel, T, 0, &c1);

            param->pData[i] = original;

            f32 numeric = (lossPlus - lossMinus) / (2.0f * epsilon);
            f32 absDiff = fabsf(numeric - analytic);
            f32 denom = fabsf(numeric) + fabsf(analytic);
            if (denom < 1.0f)
                denom = 1.0f;

            f32 relative = absDiff / denom;
            ++checked;

            if (absDiff > tolerance && relative > tolerance)
            {
                printf("tiny-llm grad check: param %d[%d] numeric %g analytic %g abs %g rel %g\n",
                    p, i, numeric, analytic, absDiff, relative);
                ++failed;
                if (failed >= 5)
                    break;
            }
        }

        if (failed >= 5)
            break;
    }

    _sc_tiny_llm_zero_params_grad(pModel);

    if (checked <= 0)
        return 0;

    sc_log_info("tiny-llm grad check: checked %d, failed %d\n", checked, failed);
    return failed == 0;
}
