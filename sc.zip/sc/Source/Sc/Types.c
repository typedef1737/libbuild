#include "Types.h"

#if defined(SC_PLATFORM_LINUX)
#define _POSIX_C_SOURCE 200809L // for sysconf()
#include <unistd.h>
#elif defined(SC_PLATFORM_WINDOWS)
#define _WINSOCKAPI_
#include <windows.h>
#endif

#include <stdio.h>

// TODO: Optimize
void
sc_copy(void* pvWrite, void* pvRead, u64 size)
{
    char* pWrite = (char*)pvWrite;
    char* pRead = (char*)pvRead;
    for (i64 c = 0; c < size; ++c)
    {
        *pWrite = *pRead;
        ++pWrite;
        ++pRead;
    }
}

i32
sc_i32_sign(i32 v)
{
    return 1 | (v >> 31);
}

i32
sc_i32_abs(i32 v)
{
    i32 absv = (v ^ (v >> 31)) - (v >> 31);
    return absv;
}

i32
sc_f32_sign(f32 v)
{
    union
    {
        f32 f;
        i32 i;
    } u = { v };

    i32 sign_bit = (u.i >> 31) & 0x1;
    i32 is_zero = ((u.i & 0x7FFFFFFF) == 0);

    if (is_zero)
        return 1;
    return sign_bit ? -1 : 1;
}

f32
sc_f32_abs(f32 v)
{
    union
    {
        f32 f;
        i32 i;
    } u = { v };

    // DOCS: Сбрасываем знаковый 31-й бит (знаковый) устанавливая его в 0.
    u.i &= 0x7FFFFFFF;

    return u.f;
}

void
sc_char_array_set_ext(char aArr[], u64 arrSize, char* pString, i64 stringLength)
{
    char* pWrite = (char*)aArr;
    char* pRead = (char*)pString;
    i64 copySize = ScMin(arrSize, stringLength);
    sc_copy(pWrite, pRead, copySize);
}

void
sc_break(const char* pMsg, const char* pFile, int line, const char* pCondition)
{
    printf(pMsg, pFile, line, pCondition);
    volatile int* cptr = NULL;
    *cptr = 0;
}

const char*
sc_build_to_string(ScBuild build)
{
    switch (build)
    {
    case ScBuild_Debug:
        return "Debug";
    case ScBuild_Release:
        return "Release";
    case ScBuild_Distribution:
        return "Distribution";
    default:
        return "None";
    }
}

const char*
sc_os_to_string(ScOs os)
{
    switch (os)
    {
    case ScOs_Linux:
        return "Linux";
    case ScOs_Windows:
        return "Windows";
    default:
        return "None";
    }
}

const char*
sc_real_to_string(ScReal scReal)
{
    switch (scReal)
    {
    case ScReal_32Bit:
        return "32Bit";
    case ScReal_64Bit:
        return "64Bit";
    default:
        return "None";
    }
}

const char*
sc_endian_to_string(ScEndian scEndian)
{
    switch (scEndian)
    {
    case ScEndian_Little:
        return "LittleEndian";
    case ScEndian_Big:
        return "BigEndian";
    default:
        return "None";
    }
}

#if defined(SC_PLATFORM_LINUX)
#elif defined(SC_PLATFORM_WINDOWS)
#else
#error "Not platform defined!"
#endif // SC_PLATFORM_WINDOWS

ScSystemInfo
sc_system_info_get()
{
    static ScSystemInfo sysInfo = {
        .Build =
#if SC_BUILD_DEBUG
            ScBuild_Debug,
#elif SC_BUILD_RELEASE || defined(PROFILE)
            ScBuild_Release,
#elif SC_BUILD_DISTRIBUTION
            ScBuild_Distribution,
#endif

        .Os =
#if defined(SC_PLATFORM_LINUX)
            ScOs_Linux,
#elif defined(SC_PLATFORM_WINDOWS)
            ScOs_Windows,
#else
ScOs_Linux
#endif

        .Real =
#if defined(SC_REAL_32_BIT)
            ScReal_32Bit,
#else
            ScReal_64Bit,
#endif

        .Endian =
#if defined(SC_SYSTEM_LIT)
            ScEndian_Little
#else
            ScEndian_Big
#endif
    };

    return sysInfo;
}

void
sc_system_info_print()
{
    ScSystemInfo info = sc_system_info_get();
    printf("--------------------------------------\n");
    printf("| ℹ️ System info 🛡\n");
    printf("|      OS:         %s\n", sc_os_to_string(info.Os));
    printf("|      System:     %s\n", sc_endian_to_string(info.Endian));
    printf("|      Float:      %s\n", sc_real_to_string(info.Real));
    printf("|      Build:      %s\n", sc_build_to_string(info.Build));
    printf("|            🐨 🐼\n");
    printf("_____________________________________\n");
}

i32
sc_system_cpu_count()
{
    i32 count = 0;

#if defined(SC_PLATFORM_LINUX)
    count = (i32)sysconf(_SC_NPROCESSORS_ONLN);
#elif defined(SC_PLATFORM_WINDOWS)
    SYSTEM_INFO systemInfo;
    GetSystemInfo(&systemInfo);
    count = (i32)systemInfo.dwNumberOfProcessors;
#endif

    if (count < 1)
        count = 1;

    return count;
}

i32
f32_equal(f32 f0, f32 f1)
{
    f32 diffAbs = sc_f32_abs(f0 - f1);
    if (diffAbs < SC_F32_EPSILON)
        return 1;
    return 0;
}

i32
v2_equal(v2 v0, v2 v1)
{
    i32 isXEqual = f32_equal(v0.X, v1.X);
    i32 isYEqual = f32_equal(v0.Y, v1.Y);
    return isXEqual && isYEqual;
}

i32
v3_equal(v3 v0, v3 v1)
{
    i32 isXEqual = f32_equal(v0.X, v1.X);
    i32 isYEqual = f32_equal(v0.Y, v1.Y);
    i32 isZEqual = f32_equal(v0.Z, v1.Z);
    return isXEqual && isYEqual && isZEqual;
}

i32
v4_equal(v4 v0, v4 v1)
{
    i32 isXEqual = f32_equal(v0.X, v1.X);
    i32 isYEqual = f32_equal(v0.Y, v1.Y);
    i32 isZEqual = f32_equal(v0.Z, v1.Z);
    i32 isWEqual = f32_equal(v0.W, v1.W);
    return isXEqual && isYEqual && isZEqual && isWEqual;
}

i32
quat_equal(quat q0, quat q1)
{
    i32 isXEqual = f32_equal(q0.X, q1.X);
    i32 isYEqual = f32_equal(q0.Y, q1.Y);
    i32 isZEqual = f32_equal(q0.Z, q1.Z);
    i32 isWEqual = f32_equal(q0.W, q1.W);
    return isXEqual && isYEqual && isZEqual && isWEqual;
    return 0;
}
