/*
 BPE-токенизатор (экспериментальный модуль, WIP).

 Назначение:
 - byte-level BPE для UTF-8 текста (включая русский);
 - обучение слияний, хранение словаря, мерджей и токенов;
 - подготовка данных для маленькой модели генерации текста по входному
   сообщению.

 Владение памятью:
 - aTokens/aMerges/aVocab выделяются в куче и освобождаются через
   sc_list_free/sc_string_destroy;
 - g хранит рабочее состояние обучения, поэтому одновременно обучать два
   BPE нельзя.

 Известные ограничения:
 - старый формат "# vocab" не экранирует байты, новый "# vocab-esc" —
   экранирует и сохраняет значения словаря без потерь;
 - sc_ai_bpe_new2 считает пары только один раз и не обновляет их после
   мерджей;
 - модель внутри example-блока — компактный MLP-baseline, пока без
   transformer-блоков и KV-cache.

 Milestones (путь к маленькой модели генерации текста по сообщению):
 1. [x] Byte-level BPE: словарь 256 байт + спецтокены, обучение слияниям.
 2. [x] Корректная работа с UTF-8: байты 0x80..0xBF (русский) не теряются.
 3. [x] Round-trip save/load: escaped-словарь (# vocab-esc), без потери
        байтов.
 4. [x] Tokenizer: encode/decode, спецтокены, неизвестные байты через
         <UNK>.
 5. [ ] Версионирование .bpe и атомарная запись (temp + rename).
 6. [x] Датасет диалогов: пары (входное сообщение -> ответ), BOS/SEP/EOS.
     [ ] Маскирование loss на prompt.
 7. [x] Маленькая модель: embedding + MLP-блок + softmax, forward и
        backward на C.
     [ ] Заменить MLP-блок на 1-4 transformer-блока.
 8. [x] Обучение: cross-entropy + Adam.
     [ ] Чекпоинты и early stopping.
 9. [x] Генерация: temperature/top-k, остановка по EOS, ограничение длины.
     [ ] KV-cache.
 10. [x] Публичный API sc_ai_model_generate(model, message).
     [ ] Оценка качества на отложенной выборке.
 */

#include "Ai.h"
#include "Sc.h"
#include <math.h>
#include <stdio.h>

const i64 c_ignore_token = -1337;

typedef struct
{
    u32* pSt0;
    u32* pSt1;
    u32* pActive;
} ScAiGlobal;

static ScAiGlobal g = {};

/*
 Создаёт элемент словаря из сырых байтов.
 NOTE: нельзя использовать sc_string_new: он трактует байты как UTF-8 и
 ломает continuation-байты 0x80..0xBF, из которых состоят русские символы.
 */
static ScBpeVocabItem
_sc_ai_bpe_vocab_item_from_bytes(char* pBytes, i64 byteCount)
{
    ScBpeVocabItem item = {
        .pValue = sc_string_new_ext_ext_r(pBytes, byteCount, byteCount),
    };
    return item;
}

/*
 Склеивает значения двух токенов как сырые байты, без повторного разбора
 UTF-8. Длина берётся по фактическому размеру C-строки.
 */
static ScBpeVocabItem
_sc_ai_bpe_vocab_item_concat(ScBpeVocabItem left, ScBpeVocabItem right)
{
    char* pBuilder = sc_builder_new();
    sc_builder_append_string(pBuilder, left.pValue, sc_string_get_length(left.pValue));
    sc_builder_append_string(pBuilder, right.pValue, sc_string_get_length(right.pValue));

    i64 length = sc_builder_count(pBuilder);
    ScBpeVocabItem item = {
        .pValue = sc_string_new_ext_ext_r(pBuilder, length, length),
    };

    sc_builder_destroy(pBuilder);
    return item;
}

static i32
_sc_ai_hex_value(char c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    return -1;
}

/*
 Читает одну строку словаря в escaped-формате (см. save).
 Поддерживает \\, \n, \r, \t и \xNN, поэтому значение может содержать
 любые байты, включая перевод строки и обратный слэш.
 */
static ScBpeVocabItem
_sc_ai_bpe_vocab_item_from_escaped_line(char* pLine, i64 lineLength)
{
    char* pBuilder = sc_builder_new();

    for (i64 i = 0; i < lineLength; ++i)
    {
        char c = pLine[i];
        if (c != '\\')
        {
            sc_builder_append_char(pBuilder, c);
            continue;
        }

        if (i + 1 >= lineLength)
        {
            sc_builder_append_char(pBuilder, c);
            break;
        }

        char escaped = pLine[++i];
        switch (escaped)
        {
        case '\\':
            sc_builder_append_char(pBuilder, '\\');
            break;
        case 'n':
            sc_builder_append_char(pBuilder, '\n');
            break;
        case 'r':
            sc_builder_append_char(pBuilder, '\r');
            break;
        case 't':
            sc_builder_append_char(pBuilder, '\t');
            break;
        case 'x':
        {
            if (i + 2 < lineLength)
            {
                i32 hi = _sc_ai_hex_value(pLine[i + 1]);
                i32 lo = _sc_ai_hex_value(pLine[i + 2]);
                if (hi >= 0 && lo >= 0)
                {
                    sc_builder_append_char(pBuilder, (char)((hi << 4) | lo));
                    i += 2;
                }
            }
            break;
        }
        default:
            sc_builder_append_char(pBuilder, escaped);
            break;
        }
    }

    i64 length = sc_builder_count(pBuilder);
    ScBpeVocabItem item = {
        .pValue = sc_string_new_ext_ext_r(pBuilder, length, length),
    };

    sc_builder_destroy(pBuilder);
    return item;
}

// mb struct ???
u32*
tokens_array_new(char* pText, i64 textLength)
{
    u32* aTokens = NULL;

    if (!pText || textLength <= 0)
        return aTokens;

    aTokens = sc_list_reserve(aTokens, textLength);
    sc_list_header(aTokens)->Count = 0;

    for (i64 i = 0; i < textLength; ++i)
    {
        char* ptr = pText + i;
        if (i + 5 <= textLength && sc_string_compare_ext(ptr, "<EOS>", 5))
        {
            sc_list_add(aTokens, ScAiSpecialToken_Eos);
            i += 4;
        }
        else
        {
            char c = *ptr;
            switch (c)
            {
            case '\n':
            case '\t':
            case '\v':
            case '\r':
                continue;
            }
            u8 ch = c;
            sc_list_add(aTokens, ch);
        }
    }

    return aTokens;
}

ScAiBpe
sc_ai_bpe_new(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;
    u64* aPairKeys = NULL;

    struct
    {
        i64 Key;
        ScBpeTokenPair Value;
    }* hPairs = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char byte = (char)i;
        ScBpeVocabItem item = _sc_ai_bpe_vocab_item_from_bytes(&byte, 1);
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < 5; ++i)
    {
        const char* names[] = { "<UNK>", "<PAD>", "<BOS>", "<EOS>", "<SEP>" };
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)names[i]) };
        sc_list_add(aVocab, item);
    }

    i64 copyCount = cfg.TextLength;
    i64 mergesCount = cfg.MergesCount;
    g.pSt0 = tokens_array_new(cfg.pText, copyCount);
    g.pSt1 = sc_list_reserve(g.pSt1, copyCount);
    g.pActive = g.pSt0;

    /* DOCS:
        Optimize plan:
        - use hash table for Pairs

        */

    for (i32 m = 0; m < mergesCount; ++m)
    {
        //
        // tokens_find_max_pair()
        //

        ScBpeTokenPair maxPair = {};
        i64 vocabCount = sc_list_count(aVocab);

        {

            u32* aTokens = g.pActive;

            i64 fptokensCount = sc_list_count(aTokens) - 1;

            for (i64 i = 0; i < fptokensCount; ++i)
            {
                // DOCS: ignore shit so we dont have to reallocate
                u32 c = aTokens[i];
                if (c >= ScAiSpecialToken_Unk && c <= ScAiSpecialToken_Sep)
                    continue;

                u32 nc = aTokens[i + 1];
                if (nc >= ScAiSpecialToken_Unk && nc <= ScAiSpecialToken_Sep)
                    continue;

                if (c >= vocabCount || nc >= vocabCount)
                    continue;

                u64 ab = (to_u64(c) << 32) | nc;
                i32 isKeyExist = sc_dict_i_contains(hPairs, ab);

                if (isKeyExist)
                {
                    // DOCS: Увеличиваем счётчик пары.
                    i64 ind = sc_dict_index(hPairs);
                    hPairs[ind].Value.Count = ++hPairs[ind].Value.Count;
                }
                else
                {
                    ScBpeTokenPair pair = {
                        .A = c,
                        .B = nc,
                        .Count = 1,
                    };
                    sc_dict_i_add(hPairs, ab, pair);
                    sc_list_add(aPairKeys, ab);
                }
            }

            i64 pairKeysCoount = sc_list_count(aPairKeys);
            sc_log_info("Pairs count: %d\n", pairKeysCoount);

            if (pairKeysCoount == 0)
            {
                sc_dict_clear(hPairs);
                sc_list_clear(aPairKeys);
                break;
            }

            u64 pairKey = aPairKeys[0];
            maxPair = sc_dict_i_get(hPairs, pairKey);
            for (i64 p = 1; p < pairKeysCoount; ++p)
            {
                pairKey = aPairKeys[p];
                ScBpeTokenPair pair = sc_dict_i_get(hPairs, pairKey);
                if (pair.Count > maxPair.Count)
                {
                    maxPair = pair;
                }
            }

            sc_dict_clear(hPairs);
            sc_list_clear(aPairKeys);
        }

        if (maxPair.Count <= 1)
        {
            sc_log_warn("прерывание: цикла, дошли до (ручки) maxPair.Count <= 1\n");
            break;
        }
        sc_bpe_token_pair_print(maxPair, m, mergesCount);

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[maxPair.A];
        ScBpeVocabItem itemB = aVocab[maxPair.B];

        ScAiMerge merge = { .T0 = maxPair.A, .T1 = maxPair.B, .Tf = newId };
        sc_list_add(aMerges, merge);

        ScBpeVocabItem newVocabItem = _sc_ai_bpe_vocab_item_concat(itemA, itemB);

        sc_list_add(aVocab, newVocabItem);

        // DOCS: new replacement
        u32* aCopyFrom = NULL;
        u32* aNewTokens = NULL;
        if (g.pActive == g.pSt0)
        {
            aCopyFrom = g.pSt0;
            aNewTokens = g.pSt1;
            g.pActive = g.pSt1;
        }
        else
        {
            aCopyFrom = g.pSt1;
            aNewTokens = g.pSt0;
            g.pActive = g.pSt0;
        }

        i64 copyTokensCount = sc_list_count(aCopyFrom);
        sc_list_header(aNewTokens)->Count = 0;

        for (i64 t = 0; t < copyTokensCount; ++t)
        {
            u32 token = aCopyFrom[t];
            if (t + 1 < copyTokensCount && token == maxPair.A && aCopyFrom[t + 1] == maxPair.B)
            {
                sc_list_add(aNewTokens, newId);
                ++t;
            }
            else
            {
                sc_list_add(aNewTokens, token);
            }
        }
    }

    scAiBpe.aTokens = g.pActive;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;

    return scAiBpe;
}

ScAiBpe
sc_ai_bpe_load_from_disk(char* pFile)
{
    ScAiBpe bpe = {};

    if (!pFile)
    {
        sc_log_erro("sc_ai_bpe_load_from_disk: pFile is null!\n");
        return bpe;
    }

    // DOCS: Extension validation, only bpe files expected.
    i64 extIndex = sc_string_last_index_of(pFile, '.');
    if (extIndex < 0 || !sc_string_compare_ext(pFile + extIndex, ".bpe", 4))
    {
        sc_log_erro("Invalid extension for the file %s!\n", pFile);
        return bpe;
    }

    i64 fileSize = 0;
    char* pFileData = sc_file_read_ext(pFile, &fileSize);
    if (!pFileData)
    {
        sc_log_erro("Failed to read bpe file %s!\n", pFile);
        return bpe;
    }

    bpe = sc_ai_bpe_load_from_memory(pFileData, fileSize);
    sc_memory_free(pFileData);

    return bpe;
}

ScAiBpe
sc_ai_bpe_load_from_memory(char* pData, i64 dataSize)
{
    ScAiBpe bpe = {};

    if (!pData || dataSize <= 0)
        return bpe;

    char* ptr = pData;
    char c = *ptr;

    while (c != '\0')
    {
        switch (c)
        {
        case '#':
        {
            if (sc_string_compare_ext(ptr, "# merges\n", 9))
            {
                ptr += 13;
                c = *ptr;

                while (!sc_char_is_integer(c))
                {
                    ++ptr;
                    c = *ptr;
                }

                ScAiMerge* aMerges = NULL;
                while (c != '`' && c != '\0')
                {
                    // DOCS: пропускаем переводы строк между мерджами.
                    ptr = sc_parse_skip_space(ptr);
                    c = *ptr;
                    if (c == '`' || c == '\0')
                        break;

                    // read line
                    ScParsedInt parsedInt0 = sc_parse_int_while_int(ptr);
                    if (!parsedInt0.pOutput)
                        break;
                    ptr = parsedInt0.pOutput;
                    ptr = sc_parse_skip_space(ptr);
                    // todo: create sc_parsed_utils

                    ScParsedInt parsedInt1 = sc_parse_int_while_int(ptr);
                    if (!parsedInt1.pOutput)
                        break;
                    ptr = parsedInt1.pOutput;
                    ptr = sc_parse_skip_space(ptr);

                    ScParsedInt parsedInt2 = sc_parse_int_while_int(ptr);
                    if (!parsedInt2.pOutput)
                        break;
                    ptr = parsedInt2.pOutput;

                    ScAiMerge merge = {
                        .T0 = parsedInt0.IntValue,
                        .T1 = parsedInt1.IntValue,
                        .Tf = parsedInt2.IntValue
                    };
                    sc_list_add(aMerges, merge);
                    c = *ptr;
                }

                bpe.aMerges = aMerges;
            }
            else if (sc_string_compare_ext(ptr, "# vocab-esc\n```", 15))
            {
                ptr += 15;

                if (*ptr == '\n')
                    ++ptr;
                c = *ptr;

                ScBpeVocabItem* aVocab = NULL;
                while (c != '\0')
                {
                    i64 newLineIndex = sc_string_index_of(ptr, '\n');
                    if (newLineIndex < 0)
                        break;

                    // DOCS: закрывающий маркер словаря.
                    if (newLineIndex == 3 && sc_string_compare_ext(ptr, "```", 3))
                        break;

                    ScBpeVocabItem vocabItem = _sc_ai_bpe_vocab_item_from_escaped_line(ptr, newLineIndex);
                    sc_list_add(aVocab, vocabItem);

                    ptr += newLineIndex + 1;
                    c = *ptr;
                }

                bpe.aVocab = aVocab;
            }
            else if (sc_string_compare_ext(ptr, "# vocab\n```", 11))
            {
                ptr += 11;

                // DOCS: пропускаем только перевод строки после открывающих ```,
                // а не все пробелы: пробел и пустая строка — тоже токены.
                if (*ptr == '\n')
                    ++ptr;
                c = *ptr;

                ScBpeVocabItem* aVocab = NULL;
                while (c != '\0')
                {
                    i64 newLineIndex = sc_string_index_of(ptr, '\n');
                    if (newLineIndex < 0)
                        break;

                    // DOCS: закрывающий маркер словаря.
                    if (newLineIndex == 3 && sc_string_compare_ext(ptr, "```", 3))
                        break;

                    ScBpeVocabItem vocabItem = {
                        .pValue = sc_string_new_ext(ptr, newLineIndex, newLineIndex)
                    };
                    sc_list_add(aVocab, vocabItem);

                    // DOCS: stopped at next string beginning
                    ptr += newLineIndex + 1;
                    c = *ptr;
                }

                bpe.aVocab = aVocab;
            }
            else
            {
                ++ptr;
                c = *ptr;
            }
            break;
        }

        default:
        {
            ++ptr;
            c = *ptr;
            break;
        }
        }
    }

    return bpe;
}

static void
_sc_ai_write_into_file_ext(const char* pOutFile, const char* pData, i64 dataLength)
{
    sc_file_append_string(pOutFile, (char*)pData, dataLength);
}
static void
_sc_ai_write_into_file(const char* pOutFile, const char* pData)
{
    _sc_ai_write_into_file_ext(pOutFile, (char*)pData, sc_string_get_length((char*)pData));
}

/*
 Пишет значение словаря в escaped-формате: любые байты, включая перевод
 строки и обратный слэш, остаются в одной строке и читаются без потерь.
 */
static void
_sc_ai_write_vocab_item_escaped(const char* pOutFile, const char* pValue, i64 length)
{
    char* pBuilder = sc_builder_new();
    char hexBuf[5] = {};

    for (i64 i = 0; i < length; ++i)
    {
        u8 c = (u8)pValue[i];
        switch (c)
        {
        case '\\':
            sc_builder_append_char(pBuilder, '\\');
            sc_builder_append_char(pBuilder, '\\');
            break;
        case '\n':
            sc_builder_append_char(pBuilder, '\\');
            sc_builder_append_char(pBuilder, 'n');
            break;
        case '\r':
            sc_builder_append_char(pBuilder, '\\');
            sc_builder_append_char(pBuilder, 'r');
            break;
        case '\t':
            sc_builder_append_char(pBuilder, '\\');
            sc_builder_append_char(pBuilder, 't');
            break;
        default:
            if (c < 0x20 || c == 0x7F || c == '`')
            {
                snprintf(hexBuf, 5, "\\x%02X", c);
                sc_builder_append_string(pBuilder, hexBuf, 4);
            }
            else
            {
                sc_builder_append_char(pBuilder, (char)c);
            }
            break;
        }
    }

    _sc_ai_write_into_file_ext(pOutFile, pBuilder, sc_builder_count(pBuilder));
    sc_builder_destroy(pBuilder);
}

void
sc_ai_bpe_save_to_disk(ScAiBpeSaveToDiskConfig cfg)
{
    if (!cfg.pFilePath)
    {
        sc_log_warn("cfg is invalid!\n");
        return;
    }

    const char* pFilePath = cfg.pFilePath;
    ScProfiler scprf = {};
    char* pProcessingTime = "n/a";
    if (cfg.pProfiler)
    {
        scprf = *(ScProfiler*)cfg.pProfiler;
        // NOTE: sc_profiler_get_string не умеет обрабатывать нулевое время.
        pProcessingTime = scprf.Result != 0 ? sc_profiler_get_string(&scprf) : "0 ns";
    }

    i64 totalTextLength = cfg.TotalTextLength;
    ScAiBpe bpe = cfg.Bpe;
    i64 totalLengthCompressed = cfg.TotalTextLengthCompressed;
    f32 ratio = 0.0f;
    if (totalTextLength > 0)
        ratio = ((f32)totalLengthCompressed / (f32)totalTextLength) * 100.0f;

    i8 c_should_add_text = cfg.ShouldAddText;
    i8 c_should_add_tokens = cfg.ShouldAddTokens;

    // NOTE: функции ниже пишут в режиме append, поэтому старый файл нужно
    // сначала очистить, иначе данные от предыдущего запуска останутся.
    sc_file_write(pFilePath, "", 0);

    char sbuf[256] = {};
    snprintf(sbuf, 256, "# processing-time: %s\n# compression: %lld/%lld (%0.1f%%)\n", pProcessingTime, (i64)totalLengthCompressed, (i64)totalTextLength, 100.0f - ratio);
    _sc_ai_write_into_file(pFilePath, sbuf);

    snprintf(sbuf, 256, "# corpus-size %lld\n# vocab-size %lld\n# merges-size %lld\n# tokens-size %lld\n\n", (i64)totalTextLength, (i64)sc_list_count(bpe.aVocab), (i64)sc_list_count(bpe.aMerges), (i64)totalLengthCompressed);
    _sc_ai_write_into_file(pFilePath, sbuf);

    _sc_ai_write_into_file(pFilePath, "# merges\n```\n");
    sc_list_for_each(bpe.aMerges, pMerge)
    {
        char mbuf[256] = {};
        snprintf(mbuf, 256, "%d %d %d\n", pMerge->T0, pMerge->T1, pMerge->Tf);
        _sc_ai_write_into_file(pFilePath, mbuf);
    }
    _sc_ai_write_into_file(pFilePath, "```\n# end merges\n");

    _sc_ai_write_into_file(pFilePath, "# vocab-esc\n```\n");
    sc_list_for_each(bpe.aVocab, pVocab)
    {
        _sc_ai_write_vocab_item_escaped(pFilePath, pVocab->pValue, sc_string_get_length(pVocab->pValue));
        _sc_ai_write_into_file(pFilePath, "\n");
    }
    _sc_ai_write_into_file(pFilePath, "```\n# end vocab\n");

    if (c_should_add_text && cfg.pText)
    {
        _sc_ai_write_into_file(pFilePath, "# text\n```\n");
        _sc_ai_write_into_file_ext(pFilePath, cfg.pText, totalTextLength);
        _sc_ai_write_into_file(pFilePath, "\n```\n# end text\n");
    }

    if (c_should_add_tokens)
    {
        _sc_ai_write_into_file(pFilePath, "# tokens\n```\n");
        sc_list_for_each(bpe.aTokens, pTokens)
        {
            i32 token = *pTokens;
            if (token != -1337)
            {
                if (token == 259)
                {
                    _sc_ai_write_into_file(pFilePath, "[EOS]\n");
                }
                else
                {
                    char mbuf[256] = {};
                    snprintf(mbuf, 256, "[%d]", token);
                    _sc_ai_write_into_file(pFilePath, mbuf);
                }
            }
        }
        _sc_ai_write_into_file(pFilePath, "\n```\n# end tokens\n");
    }
}

ScAiBpe
sc_ai_bpe_new2(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;
    u64* aPairKeys = NULL;

    struct
    {
        i64 Key;
        ScBpeTokenPair Value;
    }* hPairs = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char byte = (char)i;
        ScBpeVocabItem item = _sc_ai_bpe_vocab_item_from_bytes(&byte, 1);
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < 5; ++i)
    {
        const char* names[] = { "<UNK>", "<PAD>", "<BOS>", "<EOS>", "<SEP>" };
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)names[i]) };
        sc_list_add(aVocab, item);
    }

    i64 copyCount = cfg.TextLength;
    i64 mergesCount = cfg.MergesCount;
    g.pSt0 = tokens_array_new(cfg.pText, copyCount);
    g.pSt1 = sc_list_reserve(g.pSt1, copyCount);
    g.pActive = g.pSt0;

    /* DOCS:
        Optimize plan:
        - use hash table for Pairs

        */

    //
    // tokens_find_max_pair()
    //

    i64 vocabCount = sc_list_count(aVocab);

    {
        u32* aTokens = g.pActive;

        i64 fptokensCount = sc_list_count(aTokens) - 1;

        for (i64 i = 0; i < fptokensCount; ++i)
        {
            // DOCS: ignore shit so we dont have to reallocate
            u32 c = aTokens[i];
            if (c >= ScAiSpecialToken_Unk && c <= ScAiSpecialToken_Sep)
                continue;

            u32 nc = aTokens[i + 1];
            if (nc >= ScAiSpecialToken_Unk && nc <= ScAiSpecialToken_Sep)
                continue;

            if (c >= vocabCount || nc >= vocabCount)
                continue;

            u64 ab = (to_u64(c) << 32) | nc;
            i32 isKeyExist = sc_dict_i_contains(hPairs, ab);

            if (isKeyExist)
            {
                // DOCS: Увеличиваем счётчик пары.
                i64 ind = sc_dict_index(hPairs);
                hPairs[ind].Value.Count = ++hPairs[ind].Value.Count;
            }
            else
            {
                ScBpeTokenPair pair = {
                    .A = c,
                    .B = nc,
                    .Count = 1,
                };
                sc_dict_i_add(hPairs, ab, pair);
                sc_list_add(aPairKeys, ab);
            }
        }

        // sc_dict_clear(hPairs);
        // sc_list_clear(aPairKeys);
    }

    for (i32 m = 0; m < mergesCount; ++m)
    {
        i64 pairKeysCount = sc_list_count(aPairKeys);
        sc_log_info("Pairs count: %d\n", pairKeysCount);
        if (pairKeysCount == 0)
            break;

        u64 pairKey = aPairKeys[0];
        ScBpeTokenPair maxPair = sc_dict_i_get(hPairs, pairKey);
        for (i64 p = 1; p < pairKeysCount; ++p)
        {
            pairKey = aPairKeys[p];
            ScBpeTokenPair pair = sc_dict_i_get(hPairs, pairKey);
            if (pair.Count > maxPair.Count)
            {
                maxPair = pair;
            }
        }

        if (maxPair.Count <= 1)
        {
            sc_log_warn("прерывание: цикла, дошли до (ручки) maxPair.Count <= 1\n");
            break;
        }
        sc_bpe_token_pair_print(maxPair, m, mergesCount);

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[maxPair.A];
        ScBpeVocabItem itemB = aVocab[maxPair.B];

        ScAiMerge merge = { .T0 = maxPair.A, .T1 = maxPair.B, .Tf = newId };
        sc_list_add(aMerges, merge);

        ScBpeVocabItem newVocabItem = _sc_ai_bpe_vocab_item_concat(itemA, itemB);

        sc_list_add(aVocab, newVocabItem);

        // DOCS: new replacement
        u32* aCopyFrom = NULL;
        u32* aNewTokens = NULL;
        if (g.pActive == g.pSt0)
        {
            aCopyFrom = g.pSt0;
            aNewTokens = g.pSt1;
            g.pActive = g.pSt1;
        }
        else
        {
            aCopyFrom = g.pSt1;
            aNewTokens = g.pSt0;
            g.pActive = g.pSt0;
        }

        i64 copyTokensCount = sc_list_count(aCopyFrom);
        sc_list_header(aNewTokens)->Count = 0;

        for (i64 t = 0; t < copyTokensCount; ++t)
        {
            u32 token = aCopyFrom[t];
            if (t + 1 < copyTokensCount && token == maxPair.A && aCopyFrom[t + 1] == maxPair.B)
            {
                sc_list_add(aNewTokens, newId);
                ++t;
            }
            else
            {
                sc_list_add(aNewTokens, token);
            }
        }
    }

    scAiBpe.aTokens = g.pActive;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;

    return scAiBpe;
}

void
sc_bpe_token_pair_print(ScBpeTokenPair pair, i32 done, i32 total)
{
    // char buf[3] = { pair.A, pair.B };
    // sc_log_info("Pair: '%s' -> %d\n", buf, pair.Count);

    i32 ind = 0;
    char buf[1024] = {};

    if ((pair.A >= 32 && pair.A <= 126) || (pair.A >= 0xC0 && pair.A <= 0xFF))
    {
        buf[ind] = (char)pair.A;
        ++ind;
    }
    else
    {
        ind += snprintf(buf, 8, "\\x%02X", pair.A);
    }

    if ((pair.B >= 32 && pair.B <= 126) || (pair.B >= 0xC0 && pair.B <= 0xFF))
    {
        buf[ind] = (char)pair.B;
        ++ind;
    }

    else
    {
        snprintf(buf + ind, 8, "\\x%02X", pair.B);
    }

    ++done;
    char tbuf[32] = {};
    snprintf(tbuf, 32, "%0.1f", done / (f32)total * 100);
    printf("Pair: '%s' -> %d (%d/%d %s)\n", buf, pair.Count, done, total, tbuf);
}

#if 1 // example stuff

/*
 ###################################
 ###################################
 sc_ai_bpe: encode / decode
 ###################################
 ###################################
*/

i32*
sc_ai_bpe_tokenize(ScAiTokenizeConfig cfg)
{
    if (!cfg.pText || cfg.TextLength <= 0)
        return NULL;

    u32* aTokens = tokens_array_new(cfg.pText, cfg.TextLength);
    if (!aTokens)
        return NULL;

    i64 mergeCount = sc_list_count(cfg.Bpe.aMerges);
    for (i64 m = 0; m < mergeCount; ++m)
    {
        ScAiMerge merge = cfg.Bpe.aMerges[m];
        i64 tokenCount = sc_list_count(aTokens);
        if (tokenCount < 2)
            break;

        u32* aNext = NULL;
        aNext = sc_list_reserve(aNext, tokenCount);

        for (i64 i = 0; i < tokenCount; ++i)
        {
            u32 token = aTokens[i];
            if (i + 1 < tokenCount && token == merge.T0 && aTokens[i + 1] == merge.T1)
            {
                sc_list_add(aNext, merge.Tf);
                ++i;
            }
            else
            {
                sc_list_add(aNext, token);
            }
        }

        sc_list_free(aTokens);
        aTokens = aNext;
    }

    return (i32*)aTokens;
}

char*
sc_ai_bpe_decode(ScAiBpe bpe, i32* aTokens)
{
    char* pBuilder = sc_builder_new();
    i64 vocabCount = sc_list_count(bpe.aVocab);
    i64 tokenCount = sc_list_count(aTokens);

    for (i64 i = 0; i < tokenCount; ++i)
    {
        u32 token = (u32)aTokens[i];
        if (token < (u32)vocabCount)
        {
            ScBpeVocabItem item = bpe.aVocab[token];
            sc_builder_append_string(pBuilder, item.pValue, sc_string_get_length(item.pValue));
        }
    }

    i64 length = sc_builder_count(pBuilder);
    char* pText = sc_string_new_ext_ext_r(pBuilder, length, length);

    sc_builder_destroy(pBuilder);
    return pText;
}

/*
 ###################################
 ###################################
 small model: math helpers
 ###################################
 ###################################
*/

static u64
_sc_ai_rng_next(u64* pState)
{
    u64 x = *pState;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *pState = x;
    return x;
}

static f32
_sc_ai_rng_f32(u64* pState)
{
    u64 value = _sc_ai_rng_next(pState) >> 40;
    return (f32)value / 16777216.0f;
}

static void
_sc_ai_fill_zero(f32* pData, i64 count)
{
    for (i64 i = 0; i < count; ++i)
        pData[i] = 0.0f;
}

static ScAiParam
_sc_ai_param_new(i64 count, f32 initScale, u64* pState)
{
    ScAiParam param = {};
    param.Count = count;

    if (count <= 0)
        return param;

    param.pData = sc_memory_allocate(sizeof(f32) * count);
    param.pGrad = sc_memory_allocate(sizeof(f32) * count);
    param.pM = sc_memory_allocate(sizeof(f32) * count);
    param.pV = sc_memory_allocate(sizeof(f32) * count);

    for (i64 i = 0; i < count; ++i)
    {
        param.pData[i] = (_sc_ai_rng_f32(pState) * 2.0f - 1.0f) * initScale;
        param.pGrad[i] = 0.0f;
        param.pM[i] = 0.0f;
        param.pV[i] = 0.0f;
    }

    return param;
}

static void
_sc_ai_param_destroy(ScAiParam* pParam)
{
    if (!pParam)
        return;

    sc_memory_free(pParam->pData);
    sc_memory_free(pParam->pGrad);
    sc_memory_free(pParam->pM);
    sc_memory_free(pParam->pV);

    pParam->pData = NULL;
    pParam->pGrad = NULL;
    pParam->pM = NULL;
    pParam->pV = NULL;
    pParam->Count = 0;
}

static void
_sc_ai_param_zero_grad(ScAiParam* pParam)
{
    if (!pParam || !pParam->pGrad)
        return;

    _sc_ai_fill_zero(pParam->pGrad, pParam->Count);
}

static void
_sc_ai_param_adam(ScAiParam* pParam, f32 learningRate, i32 step, i32 batchCount)
{
    if (!pParam || !pParam->pData || pParam->Count <= 0)
        return;

    const f32 beta1 = 0.9f;
    const f32 beta2 = 0.999f;
    const f32 epsilon = 1e-8f;
    f32 scale = batchCount > 0 ? 1.0f / (f32)batchCount : 1.0f;
    f32 beta1Pow = 1.0f - powf(beta1, (f32)step);
    f32 beta2Pow = 1.0f - powf(beta2, (f32)step);

    for (i64 i = 0; i < pParam->Count; ++i)
    {
        f32 grad = pParam->pGrad[i] * scale;

        pParam->pM[i] = beta1 * pParam->pM[i] + (1.0f - beta1) * grad;
        pParam->pV[i] = beta2 * pParam->pV[i] + (1.0f - beta2) * grad * grad;

        f32 mHat = pParam->pM[i] / beta1Pow;
        f32 vHat = pParam->pV[i] / beta2Pow;

        pParam->pData[i] -= learningRate * mHat / (sqrtf(vHat) + epsilon);
        pParam->pGrad[i] = 0.0f;
    }
}

static void
_sc_ai_softmax(f32* pLogits, f32* pProbs, i32 count, f32 temperature)
{
    if (count <= 0)
        return;

    if (temperature <= 1e-5f)
        temperature = 1e-5f;

    f32 maxLogit = pLogits[0];
    for (i32 i = 1; i < count; ++i)
    {
        if (pLogits[i] > maxLogit)
            maxLogit = pLogits[i];
    }

    f32 sum = 0.0f;
    for (i32 i = 0; i < count; ++i)
    {
        f32 value = expf((pLogits[i] - maxLogit) / temperature);
        pProbs[i] = value;
        sum += value;
    }

    if (sum <= 0.0f)
        return;

    for (i32 i = 0; i < count; ++i)
        pProbs[i] /= sum;
}

static u32
_sc_ai_model_safe_token(ScAiModel* pModel, u32 token)
{
    if (token >= (u32)pModel->VocabCount)
        return (u32)ScAiSpecialToken_Unk;
    return token;
}

static void
_sc_ai_model_zero_grad(ScAiModel* pModel)
{
    _sc_ai_param_zero_grad(&pModel->TokenEmbedding);
    _sc_ai_param_zero_grad(&pModel->PositionEmbedding);
    _sc_ai_param_zero_grad(&pModel->HiddenWeights);
    _sc_ai_param_zero_grad(&pModel->HiddenBias);
    _sc_ai_param_zero_grad(&pModel->OutputWeights);
    _sc_ai_param_zero_grad(&pModel->OutputBias);
}

/*
 ###################################
 ###################################
 small model: forward / backward
 ###################################
 ###################################
*/

static void
_sc_ai_model_forward(ScAiModel* pModel, u32* aContext)
{
    i32 contextLength = pModel->ContextLength;
    i32 embeddingDim = pModel->EmbeddingDim;
    i32 hiddenDim = pModel->HiddenDim;
    i32 vocabCount = pModel->VocabCount;
    i32 inputSize = contextLength * embeddingDim;

    for (i32 i = 0; i < contextLength; ++i)
    {
        u32 token = _sc_ai_model_safe_token(pModel, aContext[i]);
        for (i32 d = 0; d < embeddingDim; ++d)
        {
            i64 index = i * embeddingDim + d;
            pModel->aContextX[index] = pModel->TokenEmbedding.pData[(i64)token * embeddingDim + d] + pModel->PositionEmbedding.pData[index];
        }
    }

    for (i32 h = 0; h < hiddenDim; ++h)
    {
        f32 sum = pModel->HiddenBias.pData[h];
        for (i32 j = 0; j < inputSize; ++j)
            sum += pModel->aContextX[j] * pModel->HiddenWeights.pData[(i64)j * hiddenDim + h];

        pModel->aHidden[h] = tanhf(sum);
    }

    for (i32 v = 0; v < vocabCount; ++v)
    {
        f32 sum = pModel->OutputBias.pData[v];
        for (i32 h = 0; h < hiddenDim; ++h)
            sum += pModel->aHidden[h] * pModel->OutputWeights.pData[(i64)h * vocabCount + v];

        pModel->aLogits[v] = sum;
    }

    _sc_ai_softmax(pModel->aLogits, pModel->aProbs, vocabCount, 1.0f);
}

static f32
_sc_ai_model_backward(ScAiModel* pModel, u32* aContext, u32 target)
{
    i32 contextLength = pModel->ContextLength;
    i32 embeddingDim = pModel->EmbeddingDim;
    i32 hiddenDim = pModel->HiddenDim;
    i32 vocabCount = pModel->VocabCount;
    i32 inputSize = contextLength * embeddingDim;

    target = _sc_ai_model_safe_token(pModel, target);

    f32 loss = -logf(pModel->aProbs[target] + 1e-8f);

    // NOTE: logits уже не нужны, используем буфер под dLogits.
    f32* aDLogits = pModel->aLogits;
    for (i32 v = 0; v < vocabCount; ++v)
        aDLogits[v] = pModel->aProbs[v];
    aDLogits[target] -= 1.0f;

    _sc_ai_fill_zero(pModel->aHiddenGrad, hiddenDim);

    for (i32 h = 0; h < hiddenDim; ++h)
    {
        for (i32 v = 0; v < vocabCount; ++v)
        {
            pModel->OutputWeights.pGrad[(i64)h * vocabCount + v] += pModel->aHidden[h] * aDLogits[v];
            pModel->aHiddenGrad[h] += pModel->OutputWeights.pData[(i64)h * vocabCount + v] * aDLogits[v];
        }
    }

    for (i32 v = 0; v < vocabCount; ++v)
        pModel->OutputBias.pGrad[v] += aDLogits[v];

    for (i32 h = 0; h < hiddenDim; ++h)
        pModel->aPreActivationGrad[h] = pModel->aHiddenGrad[h] * (1.0f - pModel->aHidden[h] * pModel->aHidden[h]);

    _sc_ai_fill_zero(pModel->aContextGrad, inputSize);

    for (i32 j = 0; j < inputSize; ++j)
    {
        for (i32 h = 0; h < hiddenDim; ++h)
        {
            pModel->HiddenWeights.pGrad[(i64)j * hiddenDim + h] += pModel->aContextX[j] * pModel->aPreActivationGrad[h];
            pModel->aContextGrad[j] += pModel->HiddenWeights.pData[(i64)j * hiddenDim + h] * pModel->aPreActivationGrad[h];
        }
    }

    for (i32 h = 0; h < hiddenDim; ++h)
        pModel->HiddenBias.pGrad[h] += pModel->aPreActivationGrad[h];

    for (i32 i = 0; i < contextLength; ++i)
    {
        u32 token = _sc_ai_model_safe_token(pModel, aContext[i]);
        for (i32 d = 0; d < embeddingDim; ++d)
        {
            i64 index = i * embeddingDim + d;
            f32 grad = pModel->aContextGrad[index];

            pModel->TokenEmbedding.pGrad[(i64)token * embeddingDim + d] += grad;
            pModel->PositionEmbedding.pGrad[index] += grad;
        }
    }

    return loss;
}

static void
_sc_ai_model_adam_step(ScAiModel* pModel, f32 learningRate, i32 step, i32 batchCount)
{
    _sc_ai_param_adam(&pModel->TokenEmbedding, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->PositionEmbedding, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->HiddenWeights, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->HiddenBias, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->OutputWeights, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->OutputBias, learningRate, step, batchCount);
}

static u32
_sc_ai_sample(ScAiModel* pModel, f32 temperature, i32 topK, u64* pState)
{
    i32 vocabCount = pModel->VocabCount;

    if (temperature <= 1e-5f)
    {
        i32 best = 0;
        for (i32 v = 1; v < vocabCount; ++v)
        {
            if (pModel->aLogits[v] > pModel->aLogits[best])
                best = v;
        }
        return (u32)best;
    }

    _sc_ai_softmax(pModel->aLogits, pModel->aProbs, vocabCount, temperature);

    if (topK > vocabCount)
        topK = vocabCount;
    if (topK < 1)
        topK = 1;

    i32* aSelected = sc_memory_allocate(sizeof(i32) * topK);
    for (i32 k = 0; k < topK; ++k)
    {
        i32 best = -1;
        f32 bestProbability = -1.0f;

        for (i32 v = 0; v < vocabCount; ++v)
        {
            i32 isUsed = 0;
            for (i32 j = 0; j < k; ++j)
            {
                if (aSelected[j] == v)
                {
                    isUsed = 1;
                    break;
                }
            }

            if (!isUsed && pModel->aProbs[v] > bestProbability)
            {
                bestProbability = pModel->aProbs[v];
                best = v;
            }
        }

        aSelected[k] = best >= 0 ? best : 0;
    }

    f32 sum = 0.0f;
    for (i32 k = 0; k < topK; ++k)
        sum += pModel->aProbs[aSelected[k]];

    f32 value = _sc_ai_rng_f32(pState) * sum;
    f32 accumulated = 0.0f;
    u32 result = (u32)aSelected[topK - 1];

    for (i32 k = 0; k < topK; ++k)
    {
        accumulated += pModel->aProbs[aSelected[k]];
        if (value <= accumulated)
        {
            result = (u32)aSelected[k];
            break;
        }
    }

    sc_memory_free(aSelected);
    return result;
}

/*
 ###################################
 ###################################
 small model: public API
 ###################################
 ###################################
*/

ScAiModel
sc_ai_model_new(ScAiModelConfig cfg)
{
    ScAiModel model = {};

    model.VocabCount = cfg.VocabCount > (i32)ScAiSpecialToken_Sep ? cfg.VocabCount : (i32)ScAiSpecialToken_Sep + 1;
    model.ContextLength = cfg.ContextLength > 0 ? cfg.ContextLength : 8;
    model.EmbeddingDim = cfg.EmbeddingDim > 0 ? cfg.EmbeddingDim : 16;
    model.HiddenDim = cfg.HiddenDim > 0 ? cfg.HiddenDim : 32;

    u64 seed = cfg.Seed ? cfg.Seed : 0x9e3779b97f4a7c15ULL;

    i32 contextLength = model.ContextLength;
    i32 embeddingDim = model.EmbeddingDim;
    i32 hiddenDim = model.HiddenDim;
    i32 vocabCount = model.VocabCount;
    i32 inputSize = contextLength * embeddingDim;

    f32 hiddenScale = 1.0f / sqrtf((f32)inputSize);
    f32 outputScale = 1.0f / sqrtf((f32)hiddenDim);

    model.TokenEmbedding = _sc_ai_param_new((i64)vocabCount * embeddingDim, 0.1f, &seed);
    model.PositionEmbedding = _sc_ai_param_new((i64)contextLength * embeddingDim, 0.1f, &seed);
    model.HiddenWeights = _sc_ai_param_new((i64)inputSize * hiddenDim, hiddenScale, &seed);
    model.HiddenBias = _sc_ai_param_new(hiddenDim, 0.0f, &seed);
    model.OutputWeights = _sc_ai_param_new((i64)hiddenDim * vocabCount, outputScale, &seed);
    model.OutputBias = _sc_ai_param_new(vocabCount, 0.0f, &seed);

    model.aContextX = sc_memory_allocate(sizeof(f32) * inputSize);
    model.aHidden = sc_memory_allocate(sizeof(f32) * hiddenDim);
    model.aLogits = sc_memory_allocate(sizeof(f32) * vocabCount);
    model.aProbs = sc_memory_allocate(sizeof(f32) * vocabCount);
    model.aHiddenGrad = sc_memory_allocate(sizeof(f32) * hiddenDim);
    model.aPreActivationGrad = sc_memory_allocate(sizeof(f32) * hiddenDim);
    model.aContextGrad = sc_memory_allocate(sizeof(f32) * inputSize);

    return model;
}

void
sc_ai_model_destroy(ScAiModel* pModel)
{
    if (!pModel)
        return;

    _sc_ai_param_destroy(&pModel->TokenEmbedding);
    _sc_ai_param_destroy(&pModel->PositionEmbedding);
    _sc_ai_param_destroy(&pModel->HiddenWeights);
    _sc_ai_param_destroy(&pModel->HiddenBias);
    _sc_ai_param_destroy(&pModel->OutputWeights);
    _sc_ai_param_destroy(&pModel->OutputBias);

    sc_memory_free(pModel->aContextX);
    sc_memory_free(pModel->aHidden);
    sc_memory_free(pModel->aLogits);
    sc_memory_free(pModel->aProbs);
    sc_memory_free(pModel->aHiddenGrad);
    sc_memory_free(pModel->aPreActivationGrad);
    sc_memory_free(pModel->aContextGrad);

    *pModel = (ScAiModel) {};
}

static u32*
_sc_ai_build_sequence(ScAiBpe bpe, char* pInput, char* pOutput)
{
    u32* aSequence = NULL;

    sc_list_add(aSequence, (u32)ScAiSpecialToken_Bos);

    ScAiTokenizeConfig inputConfig = {
        .pText = pInput,
        .TextLength = pInput ? sc_string_get_length(pInput) : 0,
        .Bpe = bpe,
    };
    i32* aInputTokens = sc_ai_bpe_tokenize(inputConfig);
    if (aInputTokens)
    {
        for (i64 i = 0; i < sc_list_count(aInputTokens); ++i)
            sc_list_add(aSequence, (u32)aInputTokens[i]);
        sc_list_free(aInputTokens);
    }

    sc_list_add(aSequence, (u32)ScAiSpecialToken_Sep);

    ScAiTokenizeConfig outputConfig = {
        .pText = pOutput,
        .TextLength = pOutput ? sc_string_get_length(pOutput) : 0,
        .Bpe = bpe,
    };
    i32* aOutputTokens = sc_ai_bpe_tokenize(outputConfig);
    if (aOutputTokens)
    {
        for (i64 i = 0; i < sc_list_count(aOutputTokens); ++i)
            sc_list_add(aSequence, (u32)aOutputTokens[i]);
        sc_list_free(aOutputTokens);
    }

    sc_list_add(aSequence, (u32)ScAiSpecialToken_Eos);

    return aSequence;
}

static void
_sc_ai_fill_context(u32* aContext, u32* aSequence, i64 endIndex, i32 contextLength)
{
    for (i32 i = 0; i < contextLength; ++i)
    {
        i64 sourceIndex = endIndex - (contextLength - 1) + i;
        aContext[i] = sourceIndex >= 0 ? aSequence[sourceIndex] : (u32)ScAiSpecialToken_Pad;
    }
}

void
sc_ai_model_train(ScAiModel* pModel, ScAiBpe bpe, ScAiDialogDataset dataset, ScAiTrainConfig cfg)
{
    if (!pModel || !dataset.aPairs || dataset.Count <= 0)
        return;

    i32 steps = cfg.Steps > 0 ? cfg.Steps : 1;
    i32 batchSize = cfg.BatchSize > 0 ? cfg.BatchSize : 1;
    f32 learningRate = cfg.LearningRate > 0.0f ? cfg.LearningRate : 0.01f;
    i32 contextLength = pModel->ContextLength;

    u32* aContext = sc_memory_allocate(sizeof(u32) * contextLength);
    i32 adamStep = 0;
    i32 batchCount = 0;
    f64 lossSum = 0.0;
    i32 lossCount = 0;

    _sc_ai_model_zero_grad(pModel);

    for (i32 step = 0; step < steps; ++step)
    {
        for (i64 pairIndex = 0; pairIndex < dataset.Count; ++pairIndex)
        {
            ScAiDialogPair pair = dataset.aPairs[pairIndex];
            u32* aSequence = _sc_ai_build_sequence(bpe, pair.pInput, pair.pOutput);
            i64 sequenceCount = sc_list_count(aSequence);

            for (i64 t = 0; t + 1 < sequenceCount; ++t)
            {
                _sc_ai_fill_context(aContext, aSequence, t, contextLength);
                _sc_ai_model_forward(pModel, aContext);

                f32 loss = _sc_ai_model_backward(pModel, aContext, aSequence[t + 1]);
                lossSum += loss;
                ++lossCount;
                ++batchCount;

                if (batchCount >= batchSize)
                {
                    ++adamStep;
                    _sc_ai_model_adam_step(pModel, learningRate, adamStep, batchCount);
                    batchCount = 0;
                }
            }

            sc_list_free(aSequence);
        }

        if (cfg.LogEvery > 0 && (step + 1) % cfg.LogEvery == 0 && lossCount > 0)
        {
            sc_log_info("ai train: step %d/%d loss %.4f\n", step + 1, steps, (f32)(lossSum / lossCount));
            lossSum = 0.0;
            lossCount = 0;
        }
    }

    if (batchCount > 0)
    {
        ++adamStep;
        _sc_ai_model_adam_step(pModel, learningRate, adamStep, batchCount);
    }

    sc_memory_free(aContext);
}

char*
sc_ai_model_generate(ScAiModel* pModel, ScAiBpe bpe, char* pMessage, ScAiGenerateConfig cfg)
{
    if (!pModel || !pMessage)
        return sc_string_new_ext_ext_r("", 0, 0);

    i32 contextLength = pModel->ContextLength;
    i32 maxTokens = cfg.MaxTokens > 0 ? cfg.MaxTokens : 64;
    f32 temperature = cfg.Temperature;
    i32 topK = cfg.TopK > 0 ? cfg.TopK : 8;
    u64 rngState = cfg.Seed ? cfg.Seed : 0x9e3779b97f4a7c15ULL;

    u32* aPrompt = NULL;
    sc_list_add(aPrompt, (u32)ScAiSpecialToken_Bos);

    ScAiTokenizeConfig tokenizeConfig = {
        .pText = pMessage,
        .TextLength = sc_string_get_length(pMessage),
        .Bpe = bpe,
    };
    i32* aMessageTokens = sc_ai_bpe_tokenize(tokenizeConfig);
    if (aMessageTokens)
    {
        for (i64 i = 0; i < sc_list_count(aMessageTokens); ++i)
            sc_list_add(aPrompt, (u32)aMessageTokens[i]);
        sc_list_free(aMessageTokens);
    }

    sc_list_add(aPrompt, (u32)ScAiSpecialToken_Sep);

    i32* aResult = NULL;
    u32* aContext = sc_memory_allocate(sizeof(u32) * contextLength);

    for (i32 i = 0; i < maxTokens; ++i)
    {
        i64 promptCount = sc_list_count(aPrompt);
        for (i32 c = 0; c < contextLength; ++c)
        {
            i64 sourceIndex = promptCount - contextLength + c;
            aContext[c] = sourceIndex >= 0 ? aPrompt[sourceIndex] : (u32)ScAiSpecialToken_Pad;
        }

        _sc_ai_model_forward(pModel, aContext);

        u32 token = _sc_ai_sample(pModel, temperature, topK, &rngState);
        if (token == (u32)ScAiSpecialToken_Eos ||
            token == (u32)ScAiSpecialToken_Bos ||
            token == (u32)ScAiSpecialToken_Sep ||
            token == (u32)ScAiSpecialToken_Pad ||
            token == (u32)ScAiSpecialToken_Unk)
        {
            break;
        }

        sc_list_add(aResult, (i32)token);
        sc_list_add(aPrompt, token);
    }

    char* pText = sc_ai_bpe_decode(bpe, aResult);

    sc_list_free(aResult);
    sc_list_free(aPrompt);
    sc_memory_free(aContext);

    return pText;
}

#endif // example stuff
