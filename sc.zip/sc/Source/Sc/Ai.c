/*
 BPE-токенизатор (экспериментальный модуль, WIP).

 Назначение:
 - byte-level BPE для UTF-8 текста (включая русский);
 - обучение слияний, хранение словаря, мерджей и токенов;
 - подготовка данных для маленькой модели генерации текста по входному
   сообщению.

 Владение памятью:
 - aTokens/aMerges/aVocab выделяются в куче и освобождаются через
   sc_list_free/sc_string_destroy;
 - sc_ai_bpe_new_fast владеет своим aTokens (ScAiBpe.OwnsTokens = 1);
 - старый sc_ai_bpe_new отдаёт aTokens из общего g, поэтому одновременно
   обучать два BPE через него нельзя.

 Известные ограничения:
 - старый формат "# vocab" не экранирует байты, новый "# vocab-esc" —
   экранирует и сохраняет значения словаря без потерь;
 - sc_ai_bpe_new — reference-реализация O(merges * tokens); для больших
   корпусов используйте sc_ai_bpe_new_fast (хеш пар + позиционные списки);
 - ScAiModel — компактный MLP-baseline; production transformer с
   KV-cache находится в Sc/TinyLlm.c.

 Milestones (путь к маленькой модели генерации текста по сообщению):
 1. [x] Byte-level BPE: словарь 256 байт + спецтокены, обучение слияниям.
 2. [x] Корректная работа с UTF-8: байты 0x80..0xBF (русский) не теряются.
 3. [x] Round-trip save/load: escaped-словарь (# vocab-esc), без потери
        байтов.
 4. [x] Tokenizer: encode/decode, спецтокены (<PERSONA>/<CHAR>/<EMO>/<SIT>),
        неизвестные байты через <UNK>.
 5. [x] Версионирование .bpe (# bpe v1) и строгая валидация словаря/мерджей.
     [ ] Атомарная запись (temp + rename).
 6. [x] Датасет условных примеров BOS/.../SEP/.../EOS.
     [x] Маскирование loss на prompt (Sc/TinyLlm.c).
 7. [x] MLP-baseline (ScAiModel) и production decoder-only transformer
        (ScTinyLlmModel): LayerNorm, MHSA, FFN, forward/backward.
 8. [x] Обучение: cross-entropy + AdamW, warmup/cosine, grad clip.
     [x] Чекпоинты (config + weights + встроенный BPE) и early stopping.
     [x] Восстановление лучших весов по val loss после early stopping.
 9. [x] Генерация: greedy/top-k/top-p/temperature, KV-cache, остановка по EOS.
 10. [x] Публичный API sc_ai_model_generate / sc_tiny_llm_generate.
     [x] Численная проверка градиента конечными разностями.
     [ ] Оценка качества на большой отложенной выборке.
 11. [x] Incremental BPE (sc_ai_bpe_new_fast): хеш-таблица частот,
         позиционные списки и max-heap. Бенчмарк 50 МБ / 10k merges ~17 с.
 12. [x] Демо-проект small-llm-try: синтетические персоны, обучение,
         генерация и reload чекпоинта.
 */

#include "Ai.h"
#include "Sc.h"
#include <math.h>
#include <stdio.h>

const i64 c_ignore_token = -1337;

typedef struct
{
    u32* pSt0;
    u32* pSt1;
    u32* pActive;
} ScAiGlobal;

static ScAiGlobal g = {};

/*
 Спецтокены в порядке ID 256..264. Порядок обязан совпадать с
 ScAiSpecialToken: токенизатор и загрузчик BPE используют его для
 разметки условных примеров (<PERSONA>, <CHAR>, <EMO>, <SIT>).
 */
static const char* c_sc_ai_special_names[] = {
    "<UNK>",
    "<PAD>",
    "<BOS>",
    "<EOS>",
    "<SEP>",
    "<PERSONA>",
    "<CHAR>",
    "<EMO>",
    "<SIT>",
};

static const u32 c_sc_ai_special_ids[] = {
    ScAiSpecialToken_Unk,
    ScAiSpecialToken_Pad,
    ScAiSpecialToken_Bos,
    ScAiSpecialToken_Eos,
    ScAiSpecialToken_Sep,
    ScAiSpecialToken_Persona,
    ScAiSpecialToken_Char,
    ScAiSpecialToken_Emo,
    ScAiSpecialToken_Sit,
};

static const i64 c_sc_ai_special_count = (i64)(sizeof(c_sc_ai_special_names) / sizeof(c_sc_ai_special_names[0]));

/*
 Создаёт элемент словаря из сырых байтов.
 NOTE: нельзя использовать sc_string_new: он трактует байты как UTF-8 и
 ломает continuation-байты 0x80..0xBF, из которых состоят русские символы.
 */
static ScBpeVocabItem
_sc_ai_bpe_vocab_item_from_bytes(char* pBytes, i64 byteCount)
{
    ScBpeVocabItem item = {
        .pValue = sc_string_new_ext_ext_r(pBytes, byteCount, byteCount),
    };
    return item;
}

/*
 Склеивает значения двух токенов как сырые байты, без повторного разбора
 UTF-8. Длина берётся по фактическому размеру C-строки.
 */
static ScBpeVocabItem
_sc_ai_bpe_vocab_item_concat(ScBpeVocabItem left, ScBpeVocabItem right)
{
    char* pBuilder = sc_builder_new();
    sc_builder_append_string(pBuilder, left.pValue, sc_string_get_length(left.pValue));
    sc_builder_append_string(pBuilder, right.pValue, sc_string_get_length(right.pValue));

    i64 length = sc_builder_count(pBuilder);
    ScBpeVocabItem item = {
        .pValue = sc_string_new_ext_ext_r(pBuilder, length, length),
    };

    sc_builder_destroy(pBuilder);
    return item;
}

static i32
_sc_ai_hex_value(char c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    return -1;
}

/*
 Читает одну строку словаря в escaped-формате (см. save).
 Поддерживает \\, \n, \r, \t и \xNN, поэтому значение может содержать
 любые байты, включая перевод строки и обратный слэш.
 */
static ScBpeVocabItem
_sc_ai_bpe_vocab_item_from_escaped_line(char* pLine, i64 lineLength)
{
    char* pBuilder = sc_builder_new();

    for (i64 i = 0; i < lineLength; ++i)
    {
        char c = pLine[i];
        if (c != '\\')
        {
            sc_builder_append_char(pBuilder, c);
            continue;
        }

        if (i + 1 >= lineLength)
        {
            sc_builder_append_char(pBuilder, c);
            break;
        }

        char escaped = pLine[++i];
        switch (escaped)
        {
        case '\\':
            sc_builder_append_char(pBuilder, '\\');
            break;
        case 'n':
            sc_builder_append_char(pBuilder, '\n');
            break;
        case 'r':
            sc_builder_append_char(pBuilder, '\r');
            break;
        case 't':
            sc_builder_append_char(pBuilder, '\t');
            break;
        case 'x':
        {
            if (i + 2 < lineLength)
            {
                i32 hi = _sc_ai_hex_value(pLine[i + 1]);
                i32 lo = _sc_ai_hex_value(pLine[i + 2]);
                if (hi >= 0 && lo >= 0)
                {
                    sc_builder_append_char(pBuilder, (char)((hi << 4) | lo));
                    i += 2;
                }
            }
            break;
        }
        default:
            sc_builder_append_char(pBuilder, escaped);
            break;
        }
    }

    i64 length = sc_builder_count(pBuilder);
    ScBpeVocabItem item = {
        .pValue = sc_string_new_ext_ext_r(pBuilder, length, length),
    };

    sc_builder_destroy(pBuilder);
    return item;
}

// mb struct ???
u32*
tokens_array_new(char* pText, i64 textLength)
{
    u32* aTokens = NULL;

    if (!pText || textLength <= 0)
        return aTokens;

    aTokens = sc_list_reserve(aTokens, textLength);
    sc_list_header(aTokens)->Count = 0;

    for (i64 i = 0; i < textLength; ++i)
    {
        char* ptr = pText + i;
        i32 isSpecial = 0;

        // DOCS: сначала спецтокены, иначе '<' попадёт в обычные байты.
        for (i64 s = 0; s < c_sc_ai_special_count; ++s)
        {
            i64 nameLength = sc_string_get_length((char*)c_sc_ai_special_names[s]);
            if (i + nameLength <= textLength && sc_string_compare_ext(ptr, (char*)c_sc_ai_special_names[s], nameLength))
            {
                sc_list_add(aTokens, c_sc_ai_special_ids[s]);
                i += nameLength - 1;
                isSpecial = 1;
                break;
            }
        }

        if (isSpecial)
            continue;

        char c = *ptr;
        switch (c)
        {
        case '\n':
        case '\t':
        case '\v':
        case '\r':
            continue;
        }
        u8 ch = c;
        sc_list_add(aTokens, ch);
    }

    return aTokens;
}

ScAiBpe
sc_ai_bpe_new(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;
    u64* aPairKeys = NULL;

    struct
    {
        i64 Key;
        ScBpeTokenPair Value;
    }* hPairs = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char byte = (char)i;
        ScBpeVocabItem item = _sc_ai_bpe_vocab_item_from_bytes(&byte, 1);
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < (i32)c_sc_ai_special_count; ++i)
    {
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)c_sc_ai_special_names[i]) };
        sc_list_add(aVocab, item);
    }

    i64 copyCount = cfg.TextLength;
    i64 mergesCount = cfg.MergesCount;
    g.pSt0 = tokens_array_new(cfg.pText, copyCount);
    g.pSt1 = sc_list_reserve(g.pSt1, copyCount);
    g.pActive = g.pSt0;

    /* DOCS:
        Optimize plan:
        - use hash table for Pairs

        */

    for (i32 m = 0; m < mergesCount; ++m)
    {
        //
        // tokens_find_max_pair()
        //

        ScBpeTokenPair maxPair = {};
        i64 vocabCount = sc_list_count(aVocab);

        {

            u32* aTokens = g.pActive;

            i64 fptokensCount = sc_list_count(aTokens) - 1;

            for (i64 i = 0; i < fptokensCount; ++i)
            {
                // DOCS: ignore shit so we dont have to reallocate
                u32 c = aTokens[i];
                if (c >= ScAiSpecialToken_Unk && c <= ScAiSpecialToken_Sit)
                    continue;

                u32 nc = aTokens[i + 1];
                if (nc >= ScAiSpecialToken_Unk && nc <= ScAiSpecialToken_Sit)
                    continue;

                if (c >= vocabCount || nc >= vocabCount)
                    continue;

                u64 ab = (to_u64(c) << 32) | nc;
                i32 isKeyExist = sc_dict_i_contains(hPairs, ab);

                if (isKeyExist)
                {
                    // DOCS: Увеличиваем счётчик пары.
                    i64 ind = sc_dict_index(hPairs);
                    hPairs[ind].Value.Count = ++hPairs[ind].Value.Count;
                }
                else
                {
                    ScBpeTokenPair pair = {
                        .A = c,
                        .B = nc,
                        .Count = 1,
                    };
                    sc_dict_i_add(hPairs, ab, pair);
                    sc_list_add(aPairKeys, ab);
                }
            }

            i64 pairKeysCoount = sc_list_count(aPairKeys);
            if (cfg.ShouldLogProgress)
                sc_log_info("Pairs count: %d\n", pairKeysCoount);

            if (pairKeysCoount == 0)
            {
                sc_dict_clear(hPairs);
                sc_list_clear(aPairKeys);
                break;
            }

            u64 pairKey = aPairKeys[0];
            maxPair = sc_dict_i_get(hPairs, pairKey);
            for (i64 p = 1; p < pairKeysCoount; ++p)
            {
                pairKey = aPairKeys[p];
                ScBpeTokenPair pair = sc_dict_i_get(hPairs, pairKey);
                if (pair.Count > maxPair.Count)
                {
                    maxPair = pair;
                }
            }

            sc_dict_clear(hPairs);
            sc_list_clear(aPairKeys);
        }

        if (maxPair.Count <= 1)
        {
            sc_log_warn("прерывание: цикла, дошли до (ручки) maxPair.Count <= 1\n");
            break;
        }
        if (cfg.ShouldLogProgress)
            sc_bpe_token_pair_print(maxPair, m, mergesCount);

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[maxPair.A];
        ScBpeVocabItem itemB = aVocab[maxPair.B];

        ScAiMerge merge = { .T0 = maxPair.A, .T1 = maxPair.B, .Tf = newId };
        sc_list_add(aMerges, merge);

        ScBpeVocabItem newVocabItem = _sc_ai_bpe_vocab_item_concat(itemA, itemB);

        sc_list_add(aVocab, newVocabItem);

        // DOCS: new replacement
        u32* aCopyFrom = NULL;
        u32* aNewTokens = NULL;
        if (g.pActive == g.pSt0)
        {
            aCopyFrom = g.pSt0;
            aNewTokens = g.pSt1;
            g.pActive = g.pSt1;
        }
        else
        {
            aCopyFrom = g.pSt1;
            aNewTokens = g.pSt0;
            g.pActive = g.pSt0;
        }

        i64 copyTokensCount = sc_list_count(aCopyFrom);
        sc_list_header(aNewTokens)->Count = 0;

        for (i64 t = 0; t < copyTokensCount; ++t)
        {
            u32 token = aCopyFrom[t];
            if (t + 1 < copyTokensCount && token == maxPair.A && aCopyFrom[t + 1] == maxPair.B)
            {
                sc_list_add(aNewTokens, newId);
                ++t;
            }
            else
            {
                sc_list_add(aNewTokens, token);
            }
        }
    }

    scAiBpe.aTokens = g.pActive;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;

    return scAiBpe;
}

/*
 Быстрый инкрементальный BPE.

 Отличия от sc_ai_bpe_new:
 - токены хранятся в двусвязном списке, а не в двух массивах;
 - частоты пар лежат в open-addressing хеш-таблице;
 - для каждой пары хранится список позиций (левых узлов), где она встречается;
 - максимальная пара выбирается из max-heap, устаревшие записи отбрасываются
   лениво по номеру версии.

 Стоимость: каждая успешная пара уменьшает число токенов на один, поэтому
 суммарная обработка позиций O(tokens + merges), а не O(tokens * merges).
 Спецтокены 256..264 считаются границами и в пары не попадают.
*/

typedef struct
{
    u32 Token;
    i32 Prev;
    // DOCS: -1 - конец списка, -2 - узел уже слит и удалён.
    i32 Next;
} ScAiFastNode;

typedef struct
{
    u64 Key;
    i32 PairIndex;
} ScAiFastSlot;

typedef struct
{
    u32 A;
    u32 B;
    u64 Key;
    i32 Count;
    i32 Version;
    i32* aOccurrences;
} ScAiFastPair;

typedef struct
{
    i32 Count;
    i32 Version;
    u64 Key;
} ScAiFastHeapItem;

typedef struct
{
    ScAiFastNode* aNodes;
    i32 NodeCount;
    i32 Head;
    i32 AliveCount;

    ScAiFastPair* aPairs;
    ScAiFastSlot* aSlots;
    i32 SlotCapacity;
    i32 SlotCount;

    ScAiFastHeapItem* aHeap;
} ScAiFastState;

static i8
_sc_ai_fast_is_special(u32 token)
{
    return token >= ScAiSpecialToken_Unk && token <= ScAiSpecialToken_Sit;
}

static u64
_sc_ai_fast_hash_mix(u64 x)
{
    x ^= x >> 33;
    x *= 0xFF51AFD7ED558CCDULL;
    x ^= x >> 33;
    x *= 0xC4CEB9FE1A85EC53ULL;
    x ^= x >> 33;
    return x;
}

// DOCS: Возвращает индекс слота: занятый с нужным ключом или первый пустой.
static i32
_sc_ai_fast_hash_find_slot(ScAiFastSlot* aSlots, i32 capacity, u64 key)
{
    u64 mask = (u64)capacity - 1;
    u64 pos = _sc_ai_fast_hash_mix(key) & mask;

    for (i32 probe = 0; probe < capacity; ++probe)
    {
        if (aSlots[pos].PairIndex < 0)
            return (i32)pos;
        if (aSlots[pos].Key == key)
            return (i32)pos;
        pos = (pos + 1) & mask;
    }

    return -1;
}

static void
_sc_ai_fast_hash_insert_slot(ScAiFastSlot* aSlots, i32 capacity, u64 key, i32 pairIndex)
{
    i32 slot = _sc_ai_fast_hash_find_slot(aSlots, capacity, key);
    if (slot < 0)
        return;

    aSlots[slot].Key = key;
    aSlots[slot].PairIndex = pairIndex;
}

static i32
_sc_ai_fast_hash_find(ScAiFastState* pState, u64 key)
{
    if (pState->SlotCapacity <= 0 || !pState->aSlots)
        return -1;

    i32 slot = _sc_ai_fast_hash_find_slot(pState->aSlots, pState->SlotCapacity, key);
    if (slot < 0)
        return -1;

    return pState->aSlots[slot].PairIndex;
}

static i8
_sc_ai_fast_hash_grow(ScAiFastState* pState)
{
    i32 newCapacity = pState->SlotCapacity > 0 ? pState->SlotCapacity * 2 : 1024;
    ScAiFastSlot* aNewSlots = sc_memory_allocate(sizeof(ScAiFastSlot) * (u64)newCapacity);
    if (!aNewSlots)
        return 0;

    for (i32 i = 0; i < newCapacity; ++i)
        aNewSlots[i] = (ScAiFastSlot){ .PairIndex = -1 };

    if (pState->aSlots)
    {
        for (i32 i = 0; i < pState->SlotCapacity; ++i)
        {
            if (pState->aSlots[i].PairIndex >= 0)
                _sc_ai_fast_hash_insert_slot(
                    aNewSlots,
                    newCapacity,
                    pState->aSlots[i].Key,
                    pState->aSlots[i].PairIndex);
        }

        sc_memory_free(pState->aSlots);
    }

    pState->aSlots = aNewSlots;
    pState->SlotCapacity = newCapacity;
    return 1;
}

static i8
_sc_ai_fast_hash_ensure(ScAiFastState* pState)
{
    if (pState->SlotCapacity > 0)
        return 1;
    return _sc_ai_fast_hash_grow(pState);
}

static i8
_sc_ai_fast_hash_put(ScAiFastState* pState, u64 key, i32 pairIndex)
{
    if (!_sc_ai_fast_hash_ensure(pState))
        return 0;

    // DOCS: держим загрузку ниже 75%, иначе linear probing деградирует.
    if ((pState->SlotCount + 1) * 4 >= pState->SlotCapacity * 3)
    {
        if (!_sc_ai_fast_hash_grow(pState))
            return 0;
    }

    i32 slot = _sc_ai_fast_hash_find_slot(pState->aSlots, pState->SlotCapacity, key);
    if (slot < 0)
        return 0;

    pState->aSlots[slot].Key = key;
    pState->aSlots[slot].PairIndex = pairIndex;
    ++pState->SlotCount;
    return 1;
}

static i32
_sc_ai_fast_pair_get_or_add(ScAiFastState* pState, u64 key)
{
    i32 pairIndex = _sc_ai_fast_hash_find(pState, key);
    if (pairIndex >= 0)
        return pairIndex;

    ScAiFastPair pair = {
        .A = (u32)(key >> 32),
        .B = (u32)key,
        .Key = key,
        .Count = 0,
        .Version = 0,
        .aOccurrences = NULL,
    };

    sc_list_add(pState->aPairs, pair);
    pairIndex = (i32)(sc_list_count(pState->aPairs) - 1);

    if (!_sc_ai_fast_hash_put(pState, key, pairIndex))
        return -1;

    return pairIndex;
}

static i8
_sc_ai_fast_heap_better(ScAiFastHeapItem left, ScAiFastHeapItem right)
{
    if (left.Count != right.Count)
        return left.Count > right.Count;
    // DOCS: при равной частоте меньший ключ даёт детерминированный порядок.
    return left.Key < right.Key;
}

static void
_sc_ai_fast_heap_swap(ScAiFastHeapItem* aHeap, i32 a, i32 b)
{
    ScAiFastHeapItem tmp = aHeap[a];
    aHeap[a] = aHeap[b];
    aHeap[b] = tmp;
}

static void
_sc_ai_fast_heap_sift_up(ScAiFastHeapItem* aHeap, i32 index)
{
    while (index > 0)
    {
        i32 parent = (index - 1) / 2;
        if (!_sc_ai_fast_heap_better(aHeap[index], aHeap[parent]))
            break;

        _sc_ai_fast_heap_swap(aHeap, index, parent);
        index = parent;
    }
}

static void
_sc_ai_fast_heap_sift_down(ScAiFastHeapItem* aHeap, i32 count, i32 index)
{
    for (;;)
    {
        i32 left = index * 2 + 1;
        i32 right = left + 1;
        i32 best = index;

        if (left < count && _sc_ai_fast_heap_better(aHeap[left], aHeap[best]))
            best = left;
        if (right < count && _sc_ai_fast_heap_better(aHeap[right], aHeap[best]))
            best = right;
        if (best == index)
            break;

        _sc_ai_fast_heap_swap(aHeap, index, best);
        index = best;
    }
}

static void
_sc_ai_fast_heap_push(ScAiFastState* pState, i32 count, i32 version, u64 key)
{
    ScAiFastHeapItem item = {
        .Count = count,
        .Version = version,
        .Key = key,
    };

    sc_list_add(pState->aHeap, item);
    _sc_ai_fast_heap_sift_up(pState->aHeap, (i32)(sc_list_count(pState->aHeap) - 1));
}

static ScAiFastHeapItem
_sc_ai_fast_heap_pop(ScAiFastState* pState)
{
    ScAiFastHeapItem item = {};
    i64 count = sc_list_count(pState->aHeap);
    if (count <= 0)
        return item;

    item = pState->aHeap[0];
    if (count == 1)
    {
        sc_list_header(pState->aHeap)->Count = 0;
        return item;
    }

    pState->aHeap[0] = pState->aHeap[count - 1];
    sc_list_header(pState->aHeap)->Count = count - 1;
    _sc_ai_fast_heap_sift_down(pState->aHeap, (i32)(count - 1), 0);
    return item;
}

static void
_sc_ai_fast_heap_rebuild(ScAiFastState* pState)
{
    if (pState->aHeap)
        sc_list_header(pState->aHeap)->Count = 0;

    i64 pairCount = sc_list_count(pState->aPairs);
    for (i64 i = 0; i < pairCount; ++i)
    {
        ScAiFastPair* pPair = &pState->aPairs[i];
        if (pPair->Count > 0)
            _sc_ai_fast_heap_push(pState, pPair->Count, pPair->Version, pPair->Key);
    }
}

static void
_sc_ai_fast_heap_maybe_rebuild(ScAiFastState* pState)
{
    if (sc_list_count(pState->aHeap) > 3 * sc_list_count(pState->aPairs) + 8192)
        _sc_ai_fast_heap_rebuild(pState);
}

/*
 Увеличивает/уменьшает частоту пары.
 occ - левый узел нового вхождения (для delta > 0).
 push - нужно ли сразу класть запись в heap (для начального прохода не нужно).
*/
static void
_sc_ai_fast_pair_add(ScAiFastState* pState, u64 key, i32 delta, i32 occ, i8 push)
{
    i32 pairIndex = delta > 0
        ? _sc_ai_fast_pair_get_or_add(pState, key)
        : _sc_ai_fast_hash_find(pState, key);

    if (pairIndex < 0)
        return;

    ScAiFastPair* pPair = &pState->aPairs[pairIndex];
    pPair->Count += delta;
    ++pPair->Version;

    if (delta > 0)
    {
        if (occ >= 0)
            sc_list_add(pPair->aOccurrences, occ);

        if (push)
            _sc_ai_fast_heap_push(pState, pPair->Count, pPair->Version, key);
    }
    else if (pPair->Count > 0)
    {
        // DOCS: после уменьшения частоты старая heap-запись устарела, но пара
        // всё ещё существует; кладём актуальную запись, иначе потеряем её.
        _sc_ai_fast_heap_push(pState, pPair->Count, pPair->Version, key);
    }
    else
    {
        // DOCS: нулевая пара больше не нужна; список позиций освобождаем.
        pPair->Count = 0;
        sc_list_free(pPair->aOccurrences);
        pPair->aOccurrences = NULL;
    }
}

static void
_sc_ai_fast_state_destroy(ScAiFastState* pState)
{
    if (pState->aPairs)
    {
        i64 pairCount = sc_list_count(pState->aPairs);
        for (i64 i = 0; i < pairCount; ++i)
            sc_list_free(pState->aPairs[i].aOccurrences);
        sc_list_free(pState->aPairs);
    }

    if (pState->aSlots)
        sc_memory_free(pState->aSlots);

    if (pState->aHeap)
        sc_list_free(pState->aHeap);

    if (pState->aNodes)
        sc_memory_free(pState->aNodes);

    *pState = (ScAiFastState){};
}

static void
_sc_ai_fast_vocab_destroy(ScBpeVocabItem* aVocab)
{
    if (!aVocab)
        return;

    sc_list_for_each(aVocab, pItem)
    {
        sc_string_destroy(pItem->pValue);
    }
    sc_list_free(aVocab);
}

ScAiBpe
sc_ai_bpe_new_fast(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};
    ScAiFastState state = {};
    u32* aTokenList = NULL;

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char byte = (char)i;
        ScBpeVocabItem item = _sc_ai_bpe_vocab_item_from_bytes(&byte, 1);
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < (i32)c_sc_ai_special_count; ++i)
    {
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)c_sc_ai_special_names[i]) };
        sc_list_add(aVocab, item);
    }

    aTokenList = tokens_array_new(cfg.pText, cfg.TextLength);
    i64 tokenCount = sc_list_count(aTokenList);

    if (tokenCount > 0x7FFFFFFF)
    {
        sc_log_erro("sc_ai_bpe_new_fast: corpus is too large (%lld tokens)\n", (long long)tokenCount);
        sc_list_free(aTokenList);
        _sc_ai_fast_vocab_destroy(aVocab);
        return scAiBpe;
    }

    i32 nodeCount = (i32)tokenCount;
    if (nodeCount > 0)
    {
        state.aNodes = sc_memory_allocate(sizeof(ScAiFastNode) * (u64)nodeCount);
        if (!state.aNodes)
        {
            sc_log_erro("sc_ai_bpe_new_fast: out of memory for %d nodes\n", nodeCount);
            sc_list_free(aTokenList);
            _sc_ai_fast_vocab_destroy(aVocab);
            return scAiBpe;
        }

        state.NodeCount = nodeCount;
        state.Head = 0;
        state.AliveCount = nodeCount;

        for (i32 i = 0; i < nodeCount; ++i)
        {
            state.aNodes[i] = (ScAiFastNode){
                .Token = aTokenList[i],
                .Prev = i - 1,
                .Next = (i + 1 < nodeCount) ? (i + 1) : -1,
            };
        }

        // DOCS: начальная частота пар. Спецтокены не участвуют в слияниях.
        for (i32 i = 0; i + 1 < nodeCount; ++i)
        {
            u32 a = state.aNodes[i].Token;
            u32 b = state.aNodes[i + 1].Token;
            if (_sc_ai_fast_is_special(a) || _sc_ai_fast_is_special(b))
                continue;

            u64 key = ((u64)a << 32) | b;
            _sc_ai_fast_pair_add(&state, key, +1, i, 0);
        }

        i64 pairCount = sc_list_count(state.aPairs);
        for (i64 i = 0; i < pairCount; ++i)
        {
            ScAiFastPair* pPair = &state.aPairs[i];
            if (pPair->Count > 0)
                _sc_ai_fast_heap_push(&state, pPair->Count, pPair->Version, pPair->Key);
        }
    }

    sc_list_free(aTokenList);

    for (i64 m = 0; m < cfg.MergesCount; ++m)
    {
        // DOCS: heap может накопить много устаревших записей; периодически чистим.
        _sc_ai_fast_heap_maybe_rebuild(&state);

        ScAiFastHeapItem best = {};
        i32 found = 0;

        while (sc_list_count(state.aHeap) > 0)
        {
            ScAiFastHeapItem item = _sc_ai_fast_heap_pop(&state);
            i32 pairIndex = _sc_ai_fast_hash_find(&state, item.Key);
            if (pairIndex < 0)
                continue;

            ScAiFastPair* pCandidate = &state.aPairs[pairIndex];
            if (pCandidate->Version != item.Version || pCandidate->Count != item.Count)
                continue;

            if (pCandidate->Count <= 1)
                break;

            best = item;
            found = 1;
            break;
        }

        if (!found)
            break;

        u64 pairKey = best.Key;
        u32 a = (u32)(pairKey >> 32);
        u32 b = (u32)pairKey;

        // DOCS: указатель на список берём до возможных вставок в aPairs.
        i32 bestIndex = _sc_ai_fast_hash_find(&state, pairKey);
        if (bestIndex < 0)
            break;

        ScAiFastPair* pBest = &state.aPairs[bestIndex];
        i32* aOccurrences = pBest->aOccurrences;
        i64 occurrenceCount = sc_list_count(aOccurrences);

        if (cfg.ShouldLogProgress)
        {
            ScBpeTokenPair pair = { .A = a, .B = b, .Count = best.Count };
            sc_bpe_token_pair_print(pair, (i32)m, (i32)cfg.MergesCount);
        }

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[a];
        ScBpeVocabItem itemB = aVocab[b];

        ScAiMerge merge = { .T0 = a, .T1 = b, .Tf = (u32)newId };
        sc_list_add(aMerges, merge);

        ScBpeVocabItem newVocabItem = _sc_ai_bpe_vocab_item_concat(itemA, itemB);
        sc_list_add(aVocab, newVocabItem);

        for (i64 oi = 0; oi < occurrenceCount; ++oi)
        {
            i32 left = aOccurrences[oi];
            if (left < 0 || left >= state.NodeCount)
                continue;

            ScAiFastNode* pLeft = &state.aNodes[left];
            if (pLeft->Next == -2 || pLeft->Token != a)
                continue;

            i32 right = pLeft->Next;
            if (right < 0 || right >= state.NodeCount)
                continue;

            ScAiFastNode* pRight = &state.aNodes[right];
            if (pRight->Next == -2 || pRight->Token != b)
                continue;

            i32 prev = pLeft->Prev;
            i32 next = pRight->Next;
            u32 prevToken = prev >= 0 ? state.aNodes[prev].Token : 0;
            u32 nextToken = next >= 0 ? state.aNodes[next].Token : 0;

            if (prev >= 0 && !_sc_ai_fast_is_special(prevToken))
            {
                u64 oldKey = ((u64)prevToken << 32) | a;
                // DOCS: при слиянии (A,A) соседняя пара тоже может быть (A,A).
                // Выбранную пару не трогаем: в конце она обнуляется целиком.
                if (oldKey != pairKey)
                    _sc_ai_fast_pair_add(&state, oldKey, -1, -1, 0);
            }

            if (next >= 0 && !_sc_ai_fast_is_special(nextToken))
            {
                u64 oldKey = ((u64)b << 32) | nextToken;
                if (oldKey != pairKey)
                    _sc_ai_fast_pair_add(&state, oldKey, -1, -1, 0);
            }

            pLeft->Token = (u32)newId;
            pLeft->Next = next;
            if (next >= 0)
                state.aNodes[next].Prev = left;

            pRight->Next = -2;
            pRight->Prev = -2;

            if (prev >= 0 && !_sc_ai_fast_is_special(prevToken))
            {
                u64 newKey = ((u64)prevToken << 32) | (u32)newId;
                _sc_ai_fast_pair_add(&state, newKey, +1, prev, 1);
            }

            if (next >= 0 && !_sc_ai_fast_is_special(nextToken))
            {
                u64 newKey = ((u64)(u32)newId << 32) | nextToken;
                _sc_ai_fast_pair_add(&state, newKey, +1, left, 1);
            }

            if (state.Head == right)
                state.Head = left;

            --state.AliveCount;

            // DOCS: одна выбранная пара может встречаться миллионы раз;
            // не даём heap разрастись внутри одного слияния.
            if ((oi & 4095) == 0)
                _sc_ai_fast_heap_maybe_rebuild(&state);
        }

        // DOCS: выбранная пара больше не существует; версия делает heap-записи
        // устаревшими, список позиций освобождаем.
        i32 pairIndex = _sc_ai_fast_hash_find(&state, pairKey);
        if (pairIndex >= 0)
        {
            ScAiFastPair* pPair = &state.aPairs[pairIndex];
            pPair->Count = 0;
            ++pPair->Version;
            sc_list_free(pPair->aOccurrences);
            pPair->aOccurrences = NULL;
        }
    }

    u32* aResultTokens = NULL;
    if (state.AliveCount > 0)
    {
        aResultTokens = sc_list_reserve(aResultTokens, state.AliveCount);
        sc_list_header(aResultTokens)->Count = 0;
    }

    i32 written = 0;
    for (i32 i = state.Head; i >= 0 && i < state.NodeCount && written < state.NodeCount; i = state.aNodes[i].Next)
    {
        if (state.aNodes[i].Next == -2)
            break;

        sc_list_add(aResultTokens, state.aNodes[i].Token);
        ++written;
    }

    if (written != state.AliveCount)
        sc_log_warn("sc_ai_bpe_new_fast: token list mismatch: written %d, alive %d\n",
            written, state.AliveCount);

    _sc_ai_fast_state_destroy(&state);

    scAiBpe.aTokens = aResultTokens;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;
    scAiBpe.OwnsTokens = 1;

    return scAiBpe;
}

ScAiBpe
sc_ai_bpe_load_from_disk(char* pFile)
{
    ScAiBpe bpe = {};

    if (!pFile)
    {
        sc_log_erro("sc_ai_bpe_load_from_disk: pFile is null!\n");
        return bpe;
    }

    // DOCS: Extension validation, only bpe files expected.
    i64 extIndex = sc_string_last_index_of(pFile, '.');
    if (extIndex < 0 || !sc_string_compare_ext(pFile + extIndex, ".bpe", 4))
    {
        sc_log_erro("Invalid extension for the file %s!\n", pFile);
        return bpe;
    }

    i64 fileSize = 0;
    char* pFileData = sc_file_read_ext(pFile, &fileSize);
    if (!pFileData)
    {
        sc_log_erro("Failed to read bpe file %s!\n", pFile);
        return bpe;
    }

    bpe = sc_ai_bpe_load_from_memory(pFileData, fileSize);
    sc_memory_free(pFileData);

    return bpe;
}

ScAiBpe
sc_ai_bpe_load_from_memory(char* pData, i64 dataSize)
{
    ScAiBpe bpe = {};

    if (!pData || dataSize <= 0)
        return bpe;

    i32 isV1 = dataSize >= 8 && sc_string_compare_ext(pData, "# bpe v1", 8);

    char* ptr = pData;
    char c = *ptr;

    while (c != '\0')
    {
        switch (c)
        {
        case '#':
        {
            if (sc_string_compare_ext(ptr, "# merges\n", 9))
            {
                ptr += 13;
                c = *ptr;

                while (!sc_char_is_integer(c))
                {
                    ++ptr;
                    c = *ptr;
                }

                ScAiMerge* aMerges = NULL;
                while (c != '`' && c != '\0')
                {
                    // DOCS: пропускаем переводы строк между мерджами.
                    ptr = sc_parse_skip_space(ptr);
                    c = *ptr;
                    if (c == '`' || c == '\0')
                        break;

                    // read line
                    ScParsedInt parsedInt0 = sc_parse_int_while_int(ptr);
                    if (!parsedInt0.pOutput)
                        break;
                    ptr = parsedInt0.pOutput;
                    ptr = sc_parse_skip_space(ptr);
                    // todo: create sc_parsed_utils

                    ScParsedInt parsedInt1 = sc_parse_int_while_int(ptr);
                    if (!parsedInt1.pOutput)
                        break;
                    ptr = parsedInt1.pOutput;
                    ptr = sc_parse_skip_space(ptr);

                    ScParsedInt parsedInt2 = sc_parse_int_while_int(ptr);
                    if (!parsedInt2.pOutput)
                        break;
                    ptr = parsedInt2.pOutput;

                    ScAiMerge merge = {
                        .T0 = parsedInt0.IntValue,
                        .T1 = parsedInt1.IntValue,
                        .Tf = parsedInt2.IntValue
                    };
                    sc_list_add(aMerges, merge);
                    c = *ptr;
                }

                bpe.aMerges = aMerges;
            }
            else if (sc_string_compare_ext(ptr, "# vocab-esc\n```", 15))
            {
                ptr += 15;

                if (*ptr == '\n')
                    ++ptr;
                c = *ptr;

                ScBpeVocabItem* aVocab = NULL;
                while (c != '\0')
                {
                    i64 newLineIndex = sc_string_index_of(ptr, '\n');
                    if (newLineIndex < 0)
                        break;

                    // DOCS: закрывающий маркер словаря.
                    if (newLineIndex == 3 && sc_string_compare_ext(ptr, "```", 3))
                        break;

                    ScBpeVocabItem vocabItem = _sc_ai_bpe_vocab_item_from_escaped_line(ptr, newLineIndex);
                    sc_list_add(aVocab, vocabItem);

                    ptr += newLineIndex + 1;
                    c = *ptr;
                }

                bpe.aVocab = aVocab;
            }
            else if (sc_string_compare_ext(ptr, "# vocab\n```", 11))
            {
                ptr += 11;

                // DOCS: пропускаем только перевод строки после открывающих ```,
                // а не все пробелы: пробел и пустая строка — тоже токены.
                if (*ptr == '\n')
                    ++ptr;
                c = *ptr;

                ScBpeVocabItem* aVocab = NULL;
                while (c != '\0')
                {
                    i64 newLineIndex = sc_string_index_of(ptr, '\n');
                    if (newLineIndex < 0)
                        break;

                    // DOCS: закрывающий маркер словаря.
                    if (newLineIndex == 3 && sc_string_compare_ext(ptr, "```", 3))
                        break;

                    ScBpeVocabItem vocabItem = {
                        .pValue = sc_string_new_ext(ptr, newLineIndex, newLineIndex)
                    };
                    sc_list_add(aVocab, vocabItem);

                    // DOCS: stopped at next string beginning
                    ptr += newLineIndex + 1;
                    c = *ptr;
                }

                bpe.aVocab = aVocab;
            }
            else
            {
                ++ptr;
                c = *ptr;
            }
            break;
        }

        default:
        {
            ++ptr;
            c = *ptr;
            break;
        }
        }
    }

    /*
     Строгая валидация v1: старые файлы без заголовка читаются как раньше,
     а новый формат обязан содержать все спецтокены и корректные ID мерджей.
     */
    if (isV1)
    {
        i32 isValid = bpe.aVocab != NULL && sc_list_count(bpe.aVocab) >= (i64)ScAiSpecialToken_Unk + c_sc_ai_special_count;

        if (isValid)
        {
            for (i64 s = 0; s < c_sc_ai_special_count; ++s)
            {
                ScBpeVocabItem item = bpe.aVocab[(i64)ScAiSpecialToken_Unk + s];
                if (!item.pValue || !sc_string_compare(item.pValue, (char*)c_sc_ai_special_names[s]))
                {
                    isValid = 0;
                    break;
                }
            }
        }

        if (isValid)
        {
            i64 vocabCount = sc_list_count(bpe.aVocab);
            sc_list_for_each(bpe.aMerges, pMerge)
            {
                if (pMerge->T0 >= (u32)vocabCount || pMerge->T1 >= (u32)vocabCount || pMerge->Tf >= (u32)vocabCount)
                {
                    isValid = 0;
                    break;
                }
            }
        }

        if (!isValid)
        {
            sc_log_erro("sc_ai_bpe_load_from_memory: invalid bpe v1 file!\n");
            sc_ai_bpe_destroy(&bpe);
            return (ScAiBpe) {};
        }
    }

    return bpe;
}

static void
_sc_ai_write_into_file_ext(const char* pOutFile, const char* pData, i64 dataLength)
{
    sc_file_append_string(pOutFile, (char*)pData, dataLength);
}
static void
_sc_ai_write_into_file(const char* pOutFile, const char* pData)
{
    _sc_ai_write_into_file_ext(pOutFile, (char*)pData, sc_string_get_length((char*)pData));
}

/*
 Пишет значение словаря в escaped-формате: любые байты, включая перевод
 строки и обратный слэш, остаются в одной строке и читаются без потерь.
 */
static void
_sc_ai_builder_append_text(char** ppBuilder, const char* pText)
{
    sc_builder_append_string(*ppBuilder, (char*)pText, sc_string_get_length((char*)pText));
}

static void
_sc_ai_builder_append_vocab_item_escaped(char** ppBuilder, const char* pValue, i64 length)
{
    char hexBuf[5] = {};

    for (i64 i = 0; i < length; ++i)
    {
        u8 c = (u8)pValue[i];
        switch (c)
        {
        case '\\':
            sc_builder_append_char(*ppBuilder, '\\');
            sc_builder_append_char(*ppBuilder, '\\');
            break;
        case '\n':
            sc_builder_append_char(*ppBuilder, '\\');
            sc_builder_append_char(*ppBuilder, 'n');
            break;
        case '\r':
            sc_builder_append_char(*ppBuilder, '\\');
            sc_builder_append_char(*ppBuilder, 'r');
            break;
        case '\t':
            sc_builder_append_char(*ppBuilder, '\\');
            sc_builder_append_char(*ppBuilder, 't');
            break;
        default:
            if (c < 0x20 || c == 0x7F || c == '`')
            {
                snprintf(hexBuf, 5, "\\x%02X", c);
                sc_builder_append_string(*ppBuilder, hexBuf, 4);
            }
            else
            {
                sc_builder_append_char(*ppBuilder, (char)c);
            }
            break;
        }
    }
}

static void
_sc_ai_write_vocab_item_escaped(const char* pOutFile, const char* pValue, i64 length)
{
    char* pBuilder = sc_builder_new();
    _sc_ai_builder_append_vocab_item_escaped(&pBuilder, pValue, length);
    _sc_ai_write_into_file_ext(pOutFile, pBuilder, sc_builder_count(pBuilder));
    sc_builder_destroy(pBuilder);
}

void
sc_ai_bpe_save_to_disk(ScAiBpeSaveToDiskConfig cfg)
{
    if (!cfg.pFilePath)
    {
        sc_log_warn("cfg is invalid!\n");
        return;
    }

    const char* pFilePath = cfg.pFilePath;
    ScProfiler scprf = {};
    char* pProcessingTime = "n/a";
    if (cfg.pProfiler)
    {
        scprf = *(ScProfiler*)cfg.pProfiler;
        // NOTE: sc_profiler_get_string не умеет обрабатывать нулевое время.
        pProcessingTime = scprf.Result != 0 ? sc_profiler_get_string(&scprf) : "0 ns";
    }

    i64 totalTextLength = cfg.TotalTextLength;
    ScAiBpe bpe = cfg.Bpe;
    i64 totalLengthCompressed = cfg.TotalTextLengthCompressed;
    f32 ratio = 0.0f;
    if (totalTextLength > 0)
        ratio = ((f32)totalLengthCompressed / (f32)totalTextLength) * 100.0f;

    i8 c_should_add_text = cfg.ShouldAddText;
    i8 c_should_add_tokens = cfg.ShouldAddTokens;

    // NOTE: функции ниже пишут в режиме append, поэтому старый файл нужно
    // сначала очистить, иначе данные от предыдущего запуска останутся.
    sc_file_write(pFilePath, "", 0);

    _sc_ai_write_into_file(pFilePath, "# bpe v1\n# specials 256 257 258 259 260 261 262 263 264\n");

    char sbuf[256] = {};
    snprintf(sbuf, 256, "# processing-time: %s\n# compression: %lld/%lld (%0.1f%%)\n", pProcessingTime, (i64)totalLengthCompressed, (i64)totalTextLength, 100.0f - ratio);
    _sc_ai_write_into_file(pFilePath, sbuf);

    snprintf(sbuf, 256, "# corpus-size %lld\n# vocab-size %lld\n# merges-size %lld\n# tokens-size %lld\n\n", (i64)totalTextLength, (i64)sc_list_count(bpe.aVocab), (i64)sc_list_count(bpe.aMerges), (i64)totalLengthCompressed);
    _sc_ai_write_into_file(pFilePath, sbuf);

    _sc_ai_write_into_file(pFilePath, "# merges\n```\n");
    sc_list_for_each(bpe.aMerges, pMerge)
    {
        char mbuf[256] = {};
        snprintf(mbuf, 256, "%d %d %d\n", pMerge->T0, pMerge->T1, pMerge->Tf);
        _sc_ai_write_into_file(pFilePath, mbuf);
    }
    _sc_ai_write_into_file(pFilePath, "```\n# end merges\n");

    _sc_ai_write_into_file(pFilePath, "# vocab-esc\n```\n");
    sc_list_for_each(bpe.aVocab, pVocab)
    {
        _sc_ai_write_vocab_item_escaped(pFilePath, pVocab->pValue, sc_string_get_length(pVocab->pValue));
        _sc_ai_write_into_file(pFilePath, "\n");
    }
    _sc_ai_write_into_file(pFilePath, "```\n# end vocab\n");

    if (c_should_add_text && cfg.pText)
    {
        _sc_ai_write_into_file(pFilePath, "# text\n```\n");
        _sc_ai_write_into_file_ext(pFilePath, cfg.pText, totalTextLength);
        _sc_ai_write_into_file(pFilePath, "\n```\n# end text\n");
    }

    if (c_should_add_tokens)
    {
        _sc_ai_write_into_file(pFilePath, "# tokens\n```\n");
        sc_list_for_each(bpe.aTokens, pTokens)
        {
            i32 token = *pTokens;
            if (token != -1337)
            {
                if (token == 259)
                {
                    _sc_ai_write_into_file(pFilePath, "[EOS]\n");
                }
                else
                {
                    char mbuf[256] = {};
                    snprintf(mbuf, 256, "[%d]", token);
                    _sc_ai_write_into_file(pFilePath, mbuf);
                }
            }
        }
        _sc_ai_write_into_file(pFilePath, "\n```\n# end tokens\n");
    }
}

char*
sc_ai_bpe_save_to_memory(ScAiBpe bpe, i64* pLength)
{
    char* pBuilder = sc_builder_new();

    _sc_ai_builder_append_text(&pBuilder, "# bpe v1\n# specials 256 257 258 259 260 261 262 263 264\n");
    sc_builder_append_format(pBuilder, "# vocab-size %lld\n# merges-size %lld\n\n",
        (long long)sc_list_count(bpe.aVocab), (long long)sc_list_count(bpe.aMerges));

    _sc_ai_builder_append_text(&pBuilder, "# merges\n```\n");
    sc_list_for_each(bpe.aMerges, pMerge)
    {
        sc_builder_append_format(pBuilder, "%d %d %d\n", pMerge->T0, pMerge->T1, pMerge->Tf);
    }
    _sc_ai_builder_append_text(&pBuilder, "```\n# end merges\n# vocab-esc\n```\n");

    sc_list_for_each(bpe.aVocab, pVocab)
    {
        _sc_ai_builder_append_vocab_item_escaped(&pBuilder, pVocab->pValue, sc_string_get_length(pVocab->pValue));
        sc_builder_append_char(pBuilder, '\n');
    }

    _sc_ai_builder_append_text(&pBuilder, "```\n# end vocab\n");

    i64 length = sc_builder_count(pBuilder);
    char* pData = sc_string_new_ext_ext_r(pBuilder, length, length);
    sc_builder_destroy(pBuilder);

    if (pLength)
        *pLength = length;

    return pData;
}

ScAiBpe
sc_ai_bpe_new2(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;
    u64* aPairKeys = NULL;

    struct
    {
        i64 Key;
        ScBpeTokenPair Value;
    }* hPairs = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char byte = (char)i;
        ScBpeVocabItem item = _sc_ai_bpe_vocab_item_from_bytes(&byte, 1);
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < (i32)c_sc_ai_special_count; ++i)
    {
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)c_sc_ai_special_names[i]) };
        sc_list_add(aVocab, item);
    }

    i64 copyCount = cfg.TextLength;
    i64 mergesCount = cfg.MergesCount;
    g.pSt0 = tokens_array_new(cfg.pText, copyCount);
    g.pSt1 = sc_list_reserve(g.pSt1, copyCount);
    g.pActive = g.pSt0;

    /* DOCS:
        Optimize plan:
        - use hash table for Pairs

        */

    //
    // tokens_find_max_pair()
    //

    i64 vocabCount = sc_list_count(aVocab);

    {
        u32* aTokens = g.pActive;

        i64 fptokensCount = sc_list_count(aTokens) - 1;

        for (i64 i = 0; i < fptokensCount; ++i)
        {
            // DOCS: ignore shit so we dont have to reallocate
            u32 c = aTokens[i];
            if (c >= ScAiSpecialToken_Unk && c <= ScAiSpecialToken_Sit)
                continue;

            u32 nc = aTokens[i + 1];
            if (nc >= ScAiSpecialToken_Unk && nc <= ScAiSpecialToken_Sit)
                continue;

            if (c >= vocabCount || nc >= vocabCount)
                continue;

            u64 ab = (to_u64(c) << 32) | nc;
            i32 isKeyExist = sc_dict_i_contains(hPairs, ab);

            if (isKeyExist)
            {
                // DOCS: Увеличиваем счётчик пары.
                i64 ind = sc_dict_index(hPairs);
                hPairs[ind].Value.Count = ++hPairs[ind].Value.Count;
            }
            else
            {
                ScBpeTokenPair pair = {
                    .A = c,
                    .B = nc,
                    .Count = 1,
                };
                sc_dict_i_add(hPairs, ab, pair);
                sc_list_add(aPairKeys, ab);
            }
        }

        // sc_dict_clear(hPairs);
        // sc_list_clear(aPairKeys);
    }

    for (i32 m = 0; m < mergesCount; ++m)
    {
        i64 pairKeysCount = sc_list_count(aPairKeys);
        if (cfg.ShouldLogProgress)
            sc_log_info("Pairs count: %d\n", pairKeysCount);
        if (pairKeysCount == 0)
            break;

        u64 pairKey = aPairKeys[0];
        ScBpeTokenPair maxPair = sc_dict_i_get(hPairs, pairKey);
        for (i64 p = 1; p < pairKeysCount; ++p)
        {
            pairKey = aPairKeys[p];
            ScBpeTokenPair pair = sc_dict_i_get(hPairs, pairKey);
            if (pair.Count > maxPair.Count)
            {
                maxPair = pair;
            }
        }

        if (maxPair.Count <= 1)
        {
            sc_log_warn("прерывание: цикла, дошли до (ручки) maxPair.Count <= 1\n");
            break;
        }
        if (cfg.ShouldLogProgress)
            sc_bpe_token_pair_print(maxPair, m, mergesCount);

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[maxPair.A];
        ScBpeVocabItem itemB = aVocab[maxPair.B];

        ScAiMerge merge = { .T0 = maxPair.A, .T1 = maxPair.B, .Tf = newId };
        sc_list_add(aMerges, merge);

        ScBpeVocabItem newVocabItem = _sc_ai_bpe_vocab_item_concat(itemA, itemB);

        sc_list_add(aVocab, newVocabItem);

        // DOCS: new replacement
        u32* aCopyFrom = NULL;
        u32* aNewTokens = NULL;
        if (g.pActive == g.pSt0)
        {
            aCopyFrom = g.pSt0;
            aNewTokens = g.pSt1;
            g.pActive = g.pSt1;
        }
        else
        {
            aCopyFrom = g.pSt1;
            aNewTokens = g.pSt0;
            g.pActive = g.pSt0;
        }

        i64 copyTokensCount = sc_list_count(aCopyFrom);
        sc_list_header(aNewTokens)->Count = 0;

        for (i64 t = 0; t < copyTokensCount; ++t)
        {
            u32 token = aCopyFrom[t];
            if (t + 1 < copyTokensCount && token == maxPair.A && aCopyFrom[t + 1] == maxPair.B)
            {
                sc_list_add(aNewTokens, newId);
                ++t;
            }
            else
            {
                sc_list_add(aNewTokens, token);
            }
        }
    }

    scAiBpe.aTokens = g.pActive;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;

    return scAiBpe;
}

/*
 Освобождает BPE. aVocab/aMerges освобождаются всегда, а aTokens - только
 если тренер передал владение (OwnsTokens). Старый sc_ai_bpe_new отдаёт
 буфер из общего g, который переиспользуется следующим вызовом.
 */
void
sc_ai_bpe_destroy(ScAiBpe* pBpe)
{
    if (!pBpe)
        return;

    if (pBpe->aVocab)
    {
        sc_list_for_each(pBpe->aVocab, pItem)
        {
            sc_string_destroy(pItem->pValue);
        }
        sc_list_free(pBpe->aVocab);
    }

    sc_list_free(pBpe->aMerges);

    // NOTE: старый тренер отдаёт aTokens из общего g.pSt0/g.pSt1, fast-тренер
    // выделяет отдельный список. Освобождаем только собственный буфер.
    if (pBpe->OwnsTokens)
        sc_list_free(pBpe->aTokens);

    pBpe->aTokens = NULL;
    pBpe->OwnsTokens = 0;

    *pBpe = (ScAiBpe) {};
}

void
sc_bpe_token_pair_print(ScBpeTokenPair pair, i32 done, i32 total)
{
    // char buf[3] = { pair.A, pair.B };
    // sc_log_info("Pair: '%s' -> %d\n", buf, pair.Count);

    i32 ind = 0;
    char buf[1024] = {};

    if ((pair.A >= 32 && pair.A <= 126) || (pair.A >= 0xC0 && pair.A <= 0xFF))
    {
        buf[ind] = (char)pair.A;
        ++ind;
    }
    else
    {
        ind += snprintf(buf, 8, "\\x%02X", pair.A);
    }

    if ((pair.B >= 32 && pair.B <= 126) || (pair.B >= 0xC0 && pair.B <= 0xFF))
    {
        buf[ind] = (char)pair.B;
        ++ind;
    }

    else
    {
        snprintf(buf + ind, 8, "\\x%02X", pair.B);
    }

    ++done;
    char tbuf[32] = {};
    snprintf(tbuf, 32, "%0.1f", done / (f32)total * 100);
    printf("Pair: '%s' -> %d (%d/%d %s)\n", buf, pair.Count, done, total, tbuf);
}

#if 1 // example stuff

/*
 ###################################
 ###################################
 sc_ai_bpe: encode / decode
 ###################################
 ###################################
*/

i32*
sc_ai_bpe_tokenize(ScAiTokenizeConfig cfg)
{
    if (!cfg.pText || cfg.TextLength <= 0)
        return NULL;

    u32* aTokens = tokens_array_new(cfg.pText, cfg.TextLength);
    if (!aTokens)
        return NULL;

    i64 mergeCount = sc_list_count(cfg.Bpe.aMerges);
    for (i64 m = 0; m < mergeCount; ++m)
    {
        ScAiMerge merge = cfg.Bpe.aMerges[m];
        i64 tokenCount = sc_list_count(aTokens);
        if (tokenCount < 2)
            break;

        // DOCS: слияние in-place: write <= read, поэтому ещё не прочитанные
        // токены не затираются, а новый буфер на каждый merge не нужен.
        i64 write = 0;
        for (i64 read = 0; read < tokenCount;)
        {
            u32 token = aTokens[read];
            if (read + 1 < tokenCount && token == merge.T0 && aTokens[read + 1] == merge.T1)
            {
                aTokens[write] = merge.Tf;
                ++write;
                read += 2;
            }
            else
            {
                aTokens[write] = token;
                ++write;
                ++read;
            }
        }

        sc_list_header(aTokens)->Count = write;
    }

    return (i32*)aTokens;
}

char*
sc_ai_bpe_decode(ScAiBpe bpe, i32* aTokens)
{
    char* pBuilder = sc_builder_new();
    i64 vocabCount = sc_list_count(bpe.aVocab);
    i64 tokenCount = sc_list_count(aTokens);

    for (i64 i = 0; i < tokenCount; ++i)
    {
        u32 token = (u32)aTokens[i];
        if (token < (u32)vocabCount)
        {
            ScBpeVocabItem item = bpe.aVocab[token];
            sc_builder_append_string(pBuilder, item.pValue, sc_string_get_length(item.pValue));
        }
    }

    i64 length = sc_builder_count(pBuilder);
    char* pText = sc_string_new_ext_ext_r(pBuilder, length, length);

    sc_builder_destroy(pBuilder);
    return pText;
}

/*
 ###################################
 ###################################
 small model: math helpers
 ###################################
 ###################################
*/

static u64
_sc_ai_rng_next(u64* pState)
{
    u64 x = *pState;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *pState = x;
    return x;
}

static f32
_sc_ai_rng_f32(u64* pState)
{
    u64 value = _sc_ai_rng_next(pState) >> 40;
    return (f32)value / 16777216.0f;
}

static void
_sc_ai_fill_zero(f32* pData, i64 count)
{
    for (i64 i = 0; i < count; ++i)
        pData[i] = 0.0f;
}

static ScAiParam
_sc_ai_param_new(i64 count, f32 initScale, u64* pState)
{
    ScAiParam param = {};
    param.Count = count;

    if (count <= 0)
        return param;

    param.pData = sc_memory_allocate(sizeof(f32) * count);
    param.pGrad = sc_memory_allocate(sizeof(f32) * count);
    param.pM = sc_memory_allocate(sizeof(f32) * count);
    param.pV = sc_memory_allocate(sizeof(f32) * count);

    for (i64 i = 0; i < count; ++i)
    {
        param.pData[i] = (_sc_ai_rng_f32(pState) * 2.0f - 1.0f) * initScale;
        param.pGrad[i] = 0.0f;
        param.pM[i] = 0.0f;
        param.pV[i] = 0.0f;
    }

    return param;
}

static void
_sc_ai_param_destroy(ScAiParam* pParam)
{
    if (!pParam)
        return;

    sc_memory_free(pParam->pData);
    sc_memory_free(pParam->pGrad);
    sc_memory_free(pParam->pM);
    sc_memory_free(pParam->pV);

    pParam->pData = NULL;
    pParam->pGrad = NULL;
    pParam->pM = NULL;
    pParam->pV = NULL;
    pParam->Count = 0;
}

static void
_sc_ai_param_zero_grad(ScAiParam* pParam)
{
    if (!pParam || !pParam->pGrad)
        return;

    _sc_ai_fill_zero(pParam->pGrad, pParam->Count);
}

static void
_sc_ai_param_adam(ScAiParam* pParam, f32 learningRate, i32 step, i32 batchCount)
{
    if (!pParam || !pParam->pData || pParam->Count <= 0)
        return;

    const f32 beta1 = 0.9f;
    const f32 beta2 = 0.999f;
    const f32 epsilon = 1e-8f;
    f32 scale = batchCount > 0 ? 1.0f / (f32)batchCount : 1.0f;
    f32 beta1Pow = 1.0f - powf(beta1, (f32)step);
    f32 beta2Pow = 1.0f - powf(beta2, (f32)step);

    for (i64 i = 0; i < pParam->Count; ++i)
    {
        f32 grad = pParam->pGrad[i] * scale;

        pParam->pM[i] = beta1 * pParam->pM[i] + (1.0f - beta1) * grad;
        pParam->pV[i] = beta2 * pParam->pV[i] + (1.0f - beta2) * grad * grad;

        f32 mHat = pParam->pM[i] / beta1Pow;
        f32 vHat = pParam->pV[i] / beta2Pow;

        pParam->pData[i] -= learningRate * mHat / (sqrtf(vHat) + epsilon);
        pParam->pGrad[i] = 0.0f;
    }
}

static void
_sc_ai_softmax(f32* pLogits, f32* pProbs, i32 count, f32 temperature)
{
    if (count <= 0)
        return;

    if (temperature <= 1e-5f)
        temperature = 1e-5f;

    f32 maxLogit = pLogits[0];
    for (i32 i = 1; i < count; ++i)
    {
        if (pLogits[i] > maxLogit)
            maxLogit = pLogits[i];
    }

    f32 sum = 0.0f;
    for (i32 i = 0; i < count; ++i)
    {
        f32 value = expf((pLogits[i] - maxLogit) / temperature);
        pProbs[i] = value;
        sum += value;
    }

    if (sum <= 0.0f)
        return;

    for (i32 i = 0; i < count; ++i)
        pProbs[i] /= sum;
}

static u32
_sc_ai_model_safe_token(ScAiModel* pModel, u32 token)
{
    if (token >= (u32)pModel->VocabCount)
        return (u32)ScAiSpecialToken_Unk;
    return token;
}

static void
_sc_ai_model_zero_grad(ScAiModel* pModel)
{
    _sc_ai_param_zero_grad(&pModel->TokenEmbedding);
    _sc_ai_param_zero_grad(&pModel->PositionEmbedding);
    _sc_ai_param_zero_grad(&pModel->HiddenWeights);
    _sc_ai_param_zero_grad(&pModel->HiddenBias);
    _sc_ai_param_zero_grad(&pModel->OutputWeights);
    _sc_ai_param_zero_grad(&pModel->OutputBias);
}

/*
 ###################################
 ###################################
 small model: forward / backward
 ###################################
 ###################################
*/

static void
_sc_ai_model_forward(ScAiModel* pModel, u32* aContext)
{
    i32 contextLength = pModel->ContextLength;
    i32 embeddingDim = pModel->EmbeddingDim;
    i32 hiddenDim = pModel->HiddenDim;
    i32 vocabCount = pModel->VocabCount;
    i32 inputSize = contextLength * embeddingDim;

    for (i32 i = 0; i < contextLength; ++i)
    {
        u32 token = _sc_ai_model_safe_token(pModel, aContext[i]);
        for (i32 d = 0; d < embeddingDim; ++d)
        {
            i64 index = i * embeddingDim + d;
            pModel->aContextX[index] = pModel->TokenEmbedding.pData[(i64)token * embeddingDim + d] + pModel->PositionEmbedding.pData[index];
        }
    }

    for (i32 h = 0; h < hiddenDim; ++h)
    {
        f32 sum = pModel->HiddenBias.pData[h];
        for (i32 j = 0; j < inputSize; ++j)
            sum += pModel->aContextX[j] * pModel->HiddenWeights.pData[(i64)j * hiddenDim + h];

        pModel->aHidden[h] = tanhf(sum);
    }

    for (i32 v = 0; v < vocabCount; ++v)
    {
        f32 sum = pModel->OutputBias.pData[v];
        for (i32 h = 0; h < hiddenDim; ++h)
            sum += pModel->aHidden[h] * pModel->OutputWeights.pData[(i64)h * vocabCount + v];

        pModel->aLogits[v] = sum;
    }

    _sc_ai_softmax(pModel->aLogits, pModel->aProbs, vocabCount, 1.0f);
}

static f32
_sc_ai_model_backward(ScAiModel* pModel, u32* aContext, u32 target)
{
    i32 contextLength = pModel->ContextLength;
    i32 embeddingDim = pModel->EmbeddingDim;
    i32 hiddenDim = pModel->HiddenDim;
    i32 vocabCount = pModel->VocabCount;
    i32 inputSize = contextLength * embeddingDim;

    target = _sc_ai_model_safe_token(pModel, target);

    f32 loss = -logf(pModel->aProbs[target] + 1e-8f);

    // NOTE: logits уже не нужны, используем буфер под dLogits.
    f32* aDLogits = pModel->aLogits;
    for (i32 v = 0; v < vocabCount; ++v)
        aDLogits[v] = pModel->aProbs[v];
    aDLogits[target] -= 1.0f;

    _sc_ai_fill_zero(pModel->aHiddenGrad, hiddenDim);

    for (i32 h = 0; h < hiddenDim; ++h)
    {
        for (i32 v = 0; v < vocabCount; ++v)
        {
            pModel->OutputWeights.pGrad[(i64)h * vocabCount + v] += pModel->aHidden[h] * aDLogits[v];
            pModel->aHiddenGrad[h] += pModel->OutputWeights.pData[(i64)h * vocabCount + v] * aDLogits[v];
        }
    }

    for (i32 v = 0; v < vocabCount; ++v)
        pModel->OutputBias.pGrad[v] += aDLogits[v];

    for (i32 h = 0; h < hiddenDim; ++h)
        pModel->aPreActivationGrad[h] = pModel->aHiddenGrad[h] * (1.0f - pModel->aHidden[h] * pModel->aHidden[h]);

    _sc_ai_fill_zero(pModel->aContextGrad, inputSize);

    for (i32 j = 0; j < inputSize; ++j)
    {
        for (i32 h = 0; h < hiddenDim; ++h)
        {
            pModel->HiddenWeights.pGrad[(i64)j * hiddenDim + h] += pModel->aContextX[j] * pModel->aPreActivationGrad[h];
            pModel->aContextGrad[j] += pModel->HiddenWeights.pData[(i64)j * hiddenDim + h] * pModel->aPreActivationGrad[h];
        }
    }

    for (i32 h = 0; h < hiddenDim; ++h)
        pModel->HiddenBias.pGrad[h] += pModel->aPreActivationGrad[h];

    for (i32 i = 0; i < contextLength; ++i)
    {
        u32 token = _sc_ai_model_safe_token(pModel, aContext[i]);
        for (i32 d = 0; d < embeddingDim; ++d)
        {
            i64 index = i * embeddingDim + d;
            f32 grad = pModel->aContextGrad[index];

            pModel->TokenEmbedding.pGrad[(i64)token * embeddingDim + d] += grad;
            pModel->PositionEmbedding.pGrad[index] += grad;
        }
    }

    return loss;
}

static void
_sc_ai_model_adam_step(ScAiModel* pModel, f32 learningRate, i32 step, i32 batchCount)
{
    _sc_ai_param_adam(&pModel->TokenEmbedding, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->PositionEmbedding, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->HiddenWeights, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->HiddenBias, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->OutputWeights, learningRate, step, batchCount);
    _sc_ai_param_adam(&pModel->OutputBias, learningRate, step, batchCount);
}

static u32
_sc_ai_sample(ScAiModel* pModel, f32 temperature, i32 topK, u64* pState)
{
    i32 vocabCount = pModel->VocabCount;

    if (temperature <= 1e-5f)
    {
        i32 best = 0;
        for (i32 v = 1; v < vocabCount; ++v)
        {
            if (pModel->aLogits[v] > pModel->aLogits[best])
                best = v;
        }
        return (u32)best;
    }

    _sc_ai_softmax(pModel->aLogits, pModel->aProbs, vocabCount, temperature);

    if (topK > vocabCount)
        topK = vocabCount;
    if (topK < 1)
        topK = 1;

    i32* aSelected = sc_memory_allocate(sizeof(i32) * topK);
    for (i32 k = 0; k < topK; ++k)
    {
        i32 best = -1;
        f32 bestProbability = -1.0f;

        for (i32 v = 0; v < vocabCount; ++v)
        {
            i32 isUsed = 0;
            for (i32 j = 0; j < k; ++j)
            {
                if (aSelected[j] == v)
                {
                    isUsed = 1;
                    break;
                }
            }

            if (!isUsed && pModel->aProbs[v] > bestProbability)
            {
                bestProbability = pModel->aProbs[v];
                best = v;
            }
        }

        aSelected[k] = best >= 0 ? best : 0;
    }

    f32 sum = 0.0f;
    for (i32 k = 0; k < topK; ++k)
        sum += pModel->aProbs[aSelected[k]];

    f32 value = _sc_ai_rng_f32(pState) * sum;
    f32 accumulated = 0.0f;
    u32 result = (u32)aSelected[topK - 1];

    for (i32 k = 0; k < topK; ++k)
    {
        accumulated += pModel->aProbs[aSelected[k]];
        if (value <= accumulated)
        {
            result = (u32)aSelected[k];
            break;
        }
    }

    sc_memory_free(aSelected);
    return result;
}

/*
 ###################################
 ###################################
 small model: public API
 ###################################
 ###################################
*/

ScAiModel
sc_ai_model_new(ScAiModelConfig cfg)
{
    ScAiModel model = {};

    model.VocabCount = cfg.VocabCount > (i32)ScAiSpecialToken_Sep ? cfg.VocabCount : (i32)ScAiSpecialToken_Sep + 1;
    model.ContextLength = cfg.ContextLength > 0 ? cfg.ContextLength : 8;
    model.EmbeddingDim = cfg.EmbeddingDim > 0 ? cfg.EmbeddingDim : 16;
    model.HiddenDim = cfg.HiddenDim > 0 ? cfg.HiddenDim : 32;

    u64 seed = cfg.Seed ? cfg.Seed : 0x9e3779b97f4a7c15ULL;

    i32 contextLength = model.ContextLength;
    i32 embeddingDim = model.EmbeddingDim;
    i32 hiddenDim = model.HiddenDim;
    i32 vocabCount = model.VocabCount;
    i32 inputSize = contextLength * embeddingDim;

    f32 hiddenScale = 1.0f / sqrtf((f32)inputSize);
    f32 outputScale = 1.0f / sqrtf((f32)hiddenDim);

    model.TokenEmbedding = _sc_ai_param_new((i64)vocabCount * embeddingDim, 0.1f, &seed);
    model.PositionEmbedding = _sc_ai_param_new((i64)contextLength * embeddingDim, 0.1f, &seed);
    model.HiddenWeights = _sc_ai_param_new((i64)inputSize * hiddenDim, hiddenScale, &seed);
    model.HiddenBias = _sc_ai_param_new(hiddenDim, 0.0f, &seed);
    model.OutputWeights = _sc_ai_param_new((i64)hiddenDim * vocabCount, outputScale, &seed);
    model.OutputBias = _sc_ai_param_new(vocabCount, 0.0f, &seed);

    model.aContextX = sc_memory_allocate(sizeof(f32) * inputSize);
    model.aHidden = sc_memory_allocate(sizeof(f32) * hiddenDim);
    model.aLogits = sc_memory_allocate(sizeof(f32) * vocabCount);
    model.aProbs = sc_memory_allocate(sizeof(f32) * vocabCount);
    model.aHiddenGrad = sc_memory_allocate(sizeof(f32) * hiddenDim);
    model.aPreActivationGrad = sc_memory_allocate(sizeof(f32) * hiddenDim);
    model.aContextGrad = sc_memory_allocate(sizeof(f32) * inputSize);

    return model;
}

void
sc_ai_model_destroy(ScAiModel* pModel)
{
    if (!pModel)
        return;

    _sc_ai_param_destroy(&pModel->TokenEmbedding);
    _sc_ai_param_destroy(&pModel->PositionEmbedding);
    _sc_ai_param_destroy(&pModel->HiddenWeights);
    _sc_ai_param_destroy(&pModel->HiddenBias);
    _sc_ai_param_destroy(&pModel->OutputWeights);
    _sc_ai_param_destroy(&pModel->OutputBias);

    sc_memory_free(pModel->aContextX);
    sc_memory_free(pModel->aHidden);
    sc_memory_free(pModel->aLogits);
    sc_memory_free(pModel->aProbs);
    sc_memory_free(pModel->aHiddenGrad);
    sc_memory_free(pModel->aPreActivationGrad);
    sc_memory_free(pModel->aContextGrad);

    *pModel = (ScAiModel) {};
}

static u32*
_sc_ai_build_sequence(ScAiBpe bpe, char* pInput, char* pOutput)
{
    u32* aSequence = NULL;

    sc_list_add(aSequence, (u32)ScAiSpecialToken_Bos);

    ScAiTokenizeConfig inputConfig = {
        .pText = pInput,
        .TextLength = pInput ? sc_string_get_length(pInput) : 0,
        .Bpe = bpe,
    };
    i32* aInputTokens = sc_ai_bpe_tokenize(inputConfig);
    if (aInputTokens)
    {
        for (i64 i = 0; i < sc_list_count(aInputTokens); ++i)
            sc_list_add(aSequence, (u32)aInputTokens[i]);
        sc_list_free(aInputTokens);
    }

    sc_list_add(aSequence, (u32)ScAiSpecialToken_Sep);

    ScAiTokenizeConfig outputConfig = {
        .pText = pOutput,
        .TextLength = pOutput ? sc_string_get_length(pOutput) : 0,
        .Bpe = bpe,
    };
    i32* aOutputTokens = sc_ai_bpe_tokenize(outputConfig);
    if (aOutputTokens)
    {
        for (i64 i = 0; i < sc_list_count(aOutputTokens); ++i)
            sc_list_add(aSequence, (u32)aOutputTokens[i]);
        sc_list_free(aOutputTokens);
    }

    sc_list_add(aSequence, (u32)ScAiSpecialToken_Eos);

    return aSequence;
}

static void
_sc_ai_fill_context(u32* aContext, u32* aSequence, i64 endIndex, i32 contextLength)
{
    for (i32 i = 0; i < contextLength; ++i)
    {
        i64 sourceIndex = endIndex - (contextLength - 1) + i;
        aContext[i] = sourceIndex >= 0 ? aSequence[sourceIndex] : (u32)ScAiSpecialToken_Pad;
    }
}

void
sc_ai_model_train(ScAiModel* pModel, ScAiBpe bpe, ScAiDialogDataset dataset, ScAiTrainConfig cfg)
{
    if (!pModel || !dataset.aPairs || dataset.Count <= 0)
        return;

    i32 steps = cfg.Steps > 0 ? cfg.Steps : 1;
    i32 batchSize = cfg.BatchSize > 0 ? cfg.BatchSize : 1;
    f32 learningRate = cfg.LearningRate > 0.0f ? cfg.LearningRate : 0.01f;
    i32 contextLength = pModel->ContextLength;

    u32* aContext = sc_memory_allocate(sizeof(u32) * contextLength);
    i32 adamStep = 0;
    i32 batchCount = 0;
    f64 lossSum = 0.0;
    i32 lossCount = 0;

    _sc_ai_model_zero_grad(pModel);

    for (i32 step = 0; step < steps; ++step)
    {
        for (i64 pairIndex = 0; pairIndex < dataset.Count; ++pairIndex)
        {
            ScAiDialogPair pair = dataset.aPairs[pairIndex];
            u32* aSequence = _sc_ai_build_sequence(bpe, pair.pInput, pair.pOutput);
            i64 sequenceCount = sc_list_count(aSequence);

            for (i64 t = 0; t + 1 < sequenceCount; ++t)
            {
                _sc_ai_fill_context(aContext, aSequence, t, contextLength);
                _sc_ai_model_forward(pModel, aContext);

                f32 loss = _sc_ai_model_backward(pModel, aContext, aSequence[t + 1]);
                lossSum += loss;
                ++lossCount;
                ++batchCount;

                if (batchCount >= batchSize)
                {
                    ++adamStep;
                    _sc_ai_model_adam_step(pModel, learningRate, adamStep, batchCount);
                    batchCount = 0;
                }
            }

            sc_list_free(aSequence);
        }

        if (cfg.LogEvery > 0 && (step + 1) % cfg.LogEvery == 0 && lossCount > 0)
        {
            sc_log_info("ai train: step %d/%d loss %.4f\n", step + 1, steps, (f32)(lossSum / lossCount));
            lossSum = 0.0;
            lossCount = 0;
        }
    }

    if (batchCount > 0)
    {
        ++adamStep;
        _sc_ai_model_adam_step(pModel, learningRate, adamStep, batchCount);
    }

    sc_memory_free(aContext);
}

char*
sc_ai_model_generate(ScAiModel* pModel, ScAiBpe bpe, char* pMessage, ScAiGenerateConfig cfg)
{
    if (!pModel || !pMessage)
        return sc_string_new_ext_ext_r("", 0, 0);

    i32 contextLength = pModel->ContextLength;
    i32 maxTokens = cfg.MaxTokens > 0 ? cfg.MaxTokens : 64;
    f32 temperature = cfg.Temperature;
    i32 topK = cfg.TopK > 0 ? cfg.TopK : 8;
    u64 rngState = cfg.Seed ? cfg.Seed : 0x9e3779b97f4a7c15ULL;

    u32* aPrompt = NULL;
    sc_list_add(aPrompt, (u32)ScAiSpecialToken_Bos);

    ScAiTokenizeConfig tokenizeConfig = {
        .pText = pMessage,
        .TextLength = sc_string_get_length(pMessage),
        .Bpe = bpe,
    };
    i32* aMessageTokens = sc_ai_bpe_tokenize(tokenizeConfig);
    if (aMessageTokens)
    {
        for (i64 i = 0; i < sc_list_count(aMessageTokens); ++i)
            sc_list_add(aPrompt, (u32)aMessageTokens[i]);
        sc_list_free(aMessageTokens);
    }

    sc_list_add(aPrompt, (u32)ScAiSpecialToken_Sep);

    i32* aResult = NULL;
    u32* aContext = sc_memory_allocate(sizeof(u32) * contextLength);

    for (i32 i = 0; i < maxTokens; ++i)
    {
        i64 promptCount = sc_list_count(aPrompt);
        for (i32 c = 0; c < contextLength; ++c)
        {
            i64 sourceIndex = promptCount - contextLength + c;
            aContext[c] = sourceIndex >= 0 ? aPrompt[sourceIndex] : (u32)ScAiSpecialToken_Pad;
        }

        _sc_ai_model_forward(pModel, aContext);

        u32 token = _sc_ai_sample(pModel, temperature, topK, &rngState);
        if (token == (u32)ScAiSpecialToken_Eos ||
            token == (u32)ScAiSpecialToken_Bos ||
            token == (u32)ScAiSpecialToken_Sep ||
            token == (u32)ScAiSpecialToken_Pad ||
            token == (u32)ScAiSpecialToken_Unk)
        {
            break;
        }

        sc_list_add(aResult, (i32)token);
        sc_list_add(aPrompt, token);
    }

    char* pText = sc_ai_bpe_decode(bpe, aResult);

    sc_list_free(aResult);
    sc_list_free(aPrompt);
    sc_memory_free(aContext);

    return pText;
}

#endif // example stuff
