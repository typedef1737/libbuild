/*
  DOCS: QOA - "Quite OK Audio" - нативная реализация (порт семантики
  qoa.h от phoboslab, без внешних зависимостей). Разделы:

    - таблицы квантования: quant (остаток -8..8 -> 3 бита),
      scalefactor (16 значений, round(pow(s + 1, 2.75))),
      reciprocal (1/scalefactor в .16 fixed point), dequant
      (16 x 8, scalefactor * {0.75, -0.75, 2.5, -2.5, 4.5, -4.5,
      7, -7} с округлением от нуля);
    - LMS-фильтр: predict (сумма weight * history >> 13), update
      (delta = residual >> 4, знаковое сложение весов, сдвиг
      истории);
    - big endian u64 read/write по позиции;
    - энкодер: перебор 16 scalefactor на слайс (с оптимизацией
      "начать с предыдущего"), ранг = сумма квадратов ошибок +
      штраф за разросшиеся веса, лучший слайс попадает в файл;
    - декодер: чтение заголовков с валидацией, восстановление
      LMS-состояния из фрейма, покомпонентная деквантизация.

  NOTE: целочисленная арифметика как в эталоне (i32, сдвиги) -
  на выходе бит-в-бит совпадает с qoa.h.
*/
#include "Sc/Sound/Qoa.h"

#include "Sc/Sc.h"

/*
  DOCS: Индекс в dequant-таблице для остатка -8..8. Отображает
  диапазон в 3 бита, на верхнем крае менее точно. Ноль совпадает с
  младшим положительным значением - это нормально, т.к. округление
  в sc_qoa_div всегда от нуля.
*/
static const i32 aQoaQuantTab[17] = {
    7, 7, 7, 5, 5, 3, 3, 1, /* -8..-1 */
    0,                      /*  0     */
    0, 2, 2, 4, 4, 6, 6, 6  /*  1..8  */
};

/*
  DOCS: 16 scalefactor-ов, вычисленных как round(pow(s + 1, 2.75)).
  Максимум 2048: 2048 * 8 покрывает остатки до 2**14 (четверть
  16-битного диапазона) - LMS-фильтр прогнозирует точнее.
*/
static const i32 aQoaScalefactorTab[16] = {
    1, 7, 21, 45, 84, 138, 211, 304, 421, 562, 731, 928, 1157, 1419, 1715, 2048
};

/*
  DOCS: Округлённые обратные величины scalefactor-ов (в .16 fixed
  point): вместо деления в энкодере - одно умножение.
*/
static const i32 aQoaReciprocalTab[16] = {
    65536, 9363, 3121, 1457, 781, 475, 311, 216, 156, 117, 90, 71, 57, 47, 39, 32
};

/*
  DOCS: Деквантованные остатки для каждого scalefactor и индекса
  quant (0..7). Отрицательные значения - зеркально положительным,
  округление "к ближайшему, тай от нуля".
*/
static const i32 aQoaDequantTab[16][8] = {
    {   1,    -1,    3,    -3,    5,    -5,     7,     -7},
    {   5,    -5,   18,   -18,   32,   -32,    49,    -49},
    {  16,   -16,   53,   -53,   95,   -95,   147,   -147},
    {  34,   -34,  113,  -113,  203,  -203,   315,   -315},
    {  63,   -63,  210,  -210,  378,  -378,   588,   -588},
    { 104,  -104,  345,  -345,  621,  -621,   966,   -966},
    { 158,  -158,  528,  -528,  950,  -950,  1477,  -1477},
    { 228,  -228,  760,  -760, 1368, -1368,  2128,  -2128},
    { 316,  -316, 1053, -1053, 1895, -1895,  2947,  -2947},
    { 422,  -422, 1405, -1405, 2529, -2529,  3934,  -3934},
    { 548,  -548, 1828, -1828, 3290, -3290,  5117,  -5117},
    { 696,  -696, 2320, -2320, 4176, -4176,  6496,  -6496},
    { 868,  -868, 2893, -2893, 5207, -5207,  8099,  -8099},
    {1064, -1064, 3548, -3548, 6386, -6386,  9933,  -9933},
    {1286, -1286, 4288, -4288, 7718, -7718, 12005, -12005},
    {1536, -1536, 5120, -5120, 9216, -9216, 14336, -14336},
};

/* //////////////////////////////////////////////////////////////////////// */
/* LMS-фильтр */

/*
  DOCS: Прогноз следующего сэмпла: сумма (weight * history),
  сдвинутая вправо на 13 бит (fixed point).
*/
static i32
sc_qoa_lms_predict(ScQoaLms* pLms)
{
    i32 prediction = 0;
    for (i32 i = 0; i < SC_QOA_LMS_LEN; ++i)
        prediction += pLms->aWeights[i] * pLms->aHistory[i];
    return prediction >> 13;
}

/*
  DOCS: Обновление весов (Sign-Sign LMS): delta = residual >> 4,
  прибавляется/вычитается по знаку history. История сдвигается,
  свежий сэмпл - последним.
*/
static void
sc_qoa_lms_update(ScQoaLms* pLms, i32 sample, i32 residual)
{
    i32 delta = residual >> 4;

    for (i32 i = 0; i < SC_QOA_LMS_LEN; ++i)
        pLms->aWeights[i] += pLms->aHistory[i] < 0 ? -delta : delta;

    for (i32 i = 0; i < SC_QOA_LMS_LEN - 1; ++i)
        pLms->aHistory[i] = pLms->aHistory[i + 1];
    pLms->aHistory[SC_QOA_LMS_LEN - 1] = sample;
}

/* //////////////////////////////////////////////////////////////////////// */
/* Утилиты */

/*
  DOCS: Округляющее деление остатка на scalefactor (индекс в
  reciprocal-таблице): умножение в .16 fixed point + доводка
  "от нуля", чтобы малые значения не округлялись в 0.
*/
static i32
sc_qoa_div(i32 value, i32 scalefactor)
{
    i32 reciprocal = aQoaReciprocalTab[scalefactor];
    i32 n = (value * reciprocal + (1 << 15)) >> 16;
    n = n + ((value > 0) - (value < 0)) - ((n > 0) - (n < 0)); /* округление от 0 */
    return n;
}

static i32
sc_qoa_clamp(i32 value, i32 min, i32 max)
{
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

/*
  DOCS: Специализированный clamp в signed 16 bit: один беззнаковый
  сравнение вместо двух, ветка предсказывается процессором.
*/
static i32
sc_qoa_clamp_s16(i32 value)
{
    if ((u32)(value + 32768) > 65535)
    {
        if (value < -32768) return -32768;
        if (value >  32767) return  32767;
    }
    return value;
}

static u64
sc_qoa_read_u64(u8* pBytes, i64* pPosition)
{
    u8* p = pBytes + *pPosition;
    *pPosition += 8;
    return
        ((u64)p[0] << 56) | ((u64)p[1] << 48) |
        ((u64)p[2] << 40) | ((u64)p[3] << 32) |
        ((u64)p[4] << 24) | ((u64)p[5] << 16) |
        ((u64)p[6] <<  8) | ((u64)p[7] <<  0);
}

static void
sc_qoa_write_u64(u64 value, u8* pBytes, i64* pPosition)
{
    u8* p = pBytes + *pPosition;
    *pPosition += 8;
    p[0] = (value >> 56) & 0xff;
    p[1] = (value >> 48) & 0xff;
    p[2] = (value >> 40) & 0xff;
    p[3] = (value >> 32) & 0xff;
    p[4] = (value >> 24) & 0xff;
    p[5] = (value >> 16) & 0xff;
    p[6] = (value >>  8) & 0xff;
    p[7] = (value >>  0) & 0xff;
}

/* //////////////////////////////////////////////////////////////////////// */
/* Энкодер */

i32
sc_qoa_encode_frame(i16* pSampleData, ScQoaDesc* pDesc, i32 frameLen, u8* pBytes)
{
    i32 channels = pDesc->Channels;

    i64 position = 0;
    i32 slices = (frameLen + SC_QOA_SLICE_LEN - 1) / SC_QOA_SLICE_LEN;
    i32 frameSize = SC_QOA_FRAME_SIZE(channels, slices);
    i32 aPrevScalefactor[SC_QOA_MAX_CHANNELS] = {};

    /* frame header */
    sc_qoa_write_u64(
        ((u64)channels          << 56) |
        ((u64)pDesc->Samplerate << 32) |
        ((u64)frameLen          << 16) |
        ((u64)frameSize),
        pBytes, &position);

    for (i32 c = 0; c < channels; ++c)
    {
        /* текущее LMS-состояние канала */
        u64 history = 0;
        u64 weights = 0;
        for (i32 i = 0; i < SC_QOA_LMS_LEN; ++i)
        {
            history = (history << 16) | (pDesc->aLms[c].aHistory[i] & 0xffff);
            weights = (weights << 16) | (pDesc->aLms[c].aWeights[i] & 0xffff);
        }
        sc_qoa_write_u64(history, pBytes, &position);
        sc_qoa_write_u64(weights, pBytes, &position);
    }

    /*
      DOCS: Каналы интерливлены на уровне слайсов: (ch0 slice0),
      (ch1 slice0), (ch0 slice1)... Перебираем все scalefactor-ы и
      берём тот, что даёт минимальный ранг (квадрат ошибки + штраф
      за веса).
    */
    for (i32 sampleIndex = 0; sampleIndex < frameLen; sampleIndex += SC_QOA_SLICE_LEN)
    {
        for (i32 c = 0; c < channels; ++c)
        {
            i32 sliceLen = sc_qoa_clamp(SC_QOA_SLICE_LEN, 0, frameLen - sampleIndex);
            i32 sliceStart = sampleIndex * channels + c;
            i32 sliceEnd = (sampleIndex + sliceLen) * channels + c;

            u64 bestRank = (u64)-1;
            u64 bestSlice = 0;
            ScQoaLms bestLms;
            i32 bestScalefactor = 0;

            for (i32 sfi = 0; sfi < 16; ++sfi)
            {
                /*
                  DOCS: Сильная корреляция scalefactor-ов соседних
                  слайсов: начинаем перебор с лучшего из предыдущего
                  (кольцевой сдвиг).
                */
                i32 scalefactor = (sfi + aPrevScalefactor[c]) & (16 - 1);

                /*
                  DOCS: LMS-состояние копируется перед каждым
                  перебором - каждая попытка его обновляет.
                */
                ScQoaLms lms = pDesc->aLms[c];
                u64 slice = scalefactor;
                u64 currentRank = 0;

                for (i32 si = sliceStart; si < sliceEnd; si += channels)
                {
                    i32 sample = pSampleData[si];
                    i32 predicted = sc_qoa_lms_predict(&lms);

                    i32 residual = sample - predicted;
                    i32 scaled = sc_qoa_div(residual, scalefactor);
                    i32 clamped = sc_qoa_clamp(scaled, -8, 8);
                    i32 quantized = aQoaQuantTab[clamped + 8];
                    i32 dequantized = aQoaDequantTab[scalefactor][quantized];
                    i32 reconstructed = sc_qoa_clamp_s16(predicted + dequantized);

                    /*
                      DOCS: Штраф за разросшиеся веса - предотвращает
                      щелчки на проблемных сигналах.
                    */
                    i32 weightsPenalty = ((
                        lms.aWeights[0] * lms.aWeights[0] +
                        lms.aWeights[1] * lms.aWeights[1] +
                        lms.aWeights[2] * lms.aWeights[2] +
                        lms.aWeights[3] * lms.aWeights[3]
                    ) >> 18) - 0x8ff;
                    if (weightsPenalty < 0)
                        weightsPenalty = 0;

                    i64 error = (sample - reconstructed);
                    u64 errorSq = (u64)(error * error);

                    currentRank += errorSq + (u64)weightsPenalty * (u64)weightsPenalty;
                    if (currentRank > bestRank)
                        break;

                    sc_qoa_lms_update(&lms, reconstructed, dequantized);
                    slice = (slice << 3) | (u64)quantized;
                }

                if (currentRank < bestRank)
                {
                    bestRank = currentRank;
                    bestSlice = slice;
                    bestLms = lms;
                    bestScalefactor = scalefactor;
                }
            }

            aPrevScalefactor[c] = bestScalefactor;

            pDesc->aLms[c] = bestLms;

            /*
              DOCS: Короткий последний слайс: сдвигаем биты влево,
              чтобы справа оказались пустые позиции.
            */
            bestSlice <<= (SC_QOA_SLICE_LEN - sliceLen) * 3;
            sc_qoa_write_u64(bestSlice, pBytes, &position);
        }
    }

    return (i32)position;
}

void*
sc_qoa_encode(i16* pSampleData, ScQoaDesc* pDesc, i64* pLength)
{
    if (pSampleData == ScNull || pDesc == ScNull || pLength == ScNull)
        return ScNull;

    if (
        pDesc->SamplesPerChannel == 0 ||
        pDesc->Samplerate == 0 || pDesc->Samplerate > 0xffffff ||
        pDesc->Channels == 0 || pDesc->Channels > SC_QOA_MAX_CHANNELS
    )
        return ScNull;

    /* размер закодированных данных */
    i32 numFrames = (pDesc->SamplesPerChannel + SC_QOA_FRAME_LEN - 1) / SC_QOA_FRAME_LEN;
    i32 numSlices = (pDesc->SamplesPerChannel + SC_QOA_SLICE_LEN - 1) / SC_QOA_SLICE_LEN;
    i64 encodedSize = 8 +                             /* file header */
        (i64)numFrames * 8 +                          /* frame headers */
        (i64)numFrames * SC_QOA_LMS_LEN * 4 * pDesc->Channels + /* lms на канал */
        (i64)numSlices * 8 * pDesc->Channels;         /* слайсы */

    u8* pBytes = (u8*)sc_memory_allocate(encodedSize);
    if (pBytes == ScNull)
        return ScNull;

    for (i32 c = 0; c < pDesc->Channels; ++c)
    {
        /*
          DOCS: Начальные веса {0, 0, -1<<13, 1<<14} - помогают
          прогнозу первых миллисекунд. История обнуляется явно
          (мог остаться мусор).
        */
        pDesc->aLms[c].aWeights[0] = 0;
        pDesc->aLms[c].aWeights[1] = 0;
        pDesc->aLms[c].aWeights[2] = -(1 << 13);
        pDesc->aLms[c].aWeights[3] =  (1 << 14);

        for (i32 i = 0; i < SC_QOA_LMS_LEN; ++i)
            pDesc->aLms[c].aHistory[i] = 0;
    }

    /* file header: magic + samples */
    i64 position = 0;
    sc_qoa_write_u64(((u64)SC_QOA_MAGIC << 32) | (u64)pDesc->SamplesPerChannel, pBytes, &position);

    i32 frameLen = SC_QOA_FRAME_LEN;
    for (i32 sampleIndex = 0; sampleIndex < pDesc->SamplesPerChannel; sampleIndex += frameLen)
    {
        frameLen = sc_qoa_clamp(SC_QOA_FRAME_LEN, 0, pDesc->SamplesPerChannel - sampleIndex);
        i16* pFrameSamples = pSampleData + sampleIndex * pDesc->Channels;
        i32 frameSize = sc_qoa_encode_frame(pFrameSamples, pDesc, frameLen, pBytes + position);
        position += frameSize;
    }

    *pLength = position;
    return pBytes;
}

/* //////////////////////////////////////////////////////////////////////// */
/* Декодер */

i32
sc_qoa_max_frame_size(ScQoaDesc* pDesc)
{
    if (pDesc == ScNull)
        return 0;
    return SC_QOA_FRAME_SIZE(pDesc->Channels, SC_QOA_SLICES_PER_FRAME);
}

/*
  DOCS: Читает file-header (magic "qoaf" + samples) и заглядывает
  в первый фрейм за channels/samplerate. Возвращает 8 (позиция
  после file-header) или 0 при ошибке.
*/
static i32
sc_qoa_decode_header(u8* pBytes, i64 size, ScQoaDesc* pDesc)
{
    i64 position = 0;
    if (size < SC_QOA_MIN_FILESIZE)
        return 0;

    u64 fileHeader = sc_qoa_read_u64(pBytes, &position);

    if ((fileHeader >> 32) != SC_QOA_MAGIC)
        return 0;

    pDesc->SamplesPerChannel = (i32)(fileHeader & 0xffffffff);
    if (!pDesc->SamplesPerChannel)
        return 0;

    u64 frameHeader = sc_qoa_read_u64(pBytes, &position);
    pDesc->Channels   = (i32)((frameHeader >> 56) & 0x0000ff);
    pDesc->Samplerate = (i32)((frameHeader >> 32) & 0xffffff);

    if (
        pDesc->Channels == 0 || pDesc->SamplesPerChannel == 0 || pDesc->Samplerate == 0 ||
        pDesc->Channels > SC_QOA_MAX_CHANNELS
    )
        return 0;

    return 8;
}

i32
sc_qoa_decode_frame(void* pData, i64 dataSize, ScQoaDesc* pDesc, i16* pSampleData, i32* pFrameLen)
{
    u8* pBytes = (u8*)pData;
    i64 position = 0;
    if (pFrameLen)
        *pFrameLen = 0;

    if (pBytes == ScNull || pDesc == ScNull || pSampleData == ScNull)
        return 0;

    if (dataSize < 8 + SC_QOA_LMS_LEN * 4 * pDesc->Channels)
        return 0;

    /* frame header */
    u64 frameHeader = sc_qoa_read_u64(pBytes, &position);
    i32 channels   = (i32)((frameHeader >> 56) & 0x0000ff);
    i32 samplerate = (i32)((frameHeader >> 32) & 0xffffff);
    i32 samples    = (i32)((frameHeader >> 16) & 0x00ffff);
    i32 frameSize  = (i32)(frameHeader        & 0x00ffff);

    i32 headerSize = 8 + SC_QOA_LMS_LEN * 4 * channels;
    i32 dataSize32 = frameSize - headerSize;
    i32 maxTotalSlices = dataSize32 / 8;
    i32 numSlices = (samples + SC_QOA_SLICE_LEN - 1) / SC_QOA_SLICE_LEN;

    if (
        channels != pDesc->Channels ||
        samplerate != pDesc->Samplerate ||
        frameSize < headerSize ||
        frameSize > dataSize ||
        numSlices > SC_QOA_SLICES_PER_FRAME ||
        numSlices * channels > maxTotalSlices
    )
        return 0;

    /* LMS-состояние: 4 x 2 байта history, 4 x 2 байта weights на канал */
    for (i32 c = 0; c < channels; ++c)
    {
        u64 history = sc_qoa_read_u64(pBytes, &position);
        u64 weights = sc_qoa_read_u64(pBytes, &position);
        for (i32 i = 0; i < SC_QOA_LMS_LEN; ++i)
        {
            pDesc->aLms[c].aHistory[i] = (i16)(history >> 48);
            history <<= 16;
            pDesc->aLms[c].aWeights[i] = (i16)(weights >> 48);
            weights <<= 16;
        }
    }

    /* все слайсы всех каналов фрейма */
    for (i32 sampleIndex = 0; sampleIndex < samples; sampleIndex += SC_QOA_SLICE_LEN)
    {
        for (i32 c = 0; c < channels; ++c)
        {
            u64 slice = sc_qoa_read_u64(pBytes, &position);

            i32 scalefactor = (i32)((slice >> 60) & 0xf);
            slice <<= 4;

            i32 sliceStart = sampleIndex * channels + c;
            i32 sliceEnd = sc_qoa_clamp(sampleIndex + SC_QOA_SLICE_LEN, 0, samples) * channels + c;

            for (i32 si = sliceStart; si < sliceEnd; si += channels)
            {
                i32 predicted = sc_qoa_lms_predict(&pDesc->aLms[c]);
                i32 quantized = (i32)((slice >> 61) & 0x7);
                i32 dequantized = aQoaDequantTab[scalefactor][quantized];
                i32 reconstructed = sc_qoa_clamp_s16(predicted + dequantized);

                pSampleData[si] = (i16)reconstructed;
                slice <<= 3;

                sc_qoa_lms_update(&pDesc->aLms[c], reconstructed, dequantized);
            }
        }
    }

    if (pFrameLen)
        *pFrameLen = samples;
    return (i32)position;
}

i16*
sc_qoa_decode(void* pData, i64 dataSize, ScQoaDesc* pDesc)
{
    if (pData == ScNull || pDesc == ScNull)
        return ScNull;

    i64 position = sc_qoa_decode_header((u8*)pData, dataSize, pDesc);
    if (position == 0)
        return ScNull;

    /* размер буфера сэмплов с округлением вверх до целых фреймов */
    u64 numFrames = ((u64)pDesc->SamplesPerChannel + SC_QOA_FRAME_LEN - 1) / SC_QOA_FRAME_LEN;
    u64 totalSamplesU64 = numFrames * SC_QOA_FRAME_LEN * (u64)pDesc->Channels;

    if (totalSamplesU64 > 0x7fffffff)
        return ScNull;

    i16* pSampleData = (i16*)sc_memory_allocate(totalSamplesU64 * sizeof(i16));
    if (pSampleData == ScNull)
        return ScNull;

    i64 sampleIndex = 0;
    i32 frameLen = 0;
    i32 frameSize = 0;

    do
    {
        i16* pSamplePtr = pSampleData + sampleIndex * pDesc->Channels;
        frameSize = sc_qoa_decode_frame((u8*)pData + position, dataSize - position, pDesc, pSamplePtr, &frameLen);

        position += frameSize;
        sampleIndex += frameLen;
    } while (frameLen == SC_QOA_FRAME_LEN && sampleIndex < pDesc->SamplesPerChannel);

    pDesc->SamplesPerChannel = (i32)sampleIndex;
    return pSampleData;
}

/* //////////////////////////////////////////////////////////////////////// */
/* Файловые функции */

i64
sc_qoa_write(char* pPath, i16* pSampleData, ScQoaDesc* pDesc)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pSampleData);
    sc_assert_not_null(pDesc);

    if (pPath == ScNull || pSampleData == ScNull || pDesc == ScNull)
        return 0;

    i64 length = 0;
    void* pEncoded = sc_qoa_encode(pSampleData, pDesc, &length);
    if (pEncoded == ScNull)
        return 0;

    sc_file_write(pPath, pEncoded, length);

    sc_memory_free(pEncoded);
    return length;
}

i16*
sc_qoa_read(char* pPath, ScQoaDesc* pDesc)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pDesc);

    if (pPath == ScNull || pDesc == ScNull)
        return ScNull;

    i64 dataSize = 0;
    void* pData = sc_file_read_ext(pPath, &dataSize);
    if (pData == ScNull)
        return ScNull;

    i16* pSampleData = sc_qoa_decode(pData, dataSize, pDesc);

    sc_memory_free(pData);
    return pSampleData;
}
