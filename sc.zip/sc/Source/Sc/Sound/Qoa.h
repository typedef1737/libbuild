/*
  QOA - "Quite OK Audio" - быстрый lossy-формат сжатия аудио.

  Реализация по спецификации из Source/Deps/qoa-specification.pdf
  (v1.1, она же продублирована в Source/Deps/qoa.h). Нативная, без
  внешних зависимостей: подходит для сборки в составе StaticLib Sc.

  QOA-файл: 8-байтный file-header (magic "qoaf" + samples), далее
  фреймы по 5120 сэмплов на канал (256 слайсов по 20 сэмплов).
  Каждый фрейм: 8-байтный frame-header, LMS-состояние (4 history +
  4 weights, i16) на канал, слайсы по 8 байт: 4 бита scalefactor +
  20 * 3 бита квантованных остатков. Всё big endian, каналы
  интерливлены по слайсам (L, R, L, R...). Прогноз сэмпла - Sign-Sign
  LMS-фильтр по 4 предыдущим сэмплам. Компрессия 5x (3.2 бита на
  16-битный сэмпл).
*/
#ifndef SC_QOA_H
#define SC_QOA_H

#include "Sc/Types.h"

/* константы формата */
#define SC_QOA_MIN_FILESIZE       16
#define SC_QOA_MAX_CHANNELS       8
#define SC_QOA_SLICE_LEN          20
#define SC_QOA_SLICES_PER_FRAME   256
#define SC_QOA_FRAME_LEN          (SC_QOA_SLICES_PER_FRAME * SC_QOA_SLICE_LEN) /* 5120 */
#define SC_QOA_LMS_LEN            4
#define SC_QOA_MAGIC              0x716f6166 /* 'qoaf' */

/* размер фрейма целиком: header + lms-состояние + слайсы */
#define SC_QOA_FRAME_SIZE(channels, slices) \
    (8 + SC_QOA_LMS_LEN * 4 * (channels) + 8 * (slices) * (channels))

/*
  DOCS: LMS-состояние канала: 4 последних сэмпла (history, свежий
  последним) и 4 веса прогноза (weights).
*/
typedef struct
{
    i32 aHistory[SC_QOA_LMS_LEN];
    i32 aWeights[SC_QOA_LMS_LEN];
} ScQoaLms;

/*
  DOCS: Описание аудио. Для кодирования заполняется вручную
  (SamplesPerChannel, Samplerate, Channels), для декодирования -
  заполняется из заголовка файла. aLms - текущее состояние фильтра
  (для потокового кодирования/декодирования фрейм за фреймом).
*/
typedef struct
{
    i32 Channels;           /* число каналов, 1..8 */
    i32 Samplerate;         /* герц, 1..16777215 */
    i32 SamplesPerChannel;  /* сэмплов на канал (0 = streaming) */
    ScQoaLms aLms[SC_QOA_MAX_CHANNELS];
} ScQoaDesc;

/*
  DOCS: Кодирует PCM i16 (каналы интерливлены) в QOA-данные в памяти.
  Возвращает ScNull при ошибке (невалидные аргументы, нехватка
  памяти), иначе - закодированные данные (освободить sc_memory_free);
  в *pLength пишется размер данных в байтах. Состояние LMS в pDesc
  сбрасывается в начальное и обновляется по мере кодирования.
*/
void* sc_qoa_encode(i16* pSampleData, ScQoaDesc* pDesc, i64* pLength);

/*
  DOCS: Декодирует QOA-данные из памяти. Возвращает ScNull при
  ошибке, иначе PCM i16 (освободить sc_memory_free; буфер округлён
  вверх до целых фреймов - хвост заполнен нулями). pDesc
  заполняется из заголовка, число реально декодированных сэмплов
  на канал - в pDesc->SamplesPerChannel.
*/
i16* sc_qoa_decode(void* pData, i64 dataSize, ScQoaDesc* pDesc);

/*
  DOCS: Кодирует PCM i16 и пишет QOA-файл на диск (sc_file_write,
  бинарно). Возвращает 0 при ошибке или число записанных байт.
*/
i64 sc_qoa_write(char* pPath, i16* pSampleData, ScQoaDesc* pDesc);

/*
  DOCS: Читает и декодирует QOA-файл с диска (sc_file_read, бинарно).
  Возвращает ScNull при ошибке, иначе PCM i16 (освободить
  sc_memory_free).
*/
i16* sc_qoa_read(char* pPath, ScQoaDesc* pDesc);

/*
  DOCS: Максимальный размер одного фрейма (для потокового
  кодирования/декодирования с заранее выделенным буфером).
*/
i32 sc_qoa_max_frame_size(ScQoaDesc* pDesc);

/*
  DOCS: Кодирует один фрейм (до SC_QOA_FRAME_LEN сэмплов на канал,
  каналы интерливлены) в pBytes. Буфер должен быть не меньше
  sc_qoa_max_frame_size(pDesc). Возвращает число записанных байт
  или 0 при ошибке. LMS-состояние в pDesc обновляется - так можно
  кодировать аудио фрейм за фреймом в поток.
*/
i32 sc_qoa_encode_frame(i16* pSampleData, ScQoaDesc* pDesc, i32 frameLen, u8* pBytes);

/*
  DOCS: Декодирует один фрейм из pBytes (dataSize - размер
  оставшихся данных). Возвращает число обработанных байт фрейма
  (0 при ошибке), в *pFrameLen - число декодированных сэмплов на
  канал. LMS-состояние в pDesc обновляется. В отличие от полного
  sc_qoa_decode, каналы/samplerate фрейма должны совпадать с pDesc.
*/
i32 sc_qoa_decode_frame(void* pData, i64 dataSize, ScQoaDesc* pDesc, i16* pSampleData, i32* pFrameLen);

#endif // SC_QOA_H
