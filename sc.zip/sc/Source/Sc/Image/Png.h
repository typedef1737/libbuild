/*
  DOCS: PNG - Portable Network Graphics. Нативная реализация без
  внешних зависимостей: разбор чанков (CRC32), zlib/inflate
  (все методы сжатия, dynamic Huffman), фильтры строк 0-4, Adam7
  interlace, палитры (PLTE + tRNS) и битовые глубины 1/2/4/8/16.
  Запись: 8 бит на канал, comp 1..4, фильтр по эвристике stb_image_write,
  сжатие - fixed Huffman + LZ77 (хеш-цепочки). Заголовок magic:
  137 80 78 71 13 10 26 10 ("\x89PNG\r\n\x1a\n").

  Пиксели: строки слева-направо, сверху-вниз, каналы пикселя подряд.
  Все возвращаемые буферы - sc_memory_allocate / sc_memory_free.
*/
#ifndef SC_PNG_H
#define SC_PNG_H

#include "Sc/Image/Image.h"

/*
  DOCS: Декодирует PNG-данные из памяти.
  channels: 0 - взять из файла, 1..4 - форсировать число каналов вывода.
  Возвращает NULL при ошибке, иначе пиксели (освободить sc_memory_free).
  pDesc заполняется из заголовка файла.
*/
void* sc_png_decode(void* pData, i64 dataSize, ScImageDesc* pDesc, i32 channels);

/*
  DOCS: Читает и декодирует PNG-файл с диска (sc_file_read, бинарно).
  Возвращает NULL при ошибке, иначе пиксели (освободить sc_memory_free).
*/
void* sc_png_read(char* pPath, ScImageDesc* pDesc, i32 channels);

/*
  DOCS: Кодирует сырые пиксели (8 бит на канал, comp 1..4) в PNG-данные
  в памяти. Возвращает NULL при ошибке (невалидные аргументы, нехватка
  памяти), иначе - закодированные данные (освободить sc_memory_free);
  в *pLength пишется размер данных в байтах.
*/
void* sc_png_encode(void* pData, ScImageDesc desc, i64* pLength);

/*
  DOCS: Кодирует сырые пиксели и пишет PNG-файл на диск
  (sc_file_write, бинарно). Возвращает 0 при ошибке или число
  записанных байт.
*/
i64 sc_png_write(char* pPath, void* pData, ScImageDesc desc);

#endif // SC_PNG_H
