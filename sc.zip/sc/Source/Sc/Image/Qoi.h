/*
  QOI - "Quite OK Image" - быстрый lossless-формат сжатия изображений.

  Реализация по спецификации из Source/Deps/qoi-specification.pdf
  (она же продублирована в Source/Deps/qoi.h). Нативная, без внешних
  зависимостей: подходит для сборки в составе StaticLib Sc.

  QOI-файл: 14-байтный заголовок, чанки, 8-байтный end-marker.
  Изображение кодируется построчно, слева направо, сверху вниз.
  Кодер и декодер стартуют с пикселя {r: 0, g: 0, b: 0, a: 255}.
*/
#ifndef SC_QOI_H
#define SC_QOI_H

#include "Sc/Types.h"

/*
  DOCS: Colorspace из заголовка QOI. Чисто информативен: пишется в файл,
  но не влияет на то, как кодируются/декодируются чанки.
*/
typedef enum
{
    ScQoiColorspace_Srgb = 0,   /* sRGB (гамма-масштабированные RGB) + линейный alpha */
    ScQoiColorspace_Linear = 1, /* все каналы линейные */
} ScQoiColorspace;

/*
  DOCS: Количество каналов пикселей.
*/
typedef enum
{
    ScQoiChannels_Rgb = 3,  /* 3 байта на пиксель */
    ScQoiChannels_Rgba = 4, /* 4 байта на пиксель */
} ScQoiChannels;

/*
  DOCS: Описание изображения. Для sc_qoi_encode/sc_qoi_write заполняется
  вручную, для sc_qoi_decode/sc_qoi_read - заполняется из заголовка.
*/
typedef struct
{
    i32 Width;      /* ширина в пикселях */
    i32 Height;     /* высота в пикселях */
    i32 Channels;   /* ScQoiChannels */
    i32 Colorspace; /* ScQoiColorspace */
} ScQoiDesc;

/*
  DOCS: Кодирует сырые RGB/RGBA пиксели в QOI-данные в памяти.
  pData - Width * Height * Channels байт пикселей.
  Возвращает NULL при ошибке (невалидные аргументы, нехватка памяти),
  иначе - закодированные данные (освободить sc_memory_free);
  в *pLength пишется размер данных в байтах.
*/
void* sc_qoi_encode(void* pData, ScQoiDesc desc, i64* pLength);

/*
  DOCS: Декодирует QOI-данные из памяти.
  channels: 0 - взять из заголовка, 3/4 - форсировать число каналов вывода.
  Возвращает NULL при ошибке, иначе пиксели (освободить sc_memory_free).
  pDesc заполняется из заголовка файла.
*/
void* sc_qoi_decode(void* pData, i64 dataSize, ScQoiDesc* pDesc, i32 channels);

/*
  DOCS: Читает и декодирует QOI-файл с диска (sc_file_read, бинарно).
  Возвращает NULL при ошибке, иначе пиксели (освободить sc_memory_free).
*/
void* sc_qoi_read(char* pPath, ScQoiDesc* pDesc, i32 channels);

/*
  DOCS: Кодирует сырые RGB/RGBA пиксели и пишет QOI-файл на диск
  (sc_file_write, бинарно). Возвращает 0 при ошибке или число
  записанных байт.
*/
i64 sc_qoi_write(char* pPath, void* pData, ScQoiDesc desc);

#endif // SC_QOI_H
