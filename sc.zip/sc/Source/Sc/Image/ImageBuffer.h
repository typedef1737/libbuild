/*
  DOCS: Растущий байтовый буфер для модулей изображений (Png, Jpg):
  общий приёмник потока байтов при кодировании. Память выделяется
  через sc_memory_allocate / освобождается sc_memory_free.
*/
#ifndef SC_IMAGE_BUFFER_H
#define SC_IMAGE_BUFFER_H

#include "Sc/Types.h"

/*
  DOCS: Буфер байтов: pData - данные, Count - записано, Capacity -
  выделено (растёт по мере записи).
*/
typedef struct
{
    u8* pData;
    i64 Count;
    i64 Capacity;
} ScImageBuffer;

/*
  DOCS: Создаёт буфер с начальной ёмкостью capacity (подсказка, буфер
  растёт по мере записи). При нехватке памяти pData == ScNull.
*/
void sc_image_buffer_init(ScImageBuffer* pBuffer, i64 capacity);

/*
  DOCS: Освобождает буфер (sc_memory_free).
*/
void sc_image_buffer_destroy(ScImageBuffer* pBuffer);

/*
  DOCS: Дописывает size байт в конец буфера. При нехватке памяти во
  время записи pData сбрасывается в ScNull (запись считается неудачной,
  Count сбрасывается).
*/
void sc_image_buffer_write(ScImageBuffer* pBuffer, void* pData, i32 size);

#endif // SC_IMAGE_BUFFER_H
