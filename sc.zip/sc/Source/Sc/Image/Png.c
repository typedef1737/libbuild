/*
  DOCS: PNG - Portable Network Graphics. Нативная реализация (без stb):
  разбор чанков с проверкой CRC32, zlib/inflate (stored / fixed /
  dynamic Huffman), фильтры строк 0-4, Adam7 interlace, палитры
  (PLTE + tRNS), битовые глубины 1/2/4/8/16, tRNS для grey/rgb.

  Запись: 8 бит на канал, comp 1..4; фильтр строки выбирается
  эвристикой "минимальная сумма модулей" (как в libpng/stb),
  сжатие - deflate с fixed Huffman + LZ77 (хеш-цепочки), zlib-обёртка
  (CMF/FLG + Adler32).

  Структура файла: сигнатура 8 байт, затем чанки
  [длина BE 4][тип 4][данные][CRC32 BE 4]. Обязательные чанки:
  IHDR (первый), IDAT (один и больше), IEND. Строки растра в IDAT:
  [тип фильтра 1 байт][строка], упакованы битами MSB-first.
*/
#include "Sc/Image/Png.h"
#include "Sc/Image/ImageBuffer.h"
#include "Sc/Sc.h"
#include <string.h>

/*
  DOCS: Максимальный размер стороны (как у stb) и общего числа
  пикселей - защита от битых заголовков и переполнений.
*/
#define SC_PNG_MAX_DIMENSIONS (1 << 24)
#define SC_PNG_PIXELS_MAX 0x7ffffffe

/* цветовые типы IHDR */
#define SC_PNG_COLOR_GREY 0
#define SC_PNG_COLOR_RGB 2
#define SC_PNG_COLOR_INDEXED 3
#define SC_PNG_COLOR_GREY_ALPHA 4
#define SC_PNG_COLOR_RGBA 6

/* типы фильтров строк */
#define SC_PNG_FILTER_NONE 0
#define SC_PNG_FILTER_SUB 1
#define SC_PNG_FILTER_UP 2
#define SC_PNG_FILTER_AVERAGE 3
#define SC_PNG_FILTER_PAETH 4

/* параметры LZ77 энкодера */
#define SC_PNG_WINDOW_SIZE 32768
#define SC_PNG_MIN_MATCH 3
#define SC_PNG_MAX_MATCH 258
#define SC_PNG_HASH_SIZE (1 << 15)
#define SC_PNG_MAX_CHAIN 128

/*
  DOCS: Базы и числа дополнительных бит кодов длин (RFC 1951, 3.2.5).
*/
static const i32 aPngLengthBase[29] = {
    3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
    35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258
};
static const i32 aPngLengthExtra[29] = {
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
    3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0
};

/*
  DOCS: Базы и числа дополнительных бит кодов дистанций.
*/
static const i32 aPngDistBase[30] = {
    1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
    257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577
};
static const i32 aPngDistExtra[30] = {
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
    7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13
};

/*
  DOCS: Порядок длин кодов блока dynamic Huffman (RFC 1951, 3.2.7).
*/
static const i32 aPngCodeLenOrder[19] = {
    16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15
};

/*
  DOCS: Старты и шаги пасов Adam7: канва разбивается на 7 подизображений,
  пиксель (i, j) паса p лежит на канве (XStart[p] + i * XStep[p],
  YStart[p] + j * YStep[p]).
*/
static const i32 aPngXStart[7] = {0, 4, 0, 2, 0, 1, 0};
static const i32 aPngYStart[7] = {0, 0, 4, 0, 2, 0, 1};
static const i32 aPngXStep[7] = {8, 8, 4, 4, 2, 2, 1};
static const i32 aPngYStep[7] = {8, 8, 8, 4, 4, 2, 2};

/*
  DOCS: Таблица CRC32 (POLY 0xedb88320, reflected). Строится лениво
  при первом использовании.
*/
static u32
sc_png_crc32_run(u32 state, u8* pData, i64 size)
{
    static u32 aTable[256];
    static i32 isTableInit = 0;

    if (!isTableInit)
    {
        for (u32 n = 0; n < 256; ++n)
        {
            u32 c = n;
            for (i32 k = 0; k < 8; ++k)
                c = (c & 1) ? (0xedb88320u ^ (c >> 1)) : (c >> 1);
            aTable[n] = c;
        }
        isTableInit = 1;
    }

    for (i64 i = 0; i < size; ++i)
        state = aTable[(state ^ pData[i]) & 0xff] ^ (state >> 8);
    return state;
}

/*
  DOCS: Adler32 (RFC 1950): s1/s2 по модулю 65521.
*/
static u32
sc_png_adler32(u8* pData, i64 size)
{
    u32 a = 1;
    u32 b = 0;

    for (i64 i = 0; i < size; ++i)
    {
        a = (a + pData[i]) % 65521u;
        b = (b + a) % 65521u;
    }

    return (b << 16) | a;
}

/* ================================================================ */
/* Inflate (RFC 1951) + zlib-обёртка (RFC 1950) - сторона чтения.   */
/* ================================================================ */

/*
  DOCS: Битовый читатель deflate: биты идут LSB-first внутри байтов,
  байты little-endian. Взводит IsFailed при выходе за границы данных.
*/
typedef struct
{
    u8* aBytes;
    i64 Size;
    i64 Pos;
    u32 Bits;  /* аккумулятор: младшие биты - следующие биты потока */
    i32 Count; /* число валидных бит в аккумуляторе */
    i32 IsFailed;
} ScPngBits;

static void
sc_png_bits_refill(ScPngBits* pBits, i32 need)
{
    while (pBits->Count < need)
    {
        if (pBits->Pos >= pBits->Size)
        {
            pBits->IsFailed = 1;
            return;
        }

        pBits->Bits |= (u32)pBits->aBytes[pBits->Pos] << pBits->Count;
        ++pBits->Pos;
        pBits->Count += 8;
    }
}

/*
  DOCS: Читает count бит (MSB-first порядок внутри значения:
  первый бит потока - младший бит результата).
*/
static i32
sc_png_bits_take(ScPngBits* pBits, i32 count)
{
    if (count == 0)
        return 0;

    sc_png_bits_refill(pBits, count);
    if (pBits->Count < count)
        return 0; // IsFailed уже взведён

    u32 mask = (count >= 32) ? 0xffffffffu : ((1u << count) - 1);
    i32 value = (i32)(pBits->Bits & mask);
    pBits->Bits >>= count;
    pBits->Count -= count;
    return value;
}

/*
  DOCS: Канонический префиксный код: счётчики длин и символы
  по возрастанию кода. Декодирование - бит за битом (как медленный
  путь stb): на уровне len код code попадает в диапазон
  [first, first + count).
*/
typedef struct
{
    i16 aCounts[16];   /* aCounts[len] - число кодов длины len (1..15) */
    i16 aSymbols[288]; /* символы по возрастанию кода */
} ScPngHuff;

/*
  DOCS: Строит код по длинам символов (0 - символ не используется).
  Возвращает 0 при переполнении кодового пространства.
*/
static i32
sc_png_huff_build(ScPngHuff* pHuff, i8* aLengths, i32 count)
{
    memset(pHuff->aCounts, 0, sizeof(pHuff->aCounts));

    for (i32 i = 0; i < count; ++i)
    {
        i32 len = aLengths[i];
        if (len < 0 || len > 15)
            return 0;
        ++pHuff->aCounts[len];
    }

    // DOCS: проверка переполнения: left - свободные коды слева.
    i32 left = 1;
    for (i32 len = 1; len <= 15; ++len)
    {
        left <<= 1;
        left -= pHuff->aCounts[len];
        if (left < 0)
            return 0;
    }

    // DOCS: стартовые индексы символов для каждой длины.
    i32 aOffsets[16];
    aOffsets[1] = 0;
    for (i32 len = 1; len < 15; ++len)
        aOffsets[len + 1] = aOffsets[len] + pHuff->aCounts[len];

    for (i32 i = 0; i < count; ++i)
    {
        if (aLengths[i] != 0)
        {
            pHuff->aSymbols[aOffsets[aLengths[i]]] = (i16)i;
            ++aOffsets[aLengths[i]];
        }
    }

    return 1;
}

/*
  DOCS: Декодирует один символ кода из потока бит.
  Возвращает -1 при ошибке (битый код / конец данных).
*/
static i32
sc_png_huff_decode(ScPngBits* pBits, ScPngHuff* pHuff)
{
    i32 code = 0;
    i32 first = 0;
    i32 index = 0;

    for (i32 len = 1; len <= 15; ++len)
    {
        code |= sc_png_bits_take(pBits, 1);
        if (pBits->IsFailed)
            return -1;

        i32 count = pHuff->aCounts[len];
        if (code - count < first)
            return pHuff->aSymbols[index + (code - first)];

        index += count;
        first = (first + count) << 1;
        code <<= 1;
    }

    return -1;
}

/*
  DOCS: Выходной растущий буфер inflate с верхним пределом размера
  (ожидаемый размер сырого растра PNG - защита от zip-бомб).
*/
typedef struct
{
    u8* pData;
    i64 Size;
    i64 Capacity;
    i64 Limit;
    i32 IsFailed;
} ScPngOut;

static i32
sc_png_out_reserve(ScPngOut* pOut, i64 extra)
{
    if (pOut->IsFailed)
        return 0;

    if (pOut->Size + extra > pOut->Limit)
    {
        pOut->IsFailed = 1;
        return 0;
    }

    if (pOut->Size + extra <= pOut->Capacity)
        return 1;

    i64 newCapacity = pOut->Capacity * 2;
    if (newCapacity < pOut->Size + extra)
        newCapacity = pOut->Size + extra;
    if (newCapacity < 4096)
        newCapacity = 4096;

    u8* pNew = (u8*)sc_memory_allocate(newCapacity);
    if (pNew == ScNull)
    {
        pOut->IsFailed = 1;
        return 0;
    }

    if (pOut->Size > 0)
        memcpy(pNew, pOut->pData, pOut->Size);
    if (pOut->pData != ScNull)
        sc_memory_free(pOut->pData);

    pOut->pData = pNew;
    pOut->Capacity = newCapacity;
    return 1;
}

/*
  DOCS: Полный inflate (RFC 1951) с опциональным zlib-заголовком
  (RFC 1950). Пишет распакованные данные в pOut (Limit обязателен).
  Возвращает 0 при ошибке.
*/
static i32
sc_png_inflate(u8* pInput, i64 inputSize, i32 hasZlibHeader, ScPngOut* pOut)
{
    ScPngBits bits = {};
    bits.aBytes = pInput;
    bits.Size = inputSize;

    ScPngHuff fixedLitlen = {};
    ScPngHuff fixedDist = {};
    i32 isFixedBuilt = 0;

    if (hasZlibHeader)
    {
        if (inputSize < 2)
            return 0;

        u8 cmf = pInput[0];
        u8 flg = pInput[1];
        if ((cmf & 0x0f) != 8) // метод - только deflate
            return 0;
        if ((cmf >> 4) > 7) // окно не больше 32K
            return 0;
        if (((u32)cmf * 256 + flg) % 31 != 0) // FCHECK
            return 0;
        if (flg & 0x20) // preset dictionary
            return 0;

        bits.Pos = 2;
    }

    for (;;)
    {
        i32 isFinal = sc_png_bits_take(&bits, 1);
        i32 type = sc_png_bits_take(&bits, 2);
        if (bits.IsFailed)
            return 0;

        if (type == 0)
        {
            // DOCS: stored: выравнивание к границе байта (возврат целых
            // DOCS: байтов аккумулятора в поток), затем LEN/NLEN/данные.
            i32 drop = bits.Count & 7;
            bits.Bits >>= drop;
            bits.Count -= drop;
            bits.Pos -= bits.Count / 8;
            bits.Count = 0;
            bits.Bits = 0;

            if (bits.Pos + 4 > bits.Size)
                return 0;

            i32 len = pInput[bits.Pos] | (pInput[bits.Pos + 1] << 8);
            i32 nlen = pInput[bits.Pos + 2] | (pInput[bits.Pos + 3] << 8);
            bits.Pos += 4;

            if (len != (~nlen & 0xffff))
                return 0;

            if (len > 0)
            {
                if (bits.Pos + len > bits.Size)
                    return 0;
                if (!sc_png_out_reserve(pOut, len))
                    return 0;

                memcpy(pOut->pData + pOut->Size, pInput + bits.Pos, len);
                pOut->Size += len;
                bits.Pos += len;
            }
        }
        else if (type == 3)
        {
            return 0; // зарезервированный тип блока
        }
        else
        {
            ScPngHuff* pLitlen = ScNull;
            ScPngHuff* pDist = ScNull;

            if (type == 1)
            {
                // DOCS: fixed Huffman (RFC 1951, 3.2.6).
                if (!isFixedBuilt)
                {
                    i8 aLitLengths[288];
                    for (i32 i = 0; i < 144; ++i) aLitLengths[i] = 8;
                    for (i32 i = 144; i < 256; ++i) aLitLengths[i] = 9;
                    for (i32 i = 256; i < 280; ++i) aLitLengths[i] = 7;
                    for (i32 i = 280; i < 288; ++i) aLitLengths[i] = 8;

                    i8 aDistLengths[30];
                    for (i32 i = 0; i < 30; ++i) aDistLengths[i] = 5;

                    if (!sc_png_huff_build(&fixedLitlen, aLitLengths, 288))
                        return 0;
                    if (!sc_png_huff_build(&fixedDist, aDistLengths, 30))
                        return 0;

                    isFixedBuilt = 1;
                }

                pLitlen = &fixedLitlen;
                pDist = &fixedDist;
            }
            else
            {
                // DOCS: dynamic Huffman: заголовок блока (RFC 1951, 3.2.7).
                i32 hlit = sc_png_bits_take(&bits, 5) + 257;
                i32 hdist = sc_png_bits_take(&bits, 5) + 1;
                i32 hclen = sc_png_bits_take(&bits, 4) + 4;
                if (bits.IsFailed)
                    return 0;
                if (hlit > 286 || hdist > 30)
                    return 0;

                i8 aCodeLenLengths[19] = {};
                for (i32 i = 0; i < hclen; ++i)
                    aCodeLenLengths[aPngCodeLenOrder[i]] = (i8)sc_png_bits_take(&bits, 3);
                if (bits.IsFailed)
                    return 0;

                ScPngHuff codeLenHuff = {};
                if (!sc_png_huff_build(&codeLenHuff, aCodeLenLengths, 19))
                    return 0;

                // DOCS: длины литералов и дистанций одним массивом,
                // DOCS: кодами 16-18 (повторы/нули).
                i8 aLengths[286 + 30] = {};
                i32 total = hlit + hdist;
                i32 i = 0;

                while (i < total)
                {
                    i32 sym = sc_png_huff_decode(&bits, &codeLenHuff);
                    if (sym < 0)
                        return 0;

                    if (sym < 16)
                    {
                        aLengths[i] = (i8)sym;
                        ++i;
                    }
                    else if (sym == 16)
                    {
                        if (i == 0)
                            return 0;

                        i32 repeat = 3 + sc_png_bits_take(&bits, 2);
                        if (bits.IsFailed || i + repeat > total)
                            return 0;

                        while (repeat-- > 0)
                        {
                            aLengths[i] = aLengths[i - 1];
                            ++i;
                        }
                    }
                    else if (sym == 17)
                    {
                        i32 repeat = 3 + sc_png_bits_take(&bits, 3);
                        if (bits.IsFailed || i + repeat > total)
                            return 0;

                        i += repeat; // нули уже стоят
                    }
                    else
                    {
                        i32 repeat = 11 + sc_png_bits_take(&bits, 7);
                        if (bits.IsFailed || i + repeat > total)
                            return 0;

                        i += repeat;
                    }
                }

                ScPngHuff litlenHuff = {};
                ScPngHuff distHuff = {};
                if (!sc_png_huff_build(&litlenHuff, aLengths, hlit))
                    return 0;
                if (!sc_png_huff_build(&distHuff, aLengths + hlit, hdist))
                    return 0;

                pLitlen = &litlenHuff;
                pDist = &distHuff;
            }

            // DOCS: декодирование символов блока до end-of-block (256).
            for (;;)
            {
                i32 sym = sc_png_huff_decode(&bits, pLitlen);
                if (sym < 0 || bits.IsFailed)
                    return 0;

                if (sym < 256)
                {
                    if (!sc_png_out_reserve(pOut, 1))
                        return 0;

                    pOut->pData[pOut->Size] = (u8)sym;
                    ++pOut->Size;
                }
                else if (sym == 256)
                {
                    break;
                }
                else
                {
                    sym -= 257;
                    if (sym >= 29)
                        return 0;

                    i32 len = aPngLengthBase[sym]
                        + sc_png_bits_take(&bits, aPngLengthExtra[sym]);

                    i32 distSym = sc_png_huff_decode(&bits, pDist);
                    if (distSym < 0 || distSym >= 30 || bits.IsFailed)
                        return 0;

                    i32 dist = aPngDistBase[distSym]
                        + sc_png_bits_take(&bits, aPngDistExtra[distSym]);

                    if (bits.IsFailed)
                        return 0;
                    if (dist > pOut->Size)
                        return 0; // ссылка до начала данных

                    if (!sc_png_out_reserve(pOut, len))
                        return 0;

                    // NOTE: копирование байт за байтом - источник и приёмник
                    // NOTE: могут перекрываться (RLE-повторы с dist < len).
                    u8* pSrc = pOut->pData + pOut->Size - dist;
                    u8* pDst = pOut->pData + pOut->Size;
                    for (i32 k = 0; k < len; ++k)
                        pDst[k] = pSrc[k];
                    pOut->Size += len;
                }
            }
        }

        if (isFinal)
            break;
    }

    return 1;
}

/* ================================================================ */
/* Разбор PNG-файла.                                                */
/* ================================================================ */

/*
  DOCS: Проверка PNG magic: 137 80 78 71 13 10 26 10.
*/
static i32
sc_png_magic_is_valid(u8* aBytes, i64 dataSize)
{
    static const u8 aMagic[8] = { 137, 80, 78, 71, 13, 10, 26, 10 };
    return dataSize >= 8 && memcmp(aBytes, aMagic, sizeof(aMagic)) == 0;
}

/*
  DOCS: Один чанк PNG: длина, тип, данные, CRC (всё уже проверено
  на границы данных файла).
*/
typedef struct
{
    i64 Size;
    u8* pType;
    u8* pData;
    u32 CRC;
    i32 IsCrcOk;
} ScPngChunk;

typedef struct
{
    u8* aBytes;
    i64 Size;
    i64 Pos;
} ScPngChunks;

/*
  DOCS: Читает следующий чанк. Возвращает 0 при выходе за границы
  данных или переполнении длины. CRC проверяется для всех чанков.
*/
static i32
sc_png_chunk_next(ScPngChunks* pChunks, ScPngChunk* pChunk)
{
    if (pChunks->Pos + 12 > pChunks->Size)
        return 0;

    u8* pAt = pChunks->aBytes + pChunks->Pos;

    pChunk->Size = ((i64)pAt[0] << 24) | ((i64)pAt[1] << 16)
        | ((i64)pAt[2] << 8) | (i64)pAt[3];
    pChunk->pType = pAt + 4;
    pChunk->pData = pAt + 8;

    if (pChunk->Size > 0x7fffffff)
        return 0;
    if (pChunks->Pos + 12 + pChunk->Size > pChunks->Size)
        return 0;

    pChunk->CRC = ((u32)pAt[8 + pChunk->Size] << 24)
        | ((u32)pAt[9 + pChunk->Size] << 16)
        | ((u32)pAt[10 + pChunk->Size] << 8)
        | (u32)pAt[11 + pChunk->Size];

    u32 state = sc_png_crc32_run(0xffffffffu, pChunk->pType, 4 + pChunk->Size);
    pChunk->IsCrcOk = ((state ^ 0xffffffffu) == pChunk->CRC);

    pChunks->Pos += 12 + pChunk->Size;
    return 1;
}

/*
  DOCS: Предиктор Paeth (фильтр 4): ближайший к p = a + b - c
  из a (слева), b (сверху), c (сверху-слева).
*/
static u8
sc_png_paeth_predict(u8 a, u8 b, u8 c)
{
    i32 p = (i32)a + (i32)b - (i32)c;
    i32 pa = (p > a) ? (p - a) : (a - p);
    i32 pb = (p > b) ? (p - b) : (b - p);
    i32 pc = (p > c) ? (p - c) : (c - p);

    if (pa <= pb && pa <= pc)
        return a;
    if (pb <= pc)
        return b;
    return c;
}

/*
  DOCS: Снимает PNG-фильтр (0-4) с одной строки растра.
  pCur - строка (stride байт, фильтруется на месте), pPrev -
  предыдущая строка того же изображения/паса (для первой - нули),
  filterBytes - число байт на единицу фильтрации
  (ceil(rasterChannels * bitDepth / 8)).
  Возвращает 0 при неизвестном типе фильтра.
*/
static i32
sc_png_unfilter_row(u8 filterType, u8* pCur, u8* pPrev, i32 stride, i32 filterBytes)
{
    switch (filterType)
    {
    case SC_PNG_FILTER_NONE:
        break;

    case SC_PNG_FILTER_SUB:
        for (i32 i = filterBytes; i < stride; ++i)
            pCur[i] = (u8)(pCur[i] + pCur[i - filterBytes]);
        break;

    case SC_PNG_FILTER_UP:
        for (i32 i = 0; i < stride; ++i)
            pCur[i] = (u8)(pCur[i] + pPrev[i]);
        break;

    case SC_PNG_FILTER_AVERAGE:
        for (i32 i = 0; i < stride; ++i)
        {
            i32 left = (i >= filterBytes) ? pCur[i - filterBytes] : 0;
            pCur[i] = (u8)(pCur[i] + ((left + pPrev[i]) >> 1));
        }
        break;

    case SC_PNG_FILTER_PAETH:
        for (i32 i = 0; i < stride; ++i)
        {
            u8 left = (i >= filterBytes) ? pCur[i - filterBytes] : 0;
            u8 up = pPrev[i];
            u8 upLeft = (i >= filterBytes) ? pPrev[i - filterBytes] : 0;
            pCur[i] = (u8)(pCur[i] + sc_png_paeth_predict(left, up, upLeft));
        }
        break;

    default:
        return 0;
    }

    return 1;
}

/*
  DOCS: Сэмпл sampleIndex из строки (MSB-first упаковка бит).
  Глубина 1: 8 пикселей в байте, 2: 4, 4: 2, 8/16: подряд.
*/
static u16
sc_png_row_sample(u8* pRow, i32 sampleIndex, i32 bitDepth)
{
    switch (bitDepth)
    {
    case 8:
        return pRow[sampleIndex];
    case 16:
        return (u16)((pRow[sampleIndex * 2] << 8) | pRow[sampleIndex * 2 + 1]);
    case 1:
        return (pRow[sampleIndex >> 3] >> (7 - (sampleIndex & 7))) & 1;
    case 2:
        return (pRow[sampleIndex >> 2] >> (6 - 2 * (sampleIndex & 3))) & 3;
    case 4:
        return (pRow[sampleIndex >> 1] >> (4 - 4 * (sampleIndex & 1))) & 15;
    default:
        return 0;
    }
}

/*
  DOCS: Размеры подизображения паса Adam7 (0..6); 0x0 - пас пуст.
*/
static void
sc_png_pass_dimensions(i32 width, i32 height, i32 pass, i32* pPassWidth, i32* pPassHeight)
{
    i32 xs = aPngXStart[pass];
    i32 ys = aPngYStart[pass];

    *pPassWidth = (width > xs)
        ? ((width - xs + aPngXStep[pass] - 1) / aPngXStep[pass]) : 0;
    *pPassHeight = (height > ys)
        ? ((height - ys + aPngYStep[pass] - 1) / aPngYStep[pass]) : 0;
}

/*
  DOCS: Приводит сэмпл к 8 битам (для 16 бит - округлённое деление,
  как у stb: (v * 255 + 32895) >> 16).
*/
static u8
sc_png_sample_to_8(u16 sample, i32 bitDepth)
{
    switch (bitDepth)
    {
    case 16:
        return (u8)(((u32)sample * 255u + 32895u) >> 16);
    case 8:
        return (u8)sample;
    case 4:
        return (u8)(sample * 17);
    case 2:
        return (u8)(sample * 85);
    case 1:
        return (u8)(sample * 255);
    default:
        return 0;
    }
}

/*
  DOCS: Декодирует PNG-данные из памяти: чанки -> склейка IDAT ->
  inflate -> снятие фильтров по строкам/пасам -> сэмплы ->
  сборка пикселей (палитра, tRNS, масштабирование, каналы).
*/
void*
sc_png_decode(void* pData, i64 dataSize, ScImageDesc* pDesc, i32 channels)
{
    sc_assert_not_null(pData);
    sc_assert_not_null(pDesc);

    if (pData == ScNull || pDesc == ScNull
        || !sc_image_data_size_is_valid(dataSize)
        || !sc_image_decode_channels_is_valid(channels)
        || !sc_png_magic_is_valid((u8*)pData, dataSize))
    {
        return ScNull;
    }

    /* состояние разбора */
    i32 width = 0;
    i32 height = 0;
    i32 colorType = 0;
    i32 bitDepth = 0;
    i32 interlace = 0;
    i32 hasIhdr = 0;
    i32 hasIdat = 0;
    i32 hasIend = 0;

    u8* aPalette = ScNull;
    i32 paletteCount = 0;
    u8* aTransIndex = ScNull;
    i32 transCount = 0;
    u16 transGrey = 0;
    u16 aTransRgb[3] = {};
    i32 hasTransColor = 0;

    ScImageBuffer idat = {};

    /* NOTE: out объявлена до цикла чанков: метка очистки освобождает её
       при любом раннем выходе. */
    ScPngOut out = {};

    ScPngChunks chunks = {};
    chunks.aBytes = (u8*)pData + 8;
    chunks.Size = dataSize - 8;

    ScPngChunk chunk = {};
    while (sc_png_chunk_next(&chunks, &chunk))
    {
        if (!chunk.IsCrcOk)
            break;

        if (memcmp(chunk.pType, "IHDR", 4) == 0)
        {
            if (hasIhdr || chunk.Size != 13)
                break;

            width = (i32)(((u32)chunk.pData[0] << 24) | ((u32)chunk.pData[1] << 16)
                | ((u32)chunk.pData[2] << 8) | chunk.pData[3]);
            height = (i32)(((u32)chunk.pData[4] << 24) | ((u32)chunk.pData[5] << 16)
                | ((u32)chunk.pData[6] << 8) | chunk.pData[7]);
            bitDepth = chunk.pData[8];
            colorType = chunk.pData[9];
            interlace = chunk.pData[12];

            // DOCS: compression (10) и filter (11) обязаны быть 0.
            if (chunk.pData[10] != 0 || chunk.pData[11] != 0)
                break;
            if (width <= 0 || height <= 0
                || width > SC_PNG_MAX_DIMENSIONS || height > SC_PNG_MAX_DIMENSIONS)
                break;
            if ((i64)width * height > SC_PNG_PIXELS_MAX)
                break;
            if (interlace != 0 && interlace != 1)
                break;

            // DOCS: допустимые глубины по цветовым типам (спецификация).
            i32 isDepthOk = 0;
            switch (colorType)
            {
            case SC_PNG_COLOR_GREY:
                isDepthOk = (bitDepth == 1 || bitDepth == 2 || bitDepth == 4
                    || bitDepth == 8 || bitDepth == 16);
                break;
            case SC_PNG_COLOR_RGB:
            case SC_PNG_COLOR_GREY_ALPHA:
            case SC_PNG_COLOR_RGBA:
                isDepthOk = (bitDepth == 8 || bitDepth == 16);
                break;
            case SC_PNG_COLOR_INDEXED:
                isDepthOk = (bitDepth == 1 || bitDepth == 2 || bitDepth == 4
                    || bitDepth == 8);
                break;
            default:
                isDepthOk = 0;
                break;
            }
            if (!isDepthOk)
                break;

            hasIhdr = 1;
        }
        else if (memcmp(chunk.pType, "PLTE", 4) == 0)
        {
            if (!hasIhdr || chunk.Size == 0 || chunk.Size % 3 != 0 || chunk.Size > 256 * 3)
                break;

            // DOCS: PLTE обязателен для indexed; для grey/grey+alpha - ошибка.
            if (colorType == SC_PNG_COLOR_GREY || colorType == SC_PNG_COLOR_GREY_ALPHA)
                break;

            if (colorType == SC_PNG_COLOR_INDEXED)
            {
                aPalette = (u8*)sc_memory_allocate(chunk.Size);
                if (aPalette == ScNull)
                    break;

                memcpy(aPalette, chunk.pData, chunk.Size);
                paletteCount = (i32)(chunk.Size / 3);
            }

            // NOTE: для rgb/rgba PLTE - только подсказка палитры, пропускаем.
        }
        else if (memcmp(chunk.pType, "tRNS", 4) == 0)
        {
            if (!hasIhdr || hasTransColor || aTransIndex != ScNull)
                break;

            if (colorType == SC_PNG_COLOR_INDEXED)
            {
                if (chunk.Size > 256)
                    break;

                aTransIndex = (u8*)sc_memory_allocate(chunk.Size == 0 ? 1 : chunk.Size);
                if (aTransIndex == ScNull)
                    break;

                memcpy(aTransIndex, chunk.pData, chunk.Size);
                transCount = (i32)chunk.Size;
            }
            else if (colorType == SC_PNG_COLOR_GREY)
            {
                if (chunk.Size != 2)
                    break;

                transGrey = (u16)((chunk.pData[0] << 8) | chunk.pData[1]);
                hasTransColor = 1;
            }
            else if (colorType == SC_PNG_COLOR_RGB)
            {
                if (chunk.Size != 6)
                    break;

                for (i32 c = 0; c < 3; ++c)
                    aTransRgb[c] = (u16)((chunk.pData[c * 2] << 8) | chunk.pData[c * 2 + 1]);
                hasTransColor = 1;
            }
            else
            {
                break; // tRNS не допускается для grey+alpha / rgba
            }
        }
        else if (memcmp(chunk.pType, "IDAT", 4) == 0)
        {
            if (!hasIhdr || hasIend)
                break;

            // DOCS: несколько IDAT подряд - части одного zlib-потока.
            if (idat.Count == 0)
                sc_image_buffer_init(&idat, chunk.Size == 0 ? 64 : chunk.Size);
            else if (idat.pData == ScNull)
                break;

            if (chunk.Size > 0)
            {
                sc_image_buffer_write(&idat, chunk.pData, (i32)chunk.Size);
                if (idat.pData == ScNull)
                    break;
            }

            hasIdat = 1;
        }
        else if (memcmp(chunk.pType, "IEND", 4) == 0)
        {
            hasIend = 1;
            break;
        }

        // NOTE: остальные чанки (ancillary) пропускаются.
    }

    u8* pPixels = ScNull;

    if (!hasIhdr || !hasIdat || !hasIend)
        goto DecodeFailLabel;

    if (colorType == SC_PNG_COLOR_INDEXED && aPalette == ScNull)
        goto DecodeFailLabel; // indexed без PLTE

    /*
      DOCS: каналы заголовка - что реально лежит в растре. Для indexed
      DOCS: это 1 индекс на пиксель; rgb/grey+alpha/rgba - по спецификации.
      DOCS: fileChannels - каналы вывода (палитра раскрывается в rgb,
      DOCS: tRNS добавляет alpha).
    */
    i32 hdrChannels = 1;
    switch (colorType)
    {
    case SC_PNG_COLOR_RGB:
        hdrChannels = 3;
        break;
    case SC_PNG_COLOR_GREY_ALPHA:
        hdrChannels = 2;
        break;
    case SC_PNG_COLOR_RGBA:
        hdrChannels = 4;
        break;
    default:
        break;
    }

    i32 rasterChannels = (colorType == SC_PNG_COLOR_INDEXED) ? 1 : hdrChannels;

    i32 fileChannels = hdrChannels;
    if (colorType == SC_PNG_COLOR_INDEXED)
        fileChannels = 3;
    if (hasTransColor)
    {
        if (colorType == SC_PNG_COLOR_GREY)
            fileChannels = 2;
        else if (colorType == SC_PNG_COLOR_RGB)
            fileChannels = 4;
    }
    if (colorType == SC_PNG_COLOR_INDEXED && aTransIndex != ScNull)
        fileChannels = 4;

    sc_image_desc_fill(pDesc, width, height, fileChannels, channels);

    /* inflate */
    i32 bppBits = rasterChannels * bitDepth;
    i32 filterBytes = (bppBits + 7) / 8;
    i32 stride = (width * bppBits + 7) / 8;

    i64 expectedRaw = 0;
    if (interlace == 0)
    {
        expectedRaw = (i64)height * (stride + 1);
    }
    else
    {
        for (i32 pass = 0; pass < 7; ++pass)
        {
            i32 passWidth = 0;
            i32 passHeight = 0;
            sc_png_pass_dimensions(width, height, pass, &passWidth, &passHeight);

            if (passWidth == 0 || passHeight == 0)
                continue;

            i32 passStride = (passWidth * bppBits + 7) / 8;
            expectedRaw += (i64)passHeight * (passStride + 1);
        }
    }

    out.Limit = expectedRaw;

    if (!sc_png_inflate(idat.pData, idat.Count, 1, &out))
        goto DecodeFailLabel;

    if (out.Size < expectedRaw)
        goto DecodeFailLabel;

    /* снятие фильтров и разбор сэмплов */
    u16* aSamples = (u16*)sc_memory_allocate((i64)width * height * rasterChannels * sizeof(u16));
    u8* pRow = (u8*)sc_memory_allocate(stride);
    u8* pPrevRow = (u8*)sc_memory_allocate(stride);

    if (aSamples == ScNull || pRow == ScNull || pPrevRow == ScNull)
    {
        sc_memory_free(aSamples);
        sc_memory_free(pRow);
        sc_memory_free(pPrevRow);
        goto DecodeFailLabel;
    }

    i64 rawPos = 0;
    i32 passCount = (interlace != 0) ? 7 : 1;
    i32 isDecoded = 1;

    for (i32 pass = 0; pass < passCount && isDecoded; ++pass)
    {
        i32 passWidth = width;
        i32 passHeight = height;

        if (interlace != 0)
            sc_png_pass_dimensions(width, height, pass, &passWidth, &passHeight);

        if (passWidth == 0 || passHeight == 0)
            continue;

        i32 passStride = (passWidth * bppBits + 7) / 8;

        // DOCS: предыдущая строка паса - нули (фильтры первой строки
        // DOCS: используют 0 вместо "сверху").
        memset(pPrevRow, 0, passStride);

        for (i32 py = 0; py < passHeight && isDecoded; ++py)
        {
            u8 filterType = out.pData[rawPos];
            ++rawPos;

            memcpy(pRow, out.pData + rawPos, passStride);
            rawPos += passStride;

            if (!sc_png_unfilter_row(filterType, pRow, pPrevRow, passStride, filterBytes))
            {
                isDecoded = 0;
                break;
            }

            // DOCS: раскладываем сэмплы строки на канве.
            for (i32 px = 0; px < passWidth; ++px)
            {
                i32 canvasX = px;
                i32 canvasY = py;

                if (interlace != 0)
                {
                    canvasX = aPngXStart[pass] + px * aPngXStep[pass];
                    canvasY = aPngYStart[pass] + py * aPngYStep[pass];
                }

                u16* pDest = aSamples + ((i64)canvasY * width + canvasX) * rasterChannels;
                for (i32 c = 0; c < rasterChannels; ++c)
                    pDest[c] = sc_png_row_sample(pRow, px * rasterChannels + c, bitDepth);
            }

            memcpy(pPrevRow, pRow, passStride);
        }
    }

    if (!isDecoded)
    {
        sc_memory_free(aSamples);
        sc_memory_free(pRow);
        sc_memory_free(pPrevRow);
        goto DecodeFailLabel;
    }

    /* сборка пикселей */
    pPixels = (u8*)sc_memory_allocate((i64)width * height * pDesc->Channels);
    if (pPixels == ScNull)
    {
        sc_memory_free(aSamples);
        sc_memory_free(pRow);
        sc_memory_free(pPrevRow);
        goto DecodeFailLabel;
    }

    for (i32 py = 0; py < height; ++py)
    {
        for (i32 px = 0; px < width; ++px)
        {
            u16* pSrc = aSamples + ((i64)py * width + px) * rasterChannels;

            u8 r = 0;
            u8 g = 0;
            u8 b = 0;
            u8 a = 255;

            switch (colorType)
            {
            case SC_PNG_COLOR_GREY:
            {
                u16 sample = pSrc[0];
                r = g = b = sc_png_sample_to_8(sample, bitDepth);
                if (hasTransColor && sample == transGrey)
                    a = 0;
                break;
            }

            case SC_PNG_COLOR_GREY_ALPHA:
            {
                r = g = b = sc_png_sample_to_8(pSrc[0], bitDepth);
                a = sc_png_sample_to_8(pSrc[1], bitDepth);
                break;
            }

            case SC_PNG_COLOR_RGB:
            {
                u16 sampleR = pSrc[0];
                u16 sampleG = pSrc[1];
                u16 sampleB = pSrc[2];
                r = sc_png_sample_to_8(sampleR, bitDepth);
                g = sc_png_sample_to_8(sampleG, bitDepth);
                b = sc_png_sample_to_8(sampleB, bitDepth);
                if (hasTransColor && sampleR == aTransRgb[0]
                    && sampleG == aTransRgb[1] && sampleB == aTransRgb[2])
                {
                    a = 0;
                }
                break;
            }

            case SC_PNG_COLOR_RGBA:
            {
                r = sc_png_sample_to_8(pSrc[0], bitDepth);
                g = sc_png_sample_to_8(pSrc[1], bitDepth);
                b = sc_png_sample_to_8(pSrc[2], bitDepth);
                a = sc_png_sample_to_8(pSrc[3], bitDepth);
                break;
            }

            case SC_PNG_COLOR_INDEXED:
            {
                i32 index = pSrc[0];
                if (index < paletteCount)
                {
                    r = aPalette[index * 3 + 0];
                    g = aPalette[index * 3 + 1];
                    b = aPalette[index * 3 + 2];
                }
                a = (index < transCount) ? aTransIndex[index] : 255;
                break;
            }

            default:
                break;
            }

            // DOCS: приведение к запрошенному числу каналов (как stb:
            // DOCS: Y = (r*77 + g*150 + b*29) >> 8; источники без
            // DOCS: альфы получают 255).
            u8 y = (u8)((r * 77 + g * 150 + b * 29) >> 8);
            u8 srcAlpha = (fileChannels == 2 || fileChannels == 4) ? a : 255;

            u8* pDst = pPixels + ((i64)py * width + px) * pDesc->Channels;
            switch (pDesc->Channels)
            {
            case 1:
                pDst[0] = y;
                break;
            case 2:
                pDst[0] = y;
                pDst[1] = srcAlpha;
                break;
            case 3:
                pDst[0] = r;
                pDst[1] = g;
                pDst[2] = b;
                break;
            case 4:
                pDst[0] = r;
                pDst[1] = g;
                pDst[2] = b;
                pDst[3] = a;
                break;
            default:
                break;
            }
        }
    }

    sc_memory_free(aSamples);
    sc_memory_free(pRow);
    sc_memory_free(pPrevRow);

    sc_memory_free(aPalette);
    sc_memory_free(aTransIndex);
    sc_image_buffer_destroy(&idat);
    sc_memory_free(out.pData);
    return pPixels;

DecodeFailLabel:
    pDesc->Width = 0;
    pDesc->Height = 0;
    pDesc->Channels = 0;

    sc_memory_free(pPixels);
    sc_memory_free(aPalette);
    sc_memory_free(aTransIndex);
    sc_image_buffer_destroy(&idat);
    sc_memory_free(out.pData);
    return ScNull;
}

/* ================================================================ */
/* Кодирование PNG.                                                 */
/* ================================================================ */

/*
  DOCS: Битовый писатель deflate: биты LSB-first, байты little-endian.
  Пишет в растущий ScImageBuffer.
*/
typedef struct
{
    ScImageBuffer* pBuffer;
    u32 Bits;
    i32 Count;
} ScPngBitWriter;

static i32
sc_png_writer_put_bits(ScPngBitWriter* pWriter, u32 value, i32 count)
{
    if (count < 0 || count > 24)
        return 0;

    pWriter->Bits |= (value << pWriter->Count);
    pWriter->Count += count;

    while (pWriter->Count >= 8)
    {
        u8 byte = (u8)(pWriter->Bits & 0xff);
        sc_image_buffer_write(pWriter->pBuffer, &byte, 1);

        if (pWriter->pBuffer->pData == ScNull)
            return 0; // нехватка памяти во время записи

        pWriter->Bits >>= 8;
        pWriter->Count -= 8;
    }

    return 1;
}

static i32
sc_png_writer_flush(ScPngBitWriter* pWriter)
{
    if (pWriter->Count > 0)
    {
        u8 byte = (u8)(pWriter->Bits & 0xff);
        sc_image_buffer_write(pWriter->pBuffer, &byte, 1);
        pWriter->Bits = 0;
        pWriter->Count = 0;
    }

    return pWriter->pBuffer->pData != ScNull;
}

/*
  DOCS: Реверс бит (deflate пишет коды старшим битом вперёд).
*/
static u32
sc_png_rev_bits(u32 value, i32 count)
{
    u32 result = 0;
    for (i32 i = 0; i < count; ++i)
    {
        result = (result << 1) | (value & 1);
        value >>= 1;
    }
    return result;
}

/*
  DOCS: Сжимает данные одним final-блоком deflate с fixed Huffman
  (RFC 1951, 3.2.6) и жадным LZ77 (хеш-цепочки по 3 байтам,
  окно 32K). Результат дописывается в pBuffer.
  Возвращает 0 при ошибке.
*/
static i32
sc_png_deflate_fixed(ScImageBuffer* pBuffer, u8* pData, i64 size)
{
    ScPngBitWriter writer = {};
    writer.pBuffer = pBuffer;

    // DOCS: заголовок блока: BFINAL=1, BTYPE=01 (fixed).
    if (!sc_png_writer_put_bits(&writer, 1, 1))
        return 0;
    if (!sc_png_writer_put_bits(&writer, 1, 2))
        return 0;

    static i32 isInit = 0;
    static u32 aLitCode[288];
    static i32 aLitBits[288];
    static u32 aDistCode[30];

    if (!isInit)
    {
        for (i32 sym = 0; sym < 288; ++sym)
        {
            i32 bits = 0;
            u32 code = 0;

            if (sym < 144)
            {
                bits = 8;
                code = 0x30 + sym;
            }
            else if (sym < 256)
            {
                bits = 9;
                code = 0x190 + (sym - 144);
            }
            else if (sym < 280)
            {
                bits = 7;
                code = sym - 256;
            }
            else
            {
                bits = 8;
                code = 0xc0 + (sym - 280);
            }

            aLitBits[sym] = bits;
            aLitCode[sym] = sc_png_rev_bits(code, bits);
        }

        for (i32 sym = 0; sym < 30; ++sym)
            aDistCode[sym] = sc_png_rev_bits((u32)sym, 5);

        isInit = 1;
    }

    i32* aHead = (i32*)sc_memory_allocate(SC_PNG_HASH_SIZE * sizeof(i32));
    i32* aPrev = (i32*)sc_memory_allocate(SC_PNG_WINDOW_SIZE * sizeof(i32));

    if (aHead == ScNull || aPrev == ScNull)
    {
        sc_memory_free(aHead);
        sc_memory_free(aPrev);
        return 0;
    }

    for (i64 i = 0; i < SC_PNG_HASH_SIZE; ++i)
        aHead[i] = -1;

    i64 pos = 0;
    while (pos < size)
    {
        i32 bestLen = 0;
        i64 bestDist = 0;

        if (pos + SC_PNG_MIN_MATCH <= size)
        {
            // DOCS: хеш тройки байтов (умножение Кнута, 15 бит).
            u32 hash = ((u32)pData[pos] << 16) | ((u32)pData[pos + 1] << 8) | pData[pos + 2];
            hash = (hash * 2654435761u) >> 17;
            hash &= SC_PNG_HASH_SIZE - 1;

            i32 candidate = aHead[hash];
            i32 chain = 0;

            while (candidate >= 0 && chain < SC_PNG_MAX_CHAIN)
            {
                i64 dist = pos - candidate;
                if (dist <= 0 || dist > SC_PNG_WINDOW_SIZE)
                    break;

                i32 maxLen = (i32)(size - pos);
                if (maxLen > SC_PNG_MAX_MATCH)
                    maxLen = SC_PNG_MAX_MATCH;

                i32 len = 0;
                while (len < maxLen && pData[candidate + len] == pData[pos + len])
                    ++len;

                if (len > bestLen)
                {
                    bestLen = len;
                    bestDist = dist;
                }

                if (bestLen >= SC_PNG_MAX_MATCH)
                    break;

                candidate = aPrev[candidate & (SC_PNG_WINDOW_SIZE - 1)];
                ++chain;
            }

            // DOCS: вставляем текущую позицию в цепочку.
            aPrev[pos & (SC_PNG_WINDOW_SIZE - 1)] = aHead[hash];
            aHead[hash] = (i32)pos;
        }

        if (bestLen >= SC_PNG_MIN_MATCH)
        {
            // DOCS: пара (len, dist).
            i32 lenSym = 0;
            while (lenSym < 28 && aPngLengthBase[lenSym + 1] <= bestLen)
                ++lenSym;

            if (!sc_png_writer_put_bits(&writer, aLitCode[257 + lenSym], aLitBits[257 + lenSym]))
                goto DeflateFailLabel;

            if (aPngLengthExtra[lenSym] > 0)
            {
                if (!sc_png_writer_put_bits(&writer,
                        (u32)(bestLen - aPngLengthBase[lenSym]), aPngLengthExtra[lenSym]))
                {
                    goto DeflateFailLabel;
                }
            }

            i32 distSym = 0;
            while (distSym < 29 && aPngDistBase[distSym + 1] <= bestDist)
                ++distSym;

            if (!sc_png_writer_put_bits(&writer, aDistCode[distSym], 5))
                goto DeflateFailLabel;

            if (aPngDistExtra[distSym] > 0)
            {
                if (!sc_png_writer_put_bits(&writer,
                        (u32)(bestDist - aPngDistBase[distSym]), aPngDistExtra[distSym]))
                {
                    goto DeflateFailLabel;
                }
            }

            pos += bestLen;
        }
        else
        {
            // DOCS: литерал.
            u8 literal = pData[pos];
            if (!sc_png_writer_put_bits(&writer, aLitCode[literal], aLitBits[literal]))
                goto DeflateFailLabel;

            ++pos;
        }
    }

    // DOCS: end-of-block (256).
    if (!sc_png_writer_put_bits(&writer, aLitCode[256], aLitBits[256]))
        goto DeflateFailLabel;

    if (!sc_png_writer_flush(&writer))
        goto DeflateFailLabel;

    sc_memory_free(aHead);
    sc_memory_free(aPrev);
    return 1;

DeflateFailLabel:
    sc_memory_free(aHead);
    sc_memory_free(aPrev);
    return 0;
}

/*
  DOCS: Применяет фильтр filterType к строке (encode-сторона):
  pRaw - исходная строка, pPrevRaw - предыдущая исходная строка,
  результат в pFiltered (stride байт).
*/
static void
sc_png_filter_row(u8 filterType, u8* pRaw, u8* pPrevRaw, u8* pFiltered, i32 stride, i32 filterBytes)
{
    switch (filterType)
    {
    case SC_PNG_FILTER_NONE:
        memcpy(pFiltered, pRaw, stride);
        break;

    case SC_PNG_FILTER_SUB:
        for (i32 i = 0; i < filterBytes; ++i)
            pFiltered[i] = pRaw[i];
        for (i32 i = filterBytes; i < stride; ++i)
            pFiltered[i] = (u8)(pRaw[i] - pRaw[i - filterBytes]);
        break;

    case SC_PNG_FILTER_UP:
        for (i32 i = 0; i < stride; ++i)
            pFiltered[i] = (u8)(pRaw[i] - pPrevRaw[i]);
        break;

    case SC_PNG_FILTER_AVERAGE:
        for (i32 i = 0; i < stride; ++i)
        {
            i32 left = (i >= filterBytes) ? pRaw[i - filterBytes] : 0;
            pFiltered[i] = (u8)(pRaw[i] - ((left + pPrevRaw[i]) >> 1));
        }
        break;

    case SC_PNG_FILTER_PAETH:
        for (i32 i = 0; i < stride; ++i)
        {
            u8 left = (i >= filterBytes) ? pRaw[i - filterBytes] : 0;
            u8 upLeft = (i >= filterBytes) ? pPrevRaw[i - filterBytes] : 0;
            pFiltered[i] = (u8)(pRaw[i] - sc_png_paeth_predict(left, pPrevRaw[i], upLeft));
        }
        break;

    default:
        break;
    }
}

/*
  DOCS: Фильтрует всё изображение в pOut (Height строк по
  (stride + 1) байт: тип фильтра + строка). Фильтр каждой строки
  выбирается эвристикой "минимальная сумма модулей отфильтрованных
  байт" (как libpng/stb_image_write).
*/
static void
sc_png_filter_image(u8* pOut, u8* pPixels, i32 height, i32 stride, i32 filterBytes)
{
    u8* pFiltered = (u8*)sc_memory_allocate(stride);
    u8* pBest = (u8*)sc_memory_allocate(stride);
    u8* pZeroRow = (u8*)sc_memory_allocate(stride);

    if (pFiltered == ScNull || pBest == ScNull || pZeroRow == ScNull)
    {
        // NOTE: нехватка памяти - fallback на фильтр None без выбора.
        for (i32 y = 0; y < height; ++y)
        {
            pOut[(i64)y * (stride + 1)] = SC_PNG_FILTER_NONE;
            memcpy(pOut + (i64)y * (stride + 1) + 1, pPixels + (i64)y * stride, stride);
        }

        sc_memory_free(pFiltered);
        sc_memory_free(pBest);
        sc_memory_free(pZeroRow);
        return;
    }

    // DOCS: строка над первой - нули (Up/Average/Paeth первой строки
    // DOCS: используют 0 вместо "сверху", как при декодировании).
    memset(pZeroRow, 0, stride);

    for (i32 y = 0; y < height; ++y)
    {
        u8* pRaw = pPixels + (i64)y * stride;
        u8* pUp = (y > 0) ? (pPixels + (i64)(y - 1) * stride) : pZeroRow;

        i32 bestFilter = SC_PNG_FILTER_NONE;
        memcpy(pBest, pRaw, stride);
        i64 bestEstimate = 0;
        for (i32 i = 0; i < stride; ++i)
        {
            i32 v = (i8)pBest[i];
            bestEstimate += (v < 0) ? -v : v;
        }

        for (i32 filter = SC_PNG_FILTER_SUB; filter <= SC_PNG_FILTER_PAETH; ++filter)
        {
            sc_png_filter_row((u8)filter, pRaw, pUp, pFiltered, stride, filterBytes);

            i64 estimate = 0;
            for (i32 i = 0; i < stride; ++i)
            {
                i32 v = (i8)pFiltered[i];
                estimate += (v < 0) ? -v : v;
            }

            if (estimate < bestEstimate)
            {
                bestEstimate = estimate;
                bestFilter = filter;
                memcpy(pBest, pFiltered, stride);
            }
        }

        pOut[(i64)y * (stride + 1)] = (u8)bestFilter;
        memcpy(pOut + (i64)y * (stride + 1) + 1, pBest, stride);
    }

    sc_memory_free(pFiltered);
    sc_memory_free(pBest);
    sc_memory_free(pZeroRow);
}

/*
  DOCS: Пишет чанк PNG: [длина BE][тип][данные][CRC32 BE].
  pData может быть ScNull при size == 0.
*/
static i32
sc_png_write_chunk(ScImageBuffer* pBuffer, const char* pType, u8* pData, i64 size)
{
    u8 aHeader[8];
    aHeader[0] = (u8)(size >> 24);
    aHeader[1] = (u8)(size >> 16);
    aHeader[2] = (u8)(size >> 8);
    aHeader[3] = (u8)size;
    for (i32 i = 0; i < 4; ++i)
        aHeader[4 + i] = (u8)pType[i];

    sc_image_buffer_write(pBuffer, aHeader, 8);

    if (size > 0)
        sc_image_buffer_write(pBuffer, pData, (i32)size);

    u32 state = sc_png_crc32_run(0xffffffffu, aHeader + 4, 4);
    if (size > 0)
        state = sc_png_crc32_run(state, pData, size);

    u32 crc = state ^ 0xffffffffu;
    u8 aCrc[4];
    aCrc[0] = (u8)(crc >> 24);
    aCrc[1] = (u8)(crc >> 16);
    aCrc[2] = (u8)(crc >> 8);
    aCrc[3] = (u8)crc;

    sc_image_buffer_write(pBuffer, aCrc, 4);
    return pBuffer->pData != ScNull;
}

/*
  DOCS: Кодирует сырые пиксели (8 бит на канал, comp 1..4) в PNG:
  сигнатура + IHDR + один IDAT (zlib: CMF/FLG + deflate fixed +
  Adler32) + IEND.
*/
void*
sc_png_encode(void* pData, ScImageDesc desc, i64* pLength)
{
    sc_assert_not_null(pData);
    sc_assert_not_null(pLength);

    if (pData == ScNull || pLength == ScNull
        || !sc_image_desc_is_valid_for_encode(desc))
    {
        return ScNull;
    }

    if ((i64)desc.Width * desc.Height > SC_PNG_PIXELS_MAX)
        return ScNull;

    i32 stride = desc.Width * desc.Channels;
    i64 rawSize = (i64)desc.Height * (stride + 1);
    if (rawSize > SC_IMAGE_DATA_SIZE_MAX)
        return ScNull;

    // DOCS: цветовой тип по числу каналов (8 бит на канал, без interlace).
    i32 colorType = 0;
    switch (desc.Channels)
    {
    case 1: colorType = SC_PNG_COLOR_GREY; break;
    case 2: colorType = SC_PNG_COLOR_GREY_ALPHA; break;
    case 3: colorType = SC_PNG_COLOR_RGB; break;
    case 4: colorType = SC_PNG_COLOR_RGBA; break;
    default: return ScNull;
    }

    ScImageBuffer out = {};
    sc_image_buffer_init(&out, rawSize + rawSize / 8 + 1024);

    u8* pRaw = (u8*)sc_memory_allocate(rawSize);
    if (out.pData == ScNull || pRaw == ScNull)
    {
        sc_image_buffer_destroy(&out);
        sc_memory_free(pRaw);
        return ScNull;
    }

    sc_png_filter_image(pRaw, (u8*)pData, desc.Height, stride, desc.Channels);

    static const u8 aSignature[8] = { 137, 80, 78, 71, 13, 10, 26, 10 };
    sc_image_buffer_write(&out, (void*)aSignature, 8);

    u8 aIhdr[13];
    aIhdr[0] = (u8)(desc.Width >> 24);
    aIhdr[1] = (u8)(desc.Width >> 16);
    aIhdr[2] = (u8)(desc.Width >> 8);
    aIhdr[3] = (u8)desc.Width;
    aIhdr[4] = (u8)(desc.Height >> 24);
    aIhdr[5] = (u8)(desc.Height >> 16);
    aIhdr[6] = (u8)(desc.Height >> 8);
    aIhdr[7] = (u8)desc.Height;
    aIhdr[8] = 8; // bit depth
    aIhdr[9] = (u8)colorType;
    aIhdr[10] = 0; // compression: deflate
    aIhdr[11] = 0; // filter: adaptive
    aIhdr[12] = 0; // interlace: none
    sc_png_write_chunk(&out, "IHDR", aIhdr, 13);

    // DOCS: IDAT = zlib-поток: CMF=0x78 (deflate, 32K), FLG=0x01 (FCHECK ok).
    ScImageBuffer zbuf = {};
    sc_image_buffer_init(&zbuf, rawSize / 2 + 256);

    u8 aZlibHeader[2] = { 0x78, 0x01 };
    sc_image_buffer_write(&zbuf, aZlibHeader, 2);

    i32 isOk = sc_png_deflate_fixed(&zbuf, pRaw, rawSize);

    u32 adler = sc_png_adler32(pRaw, rawSize);
    u8 aAdler[4];
    aAdler[0] = (u8)(adler >> 24);
    aAdler[1] = (u8)(adler >> 16);
    aAdler[2] = (u8)(adler >> 8);
    aAdler[3] = (u8)adler;

    if (isOk)
        sc_image_buffer_write(&zbuf, aAdler, 4);

    if (isOk && zbuf.pData != ScNull && zbuf.Count > 6)
    {
        sc_png_write_chunk(&out, "IDAT", zbuf.pData, zbuf.Count);
        sc_png_write_chunk(&out, "IEND", ScNull, 0);
    }

    sc_image_buffer_destroy(&zbuf);
    sc_memory_free(pRaw);

    if (out.pData == ScNull || out.Count == 0)
    {
        sc_image_buffer_destroy(&out);
        return ScNull;
    }

    *pLength = out.Count;
    return out.pData;
}

void*
sc_png_read(char* pPath, ScImageDesc* pDesc, i32 channels)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pDesc);

    if (pPath == ScNull || pDesc == ScNull)
        return ScNull;

    i64 dataSize = 0;
    void* pData = sc_file_read_ext(pPath, &dataSize);
    if (pData == ScNull)
        return ScNull;

    void* pPixels = sc_png_decode(pData, dataSize, pDesc, channels);

    sc_memory_free(pData);
    return pPixels;
}

i64
sc_png_write(char* pPath, void* pData, ScImageDesc desc)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pData);

    if (pPath == ScNull || pData == ScNull)
        return 0;

    i64 length = 0;
    void* pEncoded = sc_png_encode(pData, desc, &length);
    if (pEncoded == ScNull)
        return 0;

    sc_file_write(pPath, pEncoded, length);

    sc_memory_free(pEncoded);
    return length;
}

