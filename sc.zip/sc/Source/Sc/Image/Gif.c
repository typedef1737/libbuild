/*
  DOCS: GIF - Graphics Interchange Format. Нативная реализация
  (без stb): заголовок/LSD/GCT, Image Descriptor с LCT и interlace,
  LZW-декодер растра, Graphic Control Extension (прозрачность, delay,
  disposal), анимация с накоплением кадров на канве.

  Структура GIF-потока:
    Header "GIF87a"/"GIF89a" + Logical Screen Descriptor (+ GCT),
    затем блоки: 0x2C Image Descriptor (+ LCT, LZW-растр),
    0x21 Extension (0xF9 - Graphic Control, остальные пропускаем),
    0x3B Trailer.

  Растровая часть кадра: LZW min code size, sub-blocks по <= 255 байт
  (0x00 - конец), коды упакованы little-endian битами. Коды: 0..2^cs-1
  литералы, clear = 2^cs, end = 2^cs + 1, новые записи с 2^cs + 2.
*/
#include "Sc/Image/Gif.h"
#include "Sc/Sc.h"
#include <string.h>

/*
  DOCS: Максимальный размер стороны изображения (защита от битых
  заголовков; stb использует то же значение по умолчанию).
*/
#define SC_GIF_MAX_DIMENSIONS (1 << 24)

/*
  DOCS: Читатель потока: позиция + данные, все чтения с проверкой
  выхода за границы (возвращают 0 при конце данных).
*/
typedef struct
{
    u8* aBytes;
    i64 Size;
    i64 Pos;
} ScGifStream;

static u8
sc_gif_get8(ScGifStream* pStream)
{
    if (pStream->Pos >= pStream->Size)
        return 0;
    return pStream->aBytes[pStream->Pos++];
}

static u16
sc_gif_get16le(ScGifStream* pStream)
{
    u16 lo = sc_gif_get8(pStream);
    u16 hi = sc_gif_get8(pStream);
    return (u16)(lo | (hi << 8));
}

static i32
sc_gif_skip(ScGifStream* pStream, i64 count)
{
    if (pStream->Pos + count > pStream->Size)
        return 0;
    pStream->Pos += count;
    return 1;
}

/*
  DOCS: Проверка GIF magic: "GIF87a" или "GIF89a".
*/
static i32
sc_gif_magic_is_valid(u8* aBytes, i64 dataSize)
{
    return dataSize >= 6
        && aBytes[0] == 'G' && aBytes[1] == 'I' && aBytes[2] == 'F'
        && aBytes[3] == '8'
        && (aBytes[4] == '7' || aBytes[4] == '9')
        && aBytes[5] == 'a';
}

/*
  DOCS: Состояние декодера: палитры, canvas, история пикселей,
  фон для disposal и накопленные кадры.
*/
typedef struct
{
    u8 aPal[256][4];     /* глобальная палитра */
    u8 aLpal[256][4];    /* локальная палитра */
    u8* pColorTable;     /* активная палитра кадра (aPal или aLpal) */
    u8* pCanvas;         /* RGBA canvas: Width * Height * 4 */
    u8* pBackground;     /* фон (для disposal = 2) */
    u8* pHistory;        /* пиксели, тронутые прошлым кадром */
    u8* pFrames;         /* все кадры подряд */
    i32* aDelays;        /* задержки кадров в мс */
    i32 Width;
    i32 Height;
    i32 Frames;
    i32 Capacity;        /* выделено кадров под pFrames/aDelays */
    i32 Flags;           /* флаги LSD */
    i32 BgIndex;         /* индекс цвета фона из LSD */
    i32 Transparent;     /* индекс прозрачного цвета из GCE (-1 = нет) */
    i32 Eflags;          /* флаги GCE текущего кадра */
    i32 Delay;           /* задержка текущего кадра в мс */
} ScGifDecoder;

/*
  DOCS: Палитра из потока: entries цветов RGB + alpha
  (0 для прозрачного индекса, иначе 255).
*/
static i32
sc_gif_read_colortable(ScGifStream* pStream, u8 aPal[256][4], i32 entries, i32 transparent)
{
    if (pStream->Pos + (i64)entries * 3 > pStream->Size)
        return 0;

    for (i32 i = 0; i < entries; ++i)
    {
        aPal[i][0] = pStream->aBytes[pStream->Pos + i * 3 + 0];
        aPal[i][1] = pStream->aBytes[pStream->Pos + i * 3 + 1];
        aPal[i][2] = pStream->aBytes[pStream->Pos + i * 3 + 2];
        aPal[i][3] = (i == transparent) ? 0 : 255;
    }

    pStream->Pos += entries * 3;
    return 1;
}

/*
  DOCS: Точка растра (для interlace): продвигает текущую позицию
  записи по строкам с шагом step, при выходе за max_y переходит
  к следующему проходу interlace.
*/
typedef struct
{
    i32 CurX;
    i32 CurY;
    i32 StartX;
    i32 StartY;
    i32 MaxX;
    i32 MaxY;
    i32 Step;
    i32 Parse; /* оставшиеся проходы interlace (0 = не interlaced) */
} ScGifRasterState;

static void
sc_gif_raster_advance(ScGifRasterState* pState, i32 lineSize)
{
    pState->CurX += 4;

    if (pState->CurX >= pState->MaxX)
    {
        pState->CurX = pState->StartX;
        pState->CurY += pState->Step;

        while (pState->CurY >= pState->MaxY && pState->Parse > 0)
        {
            pState->Step = (1 << pState->Parse) * lineSize;
            pState->CurY = pState->StartY + (pState->Step >> 1);
            --pState->Parse;
        }
    }
}

/*
  DOCS: Выводит один пиксель растра на канву (index - индекс палитры).
  Прозрачные пиксели не пишутся, но помечаются в истории.
*/
static void
sc_gif_out_pixel(ScGifDecoder* pDecoder, ScGifRasterState* pState, u8 index)
{
    if (pState->CurY >= pState->MaxY)
        return;

    i32 idx = pState->CurX + pState->CurY;
    pDecoder->pHistory[idx / 4] = 1;

    u8* c = pDecoder->pColorTable + index * 4;

    if (c[3] > 128)
    {
        pDecoder->pCanvas[idx + 0] = c[0];
        pDecoder->pCanvas[idx + 1] = c[1];
        pDecoder->pCanvas[idx + 2] = c[2];
        pDecoder->pCanvas[idx + 3] = c[3];
    }
}

/*
  DOCS: Декодирует LZW-растр кадра и рисует пиксели на канву
  через sc_gif_out_pixel. Возвращает 0 при ошибке.
*/
static i32
sc_gif_decode_lzw(ScGifDecoder* pDecoder, ScGifStream* pStream, ScGifRasterState* pState, i32 lineSize)
{
    i32 minCodeSize = sc_gif_get8(pStream);
    if (minCodeSize < 1 || minCodeSize > 11)
        return 0;

    i32 clear = 1 << minCodeSize;
    i32 eoi = clear + 1;

    i32 codesize = minCodeSize + 1;
    i32 codemask = (1 << codesize) - 1;
    i32 avail = clear + 2;
    i32 oldcode = -1;
    i32 first = 1;

    /*
      DOCS: Таблица LZW: prefix (код предыдущего символа цепочки) +
      DOCS: suffix (последний байт цепочки). first_code - первый байт
      DOCS: цепочки кода (нужен для кода "length on one less").
    */
    i16 aPrefix[8192];
    u8 aSuffix[8192];
    u8 aFirst[8192];

    for (i32 i = 0; i < clear; ++i)
    {
        aPrefix[i] = -1;
        aSuffix[i] = (u8)i;
        aFirst[i] = (u8)i;
    }

    /*
      DOCS: Битовый читатель поверх sub-block'ов: len - байт, оставшихся
      DOCS: в текущем sub-block'е (0 - конец последовательности блоков).
    */
    u32 bits = 0;
    i32 validBits = 0;
    i32 len = 0;

    for (;;)
    {
        if (validBits < codesize)
        {
            if (len == 0)
            {
                len = sc_gif_get8(pStream);
                if (len == 0)
                    return 1; // конец последовательности sub-block'ов
            }

            --len;
            bits |= (u32)sc_gif_get8(pStream) << validBits;
            validBits += 8;
            continue;
        }

        i32 code = bits & codemask;
        bits >>= codesize;
        validBits -= codesize;

        if (code == clear)
        {
            codesize = minCodeSize + 1;
            codemask = (1 << codesize) - 1;
            avail = clear + 2;
            oldcode = -1;
            first = 0;
        }
        else if (code == eoi)
        {
            /*
              DOCS: Конец LZW-потока: дочитываем хвост текущего sub-block'а
              DOCS: и все последующие до терминатора (0x00), чтобы поток
              DOCS: встал точно на следующий блок GIF (extension/image/trailer).
            */
            if (!sc_gif_skip(pStream, len))
                return 0;

            for (;;)
            {
                i32 blockLen = sc_gif_get8(pStream);
                if (blockLen == 0)
                    return 1;
                if (!sc_gif_skip(pStream, blockLen))
                    return 0;
            }
        }
        else if (code <= avail)
        {
            if (first)
                return 0; // нет стартового clear-кода

            if (oldcode >= 0)
            {
                if (avail >= 8192)
                    return 0;

                aPrefix[avail] = (i16)oldcode;
                aFirst[avail] = aFirst[oldcode];
                aSuffix[avail] = (code == avail) ? aFirst[avail] : aFirst[code];
                ++avail;
            }
            else if (code == avail)
            {
                return 0; // некорректный код
            }

            /*
              DOCS: Разматываем цепочку prefix'ов рекурсией нельзя
              (глубина до 8192), поэтому собираем стек байтов и
              выводим в правильном порядке.
            */
            {
                i32 c = code;
                u8 aStack[8192];
                i32 sp = 0;

                while (c >= 0 && sp < 8192)
                {
                    aStack[sp++] = aSuffix[c];
                    c = aPrefix[c];
                }

                while (sp > 0)
                {
                    sc_gif_out_pixel(pDecoder, pState, aStack[--sp]);
                    sc_gif_raster_advance(pState, lineSize);
                }
            }

            /*
              DOCS: Раннее расширение ширины кода (как stb): после
              добавления новой записи avail, когда avail совпадает
              с codemask + 1, коды становятся шире на бит.
            */
            if ((avail & codemask) == 0 && avail <= 0x0FFF)
            {
                ++codesize;
                codemask = (1 << codesize) - 1;
            }

            oldcode = code;
        }
        else
        {
            return 0; // код вне таблицы
        }
    }
}

/*
  DOCS: Обрабатывает один Image Descriptor: прямоугольник кадра,
  локальная палитра, LZW-растр. Возвращает 0 при ошибке.
*/
static i32
sc_gif_process_image(ScGifDecoder* pDecoder, ScGifStream* pStream, i32 isFirstFrame)
{
    i32 x = sc_gif_get16le(pStream);
    i32 y = sc_gif_get16le(pStream);
    i32 w = sc_gif_get16le(pStream);
    i32 h = sc_gif_get16le(pStream);

    if (x + w > pDecoder->Width || y + h > pDecoder->Height)
        return 0;

    i32 flags = sc_gif_get8(pStream);

    ScGifRasterState state = {};
    state.StartX = x * 4;
    state.StartY = y * pDecoder->Width * 4;
    state.MaxX = state.StartX + w * 4;
    state.MaxY = state.StartY + h * pDecoder->Width * 4;
    state.CurX = state.StartX;
    state.CurY = state.StartY;

    // NOTE: ширина 0 - кадр без пикселей, сразу выходим за max_y.
    if (w == 0)
        state.CurY = state.MaxY;

    i32 lineSize = pDecoder->Width * 4;

    if (flags & 0x40)
    {
        state.Step = 8 * lineSize; // первый шаг interlace
        state.Parse = 3;
    }
    else
    {
        state.Step = lineSize;
        state.Parse = 0;
    }

    if (flags & 0x80)
    {
        i32 entries = 2 << (flags & 7);
        if (!sc_gif_read_colortable(pStream, pDecoder->aLpal, entries, (pDecoder->Eflags & 0x01) ? pDecoder->Transparent : -1))
            return 0;
        pDecoder->pColorTable = (u8*)pDecoder->aLpal;
    }
    else if (pDecoder->Flags & 0x80)
    {
        pDecoder->pColorTable = (u8*)pDecoder->aPal;
    }
    else
    {
        return 0; // нет ни локальной, ни глобальной палитры
    }

    if (!sc_gif_decode_lzw(pDecoder, pStream, &state, lineSize))
        return 0;

    /*
      DOCS: Первый кадр: пиксели, в которые никто не писал, получают
      DOCS: цвет фона из LSD (если он задан).
    */
    if (isFirstFrame && pDecoder->BgIndex > 0)
    {
        for (i32 pi = 0; pi < pDecoder->Width * pDecoder->Height; ++pi)
        {
            if (pDecoder->pHistory[pi] == 0)
            {
                u8* bg = pDecoder->aPal[pDecoder->BgIndex];
                bg[3] = 255;
                memcpy(&pDecoder->pCanvas[pi * 4], bg, 4);
            }
        }
    }

    return 1;
}

/*
  DOCS: Extension-блок. Graphic Control Extension (0xF9) задаёт
  disposal, задержку и прозрачный индекс; остальные - метаданные,
  пропускаем их sub-block'и. Возвращает 0 при ошибке.
*/
static i32
sc_gif_process_extension(ScGifDecoder* pDecoder, ScGifStream* pStream)
{
    i32 label = sc_gif_get8(pStream);

    if (label == 0xF9)
    {
        i32 len = sc_gif_get8(pStream);
        if (len != 4)
        {
            if (!sc_gif_skip(pStream, len))
                return 0;
        }
        else
        {
            pDecoder->Eflags = sc_gif_get8(pStream);
            pDecoder->Delay = 10 * sc_gif_get16le(pStream);

            // NOTE: сброс старого прозрачного индекса в палитре.
            if (pDecoder->Transparent >= 0)
                pDecoder->aPal[pDecoder->Transparent][3] = 255;

            if (pDecoder->Eflags & 0x01)
            {
                pDecoder->Transparent = sc_gif_get8(pStream);
                pDecoder->aPal[pDecoder->Transparent][3] = 0;
            }
            else
            {
                sc_gif_get8(pStream); // прозрачного нет, байт всё равно есть
                pDecoder->Transparent = -1;
            }

            // NOTE: терминатор sub-block'а GCE.
            sc_gif_get8(pStream);
            return 1;
        }
    }

    // DOCS: пропуск sub-block'ов до терминатора.
    for (;;)
    {
        i32 len = sc_gif_get8(pStream);
        if (len == 0)
            return 1;
        if (!sc_gif_skip(pStream, len))
            return 0;
    }
}

/*
  DOCS: Добавляет копию канвы в массив кадров (с ростом ёмкости).
  Возвращает 0 при нехватке памяти.
*/
static i32
sc_gif_push_frame(ScGifDecoder* pDecoder)
{
    if (pDecoder->Frames == pDecoder->Capacity)
    {
        i32 newCapacity = (pDecoder->Capacity == 0) ? 8 : pDecoder->Capacity * 2;

        i64 framesSize = (i64)newCapacity * pDecoder->Width * pDecoder->Height * 4;
        u8* pNewFrames = (u8*)sc_memory_allocate(framesSize);
        i32* pNewDelays = (i32*)sc_memory_allocate((i64)newCapacity * sizeof(i32));

        if (pNewFrames == ScNull || pNewDelays == ScNull)
        {
            sc_memory_free(pNewFrames);
            sc_memory_free(pNewDelays);
            return 0;
        }

        if (pDecoder->pFrames != ScNull)
        {
            memcpy(pNewFrames, pDecoder->pFrames,
                   (i64)pDecoder->Frames * pDecoder->Width * pDecoder->Height * 4);
            memcpy(pNewDelays, pDecoder->aDelays,
                   (i64)pDecoder->Frames * sizeof(i32));
            sc_memory_free(pDecoder->pFrames);
            sc_memory_free(pDecoder->aDelays);
        }

        pDecoder->pFrames = pNewFrames;
        pDecoder->aDelays = pNewDelays;
        pDecoder->Capacity = newCapacity;
    }

    memcpy(
        pDecoder->pFrames + (i64)pDecoder->Frames * pDecoder->Width * pDecoder->Height * 4,
        pDecoder->pCanvas,
        (i64)pDecoder->Width * pDecoder->Height * 4);
    pDecoder->aDelays[pDecoder->Frames] = pDecoder->Delay;
    ++pDecoder->Frames;
    return 1;
}

/*
  DOCS: Применяет disposal-метод предыдущего кадра к канве перед
  рисованием следующего. dispose == 2 восстанавливает фон, 3 -
  кадр двух кадров назад (из pFrames), 0/1 оставляют как есть.
*/
static void
sc_gif_apply_disposal(ScGifDecoder* pDecoder)
{
    i32 dispose = (pDecoder->Eflags & 0x1C) >> 2;
    i32 pcount = pDecoder->Width * pDecoder->Height;

    /*
      DOCS: Для disposal == 3 нужен кадр двух кадров назад; пока
      DOCS: кадров меньше двух, откатываемся к поведению disposal == 2.
    */
    u8* pTwoBack = ScNull;
    if (pDecoder->Frames >= 2)
        pTwoBack = pDecoder->pFrames + (i64)(pDecoder->Frames - 2) * pcount * 4;

    if (dispose == 3 && pTwoBack == ScNull)
        dispose = 2;

    if (dispose == 3)
    {
        for (i32 pi = 0; pi < pcount; ++pi)
        {
            if (pDecoder->pHistory[pi])
                memcpy(&pDecoder->pCanvas[pi * 4], &pTwoBack[pi * 4], 4);
        }
    }
    else if (dispose == 2)
    {
        for (i32 p = 0; p < pcount; ++p)
        {
            if (pDecoder->pHistory[p])
                memcpy(&pDecoder->pCanvas[p * 4], &pDecoder->pBackground[p * 4], 4);
        }
    }

    // DOCS: фон следующего кадра - канва после undo.
    memcpy(pDecoder->pBackground, pDecoder->pCanvas, (i64)pcount * 4);
}

ScGifAnim
sc_gif_decode(void* pData, i64 dataSize)
{
    sc_assert_not_null(pData);

    ScGifAnim anim = {};
    if (pData == ScNull || dataSize <= 0)
        return anim;

    ScGifStream stream = { .aBytes = (u8*)pData, .Size = dataSize, .Pos = 0 };
    if (!sc_gif_magic_is_valid(stream.aBytes, dataSize))
        return anim;

    ScGifDecoder decoder = {};
    decoder.Transparent = -1;

    // DOCS: Header (6 байт magic, уже проверен) + Logical Screen Descriptor.
    stream.Pos = 6;
    decoder.Width = sc_gif_get16le(&stream);
    decoder.Height = sc_gif_get16le(&stream);
    decoder.Flags = sc_gif_get8(&stream);
    decoder.BgIndex = sc_gif_get8(&stream);
    sc_gif_get8(&stream); // pixel aspect ratio

    if (decoder.Width == 0 || decoder.Height == 0
        || decoder.Width > SC_GIF_MAX_DIMENSIONS || decoder.Height > SC_GIF_MAX_DIMENSIONS)
    {
        return anim;
    }

    // DOCS: Global Color Table.
    if (decoder.Flags & 0x80)
    {
        i32 entries = 2 << (decoder.Flags & 7);
        if (!sc_gif_read_colortable(&stream, decoder.aPal, entries, -1))
            return anim;
    }

    i64 pcount = (i64)decoder.Width * decoder.Height;
    decoder.pCanvas = (u8*)sc_memory_allocate(pcount * 4);
    decoder.pBackground = (u8*)sc_memory_allocate(pcount * 4);
    decoder.pHistory = (u8*)sc_memory_allocate(pcount);

    if (decoder.pCanvas == ScNull || decoder.pBackground == ScNull
        || decoder.pHistory == ScNull)
    {
        sc_memory_free(decoder.pCanvas);
        sc_memory_free(decoder.pBackground);
        sc_memory_free(decoder.pHistory);
        return anim;
    }

    /*
      DOCS: Канва стартует прозрачной (0,0,0,0): первый кадр пишет
      поверх, нетронутые пиксели могут получить цвет фона (BgIndex).
    */
    memset(decoder.pCanvas, 0, pcount * 4);
    memset(decoder.pBackground, 0, pcount * 4);
    memset(decoder.pHistory, 0, pcount);

    i32 isFirstFrame = 1;

    for (;;)
    {
        i32 tag = sc_gif_get8(&stream);

        if (tag == 0x3B) // Trailer - конец потока
            break;

        if (tag == 0x21) // Extension
        {
            if (!sc_gif_process_extension(&decoder, &stream))
                break;
            continue;
        }

        if (tag == 0x2C) // Image Descriptor
        {
            if (!isFirstFrame)
                sc_gif_apply_disposal(&decoder);

            memset(decoder.pHistory, 0, pcount);

            if (!sc_gif_process_image(&decoder, &stream, isFirstFrame))
                break;

            if (!sc_gif_push_frame(&decoder))
                break;

            isFirstFrame = 0;
            continue;
        }

        break; // неизвестный тег - битый поток
    }

    anim.Width = decoder.Width;
    anim.Height = decoder.Height;
    anim.Channels = 4;

    if (decoder.Frames == 0)
    {
        sc_memory_free(decoder.pCanvas);
        sc_memory_free(decoder.pBackground);
        sc_memory_free(decoder.pHistory);
        sc_memory_free(decoder.pFrames);
        sc_memory_free(decoder.aDelays);
        return anim;
    }

    /*
      DOCS: Отдаём буферы ровно под Frames кадров: пользователь
      освободит их sc_memory_free, лишнюю ёмкость держать незачем.
    */
    i64 framesSize = (i64)decoder.Frames * pcount * 4;
    anim.pData = sc_memory_allocate(framesSize);
    anim.aDelays = (i32*)sc_memory_allocate((i64)decoder.Frames * sizeof(i32));

    if (anim.pData == ScNull || anim.aDelays == ScNull)
    {
        sc_memory_free(anim.pData);
        sc_memory_free(anim.aDelays);
        anim.pData = ScNull;
        anim.aDelays = ScNull;
        anim.Frames = 0;
    }
    else
    {
        memcpy(anim.pData, decoder.pFrames, framesSize);
        memcpy(anim.aDelays, decoder.aDelays, (i64)decoder.Frames * sizeof(i32));
        anim.Frames = decoder.Frames;
    }

    sc_memory_free(decoder.pCanvas);
    sc_memory_free(decoder.pBackground);
    sc_memory_free(decoder.pHistory);
    sc_memory_free(decoder.pFrames);
    sc_memory_free(decoder.aDelays);
    return anim;
}

ScGifAnim
sc_gif_read(char* pPath)
{
    sc_assert_not_null(pPath);

    ScGifAnim anim = {};
    if (pPath == ScNull)
        return anim;

    i64 dataSize = 0;
    void* pData = sc_file_read_ext(pPath, &dataSize);
    if (pData == ScNull)
        return anim;

    anim = sc_gif_decode(pData, dataSize);

    sc_memory_free(pData);
    return anim;
}
