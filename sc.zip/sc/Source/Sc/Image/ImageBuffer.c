#include "ImageBuffer.h"

#include "Sc/Sc.h"
#include <string.h>

void
sc_image_buffer_init(ScImageBuffer* pBuffer, i64 capacity)
{
    pBuffer->pData = (u8*)sc_memory_allocate(capacity);
    pBuffer->Count = 0;
    pBuffer->Capacity = (pBuffer->pData != ScNull) ? capacity : 0;
}

void
sc_image_buffer_destroy(ScImageBuffer* pBuffer)
{
    if (pBuffer->pData != ScNull)
        sc_memory_free(pBuffer->pData);
    pBuffer->pData = ScNull;
    pBuffer->Count = 0;
    pBuffer->Capacity = 0;
}

void
sc_image_buffer_write(ScImageBuffer* pBuffer, void* pData, i32 size)
{
    if (pBuffer->pData == ScNull)
        return;

    if (pBuffer->Count + size > pBuffer->Capacity)
    {
        i64 newCapacity = pBuffer->Capacity * 2;
        if (newCapacity < pBuffer->Count + size)
            newCapacity = pBuffer->Count + size;

        u8* pNew = (u8*)sc_memory_allocate(newCapacity);
        if (pNew == ScNull)
        {
            // DOCS: нехватка памяти - буфер помечается неудачным
            // DOCS: (pData == ScNull), Count сбрасывается.
            sc_image_buffer_destroy(pBuffer);
            return;
        }

        /*
          NOTE: нельзя sc_image_buffer_destroy - она обнуляет Count,
          NOTE: и новая порция затёрла бы уже записанные данные.
        */
        memcpy(pNew, pBuffer->pData, pBuffer->Count);
        sc_memory_free(pBuffer->pData);

        pBuffer->pData = pNew;
        pBuffer->Capacity = newCapacity;
    }

    memcpy(pBuffer->pData + pBuffer->Count, pData, size);
    pBuffer->Count += size;
}
