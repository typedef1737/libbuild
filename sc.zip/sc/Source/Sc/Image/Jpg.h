/*
  DOCS: JPEG (baseline sequential, без progressive) - нативная реализация
  (без stb). Чтение: маркеры SOI/SOF0/DQT/DHT/SOS/DRI/RST/EOI, Huffman,
  dequant, integer IDCT (DCT_ISLOW, как libjpeg), хрома-субсэмплинг
  с fancy upsampling (треугольный фильтр libjpeg), YCbCr -> RGB
  (fixed point). Запись: baseline, 3-компонентный YCbCr (comp 1..4,
  alpha игнорируется; grey -> Y с нулевыми U/V), 4:2:0 при quality <= 90
  (иначе 4:4:4), стандартные таблицы Annex K. Заголовок magic:
  FF D8 FF (SOI + маркер).

  JPEG - формат с потерями: закодированные пиксели не обязаны
  совпадать с исходными. Пиксели: строки слева-направо, сверху-вниз,
  каналы подряд. Все возвращаемые буферы - sc_memory_allocate /
  sc_memory_free.
*/
#ifndef SC_JPG_H
#define SC_JPG_H

#include "Sc/Image/Image.h"

/*
  DOCS: Декодирует JPEG-данные из памяти.
  channels: 0 - взять из файла (1 или 3), 1..4 - форсировать вывод.
  Возвращает NULL при ошибке, иначе пиксели (освободить sc_memory_free).
  pDesc заполняется из заголовка файла.
*/
void* sc_jpg_decode(void* pData, i64 dataSize, ScImageDesc* pDesc, i32 channels);

/*
  DOCS: Читает и декодирует JPEG-файл с диска (sc_file_read, бинарно).
  Возвращает NULL при ошибке, иначе пиксели (освободить sc_memory_free).
*/
void* sc_jpg_read(char* pPath, ScImageDesc* pDesc, i32 channels);

/*
  DOCS: Кодирует сырые пиксели в JPEG-данные в памяти (формат с потерями).
  comp 1..4 (alpha игнорируется), quality 1..100 (0 - по умолчанию 90).
  Возвращает NULL при ошибке, иначе - закодированные данные
  (освободить sc_memory_free); в *pLength пишется размер данных в байтах.
*/
void* sc_jpg_encode(void* pData, ScImageDesc desc, i32 quality, i64* pLength);

/*
  DOCS: Кодирует сырые пиксели и пишет JPEG-файл на диск
  (sc_file_write, бинарно). Возвращает 0 при ошибке или число
  записанных байт.
*/
i64 sc_jpg_write(char* pPath, void* pData, ScImageDesc desc, i32 quality);

#endif // SC_JPG_H
