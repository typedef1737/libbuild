/*
  DOCS: GIF - Graphics Interchange Format. Нативная реализация без
  внешних зависимостей: LZW-декодер растра, глобальные и локальные
  палитры, прозрачность (Graphic Control Extension), interlace и
  анимации с задержками кадров и методами disposal (do not dispose /
  restore to background / restore to previous).

  Все кадры склеиваются в один массив: Frames * Width * Height * 4
  байт RGBA. aDelays[i] - задержка i-го кадра в миллисекундах
  (кратна 10: GIF хранит её в единицах 1/100 с).

  Чтение только: записи GIF нет (для сохранения изображений см. Png,
  Jpg, Qoi).

  Пиксели: строки слева-направо, сверху-вниз, каналы пикселя подряд.
  Все возвращаемые буферы - sc_memory_allocate / sc_memory_free.
*/
#ifndef SC_GIF_H
#define SC_GIF_H

#include "Sc/Image/Image.h"

/*
  DOCS: Кадры и пиксели анимации/статичного GIF.
  pData - Frames * Width * Height * 4 байт RGBA (все кадры подряд,
  кадр i начинается с pData + i * Width * Height * 4).
  aDelays - Frames задержек в миллисекундах (0 для статичных GIF).
*/
typedef struct
{
    i32 Width;    /* ширина в пикселях */
    i32 Height;   /* высота в пикселях */
    i32 Frames;   /* число кадров (>= 1) */
    i32 Channels; /* всегда 4 (ScImageChannels_Rgba) */
    void* pData;  /* пиксели (освободить sc_memory_free) */
    i32* aDelays; /* задержки в мс (освободить sc_memory_free) */
} ScGifAnim;

/*
  DOCS: Декодирует GIF-данные из памяти (все кадры, RGBA).
  Возвращает NULL при ошибке, иначе заполненную ScGifAnim
  (pData и aDelays освободить sc_memory_free).
*/
ScGifAnim sc_gif_decode(void* pData, i64 dataSize);

/*
  DOCS: Читает и декодирует GIF-файл с диска (sc_file_read, бинарно).
  Возвращает ScGifAnim с pData == NULL при ошибке.
*/
ScGifAnim sc_gif_read(char* pPath);

#endif // SC_GIF_H
