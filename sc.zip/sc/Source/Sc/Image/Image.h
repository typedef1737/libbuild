/*
  DOCS: Общие типы модулей изображений Sc (Png, Jpg, Gif).

  Каждый модуль - отдельная пара .h/.c (Png, Jpg, Gif), все следуют
  одному контракту: пиксели вертикальные ряды слева-направо, сверху-вниз,
  каналы пикселя подряд (interleaved). Возвращаемые буферы выделяются
  через sc_memory_allocate и освобождаются sc_memory_free.
*/
#ifndef SC_IMAGE_H
#define SC_IMAGE_H

#include "Sc/Types.h"

/*
  DOCS: Максимальный размер входных данных декодирования.
*/
#define SC_IMAGE_DATA_SIZE_MAX 0x7fffffff

/*
  DOCS: Проверка размера входных данных.
*/
static i32
sc_image_data_size_is_valid(i64 dataSize)
{
    return dataSize > 0 && dataSize <= SC_IMAGE_DATA_SIZE_MAX;
}

/*
  DOCS: Допустимое число каналов для декодирования: 0 - взять из файла,
  1..4 - форсировать вывод (Y, YA, RGB, RGBA).
*/
static i32
sc_image_decode_channels_is_valid(i32 channels)
{
    return channels >= 0 && channels <= 4;
}

/*
  DOCS: Число каналов пикселей.
*/
typedef enum
{
    ScImageChannels_Grey = 1,      /* 1 байт на пиксель */
    ScImageChannels_GreyAlpha = 2, /* 2 байта на пиксель */
    ScImageChannels_Rgb = 3,       /* 3 байта на пиксель */
    ScImageChannels_Rgba = 4,      /* 4 байта на пиксель */
} ScImageChannels;

/*
  DOCS: Описание изображения. Для encode/write заполняется вручную,
  для decode/read - заполняется из заголовка файла.
*/
typedef struct
{
    i32 Width;    /* ширина в пикселях */
    i32 Height;   /* высота в пикселях */
    i32 Channels; /* ScImageChannels */
} ScImageDesc;

/*
  DOCS: Проверка описания изображения для кодирования.
*/
i32 sc_image_desc_is_valid_for_encode(ScImageDesc desc);

/*
  DOCS: Заполняет ScImageDesc по результату декодирования: channels == 0
  означает "взять число каналов из файла" (fileChannels - число каналов
  файла после расширения палитр/tRNS).
*/
void sc_image_desc_fill(ScImageDesc* pDesc, i32 width, i32 height, i32 fileChannels, i32 channels);

#endif // SC_IMAGE_H
