/*
  DOCS: JPEG - нативная реализация (без stb).

  Декодер (baseline sequential):
    - маркеры: SOI (FFD8), SOF0 (FFC0), DQT (FFDB, 8/16-бит таблицы),
      DHT (FFC4), DRI (FFDD), SOS (FFDA), RST0-7 (FFD0-FFD7), EOI (FFD9),
      APPn/COM пропускаются (JFIF/Adobe распознаются для RGB/CMYK);
    - Huffman-декодирование с ускоряющей таблицей (FAST_BITS = 9);
    -熵ийно-кодированные данные с байт-stuffing (FF -> FF 00) и
      restart-маркерами;
    - dequant + integer IDCT (DCT_ISLOW из libjpeg: f2f(x) = x*4096+0.5,
      смещения 512 / 65536+128<<17, clamp);
    - хрома-субсэмплинг 4:2:0 / 4:2:2 / 4:4:4 с "fancy" upsampling
      (треугольный фильтр 3:1, как libjpeg/stb);
    - YCbCr -> RGB fixed point (float2fixed(x) = x*4096+0.5 << 8);
    - grayscale (1 компонент), RGB (компоненты R,G,B), CMYK/YCCK
      (4 компонента, Adobe APP14).

  Энкодер (baseline, по мотивам jo_jpeg/stb_image_write):
    - всегда 3-компонентный YCbCr (grey -> Y, U/V = 0; alpha игнорируется);
    - 4:2:0 при quality <= 90, иначе 4:4:4;
    - quant-таблицы Annex K (YQT/UVQT) со scale по quality;
    - forward DCT float, зигзаг, RLE + Huffman (стандартные таблицы
      Annex K);
    - byte-stuffing при записи битов (FF -> FF 00).

  MCU (Minimum Coded Unit): h_max * v_max блоков 8x8; компоненты
  сэмплируются h/v раз внутри MCU. Блоки 8x8 коэффициентов: DC (0,0)
  кодируется разностью с предсказанием, AC - RLE (run, size).
*/
#include "Sc/Image/Jpg.h"
#include "Sc/Image/ImageBuffer.h"
#include "Sc/Sc.h"
#include <string.h>

#define SC_JPG_MAX_DIMENSIONS (1 << 24)

/* маркеры */
#define SC_JPG_MARKER_SOI 0xd8
#define SC_JPG_MARKER_EOI 0xd9
#define SC_JPG_MARKER_SOS 0xda
#define SC_JPG_MARKER_DQT 0xdb
#define SC_JPG_MARKER_DHT 0xc4
#define SC_JPG_MARKER_DRI 0xdd
#define SC_JPG_MARKER_DNL 0xdc
#define SC_JPG_MARKER_NONE 0x100

/* параметры декодера */
#define SC_JPG_FAST_BITS 9

/*
  DOCS: Зигзаг-порядок коэффициентов 8x8 (естественный -> зигзаг).
*/
static const u8 aJpgDezigzag[64 + 15] = {
    0,  1,  8, 16,  9,  2,  3, 10,
   17, 24, 32, 25, 18, 11,  4,  5,
   12, 19, 26, 33, 40, 48, 41, 34,
   27, 20, 13,  6,  7, 14, 21, 28,
   35, 42, 49, 56, 57, 50, 43, 36,
   29, 22, 15, 23, 30, 37, 44, 51,
   58, 59, 52, 45, 38, 31, 39, 46,
   53, 60, 61, 54, 47, 55, 62, 63,
   /* защита от кривых данных: хвост читает последний элемент */
   63, 63, 63, 63, 63, 63, 63, 63,
   63, 63, 63, 63, 63, 63, 63
};

/*
  DOCS: bias[n] = (-1 << n) + 1: extension receive для DC/AC амплитуд.
*/
static const i32 aJpgBias[16] = {
    0, -1, -3, -7, -15, -31, -63, -127, -255, -511,
    -1023, -2047, -4095, -8191, -16383, -32767
};

/*
  DOCS: Битовый поток JPEG (MSB-first): 32-битный буфер, entropy
  данные с byte-stuffing; маркеры ловятся на границе.
*/
typedef struct
{
    u8* aBytes;
    i64 Size;
    i64 Pos;
    u32 CodeBuffer;
    i32 CodeBits;
    i32 Marker;   /* SC_JPG_MARKER_* или 0x100 = NONE */
    i32 NoMore;   /* после маркера данные не читаются */
} ScJpgBits;

static u8
sc_jpg_get8(ScJpgBits* pBits)
{
    if (pBits->Pos >= pBits->Size)
        return 0;
    return pBits->aBytes[pBits->Pos++];
}

static u16
sc_jpg_get16be(ScJpgBits* pBits)
{
    u16 hi = sc_jpg_get8(pBits);
    u16 lo = sc_jpg_get8(pBits);
    return (u16)((hi << 8) | lo);
}

static void
sc_jpg_grow_buffer(ScJpgBits* pBits)
{
    do
    {
        u8 b = pBits->NoMore ? 0 : sc_jpg_get8(pBits);
        if (b == 0xff)
        {
            u8 c = sc_jpg_get8(pBits);
            while (c == 0xff)
                c = sc_jpg_get8(pBits); // fill bytes
            if (c != 0)
            {
                pBits->Marker = c;
                pBits->NoMore = 1;
                return;
            }
        }

        pBits->CodeBuffer |= (u32)b << (24 - pBits->CodeBits);
        pBits->CodeBits += 8;
    } while (pBits->CodeBits <= 24);
}

/*
  DOCS: Читает следующий маркер (пропуская fill bytes).
*/
static i32
sc_jpg_get_marker(ScJpgBits* pBits)
{
    if (pBits->Marker != SC_JPG_MARKER_NONE)
    {
        i32 m = pBits->Marker;
        pBits->Marker = SC_JPG_MARKER_NONE;
        return m;
    }

    u8 c = sc_jpg_get8(pBits);
    while (c != 0xff)
    {
        if (pBits->Pos >= pBits->Size)
            return SC_JPG_MARKER_NONE;
        c = sc_jpg_get8(pBits);
    }

    u8 m = sc_jpg_get8(pBits);
    while (m == 0xff)
        m = sc_jpg_get8(pBits); // fill bytes

    return (m == 0x00) ? SC_JPG_MARKER_NONE : m;
}

/*
  DOCS: Huffman-код: длины/символы по спецификации + ускоряющая
  DOCS: таблица fast (верхние FAST_BITS бит -> символ, 255 = мимо).
  DOCS: aSize/aCode - рабочие массивы построения, aValues - сами
  DOCS: символы из DHT.
*/
typedef struct
{
    u8 aFast[1 << SC_JPG_FAST_BITS];
    u8 aSize[257];
    u16 aCode[256];
    u8 aValues[256];
    u16 aMaxCode[18];
    i32 aDelta[17];
} ScJpgHuff;

static i32
sc_jpg_build_huffman(ScJpgHuff* pHuff, i32* aCount)
{
    i32 k = 0;

    for (i32 i = 0; i < 16; ++i)
        for (i32 j = 0; j < aCount[i]; ++j)
            pHuff->aSize[k++] = (u8)(i + 1);
    pHuff->aSize[k] = 0;

    u32 code = 0;
    k = 0;
    for (i32 j = 1; j <= 16; ++j)
    {
        pHuff->aDelta[j] = k - code;
        if (pHuff->aSize[k] == j)
        {
            while (pHuff->aSize[k] == j)
                pHuff->aCode[k++] = (u16)(code++);
            if (code - 1 >= (1u << j))
                return 0; // переполнение кодового пространства
        }

        pHuff->aMaxCode[j] = code << (16 - j);
        code <<= 1;
    }
    pHuff->aMaxCode[17] = 0xffff;

    memset(pHuff->aFast, 255, sizeof(pHuff->aFast));
    for (i32 i = 0; i < k; ++i)
    {
        i32 s = pHuff->aSize[i];
        if (s <= SC_JPG_FAST_BITS)
        {
            i32 c = pHuff->aCode[i] << (SC_JPG_FAST_BITS - s);
            i32 m = 1 << (SC_JPG_FAST_BITS - s);
            for (i32 j = 0; j < m; ++j)
                pHuff->aFast[c + j] = (u8)i;
        }
    }

    return 1;
}

/*
  DOCS: Декодирует один Huffman-символ из потока бит.
  Возвращает -1 при ошибке.
*/
static i32
sc_jpg_huff_decode(ScJpgBits* pBits, ScJpgHuff* pHuff)
{
    if (pBits->CodeBits < 16)
        sc_jpg_grow_buffer(pBits);

    i32 c = (pBits->CodeBuffer >> (32 - SC_JPG_FAST_BITS))
        & ((1 << SC_JPG_FAST_BITS) - 1);
    i32 k = pHuff->aFast[c];
    if (k < 255)
    {
        i32 s = pHuff->aSize[k];
        if (s > pBits->CodeBits)
            return -1;

        pBits->CodeBuffer <<= s;
        pBits->CodeBits -= s;
        return pHuff->aValues[k];
    }

    u32 temp = pBits->CodeBuffer >> 16;
    for (k = SC_JPG_FAST_BITS + 1; ; ++k)
        if (temp < pHuff->aMaxCode[k])
            break;

    if (k == 17)
    {
        pBits->CodeBits -= 16;
        return -1;
    }

    if (k > pBits->CodeBits)
        return -1;

    c = (i32)((pBits->CodeBuffer >> (32 - k))
        & ((1u << k) - 1)) + pHuff->aDelta[k];
    pBits->CodeBits -= k;
    pBits->CodeBuffer <<= k;
    return pHuff->aValues[c];
}

/*
  DOCS: Компонент кадра: сэмплинг h/v, плоскость w2 x h2 (кратно MCU).
*/
typedef struct
{
    i32 Id;
    i32 H;
    i32 V;
    i32 Tq;
    i32 Hd;
    i32 Ha;
    i32 DcPred;
    i32 X, Y;     /* эффективные размеры */
    i32 W2, H2;   /* ширина/высота плоскости (MCU-выровненные) */
    u8* pData;
} ScJpgComponent;

/*
  DOCS: Состояние JPEG-декодера.
*/
typedef struct
{
    ScJpgBits Bits;
    ScJpgHuff HuffDC[4];
    ScJpgHuff HuffAC[4];
    u16 aDequant[4][64];
    ScJpgComponent aComp[4];
    i32 CompCount;
    i32 Width;
    i32 Height;
    i32 HMax;
    i32 VMax;
    i32 McuX;
    i32 McuY;
    i32 RestartInterval;
    i32 Todo;
    i32 IsJfif;
    i32 App14ColorTransform; /* -1 = нет, 0 = CMYK, 2 = YCCK */
    i32 IsRgb;
    i32 aOrder[4];
    i32 ScanN;
    i32 SpecStart;
    i32 SpecEnd;
    i32 SuccHigh;
    i32 SuccLow;
} ScJpgDecoder;

/*
  DOCS: combined receive+extend: амплитуда из n бит со знаком.
*/
static i32
sc_jpg_extend_receive(ScJpgBits* pBits, i32 n)
{
    if (pBits->CodeBits < n)
        sc_jpg_grow_buffer(pBits);

    u32 sgn = pBits->CodeBuffer >> 31;
    u32 k = (pBits->CodeBuffer << n) | (pBits->CodeBuffer >> (32 - n));
    pBits->CodeBuffer = (k & ~((1u << n) - 1));
    k &= ((1u << n) - 1);
    pBits->CodeBits -= n;
    return (i32)k + (aJpgBias[n] & (sgn - 1));
}

/*
  DOCS: unsigned биты (для progressive eobrun / refinement).
*/
static i32
sc_jpg_get_bits(ScJpgBits* pBits, i32 n)
{
    if (pBits->CodeBits < n)
        sc_jpg_grow_buffer(pBits);

    u32 k = (pBits->CodeBuffer << n) | (pBits->CodeBuffer >> (32 - n));
    pBits->CodeBuffer = k & ~((1u << n) - 1);
    k &= ((1u << n) - 1);
    pBits->CodeBits -= n;
    return (i32)k;
}

/*
  DOCS: Один бит (refinement scans).
*/
static i32
sc_jpg_get_bit(ScJpgBits* pBits)
{
    if (pBits->CodeBits < 1)
        sc_jpg_grow_buffer(pBits);

    i32 k = (i32)(pBits->CodeBuffer >> 31);
    pBits->CodeBuffer <<= 1;
    --pBits->CodeBits;
    return k;
}

/* ================================================================ */
/* IDCT (DCT_ISLOW, integer, как libjpeg/stb).                      */
/* ================================================================ */

/*
  DOCS: f2f(x) = x * 4096 + 0.5 - масштабирование констант DCT.
*/
#define sc_jpg_f2f(x) ((i32)((x) * 4096.0 + 0.5))
#define sc_jpg_fsh(x) ((x) * 4096)

/*
  DOCS: Одномерный IDCT (используется колонками и строками блока).
*/
#define SC_JPG_IDCT_1D(s0, s1, s2, s3, s4, s5, s6, s7) \
    i32 t0, t1, t2, t3, p1, p2, p3, p4, p5, x0, x1, x2, x3; \
    p2 = s2; \
    p3 = s6; \
    p1 = (p2 + p3) * sc_jpg_f2f(0.5411961); \
    t2 = p1 + p3 * sc_jpg_f2f(-1.847759065); \
    t3 = p1 + p2 * sc_jpg_f2f(0.765366865); \
    p2 = s0; \
    p3 = s4; \
    t0 = sc_jpg_fsh(p2 + p3); \
    t1 = sc_jpg_fsh(p2 - p3); \
    x0 = t0 + t3; \
    x3 = t0 - t3; \
    x1 = t1 + t2; \
    x2 = t1 - t2; \
    t0 = s7; \
    t1 = s5; \
    t2 = s3; \
    t3 = s1; \
    p3 = t0 + t2; \
    p4 = t1 + t3; \
    p1 = t0 + t3; \
    p2 = t1 + t2; \
    p5 = (p3 + p4) * sc_jpg_f2f(1.175875602); \
    t0 = t0 * sc_jpg_f2f(0.298631336); \
    t1 = t1 * sc_jpg_f2f(2.053119869); \
    t2 = t2 * sc_jpg_f2f(3.072711026); \
    t3 = t3 * sc_jpg_f2f(1.501321110); \
    p1 = p5 + p1 * sc_jpg_f2f(-0.899976223); \
    p2 = p5 + p2 * sc_jpg_f2f(-2.562915447); \
    p3 = p3 * sc_jpg_f2f(-1.961570560); \
    p4 = p4 * sc_jpg_f2f(-0.390180644); \
    t3 += p1 + p4; \
    t2 += p2 + p3; \
    t1 += p2 + p4; \
    t0 += p1 + p3

static u8
sc_jpg_clamp(i32 x)
{
    if ((u32)x > 255)
        return (x < 0) ? 0 : 255;
    return (u8)x;
}

/*
  DOCS: Полный 2D IDCT блока 8x8 коэффициентов (i16) в пиксели.
  Двухпроходный: колонки (с шорткатом DC-only), затем строки.
*/
static void
sc_jpg_idct_block(u8* pOut, i32 outStride, i16 aData[64])
{
    i32 aVal[64];

    /* колонки */
    for (i32 i = 0; i < 8; ++i)
    {
        i16* d = aData + i;
        i32* v = aVal + i;

        if (d[8] == 0 && d[16] == 0 && d[24] == 0 && d[32] == 0
            && d[40] == 0 && d[48] == 0 && d[56] == 0)
        {
            i32 dcterm = d[0] * 4;
            v[0] = v[8] = v[16] = v[24] = v[32] = v[40] = v[48] = v[56] = dcterm;
        }
        else
        {
            SC_JPG_IDCT_1D(d[0], d[8], d[16], d[24], d[32], d[40], d[48], d[56]);

            x0 += 512; x1 += 512; x2 += 512; x3 += 512;
            v[0] = (x0 + t3) >> 10;
            v[56] = (x0 - t3) >> 10;
            v[8] = (x1 + t2) >> 10;
            v[48] = (x1 - t2) >> 10;
            v[16] = (x2 + t1) >> 10;
            v[40] = (x2 - t1) >> 10;
            v[24] = (x3 + t0) >> 10;
            v[32] = (x3 - t0) >> 10;
        }
    }

    /* строки */
    for (i32 i = 0; i < 8; ++i)
    {
        i32* v = aVal + i * 8;
        u8* o = pOut + (i64)i * outStride;

        SC_JPG_IDCT_1D(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7]);

        x0 += 65536 + (128 << 17);
        x1 += 65536 + (128 << 17);
        x2 += 65536 + (128 << 17);
        x3 += 65536 + (128 << 17);

        o[0] = sc_jpg_clamp((x0 + t3) >> 17);
        o[7] = sc_jpg_clamp((x0 - t3) >> 17);
        o[1] = sc_jpg_clamp((x1 + t2) >> 17);
        o[6] = sc_jpg_clamp((x1 - t2) >> 17);
        o[2] = sc_jpg_clamp((x2 + t1) >> 17);
        o[5] = sc_jpg_clamp((x2 - t1) >> 17);
        o[3] = sc_jpg_clamp((x3 + t0) >> 17);
        o[4] = sc_jpg_clamp((x3 - t0) >> 17);
    }
}

/*
  DOCS: Декодирует один блок 8x8 (baseline): DC-разность + AC RLE.
  Возвращает 0 при ошибке.
*/
static i32
sc_jpg_decode_block(ScJpgDecoder* pDec, i16 aData[64], i32 compIndex)
{
    ScJpgComponent* pComp = &pDec->aComp[compIndex];
    u16* aDequant = pDec->aDequant[pComp->Tq];

    if (pDec->Bits.CodeBits < 16)
        sc_jpg_grow_buffer(&pDec->Bits);

    i32 t = sc_jpg_huff_decode(&pDec->Bits, &pDec->HuffDC[pComp->Hd]);
    if (t < 0 || t > 15)
        return 0;

    memset(aData, 0, 64 * sizeof(aData[0]));

    i32 diff = t ? sc_jpg_extend_receive(&pDec->Bits, t) : 0;
    pComp->DcPred += diff;
    aData[0] = (i16)(pComp->DcPred * aDequant[0]);

    i32 k = 1;
    do
    {
        if (pDec->Bits.CodeBits < 16)
            sc_jpg_grow_buffer(&pDec->Bits);

        i32 rs = sc_jpg_huff_decode(&pDec->Bits, &pDec->HuffAC[pComp->Ha]);
        if (rs < 0)
            return 0;

        i32 s = rs & 15;
        i32 r = rs >> 4;
        if (s == 0)
        {
            if (rs != 0xf0)
                break; // end of block
            k += 16;
        }
        else
        {
            k += r;
            if (k > 63)
                return 0; // защита от кривых файлов
            u32 zig = aJpgDezigzag[k++];
            aData[zig] = (i16)(sc_jpg_extend_receive(&pDec->Bits, s) * aDequant[zig]);
        }
    } while (k < 64);

    return 1;
}

/*
  DOCS: Сброс предсказаний DC / entropy-состояния (после restart).
*/
static void
sc_jpg_reset(ScJpgDecoder* pDec)
{
    pDec->Bits.CodeBits = 0;
    pDec->Bits.CodeBuffer = 0;
    pDec->Bits.NoMore = 0;
    pDec->Bits.Marker = SC_JPG_MARKER_NONE;

    for (i32 i = 0; i < 4; ++i)
        pDec->aComp[i].DcPred = 0;

    pDec->Todo = pDec->RestartInterval ? pDec->RestartInterval : 0x7fffffff;
}

/*
  DOCS: Является ли маркер restart-маркером (FFD0-FFD7).
*/
static i32
sc_jpg_is_restart(i32 marker)
{
    return marker >= 0xd0 && marker <= 0xd7;
}

/*
  DOCS: Обрабатывает маркер DQT / DHT / DRI / APPn / COM.
  Возвращает 0 при ошибке.
*/
static i32
sc_jpg_process_marker(ScJpgDecoder* pDec, i32 m)
{
    ScJpgBits* pBits = &pDec->Bits;

    switch (m)
    {
    case SC_JPG_MARKER_DRI:
        if (sc_jpg_get16be(pBits) != 4)
            return 0;
        pDec->RestartInterval = sc_jpg_get16be(pBits);
        return 1;

    case SC_JPG_MARKER_DQT:
    {
        i32 L = sc_jpg_get16be(pBits) - 2;
        while (L > 0)
        {
            i32 q = sc_jpg_get8(pBits);
            i32 precision = q >> 4;
            i32 tableId = q & 15;
            if (precision > 1 || tableId > 3)
                return 0;

            for (i32 i = 0; i < 64; ++i)
            {
                u16 v = (precision == 1)
                    ? sc_jpg_get16be(pBits)
                    : sc_jpg_get8(pBits);
                pDec->aDequant[tableId][aJpgDezigzag[i]] = v;
            }

            L -= (precision == 1) ? 129 : 65;
        }
        return L == 0;
    }

    case SC_JPG_MARKER_DHT:
    {
        i32 L = sc_jpg_get16be(pBits) - 2;
        while (L > 0)
        {
            i32 aSizes[16];
            i32 n = 0;

            i32 q = sc_jpg_get8(pBits);
            i32 tc = q >> 4;
            i32 th = q & 15;
            if (tc > 1 || th > 3)
                return 0;

            for (i32 i = 0; i < 16; ++i)
            {
                aSizes[i] = sc_jpg_get8(pBits);
                n += aSizes[i];
            }
            L -= 17;

            ScJpgHuff* pHuff = (tc == 0)
                ? &pDec->HuffDC[th]
                : &pDec->HuffAC[th];
            if (!sc_jpg_build_huffman(pHuff, aSizes))
                return 0;

            for (i32 i = 0; i < n; ++i)
                pHuff->aValues[i] = sc_jpg_get8(pBits);
            L -= n;
        }
        return L == 0;
    }

    default:
        break;
    }

    /* APPn / COM: пропускаем, JFIF и Adobe APP14 распознаём */
    if ((m >= 0xe0 && m <= 0xef) || m == 0xfe)
    {
        i32 L = sc_jpg_get16be(pBits);
        if (L < 2)
            return 0;
        L -= 2;

        if (m == 0xe0 && L >= 5)
        {
            static const u8 aTag[5] = { 'J', 'F', 'I', 'F', 0 };
            i32 isOk = 1;
            for (i32 i = 0; i < 5; ++i)
                if (sc_jpg_get8(pBits) != aTag[i])
                    isOk = 0;
            L -= 5;
            if (isOk)
                pDec->IsJfif = 1;
        }
        else if (m == 0xee && L >= 12)
        {
            static const u8 aTag[6] = { 'A', 'd', 'o', 'b', 'e', 0 };
            i32 isOk = 1;
            for (i32 i = 0; i < 6; ++i)
                if (sc_jpg_get8(pBits) != aTag[i])
                    isOk = 0;
            L -= 6;

            if (isOk)
            {
                sc_jpg_get8(pBits);   // version
                sc_jpg_get16be(pBits); // flags0
                sc_jpg_get16be(pBits); // flags1
                pDec->App14ColorTransform = sc_jpg_get8(pBits);
                L -= 6;
            }
        }

        pBits->Pos += L; // skip
        return 1;
    }

    return 0; // неизвестный маркер
}

/*
  DOCS: Обрабатывает SOF0 (baseline): размеры, компоненты, сэмплинг.
  Возвращает 0 при ошибке.
*/
static i32
sc_jpg_process_frame_header(ScJpgDecoder* pDec)
{
    ScJpgBits* pBits = &pDec->Bits;

    i32 Lf = sc_jpg_get16be(pBits);
    if (Lf < 11)
        return 0;

    i32 precision = sc_jpg_get8(pBits);
    if (precision != 8)
        return 0; // только 8 бит

    pDec->Height = sc_jpg_get16be(pBits);
    pDec->Width = sc_jpg_get16be(pBits);
    if (pDec->Height == 0 || pDec->Width == 0
        || pDec->Width > SC_JPG_MAX_DIMENSIONS || pDec->Height > SC_JPG_MAX_DIMENSIONS)
        return 0;

    i32 c = sc_jpg_get8(pBits);
    if (c != 1 && c != 3 && c != 4)
        return 0;
    pDec->CompCount = c;

    if (Lf != 8 + 3 * c)
        return 0;

    pDec->IsRgb = 0;
    for (i32 i = 0; i < c; ++i)
    {
        static const u8 aRgb[3] = { 'R', 'G', 'B' };
        ScJpgComponent* pComp = &pDec->aComp[i];

        pComp->Id = sc_jpg_get8(pBits);
        if (c == 3 && pComp->Id == aRgb[i])
            ++pDec->IsRgb;

        i32 q = sc_jpg_get8(pBits);
        pComp->H = q >> 4;
        pComp->V = q & 15;
        if (pComp->H < 1 || pComp->H > 4 || pComp->V < 1 || pComp->V > 4)
            return 0;

        pComp->Tq = sc_jpg_get8(pBits);
        if (pComp->Tq > 3)
            return 0;
    }

    if ((i64)pDec->Width * pDec->Height > 0x3fffffff)
        return 0;

    i32 hMax = 1;
    i32 vMax = 1;
    for (i32 i = 0; i < c; ++i)
    {
        if (pDec->aComp[i].H > hMax) hMax = pDec->aComp[i].H;
        if (pDec->aComp[i].V > vMax) vMax = pDec->aComp[i].V;
    }

    for (i32 i = 0; i < c; ++i)
    {
        if (hMax % pDec->aComp[i].H != 0) return 0;
        if (vMax % pDec->aComp[i].V != 0) return 0;
    }

    pDec->HMax = hMax;
    pDec->VMax = vMax;
    pDec->McuX = (pDec->Width + hMax * 8 - 1) / (hMax * 8);
    pDec->McuY = (pDec->Height + vMax * 8 - 1) / (vMax * 8);

    for (i32 i = 0; i < c; ++i)
    {
        ScJpgComponent* pComp = &pDec->aComp[i];

        pComp->X = (pDec->Width * pComp->H + hMax - 1) / hMax;
        pComp->Y = (pDec->Height * pComp->V + vMax - 1) / vMax;
        pComp->W2 = pDec->McuX * pComp->H * 8;
        pComp->H2 = pDec->McuY * pComp->V * 8;

        pComp->pData = (u8*)sc_memory_allocate((i64)pComp->W2 * pComp->H2);
        if (pComp->pData == ScNull)
            return 0;
    }

    return 1;
}

/*
  DOCS: Обрабатывает SOS: компоненты скана + Huffman-таблицы.
  Возвращает 0 при ошибке.
*/
static i32
sc_jpg_process_scan_header(ScJpgDecoder* pDec)
{
    ScJpgBits* pBits = &pDec->Bits;

    i32 Ls = sc_jpg_get16be(pBits);
    pDec->ScanN = sc_jpg_get8(pBits);
    if (pDec->ScanN < 1 || pDec->ScanN > 4 || pDec->ScanN > pDec->CompCount)
        return 0;
    if (Ls != 6 + 2 * pDec->ScanN)
        return 0;

    for (i32 i = 0; i < pDec->ScanN; ++i)
    {
        i32 id = sc_jpg_get8(pBits);
        i32 q = sc_jpg_get8(pBits);

        i32 which = 0;
        for (; which < pDec->CompCount; ++which)
            if (pDec->aComp[which].Id == id)
                break;
        if (which == pDec->CompCount)
            return 0;

        pDec->aComp[which].Hd = q >> 4;
        pDec->aComp[which].Ha = q & 15;
        if (pDec->aComp[which].Hd > 3 || pDec->aComp[which].Ha > 3)
            return 0;

        pDec->aOrder[i] = which;
    }

    pDec->SpecStart = sc_jpg_get8(pBits);
    pDec->SpecEnd = sc_jpg_get8(pBits);
    i32 aa = sc_jpg_get8(pBits);
    pDec->SuccHigh = aa >> 4;
    pDec->SuccLow = aa & 15;

    /* baseline: только полный диапазон коэффициентов */
    if (pDec->SpecStart != 0 || pDec->SuccHigh != 0 || pDec->SuccLow != 0)
        return 0;
    pDec->SpecEnd = 63;

    return 1;
}

/*
  DOCS: Декодирует entropy-данные одного скана (baseline):
  interleaved MCU или single-component тривиальный порядок.
  Возвращает 0 при ошибке.
*/
static i32
sc_jpg_parse_entropy_data(ScJpgDecoder* pDec)
{
    sc_jpg_reset(pDec);

    if (pDec->ScanN == 1)
    {
        i32 n = pDec->aOrder[0];
        ScJpgComponent* pComp = &pDec->aComp[n];

        i32 w = (pComp->X + 7) >> 3;
        i32 h = (pComp->Y + 7) >> 3;

        for (i32 j = 0; j < h; ++j)
        {
            for (i32 i = 0; i < w; ++i)
            {
                i16 aData[64];
                if (!sc_jpg_decode_block(pDec, aData, n))
                    return 0;

                sc_jpg_idct_block(pComp->pData + (i64)j * 8 * pComp->W2 + i * 8,
                                  pComp->W2, aData);

                if (--pDec->Todo <= 0)
                {
                    if (pDec->Bits.CodeBits < 24)
                        sc_jpg_grow_buffer(&pDec->Bits);
                    if (!sc_jpg_is_restart(pDec->Bits.Marker))
                        return 1; // битые данные вместо отсутствия данных
                    sc_jpg_reset(pDec);
                }
            }
        }

        return 1;
    }

    /* interleaved MCU */
    for (i32 j = 0; j < pDec->McuY; ++j)
    {
        for (i32 i = 0; i < pDec->McuX; ++i)
        {
            for (i32 k = 0; k < pDec->ScanN; ++k)
            {
                i32 n = pDec->aOrder[k];
                ScJpgComponent* pComp = &pDec->aComp[n];

                for (i32 y = 0; y < pComp->V; ++y)
                {
                    for (i32 x = 0; x < pComp->H; ++x)
                    {
                        i16 aData[64];
                        if (!sc_jpg_decode_block(pDec, aData, n))
                            return 0;

                        i32 x2 = (i * pComp->H + x) * 8;
                        i32 y2 = (j * pComp->V + y) * 8;
                        sc_jpg_idct_block(pComp->pData + (i64)y2 * pComp->W2 + x2,
                                          pComp->W2, aData);
                    }
                }
            }

            if (--pDec->Todo <= 0)
            {
                if (pDec->Bits.CodeBits < 24)
                    sc_jpg_grow_buffer(&pDec->Bits);
                if (!sc_jpg_is_restart(pDec->Bits.Marker))
                    return 1;
                sc_jpg_reset(pDec);
            }
        }
    }

    return 1;
}



/* ================================================================ */
/* Upsampling и цветовая конверсия.                                  */
/* ================================================================ */

/*
  DOCS: 2x по вертикали из строк near/far (вес 3:1, fancy upsampling).
*/
static void
sc_jpg_resample_row_v_2(u8* pOut, u8* pNear, u8* pFar, i32 w)
{
    for (i32 i = 0; i < w; ++i)
        pOut[i] = (u8)((3 * pNear[i] + pFar[i] + 2) >> 2);
}

/*
  DOCS: 2x по горизонтали (вес 3:1, clamp по краям).
*/
static void
sc_jpg_resample_row_h_2(u8* pOut, u8* pIn, i32 w)
{
    if (w == 1)
    {
        pOut[0] = pOut[1] = pIn[0];
        return;
    }

    pOut[0] = pIn[0];
    pOut[1] = (u8)((pIn[0] * 3 + pIn[1] + 2) >> 2);
    for (i32 i = 1; i < w - 1; ++i)
    {
        i32 n = 3 * pIn[i] + 2;
        pOut[i * 2 + 0] = (u8)((n + pIn[i - 1]) >> 2);
        pOut[i * 2 + 1] = (u8)((n + pIn[i + 1]) >> 2);
    }
    pOut[(w - 1) * 2 + 0] = (u8)((pIn[w - 2] * 3 + pIn[w - 1] + 2) >> 2);
    pOut[(w - 1) * 2 + 1] = pIn[w - 1];
}

/*
  DOCS: 2x2 (вертикаль + горизонталь, веса 3:1 -> деление на 16).
*/
static void
sc_jpg_resample_row_hv_2(u8* pOut, u8* pNear, u8* pFar, i32 w)
{
    if (w == 1)
    {
        pOut[0] = pOut[1] = (u8)((3 * pNear[0] + pFar[0] + 2) >> 2);
        return;
    }

    i32 t1 = 3 * pNear[0] + pFar[0];
    pOut[0] = (u8)((t1 + 2) >> 2);
    for (i32 i = 1; i < w; ++i)
    {
        i32 t0 = t1;
        t1 = 3 * pNear[i] + pFar[i];
        pOut[i * 2 - 1] = (u8)((3 * t0 + t1 + 8) >> 4);
        pOut[i * 2] = (u8)((3 * t1 + t0 + 8) >> 4);
    }
    pOut[w * 2 - 1] = (u8)((t1 + 2) >> 2);
}

/*
  DOCS: Быстрое перемножение 0..255 * 0..255 -> 0..255 (CMYK).
*/
static u8
sc_jpg_blinn_8x8(u8 x, u8 y)
{
    u32 t = (u32)x * y + 128;
    return (u8)((t + (t >> 8)) >> 8);
}

/*
  DOCS: YCbCr -> RGB fixed point.
*/
#define sc_jpg_float2fixed(x) (((i32)((x) * 4096.0 + 0.5)) << 8)

static void
sc_jpg_ycbcr_to_rgb_row(u8* pOut, u8* pY, u8* pCb, u8* pCr, i32 count, i32 step)
{
    for (i32 i = 0; i < count; ++i)
    {
        i32 yFixed = (pY[i] << 20) + (1 << 19); // rounding
        i32 cr = pCr[i] - 128;
        i32 cb = pCb[i] - 128;

        i32 r = yFixed + cr * sc_jpg_float2fixed(1.40200);
        i32 g = yFixed + (cr * -sc_jpg_float2fixed(0.71414))
            + ((cb * -sc_jpg_float2fixed(0.34414)) & (i32)0xffff0000);
        i32 b = yFixed + cb * sc_jpg_float2fixed(1.77200);

        r >>= 20;
        g >>= 20;
        b >>= 20;

        pOut[0] = sc_jpg_clamp(r);
        pOut[1] = sc_jpg_clamp(g);
        pOut[2] = sc_jpg_clamp(b);
        if (step >= 4)
            pOut[3] = 255;
        pOut += step;
    }
}

/*
  DOCS: Состояние апсемплера компонента при выводе строк.
*/
typedef struct
{
    i32 Hs;      /* горизонтальный фактор апсемплинга (h_max / h) */
    i32 Vs;      /* вертикальный */
    i32 YStep;
    i32 WLores;
    i32 YPos;
    u8* pLine0;
    u8* pLine1;
    u8* pLineBuf;
} ScJpgResample;

/*
  DOCS: Проверка JPEG magic: FF D8 FF (SOI, за ним обязательно маркер).
*/
static i32
sc_jpg_magic_is_valid(u8* aBytes, i64 dataSize)
{
    return dataSize >= 3
        && aBytes[0] == 0xff && aBytes[1] == 0xd8 && aBytes[2] == 0xff;
}

/*
  DOCS: Полный decode: маркеры -> entropy -> resample -> цвет.
*/
void*
sc_jpg_decode(void* pData, i64 dataSize, ScImageDesc* pDesc, i32 channels)
{
    sc_assert_not_null(pData);
    sc_assert_not_null(pDesc);

    if (pData == ScNull || pDesc == ScNull
        || !sc_image_data_size_is_valid(dataSize)
        || !sc_image_decode_channels_is_valid(channels)
        || !sc_jpg_magic_is_valid((u8*)pData, dataSize))
    {
        return ScNull;
    }

    ScJpgDecoder dec = {};
    dec.App14ColorTransform = -1;
    dec.Bits.Marker = SC_JPG_MARKER_NONE;
    dec.Bits.aBytes = (u8*)pData;
    dec.Bits.Size = dataSize;
    dec.Bits.Pos = 0;

    u8* pOutput = ScNull;

    /* маркеры до SOF */
    i32 m = sc_jpg_get_marker(&dec.Bits);
    if (m != SC_JPG_MARKER_SOI)
        goto JpgDecodeFailLabel;

    m = sc_jpg_get_marker(&dec.Bits);
    while (m != 0xc0 && m != 0xc1 && m != 0xc2)
    {
        if (m == SC_JPG_MARKER_NONE)
            goto JpgDecodeFailLabel;
        if (!sc_jpg_process_marker(&dec, m))
            goto JpgDecodeFailLabel;

        m = sc_jpg_get_marker(&dec.Bits);
    }

    if (m == 0xc2)
        goto JpgDecodeFailLabel; // progressive не поддерживается

    if (!sc_jpg_process_frame_header(&dec))
        goto JpgDecodeFailLabel;

    /* маркеры после SOF до EOI: сканы */
    m = sc_jpg_get_marker(&dec.Bits);
    while (m != SC_JPG_MARKER_EOI)
    {
        if (m == SC_JPG_MARKER_SOS)
        {
            if (!sc_jpg_process_scan_header(&dec))
                goto JpgDecodeFailLabel;
            if (!sc_jpg_parse_entropy_data(&dec))
                goto JpgDecodeFailLabel;

            /* хвостовые нули до следующего маркера */
            if (dec.Bits.Marker == SC_JPG_MARKER_NONE)
            {
                while (dec.Bits.Pos < dec.Bits.Size)
                {
                    u8 x = sc_jpg_get8(&dec.Bits);
                    if (x == 255)
                    {
                        dec.Bits.Marker = sc_jpg_get8(&dec.Bits);
                        break;
                    }
                }
            }
        }
        else if (m == SC_JPG_MARKER_DNL)
        {
            i32 Ld = sc_jpg_get16be(&dec.Bits);
            i32 nl = sc_jpg_get16be(&dec.Bits);
            if (Ld != 4 || nl != dec.Height)
                goto JpgDecodeFailLabel;
        }
        else
        {
            if (m == SC_JPG_MARKER_NONE
                || !sc_jpg_process_marker(&dec, m))
            {
                goto JpgDecodeFailLabel;
            }
        }

        m = sc_jpg_get_marker(&dec.Bits);
    }

    /* число каналов вывода */
    i32 outChannels = (channels != 0) ? channels
        : ((dec.CompCount >= 3) ? 3 : 1);

    i32 isRgb = (dec.CompCount == 3)
        && (dec.IsRgb == 3 || (dec.App14ColorTransform == 0 && !dec.IsJfif));

    i32 decodeN = dec.CompCount;
    if (dec.CompCount == 3 && outChannels < 3 && !isRgb)
        decodeN = 1; // только Y для серого вывода

    /* resample и цветовая конверсия */
    {
        ScJpgResample aRes[4] = {};

        for (i32 k = 0; k < decodeN; ++k)
        {
            ScJpgResample* pR = &aRes[k];
            ScJpgComponent* pComp = &dec.aComp[k];

            pR->Hs = dec.HMax / pComp->H;
            pR->Vs = dec.VMax / pComp->V;
            pR->YStep = pR->Vs >> 1;
            pR->WLores = (dec.Width + pR->Hs - 1) / pR->Hs;
            pR->YPos = 0;
            pR->pLine0 = pR->pLine1 = pComp->pData;
            pR->pLineBuf = (u8*)sc_memory_allocate(dec.Width + 3);
            if (pR->pLineBuf == ScNull)
                goto JpgDecodeFailLabel;
        }

        pOutput = (u8*)sc_memory_allocate((i64)dec.Width * dec.Height * outChannels);
        if (pOutput == ScNull)
            goto JpgDecodeFailLabel;

        u8* aCompOut[4] = {};

        for (i32 j = 0; j < dec.Height; ++j)
        {
            u8* pOut = pOutput + (i64)j * dec.Width * outChannels;

            for (i32 k = 0; k < decodeN; ++k)
            {
                ScJpgResample* pR = &aRes[k];
                ScJpgComponent* pComp = &dec.aComp[k];

                i32 yBot = pR->YStep >= (pR->Vs >> 1);
                u8* pNear = yBot ? pR->pLine1 : pR->pLine0;
                u8* pFar = yBot ? pR->pLine0 : pR->pLine1;

                /* горизонтальный + вертикальный апсемплинг */
                if (pR->Hs == 1 && pR->Vs == 1)
                {
                    aCompOut[k] = pNear;
                }
                else if (pR->Hs == 1 && pR->Vs == 2)
                {
                    sc_jpg_resample_row_v_2(pR->pLineBuf, pNear, pFar, pR->WLores);
                    aCompOut[k] = pR->pLineBuf;
                }
                else if (pR->Hs == 2 && pR->Vs == 1)
                {
                    sc_jpg_resample_row_h_2(pR->pLineBuf, pNear, pR->WLores);
                    aCompOut[k] = pR->pLineBuf;
                }
                else if (pR->Hs == 2 && pR->Vs == 2)
                {
                    sc_jpg_resample_row_hv_2(pR->pLineBuf, pNear, pFar, pR->WLores);
                    aCompOut[k] = pR->pLineBuf;
                }
                else
                {
                    /* generic: ближайший сосед (нетипичные факторы) */
                    for (i32 i = 0; i < pR->WLores; ++i)
                        for (i32 q = 0; q < pR->Hs; ++q)
                            pR->pLineBuf[i * pR->Hs + q] = pNear[i];
                    aCompOut[k] = pR->pLineBuf;
                }

                if (++pR->YStep >= pR->Vs)
                {
                    pR->YStep = 0;
                    pR->pLine0 = pR->pLine1;
                    if (++pR->YPos < pComp->Y)
                        pR->pLine1 += pComp->W2;
                }
            }

            /* цвет */
            if (outChannels >= 3)
            {
                u8* pY = aCompOut[0];

                if (dec.CompCount == 3)
                {
                    if (isRgb)
                    {
                        for (i32 i = 0; i < dec.Width; ++i)
                        {
                            pOut[0] = pY[i];
                            pOut[1] = aCompOut[1][i];
                            pOut[2] = aCompOut[2][i];
                            pOut[3] = 255;
                            pOut += outChannels;
                        }
                    }
                    else
                    {
                        sc_jpg_ycbcr_to_rgb_row(pOut, pY, aCompOut[1], aCompOut[2],
                                                dec.Width, outChannels);
                    }
                }
                else if (dec.CompCount == 4)
                {
                    if (dec.App14ColorTransform == 0) // CMYK
                    {
                        for (i32 i = 0; i < dec.Width; ++i)
                        {
                            u8 m2 = aCompOut[3][i];
                            pOut[0] = sc_jpg_blinn_8x8(aCompOut[0][i], m2);
                            pOut[1] = sc_jpg_blinn_8x8(aCompOut[1][i], m2);
                            pOut[2] = sc_jpg_blinn_8x8(aCompOut[2][i], m2);
                            pOut[3] = 255;
                            pOut += outChannels;
                        }
                    }
                    else if (dec.App14ColorTransform == 2) // YCCK
                    {
                        sc_jpg_ycbcr_to_rgb_row(pOut, pY, aCompOut[1], aCompOut[2],
                                                dec.Width, outChannels);
                        for (i32 i = 0; i < dec.Width; ++i)
                        {
                            u8 m2 = aCompOut[3][i];
                            pOut[0] = sc_jpg_blinn_8x8(255 - pOut[0], m2);
                            pOut[1] = sc_jpg_blinn_8x8(255 - pOut[1], m2);
                            pOut[2] = sc_jpg_blinn_8x8(255 - pOut[2], m2);
                            pOut += outChannels;
                        }
                    }
                    else
                    {
                        sc_jpg_ycbcr_to_rgb_row(pOut, pY, aCompOut[1], aCompOut[2],
                                                dec.Width, outChannels);
                    }
                }
            }
            else
            {
                u8* pY = aCompOut[0];

                if (isRgb)
                {
                    for (i32 i = 0; i < dec.Width; ++i)
                        pOut[i] = (u8)((aCompOut[0][i] * 77
                            + aCompOut[1][i] * 150
                            + aCompOut[2][i] * 29) >> 8);
                }
                else if (dec.CompCount == 4 && dec.App14ColorTransform == 0)
                {
                    for (i32 i = 0; i < dec.Width; ++i)
                    {
                        u8 m2 = aCompOut[3][i];
                        u8 r = sc_jpg_blinn_8x8(aCompOut[0][i], m2);
                        u8 g = sc_jpg_blinn_8x8(aCompOut[1][i], m2);
                        u8 b = sc_jpg_blinn_8x8(aCompOut[2][i], m2);
                        pOut[i] = (u8)((r * 77 + g * 150 + b * 29) >> 8);
                    }
                }
                else if (dec.CompCount == 4 && dec.App14ColorTransform == 2)
                {
                    for (i32 i = 0; i < dec.Width; ++i)
                        pOut[i] = sc_jpg_blinn_8x8(255 - aCompOut[0][i], aCompOut[3][i]);
                }
                else
                {
                    if (outChannels == 1)
                        memcpy(pOut, pY, dec.Width);
                    else
                        for (i32 i = 0; i < dec.Width; ++i)
                        {
                            pOut[i * 2] = pY[i];
                            pOut[i * 2 + 1] = 255;
                        }
                }
            }
        }

        for (i32 k = 0; k < 4; ++k)
            sc_memory_free(aRes[k].pLineBuf);
    }

    i32 fileChannels = (dec.CompCount >= 3) ? 3 : 1;
    sc_image_desc_fill(pDesc, dec.Width, dec.Height, fileChannels, channels);

    for (i32 i = 0; i < 4; ++i)
        sc_memory_free(dec.aComp[i].pData);

    return pOutput;

JpgDecodeFailLabel:
    pDesc->Width = 0;
    pDesc->Height = 0;
    pDesc->Channels = 0;

    sc_memory_free(pOutput);
    for (i32 i = 0; i < 4; ++i)
        sc_memory_free(dec.aComp[i].pData);

    return ScNull;
}

void*
sc_jpg_read(char* pPath, ScImageDesc* pDesc, i32 channels)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pDesc);

    if (pPath == ScNull || pDesc == ScNull)
        return ScNull;

    i64 dataSize = 0;
    void* pData = sc_file_read_ext(pPath, &dataSize);
    if (pData == ScNull)
        return ScNull;

    void* pPixels = sc_jpg_decode(pData, dataSize, pDesc, channels);

    sc_memory_free(pData);
    return pPixels;
}

/* ================================================================ */
/* Кодирование (baseline, по мотивам jo_jpeg / stb_image_write).    */
/* ================================================================ */

/*
  DOCS: Зигзаг для энкодера (позиция -> зигзаг-порядок).
*/
static const u8 aJpgZigZag[64] = {
    0, 1, 5, 6, 14, 15, 27, 28, 2, 4, 7, 13, 16, 26, 29, 42,
    3, 8, 12, 17, 25, 30, 41, 43, 9, 11, 18, 24, 31, 40, 44, 53,
    10, 19, 23, 32, 39, 45, 52, 54, 20, 22, 33, 38, 46, 51, 55, 60,
    21, 34, 37, 47, 50, 56, 59, 61, 35, 36, 48, 49, 57, 58, 62, 63
};

/*
  DOCS: Стандартные quant-таблицы Annex K (luminance/chrominance).
*/
static const i32 aJpgYQT[64] = {
    16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55,
    14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62,
    18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92,
    49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99
};
static const i32 aJpgUVQT[64] = {
    17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99,
    24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99
};

/*
  DOCS: Стандартные Huffman-таблицы Annex K (nrcodes + values).
*/
static const u8 aJpgStdDcLumNrcodes[] = { 0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0 };
static const u8 aJpgStdDcLumValues[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
static const u8 aJpgStdAcLumNrcodes[] = { 0, 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d };
static const u8 aJpgStdAcLumValues[] = {
    0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07,
    0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08, 0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0,
    0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
    0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49,
    0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69,
    0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
    0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
    0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5,
    0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
    0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
    0xf9, 0xfa
};
static const u8 aJpgStdDcChromaNrcodes[] = { 0, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0 };
static const u8 aJpgStdDcChromaValues[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
static const u8 aJpgStdAcChromaNrcodes[] = { 0, 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77 };
static const u8 aJpgStdAcChromaValues[] = {
    0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71,
    0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91, 0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0,
    0x15, 0x62, 0x72, 0xd1, 0x0a, 0x16, 0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
    0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
    0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68,
    0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
    0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5,
    0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3,
    0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
    0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
    0xf9, 0xfa
};

/*
  DOCS: Таблицы кодов для записи: aHuffCode[symbol][2] = {code, bits}.
  Строятся из nrcodes/values при первом использовании.
*/
typedef struct
{
    u16 aCode[256];
    u8 aBits[256];
    i32 IsInit;
} ScJpgHuffEnc;

static void
sc_jpg_huff_enc_build(ScJpgHuffEnc* pEnc, const u8* aNrcodes, const u8* aValues)
{
    u16 code = 0;
    i32 k = 0;

    for (i32 i = 1; i <= 16; ++i)
    {
        for (i32 j = 0; j < aNrcodes[i]; ++j)
        {
            pEnc->aCode[aValues[k]] = code;
            pEnc->aBits[aValues[k]] = (u8)i;
            ++code;
            ++k;
        }
        code <<= 1;
    }

    pEnc->IsInit = 1;
}

/*
  DOCS: Битовый писатель JPEG (byte-stuffing FF -> FF 00).
*/
typedef struct
{
    ScImageBuffer* pBuffer;
    u32 BitBuf;
    i32 BitCnt;
} ScJpgBitWriter;

static void
sc_jpg_write_bits(ScJpgBitWriter* pWriter, u16 code, i32 bits)
{
    pWriter->BitCnt += bits;
    pWriter->BitBuf |= (u32)code << (24 - pWriter->BitCnt);

    while (pWriter->BitCnt >= 8)
    {
        u8 c = (u8)((pWriter->BitBuf >> 16) & 255);
        sc_image_buffer_write(pWriter->pBuffer, &c, 1);
        if (c == 255)
        {
            u8 zero = 0;
            sc_image_buffer_write(pWriter->pBuffer, &zero, 1);
        }

        pWriter->BitBuf <<= 8;
        pWriter->BitCnt -= 8;
    }
}

/*
  DOCS: Магнитуда + биты амплитуды для DC/AC (как stb calcBits).
*/
static void
sc_jpg_calc_bits(i32 value, u16* pCode, i32* pBits)
{
    i32 magnitude = (value < 0) ? -value : value;
    i32 biased = (value < 0) ? value - 1 : value;

    *pBits = 1;
    while ((magnitude >>= 1) != 0)
        ++*pBits;

    *pCode = (u16)(biased & ((1 << *pBits) - 1));
}

/*
  DOCS: Forward DCT (float, jo_jpeg-стиль), 8 входов на месте.
*/
static void
sc_jpg_fdct(f32* d0, f32* d1, f32* d2, f32* d3, f32* d4, f32* d5, f32* d6, f32* d7)
{
    f32 z1, z2, z3, z4, z5, z11, z13;

    f32 tmp0 = *d0 + *d7;
    f32 tmp7 = *d0 - *d7;
    f32 tmp1 = *d1 + *d6;
    f32 tmp6 = *d1 - *d6;
    f32 tmp2 = *d2 + *d5;
    f32 tmp5 = *d2 - *d5;
    f32 tmp3 = *d3 + *d4;
    f32 tmp4 = *d3 - *d4;

    /* even */
    f32 tmp10 = tmp0 + tmp3;
    f32 tmp13 = tmp0 - tmp3;
    f32 tmp11 = tmp1 + tmp2;
    f32 tmp12 = tmp1 - tmp2;

    f32 s0 = tmp10 + tmp11;
    f32 s4 = tmp10 - tmp11;

    z1 = (tmp12 + tmp13) * 0.707106781f;
    f32 s2 = tmp13 + z1;
    f32 s6 = tmp13 - z1;

    /* odd */
    tmp10 = tmp4 + tmp5;
    tmp11 = tmp5 + tmp6;
    tmp12 = tmp6 + tmp7;

    z5 = (tmp10 - tmp12) * 0.382683433f;
    z2 = tmp10 * 0.541196100f + z5;
    z4 = tmp12 * 1.306562965f + z5;
    z3 = tmp11 * 0.707106781f;

    z11 = tmp7 + z3;
    z13 = tmp7 - z3;

    f32 s5 = z13 + z2;
    f32 s3 = z13 - z2;
    f32 s1 = z11 + z4;
    f32 s7 = z11 - z4;

    *d0 = s0; *d1 = s1; *d2 = s2; *d3 = s3;
    *d4 = s4; *d5 = s5; *d6 = s6; *d7 = s7;
}

/*
  DOCS: Кодирует один блок 8x8 (DCT -> quant -> zigzag -> Huffman).
  Возвращает новое значение DC-предсказания.
*/
static i32
sc_jpg_process_du(ScJpgBitWriter* pWriter, f32* aCDU, i32 duStride,
    f32* aFdctTable, i32 dcPred, ScJpgHuffEnc* pHuffDC, ScJpgHuffEnc* pHuffAC)
{
    i32 aDU[64];

    /* DCT по строкам и колонкам */
    for (i32 off = 0, n = duStride * 8; off < n; off += duStride)
        sc_jpg_fdct(&aCDU[off], &aCDU[off + 1], &aCDU[off + 2], &aCDU[off + 3],
                    &aCDU[off + 4], &aCDU[off + 5], &aCDU[off + 6], &aCDU[off + 7]);

    for (i32 off = 0; off < 8; ++off)
        sc_jpg_fdct(&aCDU[off], &aCDU[off + duStride], &aCDU[off + duStride * 2],
                    &aCDU[off + duStride * 3], &aCDU[off + duStride * 4],
                    &aCDU[off + duStride * 5], &aCDU[off + duStride * 6],
                    &aCDU[off + duStride * 7]);

    /* квантование + зигзаг */
    for (i32 y = 0, j = 0; y < 8; ++y)
    {
        for (i32 x = 0; x < 8; ++x, ++j)
        {
            f32 v = aCDU[y * duStride + x] * aFdctTable[j];
            aDU[aJpgZigZag[j]] = (i32)(v < 0 ? v - 0.5f : v + 0.5f);
        }
    }

    /* DC */
    i32 diff = aDU[0] - dcPred;
    if (diff == 0)
    {
        sc_jpg_write_bits(pWriter, pHuffDC->aCode[0], pHuffDC->aBits[0]);
    }
    else
    {
        u16 code;
        i32 bits;
        sc_jpg_calc_bits(diff, &code, &bits);
        sc_jpg_write_bits(pWriter, pHuffDC->aCode[bits], pHuffDC->aBits[bits]);
        sc_jpg_write_bits(pWriter, code, bits);
    }

    /* AC */
    i32 end0pos = 63;
    while (end0pos > 0 && aDU[end0pos] == 0)
        --end0pos;

    if (end0pos == 0)
    {
        sc_jpg_write_bits(pWriter, pHuffAC->aCode[0x00], pHuffAC->aBits[0x00]);
        return aDU[0];
    }

    for (i32 i = 1; i <= end0pos; ++i)
    {
        i32 startPos = i;
        while (aDU[i] == 0 && i <= end0pos)
            ++i;

        i32 nrzeroes = i - startPos;
        if (nrzeroes >= 16)
        {
            i32 lng = nrzeroes >> 4;
            for (i32 marker = 1; marker <= lng; ++marker)
                sc_jpg_write_bits(pWriter, pHuffAC->aCode[0xF0], pHuffAC->aBits[0xF0]);
            nrzeroes &= 15;
        }

        u16 code;
        i32 bits;
        sc_jpg_calc_bits(aDU[i], &code, &bits);
        sc_jpg_write_bits(pWriter, pHuffAC->aCode[(nrzeroes << 4) + bits],
                          pHuffAC->aBits[(nrzeroes << 4) + bits]);
        sc_jpg_write_bits(pWriter, code, bits);
    }

    if (end0pos != 63)
        sc_jpg_write_bits(pWriter, pHuffAC->aCode[0x00], pHuffAC->aBits[0x00]);

    return aDU[0];
}

/*
  DOCS: Кодирует сырые пиксели в JPEG (baseline YCbCr).
*/
void*
sc_jpg_encode(void* pData, ScImageDesc desc, i32 quality, i64* pLength)
{
    sc_assert_not_null(pData);
    sc_assert_not_null(pLength);

    if (pData == ScNull || pLength == ScNull
        || !sc_image_desc_is_valid_for_encode(desc))
    {
        return ScNull;
    }

    if ((i64)desc.Width * desc.Height > 0x3fffffff)
        return ScNull;

    i32 comp = desc.Channels;
    i32 width = desc.Width;
    i32 height = desc.Height;

    if (quality <= 0)
        quality = 90;
    i32 subsample = (quality <= 90) ? 1 : 0;
    if (quality < 1) quality = 1;
    if (quality > 100) quality = 100;
    quality = (quality < 50) ? (5000 / quality) : (200 - quality * 2);

    /* quant-таблицы */
    u8 aYTable[64];
    u8 aUVTable[64];
    for (i32 i = 0; i < 64; ++i)
    {
        i32 yti = (aJpgYQT[i] * quality + 50) / 100;
        i32 uvti = (aJpgUVQT[i] * quality + 50) / 100;
        aYTable[aJpgZigZag[i]] = (u8)((yti < 1) ? 1 : (yti > 255) ? 255 : yti);
        aUVTable[aJpgZigZag[i]] = (u8)((uvti < 1) ? 1 : (uvti > 255) ? 255 : uvti);
    }

    /* forward-DCT таблицы (1 / (quant * aasf)) */
    static const f32 aAasf[8] = {
        1.0f * 2.828427125f, 1.387039845f * 2.828427125f,
        1.306562965f * 2.828427125f, 1.175875602f * 2.828427125f,
        1.0f * 2.828427125f, 0.785694958f * 2.828427125f,
        0.541196100f * 2.828427125f, 0.275899379f * 2.828427125f
    };

    f32 aFdctY[64];
    f32 aFdctUV[64];
    for (i32 row = 0, k = 0; row < 8; ++row)
    {
        for (i32 col = 0; col < 8; ++col, ++k)
        {
            aFdctY[k] = 1.0f / (aYTable[aJpgZigZag[k]] * aAasf[row] * aAasf[col]);
            aFdctUV[k] = 1.0f / (aUVTable[aJpgZigZag[k]] * aAasf[row] * aAasf[col]);
        }
    }

    /* Huffman-таблицы записи */
    static ScJpgHuffEnc huffDCLum = {};
    static ScJpgHuffEnc huffACLum = {};
    static ScJpgHuffEnc huffDCChroma = {};
    static ScJpgHuffEnc huffACChroma = {};

    if (!huffDCLum.IsInit)
    {
        sc_jpg_huff_enc_build(&huffDCLum, aJpgStdDcLumNrcodes, aJpgStdDcLumValues);
        sc_jpg_huff_enc_build(&huffACLum, aJpgStdAcLumNrcodes, aJpgStdAcLumValues);
        sc_jpg_huff_enc_build(&huffDCChroma, aJpgStdDcChromaNrcodes, aJpgStdDcChromaValues);
        sc_jpg_huff_enc_build(&huffACChroma, aJpgStdAcChromaNrcodes, aJpgStdAcChromaValues);
    }

    ScImageBuffer out = {};
    i64 estimate = (i64)width * height * comp + 2048;
    sc_image_buffer_init(&out, estimate);
    if (out.pData == ScNull)
        return ScNull;

    /* заголовок: SOI + JFIF APP0 + DQT (2 таблицы) */
    static const u8 aHead0[] = {
        0xFF, 0xD8, 0xFF, 0xE0, 0, 0x10, 'J', 'F', 'I', 'F', 0,
        1, 1, 0, 0, 1, 0, 1, 0, 0,
        0xFF, 0xDB, 0, 0x84, 0
    };
    sc_image_buffer_write(&out, (void*)aHead0, sizeof(aHead0));
    sc_image_buffer_write(&out, aYTable, 64);
    u8 one = 1;
    sc_image_buffer_write(&out, &one, 1);
    sc_image_buffer_write(&out, aUVTable, 64);

    /* SOF0 */
    u8 aSof[19];
    aSof[0] = 0xFF; aSof[1] = 0xC0;
    aSof[2] = 0; aSof[3] = 0x11; // Lf = 17
    aSof[4] = 8; // precision
    aSof[5] = (u8)(height >> 8); aSof[6] = (u8)height;
    aSof[7] = (u8)(width >> 8); aSof[8] = (u8)width;
    aSof[9] = 3; // 3 компоненты
    aSof[10] = 1; aSof[11] = (u8)(subsample ? 0x22 : 0x11); aSof[12] = 0;
    aSof[13] = 2; aSof[14] = 0x11; aSof[15] = 1;
    aSof[16] = 3; aSof[17] = 0x11; aSof[18] = 1;
    sc_image_buffer_write(&out, aSof, sizeof(aSof));

    /* DHT (4 таблицы): длина 0x01A2 покрывает все 4; последняя запись -
       Tc/Th байт + 16 счётчиков + values (как у stb: head1 с trailing 0). */
    u8 aDhtMarker[] = { 0xFF, 0xC4, 0x01, 0xA2, 0 };
    sc_image_buffer_write(&out, aDhtMarker, sizeof(aDhtMarker));
    sc_image_buffer_write(&out, (void*)(aJpgStdDcLumNrcodes + 1), 16);
    sc_image_buffer_write(&out, (void*)aJpgStdDcLumValues, sizeof(aJpgStdDcLumValues));

    u8 aInfo0 = 0x10;
    sc_image_buffer_write(&out, &aInfo0, 1);
    sc_image_buffer_write(&out, (void*)(aJpgStdAcLumNrcodes + 1), 16);
    sc_image_buffer_write(&out, (void*)aJpgStdAcLumValues, sizeof(aJpgStdAcLumValues));

    u8 aInfo1 = 1;
    sc_image_buffer_write(&out, &aInfo1, 1);
    sc_image_buffer_write(&out, (void*)(aJpgStdDcChromaNrcodes + 1), 16);
    sc_image_buffer_write(&out, (void*)aJpgStdDcChromaValues, sizeof(aJpgStdDcChromaValues));

    u8 aInfo2 = 0x11;
    sc_image_buffer_write(&out, &aInfo2, 1);
    sc_image_buffer_write(&out, (void*)(aJpgStdAcChromaNrcodes + 1), 16);
    sc_image_buffer_write(&out, (void*)aJpgStdAcChromaValues, sizeof(aJpgStdAcChromaValues));

    /* SOS */
    static const u8 aSos[] = {
        0xFF, 0xDA, 0, 0xC, 3, 1, 0, 2, 0x11, 3, 0x11, 0, 0x3F, 0
    };
    sc_image_buffer_write(&out, (void*)aSos, sizeof(aSos));

    /* макроблоки */
    ScJpgBitWriter writer = {};
    writer.pBuffer = &out;

    i32 dcY = 0;
    i32 dcU = 0;
    i32 dcV = 0;

    /* компоновка каналов: comp 1/2 -> r=g=b (grey), alpha игнорируется */
    i32 ofsG = (comp > 2) ? 1 : 0;
    i32 ofsB = (comp > 2) ? 2 : 0;
    u8* pDataR = (u8*)pData;
    u8* pDataG = pDataR + ofsG;
    u8* pDataB = pDataR + ofsB;

    if (out.pData == ScNull)
    {
        sc_image_buffer_destroy(&out);
        return ScNull;
    }

    if (subsample)
    {
        for (i32 y = 0; y < height; y += 16)
        {
            for (i32 x = 0; x < width; x += 16)
            {
                f32 aY[256];
                f32 aU[256];
                f32 aV[256];

                for (i32 row = y, pos = 0; row < y + 16; ++row)
                {
                    i32 clampedRow = (row < height) ? row : height - 1;
                    u8* pBase = pDataR + (i64)clampedRow * width * comp;
                    u8* pBaseG = pDataG + (i64)clampedRow * width * comp;
                    u8* pBaseB = pDataB + (i64)clampedRow * width * comp;

                    for (i32 col = x; col < x + 16; ++col, ++pos)
                    {
                        i32 cx = (col < width) ? col : width - 1;
                        f32 r = pBase[(i64)cx * comp];
                        f32 g = pBaseG[(i64)cx * comp];
                        f32 b = pBaseB[(i64)cx * comp];

                        aY[pos] = 0.29900f * r + 0.58700f * g + 0.11400f * b - 128.0f;
                        aU[pos] = -0.16874f * r - 0.33126f * g + 0.50000f * b;
                        aV[pos] = 0.50000f * r - 0.41869f * g - 0.08131f * b;
                    }
                }

                dcY = sc_jpg_process_du(&writer, aY, 16, aFdctY, dcY, &huffDCLum, &huffACLum);
                dcY = sc_jpg_process_du(&writer, aY + 8, 16, aFdctY, dcY, &huffDCLum, &huffACLum);
                dcY = sc_jpg_process_du(&writer, aY + 128, 16, aFdctY, dcY, &huffDCLum, &huffACLum);
                dcY = sc_jpg_process_du(&writer, aY + 136, 16, aFdctY, dcY, &huffDCLum, &huffACLum);

                /* subsample U,V 2x2 -> 8x8 */
                f32 aSubU[64];
                f32 aSubV[64];
                for (i32 yy = 0, pos = 0; yy < 8; ++yy)
                {
                    for (i32 xx = 0; xx < 8; ++xx, ++pos)
                    {
                        i32 j = yy * 32 + xx * 2;
                        aSubU[pos] = (aU[j] + aU[j + 1] + aU[j + 16] + aU[j + 17]) * 0.25f;
                        aSubV[pos] = (aV[j] + aV[j + 1] + aV[j + 16] + aV[j + 17]) * 0.25f;
                    }
                }

                dcU = sc_jpg_process_du(&writer, aSubU, 8, aFdctUV, dcU, &huffDCChroma, &huffACChroma);
                dcV = sc_jpg_process_du(&writer, aSubV, 8, aFdctUV, dcV, &huffDCChroma, &huffACChroma);
            }
        }
    }
    else
    {
        for (i32 y = 0; y < height; y += 8)
        {
            for (i32 x = 0; x < width; x += 8)
            {
                f32 aY[64];
                f32 aU[64];
                f32 aV[64];

                for (i32 row = y, pos = 0; row < y + 8; ++row)
                {
                    i32 clampedRow = (row < height) ? row : height - 1;
                    u8* pBase = pDataR + (i64)clampedRow * width * comp;
                    u8* pBaseG = pDataG + (i64)clampedRow * width * comp;
                    u8* pBaseB = pDataB + (i64)clampedRow * width * comp;

                    for (i32 col = x; col < x + 8; ++col, ++pos)
                    {
                        i32 cx = (col < width) ? col : width - 1;
                        f32 r = pBase[(i64)cx * comp];
                        f32 g = pBaseG[(i64)cx * comp];
                        f32 b = pBaseB[(i64)cx * comp];

                        aY[pos] = 0.29900f * r + 0.58700f * g + 0.11400f * b - 128.0f;
                        aU[pos] = -0.16874f * r - 0.33126f * g + 0.50000f * b;
                        aV[pos] = 0.50000f * r - 0.41869f * g - 0.08131f * b;
                    }
                }

                dcY = sc_jpg_process_du(&writer, aY, 8, aFdctY, dcY, &huffDCLum, &huffACLum);
                dcU = sc_jpg_process_du(&writer, aU, 8, aFdctUV, dcU, &huffDCChroma, &huffACChroma);
                dcV = sc_jpg_process_du(&writer, aV, 8, aFdctUV, dcV, &huffDCChroma, &huffACChroma);
            }
        }
    }

    /* выравнивание битов + EOI */
    sc_jpg_write_bits(&writer, 0x7F, 7);
    u8 aEoi[] = { 0xFF, 0xD9 };
    sc_image_buffer_write(&out, aEoi, 2);

    if (out.pData == ScNull || out.Count == 0)
    {
        sc_image_buffer_destroy(&out);
        return ScNull;
    }

    *pLength = out.Count;
    return out.pData;
}

i64
sc_jpg_write(char* pPath, void* pData, ScImageDesc desc, i32 quality)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pData);

    if (pPath == ScNull || pData == ScNull)
        return 0;

    i64 length = 0;
    void* pEncoded = sc_jpg_encode(pData, desc, quality, &length);
    if (pEncoded == ScNull)
        return 0;

    sc_file_write(pPath, pEncoded, length);

    sc_memory_free(pEncoded);
    return length;
}
