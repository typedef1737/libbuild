/*
  QOI - "Quite OK Image" формат. Реализация по спецификации
  из Source/Deps/qoi-specification.pdf (data format: заголовок 14 байт,
  чанки QOI_OP_INDEX/DIFF/LUMA/RUN/RGB/RGBA, бегущий индекс на 64 пикселя,
  end-marker 7 x 0x00 + 0x01).
*/
#include "Sc/Image/Qoi.h"
#include "Sc/Sc.h"
#include <string.h>

/*
  DOCS: 2-битные теги чанков (старшие биты первого байта) и 8-битные теги.
  8-битные теги имеют приоритет: декодер проверяет их первыми.
*/
#define SC_QOI_OP_INDEX 0x00 /* 00xxxxxx */
#define SC_QOI_OP_DIFF 0x40  /* 01xxxxxx */
#define SC_QOI_OP_LUMA 0x80  /* 10xxxxxx */
#define SC_QOI_OP_RUN 0xc0   /* 11xxxxxx */
#define SC_QOI_OP_RGB 0xfe   /* 11111110 */
#define SC_QOI_OP_RGBA 0xff  /* 11111111 */

#define SC_QOI_MASK_2 0xc0 /* 11000000 */

/*
  DOCS: 2GB - максимальный размер, который эта реализация безопасно
  выдерживает (худший случай 5 байт на пиксель).
*/
#define SC_QOI_PIXELS_MAX 400000000

#define SC_QOI_HEADER_SIZE 14

/*
  DOCS: Пиксель как цвет и как u32: сравнение через v, доступ к каналам
  через rgba. Endianness значения не имеет - v только для сравнения.
*/
typedef union
{
    struct
    {
        u8 R, G, B, A;
    } rgba;
    u32 v;
} ScQoiPixel;

/*
  DOCS: End-marker QOI-потока: 7 нулей + 0x01.
*/
static const u8 sc_qoi_padding[8] = { 0, 0, 0, 0, 0, 0, 0, 1 };

/*
  DOCS: Хеш позиции в бегущем индексе (спецификация: r*3 + g*5 + b*7 + a*11).
*/
#define sc_qoi_color_hash(px) ((px).rgba.R * 3 + (px).rgba.G * 5 + (px).rgba.B * 7 + (px).rgba.A * 11)

static void
sc_qoi_write_32(u8* aBytes, i64* p, u32 value)
{
    aBytes[(*p)++] = (0xff000000 & value) >> 24;
    aBytes[(*p)++] = (0x00ff0000 & value) >> 16;
    aBytes[(*p)++] = (0x0000ff00 & value) >> 8;
    aBytes[(*p)++] = (0x000000ff & value);
}

static u32
sc_qoi_read_32(u8* aBytes, i64* p)
{
    u32 a = aBytes[(*p)++];
    u32 b = aBytes[(*p)++];
    u32 c = aBytes[(*p)++];
    u32 d = aBytes[(*p)++];
    return a << 24 | b << 16 | c << 8 | d;
}

/*
  DOCS: Валидация описания изображения (общая для encode и decode).
*/
static i32
sc_qoi_desc_is_valid(ScQoiDesc desc)
{
    if (desc.Width == 0 || desc.Height == 0
        || desc.Channels < 3 || desc.Channels > 4
        || desc.Colorspace > 1
        || (u32)desc.Height >= SC_QOI_PIXELS_MAX / (u32)desc.Width)
    {
        return 0;
    }

    return 1;
}

void*
sc_qoi_encode(void* pData, ScQoiDesc desc, i64* pLength)
{
    sc_assert_not_null(pData);
    sc_assert_not_null(pLength);

    if (pData == ScNull || pLength == ScNull)
        return ScNull;

    ScQoiDesc validateDesc = desc;
    if (!sc_qoi_desc_is_valid(validateDesc))
        return ScNull;

    i64 channels = desc.Channels;
    i64 pxLen = (i64)desc.Width * (i64)desc.Height * channels;
    i64 pxEnd = pxLen - channels;

    /*
      DOCS: Верхняя граница размера: худший случай (channels + 1) байт
      на пиксель + заголовок + end-marker.
    */
    i64 maxSize = pxLen + (i64)desc.Width * desc.Height + SC_QOI_HEADER_SIZE + sizeof(sc_qoi_padding);

    u8* aBytes = (u8*)sc_memory_allocate(maxSize);
    if (!aBytes)
        return ScNull;

    i64 p = 0;
    sc_qoi_write_32(aBytes, &p, ((u32)'q') << 24 | ((u32)'o') << 16 | ((u32)'i') << 8 | ((u32)'f'));
    sc_qoi_write_32(aBytes, &p, (u32)desc.Width);
    sc_qoi_write_32(aBytes, &p, (u32)desc.Height);
    aBytes[p++] = (u8)desc.Channels;
    aBytes[p++] = (u8)desc.Colorspace;

    u8* aPixels = (u8*)pData;

    /*
      DOCS: Бегущий индекс из 64 ранее виденных пикселей. Каждый пиксель
      кладется на позицию sc_qoi_color_hash(px) % 64.
    */
    ScQoiPixel aIndex[64];
    memset(aIndex, 0, sizeof(aIndex));

    i64 run = 0;
    ScQoiPixel px = { .rgba = { .R = 0, .G = 0, .B = 0, .A = 255 } };
    ScQoiPixel pxPrev = px;

    for (i64 pxPos = 0; pxPos < pxLen; pxPos += channels)
    {
        px.rgba.R = aPixels[pxPos + 0];
        px.rgba.G = aPixels[pxPos + 1];
        px.rgba.B = aPixels[pxPos + 2];

        if (channels == 4)
        {
            px.rgba.A = aPixels[pxPos + 3];
        }

        if (px.v == pxPrev.v)
        {
            run++;

            /*
              DOCS: QOI_OP_RUN: длина повтора 1..62 (63 и 64 заняты
              8-битными тегами QOI_OP_RGB/QOI_OP_RGBA).
            */
            if (run == 62 || pxPos == pxEnd)
            {
                aBytes[p++] = SC_QOI_OP_RUN | (u8)(run - 1);
                run = 0;
            }
        }
        else
        {
            if (run > 0)
            {
                aBytes[p++] = SC_QOI_OP_RUN | (u8)(run - 1);
                run = 0;
            }

            i64 indexPos = sc_qoi_color_hash(px) & (64 - 1);

            if (aIndex[indexPos].v == px.v)
            {
                aBytes[p++] = SC_QOI_OP_INDEX | (u8)indexPos;
            }
            else
            {
                aIndex[indexPos] = px;

                if (px.rgba.A == pxPrev.rgba.A)
                {
                    i8 vr = px.rgba.R - pxPrev.rgba.R;
                    i8 vg = px.rgba.G - pxPrev.rgba.G;
                    i8 vb = px.rgba.B - pxPrev.rgba.B;

                    i8 vg_r = vr - vg;
                    i8 vg_b = vb - vg;

                    if (vr > -3 && vr < 2 && vg > -3 && vg < 2 && vb > -3 && vb < 2)
                    {
                        /*
                          DOCS: QOI_OP_DIFF: 2-битные дельты каналов, bias 2.
                        */
                        aBytes[p++] = SC_QOI_OP_DIFF | (u8)((vr + 2) << 4 | (vg + 2) << 2 | (vb + 2));
                    }
                    else if (vg_r > -9 && vg_r < 8 && vg > -33 && vg < 32 && vg_b > -9 && vg_b < 8)
                    {
                        /*
                          DOCS: QOI_OP_LUMA: 6-битная дельта зеленого (bias 32),
                          4-битные дельты красного/синего минус зеленая (bias 8).
                        */
                        aBytes[p++] = SC_QOI_OP_LUMA | (u8)(vg + 32);
                        aBytes[p++] = (u8)((vg_r + 8) << 4 | (vg_b + 8));
                    }
                    else
                    {
                        /*
                          DOCS: QOI_OP_RGB: полные R, G, B (alpha без изменений).
                        */
                        aBytes[p++] = SC_QOI_OP_RGB;
                        aBytes[p++] = px.rgba.R;
                        aBytes[p++] = px.rgba.G;
                        aBytes[p++] = px.rgba.B;
                    }
                }
                else
                {
                    /*
                      DOCS: QOI_OP_RGBA: полные R, G, B, A.
                    */
                    aBytes[p++] = SC_QOI_OP_RGBA;
                    aBytes[p++] = px.rgba.R;
                    aBytes[p++] = px.rgba.G;
                    aBytes[p++] = px.rgba.B;
                    aBytes[p++] = px.rgba.A;
                }
            }
        }

        pxPrev = px;
    }

    for (i64 i = 0; i < (i64)sizeof(sc_qoi_padding); ++i)
    {
        aBytes[p++] = sc_qoi_padding[i];
    }

    *pLength = p;
    return aBytes;
}

void*
sc_qoi_decode(void* pData, i64 dataSize, ScQoiDesc* pDesc, i32 channels)
{
    sc_assert_not_null(pData);
    sc_assert_not_null(pDesc);

    if (pData == ScNull || pDesc == ScNull
        || (channels != 0 && channels != 3 && channels != 4)
        || dataSize < SC_QOI_HEADER_SIZE + (i64)sizeof(sc_qoi_padding))
    {
        return ScNull;
    }

    u8* aBytes = (u8*)pData;

    i64 p = 0;
    u32 magic = sc_qoi_read_32(aBytes, &p);
    pDesc->Width = (i32)sc_qoi_read_32(aBytes, &p);
    pDesc->Height = (i32)sc_qoi_read_32(aBytes, &p);
    pDesc->Channels = aBytes[p++];
    pDesc->Colorspace = aBytes[p++];

    if (magic != (((u32)'q') << 24 | ((u32)'o') << 16 | ((u32)'i') << 8 | ((u32)'f'))
        || !sc_qoi_desc_is_valid(*pDesc))
    {
        return ScNull;
    }

    if (channels == 0)
    {
        channels = pDesc->Channels;
    }

    i64 pxLen = (i64)pDesc->Width * (i64)pDesc->Height * channels;
    u8* aPixels = (u8*)sc_memory_allocate(pxLen);
    if (!aPixels)
        return ScNull;

    ScQoiPixel aIndex[64];
    memset(aIndex, 0, sizeof(aIndex));

    ScQoiPixel px = { .rgba = { .R = 0, .G = 0, .B = 0, .A = 255 } };

    i64 run = 0;
    i64 chunksLen = dataSize - (i64)sizeof(sc_qoi_padding);

    for (i64 pxPos = 0; pxPos < pxLen; pxPos += channels)
    {
        if (run > 0)
        {
            run--;
        }
        else if (p < chunksLen)
        {
            /*
              DOCS: 8-битные теги проверяются первыми (спецификация).
            */
            u8 b1 = aBytes[p++];

            if (b1 == SC_QOI_OP_RGB)
            {
                px.rgba.R = aBytes[p++];
                px.rgba.G = aBytes[p++];
                px.rgba.B = aBytes[p++];
            }
            else if (b1 == SC_QOI_OP_RGBA)
            {
                px.rgba.R = aBytes[p++];
                px.rgba.G = aBytes[p++];
                px.rgba.B = aBytes[p++];
                px.rgba.A = aBytes[p++];
            }
            else if ((b1 & SC_QOI_MASK_2) == SC_QOI_OP_INDEX)
            {
                px = aIndex[b1];
            }
            else if ((b1 & SC_QOI_MASK_2) == SC_QOI_OP_DIFF)
            {
                /*
                  DOCS: Wraparound-арифметика u8: "1 - 2" -> 255, "255 + 1" -> 0.
                */
                px.rgba.R += ((b1 >> 4) & 0x03) - 2;
                px.rgba.G += ((b1 >> 2) & 0x03) - 2;
                px.rgba.B += (b1 & 0x03) - 2;
            }
            else if ((b1 & SC_QOI_MASK_2) == SC_QOI_OP_LUMA)
            {
                u8 b2 = aBytes[p++];
                i32 vg = (b1 & 0x3f) - 32;
                px.rgba.R += vg - 8 + ((b2 >> 4) & 0x0f);
                px.rgba.G += vg;
                px.rgba.B += vg - 8 + (b2 & 0x0f);
            }
            else if ((b1 & SC_QOI_MASK_2) == SC_QOI_OP_RUN)
            {
                run = (b1 & 0x3f);
            }

            aIndex[sc_qoi_color_hash(px) & (64 - 1)] = px;
        }

        aPixels[pxPos + 0] = px.rgba.R;
        aPixels[pxPos + 1] = px.rgba.G;
        aPixels[pxPos + 2] = px.rgba.B;

        if (channels == 4)
        {
            aPixels[pxPos + 3] = px.rgba.A;
        }
    }

    return aPixels;
}

void*
sc_qoi_read(char* pPath, ScQoiDesc* pDesc, i32 channels)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pDesc);

    if (pPath == ScNull || pDesc == ScNull)
        return ScNull;

    i64 dataSize = 0;
    void* pData = sc_file_read_ext(pPath, &dataSize);
    if (!pData)
        return ScNull;

    void* pPixels = sc_qoi_decode(pData, dataSize, pDesc, channels);

    sc_memory_free(pData);
    return pPixels;
}

i64
sc_qoi_write(char* pPath, void* pData, ScQoiDesc desc)
{
    sc_assert_not_null(pPath);
    sc_assert_not_null(pData);

    if (pPath == ScNull || pData == ScNull)
        return 0;

    i64 length = 0;
    void* pEncoded = sc_qoi_encode(pData, desc, &length);
    if (!pEncoded)
        return 0;

    sc_file_write(pPath, pEncoded, length);

    sc_memory_free(pEncoded);
    return length;
}
