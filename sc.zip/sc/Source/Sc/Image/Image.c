#include "Image.h"

i32
sc_image_desc_is_valid_for_encode(ScImageDesc desc)
{
    return desc.Width > 0 && desc.Height > 0
        && desc.Channels >= 1 && desc.Channels <= 4;
}

/*
  DOCS: Заполняет ScImageDesc по результату декодирования: channels == 0
  означает "взять число каналов из файла" (fileChannels - число каналов
  файла после расширения палитр/tRNS).
*/
void
sc_image_desc_fill(ScImageDesc* pDesc, i32 width, i32 height, i32 fileChannels, i32 channels)
{
    pDesc->Width = width;
    pDesc->Height = height;
    pDesc->Channels = (channels != 0) ? channels : fileChannels;
}