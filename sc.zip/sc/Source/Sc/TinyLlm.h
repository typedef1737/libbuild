#ifndef SC_TINY_LLM_H
#define SC_TINY_LLM_H

#include "Ai.h"
#include "Types.h"

/*
  Микро-LLM для условной генерации реплики.

  Это учебно-практическая реализация decoder-only transformer на float32:
  без BLAS, без внешних ML-библиотек, только Sc.h/Types.h и stdlib C.
  Модель хранит BPE отдельно (ScAiBpe), поэтому один и тот же токенизатор
  используется в обучении, оценке и генерации.
*/

typedef enum
{
    // DOCS: loss по всем токенам (как в обычном LM).
    ScTinyLlmLossMask_None = 0,
    // DOCS: loss только по токенам ответа, начиная с первого токена после <SEP>.
    ScTinyLlmLossMask_Prompt = 1,
} ScTinyLlmLossMask;

typedef struct
{
    i32 NumMerges;
    char* pCorpusPath;
    char* pBpePath;
} ScTinyLlmBpeConfig;

typedef enum
{
    ScTinyLlmSize_Micro = 0,
    ScTinyLlmSize_Medium = 1,
    ScTinyLlmSize_Target = 2,
} ScTinyLlmSize;

typedef struct
{
    i32 NumLayers;
    i32 DModel;
    i32 NumHeads;
    i32 DFf;
    i32 ContextLength;
    i32 VocabCount;
    f32 InitStd;
    u64 Seed;
} ScTinyLlmModelConfig;

typedef struct
{
    // DOCS: полная последовательность, включая <BOS>/<SEP>/<EOS>.
    i32* aTokens;
    i64 Count;
    // DOCS: индекс последнего <SEP>; -1, если разметки нет.
    i32 SepIndex;
} ScTinyLlmExample;

typedef struct
{
    ScTinyLlmExample* aExamples;
    i64 Count;
} ScTinyLlmDataset;

typedef struct
{
    i32 Steps;
    i32 BatchSize;
    f32 LearningRate;
    f32 WeightDecay;
    i32 WarmupSteps;
    ScTinyLlmLossMask LossMask;
    i32 LogEvery;

    // DOCS: 0 отключает клиппинг по глобальной норме градиента.
    f32 GradClip;

    // DOCS: 0 отключает валидацию. EvalBatches - сколько окон проверять.
    i32 EvalEvery;
    i32 EvalBatches;
    i32 Patience;
    f32 MinDelta;

    // DOCS: чекпоинты. Оба поля должны быть заданы, иначе сохранения нет.
    char* pCheckpointPath;
    i32 CheckpointEvery;

    // DOCS: путь CSV-лога валидации "step,val_loss,val_ppl" (append).
    // NULL — лог не пишется. Файл создаётся с заголовком при первой записи.
    char* pValLogPath;

    // DOCS: 1 - после early stopping/обучения вернуть веса с лучшим val loss.
    i8 RestoreBest;

    u64 Seed;
} ScTinyLlmTrainConfig;

typedef struct
{
    i32 MaxTokens;
    f32 Temperature;
    i32 TopK;
    f32 TopP;
    u64 Seed;
    // DOCS: 1 — добавить <SEP> в конец prompt, если его нет (условная
    // генерация ответа, этап fine-tuning). 0 — чистое продолжение текста
    // (LM-прелюдия: модель продолжает фразу без разметки).
    i8 AppendSep;
} ScTinyLlmGenerateConfig;

// DOCS: Диагностика CPU-бэкенда TinyLlm: "avx2+fma" или "scalar".
// Бэкенд выбирается во время выполнения по CPUID: один бинарник работает
// и на CPU с AVX2, и без него.
const char* sc_tiny_llm_cpu_backend_name(void);
i32 sc_tiny_llm_cpu_has_avx2(void);
i32 sc_tiny_llm_cpu_has_fma(void);

// DOCS: Непрозрачный тип: веса и кэши скрыты в TinyLlm.c.
typedef struct ScTinyLlmModel ScTinyLlmModel;

ScTinyLlmModelConfig sc_tiny_llm_model_config_default(i32 vocabCount);
// DOCS: Пресеты из ТЗ: micro (2/64/2/256/128), medium (4/128/4/512/256),
// target (6/256/8/1024/512).
ScTinyLlmModelConfig sc_tiny_llm_model_config_preset(ScTinyLlmSize size, i32 vocabCount);
ScTinyLlmTrainConfig sc_tiny_llm_train_config_default(void);
ScTinyLlmGenerateConfig sc_tiny_llm_generate_config_default(void);

// DOCS: Создать/уничтожить модель. VocabCount должен покрывать спецтокены.
ScTinyLlmModel* sc_tiny_llm_create(const ScTinyLlmModelConfig* pConfig);
void sc_tiny_llm_destroy(ScTinyLlmModel* pModel);
// DOCS: Сколько f32-параметров в модели (для логов и оценки памяти).
i64 sc_tiny_llm_param_count(ScTinyLlmModel* pModel);

// DOCS: Датасет хранит уже токенизированные последовательности.
ScTinyLlmDataset sc_tiny_llm_dataset_new(void);
void sc_tiny_llm_dataset_destroy(ScTinyLlmDataset* pDataset);
i32 sc_tiny_llm_dataset_add(ScTinyLlmDataset* pDataset, ScAiBpe bpe, const char* pText);
// DOCS: Добавить пример из уже готовых токенов, без повторной токенизации.
// Нужен для упаковки окон (sequence packing): вызывающий сам склеивает
// <BOS>строка<EOS> в непрерывный поток и режет его на окна. Токены
// копируются, Count должен быть >= 2. <SEP> ищется так же, как в
// sc_tiny_llm_dataset_add.
i32 sc_tiny_llm_dataset_add_tokens(ScTinyLlmDataset* pDataset, const i32* aTokens, i64 Count);
i32 sc_tiny_llm_dataset_load_file(ScTinyLlmDataset* pDataset, ScAiBpe bpe, const char* pPath);

// DOCS: Обучение. Возвращает 1 при успехе, 0 при ошибке.
i32 sc_tiny_llm_train(ScTinyLlmModel* pModel, ScAiBpe bpe, const ScTinyLlmDataset* pTrain,
    const ScTinyLlmDataset* pValidation, const ScTinyLlmTrainConfig* pConfig);

// DOCS: Валидационный loss; pValidation не изменяется.
f32 sc_tiny_llm_eval(ScTinyLlmModel* pModel, const ScTinyLlmDataset* pDataset,
    i32 batches, ScTinyLlmLossMask lossMask, u64 seed);

// DOCS: Сгенерировать одну реплику. Возвращает NUL-terminated строку,
// которую нужно освободить через sc_string_destroy.
char* sc_tiny_llm_generate(ScTinyLlmModel* pModel, ScAiBpe bpe, const char* pPrompt,
    const ScTinyLlmGenerateConfig* pConfig);

// DOCS: Чекпоинт: magic + version + config + weights + встроенная копия BPE.
i32 sc_tiny_llm_save_checkpoint(ScTinyLlmModel* pModel, ScAiBpe bpe, const char* pPath);
ScTinyLlmModel* sc_tiny_llm_load_checkpoint(const char* pPath, ScAiBpe* pOutBpe);

// DOCS: Отладочная проверка аналитического градиента конечными разностями.
// Проверяет не более maxParams параметров каждого тензора.
i32 sc_tiny_llm_grad_check(ScTinyLlmModel* pModel, const ScTinyLlmDataset* pDataset,
    i32 maxParams, f32 epsilon, f32 tolerance);

#endif // SC_TINY_LLM_H
