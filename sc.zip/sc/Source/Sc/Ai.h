#ifndef SC_AI_H
#define SC_AI_H

#include "Types.h"

/*
- Токенизация методом BPE

*/

typedef struct
{
    char* pText;
    i64 TextLength;
    i64 MergesCount;
} ScAiBpeConfig;

typedef struct
{
    char* pValue;
} ScBpeVocabItem;

typedef struct
{
    u32 A;
    u32 B;
    i32 Count;
} ScBpeTokenPair;

typedef struct
{
    u32 T0;
    u32 T1;
    u32 Tf;
} ScAiMerge;

typedef enum
{
    ScAiSpecialToken_Unk = 256,
    ScAiSpecialToken_Pad = 257,
    ScAiSpecialToken_Bos = 258,
    ScAiSpecialToken_Eos = 259,
    ScAiSpecialToken_Sep = 260
} ScAiSpecialToken;

typedef struct
{
    u32* aTokens;
    ScAiMerge* aMerges;
    ScBpeVocabItem* aVocab;
} ScAiBpe;

typedef struct
{
    ScAiBpe Bpe;
    void* pProfiler;
    i64 TotalTextLength;
    i64 TotalTextLengthCompressed;
    char* pFilePath;

    char* pText;
    i8 ShouldAddText;
    i8 ShouldAddTokens;
} ScAiBpeSaveToDiskConfig;

typedef struct
{
    char* pText;
    i64 TextLength;
    ScAiBpe Bpe;
} ScAiTokenizeConfig;

/*
 Параметр маленькой модели: веса, накопленный градиент и состояние Adam.
 */
typedef struct
{
    f32* pData;
    f32* pGrad;
    f32* pM;
    f32* pV;
    i64 Count;
} ScAiParam;

typedef struct
{
    i32 VocabCount;
    i32 ContextLength;
    i32 EmbeddingDim;
    i32 HiddenDim;
    u64 Seed;
} ScAiModelConfig;

/*
 Минимальная языковая модель: embedding текущего окна токенов, один
 скрытый слой и softmax над словарём. Это компактный baseline для
 проверки всего пайплайна; transformer-блоки можно добавить позже.
 */
typedef struct
{
    ScAiParam TokenEmbedding;
    ScAiParam PositionEmbedding;
    ScAiParam HiddenWeights;
    ScAiParam HiddenBias;
    ScAiParam OutputWeights;
    ScAiParam OutputBias;

    f32* aContextX;
    f32* aHidden;
    f32* aLogits;
    f32* aProbs;
    f32* aHiddenGrad;
    f32* aPreActivationGrad;
    f32* aContextGrad;

    i32 VocabCount;
    i32 ContextLength;
    i32 EmbeddingDim;
    i32 HiddenDim;
} ScAiModel;

typedef struct
{
    char* pInput;
    char* pOutput;
} ScAiDialogPair;

typedef struct
{
    ScAiDialogPair* aPairs;
    i64 Count;
} ScAiDialogDataset;

typedef struct
{
    i32 Steps;
    i32 BatchSize;
    f32 LearningRate;
    i32 LogEvery;
} ScAiTrainConfig;

typedef struct
{
    i32 MaxTokens;
    f32 Temperature;
    i32 TopK;
    u64 Seed;
} ScAiGenerateConfig;

// DOCS: Create and learn bpe-tokenizer
ScAiBpe sc_ai_bpe_new(ScAiBpeConfig cfg);
// DOCS: More optimized tokenizer, wip (Create and learn bpe-tokenizer)
ScAiBpe sc_ai_bpe_new2(ScAiBpeConfig cfg);

// DOCS: Tokenize text using learned bpe. Returns a list of token ids.
i32* sc_ai_bpe_tokenize(ScAiTokenizeConfig cfg);
// DOCS: Decode token ids back to a NUL-terminated string.
char* sc_ai_bpe_decode(ScAiBpe bpe, i32* aTokens);

// DOCS: save to disk
void sc_ai_bpe_save_to_disk(ScAiBpeSaveToDiskConfig cfg);
// DOCS: Load *.bpe file from disk
ScAiBpe sc_ai_bpe_load_from_disk(char* pFile);
// DOCS: Load bpe data from memory
ScAiBpe sc_ai_bpe_load_from_memory(char* pData, i64 dataSize);

// DOCS: Create/destroy a small language model.
ScAiModel sc_ai_model_new(ScAiModelConfig cfg);
void sc_ai_model_destroy(ScAiModel* pModel);
// DOCS: Train on (input message -> answer) pairs.
void sc_ai_model_train(ScAiModel* pModel, ScAiBpe bpe, ScAiDialogDataset dataset, ScAiTrainConfig cfg);
// DOCS: Generate an answer for the input message.
char* sc_ai_model_generate(ScAiModel* pModel, ScAiBpe bpe, char* pMessage, ScAiGenerateConfig cfg);

// DOCS: Debug utils
void sc_bpe_token_pair_print(ScBpeTokenPair pair, i32 done, i32 total);

#endif // SC_AI_H
