#include "Sc/Gfx/Vk.h"
#include "Sc/Sc.h"
#include "Sc/Sc.h"
#include "Sc/Types.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xcb/xproto.h>

#if defined(SC_PLATFORM_WINDOWS)
#error "Implementation pending"
#elif defined(SC_PLATFORM_LINUX)
// #include <vulkan/vulkan_xcb.h>
#include <xcb/xcb.h>
#endif

#define sc_vk_error(pScVk, pMessage) sc_vk_error_ext0(pScVk, pMessage, __LINE__)
#define sc_vk_fatal(pScVk, pMessage) sc_vk_fatal_ext(pScVk, pMessage, __LINE__)
#define sc_vk_warning(pScVk, pMessage) sc_vk_warning_ext(pScVk, pMessage, __LINE__)

void sc_vk_error_ext0(ScVk* pScVk, const char* pMessage, i32 line);
void sc_vk_fatal_ext(ScVk* pScVk, const char* pMessage, i32 line);
void sc_vk_warning_ext(ScVk* pScVk, const char* pMessage, i32 line);

typedef struct
{
    u32 Version;
    const char* pName;
    const char* pWindowExtension;
} ScVkInstanceConfig;

VkExtensionProperties*
sc_vk_instance_extension_enumerator(ScVk* pScVk)
{
    u32 count;
    vkEnumerateInstanceExtensionProperties(NULL, &count, NULL);

    VkExtensionProperties* aExtProperties = sc_list_reserve(aExtProperties, count);

    VkResult enumResult = vkEnumerateInstanceExtensionProperties(NULL, &count, aExtProperties);
    if (enumResult != VK_SUCCESS)
    {
        sc_log_erro("vkEnumerateInstanceExtensionProperties %s\n", vk_result_to_string(enumResult));

        char buf[128] = {};
        snprintf(buf, 128, "vkEnumerateInstanceExtensionProperties error %d!\n", enumResult);
        sc_guard(0 && "Failed!");
        sc_vk_error(pScVk, buf);
        return NULL;
    }

    sc_list_header(aExtProperties)->Count = count;

    return aExtProperties;
}

char**
sc_vk_get_required_extensions(ScVk* pScVk, VkExtensionProperties* aExtProperties, const char* pWindowExt)
{
    char** aExts = NULL;
    for (i32 i = 0; i < sc_list_count(aExtProperties); ++i)
    {
        VkExtensionProperties prop = aExtProperties[i];
        if (sc_string_compare(prop.extensionName, "VK_KHR_surface"))
        {
            sc_list_add(aExts, (char*)"VK_KHR_surface");
        }
        // DOCS: include only if exist in extProps
        else if (sc_string_compare(prop.extensionName, (char*)pWindowExt))
        {
            sc_list_add(aExts, (char*)pWindowExt);
        }
    }

#if defined(SC_BUILD_DEBUG)
    sc_list_add(aExts, VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
#endif // SC_BUILD_DEBUG

    return aExts;
}

char**
sc_vk_get_validation_layers(ScVk* pScVk)
{
    char** aValidationLayers = NULL;
    if (pScVk->Flags.IsDebug)
        sc_list_add(aValidationLayers, "VK_LAYER_KHRONOS_validation");
    return aValidationLayers;
}

static VkBool32
sc_vk_validation_error(VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
    VkDebugUtilsMessageTypeFlagsEXT messageTypes,
    const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
    void* pUserData)
{
    const char* pLevel = NULL;
    switch (messageSeverity)
    {
    case VK_DEBUG_UTILS_MESSAGE_SEVERITY_INFO_BIT_EXT:
    {
        sc_log_info("%s\n", pCallbackData->pMessage);
        break;
    }
    case VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT:
    {
        sc_log_warn("%s\n", pCallbackData->pMessage);
        break;
    }
    case VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT:
    {
        sc_log_erro("%s\n", pCallbackData->pMessage);
        break;
    }
    default:
        sc_log_info("%s\n", pCallbackData->pMessage);
        break;
    }

    return VK_TRUE;
}

VkDebugUtilsMessengerCreateInfoEXT*
sc_vk_get_debug_utils_messanger(ScVk* pScVk)
{
#if defined(SC_BUILD_DEBUG)
    static VkDebugUtilsMessengerCreateInfoEXT debug = (VkDebugUtilsMessengerCreateInfoEXT) {
        .sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT,
        .flags = 0,
        .messageSeverity =
            /* VK_DEBUG_UTILS_MESSAGE_SEVERITY_INFO_BIT_EXT | */ VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT,
        .messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT,
        .pfnUserCallback = sc_vk_validation_error,
        .pUserData = NULL
    };

    return &debug;
#else // defined(SC_BUILD_RELEASE)
    return NULL;
#endif
}

static ScVkStageConfig*
get_stage_config(ScVkPipelineConfig cfg, ScVkStageType type)
{
    for (i32 s = 0; s < cfg.StagesCount; ++s)
    {
        ScVkStageConfig* pStageCfg = &cfg.aStages[s];
        if (pStageCfg->Type == type)
            return pStageCfg;
    }
    return NULL;
}

static i32
get_tesselation_patch_ctrl_points(ScVkPipelineConfig cfg)
{
    ScVkStageConfig* pTesselationCtrl = get_stage_config(cfg, ScVkStageType_Tesselation_Control);
    return pTesselationCtrl != NULL ? pTesselationCtrl->PatchControlPoints : 0;
}

void
sc_vk_instance_init(ScVk* pScVk, ScVkInstanceConfig config)
{
    if (config.pName == NULL)
    {
        sc_vk_error(pScVk, "config.pName == NULL\n");
    }

    u32 vulkanVerison = config.Version;
    if (vulkanVerison == 0)
        vulkanVerison = VK_MAKE_API_VERSION(0, 1, 0, 0);

    printf("before sc_vk_instance_extension_enumerator\n");
    VkExtensionProperties* aExtProperties = sc_vk_instance_extension_enumerator(pScVk);
    printf("after sc_vk_instance_extension_enumerator\n");
    if (!aExtProperties)
    {
        sc_vk_error(pScVk, "sc_vk_instance_extension_enumerator failed.\n");
    }

    char** aExts = sc_vk_get_required_extensions(pScVk, aExtProperties, config.pWindowExtension);
    sc_list_free(aExtProperties);
    if (!aExts)
    {
        sc_vk_error(pScVk, "sc_vk_get_required_extensions failed");
    }

    sc_list_for_each(aExts, pExt)
    {
        printf("Ext: %s\n", *pExt);
    }

    char** aValidationLayerNames = sc_vk_get_validation_layers(pScVk);

    VkDebugUtilsMessengerCreateInfoEXT* pDebug = sc_vk_get_debug_utils_messanger(pScVk);

    VkApplicationInfo applicationInfo = {
        .sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
        .pNext = NULL,
        .pApplicationName = config.pName,
        .applicationVersion = VK_MAKE_API_VERSION(0, 1, 0, 0),
        .pEngineName = config.pName,
        .engineVersion = VK_MAKE_API_VERSION(0, 1, 0, 0),
        .apiVersion = vulkanVerison
    };

    VkInstanceCreateInfo instanceCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
        .pNext = pDebug,
        .flags = 0,
        .pApplicationInfo = &applicationInfo,
        .enabledLayerCount = sc_list_count(aValidationLayerNames),
        .ppEnabledLayerNames = (const char* const*)aValidationLayerNames,
        .enabledExtensionCount = sc_list_count(aExts),
        .ppEnabledExtensionNames = (const char* const*)aExts
    };

    VkInstance vkInstance;
    printf("before vkCreateInstance\n");
    VkResult createInstanceResult = vkCreateInstance(&instanceCreateInfo, pScVk->pAllocator, &vkInstance);
    printf("after vkCreateInstance\n");
    if (createInstanceResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Can't create instance");
    }

    VkDebugUtilsMessengerEXT messenger;

    if (pScVk->Flags.IsDebug)
    {
        PFN_vkCreateDebugUtilsMessengerEXT vkCreateDebugUtilsMessenger = (PFN_vkCreateDebugUtilsMessengerEXT)
            vkGetInstanceProcAddr(vkInstance,
                "vkCreateDebugUtilsMessengerEXT");

        VkResult createResult = vkCreateDebugUtilsMessenger(vkInstance, pDebug, pScVk->pAllocator, &messenger);

        if (createResult != VK_SUCCESS)
        {
            sc_vk_error(pScVk, "Can't create debug utils");
        }

#if SC_BUILD_DEBUG
        pScVk->Debug.UtilMessager = messenger;
#endif // SC_BUILD_DEBUG
    }

    pScVk->Handle = vkInstance;
}

#if defined(SC_PLATFORM_LINUX)

#define VK_KHR_xcb_surface 1
#define VK_KHR_XCB_SURFACE_SPEC_VERSION 6
#define VK_KHR_XCB_SURFACE_EXTENSION_NAME "VK_KHR_xcb_surface"

typedef VkFlags VkXcbSurfaceCreateFlagsKHR;

typedef struct VkXcbSurfaceCreateInfoKHR
{
    VkStructureType sType;
    const void* pNext;
    VkXcbSurfaceCreateFlagsKHR flags;
    xcb_connection_t* connection;
    xcb_window_t window;
} VkXcbSurfaceCreateInfoKHR;

typedef VkResult(VKAPI_PTR* PFN_vkCreateXcbSurfaceKHR)(VkInstance instance, const VkXcbSurfaceCreateInfoKHR* pCreateInfo, const VkAllocationCallbacks* pAllocator, VkSurfaceKHR* pSurface);
typedef VkBool32(VKAPI_PTR* PFN_vkGetPhysicalDeviceXcbPresentationSupportKHR)(VkPhysicalDevice physicalDevice, uint32_t queueFamilyIndex, xcb_connection_t* connection, xcb_visualid_t visual_id);

#ifndef VK_NO_PROTOTYPES
#ifndef VK_ONLY_EXPORTED_PROTOTYPES

VKAPI_ATTR VkResult VKAPI_CALL vkCreateXcbSurfaceKHR(
    VkInstance instance,
    const VkXcbSurfaceCreateInfoKHR* pCreateInfo,
    const VkAllocationCallbacks* pAllocator,
    VkSurfaceKHR* pSurface);

VKAPI_ATTR VkBool32 VKAPI_CALL vkGetPhysicalDeviceXcbPresentationSupportKHR(
    VkPhysicalDevice physicalDevice,
    uint32_t queueFamilyIndex,
    xcb_connection_t* connection,
    xcb_visualid_t visual_id);

#endif
#endif

#elif defined(SC_PLATFORM_WINDOWS)

#endif // SC_PLATFORM_WINDOWS

void
sc_vk_surface(ScVk* pScVk, ScVkWindowBackend windowBackend)
{
#if defined(SC_PLATFORM_WINDOWS)
#error "Implementation pending"
#elif defined(SC_PLATFORM_LINUX)
    xcb_window_t window = *(xcb_window_t*)windowBackend.pXcbWindow;
    xcb_connection_t* pConnection = (xcb_connection_t*)windowBackend.pXcbConnection;

    PFN_vkCreateXcbSurfaceKHR pfnCreateXcbSurfaceKHR = (PFN_vkCreateXcbSurfaceKHR)vkGetInstanceProcAddr(pScVk->Handle, "vkCreateXcbSurfaceKHR");

    if (!pfnCreateXcbSurfaceKHR)
    {
        sc_vk_error(pScVk, "VK_KHR_xcb_surface extension not available\n");
        pScVk->Surface = VK_NULL_HANDLE;
        return;
    }

    // 2. Prepare surface creation info
    VkXcbSurfaceCreateInfoKHR createInfo = {
        .sType = VK_STRUCTURE_TYPE_XCB_SURFACE_CREATE_INFO_KHR,
        .pNext = NULL,
        .flags = 0,
        .connection = pConnection,
        .window = window
    };

    // 3. Create the surface
    VkSurfaceKHR surface = VK_NULL_HANDLE;
    VkResult result = pfnCreateXcbSurfaceKHR(pScVk->Handle, &createInfo, NULL, &surface);

    printf("Surface pointer: %p\n", surface);

    if (result != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Failed to create XCB surface\n");
        pScVk->Surface = VK_NULL_HANDLE;
        return;
    }

    pScVk->Surface = surface;
#endif // SC_PLATFORM_LINUX
}

void
sc_vk_devices_create(ScVk* pScVk)
{
    // DOCS: Get Physical Device
    VkPhysicalDevice physicalDevice = VK_NULL_HANDLE;
    VkPhysicalDeviceProperties vkProperties;

    VkPhysicalDevice* aDevices = sc_vk_get_devices(pScVk);
    i32 deviceCount = sc_list_count(aDevices);
    for (i32 i = 0; i < deviceCount; ++i)
    {
        VkPhysicalDeviceProperties physicalDeviceProperties;
        VkPhysicalDevice device = aDevices[i];
        vkGetPhysicalDeviceProperties(device, &physicalDeviceProperties);

        VkPhysicalDeviceFeatures deviceFeatures;
        vkGetPhysicalDeviceFeatures(device, &deviceFeatures);

        if (deviceFeatures.samplerAnisotropy
            && deviceFeatures.multiDrawIndirect
            && deviceFeatures.tessellationShader)
        {
            physicalDevice = device;
            vkProperties = physicalDeviceProperties;
            break;
        }
    }

    if (physicalDevice == VK_NULL_HANDLE)
    {
        sc_vk_fatal(pScVk, "Can't pick physical device!\n");
    }

    pScVk->PhysicalDevice = physicalDevice;

    VkExtensionProperties* aExtensionProperties = sc_vk_get_device_extensions(pScVk, physicalDevice);

    if (1) /* todo: add variable here */
    {
        printf("[Physical Device] { \n\t"
               ".apiVersion = %d.%d.%d ,\n\t"
               ".driverVersion = %d.%d.%d,\n\t"
               ".vendorID = %d,\n\t"
               ".deviceID = %d,\n\t"
               ".deviceType = %s,\n\t"
               ".deviceName = %s\n}\n",

            // api version
            VK_API_VERSION_MAJOR(vkProperties.apiVersion),
            VK_API_VERSION_MINOR(vkProperties.apiVersion),
            VK_API_VERSION_PATCH(vkProperties.apiVersion),

            // driver version
            VK_API_VERSION_MAJOR(vkProperties.driverVersion),
            VK_API_VERSION_MINOR(vkProperties.driverVersion),
            VK_API_VERSION_PATCH(vkProperties.driverVersion),

            vkProperties.vendorID,
            vkProperties.deviceID,
            sc_vk_device_type_to_string(vkProperties.deviceType),
            vkProperties.deviceName);
    }

    // DOCS: Find Queue;s
    VkQueueFamilyProperties* aFamilyProperties = sc_vk_get_queues_family_properties(pScVk);

    i32 graphicsIndex = -1, presentationIndex = -1;

    i32 familyPropertiesCount = sc_list_count(aFamilyProperties);
    for (i32 i = 0; i < familyPropertiesCount; ++i)
    {
        char* flagAsStr = NULL;
        VkQueueFamilyProperties familyProperty = aFamilyProperties[i];

        VkBool32 isSurfaceKhrSupported;
        VkResult getSupportForKhrResult = vkGetPhysicalDeviceSurfaceSupportKHR(pScVk->PhysicalDevice, i, pScVk->Surface, &isSurfaceKhrSupported);
        if (getSupportForKhrResult != VK_SUCCESS)
        {
            sc_vk_fatal(pScVk, "vkGetPhysicalDeviceSurfaceSupportKHR error");
        }

        if (familyProperty.queueFlags & VK_QUEUE_GRAPHICS_BIT || familyProperty.queueFlags & VK_QUEUE_COMPUTE_BIT)
        {
            graphicsIndex = i;
        }

        if (isSurfaceKhrSupported == VK_TRUE)
        {
            presentationIndex = i;
        }

        if (graphicsIndex != -1 && presentationIndex != -1)
        {
            break;
        }
    }

    pScVk->GraphicsQueueIndex = graphicsIndex;
    pScVk->PresentationQueueIndex = presentationIndex;

    // DOCS: Create Logical Device
    // TODO(typedef): Check if video card support it
    VkPhysicalDeviceFeatures physcialDeviceFeatures = {
        /*
          DOCS(typedef): we need special features
        */

        // DOCS(typedef): For antisotropic filtering for textures x8, x16
        .samplerAnisotropy = VK_TRUE,

        // DOCS(typedef): For enabling none VK_POLYGON_MODE_FILL fill mode
        .fillModeNonSolid = VK_TRUE,

        // DOCS(typedef): MultiDrawIndirect feature for modern renderer
        .multiDrawIndirect = VK_TRUE,

        .depthClamp = VK_TRUE,

        // DOCS(tdef): For terrain
        .tessellationShader = VK_TRUE,
    };

    VkPhysicalDeviceVulkan12Features physicalFeatures2 = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES,
        .shaderSampledImageArrayNonUniformIndexing = VK_TRUE,
        .runtimeDescriptorArray = VK_TRUE
    };

    /*
          DOCS(typedef): Create info for creating Queue's.
          As Queue's created within VkDevice we need make CreateInfo
          structs for them as well, before creating VkDevice.
        */
    f32 queuePriority = 1.0f;
    VkDeviceQueueCreateInfo* aQueueCreateInfos = NULL;
    VkDeviceQueueCreateInfo graphicsQueueCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .queueFamilyIndex = graphicsIndex,
        .queueCount = 1,
        .pQueuePriorities = &queuePriority
    };
    sc_list_add(aQueueCreateInfos, graphicsQueueCreateInfo);

    if (graphicsIndex != presentationIndex)
    {
        VkDeviceQueueCreateInfo presentationQueueCreateInfo = {
            .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
            .pNext = NULL,
            .flags = 0,
            .queueFamilyIndex = presentationIndex,
            .queueCount = 1,
            .pQueuePriorities = &queuePriority
        };
        sc_list_add(aQueueCreateInfos, presentationQueueCreateInfo);
    }

    const char* aDeviceExts[] = {
        VK_KHR_SWAPCHAIN_EXTENSION_NAME
    };
    VkDeviceCreateInfo deviceCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
        .pNext = &physicalFeatures2,
        .flags = 0,
        .queueCreateInfoCount = sc_list_count(aQueueCreateInfos),
        .pQueueCreateInfos = aQueueCreateInfos,
        .enabledExtensionCount = ScArrayCount(aDeviceExts),
        .ppEnabledExtensionNames = aDeviceExts,
        .pEnabledFeatures = &physcialDeviceFeatures
    };

    VkDevice vkDevice;
    VkResult deviceCreateResult = vkCreateDevice(pScVk->PhysicalDevice, &deviceCreateInfo, pScVk->pAllocator, &vkDevice);
    if (deviceCreateResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkCreateDevice call error!\n");
    }

    pScVk->Device = vkDevice;

    vkGetDeviceQueue(vkDevice, graphicsIndex, 0, &pScVk->GraphicsQueue);
    if (pScVk->GraphicsQueue == VK_NULL_HANDLE)
    {
        sc_vk_fatal(pScVk, "Error creating graphics queue!\n");
    }

    vkGetDeviceQueue(vkDevice, presentationIndex, 0, &pScVk->PresentationQueue);
    if (pScVk->PresentationQueue == VK_NULL_HANDLE)
    {
        sc_vk_fatal(pScVk, "Error creating presentation queue!\n");
    }

    sc_list_free(aFamilyProperties);
    sc_list_free(aQueueCreateInfos);
}

void
sc_vk_sync_create(ScVk* pScVk)
{
    // pScVk->ImageAvailableSemaphore = sc_vk_sync_semaphore_new(pScVk, 0);
    // pScVk->RenderFinishedSemaphore = sc_vk_sync_semaphore_new(pScVk, 0);
    // pScVk->FrameFence = sc_vk_sync_fence_new(pScVk, VK_FENCE_CREATE_SIGNALED_BIT);

    VkSemaphore* aImageAvailableSemaphores = NULL;
    VkSemaphore* aRenderFinishedSemaphores = NULL;
    VkFence* aFrameFences = NULL;

    sc_vk_get_swap_images(pScVk, pScVk->Swap.Swapchain);

    u32 imagesCount = 0;
    VkResult result = vkGetSwapchainImagesKHR(pScVk->Device, pScVk->Swap.Swapchain, &imagesCount, NULL);
    if (result != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "sc_vk_sync_create, can;t get vkGetSwapchainImagesKHR!\n");
    }

    for (i32 i = 0; i < imagesCount; ++i)
    {
        sc_list_add(aImageAvailableSemaphores, sc_vk_sync_semaphore_new(pScVk, 0));
        sc_list_add(aRenderFinishedSemaphores, sc_vk_sync_semaphore_new(pScVk, 0));
        sc_list_add(aFrameFences, sc_vk_fence_new(pScVk, VK_FENCE_CREATE_SIGNALED_BIT));
    }

    pScVk->aImageAvailableSemaphores = aImageAvailableSemaphores;
    pScVk->aRenderFinishedSemaphores = aRenderFinishedSemaphores;
    pScVk->aFrameFences = aFrameFences;
}

void
sc_vk_cmd_create(ScVk* pScVk)
{
    pScVk->Cmd.GraphicsPool = sc_vk_cmd_pool_new(pScVk, pScVk->GraphicsQueueIndex);
    pScVk->Cmd.GraphicsBuffer = sc_vk_cmd_buffer_new(pScVk, pScVk->Cmd.GraphicsPool);

    VkCommandBuffer* aList = NULL;
    VkImage* aImages = sc_vk_get_swap_images(pScVk, pScVk->Swap.Swapchain);
    i32 listCount = sc_list_count(aImages);
    for (i32 i = 0; i < listCount; ++i)
    {
        VkCommandBuffer cmd = sc_vk_cmd_buffer_new(pScVk, pScVk->Cmd.GraphicsPool);
        sc_list_add(aList, cmd);
    }

    pScVk->Cmd.aList = aList;
    sc_assert_not_null(pScVk->Cmd.aList);
}

void
sc_vk_swap_create(ScVk* pScVk, ScVkConfig config)
{
    ScVkSwapchainConfig cfg = {
        .IsVsync = config.IsVsync,
        .Resolution = (VkExtent2D) { config.WindowSize.Width, config.WindowSize.Height },
        .SurfaceFormat = (VkSurfaceFormatKHR) {
            .format = VK_FORMAT_B8G8R8A8_UNORM, // VK_FORMAT_R8G8B8A8_SRGB,
            .colorSpace = VK_COLOR_SPACE_SRGB_NONLINEAR_KHR },
        .PrevSwapchain = VK_NULL_HANDLE
    };
    pScVk->Swap = sc_vk_swapchain_new(pScVk, cfg);
}

void
create_final_pass(ScVk* pScVk)
{
    VkSampleCountFlags samplesCount = VK_SAMPLE_COUNT_1_BIT;

    VkAttachmentDescription colorAttachment = {
        .format = pScVk->Swap.SurfaceFormat.format,
        .samples = samplesCount,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR
    };

    VkAttachmentReference colorAttachmentRef = {
        .attachment = 0,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
    };

    VkSubpassDescription subpass = {
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount = 1,
        .pColorAttachments = &colorAttachmentRef
    };

    // Dependency - ждем завершения предыдущих pass'ов
    VkSubpassDependency dependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .srcAccessMask = 0,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT
    };

    VkRenderPassCreateInfo renderPassInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .attachmentCount = 1,
        .pAttachments = &colorAttachment,
        .subpassCount = 1,
        .pSubpasses = &subpass,
        .dependencyCount = 1,
        .pDependencies = &dependency
    };

    VkRenderPass renderPass;
    VkResult result = vkCreateRenderPass(pScVk->Device, &renderPassInfo, NULL, &renderPass);
    if (result != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Failed to create final render pass");
    }

    VkImageView* aAttachmentViews = NULL;
    VkImageView* aSwapImageViews = NULL;

    VkImage* aSwapImages = sc_vk_get_swap_images(pScVk, pScVk->Swap.Swapchain);

    sc_list_for_each(aSwapImages, pImage)
    {
        VkImageViewCreateInfo ci = {
            .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
            .pNext = NULL,
            .flags = 0,
            .image = *pImage,
            .viewType = VK_IMAGE_VIEW_TYPE_2D,
            .format = colorAttachment.format,
            .components = {
                .r = VK_COMPONENT_SWIZZLE_IDENTITY,
                .g = VK_COMPONENT_SWIZZLE_IDENTITY,
                .b = VK_COMPONENT_SWIZZLE_IDENTITY,
                .a = VK_COMPONENT_SWIZZLE_IDENTITY },
            .subresourceRange = { .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT, .baseMipLevel = 0, .levelCount = 1, .baseArrayLayer = 0, .layerCount = 1 }
        };
        VkImageView swapImageView = sc_vk_image_view_new(pScVk, ci);

        sc_list_add(aSwapImageViews, swapImageView);
    }

    /*
       DOCS: Creating framebuffer;s
    */
    i32 framebuffersCount = sc_list_count(aSwapImages);
    ScVkFramebuffer* aFramebuffers = NULL;
    for (i32 f = 0; f < framebuffersCount; ++f)
    {
        ScVkFramebuffer scVkFramebuffer = sc_vk_framebuffer_new_swapchain(pScVk, renderPass, &aSwapImageViews[f], 1);
        sc_list_add(aFramebuffers, scVkFramebuffer);
    }

    ScVkRenderPass scVkRenderPass = {
        .Type = ScVkRenderPassType_Final,
        .Handle = renderPass,
        .aFramebuffers = aFramebuffers,
        .Samples = samplesCount
    };

    pScVk->FinalPassId = sc_vk_register_render_pass(pScVk, &scVkRenderPass);
}

typedef struct
{
    i32 PassesCount;
} ComposityUbo;

void
create_final_pipe(ScVk* pScVk)
{
    ScVkDescriptorConfig uniformDescr = {
        .pName = "u_Composite",
        .Type = ScVkDescriptorType_Uniform,
        .Binding = 0,
        .Count = 1,
        .Size = sizeof(ComposityUbo)
    };
    ScVkDescriptorConfig image3Descr = {
        .pName = "aPassImages",
        .Type = ScVkDescriptorType_Image,
        .Binding = 1,
        .Count = 5
    };

    ScVkDescriptorConfig aDescriptors[] = {
        [0] = uniformDescr,
        [1] = image3Descr,
    };

    ScVkStageConfig vertexStage = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/FinalPipe.vert",
        .DescriptorsCount = 0
    };

    ScVkStageConfig fragmentStage = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/FinalPipe.frag",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = 2
    };

    ScVkStageConfig aStages[] = {
        [0] = vertexStage,
        [1] = fragmentStage
    };

    ScVkAttribute aAttributes[] = {};

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .RenderPassId = pScVk->FinalPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .StagesCount = ScArrayCount(aStages),
        .Stride = 0,
        .AttributesCount = 0,
    });
    // sc_vk_pipeline_config_print(pScVk, pipeCfg);

    pScVk->FinalPipeId = sc_vk_pipeline_new(pScVk, pipeCfg);
}

/*

  ###################################
  ###################################
  sc_vk_
  ###################################
  ###################################

*/

ScVk
sc_vk_new(ScVkConfig config)
{
    sc_vulkan_init();

    ScVk scVk = {
        .Flags = {
            .IsDebug = config.IsDebug,
            .IsVsync = config.IsVsync },
        .Messages = { .OnError = config.OnError, .OnWarning = config.OnWarning }
    };

    ScVkInstanceConfig instanceConfig = {
        .Version = config.VulkanVersion,
        .pName = sc_if_null(config.pName, "ScVkApp"),
        .pWindowExtension = (char*)
#if defined(SC_PLATFORM_WINDOWS)
            "VK_KHR_win32_surface"
#elif defined(SC_PLATFORM_LINUX)
            "VK_KHR_xcb_surface"
#endif // SC_PLATFORM_LINUX
    };
    sc_vk_instance_init(&scVk, instanceConfig);

    sc_vk_surface(&scVk, config.WindowBackend);

    sc_vk_devices_create(&scVk);

    sc_vk_swap_create(&scVk, config);
    sc_vk_sync_create(&scVk);
    sc_vk_cmd_create(&scVk); // depends on sc_vk_swap_create()

    scVk.WindowSize = config.WindowSize;

    create_final_pass(&scVk);
    create_final_pipe(&scVk);
    scVk.DefaultLinearSampler = sc_vk_sampler_create(&scVk, VK_FILTER_LINEAR, VK_FILTER_LINEAR, 1);

    return scVk;
}

void
sc_vk_destroy(ScVk* pScVk)
{
    vkDeviceWaitIdle(pScVk->Device);

    sc_vk_render_pass_destroy(pScVk, pScVk->FinalPassId);
    sc_vk_pipeline_destroy_by_id(pScVk, pScVk->FinalPipeId);
    sc_vk_sampler_destroy(pScVk, pScVk->DefaultLinearSampler);

    // note: убрал отсюда удаление пайпов и пасов, так как удаляю это все на стороне приложения.
    // мб имеет смысл сделать отдельную функцию для этого.

    sc_vk_destroy_pipes_and_passes(pScVk);

    // DOCS: Destroy swapchain
    for (i32 iv = 0; iv < sc_list_count(pScVk->aImageAvailableSemaphores); ++iv)
    {
        // DOCS: Destroy sync primitives
        vkDestroySemaphore(pScVk->Device, pScVk->aImageAvailableSemaphores[iv], pScVk->pAllocator);
        vkDestroySemaphore(pScVk->Device, pScVk->aRenderFinishedSemaphores[iv], pScVk->pAllocator);
        vkDestroyFence(pScVk->Device, pScVk->aFrameFences[iv], pScVk->pAllocator);
    }
    vkDestroySwapchainKHR(pScVk->Device, pScVk->Swap.Swapchain, pScVk->pAllocator);

    // DOCS: Destroy render passes

    // DOCS: Destroy cmd
    vkDestroyCommandPool(pScVk->Device, pScVk->Cmd.GraphicsPool, pScVk->pAllocator);

    // DOCS: Destroy (logical) device
    vkDestroyDevice(pScVk->Device, pScVk->pAllocator);

#if defined(SC_BUILD_DEBUG)
    if (pScVk->Flags.IsDebug)
    {
        PFN_vkDestroyDebugUtilsMessengerEXT vkDestroyDebugUtilsMessengerEXT = (PFN_vkDestroyDebugUtilsMessengerEXT)
            vkGetInstanceProcAddr(pScVk->Handle, "vkDestroyDebugUtilsMessengerEXT");

        vkDestroyDebugUtilsMessengerEXT(pScVk->Handle, pScVk->Debug.UtilMessager, pScVk->pAllocator);
    }
#endif // SC_BUILD_DEBUG

    // DOCS: Destroy surface
    vkDestroySurfaceKHR(pScVk->Handle, pScVk->Surface, pScVk->pAllocator);

    vkDestroyInstance(pScVk->Handle, pScVk->pAllocator);
}

void
sc_vk_destroy_pipes_and_passes(ScVk* pScVk)
{
    sc_vk_uniform_buffer_free(pScVk);

    i64 pipesCount = sc_list_count(pScVk->aPipelines);
    sc_log_info("Pipe count: %d\n", pipesCount);
    for (i32 p = 1; p < pipesCount; ++p)
    {
        ScVkPipeline pipe = pScVk->aPipelines[p];
        sc_vk_pipeline_destroy(pScVk, pipe);
    }
    i64 passesCount = sc_list_count(pScVk->aRenderPasses);
    sc_log_info("Render passes count: %d\n", passesCount);
    for (i32 p = 1; p < passesCount; ++p)
    {
        ScVkRenderPass pass = pScVk->aRenderPasses[p];
        sc_vk_render_pass_destroy(pScVk, pass.Id);
    }

    // NOTE: Не объединять удаление пайпов и пасов.Нет гарантии что их count будут равны.
    // DOCS: Удаляем с конца, так как это быстрее.
    for (i32 p = (pipesCount - 1); p > 1; --p)
    {
        sc_list_remove_index(pScVk->aPipelines, p);
    }

    for (i32 p = (passesCount - 1); p > 1; --p)
    {
        sc_list_remove_index(pScVk->aRenderPasses, p);
    }
}

void
sc_vk_set_passes_images(ScVk* pScVk, Sc2dTexture* aTextures, i32 texturesCount)
{
    sc_list_clear(pScVk->aImages);

    ScVkPipeline* pPipe = sc_vk_get_pipeline(pScVk, pScVk->FinalPipeId);

    ScVkUniform* pCompositeUniform = sc_vk_pipeline_get_uniform(pPipe, "u_Composite");
    i32 passesCount = texturesCount;
    sc_vk_uniform_set(pScVk, pCompositeUniform, &passesCount, 0, sizeof(i32));

    for (i32 t = 0; t < texturesCount; ++t)
    {
        Sc2dTexture sctxt = aTextures[t];
        VkDescriptorImageInfo imageInfo = {
            .sampler = sctxt.Sampler,
            .imageView = sctxt.View,
            .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
        };
        sc_list_add(pScVk->aImages, imageInfo);
    }

    VkWriteDescriptorSet aWriteSets[] = {
        [0] = {
            .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
            .dstSet = pPipe->ShaderBridge.Set,
            .dstBinding = 1,
            .dstArrayElement = 0,
            .descriptorCount = sc_list_count(pScVk->aImages),
            .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
            .pImageInfo = pScVk->aImages,
        }
    };

    vkUpdateDescriptorSets(pScVk->Device, ScArrayCount(aWriteSets), aWriteSets, 0, NULL);
}

void
sc_vk_draw(ScVk* pScVk, i64* aRenderPassIds, i32 renderPassesCount)
{
    u32 s_image_index = 0;
    static u64 noTime = UINT64_MAX;

    // if (g.ResizeMemory.IsResizePending)
    // {
    //     sc_log_warn("Resize is pending not rendering anything!\n");
    //     return;
    // }

    ScVkRenderPass* pFinalPass = sc_vk_get_render_pass(pScVk, pScVk->FinalPassId);
    pScVk->SyncIndex = (pScVk->SyncIndex + 1) % sc_list_count(pFinalPass->aFramebuffers);
    ScVkPipeline* pFinalPipe = sc_vk_get_pipeline(pScVk, pScVk->FinalPipeId);

    // todo: Put inside finalPass.
    VkSemaphore* pAvailableSemaphore = &pScVk->aImageAvailableSemaphores[pScVk->SyncIndex];
    VkSemaphore* pFinishedSemaphore = &pScVk->aRenderFinishedSemaphores[pScVk->SyncIndex];
    VkFence* pFrameFence = &pScVk->aFrameFences[pScVk->SyncIndex];

    // DOCS: Ждем завершения предыдущего кадра
    vkWaitForFences(pScVk->Device, 1, pFrameFence, VK_TRUE, noTime);
    vkResetFences(pScVk->Device, 1, pFrameFence);

    // DOCS: Получаем следующее изображение от swapchain
    VkResult accuireNextImageResult = vkAcquireNextImageKHR(pScVk->Device, pScVk->Swap.Swapchain, noTime, *pAvailableSemaphore, VK_NULL_HANDLE, &s_image_index);

    if (accuireNextImageResult == VK_ERROR_OUT_OF_DATE_KHR || accuireNextImageResult == VK_SUBOPTIMAL_KHR)
    {
        // mrql_renderer_request_resize();
        sc_log_warn("AcquireNextImage out of date or suboptimal!\n");
        return;
    }
    else if (accuireNextImageResult != VK_SUCCESS)
    {
        printf("Failed to acquire next image: %d\n", accuireNextImageResult);
        return;
    }

    // DOCS: Начинаем запись командного буфера
    VkCommandBuffer drawCmd = pScVk->Cmd.aList[s_image_index];
    vkResetCommandBuffer(drawCmd, 0);

    VkCommandBufferBeginInfo bi = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT
    };

    VkResult beginResult = vkBeginCommandBuffer(drawCmd, &bi);
    if (beginResult != VK_SUCCESS)
    {
        sc_log_erro("Failed to begin command buffer: %d\n", beginResult);
        return;
    }

    { // DOCS: Rendering render passes
        sc_list_clear(pScVk->aPassesTextures);
        for (i32 rp = 0; rp < renderPassesCount; ++rp)
        {
            i64 renderPassId = aRenderPassIds[rp];
            ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, renderPassId);
            sc_vk_render_pass_draw_v2(pScVk, pPass, drawCmd);
            Sc2dTexture sc2dTxt = sc_vk_render_pass_get_current_image_as_texture(pPass, pScVk->DefaultLinearSampler);
            sc_list_add(pScVk->aPassesTextures, sc2dTxt);
        }
        sc_vk_set_passes_images(pScVk, pScVk->aPassesTextures, sc_list_count(pScVk->aPassesTextures));
    }

    VkClearValue clearValue = {
        .color = { 0.01f, 0.01f, 0.05f, 1.0f }
    };

    VkRenderPassBeginInfo renderPassBeginInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .renderPass = pFinalPass->Handle,
        .framebuffer = pFinalPass->aFramebuffers[s_image_index].Framebuffer,
        .renderArea = {
            .offset = { 0, 0 },
            .extent = pScVk->Swap.Resolution },
        .clearValueCount = 1,
        .pClearValues = &clearValue
    };

    vkCmdBeginRenderPass(drawCmd, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);

    VkViewport viewport = {
        .x = 0,
        .y = 0,
        .width = (float)pScVk->Swap.Resolution.width,
        .height = (float)pScVk->Swap.Resolution.height,
        .minDepth = 0,
        .maxDepth = 1
    };
    vkCmdSetViewport(drawCmd, 0, 1, &viewport);

    VkRect2D scissor = {
        .offset = { 0, 0 },
        .extent = pScVk->Swap.Resolution
    };
    vkCmdSetScissor(drawCmd, 0, 1, &scissor);

    vkCmdBindPipeline(drawCmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pFinalPipe->Handle);
    vkCmdBindDescriptorSets(drawCmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pFinalPipe->Layout, 0, 1, &pFinalPipe->ShaderBridge.Set, 0, NULL);
    vkCmdDraw(drawCmd, 6, 1, 0, 0);

    vkCmdEndRenderPass(drawCmd);

    VkResult vkEndCmdBufferResult = vkEndCommandBuffer(drawCmd);
    if (vkEndCmdBufferResult != VK_SUCCESS)
    {
        sc_log_erro("Failed to end command buffer: %d\n", vkEndCmdBufferResult);
        return;
    }

    // DOCS: Отправляем команды в очередь
    VkPipelineStageFlags pipelineStageFlag = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkPipelineStageFlags aWaitStages[] = { VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT };

    VkSubmitInfo cmdSubmitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = pAvailableSemaphore,
        .pWaitDstStageMask = &pipelineStageFlag,
        .commandBufferCount = 1,
        .pCommandBuffers = &drawCmd,
        .signalSemaphoreCount = 1,
        .pSignalSemaphores = pFinishedSemaphore
    };

    VkResult queueSubmitResult = vkQueueSubmit(pScVk->GraphicsQueue, 1, &cmdSubmitInfo, *pFrameFence);
    if (queueSubmitResult != VK_SUCCESS)
    {
        sc_log_erro("Failed to submit queue: %d\n", queueSubmitResult);
        return;
    }

    // DOCS: Представляем изображение
    VkPresentInfoKHR presentInfoKhr = {
        .sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = pFinishedSemaphore,
        .swapchainCount = 1,
        .pSwapchains = &pScVk->Swap.Swapchain,
        .pImageIndices = &s_image_index
    };

    VkResult queuePresentKhr = vkQueuePresentKHR(pScVk->PresentationQueue, &presentInfoKhr);
    if (queuePresentKhr == VK_ERROR_OUT_OF_DATE_KHR || queuePresentKhr == VK_SUBOPTIMAL_KHR)
    {
        sc_log_warn("QueuePresent out of date or suboptimal!\n");
        // g.ResizeMemory.IsResizePending = 1;
        return;
    }
    else if (queuePresentKhr != VK_SUCCESS)
    {
        sc_log_erro("Failed to present queue: %d\n", queuePresentKhr);
        return;
    }
}

void
sc_vk_uniform_buffer_allocate(ScVk* pScVk)
{
    pScVk->Uniform.Buffer = sc_vk_uniform_buffer_new(pScVk, pScVk->Uniform.TotalSize);

    sc_log_succ("UniformBuffer.TotalSize: %d\n", pScVk->Uniform.TotalSize);
}

void
sc_vk_uniform_buffer_free(ScVk* pScVk)
{
    pScVk->Uniform.TotalSize = 0;
    sc_vk_shared_buffer_destroy(pScVk, pScVk->Uniform.Buffer);
}

i32
sc_vk_get_next_pipeline_index(ScVk* pScVk)
{
    return sc_list_count(pScVk->aPipelines);
}

ScVkPipeline*
sc_vk_get_pipeline(ScVk* pScVk, i32 pipeId)
{
    i32 pipesCount = sc_list_count(pScVk->aPipelines);
    if (pipeId < 0 || pipeId < pipesCount)
        return &pScVk->aPipelines[pipeId];
    return NULL;
}

i32
sc_vk_set_pipeline(ScVk* pScVk, i32 pipeId, ScVkPipeline pipe)
{
    i32 capacity = sc_list_capacity(pScVk->aPipelines);
    if (pipeId < 0 || pipeId >= capacity)
        return 0;
    pScVk->aPipelines[pipeId] = pipe;
    return 1;
}

i32
sc_vk_get_next_render_pass_index(ScVk* pScVk)
{
    return sc_list_count(pScVk->aRenderPasses);
}

ScVkRenderPass*
sc_vk_get_render_pass(ScVk* pScVk, i32 passId)
{
    i32 passesCount = sc_list_count(pScVk->aRenderPasses);
    if (passId < 0 || passId < passesCount)
        return &pScVk->aRenderPasses[passId];
    return NULL;
}

i32
sc_vk_register_render_pass(ScVk* pScVk, ScVkRenderPass* pPass)
{
    pPass->Id = sc_list_count(pScVk->aRenderPasses);
    sc_list_add(pScVk->aRenderPasses, *pPass);

    return pPass->Id;
}

void
sc_vk_remove_render_pass(ScVk* pScVk, i32 id)
{
    pScVk->aRenderPasses[id].Id *= -1;
}

/*

  ###################################
  ###################################
  sc_vk_sync
  ###################################
  ###################################

*/

VkSemaphore
sc_vk_sync_semaphore_new(ScVk* pScVk, VkSemaphoreCreateFlags createFlags)
{
    VkSemaphore vkSemaphore = {};

    VkSemaphoreCreateInfo semaphoreCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO,
        .pNext = NULL,
        .flags = createFlags
    };

    VkResult vkResult = vkCreateSemaphore(pScVk->Device, &semaphoreCreateInfo, pScVk->pAllocator, &vkSemaphore);
    if (vkResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "semaphore: failed to create!");
    }

    return vkSemaphore;
}

VkFence
sc_vk_fence_new(ScVk* pScVk, VkFenceCreateFlags fenceFlags)
{
    VkFence vkFence = {};

    VkFenceCreateInfo frameFenceCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
        .pNext = NULL,
        // NOTE(typedef): this will become unsignaled at the 2 line (vkResetFences) of the render loop
        .flags = fenceFlags // VK_FENCE_CREATE_SIGNALED_BIT
    };
    VkResult vkResult = vkCreateFence(pScVk->Device, &frameFenceCreateInfo, pScVk->pAllocator, &vkFence);
    if (vkResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "fence: failed to create!");
    }

    return vkFence;
}

/*

  ###################################
  ###################################
  sc_vk_cmd
  ###################################
  ###################################

*/

VkCommandPool
sc_vk_cmd_pool_new(ScVk* pScVk, i32 queueIndex)
{
    VkCommandPool vkCmdPool;
    VkCommandPoolCreateInfo commandPoolCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
        .pNext = NULL,
        .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
        .queueFamilyIndex = queueIndex
    };
    VkResult vkResult = vkCreateCommandPool(pScVk->Device, &commandPoolCreateInfo, pScVk->pAllocator, &vkCmdPool);

    if (vkResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Cmd Pool: Failed to creatte!\n");
    }
    return vkCmdPool;
}

VkCommandBuffer
sc_vk_cmd_buffer_new(ScVk* pScVk, VkCommandPool vkCommandPool)
{
    VkCommandBuffer vkCommandBuffer;

    VkCommandBufferAllocateInfo commandBufferAllocatedInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
        .pNext = NULL,
        .commandPool = vkCommandPool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
        .commandBufferCount = 1
    };
    VkResult vkResult = vkAllocateCommandBuffers(pScVk->Device, &commandBufferAllocatedInfo, &vkCommandBuffer);

    if (vkResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "CmdBuffer: Failed to create!\n");
    }

    return vkCommandBuffer;
}

/*

  ###################################
  ###################################
  sc_vk_swapchain
  ###################################
  ###################################

*/

VkSurfaceFormatKHR
sc_vk_pick_surface_format(ScVk* pScVk, ScVkSwapchainConfig config)
{
    VkSurfaceFormatKHR* aSurfaceFormats = sc_vk_get_device_surface_formats(pScVk);
    VkSurfaceFormatKHR surfaceFormatWeWant = config.SurfaceFormat;
    VkSurfaceFormatKHR surfaceFormat = aSurfaceFormats[0];
    for (i32 p = 0; p < sc_list_count(aSurfaceFormats); ++p)
    {
        VkSurfaceFormatKHR iter = aSurfaceFormats[p];
        if (iter.format == surfaceFormatWeWant.format && iter.colorSpace == surfaceFormatWeWant.colorSpace)
        {
            surfaceFormat = aSurfaceFormats[p];
            break;
        }
    }

    sc_list_free(aSurfaceFormats);
    return surfaceFormat;
}

VkPresentModeKHR
sc_vk_pick_present_mode(ScVk* pScVk, ScVkSwapchainConfig config)
{
    VkPresentModeKHR* aPresentModes = sc_vk_get_device_surface_modes(pScVk);
    pScVk->Flags.IsVsync = config.IsVsync;

    VkPresentModeKHR presentModeWeWant;
    if (config.IsVsync)
    {
        presentModeWeWant = VK_PRESENT_MODE_FIFO_KHR;
    }
    else
    {
        presentModeWeWant = VK_PRESENT_MODE_IMMEDIATE_KHR;
    }

    VkPresentModeKHR presentMode = aPresentModes[0];
    for (i32 p = 0; p < sc_list_count(aPresentModes); ++p)
    {
        if (aPresentModes[p] == presentModeWeWant)
        {
            presentMode = aPresentModes[p];
            break;
        }
    }
    sc_list_free(aPresentModes);

    return presentMode;
}

ScVkSwapObject
sc_vk_swapchain_new(ScVk* pScVk, ScVkSwapchainConfig config)
{
    VkSurfaceFormatKHR surfaceFormat = sc_vk_pick_surface_format(pScVk, config);
    VkPresentModeKHR presentMode = sc_vk_pick_present_mode(pScVk, config);

    VkSurfaceCapabilitiesKHR caps = sc_vk_get_surface_capabilities(pScVk);

    i32 maxImageCount = caps.maxImageCount;
    if (caps.maxImageCount == 0)
        maxImageCount = 3 * caps.minImageCount + 2;

    i32 swapImageCount = ScMinMax(caps.minImageCount + 1, caps.minImageCount, maxImageCount);
    printf("swap image count: %d\n", swapImageCount);
    VkExtent2D min = caps.minImageExtent;
    VkExtent2D max = caps.maxImageExtent;

    if (pScVk->Flags.IsDebug)
    {
        // check if bug still exists and we need this
        // sc_vk_get_surface_capabilities(pScVk);
    }

    VkSwapchainCreateInfoKHR swapChainCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
        .pNext = NULL, // todo: &scalingExt,
        .flags = 0,
        .surface = pScVk->Surface,
        .minImageCount = swapImageCount,
        .imageFormat = surfaceFormat.format,
        .imageColorSpace = surfaceFormat.colorSpace,
        .imageExtent = config.Resolution,
        .imageArrayLayers = 1,
        /*DOCS:
          Use VK_IMAGE_USAGE_TRANSFER_DST_BIT if post-processing is involved
          render image to post-processing color_attach and then copy with
          memory operation back to swap_chain_image
        */
        .imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
        .preTransform = caps.currentTransform,
        /*DOCS:
          If the alpha channel should be used for blending with other windows in the window system set other value, else VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR
        */
        .compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR,
        .presentMode = presentMode,
        .clipped = VK_TRUE,
        // DOCS: For resizing
        .oldSwapchain = config.PrevSwapchain,
    };

    u32 queueIndices[] = {
        pScVk->GraphicsQueueIndex,
        pScVk->PresentationQueueIndex,
    };
    if (queueIndices[0] != queueIndices[1])
    {
        swapChainCreateInfo.imageSharingMode = VK_SHARING_MODE_CONCURRENT;
        swapChainCreateInfo.queueFamilyIndexCount = 2;
        swapChainCreateInfo.pQueueFamilyIndices = queueIndices;
    }
    else
    {
        swapChainCreateInfo.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    }

    VkSwapchainKHR swapchain;
    VkResult swapChainCreateResult = vkCreateSwapchainKHR(pScVk->Device, &swapChainCreateInfo, pScVk->pAllocator, &swapchain);
    if (swapChainCreateResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkCreateSwapchainKHR: Swap creation failed!\n");
    }

    ScVkSwapObject swap = {
        .Swapchain = swapchain,
        .Resolution = config.Resolution,
        .SurfaceFormat = surfaceFormat,
    };

    return swap;
}

void
sc_vk_swapchain_destroy(ScVk* pScVk, ScVkSwapObject object)
{
    if (object.Swapchain != VK_NULL_HANDLE)
    {
        vkDestroySwapchainKHR(pScVk->Device, object.Swapchain, pScVk->pAllocator);
    }
}

/*

  ###################################
  ###################################
  sc_vk_image
  ###################################
  ###################################

*/

VkImageView
sc_vk_image_view_new(ScVk* pScVk, VkImageViewCreateInfo vkImageViewCreateInfo)
{
    VkImageView vkImageView;

    VkResult vkResult = vkCreateImageView(pScVk->Device, &vkImageViewCreateInfo, pScVk->pAllocator, &vkImageView);
    if (vkResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "VkImageView: Can't create!\n");
    }

    return vkImageView;
}

ScVkImage
sc_vk_image_new(ScVk* pScVk, VkImageCreateInfo vkImageCreateInfo, VkMemoryPropertyFlags memoryProperyFlag)
{
    ScVkImage scImage = {};

    VkImage vkImage;
    VkResult vkCreateImageResult = vkCreateImage(
        pScVk->Device, &vkImageCreateInfo, pScVk->pAllocator, &vkImage);
    if (vkCreateImageResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkCreateImage: Failed!\n");
    }

    VkMemoryRequirements memRequirements;
    vkGetImageMemoryRequirements(pScVk->Device, vkImage, &memRequirements);

    i32 index = sc_vk_get_memory_type(pScVk, memRequirements, memoryProperyFlag);

    VkMemoryAllocateInfo allocateInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .pNext = NULL,
        .allocationSize = memRequirements.size,
        .memoryTypeIndex = index
    };

    VkDeviceMemory deviceMemory = {};
    VkResult vkAllocateMemoryResult = vkAllocateMemory(pScVk->Device, &allocateInfo, pScVk->pAllocator, &deviceMemory);
    if (vkAllocateMemoryResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkAllocateMemory: Failed for image memory creation!\n");
    }

    VkResult vkBindImageMemoryResult = vkBindImageMemory(pScVk->Device, vkImage, deviceMemory, 0);
    if (vkBindImageMemoryResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkBindImageMemory: Failed!\n");
    }

    scImage.Image = vkImage;
    scImage.Memory = deviceMemory;

    return scImage;
}

void
sc_vk_image_destroy(ScVk* pScVk, VkImage image)
{
    vkDestroyImage(pScVk->Device, image, pScVk->pAllocator);
}

void
sc_vk_image_change_layout(ScVk* pScVk, VkImage vkImage, VkImageLayout vkOldLayout, VkImageLayout vkNewLayout, VkFormat vkFormat, i32 mipLevels)
{
    VkCommandBuffer cmd = sc_vk_cmd_begin(pScVk);

    VkImageMemoryBarrier vkImageMemoryBarrier = {
        .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
        .pNext = NULL,
        .srcAccessMask = 0, // TODO(typedef): empty for now
        .dstAccessMask = 0, // TODO(typedef): empty for now
        .oldLayout = vkOldLayout,
        .newLayout = vkNewLayout,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .image = vkImage,
        .subresourceRange = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .baseMipLevel = 0,
            .levelCount = mipLevels,
            .baseArrayLayer = 0,
            .layerCount = 1,
        }
    };

    VkPipelineStageFlags vkSrcPipelineStageFlags;
    VkPipelineStageFlags vkDstPipelineStageFlags;
    if (vkOldLayout == VK_IMAGE_LAYOUT_UNDEFINED && vkNewLayout == VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL)
    {
        vkImageMemoryBarrier.srcAccessMask = 0;
        vkImageMemoryBarrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        vkSrcPipelineStageFlags = VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT;
        vkDstPipelineStageFlags = VK_PIPELINE_STAGE_TRANSFER_BIT;
    }
    else if (vkOldLayout == VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL && vkNewLayout == VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL)
    {
        vkImageMemoryBarrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        vkImageMemoryBarrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        vkSrcPipelineStageFlags = VK_PIPELINE_STAGE_TRANSFER_BIT;
        vkDstPipelineStageFlags = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
    }
    else
    {
        sc_assert(0 && "Wrong new||old layout picked !!!");
    }

    vkCmdPipelineBarrier(cmd,
        vkSrcPipelineStageFlags,
        vkDstPipelineStageFlags,
        VK_DEPENDENCY_BY_REGION_BIT,
        0,
        NULL,
        0,
        NULL,
        1,
        &vkImageMemoryBarrier);

    sc_vk_cmd_end(pScVk, cmd);
}

void
sc_vk_image_change_layout_ext(ScVk* pScVk, VkImage vkImage, VkImageLayout vkOldLayout, VkImageLayout vkNewLayout, VkPipelineStageFlags srcPipe, VkPipelineStageFlags dstPipe, i32 mipLevels)
{
    VkCommandBuffer cmd = sc_vk_cmd_begin(pScVk);

    VkImageMemoryBarrier vkImageMemoryBarrier = {
        .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
        .pNext = NULL,
        .srcAccessMask = 0, // TODO(typedef): empty for now
        .dstAccessMask = 0, // TODO(typedef): empty for now
        .oldLayout = vkOldLayout,
        .newLayout = vkNewLayout,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .image = vkImage,
        .subresourceRange = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .baseMipLevel = 0,
            .levelCount = mipLevels,
            .baseArrayLayer = 0,
            .layerCount = 1,
        }
    };

    vkCmdPipelineBarrier(cmd,
        srcPipe,
        dstPipe,
        VK_DEPENDENCY_BY_REGION_BIT,
        0,
        NULL,
        0,
        NULL,
        1,
        &vkImageMemoryBarrier);

    sc_vk_cmd_end(pScVk, cmd);
}

void
sc_vk_image_from_buffer(ScVk* pScVk, VkImage vkImage, VkBuffer vkBuffer, i32 width, i32 height)
{
    VkCommandBuffer cmd = sc_vk_cmd_begin(pScVk);

    VkBufferImageCopy vkBufferImageCopy = {
        .bufferOffset = 0,
        .bufferRowLength = 0,
        .bufferImageHeight = 0,
        .imageSubresource = {
            .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
            .mipLevel = 0,
            .baseArrayLayer = 0,
            .layerCount = 1 },
        .imageOffset = { .x = 0, .y = 0, .z = 0 },
        .imageExtent = { .width = width, .height = height, .depth = 1 }
    };

    vkCmdCopyBufferToImage(cmd, vkBuffer, vkImage, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &vkBufferImageCopy);
    sc_vk_cmd_end(pScVk, cmd);
}

/*

  ###################################
  ###################################
  sc_vk_texture
  ###################################
  ###################################

*/

ScTexture
sc_vk_texture_new(ScVk* pScVk, VkImageCreateInfo imageCreateInfo, VkImageViewCreateInfo imageViewCreateInfo, VkMemoryPropertyFlags memoryProperyFlag)
{
    ScTexture scTexture = {};

    ScVkImage scImage = sc_vk_image_new(pScVk, imageCreateInfo, memoryProperyFlag);
    imageViewCreateInfo.image = scImage.Image;
    VkImageView imageView = sc_vk_image_view_new(pScVk, imageViewCreateInfo);

    scTexture.Image = scImage.Image;
    scTexture.Memory = scImage.Memory;
    scTexture.View = imageView;

    return scTexture;
}

void
sc_vk_texture_destroy(ScVk* pScVk, ScTexture texture)
{
    vkDestroyImage(pScVk->Device, texture.Image, pScVk->pAllocator);
    vkDestroyImageView(pScVk->Device, texture.View, pScVk->pAllocator);
    vkFreeMemory(pScVk->Device, texture.Memory, pScVk->pAllocator);
}

Sc2dTexture
sc_vk_2d_texture_new(ScVk* pScVk, void* pData, i32 width, i32 height, VkFormat vkFormat)
{
    if (vkFormat == VK_FORMAT_UNDEFINED)
    {
        vkFormat = VK_FORMAT_R8G8B8A8_SRGB;
    }
    const i32 channels = 4;
    const i32 isMipMapped = 0;

    i32 mipLevels = 1;
    if (isMipMapped)
    { // note: find mipLevels
        f32 logValue = log2f(ScMin(width, height));
        mipLevels = ScMin(((i32)(logValue)) + 1, 10);
    }

    VkImageCreateInfo vkImageCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .imageType = VK_IMAGE_TYPE_2D,
        .format = vkFormat,
        .extent = {
            .width = width,
            .height = height,
            .depth = 1 },
        .mipLevels = mipLevels,
        .arrayLayers = 1,
        .samples = VK_SAMPLE_COUNT_1_BIT,
        .tiling = VK_IMAGE_TILING_OPTIMAL,
        // todo: should we use samples the
        .usage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
        .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
        .queueFamilyIndexCount = 0, // NOTE(): should we set this value
        .pQueueFamilyIndices = NULL,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED
    };

    ScVkImage scImage = sc_vk_image_new(pScVk, vkImageCreateInfo, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    { // DOCS: Push data into gpu memory + buffer creation

        /*
          NOTE(typedef): Make this thing faster with *_lite() function wo cmd buffers
        */
        size_t imageSize = width * height * channels;

        // use shared buffer for this stuff
        VkBufferUsageFlags usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT;
        VkMemoryPropertyFlags memProperty = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
        ScVkBuffer stagingBuffer = sc_vk_buffer_new(pScVk, imageSize, usage, memProperty);

        // DOCS: Set memory
        void* pBufferData;
        vkMapMemory(pScVk->Device, stagingBuffer.Memory, 0, imageSize, 0, &pBufferData);
        memcpy(pBufferData, pData, imageSize);
        vkUnmapMemory(pScVk->Device, stagingBuffer.Memory);

        sc_vk_image_change_layout(pScVk, scImage.Image, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, vkFormat, mipLevels);
        sc_vk_image_from_buffer(pScVk, scImage.Image, stagingBuffer.Buffer, width, height);

        if (!isMipMapped)
        {
            // DOCS(typedef): imageBlit cmd will transfer image to SHADER format
            //  NOTE(typedef): This is for using image in shader
            sc_vk_image_change_layout(pScVk, scImage.Image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, vkFormat, 1);
        }
        else
        {
            // sc_vk_image_create_mipmaps(pInstance, vkImage, set.Width, set.Height, mipLevels);
        }

        sc_vk_buffer_destroy(pScVk, stagingBuffer);
    }

    VkImageViewCreateInfo imageViewCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .image = scImage.Image,
        .viewType = VK_IMAGE_VIEW_TYPE_2D,
        .format = vkFormat,
        .components = {
            .r = VK_COMPONENT_SWIZZLE_IDENTITY,
            .g = VK_COMPONENT_SWIZZLE_IDENTITY,
            .b = VK_COMPONENT_SWIZZLE_IDENTITY,
            .a = VK_COMPONENT_SWIZZLE_IDENTITY },
        .subresourceRange = { .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT, .baseMipLevel = 0, .levelCount = mipLevels, .baseArrayLayer = 0, .layerCount = 1 }
    };
    VkImageView imageView = sc_vk_image_view_new(pScVk, imageViewCreateInfo);

    Sc2dTexture sc2dTexture = {
        .Image = scImage,
        .View = imageView,
        .Sampler = sc_vk_sampler_create(pScVk, VK_FILTER_NEAREST, VK_FILTER_NEAREST, 0)
    };

    return sc2dTexture;
}

void
sc_vk_2d_texture_destroy(ScVk* pScVk, Sc2dTexture sc2dTexture)
{
    vkDestroySampler(pScVk->Device, sc2dTexture.Sampler, pScVk->pAllocator);
    vkDestroyImage(pScVk->Device, sc2dTexture.Image.Image, pScVk->pAllocator);
    vkFreeMemory(pScVk->Device, sc2dTexture.Image.Memory, pScVk->pAllocator);
    vkDestroyImageView(pScVk->Device, sc2dTexture.View, pScVk->pAllocator);
}

VkSampler
sc_vk_sampler_create(ScVk* pScVk, VkFilter minFilter, VkFilter maxFilter, i32 mipLevels)
{
    VkSampler vkSampler;

    VkPhysicalDeviceProperties properties;
    vkGetPhysicalDeviceProperties(pScVk->PhysicalDevice, &properties);
    f32 maxAnisotropy = properties.limits.maxSamplerAnisotropy;

    // VK_SAMPLER_ADDRESS_MODE_REPEAT; VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_BORDER;
    VkSamplerAddressMode addressMode = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    VkBool32 isAnisotropyFilterEnabled = VK_FALSE;
    VkBool32 compareEnabled = VK_FALSE;           // NOTE(typedef): used for PCF in shadow map technique
    VkCompareOp compareOp = VK_COMPARE_OP_ALWAYS; // NOTE(typedef): used for PCF in shadow map technique

    VkSamplerCreateInfo vkSamplerCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .magFilter = maxFilter,
        .minFilter = minFilter,
        .mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR,
        .addressModeU = addressMode,
        .addressModeV = addressMode,
        .addressModeW = addressMode,
        .mipLodBias = 0.0f,
        .anisotropyEnable = isAnisotropyFilterEnabled,
        .maxAnisotropy = maxAnisotropy,
        .compareEnable = compareEnabled,
        .compareOp = compareOp,
        .minLod = 0.0f, // NOTE(typedef): Multisample trick (f32) (mipLevels)/8,
        .maxLod = (f32)mipLevels,
        .borderColor = VK_BORDER_COLOR_INT_OPAQUE_BLACK,
        .unnormalizedCoordinates = VK_FALSE
    };

    VkResult vkCreateSamplerResult = vkCreateSampler(pScVk->Device, &vkSamplerCreateInfo, pScVk->pAllocator, &vkSampler);
    if (vkCreateSamplerResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Can;t create sampler!\n");
    }

    return vkSampler;
}

void
sc_vk_sampler_destroy(ScVk* pScVk, VkSampler sampler)
{
    vkDestroySampler(pScVk->Device, sampler, pScVk->pAllocator);
}

/*

  ###################################
  ###################################
  sc_vk_get
  ###################################
  ###################################

*/

VkPhysicalDevice*
sc_vk_get_devices(ScVk* pScVk)
{
    VkPhysicalDevice* aDevices = NULL;

    u32 physicalDevicesCount;
    VkResult enumerateResult = vkEnumeratePhysicalDevices(pScVk->Handle, &physicalDevicesCount, NULL);

    if (enumerateResult != VK_SUCCESS || physicalDevicesCount <= 0)
    {
        sc_vk_fatal(pScVk, "Physical device enumeration error\n");
    }
    else if (enumerateResult == VK_ERROR_INITIALIZATION_FAILED)
    {
        sc_vk_fatal(pScVk, "Can't enemerate physical devices, maybe installable client driver (ICD) is not installed on your machine!\n");
    }

    aDevices = sc_list_reserve(aDevices, physicalDevicesCount);
    sc_list_header(aDevices)->Count = physicalDevicesCount;

    enumerateResult = vkEnumeratePhysicalDevices(pScVk->Handle, &physicalDevicesCount, aDevices);
    if (enumerateResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "Can't enemerate physical devices, maybe installable client driver (ICD) is not installed on your machine! [Second call]\n");
    }

    return aDevices;
}

VkExtensionProperties*
sc_vk_get_device_extensions(ScVk* pScVk, VkPhysicalDevice device)
{
    VkExtensionProperties* aExts = NULL;

    u32 physicalDeviceExtCount;
    VkResult result = vkEnumerateDeviceExtensionProperties(device, NULL, &physicalDeviceExtCount, NULL);

    if (result != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkEnumerateDeviceExtensionProperties call error!\n");
    }

    sc_list_reserve(aExts, physicalDeviceExtCount);
    sc_list_header(aExts)->Count = physicalDeviceExtCount;

    result = vkEnumerateDeviceExtensionProperties(device, NULL, &physicalDeviceExtCount, aExts);
    if (result != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkEnumerateDeviceExtensionProperties call error! [second time]\n");
    }

    return aExts;
}

const char*
sc_vk_device_type_to_string(VkPhysicalDeviceType type)
{
    switch (type)
    {
    case VK_PHYSICAL_DEVICE_TYPE_OTHER:
        return "Other";
    case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU:
        return "Integrated GPU";
    case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU:
        return "GPU";
    case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU:
        return "Virtual GPU";
    case VK_PHYSICAL_DEVICE_TYPE_CPU:
        return "CPU";
    default:
        return "";
    }
}

VkQueueFamilyProperties*
sc_vk_get_queues_family_properties(ScVk* pScVk)
{
    VkQueueFamilyProperties* aFamilyProperties = NULL;
    u32 familyPropertyCount;
    vkGetPhysicalDeviceQueueFamilyProperties(pScVk->PhysicalDevice, &familyPropertyCount, NULL);
    sc_list_reserve(aFamilyProperties, familyPropertyCount);
    sc_list_header(aFamilyProperties)->Count = familyPropertyCount;
    vkGetPhysicalDeviceQueueFamilyProperties(pScVk->PhysicalDevice, &familyPropertyCount, aFamilyProperties);
    return aFamilyProperties;
}

VkSurfaceFormatKHR*
sc_vk_get_device_surface_formats(ScVk* pScVk)
{
    VkSurfaceFormatKHR* aFormats = NULL;

    u32 formatsCount;
    VkResult getSurfaceFormatResult = vkGetPhysicalDeviceSurfaceFormatsKHR(pScVk->PhysicalDevice, pScVk->Surface, &formatsCount, NULL);
    if (getSurfaceFormatResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkGetPhysicalDeviceSurfaceFormatsKHR call error\n");
    }

    sc_list_reserve(aFormats, formatsCount);
    sc_list_header(aFormats)->Count = formatsCount;

    getSurfaceFormatResult = vkGetPhysicalDeviceSurfaceFormatsKHR(pScVk->PhysicalDevice, pScVk->Surface, &formatsCount, aFormats);

    if (getSurfaceFormatResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkGetPhysicalDeviceSurfaceFormatsKHR call error [second call]\n");
    }

    return aFormats;
}

VkPresentModeKHR*
sc_vk_get_device_surface_modes(ScVk* pScVk)
{
    VkPresentModeKHR* aPresentModes = NULL;

    u32 presentModesCount;
    VkResult getSurfaceModeResult = vkGetPhysicalDeviceSurfacePresentModesKHR(
        pScVk->PhysicalDevice,
        pScVk->Surface,
        &presentModesCount,
        NULL);
    if (getSurfaceModeResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkGetPhysicalDeviceSurfacePresentModesKHR call failed!\n");
    }

    sc_list_reserve(aPresentModes, presentModesCount);
    sc_list_header(aPresentModes)->Count = presentModesCount;

    getSurfaceModeResult = vkGetPhysicalDeviceSurfacePresentModesKHR(pScVk->PhysicalDevice, pScVk->Surface, &presentModesCount, aPresentModes);
    if (getSurfaceModeResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkGetPhysicalDeviceSurfacePresentModesKHR call failed!\n");
    }

    return aPresentModes;
}

VkSurfaceCapabilitiesKHR
sc_vk_get_surface_capabilities(ScVk* pScVk)
{
    VkSurfaceCapabilitiesKHR caps;
    VkResult vkResult = vkGetPhysicalDeviceSurfaceCapabilitiesKHR(pScVk->PhysicalDevice, pScVk->Surface, &caps);
    if (vkResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkGetPhysicalDeviceSurfaceCapabilitiesKHR: failed!\n");
    }
    return caps;
}

VkImage*
sc_vk_get_swap_images(ScVk* pScVk, VkSwapchainKHR swapchain)
{
    VkImage* aImages = NULL;

    u32 imagesCount;
    VkResult result = vkGetSwapchainImagesKHR(pScVk->Device, swapchain, &imagesCount, NULL);

    if (result != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkGetSwapchainImagesKHR: Failed to get!\n");
    }

    sc_list_reserve(aImages, imagesCount);
    sc_list_header(aImages)->Count = imagesCount;

    result = vkGetSwapchainImagesKHR(pScVk->Device, swapchain, &imagesCount, aImages);
    if (result != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "vkGetSwapchainImagesKHR: Failed to get [x2]!\n");
    }

    return aImages;
}

i32
sc_vk_get_memory_type(ScVk* pScVk, VkMemoryRequirements memoryRequirements, VkMemoryPropertyFlags vkMemoryPropertyFlags)
{
    VkPhysicalDeviceMemoryProperties dMemoryProperties;
    vkGetPhysicalDeviceMemoryProperties(pScVk->PhysicalDevice, &dMemoryProperties);
    u32 typeBit = memoryRequirements.memoryTypeBits;

    for (i32 i = 0; i < dMemoryProperties.memoryTypeCount; ++i)
    {
        VkMemoryType memoryType = dMemoryProperties.memoryTypes[i];
        if ((typeBit & (1 << i)) && (memoryType.propertyFlags & vkMemoryPropertyFlags))
        {
            return i;
        }
    }

    return 0;
}

/*

  ###################################
  ###################################
  sc_vk_shader
  ###################################
  ###################################

*/

VkShaderModule
sc_vk_shader_new(ScVkShaderCompileConfig config)
{
    if (sc_path(config.pSourcePath) != ScPathItemType_File)
    {
        char buf[512] = {};
        snprintf(buf, 512, "sc_vk_shader_compile_ext: Failed to compile %s", config.pSourcePath);
        sc_vk_error(config.pScVk, buf);
    }

    struct
    {
        char* pDirectory;
        char* pBinPath;
    } allocated = {};

    if (!config.pBinPath)
    {
        allocated.pDirectory = sc_path_get_directory(config.pSourcePath);
        allocated.pBinPath = sc_path_combine(allocated.pDirectory, "Bin");
        config.pBinPath = allocated.pBinPath;
        sc_directory_create(config.pBinPath);
    }
    else if (sc_path(config.pBinPath) != ScPathItemType_Directory)
    {
        sc_directory_create(config.pBinPath);
        char buf[512] = {};
        snprintf(buf, 512, "sc_vk_shader_compile_ext: Directory not found %s", config.pBinPath);
        sc_vk_warning(config.pScVk, buf);
    }

    char* pName = sc_path_get_name_wo_alloc(config.pSourcePath);

    i32 binPathLen = sc_string_get_length(config.pBinPath);
    if (config.pBinPath[binPathLen - 1] == '/')
        config.pBinPath[binPathLen - 1] = '\0';
    char* pDestDir = config.pBinPath;

#define buf_size 1024
    char pSpvPath[buf_size] = {};
    // DOCS: /dest/dit/source.ext.spv
    snprintf(pSpvPath, buf_size, "%s/%s%s", pDestDir, pName, ".spv");
#undef buf_size

    i32 isRecompilationNeeded = 0;
    if (sc_path(pSpvPath) != ScPathItemType_File)
    {
        isRecompilationNeeded = 1;
    }
    else
    {
        ScFileTime fileTime = sc_file_get_time(pSpvPath);
        if (fileTime.LastModificationTime > fileTime.LastCreateTime)
            isRecompilationNeeded = 1;
    }

    if (!isRecompilationNeeded)
    {
        goto ScVkShaderCompileEndLabel;
    }

    // glslc Vsr3dd.frag -O -o Vsr3ddFrag.spv --target-env=vulkan1.3 -w -x glsl
    // glslc Vsr3dd.vert -O -o Vsr3ddVert.spv --target-env=vulkan1.3 -w -x glsl

    const char* optimization = "";
    if (config.IsOmpimize)
        optimization = "-O";

    char cmd[1024] = {};
    sprintf(cmd, "glslc %s %s -o %s --target-env=vulkan1.3 -w -x glsl", config.pSourcePath, optimization, pSpvPath);
    system(cmd);
    printf("pSpvPath: %s\n", pSpvPath);
    printf("cmd: %s\n", cmd);

    i64 byteCodeSize;
    void* pByteCode;
ScVkShaderCompileEndLabel:
    pByteCode = (void*)sc_file_read_ext(pSpvPath, &byteCodeSize);

    VkShaderModuleCreateInfo shaderCi = {
        .sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .codeSize = byteCodeSize,
        .pCode = pByteCode
    };

    VkShaderModule shaderModule;
    VkResult vkResult = vkCreateShaderModule(config.pScVk->Device, &shaderCi, config.pScVk->pAllocator, &shaderModule);
    if (vkResult != VK_SUCCESS)
    {
#define buf_size 512
        char buf[buf_size] = {};
        snprintf(buf, buf_size, "ShaderCompilation: %s", config.pSourcePath);
        sc_vk_error(config.pScVk, buf);
#undef buf_size
    }

    sc_memory_free(pByteCode);
    // todo: check if allocated with sc_memory_allocate before free
    // sc_memory_free(pDestDir);

    if (allocated.pDirectory)
    {
        sc_memory_free(allocated.pDirectory);
        sc_memory_free(allocated.pBinPath);
    }

    return shaderModule;
}

void
sc_vk_shader_destroy(ScVk* pScVk, VkShaderModule shaderModule)
{
    vkDestroyShaderModule(pScVk->Device, shaderModule, pScVk->pAllocator);
}

/*

  ###################################
  ###################################
  sc_vk_buffer
  ###################################
  ###################################

*/

ScVkBuffer
sc_vk_buffer_new(ScVk* pScVk, u64 size, VkBufferUsageFlags usage, VkMemoryPropertyFlags memoryPropertyFlags)
{
    VkBuffer vkBuffer;
    VkDeviceMemory vkMemory;

    VkBufferCreateInfo vkCreateBufferCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .size = size,
        .usage = usage,
        .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
        .queueFamilyIndexCount = 0,
        .pQueueFamilyIndices = NULL
    };

    VkResult createBufferResult = vkCreateBuffer(pScVk->Device, &vkCreateBufferCreateInfo, pScVk->pAllocator, &vkBuffer);
    if (createBufferResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "sc_vk_buffer_new: vkCreateBuffer failed!\n");
    }

    // NOTE(typedef): Allocating memory for VkBuffer
    VkMemoryRequirements memReqs;
    vkGetBufferMemoryRequirements(pScVk->Device, vkBuffer, &memReqs);

    // NOTE(typedef): Find suitable memory type
    i32 index = sc_vk_get_memory_type(pScVk, memReqs, memoryPropertyFlags);

    VkMemoryAllocateInfo memoryAllocateInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .pNext = NULL,
        .allocationSize = memReqs.size,
        .memoryTypeIndex = index
    };

    VkResult allocateMemoryResult = vkAllocateMemory(pScVk->Device, &memoryAllocateInfo, pScVk->pAllocator, &vkMemory);
    if (allocateMemoryResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkAllocateMemory: failed!\n");
    }

    VkResult bindBufferMemoryResult = vkBindBufferMemory(pScVk->Device, vkBuffer, vkMemory, 0);
    if (bindBufferMemoryResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "vkBindBufferMemory: failed\n");
    }

    ScVkBuffer scVkBuffer = {
        .Buffer = vkBuffer,
        .Memory = vkMemory
    };

    return scVkBuffer;
}

ScVkSharedBuffer
sc_vk_vertex_buffer_new(ScVk* pScVk, u64 size)
{
    ScVkSharedBuffer vkSharedBuffer = {};

    vkSharedBuffer.CpuBuffer = sc_vk_buffer_new(pScVk, size, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT));

    vkSharedBuffer.GpuBuffer = sc_vk_buffer_new(pScVk, size, VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    return vkSharedBuffer;
}

ScVkSharedBuffer
sc_vk_index_buffer_new(ScVk* pScVk, u64 size)
{
    ScVkSharedBuffer vkSharedBuffer = {};

    vkSharedBuffer.CpuBuffer = sc_vk_buffer_new(pScVk, size, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT));

    vkSharedBuffer.GpuBuffer = sc_vk_buffer_new(pScVk, size, VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_INDEX_BUFFER_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    return vkSharedBuffer;
}

ScVkSharedBuffer
sc_vk_uniform_buffer_new(ScVk* pScVk, u64 size)
{
    ScVkSharedBuffer vkSharedBuffer = {};

    vkSharedBuffer.CpuBuffer = sc_vk_buffer_new(pScVk, size, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT));

    vkSharedBuffer.GpuBuffer = sc_vk_buffer_new(pScVk, size, VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    return vkSharedBuffer;
}

void
sc_vk_buffer_destroy(ScVk* pScVk, ScVkBuffer buffer)
{
    vkDestroyBuffer(pScVk->Device, buffer.Buffer, pScVk->pAllocator);
    vkFreeMemory(pScVk->Device, buffer.Memory, pScVk->pAllocator);
}

void
sc_vk_shared_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer buffer)
{
    sc_vk_buffer_destroy(pScVk, buffer.CpuBuffer);
    sc_vk_buffer_destroy(pScVk, buffer.GpuBuffer);
}

void
sc_vk_vertex_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer buffer)
{
    sc_vk_shared_buffer_destroy(pScVk, buffer);
}

void
sc_vk_index_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer index)
{
    sc_vk_shared_buffer_destroy(pScVk, index);
}

void
sc_vk_uniform_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer uniform)
{
    sc_vk_shared_buffer_destroy(pScVk, uniform);
}

// todo: check if it works as expected
void
sc_vk_shared_buffer_set_data(ScVk* pScVk, ScVkSharedBuffer* pScVkSharedBuffer, void* pData, u64 offset, u64 dataSize)
{
    sc_guard_not_null(pData);
    sc_guard(dataSize > 0);

    void* data;
    VkResult vkMapResult = vkMapMemory(pScVk->Device, pScVkSharedBuffer->CpuBuffer.Memory, offset, dataSize, 0, &data);
    if (vkMapResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "sc_vk_shared_buffer_set_data: Failed mapping memory!\n");
    }

    memcpy(data, pData, dataSize);
    vkUnmapMemory(pScVk->Device, pScVkSharedBuffer->CpuBuffer.Memory);

    VkCommandBuffer cmdBuffer = sc_vk_cmd_begin(pScVk);

    VkBufferCopy copyRegion = {
        .srcOffset = offset,
        .dstOffset = offset,
        .size = dataSize,
    };

    vkCmdCopyBuffer(cmdBuffer, pScVkSharedBuffer->CpuBuffer.Buffer, pScVkSharedBuffer->GpuBuffer.Buffer, 1, &copyRegion);

    sc_vk_cmd_end(pScVk, cmdBuffer);
}

/*

  ###################################
  ###################################
  sc_vk_uniform
  ###################################
  ###################################

*/

ScVkUniform
sc_vk_uniform_new(ScVk* pScVk, ScVkUniformConfig cfg)
{
    // todo: rework
    if (cfg.Size == 0 || cfg.ItemSize == 0)
    {
        sc_log_warn("Size or ItemSize for uniform %s was not provided!\n", cfg.pName);
        sc_assert_break();
    }

    ScVkUniform scVkUniform = {
        .pName = cfg.pName,
        .Size = cfg.Size,
        .ItemSize = cfg.ItemSize,
        .BindingIndex = cfg.BindingIndex,
        .PipelineIndex = cfg.PipelineIndex,
        .Offset = pScVk->Uniform.TotalSize,
    };

    pScVk->Uniform.TotalSize += cfg.Size;

    return scVkUniform;
}

void
sc_vk_uniform_destroy(ScVk* pScVk, ScVkUniform uniform)
{
}

ScVkPipeline*
sc_vk_pipeline_get(ScVk* pScVk, i32 pipeIndex)
{
    i32 cnt = sc_list_count(pScVk->aPipelines);
    if (pipeIndex < 0 || pipeIndex >= cnt)
        return NULL;
    ScVkPipeline* aPipes = (ScVkPipeline*)pScVk->aPipelines;
    return &aPipes[pipeIndex];
}

i32
sc_vk_uniform_set(ScVk* pScVk, ScVkUniform* pUniform, void* pData, u64 offset, u64 size)
{
    u64 totalOffset = pUniform->Offset + offset;
    if ((offset + size) > pScVk->Uniform.TotalSize)
    {
        sc_log_warn("You run of memory for uniform %s\n", pUniform->pName);
        return 0;
    }

    sc_vk_shared_buffer_set_data(pScVk, &pScVk->Uniform.Buffer, pData, totalOffset, size);

    VkDescriptorBufferInfo bufferInfo = {
        .buffer = pScVk->Uniform.Buffer.GpuBuffer.Buffer,
        .offset = totalOffset,
        .range = size
    };

    ScVkPipeline* pPipe = sc_vk_pipeline_get(pScVk, pUniform->PipelineIndex);

    // NOTE(FEATURE0): VK_DESCRIPTOR_BINDING_UPDATE_AFTER_BIND_BIT VkDescriptorSetLayoutBindingFlagsCreateInfo
    VkWriteDescriptorSet vkWriteDescriptorSet = {
        .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
        .pNext = NULL,
        .dstSet = pPipe->ShaderBridge.Set,
        .dstBinding = pUniform->BindingIndex,
        .dstArrayElement = 0,
        .descriptorCount = 1,
        .descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
        .pImageInfo = NULL,
        .pBufferInfo = &bufferInfo,
        .pTexelBufferView = NULL
    };

    // NOTE/TODO(): Can update everything in one call
    VkWriteDescriptorSet vkWriteDescriptorSets[] = {
        [0] = vkWriteDescriptorSet
    };

    vkUpdateDescriptorSets(pScVk->Device, 1, vkWriteDescriptorSets, 0, NULL);

    return 1;
}

/*

  ###################################
  ###################################
  sc_vk_cmd
  ###################################
  ###################################

*/

VkCommandBuffer
sc_vk_cmd_begin(ScVk* pScVk)
{
    VkCommandBufferAllocateInfo vkCmdBufferAllocatedInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
        .pNext = NULL,
        .commandPool = pScVk->Cmd.GraphicsPool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
        .commandBufferCount = 1
    };

    VkCommandBuffer vkCmdBuffer;
    VkResult vkAllocateCmdBuffersResult = vkAllocateCommandBuffers(pScVk->Device, &vkCmdBufferAllocatedInfo, &vkCmdBuffer);
    if (vkAllocateCmdBuffersResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "sc_vk_cmd_begin: Failed cmd buffer allocation!\n");
    }

    VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .pNext = NULL,
        .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT,
        .pInheritanceInfo = NULL
    };
    vkBeginCommandBuffer(vkCmdBuffer, &beginInfo);

    return vkCmdBuffer;
}

void
sc_vk_cmd_end(ScVk* pScVk, VkCommandBuffer vkCmdBuffer)
{
    VkResult vkEndCmdBufferResult = vkEndCommandBuffer(vkCmdBuffer);
    if (vkEndCmdBufferResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "sc_vk_cmd_end: Failed end cmd buffer!");
    }

    // Execute command
    VkSubmitInfo submitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .pNext = NULL,
        .waitSemaphoreCount = 0,
        .pWaitSemaphores = NULL,
        .pWaitDstStageMask = NULL,
        .commandBufferCount = 1,
        .pCommandBuffers = &vkCmdBuffer,
        .signalSemaphoreCount = 0,
        .pSignalSemaphores = NULL
    };

    vkQueueSubmit(pScVk->GraphicsQueue, 1, &submitInfo, VK_NULL_HANDLE);
    vkQueueWaitIdle(pScVk->GraphicsQueue);

    // Free command for buffer
    vkFreeCommandBuffers(pScVk->Device, pScVk->Cmd.GraphicsPool, 1, &vkCmdBuffer);
}

/*

  ###################################
  ###################################
  sc_vk_frame_buffer
  ###################################
  ###################################

*/

ScVkFramebuffer
sc_vk_framebuffer_new_swapchain(ScVk* pScVk, VkRenderPass pass, VkImageView* aAttachmentViews, i32 attachmentsCount)
{
    VkImageView* aViews = NULL;
    for (i32 a = 0; a < attachmentsCount; ++a)
    {
        VkImageView view = aAttachmentViews[a];
        sc_list_add(aViews, view);
    }

    VkFramebufferCreateInfo frabufferCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
        .renderPass = pass,
        .attachmentCount = attachmentsCount,
        .pAttachments = aViews,
        .width = pScVk->WindowSize.Width,
        .height = pScVk->WindowSize.Height,
        .layers = 1
    };

    VkFramebuffer vkFramebuffer;
    VkResult createFramebufferResult = vkCreateFramebuffer(pScVk->Device, &frabufferCreateInfo, pScVk->pAllocator, &vkFramebuffer);

    if (createFramebufferResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "sc_vk_render_pass_new_ext: Failed to craete framebuffer!\n");
    }

    ScVkFramebuffer scVkFramebuffer = {
        .Framebuffer = vkFramebuffer,
        .aViews = aViews
    };
    return scVkFramebuffer;
}

ScVkFramebuffer
sc_vk_framebuffer_new_offscreen(ScVk* pScVk, VkRenderPass pass, ScTexture* aTextures)
{
    i32 attachmentsCount = sc_list_count(aTextures);
    VkImageView* aViews = sc_list_select(aTextures, View);
    VkImage* aImages = sc_list_select(aTextures, Image);
    VkDeviceMemory* aMemories = sc_list_select(aTextures, Memory);

    VkFramebufferCreateInfo frabufferCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
        .renderPass = pass,
        .attachmentCount = attachmentsCount,
        .pAttachments = aViews,
        .width = pScVk->WindowSize.Width,
        .height = pScVk->WindowSize.Height,
        .layers = 1
    };

    VkFramebuffer vkFramebuffer;
    VkResult createFramebufferResult = vkCreateFramebuffer(pScVk->Device, &frabufferCreateInfo, pScVk->pAllocator, &vkFramebuffer);

    if (createFramebufferResult != VK_SUCCESS)
    {
        sc_vk_fatal(pScVk, "sc_vk_render_pass_new_ext: Failed to craete framebuffer!\n");
    }

    ScVkFramebuffer scVkFramebuffer = {
        .Framebuffer = vkFramebuffer,
        .aViews = aViews,
        .aImages = aImages,
        .aMemories = aMemories
    };
    return scVkFramebuffer;
}

void
sc_vk_framebuffer_destroy(ScVk* pScVk, ScVkFramebuffer framebuffer)
{
    i32 viewsCount = sc_list_count(framebuffer.aViews);
    // note: у Swap есть только Views
    for (i32 i = 0; i < viewsCount; ++i)
    {
        vkDestroyImageView(pScVk->Device, framebuffer.aViews[i], pScVk->pAllocator);
    }

    i32 imagesCount = sc_list_count(framebuffer.aImages);
    // note: offscreen render-pass имеет images + memories
    for (i32 i = 0; i < imagesCount; ++i)
    {
        vkDestroyImage(pScVk->Device, framebuffer.aImages[i], pScVk->pAllocator);
        vkFreeMemory(pScVk->Device, framebuffer.aMemories[i], pScVk->pAllocator);
    }

    vkDestroyFramebuffer(pScVk->Device, framebuffer.Framebuffer, pScVk->pAllocator);
}

/*

  ###################################
  ###################################
  sc_vk_render_pass
  ###################################
  ###################################

*/

i32
sc_vk_render_pass_final_new(ScVk* pScVk)
{
    VkSampleCountFlags samplesCount = VK_SAMPLE_COUNT_1_BIT;

    printf("format %s\n", sc_vk_format_to_string(pScVk->Swap.SurfaceFormat.format));

    VkAttachmentDescription colorAttachment = {
        .format = pScVk->Swap.SurfaceFormat.format,
        .samples = samplesCount,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR
    };

    VkAttachmentReference colorAttachmentRef = {
        .attachment = 0,
        .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
    };

    VkSubpassDescription subpass = {
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount = 1,
        .pColorAttachments = &colorAttachmentRef
    };

    // Dependency - ждем завершения предыдущих pass'ов
    VkSubpassDependency dependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
        .srcAccessMask = 0,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT
    };

    VkRenderPassCreateInfo renderPassInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .attachmentCount = 1,
        .pAttachments = &colorAttachment,
        .subpassCount = 1,
        .pSubpasses = &subpass,
        .dependencyCount = 1,
        .pDependencies = &dependency
    };

    VkRenderPass renderPass;
    VkResult result = vkCreateRenderPass(pScVk->Device, &renderPassInfo, NULL, &renderPass);
    if (result != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Failed to create final render pass");
        return -1;
    }

    VkImageView* aAttachmentViews = NULL;
    VkImageView* aSwapImageViews = NULL;

    VkImage* aSwapImages = sc_vk_get_swap_images(pScVk, pScVk->Swap.Swapchain);

    sc_list_for_each(aSwapImages, pImage)
    {
        VkImageViewCreateInfo ci = {
            .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
            .pNext = NULL,
            .flags = 0,
            .image = *pImage,
            .viewType = VK_IMAGE_VIEW_TYPE_2D,
            .format = colorAttachment.format,
            .components = {
                .r = VK_COMPONENT_SWIZZLE_IDENTITY,
                .g = VK_COMPONENT_SWIZZLE_IDENTITY,
                .b = VK_COMPONENT_SWIZZLE_IDENTITY,
                .a = VK_COMPONENT_SWIZZLE_IDENTITY },
            .subresourceRange = { .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT, .baseMipLevel = 0, .levelCount = 1, .baseArrayLayer = 0, .layerCount = 1 }
        };
        VkImageView swapImageView = sc_vk_image_view_new(pScVk, ci);

        sc_list_add(aSwapImageViews, swapImageView);
    }

    /*
       DOCS: Creating framebuffer;s
    */
    i32 framebuffersCount = sc_list_count(aSwapImages);
    ScVkFramebuffer* aFramebuffers = NULL;
    for (i32 f = 0; f < framebuffersCount; ++f)
    {
        ScVkFramebuffer scVkFramebuffer = sc_vk_framebuffer_new_swapchain(pScVk, renderPass, &aSwapImageViews[f], 1);
        sc_list_add(aFramebuffers, scVkFramebuffer);
    }

    ScVkRenderPass scVkRenderPass = {
        .Type = ScVkRenderPassType_Final,
        .Handle = renderPass,
        .aFramebuffers = aFramebuffers,
        .Samples = samplesCount
    };

    sc_vk_register_render_pass(pScVk, &scVkRenderPass);

    return scVkRenderPass.Id;
}

i32
sc_vk_render_pass_new(ScVk* pScVk, ScVkRenderPassConfig renderPassCfg)
{
    if (renderPassCfg.BufferingType < ScVkRenderPassBufferingType_Single || renderPassCfg.BufferingType > ScVkRenderPassBufferingType_Triple)
    {
        sc_log_erro("FrameBufferingDim can be single, double or tripple!\n");
        sc_assert_break();
    }

    VkAttachmentReference* aColorRefs = NULL;
    VkAttachmentReference* pResolvedRef = NULL;
    VkAttachmentReference* pDepthRef = NULL;
    // SvlAttachment* aAttachments = NULL;
    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
    VkAttachmentDescription* aAllDescrs = NULL;

    for (i32 a = 0; a < renderPassCfg.AttachmentsCount; ++a)
    {
        ScVkAttachment attachment = renderPassCfg.aAttachments[a];

        VkSampleCountFlagBits descSample = renderPassCfg.aAttachments[a].Description.samples;
        if (descSample > samples)
            samples = descSample;

        switch (attachment.Type)
        {
        case ScVkAttachmentType_Color:
        {
            sc_list_add(aColorRefs, attachment.Reference);
            break;
        }

        case ScVkAttachmentType_Depth:
        {
            pDepthRef = &renderPassCfg.aAttachments[a].Reference;
            break;
        }
        case ScVkAttachmentType_ResolveMultisample:
        {
            if (pResolvedRef)
            {
                sc_vk_error(pScVk, "sc_vk_render_pass_new: pResolvedRef was already set!\n");
            }
            pResolvedRef = &renderPassCfg.aAttachments[a].Reference;
            break;
        }
        }

        sc_list_add(aAllDescrs, attachment.Description);
    }

    VkSubpassDescription subpassDescription = {
        // VkSubpassDescriptionFlags       flags;
        .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
        // todo:
        .inputAttachmentCount = 0,
        .pInputAttachments = NULL,
        .colorAttachmentCount = sc_list_count(aColorRefs),
        .pColorAttachments = aColorRefs,
        .pResolveAttachments = pResolvedRef,
        .pDepthStencilAttachment = pDepthRef,
        // todo:
        .preserveAttachmentCount = 0,
        .pPreserveAttachments = NULL,
    };

    VkRenderPassCreateInfo renderPassCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .pNext = NULL,
        .flags = 0, // VkRenderPassCreateFlags
        // NOTE: Maybe in some cases it may cause a problem
        .attachmentCount = sc_list_count(aAllDescrs),
        .pAttachments = aAllDescrs,
        .subpassCount = 1,
        .pSubpasses = &subpassDescription,
        .dependencyCount = 1,
        .pDependencies = &renderPassCfg.Dependency
    };

    VkRenderPass vkRenderPass;
    VkResult createRenderPassResult = vkCreateRenderPass(pScVk->Device, &renderPassCreateInfo, pScVk->pAllocator, &vkRenderPass);
    if (createRenderPassResult != VK_SUCCESS)
    {
        printf("%d\n", createRenderPassResult);
        sc_vk_fatal(pScVk, "sc_vk_render_pass_new: Failed to create!\n");
    }

    /* Craeting view images for attachments */
    i32 frame_buffering_dim = (i32)renderPassCfg.BufferingType;
    ScVkFramebuffer* aFrames = NULL;
    VkCommandBuffer* aCmdBuffers = NULL;
    VkSemaphore* aRenderFinishedSemaphores = NULL; // note: not using now
    VkFence* aFrameFences = NULL;

    for (i32 f = 0; f < frame_buffering_dim; ++f)
    {
        VkImageView* aAttachmentViews = NULL;
        VkImage* aImages = NULL;
        VkDeviceMemory* aMemories = NULL;
        ScTexture* aTextures = NULL;

        for (i32 a = 0; a < renderPassCfg.AttachmentsCount; ++a)
        {
            ScVkAttachment attachment = renderPassCfg.aAttachments[a];

            switch (attachment.Type)
            {
            case ScVkAttachmentType_Color:
            {
                VkImageCreateInfo imageCi = {
                    .sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
                    .pNext = NULL,
                    .flags = 0,
                    .imageType = VK_IMAGE_TYPE_2D,
                    .format = attachment.Description.format,
                    .extent = {
                        .width = renderPassCfg.Resolution.Width,
                        .height = renderPassCfg.Resolution.Height,
                        .depth = 1.0f },
                    .mipLevels = 1,
                    .arrayLayers = 1,
                    .samples = VK_SAMPLE_COUNT_1_BIT,
                    .tiling = VK_IMAGE_TILING_OPTIMAL,
                    .usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT /*  Для рендеринга */
                             | VK_IMAGE_USAGE_SAMPLED_BIT        /* Для семплинга в шейдере */
                    ,
                    .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
                    .queueFamilyIndexCount = 0, // NOTE(): should we set this value
                    .pQueueFamilyIndices = NULL,
                    .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED
                };

                VkImageViewCreateInfo imageViewCi = {
                    .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
                    .pNext = NULL,
                    .flags = 0,
                    .viewType = VK_IMAGE_VIEW_TYPE_2D,
                    .format = attachment.Description.format,
                    .components = {
                        .r = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .g = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .b = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .a = VK_COMPONENT_SWIZZLE_IDENTITY },
                    .subresourceRange = { .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT, .baseMipLevel = 0, .levelCount = 1, .baseArrayLayer = 0, .layerCount = 1 }
                };

                ScTexture scTxt = sc_vk_texture_new(pScVk, imageCi, imageViewCi, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

                // todo: for depth
                // sc_vk_image_change_layout_ext(pScVk, scTxt.Image,
                //     VK_IMAGE_LAYOUT_UNDEFINED,
                //     VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL, // Для рендеринга
                //     VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                //     VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
                //     1);

                sc_list_add(aTextures, scTxt);
                break;
            }

            case ScVkAttachmentType_Depth:
            {
                VkImageCreateInfo imageCi = {
                    .sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
                    .pNext = NULL,
                    .flags = 0,
                    .imageType = VK_IMAGE_TYPE_2D,
                    .format = attachment.Description.format,
                    .extent = {
                        .width = renderPassCfg.Resolution.Width,
                        .height = renderPassCfg.Resolution.Height,
                        .depth = 1.0f },
                    .mipLevels = 1,
                    .arrayLayers = 1,
                    .samples = attachment.Description.samples,
                    .tiling = VK_IMAGE_TILING_OPTIMAL,
                    .usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
                    .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
                    // NOTE(): should we set this value
                    .queueFamilyIndexCount = 0,
                    .pQueueFamilyIndices = NULL,
                    .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED
                };
                VkImageViewCreateInfo imageViewCi = {
                    .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
                    .pNext = NULL,
                    .flags = 0,
                    .viewType = VK_IMAGE_VIEW_TYPE_2D,
                    .format = attachment.Description.format,
                    .components = {
                        .r = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .g = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .b = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .a = VK_COMPONENT_SWIZZLE_IDENTITY },
                    .subresourceRange = { .aspectMask = VK_IMAGE_ASPECT_DEPTH_BIT, .baseMipLevel = 0, .levelCount = 1, .baseArrayLayer = 0, .layerCount = 1 }
                };
                ScTexture scTxt = sc_vk_texture_new(pScVk, imageCi, imageViewCi, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
                sc_list_add(aTextures, scTxt);
                break;
            }

            case ScVkAttachmentType_ResolveMultisample:
            {
                VkImageCreateInfo imageCi = {
                    .sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
                    .imageType = VK_IMAGE_TYPE_2D,
                    .format = attachment.Description.format,
                    .extent = {
                        .width = renderPassCfg.Resolution.Width,
                        .height = renderPassCfg.Resolution.Height,
                        .depth = 1.0f },
                    .mipLevels = 1,
                    .arrayLayers = 1,
                    .samples = samples,
                    .tiling = VK_IMAGE_TILING_OPTIMAL,
                    .usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
                    .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
                    .queueFamilyIndexCount = 0, // NOTE(): should we set this value
                    .pQueueFamilyIndices = NULL,
                    .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED
                };

                VkImageViewCreateInfo imageViewCi = {
                    .sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
                    .pNext = NULL,
                    .flags = 0,
                    .viewType = VK_IMAGE_VIEW_TYPE_2D,
                    .format = attachment.Description.format,
                    .components = {
                        .r = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .g = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .b = VK_COMPONENT_SWIZZLE_IDENTITY,
                        .a = VK_COMPONENT_SWIZZLE_IDENTITY },
                    .subresourceRange = { .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT, .baseMipLevel = 0, .levelCount = 1, .baseArrayLayer = 0, .layerCount = 1 }
                };

                ScTexture scTxt = sc_vk_texture_new(pScVk, imageCi, imageViewCi, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
                sc_list_add(aTextures, scTxt);
                break;
            }
            }
        }

        ScVkFramebuffer scVkFramebuffer = sc_vk_framebuffer_new_offscreen(pScVk, vkRenderPass, aTextures);
        sc_list_add(aFrames, scVkFramebuffer);
    }

    sc_list_free(aColorRefs);
    sc_list_free(aAllDescrs);

    ScVkRenderPass renderPass = {
        .Handle = vkRenderPass,
        .BufferingType = renderPassCfg.BufferingType,
        .aFramebuffers = aFrames,
        .Samples = samples,
    };

    sc_vk_register_render_pass(pScVk, &renderPass);

    return renderPass.Id;
}

void
sc_vk_render_pass_destroy(ScVk* pScVk, i32 id)
{
    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, id);
    ScVkRenderPass renderPass = *pPass;
    sc_vk_remove_render_pass(pScVk, id);

    sc_vk_shared_buffer_destroy(pScVk, renderPass.Vertex);
    sc_vk_shared_buffer_destroy(pScVk, renderPass.Index);

    for (i32 m = 0; m < sc_list_count(renderPass.aMemories); ++m)
    {
        VkDeviceMemory memory = renderPass.aMemories[m];
        vkFreeMemory(pScVk->Device, memory, pScVk->pAllocator);
    }

    for (i32 f = 0; f < sc_list_count(renderPass.aFramebuffers); ++f)
    {
        ScVkFramebuffer framebuffer = renderPass.aFramebuffers[f];
        sc_vk_framebuffer_destroy(pScVk, framebuffer);
    }

    vkDestroyRenderPass(pScVk->Device, renderPass.Handle, pScVk->pAllocator);
}

Sc2dTexture
sc_vk_render_pass_get_current_image_as_texture(ScVkRenderPass* pPass, VkSampler sampler)
{
    ScVkFramebuffer framebuffer = pPass->aFramebuffers[pPass->FrameIndex];
    VkImage image2d = framebuffer.aImages[0];
    VkImageView view2d = framebuffer.aViews[0];
    Sc2dTexture txt2d = {
        .Image = image2d,
        .View = view2d,
        .Sampler = sampler
    };
    return txt2d;
}

const char*
sc_vk_render_pass_type_to_string(ScVkRenderPassType type)
{
    switch (type)
    {
    case ScVkRenderPassType_Final:
        return "Final";
    case ScVkRenderPassType_Custom:
        return "Final";
    default:
        return "Undefined";
    }
}

void
sc_vk_render_pass_draw_v2(ScVk* pScVk, ScVkRenderPass* pPass, VkCommandBuffer cmdBuffer)
{
    i8 frameIndex = pPass->FrameIndex;
    pPass->FrameIndex = (pPass->FrameIndex + 1) % sc_list_count(pPass->aFramebuffers);
    ScVkFramebuffer scVkFramebuffer = pPass->aFramebuffers[frameIndex];

    VkClearValue aClearValues[2] = {
        [0] = (VkClearValue) {
            .color = { 0.0f, 0.0f, 0.0f, 0.0f } },
        [1] = (VkClearValue) { .depthStencil = { .depth = 1.0f, .stencil = 0 } }
    };

    VkRenderPassBeginInfo renderPassBeginInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .renderPass = pPass->Handle,
        .framebuffer = scVkFramebuffer.Framebuffer,
        .renderArea = {
            .offset = { 0, 0 },
            .extent = pScVk->Swap.Resolution },
        .clearValueCount = ScArrayCount(aClearValues),
        .pClearValues = aClearValues
    };

    vkCmdBeginRenderPass(cmdBuffer, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);

    VkViewport viewport = {
        .x = 0,
        .y = 0,
        .width = (float)pScVk->Swap.Resolution.width,
        .height = (float)pScVk->Swap.Resolution.height,
        .minDepth = 0,
        .maxDepth = 1
    };
    vkCmdSetViewport(cmdBuffer, 0, 1, &viewport);

    VkRect2D scissor = {
        .offset = { 0, 0 },
        .extent = pScVk->Swap.Resolution
    };
    vkCmdSetScissor(cmdBuffer, 0, 1, &scissor);

    i32 pipeCount = sc_list_count(pPass->aPipelineIds);
    for (i32 p = 0; p < pipeCount; ++p)
    {
        i64 id = pPass->aPipelineIds[p];
        ScVkPipeline* pPipe = sc_vk_get_pipeline(pScVk, id);
        if (!pPipe->IsEnabled)
            continue;

        VkExtent2D extent = { .width = (float)pScVk->Swap.Resolution.width, .height = (float)pScVk->Swap.Resolution.height };
        // render pipe
        VkViewport viewport = {
            .x = 0,
            .y = 0,
            .width = extent.width,
            .height = extent.height,
            .minDepth = 0,
            .maxDepth = 1
        };
        vkCmdSetViewport(cmdBuffer, 0, 1, &viewport);

        // TODO(typedef): set in pipeline
        VkRect2D scissor = {
            .offset = { 0, 0 },
            .extent = extent
        };
        vkCmdSetScissor(cmdBuffer, 0, 1, &scissor);

        vkCmdBindPipeline(cmdBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pPipe->Handle);
        vkCmdBindDescriptorSets(cmdBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pPipe->Layout, 0, 1, &pPipe->ShaderBridge.Set, 0, NULL);

        // todo: rename to bufferView
        ScVkBufferView bufferView = pPass->aBufferViews[pPipe->BufferId];

        VkDeviceSize offsets[1] = { bufferView.VerticesOffset };
        vkCmdBindVertexBuffers(cmdBuffer, 0, 1, &pPass->Vertex.GpuBuffer.Buffer, offsets);
        vkCmdBindIndexBuffer(cmdBuffer, pPass->Index.GpuBuffer.Buffer, bufferView.IndicesOffset, VK_INDEX_TYPE_UINT32);

        vkCmdDrawIndexed(cmdBuffer, pPipe->State.IndicesCount, 1, 0, 0, 0);

        pPipe->State.IndicesCount = 0;
    }

    // end render pass
    vkCmdEndRenderPass(cmdBuffer);
}

v2
sc_vk_request_buffer_get_sizes(ScVkRenderPass* pPass)
{
    v2 totals = {};
    i64 cnt = sc_list_count(pPass->aBufferViews);

    for (i32 i = 0; i < cnt; ++i)
    {
        ScVkBufferView req = pPass->aBufferViews[i];
        totals.V[0] += req.VerticesSize;
        totals.V[1] = ScMax(totals.V[1], req.IndicesSize);
    }

    return totals;
}

i32
sc_vk_render_pass_request_buffer(ScVk* pScVk, ScVkRenderPass* pPass, i64 verticesSize, i64 indicesSize)
{
    v2 totals = sc_vk_request_buffer_get_sizes(pPass);
    i32 requestIndex = sc_list_count(pPass->aBufferViews);

    ScVkBufferView request = {
        .VerticesOffset = totals.X,
        .IndicesOffset = 0,
        .VerticesSize = verticesSize,
        .IndicesSize = indicesSize
    };
    sc_list_add(pPass->aBufferViews, request);

    return requestIndex;
}

void
sc_vk_render_pass_create_buffers(ScVk* pScVk, i32 id)
{
    i32 ind = sc_list_index_of(pScVk->aRenderPasses, item.Id == id);
    sc_assert(ind != -1 && "Can't find render pass by id.");
    ScVkRenderPass* pPass = &pScVk->aRenderPasses[ind];

    v2 totalSizes = sc_vk_request_buffer_get_sizes(pPass);

    ScVkSharedBuffer vertexBuffer = sc_vk_vertex_buffer_new(pScVk, totalSizes.V[0]);
    ScVkSharedBuffer indexBuffer = sc_vk_index_buffer_new(pScVk, totalSizes.V[1]);
    pPass->Vertex = vertexBuffer;
    pPass->Index = indexBuffer;
}

/*

  ###################################
  ###################################
  sc_vk_pipe
  ###################################
  ###################################

*/

ScVkShaderModule
sc_vk_shader_module_new(ScVkShaderCompileConfig cfg)
{
    VkShaderModule module = sc_vk_shader_new(cfg);
    ScVkShaderModule scVkShaderModule = {
        .pPath = cfg.pSourcePath,
        .Module = module
    };
    return scVkShaderModule;
}

ScVkStage
sc_vk_stage_new(ScVk* pScVk, ScVkStageConfig cfg, i32 shouldAddToTessEval, VkDescriptorSetLayoutBinding** paBindings, VkDescriptorPoolSize** paPoolSizes)
{
    ScVkStage stage = {
        .Type = cfg.Type
    };

    ScVkShaderCompileConfig shaderCfg = {
        .pScVk = pScVk,
        .pSourcePath = (char*)cfg.pShaderPath,
        .IsOmpimize = pScVk->Flags.IsDebug == 0
    };
    ScVkShaderModule shaderModule = sc_vk_shader_module_new(shaderCfg);
    stage.Shader = shaderModule;

    VkShaderStageFlagBits stageFlag = sc_vk_stage_type_to_native(cfg.Type);
    if (shouldAddToTessEval)
        stageFlag |= VK_SHADER_STAGE_TESSELLATION_EVALUATION_BIT;

    VkDescriptorSetLayoutBinding* aBindings = *paBindings;
    VkDescriptorPoolSize* aPoolSizes = *paPoolSizes;

    for (i32 d = 0; d < cfg.DescriptorsCount; ++d)
    {
        ScVkDescriptorConfig descriptor = cfg.aDescriptors[d];
        sc_assert(descriptor.Count > 0); // todo: do it inside cfg creators
        i32 descrCnt = 1;

        switch (descriptor.Type)
        {

        case ScVkDescriptorType_Uniform:
        {
            // todo: get offset for new virtual_uniform_buffer
            ScVkUniformConfig uniCfg = {
                .pName = (char*)descriptor.pName,
                .Size = descriptor.Size * descriptor.Count,
                .ItemSize = descriptor.Size,
                .BindingIndex = descriptor.Binding,
                .PipelineIndex = cfg.PipelineIndex
            };
            ScVkUniform scVkUniform = sc_vk_uniform_new(pScVk, uniCfg);
            sc_list_add(stage.aUniforms, scVkUniform);
            break;
        }

        case ScVkDescriptorType_Image:
        {
            descrCnt = descriptor.Count;
            descriptor.pName = sc_string_new(descriptor.pName);
            sc_list_add(stage.aDescriptors, descriptor);
            break;
        }

        default:
            // not sure we need this
            sc_assert(0);
            break;
        }

        VkDescriptorType descriptorType = sc_vk_descriptor_type_to_native(descriptor.Type);

        VkDescriptorSetLayoutBinding binding = {
            .binding = descriptor.Binding,
            .descriptorType = descriptorType,
            .descriptorCount = descrCnt,
            .stageFlags = stageFlag,
            .pImmutableSamplers = NULL
        };

        VkDescriptorPoolSize poolSize = {
            .type = descriptorType,
            .descriptorCount = descrCnt
        };

        sc_list_add(aBindings, binding);
        sc_list_add(aPoolSizes, poolSize);
    }

    *paBindings = aBindings;
    *paPoolSizes = aPoolSizes;

    return stage;
}

ScVkShaderBridge
sc_vk_shader_bridge_new(ScVk* pScVk, ScVkStageConfig* aStages, i32 stagesCount)
{
    ScVkShaderBridge bridge = {};

    VkDescriptorSetLayoutBinding* aBindings = NULL;
    VkDescriptorPoolSize* aPoolSizes = NULL;

    i32 shouldAddToTess = 0;
    for (i32 s = 0; s < stagesCount; ++s)
    {
        ScVkStageConfig* pStageCfg = &aStages[s];
        if (pStageCfg->Type == ScVkStageType_Tesselation_Evaluation)
            shouldAddToTess = 1;
    }

    for (i32 i = 0; i < stagesCount; ++i)
    {
        ScVkStageConfig stageCfg = aStages[i];
        ScVkStage stage = sc_vk_stage_new(pScVk, stageCfg, shouldAddToTess, &aBindings, &aPoolSizes);
        sc_list_add(bridge.aStages, stage);
    }

    VkDescriptorSetLayoutCreateInfo descriptorCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO,
        .pNext = NULL,
        .flags = 0, // VK_DESCRIPTOR_SET_LAYOUT_CREATE_UPDATE_AFTER_BIND_POOL_BIT,//0,
        .bindingCount = sc_list_count(aBindings),
        .pBindings = aBindings
    }; // VkDescriptorSetLayoutBinding

    sc_log_info("BINDING CNT: %lld\n", sc_list_count(aBindings));
    sc_list_for_each(aBindings, pBind)
    {
        sc_log_info("dscr-type: %s\n", sc_vk_n_descriptor_type_to_string(pBind->descriptorType));
    }

    VkDescriptorSetLayout vkDescriptorSetLayout;
    VkResult createDescriptorSetLayoutResult = vkCreateDescriptorSetLayout(pScVk->Device, &descriptorCreateInfo, pScVk->pAllocator, &vkDescriptorSetLayout);

    if (createDescriptorSetLayoutResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Failed descriptor set layout creation!");
    }

    VkDescriptorPoolCreateInfo vkPoolCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO,
        .pNext = NULL,
        .flags = VK_DESCRIPTOR_POOL_CREATE_UPDATE_AFTER_BIND_BIT,
        .maxSets = 1,
        .poolSizeCount = sc_list_count(aPoolSizes),
        .pPoolSizes = aPoolSizes,
    };

    VkDescriptorPool vkDescriptorPool;
    VkResult descriptorPoolCreateResult = vkCreateDescriptorPool(pScVk->Device, &vkPoolCreateInfo, pScVk->pAllocator, &vkDescriptorPool);

    if (descriptorPoolCreateResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Failed Descriptor Pool Creation!");
    }

    VkDescriptorSet vkDescriptorSet;
    VkDescriptorSetAllocateInfo vkDescriptorSetAllocateInfo = {
        .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO,
        .pNext = NULL,
        .descriptorPool = vkDescriptorPool,
        .descriptorSetCount = 1,
        .pSetLayouts = &vkDescriptorSetLayout,
    };

    VkResult allocateDescritorSetsResult = vkAllocateDescriptorSets(pScVk->Device, &vkDescriptorSetAllocateInfo, &vkDescriptorSet);

    if (allocateDescritorSetsResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Failed allocate descriptor sets!");
    }

    sc_list_free(aBindings);
    sc_list_free(aPoolSizes);

    bridge.Set = vkDescriptorSet;
    bridge.SetLayout = vkDescriptorSetLayout;
    bridge.Pool = vkDescriptorPool;

    return bridge;
}

void
sc_vk_shader_bridge_destroy(ScVk* pScVk, ScVkShaderBridge bridge)
{
    vkDestroyDescriptorPool(pScVk->Device, bridge.Pool, pScVk->pAllocator);
    vkDestroyDescriptorSetLayout(pScVk->Device, bridge.SetLayout, pScVk->pAllocator);

    ScVkStage* aStages = bridge.aStages;
    for (i32 s = 0; s < sc_list_count(aStages); ++s)
    {
        ScVkStage stage = aStages[s];

        sc_list_for_each(stage.aUniforms, pUniform)
        {
            sc_vk_uniform_destroy(pScVk, *pUniform);
        }

        sc_list_free(stage.aDescriptors);
        sc_list_free(stage.aUniforms);
        sc_vk_shader_destroy(pScVk, stage.Shader.Module);
    }
}

i32
sc_vk_pipeline_new(ScVk* pScVk, ScVkPipelineConfig cfg)
{
    ScVkPipeline pipe = {
        .IsEnabled = 1,
        .Id = sc_list_count(pScVk->aPipelines),
        .RenderPassId = cfg.RenderPassId,
        // .Config = cfg,
    };

    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, cfg.RenderPassId);
    sc_list_add(pPass->aPipelineIds, pipe.Id);

    i64 verticesSize = cfg.VerticesCount * cfg.Stride;
    i64 indicesSize = cfg.IndicesCount * sizeof(u32);
    i32 bufferInd = sc_vk_render_pass_request_buffer(pScVk, pPass, verticesSize, indicesSize);
    pipe.BufferId = bufferInd;

    // DOCS: Создаём Layout

    ScVkShaderBridge shaderBridge = sc_vk_shader_bridge_new(pScVk, cfg.aStages, cfg.StagesCount);
    pipe.ShaderBridge = shaderBridge;

    VkPipelineLayoutCreateInfo pipelineLayoutCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
        .setLayoutCount = 1,
        .pSetLayouts = &shaderBridge.SetLayout,
        .pushConstantRangeCount = 0,
        .pPushConstantRanges = NULL
    };

    VkPipelineLayout layout;
    VkResult createPipelineLayoutResult = vkCreatePipelineLayout(pScVk->Device, &pipelineLayoutCreateInfo, pScVk->pAllocator, &layout);
    if (createPipelineLayoutResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Can't create pipeline layout!");
        goto ScVkPipelineCreateEndLabel;
    }

    // DOCS: Создаём Pipeline

    VkPipelineShaderStageCreateInfo* aStageCreateInfos = NULL;
    for (i32 s = 0; s < sc_list_count(shaderBridge.aStages); ++s)
    {
        ScVkStage stage = shaderBridge.aStages[s];
        VkPipelineShaderStageCreateInfo ci = {
            .sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
            .pNext = NULL,
            .flags = 0,
            .stage = sc_vk_stage_type_to_native(stage.Type),
            .module = stage.Shader.Module,
            .pName = "main",
            /* NOTE(typedef): use this thing if we need constants in shader */
            .pSpecializationInfo = NULL
        };
        sc_list_add(aStageCreateInfos, ci);
    }

    VkVertexInputAttributeDescription* aAttributeDescrs = NULL;
    for (i32 a = 0; a < cfg.AttributesCount; ++a)
    {
        ScVkAttribute attr = cfg.aAttributes[a];
        VkVertexInputAttributeDescription descr = {
            .location = a,
            .binding = 0, // GroupBinding ?
            .format = attr.Format,
            .offset = attr.Offset
        };

        sc_list_add(aAttributeDescrs, descr);
    }

    VkVertexInputBindingDescription vkVertexInputBindingDescription = {
        .binding = 0,
        .stride = cfg.Stride,
        .inputRate = VK_VERTEX_INPUT_RATE_VERTEX
    };

    VkPipelineVertexInputStateCreateInfo pipelineVertexInputCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO,
        .vertexBindingDescriptionCount = 1,
        .pVertexBindingDescriptions = &vkVertexInputBindingDescription,
        .vertexAttributeDescriptionCount = sc_list_count(aAttributeDescrs),
        .pVertexAttributeDescriptions = aAttributeDescrs
    };

    VkDynamicState dynamicStates[2] = {
        [0] = VK_DYNAMIC_STATE_VIEWPORT,
        [1] = VK_DYNAMIC_STATE_SCISSOR
    };

    VkPipelineDynamicStateCreateInfo pipelineDynamicStateCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO,
        .dynamicStateCount = ScArrayCount(dynamicStates),
        .pDynamicStates = dynamicStates,
    };

    VkPrimitiveTopology primitiveTopology = sc_vk_topology_type_to_vk(cfg.Topology);
    VkPipelineInputAssemblyStateCreateInfo pipelineInputAssemblyCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .topology = primitiveTopology,
        .primitiveRestartEnable = VK_FALSE
    };

    // DOCS(typedef): passing viewport, scissor here make them immutable
    VkPipelineViewportStateCreateInfo pipelineViewportCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO,
        .viewportCount = 1,
        .scissorCount = 1
    };

    VkPipelineRasterizationStateCreateInfo pipelineRasterizationCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .depthClampEnable = VK_TRUE, // NOTE(typedef): enabling that requires gpu feature
        .rasterizerDiscardEnable = VK_FALSE,
        .polygonMode = cfg.PolygonMode, // NOTE(typedef): requires enabling gpu feature
        .cullMode =
#if 1 // NOTE(): best option
            VK_CULL_MODE_NONE,
#else // DOCS: Using this for now
            VK_CULL_MODE_BACK_BIT,
#endif
        .frontFace =
#if 0 // NOTE(): best option
            VK_FRONT_FACE_COUNTER_CLOCKWISE,
#else
            VK_FRONT_FACE_CLOCKWISE,
#endif
        .depthBiasEnable = VK_FALSE,
        .depthBiasConstantFactor = 0.0f,
        .depthBiasClamp = 0.0f,
        .depthBiasSlopeFactor = 0.0f,
        // NOTE(typedef): anything other then 1.0f requires enabling GPU feature
        .lineWidth = 1.0f
    };

    ScVkRenderPass* pRenderPass = sc_vk_get_render_pass(pScVk, cfg.RenderPassId);
    VkSampleCountFlagBits samples = pRenderPass->Samples;
    printf("Pipe sample count: %s\n", sc_vk_sample_count_to_string(samples));
    VkPipelineMultisampleStateCreateInfo pipelineMultisampleCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO,
        .rasterizationSamples = samples,
        .sampleShadingEnable = VK_FALSE,
        .minSampleShading = 1.0f,
        .alphaToCoverageEnable = VK_FALSE,
        .alphaToOneEnable = VK_FALSE
    };

    i32 isDepthEnabled = cfg.IsDepthWriteEnabled ? VK_TRUE : VK_FALSE;
    VkPipelineDepthStencilStateCreateInfo depthStencilCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO,
        .depthTestEnable = VK_TRUE,
        .depthWriteEnable = isDepthEnabled,            // DOCS: Отключили для 2д рендеринга
        .depthCompareOp = VK_COMPARE_OP_LESS_OR_EQUAL, // is new value correct ? ? VK_COMPARE_OP_LESS,
        .depthBoundsTestEnable = VK_FALSE,
        .stencilTestEnable = VK_FALSE,
        .front = 0.0f,
        .back = 0.0f,
        .minDepthBounds = 0.0f,
        .maxDepthBounds = 1.0f
    };

    printf("Blending: %s\n", (cfg.Blend.State == ScVkBlendState_Enabled) ? "Enabled" : "Disabled");
    VkPipelineColorBlendAttachmentState pipelineColorBlendAttachment = {
        .blendEnable = (cfg.Blend.State == ScVkBlendState_Enabled) ? VK_TRUE : VK_FALSE,
        .colorBlendOp = VK_BLEND_OP_ADD,
        .alphaBlendOp = VK_BLEND_OP_ADD,

        .srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA,
        .dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA,

        .srcAlphaBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA,
        .dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA,

        .colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT,
    };

    VkPipelineColorBlendStateCreateInfo pipelineColorBlendCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO,
        .logicOpEnable = VK_FALSE,
        .attachmentCount = 1,
        .pAttachments = &pipelineColorBlendAttachment,
    };

    VkPipelineTessellationStateCreateInfo* pTesselationState = NULL;

    VkPipelineTessellationStateCreateInfo tesselationState = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_TESSELLATION_STATE_CREATE_INFO,
        .patchControlPoints = get_tesselation_patch_ctrl_points(cfg)
    };
    if (get_stage_config(cfg, ScVkStageType_Tesselation_Control) != NULL)
    {
        pTesselationState = &tesselationState;
    }

    VkGraphicsPipelineCreateInfo graphicsPipelineCreateInfo = {
        .sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO,
        .pNext = NULL,
        .flags = 0,
        .stageCount = sc_list_count(aStageCreateInfos),
        .pStages = aStageCreateInfos,
        .pVertexInputState = &pipelineVertexInputCreateInfo,
        .pInputAssemblyState = &pipelineInputAssemblyCreateInfo,
        .pTessellationState = pTesselationState,
        .pViewportState = &pipelineViewportCreateInfo,
        .pRasterizationState = &pipelineRasterizationCreateInfo,
        .pMultisampleState = &pipelineMultisampleCreateInfo,
        .pDepthStencilState = &depthStencilCreateInfo,
        .pColorBlendState = &pipelineColorBlendCreateInfo,
        .pDynamicState = &pipelineDynamicStateCreateInfo,
        .layout = layout,
        .renderPass = pRenderPass->Handle,
        .subpass = 0,
        .basePipelineHandle = VK_NULL_HANDLE,
        .basePipelineIndex = -1
    };

    VkPipeline pipeline;
    VkResult createGraphicsPipelinesResult = vkCreateGraphicsPipelines(pScVk->Device, VK_NULL_HANDLE, 1, &graphicsPipelineCreateInfo, pScVk->pAllocator, &pipeline);

    if (createGraphicsPipelinesResult != VK_SUCCESS)
    {
        sc_vk_error(pScVk, "Can't create Graphics Pipeline!");
    }

ScVkPipelineCreateEndLabel:
    sc_list_free(aStageCreateInfos);
    sc_list_free(aAttributeDescrs);

    pipe.Handle = pipeline;
    pipe.Layout = layout;
    pipe.ShaderBridge = shaderBridge;

    sc_list_add(pScVk->aPipelines, pipe);

    return pipe.Id;
}

void
sc_vk_pipeline_destroy(ScVk* pScVk, ScVkPipeline pipeline)
{
    ScVkShaderBridge shaderBridge = pipeline.ShaderBridge;
    sc_vk_shader_bridge_destroy(pScVk, shaderBridge);
    vkDestroyPipelineLayout(pScVk->Device, pipeline.Layout, pScVk->pAllocator);
    vkDestroyPipeline(pScVk->Device, pipeline.Handle, pScVk->pAllocator);
}

void
sc_vk_pipeline_destroy_by_id(ScVk* pScVk, i64 pipeId)
{
    ScVkPipeline* pPipe = sc_vk_pipeline_get(pScVk, pipeId);
    sc_vk_pipeline_destroy(pScVk, *pPipe);
}

ScVkUniform*
sc_vk_pipeline_get_uniform(ScVkPipeline* pPipeline, const char* pName)
{
    i32 nameLength = sc_string_get_length((char*)pName);
    i32 stagesCount = sc_list_count(pPipeline->ShaderBridge.aStages);

    for (i32 s = 0; s < stagesCount; ++s)
    {
        ScVkStage stage = pPipeline->ShaderBridge.aStages[s];

        i32 uniformsCount = sc_list_count(stage.aUniforms);
        for (i32 u = 0; u < uniformsCount; ++u)
        {
            ScVkUniform* pUniform = &stage.aUniforms[u];
            i32 uniformNameLength = sc_string_get_length(pUniform->pName);
            if (uniformNameLength != nameLength)
                continue;

            if (sc_string_compare_ext(pUniform->pName, (char*)pName, nameLength))
                return pUniform;
        }
    }

    return NULL;
}

i32
sc_vk_pipeline_set_uniform(ScVk* pScVk, i64 pipeId, const char* pName, void* pData, u64 offset, u64 dataSize)
{
    if (pipeId == -1)
        return 0;

    ScVkPipeline* pPipe = sc_vk_get_pipeline(pScVk, pipeId);
    if (!pPipe)
        return 0;

    ScVkUniform* pCameraUniform = sc_vk_pipeline_get_uniform(pPipe, pName);
    if (!pCameraUniform)
    {
        char buf[256] = {};
        snprintf(buf, 256, "%s doesn;t exist in %s pipe!", pName, pPipe->pName);
        return 0;
    }

    sc_vk_uniform_set(pScVk, pCameraUniform, pData, offset, dataSize);
    return 1;
}

ScVkDescriptorConfig*
sc_vk_pipeline_get_descriptor(ScVkPipeline* pPipeline, const char* pName)
{
    i32 nameLength = sc_string_get_length((char*)pName);
    i32 stagesCount = sc_list_count(pPipeline->ShaderBridge.aStages);

    for (i32 s = 0; s < stagesCount; ++s)
    {
        ScVkStage stage = pPipeline->ShaderBridge.aStages[s];

        i32 descriptorCount = sc_list_count(stage.aDescriptors);
        for (i32 u = 0; u < descriptorCount; ++u)
        {
            ScVkDescriptorConfig* pDescr = &stage.aDescriptors[u];
            i32 uniformNameLength = sc_string_get_length(pDescr->pName);
            if (uniformNameLength != nameLength)
                continue;

            if (sc_string_compare_ext(pDescr->pName, (char*)pName, nameLength))
                return pDescr;
        }
    }
    return NULL;
}

void
sc_vk_pipeline_set_vertices_ext(ScVk* pScVk, ScVkPipeline* pPipeline, void* pData, u64 size, u64 offset)
{
    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, pPipeline->RenderPassId);
    ScVkSharedBuffer* pVertex = &pPass->Vertex;
    ScVkBufferView view = pPass->aBufferViews[pPipeline->BufferId];
    sc_vk_shared_buffer_set_data(pScVk, pVertex, pData, view.VerticesOffset + offset, size);
}

void
sc_vk_pipeline_set_vertices(ScVk* pScVk, ScVkPipeline* pPipeline, void* pData, u64 size)
{
    sc_vk_pipeline_set_vertices_ext(pScVk, pPipeline, pData, size, 0);
}

ScVkPipelineConfig
sc_vk_pipeline_config_new_ext(ScVkPipelineConfig cfg)
{
    // note: this approach can be wrong.
    if (cfg.Stride == 0)
    {
        u64 stride = 0;
        for (i32 i = 0; i < cfg.AttributesCount; ++i)
        {
            ScVkAttribute attr = cfg.aAttributes[i];
            stride += sc_vk_format_get_size(attr.Format);
        }
        cfg.Stride = stride;
    }
    else if (cfg.Stride == -1)
    {
        cfg.Stride = 0;
    }

    // note: validate
    for (i32 s = 0; s < cfg.StagesCount; ++s)
    {
        ScVkStageConfig stage = cfg.aStages[s];
        if (stage.DescriptorsCount > 0 && stage.aDescriptors == NULL)
        {
            printf(ScTerminalRed("Wrong stage config: %s \nLook at aDescriptors and stage.DescriptorCount!") "\n", sc_vk_stage_type_to_string(stage.Type));
        }
    }

    return cfg;
}

void
sc_vk_test_pipe(ScVk* pScVk, ScVkRenderPass renderPass)
{

    // sc_vk_pipeline_destroy(pScVk, testPipe);

    /*
    Deps:
      RenderPass->Handle -> VkGraphicsPipelineCreateInfo
      RenderPass->Samples -> VkPipelineMultisampleStateCreateInfo

    Actions:
      create [Descriptor Set] object;s
      create [ShaderModule] object;s
      create [AttributeDescription] ;s -> VkPipelineVertexInputStateCreateInfo

    Todo:
      create vertex/index buffers (mb ssbo, indirect cmd;s)


    */

    /*
   Actxions:
    */
}

/*

  ###################################
  ###################################
  sc_vk_frame
  ###################################
  ###################################

*/

#if 0
ScVkFrameResult
sc_vk_frame_start(ScVk* pScVk, VkCommandBuffer cmd, u32* pImageIndex)
{
    static u64 noTime = (18446744073709551615ULL);
    vkWaitForFences(pScVk->Device, 1, &pScVk->FrameFence, VK_TRUE, noTime);
    vkResetFences(pScVk->Device, 1, &pScVk->FrameFence);

    VkResult accuireNextImageResult =
        vkAcquireNextImageKHR(pScVk->Device, pScVk->Swap.Swapchain, noTime, pScVk->ImageAvailableSemaphore, VK_NULL_HANDLE, pImageIndex);
    if (accuireNextImageResult == VK_ERROR_OUT_OF_DATE_KHR)
    {
        // todo: impl
        // GINFO("Recreate!\n");
        // vsa_swapchain_objects_recreate();
        return ScVkFrameResult_SwapchainNeedsRecreation;
    }
    else if (accuireNextImageResult == VK_SUBOPTIMAL_KHR)
    {
        // DOCS(typedef): this thing is not an error or smth, just continue there
        // GWARNING("Swapchain is VK_SUBOPTIMAL_KHR!\n");
        return ScVkFrameResult_SurfaceChanged;
    }
    else
    {
        // vkValidResult(accuireNextImageResult, "Can't acquire next image khr!");
    }

    // todo: check if this was correct
    // vkResetFences(pScVk->Device, 1, &pScVk->FrameFence);

    const i32 no_flag = 0;
    vkResetCommandBuffer(cmd, no_flag);

    return ScVkFrameResult_Created;
}

void
sc_vk_frame_end(ScVk* pScVk, VkCommandBuffer cmd, u32* pImageIndex)
{
    VkPipelineStageFlags pipelineStageFlag = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;

    VkSubmitInfo submitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .pNext = NULL,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = &pScVk->ImageAvailableSemaphore,
        .pWaitDstStageMask = &pipelineStageFlag,
        .commandBufferCount = 1,
        .pCommandBuffers = &cmd,
        .signalSemaphoreCount = 1,
        .pSignalSemaphores = &pScVk->RenderFinishedSemaphore
    };

    // NOTE(typedef): Submiting Recorded Commands
    VkResult queueSubmitResult =
        vkQueueSubmit(pScVk->GraphicsQueue, 1, &submitInfo, pScVk->FrameFence);
    // vkValidResult(queueSubmitResult, "Can't Submit Queue!");

    VkPresentInfoKHR presentInfoKhr = {
        .sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
        .pNext = NULL,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = &pScVk->RenderFinishedSemaphore,
        .swapchainCount = 1,
        .pSwapchains = &pScVk->Swap.Swapchain,
        .pImageIndices = pImageIndex,
        .pResults = NULL
    };

    VkResult queuePresentKhr =
        vkQueuePresentKHR(pScVk->GraphicsQueue, &presentInfoKhr);
    if (queuePresentKhr == VK_ERROR_OUT_OF_DATE_KHR || queuePresentKhr == VK_SUBOPTIMAL_KHR /* || gIsWindowBeenResized */)
    {
        // GINFO("Recreate!\n");
        // gIsWindowBeenResized = 0;
        // vsa_swapchain_objects_recreate();
        return;
    }
    else
    {
        // vkValidResult(queuePresentKhr, "Queue Present KHR!\n");
    }
}
#endif // if 0

/*

  ###################################
  ###################################
  sc_vk_helpers
  ###################################
  ###################################

*/

u64
sc_vk_format_get_size(VkFormat vkFormat)
{
    switch (vkFormat)
    {
        // 8-bit formats
    case VK_FORMAT_R8_UNORM:
    case VK_FORMAT_R8_SNORM:
    case VK_FORMAT_R8_USCALED:
    case VK_FORMAT_R8_SSCALED:
    case VK_FORMAT_R8_UINT:
    case VK_FORMAT_R8_SINT:
    case VK_FORMAT_R8_SRGB:
        return 1;

    // 16-bit formats
    case VK_FORMAT_R8G8_UNORM:
    case VK_FORMAT_R8G8_SNORM:
    case VK_FORMAT_R8G8_USCALED:
    case VK_FORMAT_R8G8_SSCALED:
    case VK_FORMAT_R8G8_UINT:
    case VK_FORMAT_R8G8_SINT:
    case VK_FORMAT_R8G8_SRGB:
    case VK_FORMAT_R16_UNORM:
    case VK_FORMAT_R16_SNORM:
    case VK_FORMAT_R16_USCALED:
    case VK_FORMAT_R16_SSCALED:
    case VK_FORMAT_R16_UINT:
    case VK_FORMAT_R16_SINT:
    case VK_FORMAT_R16_SFLOAT:
        return 2;

    // 24-bit formats (treated as 4 bytes for alignment)
    case VK_FORMAT_R8G8B8_UNORM:
    case VK_FORMAT_R8G8B8_SNORM:
    case VK_FORMAT_R8G8B8_USCALED:
    case VK_FORMAT_R8G8B8_SSCALED:
    case VK_FORMAT_R8G8B8_UINT:
    case VK_FORMAT_R8G8B8_SINT:
    case VK_FORMAT_R8G8B8_SRGB:
    case VK_FORMAT_B8G8R8_UNORM:
    case VK_FORMAT_B8G8R8_SNORM:
    case VK_FORMAT_B8G8R8_USCALED:
    case VK_FORMAT_B8G8R8_SSCALED:
    case VK_FORMAT_B8G8R8_UINT:
    case VK_FORMAT_B8G8R8_SINT:
    case VK_FORMAT_B8G8R8_SRGB:
        return 3; // Note: Many APIs will pad to 4 bytes

    // 32-bit formats
    case VK_FORMAT_R8G8B8A8_UNORM:
    case VK_FORMAT_R8G8B8A8_SNORM:
    case VK_FORMAT_R8G8B8A8_USCALED:
    case VK_FORMAT_R8G8B8A8_SSCALED:
    case VK_FORMAT_R8G8B8A8_UINT:
    case VK_FORMAT_R8G8B8A8_SINT:
    case VK_FORMAT_R8G8B8A8_SRGB:
    case VK_FORMAT_B8G8R8A8_UNORM:
    case VK_FORMAT_B8G8R8A8_SNORM:
    case VK_FORMAT_B8G8R8A8_USCALED:
    case VK_FORMAT_B8G8R8A8_SSCALED:
    case VK_FORMAT_B8G8R8A8_UINT:
    case VK_FORMAT_B8G8R8A8_SINT:
    case VK_FORMAT_B8G8R8A8_SRGB:
    case VK_FORMAT_R16G16_UNORM:
    case VK_FORMAT_R16G16_SNORM:
    case VK_FORMAT_R16G16_USCALED:
    case VK_FORMAT_R16G16_SSCALED:
    case VK_FORMAT_R16G16_UINT:
    case VK_FORMAT_R16G16_SINT:
    case VK_FORMAT_R16G16_SFLOAT:
    case VK_FORMAT_R32_UINT:
    case VK_FORMAT_R32_SINT:
    case VK_FORMAT_R32_SFLOAT:
    case VK_FORMAT_A2R10G10B10_UNORM_PACK32:
    case VK_FORMAT_A2R10G10B10_SNORM_PACK32:
    case VK_FORMAT_A2R10G10B10_USCALED_PACK32:
    case VK_FORMAT_A2R10G10B10_SSCALED_PACK32:
    case VK_FORMAT_A2R10G10B10_UINT_PACK32:
    case VK_FORMAT_A2R10G10B10_SINT_PACK32:
        return 4;

    // 48-bit formats
    case VK_FORMAT_R16G16B16_UNORM:
    case VK_FORMAT_R16G16B16_SNORM:
    case VK_FORMAT_R16G16B16_USCALED:
    case VK_FORMAT_R16G16B16_SSCALED:
    case VK_FORMAT_R16G16B16_UINT:
    case VK_FORMAT_R16G16B16_SINT:
    case VK_FORMAT_R16G16B16_SFLOAT:
        return 6;

    // 64-bit formats
    case VK_FORMAT_R16G16B16A16_UNORM:
    case VK_FORMAT_R16G16B16A16_SNORM:
    case VK_FORMAT_R16G16B16A16_USCALED:
    case VK_FORMAT_R16G16B16A16_SSCALED:
    case VK_FORMAT_R16G16B16A16_UINT:
    case VK_FORMAT_R16G16B16A16_SINT:
    case VK_FORMAT_R16G16B16A16_SFLOAT:
    case VK_FORMAT_R32G32_UINT:
    case VK_FORMAT_R32G32_SINT:
    case VK_FORMAT_R32G32_SFLOAT:
    case VK_FORMAT_R64_UINT:
    case VK_FORMAT_R64_SINT:
    case VK_FORMAT_R64_SFLOAT:
        return 8;

    // 96-bit formats
    case VK_FORMAT_R32G32B32_UINT:
    case VK_FORMAT_R32G32B32_SINT:
    case VK_FORMAT_R32G32B32_SFLOAT:
        return 12;

    // 128-bit formats
    case VK_FORMAT_R32G32B32A32_UINT:
    case VK_FORMAT_R32G32B32A32_SINT:
    case VK_FORMAT_R32G32B32A32_SFLOAT:
    case VK_FORMAT_R64G64_UINT:
    case VK_FORMAT_R64G64_SINT:
    case VK_FORMAT_R64G64_SFLOAT:
        return 16;

    // 192-bit formats
    case VK_FORMAT_R64G64B64_UINT:
    case VK_FORMAT_R64G64B64_SINT:
    case VK_FORMAT_R64G64B64_SFLOAT:
        return 24;

    // 256-bit formats
    case VK_FORMAT_R64G64B64A64_UINT:
    case VK_FORMAT_R64G64B64A64_SINT:
    case VK_FORMAT_R64G64B64A64_SFLOAT:
        return 32;

    // Compressed formats return block size
    case VK_FORMAT_BC1_RGB_UNORM_BLOCK:
    case VK_FORMAT_BC1_RGB_SRGB_BLOCK:
    case VK_FORMAT_BC1_RGBA_UNORM_BLOCK:
    case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
    case VK_FORMAT_BC2_UNORM_BLOCK:
    case VK_FORMAT_BC2_SRGB_BLOCK:
    case VK_FORMAT_BC3_UNORM_BLOCK:
    case VK_FORMAT_BC3_SRGB_BLOCK:
    case VK_FORMAT_BC4_UNORM_BLOCK:
    case VK_FORMAT_BC4_SNORM_BLOCK:
    case VK_FORMAT_BC5_UNORM_BLOCK:
    case VK_FORMAT_BC5_SNORM_BLOCK:
    case VK_FORMAT_BC6H_UFLOAT_BLOCK:
    case VK_FORMAT_BC6H_SFLOAT_BLOCK:
    case VK_FORMAT_BC7_UNORM_BLOCK:
    case VK_FORMAT_BC7_SRGB_BLOCK:
        return 8; // Block size for BC formats

    case VK_FORMAT_ETC2_R8G8B8_UNORM_BLOCK:
    case VK_FORMAT_ETC2_R8G8B8_SRGB_BLOCK:
    case VK_FORMAT_ETC2_R8G8B8A1_UNORM_BLOCK:
    case VK_FORMAT_ETC2_R8G8B8A1_SRGB_BLOCK:
    case VK_FORMAT_ETC2_R8G8B8A8_UNORM_BLOCK:
    case VK_FORMAT_ETC2_R8G8B8A8_SRGB_BLOCK:
        return 8; // Block size for ETC2

    case VK_FORMAT_ASTC_4x4_UNORM_BLOCK:
    case VK_FORMAT_ASTC_4x4_SRGB_BLOCK:
        return 16; // ASTC block sizes vary by format

    // Depth/stencil formats
    case VK_FORMAT_D16_UNORM:
        return 2;
    case VK_FORMAT_D32_SFLOAT:
        return 4;
    case VK_FORMAT_S8_UINT:
        return 1;
    case VK_FORMAT_D16_UNORM_S8_UINT:
        return 3; // Typically 24-bit packed
    case VK_FORMAT_D24_UNORM_S8_UINT:
        return 4;
    case VK_FORMAT_D32_SFLOAT_S8_UINT:
        return 5; // 32-bit float + 8-bit stencil

    // Undefined/special cases
    case VK_FORMAT_UNDEFINED:
    default:
        return 0; // Unknown format
    }
}

const char*
sc_vk_format_to_string(VkFormat vkFormat)
{
    switch (vkFormat)
    {
    // 8-bit formats
    case VK_FORMAT_R4G4_UNORM_PACK8:
        return "FormatR4G4UnormPack8";
    case VK_FORMAT_R4G4B4A4_UNORM_PACK16:
        return "FormatR4G4B4A4UnormPack16";
    case VK_FORMAT_B4G4R4A4_UNORM_PACK16:
        return "FormatB4G4R4A4UnormPack16";
    case VK_FORMAT_R5G6B5_UNORM_PACK16:
        return "FormatR5G6B5UnormPack16";
    case VK_FORMAT_B5G6R5_UNORM_PACK16:
        return "FormatB5G6R5UnormPack16";
    case VK_FORMAT_R5G5B5A1_UNORM_PACK16:
        return "FormatR5G5B5A1UnormPack16";
    case VK_FORMAT_B5G5R5A1_UNORM_PACK16:
        return "FormatB5G5R5A1UnormPack16";
    case VK_FORMAT_A1R5G5B5_UNORM_PACK16:
        return "FormatA1R5G5B5UnormPack16";

    case VK_FORMAT_R8_UNORM:
        return "FormatR8Unorm";
    case VK_FORMAT_R8_SNORM:
        return "FormatR8Snorm";
    case VK_FORMAT_R8_USCALED:
        return "FormatR8Uscaled";
    case VK_FORMAT_R8_SSCALED:
        return "FormatR8Sscaled";
    case VK_FORMAT_R8_UINT:
        return "FormatR8Uint";
    case VK_FORMAT_R8_SINT:
        return "FormatR8Sint";
    case VK_FORMAT_R8_SRGB:
        return "FormatR8Srgb";

    // 16-bit formats
    case VK_FORMAT_R8G8_UNORM:
        return "FormatR8G8Unorm";
    case VK_FORMAT_R8G8_SNORM:
        return "FormatR8G8Snorm";
    case VK_FORMAT_R8G8_USCALED:
        return "FormatR8G8Uscaled";
    case VK_FORMAT_R8G8_SSCALED:
        return "FormatR8G8Sscaled";
    case VK_FORMAT_R8G8_UINT:
        return "FormatR8G8Uint";
    case VK_FORMAT_R8G8_SINT:
        return "FormatR8G8Sint";
    case VK_FORMAT_R8G8_SRGB:
        return "FormatR8G8Srgb";

    case VK_FORMAT_R16_UNORM:
        return "FormatR16Unorm";
    case VK_FORMAT_R16_SNORM:
        return "FormatR16Snorm";
    case VK_FORMAT_R16_USCALED:
        return "FormatR16Uscaled";
    case VK_FORMAT_R16_SSCALED:
        return "FormatR16Sscaled";
    case VK_FORMAT_R16_UINT:
        return "FormatR16Uint";
    case VK_FORMAT_R16_SINT:
        return "FormatR16Sint";
    case VK_FORMAT_R16_SFLOAT:
        return "FormatR16Sfloat";

    // 24-bit formats
    case VK_FORMAT_R8G8B8_UNORM:
        return "FormatR8G8B8Unorm";
    case VK_FORMAT_R8G8B8_SNORM:
        return "FormatR8G8B8Snorm";
    case VK_FORMAT_R8G8B8_USCALED:
        return "FormatR8G8B8Uscaled";
    case VK_FORMAT_R8G8B8_SSCALED:
        return "FormatR8G8B8Sscaled";
    case VK_FORMAT_R8G8B8_UINT:
        return "FormatR8G8B8Uint";
    case VK_FORMAT_R8G8B8_SINT:
        return "FormatR8G8B8Sint";
    case VK_FORMAT_R8G8B8_SRGB:
        return "FormatR8G8B8Srgb";

    case VK_FORMAT_B8G8R8_UNORM:
        return "FormatB8G8R8Unorm";
    case VK_FORMAT_B8G8R8_SNORM:
        return "FormatB8G8R8Snorm";
    case VK_FORMAT_B8G8R8_USCALED:
        return "FormatB8G8R8Uscaled";
    case VK_FORMAT_B8G8R8_SSCALED:
        return "FormatB8G8R8Sscaled";
    case VK_FORMAT_B8G8R8_UINT:
        return "FormatB8G8R8Uint";
    case VK_FORMAT_B8G8R8_SINT:
        return "FormatB8G8R8Sint";
    case VK_FORMAT_B8G8R8_SRGB:
        return "FormatB8G8R8Srgb";

    // 32-bit formats
    case VK_FORMAT_R8G8B8A8_UNORM:
        return "FormatR8G8B8A8Unorm";
    case VK_FORMAT_R8G8B8A8_SNORM:
        return "FormatR8G8B8A8Snorm";
    case VK_FORMAT_R8G8B8A8_USCALED:
        return "FormatR8G8B8A8Uscaled";
    case VK_FORMAT_R8G8B8A8_SSCALED:
        return "FormatR8G8B8A8Sscaled";
    case VK_FORMAT_R8G8B8A8_UINT:
        return "FormatR8G8B8A8Uint";
    case VK_FORMAT_R8G8B8A8_SINT:
        return "FormatR8G8B8A8Sint";
    case VK_FORMAT_R8G8B8A8_SRGB:
        return "FormatR8G8B8A8Srgb";

    case VK_FORMAT_B8G8R8A8_UNORM:
        return "FormatB8G8R8A8Unorm";
    case VK_FORMAT_B8G8R8A8_SNORM:
        return "FormatB8G8R8A8Snorm";
    case VK_FORMAT_B8G8R8A8_USCALED:
        return "FormatB8G8R8A8Uscaled";
    case VK_FORMAT_B8G8R8A8_SSCALED:
        return "FormatB8G8R8A8Sscaled";
    case VK_FORMAT_B8G8R8A8_UINT:
        return "FormatB8G8R8A8Uint";
    case VK_FORMAT_B8G8R8A8_SINT:
        return "FormatB8G8R8A8Sint";
    case VK_FORMAT_B8G8R8A8_SRGB:
        return "FormatB8G8R8A8Srgb";

    case VK_FORMAT_A8B8G8R8_UNORM_PACK32:
        return "FormatA8B8G8R8UnormPack32";
    case VK_FORMAT_A8B8G8R8_SNORM_PACK32:
        return "FormatA8B8G8R8SnormPack32";
    case VK_FORMAT_A8B8G8R8_USCALED_PACK32:
        return "FormatA8B8G8R8UscaledPack32";
    case VK_FORMAT_A8B8G8R8_SSCALED_PACK32:
        return "FormatA8B8G8R8SscaledPack32";
    case VK_FORMAT_A8B8G8R8_UINT_PACK32:
        return "FormatA8B8G8R8UintPack32";
    case VK_FORMAT_A8B8G8R8_SINT_PACK32:
        return "FormatA8B8G8R8SintPack32";
    case VK_FORMAT_A8B8G8R8_SRGB_PACK32:
        return "FormatA8B8G8R8SrgbPack32";

    case VK_FORMAT_A2R10G10B10_UNORM_PACK32:
        return "FormatA2R10G10B10UnormPack32";
    case VK_FORMAT_A2R10G10B10_SNORM_PACK32:
        return "FormatA2R10G10B10SnormPack32";
    case VK_FORMAT_A2R10G10B10_USCALED_PACK32:
        return "FormatA2R10G10B10UscaledPack32";
    case VK_FORMAT_A2R10G10B10_SSCALED_PACK32:
        return "FormatA2R10G10B10SscaledPack32";
    case VK_FORMAT_A2R10G10B10_UINT_PACK32:
        return "FormatA2R10G10B10UintPack32";
    case VK_FORMAT_A2R10G10B10_SINT_PACK32:
        return "FormatA2R10G10B10SintPack32";

    case VK_FORMAT_A2B10G10R10_UNORM_PACK32:
        return "FormatA2B10G10R10UnormPack32";
    case VK_FORMAT_A2B10G10R10_SNORM_PACK32:
        return "FormatA2B10G10R10SnormPack32";
    case VK_FORMAT_A2B10G10R10_USCALED_PACK32:
        return "FormatA2B10G10R10UscaledPack32";
    case VK_FORMAT_A2B10G10R10_SSCALED_PACK32:
        return "FormatA2B10G10R10SscaledPack32";
    case VK_FORMAT_A2B10G10R10_UINT_PACK32:
        return "FormatA2B10G10R10UintPack32";
    case VK_FORMAT_A2B10G10R10_SINT_PACK32:
        return "FormatA2B10G10R10SintPack32";

    case VK_FORMAT_R16G16_UNORM:
        return "FormatR16G16Unorm";
    case VK_FORMAT_R16G16_SNORM:
        return "FormatR16G16Snorm";
    case VK_FORMAT_R16G16_USCALED:
        return "FormatR16G16Uscaled";
    case VK_FORMAT_R16G16_SSCALED:
        return "FormatR16G16Sscaled";
    case VK_FORMAT_R16G16_UINT:
        return "FormatR16G16Uint";
    case VK_FORMAT_R16G16_SINT:
        return "FormatR16G16Sint";
    case VK_FORMAT_R16G16_SFLOAT:
        return "FormatR16G16Sfloat";

    case VK_FORMAT_R32_UINT:
        return "FormatR32Uint";
    case VK_FORMAT_R32_SINT:
        return "FormatR32Sint";
    case VK_FORMAT_R32_SFLOAT:
        return "FormatR32Sfloat";

    // 48-bit formats
    case VK_FORMAT_R16G16B16_UNORM:
        return "FormatR16G16B16Unorm";
    case VK_FORMAT_R16G16B16_SNORM:
        return "FormatR16G16B16Snorm";
    case VK_FORMAT_R16G16B16_USCALED:
        return "FormatR16G16B16Uscaled";
    case VK_FORMAT_R16G16B16_SSCALED:
        return "FormatR16G16B16Sscaled";
    case VK_FORMAT_R16G16B16_UINT:
        return "FormatR16G16B16Uint";
    case VK_FORMAT_R16G16B16_SINT:
        return "FormatR16G16B16Sint";
    case VK_FORMAT_R16G16B16_SFLOAT:
        return "FormatR16G16B16Sfloat";

    // 64-bit formats
    case VK_FORMAT_R16G16B16A16_UNORM:
        return "FormatR16G16B16A16Unorm";
    case VK_FORMAT_R16G16B16A16_SNORM:
        return "FormatR16G16B16A16Snorm";
    case VK_FORMAT_R16G16B16A16_USCALED:
        return "FormatR16G16B16A16Uscaled";
    case VK_FORMAT_R16G16B16A16_SSCALED:
        return "FormatR16G16B16A16Sscaled";
    case VK_FORMAT_R16G16B16A16_UINT:
        return "FormatR16G16B16A16Uint";
    case VK_FORMAT_R16G16B16A16_SINT:
        return "FormatR16G16B16A16Sint";
    case VK_FORMAT_R16G16B16A16_SFLOAT:
        return "FormatR16G16B16A16Sfloat";

    case VK_FORMAT_R32G32_UINT:
        return "FormatR32G32Uint";
    case VK_FORMAT_R32G32_SINT:
        return "FormatR32G32Sint";
    case VK_FORMAT_R32G32_SFLOAT:
        return "FormatR32G32Sfloat";

    case VK_FORMAT_R64_UINT:
        return "FormatR64Uint";
    case VK_FORMAT_R64_SINT:
        return "FormatR64Sint";
    case VK_FORMAT_R64_SFLOAT:
        return "FormatR64Sfloat";

    // 96-bit formats
    case VK_FORMAT_R32G32B32_UINT:
        return "FormatR32G32B32Uint";
    case VK_FORMAT_R32G32B32_SINT:
        return "FormatR32G32B32Sint";
    case VK_FORMAT_R32G32B32_SFLOAT:
        return "FormatR32G32B32Sfloat";

    // 128-bit formats
    case VK_FORMAT_R32G32B32A32_UINT:
        return "FormatR32G32B32A32Uint";
    case VK_FORMAT_R32G32B32A32_SINT:
        return "FormatR32G32B32A32Sint";
    case VK_FORMAT_R32G32B32A32_SFLOAT:
        return "FormatR32G32B32A32Sfloat";

    case VK_FORMAT_R64G64_UINT:
        return "FormatR64G64Uint";
    case VK_FORMAT_R64G64_SINT:
        return "FormatR64G64Sint";
    case VK_FORMAT_R64G64_SFLOAT:
        return "FormatR64G64Sfloat";

    // 192-bit formats
    case VK_FORMAT_R64G64B64_UINT:
        return "FormatR64G64B64Uint";
    case VK_FORMAT_R64G64B64_SINT:
        return "FormatR64G64B64Sint";
    case VK_FORMAT_R64G64B64_SFLOAT:
        return "FormatR64G64B64Sfloat";

    // 256-bit formats
    case VK_FORMAT_R64G64B64A64_UINT:
        return "FormatR64G64B64A64Uint";
    case VK_FORMAT_R64G64B64A64_SINT:
        return "FormatR64G64B64A64Sint";
    case VK_FORMAT_R64G64B64A64_SFLOAT:
        return "FormatR64G64B64A64Sfloat";

    // Depth/stencil formats
    case VK_FORMAT_D16_UNORM:
        return "FormatD16Unorm";
    case VK_FORMAT_X8_D24_UNORM_PACK32:
        return "FormatX8D24UnormPack32";
    case VK_FORMAT_D32_SFLOAT:
        return "FormatD32Sfloat";
    case VK_FORMAT_S8_UINT:
        return "FormatS8Uint";
    case VK_FORMAT_D16_UNORM_S8_UINT:
        return "FormatD16UnormS8Uint";
    case VK_FORMAT_D24_UNORM_S8_UINT:
        return "FormatD24UnormS8Uint";
    case VK_FORMAT_D32_SFLOAT_S8_UINT:
        return "FormatD32SfloatS8Uint";

    // BC compressed formats
    case VK_FORMAT_BC1_RGB_UNORM_BLOCK:
        return "FormatBC1RgbUnormBlock";
    case VK_FORMAT_BC1_RGB_SRGB_BLOCK:
        return "FormatBC1RgbSrgbBlock";
    case VK_FORMAT_BC1_RGBA_UNORM_BLOCK:
        return "FormatBC1RgbaUnormBlock";
    case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
        return "FormatBC1RgbaSrgbBlock";
    case VK_FORMAT_BC2_UNORM_BLOCK:
        return "FormatBC2UnormBlock";
    case VK_FORMAT_BC2_SRGB_BLOCK:
        return "FormatBC2SrgbBlock";
    case VK_FORMAT_BC3_UNORM_BLOCK:
        return "FormatBC3UnormBlock";
    case VK_FORMAT_BC3_SRGB_BLOCK:
        return "FormatBC3SrgbBlock";
    case VK_FORMAT_BC4_UNORM_BLOCK:
        return "FormatBC4UnormBlock";
    case VK_FORMAT_BC4_SNORM_BLOCK:
        return "FormatBC4SnormBlock";
    case VK_FORMAT_BC5_UNORM_BLOCK:
        return "FormatBC5UnormBlock";
    case VK_FORMAT_BC5_SNORM_BLOCK:
        return "FormatBC5SnormBlock";
    case VK_FORMAT_BC6H_UFLOAT_BLOCK:
        return "FormatBC6HUfloatBlock";
    case VK_FORMAT_BC6H_SFLOAT_BLOCK:
        return "FormatBC6HSfloatBlock";
    case VK_FORMAT_BC7_UNORM_BLOCK:
        return "FormatBC7UnormBlock";
    case VK_FORMAT_BC7_SRGB_BLOCK:
        return "FormatBC7SrgbBlock";

    // ETC2 compressed formats
    case VK_FORMAT_ETC2_R8G8B8_UNORM_BLOCK:
        return "FormatETC2R8G8B8UnormBlock";
    case VK_FORMAT_ETC2_R8G8B8_SRGB_BLOCK:
        return "FormatETC2R8G8B8SrgbBlock";
    case VK_FORMAT_ETC2_R8G8B8A1_UNORM_BLOCK:
        return "FormatETC2R8G8B8A1UnormBlock";
    case VK_FORMAT_ETC2_R8G8B8A1_SRGB_BLOCK:
        return "FormatETC2R8G8B8A1SrgbBlock";
    case VK_FORMAT_ETC2_R8G8B8A8_UNORM_BLOCK:
        return "FormatETC2R8G8B8A8UnormBlock";
    case VK_FORMAT_ETC2_R8G8B8A8_SRGB_BLOCK:
        return "FormatETC2R8G8B8A8SrgbBlock";

    // ASTC compressed formats
    case VK_FORMAT_ASTC_4x4_UNORM_BLOCK:
        return "FormatASTC4x4UnormBlock";
    case VK_FORMAT_ASTC_4x4_SRGB_BLOCK:
        return "FormatASTC4x4SrgbBlock";

    // Special cases
    case VK_FORMAT_UNDEFINED:
        return "FormatUndefined";

    default:
        return "FormatUnknown";
    }
}

VkShaderStageFlagBits
sc_vk_stage_type_to_native(ScVkStageType type)
{
    VkShaderStageFlagBits flag = 0;
    switch (type)
    {
    case ScVkStageType_Vertex:
        return VK_SHADER_STAGE_VERTEX_BIT;
    case ScVkStageType_Fragment:
        return VK_SHADER_STAGE_FRAGMENT_BIT;
    case ScVkStageType_Tesselation_Control:
        return VK_SHADER_STAGE_TESSELLATION_CONTROL_BIT;
    case ScVkStageType_Tesselation_Evaluation:
        return VK_SHADER_STAGE_TESSELLATION_EVALUATION_BIT;
    default:
        /*
        VK_SHADER_STAGE_GEOMETRY_BIT = 0x00000008,
        VK_SHADER_STAGE_COMPUTE_BIT = 0x00000020,
        VK_SHADER_STAGE_ALL_GRAPHICS = 0x0000001F,
        VK_SHADER_STAGE_ALL = 0x7FFFFFFF,
        VK_SHADER_STAGE_RAYGEN_BIT_KHR = 0x00000100,
        VK_SHADER_STAGE_ANY_HIT_BIT_KHR = 0x00000200,
        VK_SHADER_STAGE_CLOSEST_HIT_BIT_KHR = 0x00000400,
        VK_SHADER_STAGE_MISS_BIT_KHR = 0x00000800,
        VK_SHADER_STAGE_INTERSECTION_BIT_KHR = 0x00001000,
        VK_SHADER_STAGE_CALLABLE_BIT_KHR = 0x00002000,
        VK_SHADER_STAGE_TASK_BIT_EXT = 0x00000040,
        VK_SHADER_STAGE_MESH_BIT_EXT = 0x00000080,
        VK_SHADER_STAGE_SUBPASS_SHADING_BIT_HUAWEI = 0x00004000,
        VK_SHADER_STAGE_CLUSTER_CULLING_BIT_HUAWEI = 0x00080000,
        VK_SHADER_STAGE_RAYGEN_BIT_NV = VK_SHADER_STAGE_RAYGEN_BIT_KHR,
        VK_SHADER_STAGE_ANY_HIT_BIT_NV = VK_SHADER_STAGE_ANY_HIT_BIT_KHR,
        VK_SHADER_STAGE_CLOSEST_HIT_BIT_NV = VK_SHADER_STAGE_CLOSEST_HIT_BIT_KHR,
        VK_SHADER_STAGE_MISS_BIT_NV = VK_SHADER_STAGE_MISS_BIT_KHR,
        VK_SHADER_STAGE_INTERSECTION_BIT_NV = VK_SHADER_STAGE_INTERSECTION_BIT_KHR,
        VK_SHADER_STAGE_CALLABLE_BIT_NV = VK_SHADER_STAGE_CALLABLE_BIT_KHR,
        VK_SHADER_STAGE_TASK_BIT_NV = VK_SHADER_STAGE_TASK_BIT_EXT,
        VK_SHADER_STAGE_MESH_BIT_NV = VK_SHADER_STAGE_MESH_BIT_EXT,
        VK_SHADER_STAGE_FLAG_BITS_MAX_ENUM = 0x7FFFFFFF
        */
        return 0;
    }
}

const char*
sc_vk_stage_type_to_string(ScVkStageType type)
{
    switch (type)
    {
    case ScVkStageType_Vertex:
        return "Stage-Vertex";
    case ScVkStageType_Fragment:
        return "Stage-Fragment";
    default:
        return "Undefined";
    }
}

VkDescriptorType
sc_vk_descriptor_type_to_native(ScVkDescriptorType type)
{
    switch (type)
    {
        // todo: note: mb this VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC
    case ScVkDescriptorType_Uniform:
        return VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    case ScVkDescriptorType_Image:
        return VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    case ScVkDescriptorType_Ssbo:
    {
        return VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    }
    }
    return 0;
}

const char*
sc_vk_descriptor_type_to_string(ScVkDescriptorType type)
{
    switch (type)
    {
    case ScVkDescriptorType_Uniform:
        return "Desc-Uniform";
    case ScVkDescriptorType_Image:
        return "Desc-Image";
    case ScVkDescriptorType_Ssbo:
        return "Desc-Ssbo";
    }
}

const char*
sc_vk_n_descriptor_type_to_string(VkDescriptorType type)
{
    switch (type)
    {
    case VK_DESCRIPTOR_TYPE_SAMPLER:
        return "Sampler";
    case VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER:
        return "CombinedImageSampler";
    case VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE:
        return "SampledImage";
    case VK_DESCRIPTOR_TYPE_STORAGE_IMAGE:
        return "StorageImage";
    case VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER:
        return "UniformTexelBuffer";
    case VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER:
        return "StorageTexelBuffer";
    case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER:
        return "UniformBuffer";
    case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER:
        return "StorageBuffer";
    case VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER_DYNAMIC:
        return "UniformBufferDynamic";
    case VK_DESCRIPTOR_TYPE_STORAGE_BUFFER_DYNAMIC:
        return "StorageBufferDynamic";
    case VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT:
        return "InputAttachment";
    case VK_DESCRIPTOR_TYPE_INLINE_UNIFORM_BLOCK:
        return "InlineUniformBlock";
    case VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR:
        return "AccelerationStructureKHR";
    case VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_NV:
        return "AccelerationStructureNV";
    default:
        return NULL;
    }
}

void
sc_vk_error_ext1(ScVk* pScVk, const char* pMessage, void* pData, i32 line)
{
#define buf_size 1024
    char buf[buf_size] = {};
    snprintf(buf, buf_size, "line: %d %s\n", line, pMessage);
#undef buf_size

    if (pScVk->Messages.OnError)
    {
        pScVk->Messages.OnError(buf, pData);
    }

    sc_log_erro("%s\n", buf);
    sc_assert_break();
}

void
sc_vk_error_ext0(ScVk* pScVk, const char* pMessage, i32 line)
{
    sc_vk_error_ext1(pScVk, pMessage, NULL, line);
}

void
sc_vk_fatal_ext(ScVk* pScVk, const char* pMessage, i32 line)
{
    if (pScVk->Messages.OnError)
    {
#define buf_size 1024
        char buf[buf_size] = {};
        snprintf(buf, buf_size, "line: %d %s\n", line, pMessage);
        pScVk->Messages.OnError(buf, NULL);
#undef buf_size
    }

    sc_guard(0 && "Fatal error occured!\n");
}

void
sc_vk_warning_ext(ScVk* pScVk, const char* pMessage, i32 line)
{
    if (pScVk->Messages.OnWarning)
    {
        pScVk->Messages.OnWarning(pMessage, NULL);
    }

    sc_assert_break();
}

void
sc_vk_pipeline_config_print(ScVk* pScVk, ScVkPipelineConfig cfg)
{
#define pOffset1 "  "
#define pOffset2 pOffset1 pOffset1
#define pOffset3 pOffset1 pOffset1 pOffset1
#define pOffset4 pOffset1 pOffset1 pOffset1 pOffset1

    ScVkRenderPass* pRenderPass = sc_vk_get_render_pass(pScVk, cfg.RenderPassId);

    printf("[ScVkPipelineConfig]\n");
    printf("%sRender Pass - %p - %s\n", pOffset1, pRenderPass->Handle, sc_vk_render_pass_type_to_string(pRenderPass->Type));
    printf("%sPolygon Mode: %s\n", pOffset1, sc_vk_polygon_mode_to_string(cfg.PolygonMode));
    printf("%sStride: %lld\n", pOffset1, cfg.Stride);
    printf("%sVerticesCount: %lld\n", pOffset1, cfg.VerticesCount);
    printf("%sIndicesCount: %lld\n", pOffset1, cfg.IndicesCount);

    for (i32 s = 0; s < cfg.StagesCount; ++s)
    {
        ScVkStageConfig stage = cfg.aStages[s];
        printf("%s[%s]\n", pOffset2, sc_vk_stage_type_to_string(stage.Type));
        printf("%sShader Path - %s\n", pOffset3, stage.pShaderPath);
        printf("%sPipe index - %d\n", pOffset3, stage.PipelineIndex);
        printf("%sDescriptor Count - %d\n", pOffset3, stage.DescriptorsCount);

        if (stage.aDescriptors != NULL)
        {
            for (i32 d = 0; d < stage.DescriptorsCount; ++d)
            {
                ScVkDescriptorConfig descCfg = stage.aDescriptors[d];

                printf("%s[Descriptor %d]\n", pOffset3, d);

                printf("%sType - %s\n", pOffset4, sc_vk_descriptor_type_to_string(descCfg.Type));
                printf("%sName - %s\n", pOffset4, descCfg.pName);
                printf("%sCount - %lld\n", pOffset4, descCfg.Count);
                printf("%sSize - %lld\n", pOffset4, descCfg.Size);
            }
        }
        else
        {
            printf(ScTerminalRed("%sstage.aDescriptors == null") "\n", pOffset3);
        }
    }

    printf("%sAttributes Count - %d\n", pOffset1, cfg.AttributesCount);
    for (i32 a = 0; a < cfg.AttributesCount; ++a)
    {
        ScVkAttribute attr = cfg.aAttributes[a];
        printf("%s[%d Attribute]\n", pOffset2, a);
        printf("%spName - %s\n", pOffset3, sc_vk_format_to_string(attr.Format));
        printf("%sOffset - %d\n", pOffset3, attr.Offset);
    }

    printf("\n");

#undef pOffset0
#undef pOffset1
#undef pOffset2
#undef pOffset3
}

const char*
sc_vk_sample_count_to_string(VkSampleCountFlagBits sampleCount)
{
    switch (sampleCount)
    {
    case VK_SAMPLE_COUNT_1_BIT:
    {
        return "VK_SAMPLE_COUNT_1_BIT";
    }
    case VK_SAMPLE_COUNT_2_BIT:
    {
        return "VK_SAMPLE_COUNT_2_BIT";
    }
    case VK_SAMPLE_COUNT_4_BIT:
    {
        return "VK_SAMPLE_COUNT_4_BIT";
    }
    case VK_SAMPLE_COUNT_8_BIT:
    {
        return "VK_SAMPLE_COUNT_8_BIT";
    }
    case VK_SAMPLE_COUNT_16_BIT:
    {
        return "VK_SAMPLE_COUNT_16_BIT";
    }
    case VK_SAMPLE_COUNT_32_BIT:
    {
        return "VK_SAMPLE_COUNT_32_BIT";
    }
    case VK_SAMPLE_COUNT_64_BIT:
    {
        return "VK_SAMPLE_COUNT_64_BIT";
    }
    case VK_SAMPLE_COUNT_FLAG_BITS_MAX_ENUM:
    {
        return "VK_SAMPLE_COUNT_FLAG_BITS_MAX_ENUM";
    }

    default:
    {
        return "Unknown value";
    }
    }
}

const char*
sc_vk_polygon_mode_to_string(VkPolygonMode vkPolygonMode)
{
    switch (vkPolygonMode)
    {
    case VK_POLYGON_MODE_FILL:
        return "PolygonMode_Fill";
    case VK_POLYGON_MODE_LINE:
        return "PolygonMode_Line";
    case VK_POLYGON_MODE_POINT:
        return "PolygonMode_Point";
    case VK_POLYGON_MODE_FILL_RECTANGLE_NV:
        return "PolygonMode_FillRectangleNv";
    case VK_POLYGON_MODE_MAX_ENUM:
        return "PolygonMode_MaxEnum";
    default:
        return "Undefined";
    }
}

VkPrimitiveTopology
sc_vk_topology_type_to_vk(ScVkTopologyType type)
{
    switch (type)
    {
    case ScVkTopologyType_PointList:
        return VK_PRIMITIVE_TOPOLOGY_POINT_LIST;
    case ScVkTopologyType_LineList:
        return VK_PRIMITIVE_TOPOLOGY_LINE_LIST;
    case ScVkTopologyType_LineStrip:
        return VK_PRIMITIVE_TOPOLOGY_LINE_STRIP;
    case ScVkTopologyType_TriangleList:
        return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    case ScVkTopologyType_TriangleStrip:
        return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP;
    case ScVkTopologyType_TriangleFan:
        return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_FAN;
    case ScVkTopologyType_LineListWithAdjacency:
        return VK_PRIMITIVE_TOPOLOGY_LINE_LIST_WITH_ADJACENCY;
    case ScVkTopologyType_LineStripWithAdjacency:
        return VK_PRIMITIVE_TOPOLOGY_LINE_STRIP_WITH_ADJACENCY;
    case ScVkTopologyType_TriangleListWithAdjacency:
        return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST_WITH_ADJACENCY;
    case ScVkTopologyType_TriangleStripWithAdjacency:
        return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP_WITH_ADJACENCY;
    case ScVkTopologyType_PatchList:
        return VK_PRIMITIVE_TOPOLOGY_PATCH_LIST;
    default:
        sc_assert_break();
        // Возвращаем значение по умолчанию или можно добавить assert
        return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    }
}
