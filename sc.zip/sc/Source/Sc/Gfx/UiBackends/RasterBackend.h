/*
  DOCS: RasterBackend - бэкенд ui (ScUiBackendRender из Gfx/Ui.h)
  поверх программного рендерера ScRaster (Gfx/Raster.h). Растер
  принадлежит бэкенду, окно забирает готовый кадр через
  sc_raster_backend_get_raster() + sc_raster_swap().
*/
#ifndef SC_RASTER_BACKEND_H
#define SC_RASTER_BACKEND_H

#include "../Raster.h"
#include "../Ui.h"
#include "Sc/Types.h"

void sc_raster_backend_new();
void sc_raster_backend_update(ScUiBackendState state);
void sc_raster_backend_render();
ScUiInput* sc_raster_backend_get_input();

/* DOCS: Растер бэкенда (для blit-а готового кадра в окно). */
ScRaster* sc_raster_backend_get_raster();

/*
  DOCS: Заливает текстуру в бэкенд: ключ - имя, значение - сырые
  пиксели (width*height*channel байт, pData принадлежит вызывающему).
  Возвращает стабильный id текстуры (1, 2, ...), ScInvalidId при
  невалидных аргументах. Повторная заливка того же имени возвращает
  id уже залитой записи (pData/размеры НЕ обновляются).
*/
i64 sc_raster_backend_upload_texture(char* pTextureName, void* pData, u32 width, u32 height, u8 channel);

/* DOCS: Освобождает буферы растера (sc_raster_free). */
void sc_raster_backend_free();

#endif // SC_RASTER_BACKEND_H
