/*
  DOCS: RasterBackend - бэкенд ui (ScUiBackendRender из Gfx/Ui.h)
  поверх программного рендерера ScRaster (Gfx/Raster.h). Растер
  принадлежит бэкенду, окно забирает готовый кадр через
  sc_raster_backend_get_raster() + sc_raster_swap().
*/
#ifndef SC_RASTER_BACKEND_H
#define SC_RASTER_BACKEND_H

#include "../Raster.h"
#include "../Ui.h"
#include "Sc/Text/Font.h"
#include "Sc/Types.h"

/*
  DOCS: Запись текстуры в хранилище бэкенда. Id - стабильный
  индекс (0-based), pData - сырые пиксели width * height * channel
  байт (строки подряд). Память pData принадлежит вызывающему.
*/
typedef struct
{
    i64 Id;
    void* pData;
    u32 Width;
    u32 Height;
    u8 Channels;
} ScRasterImage;

void sc_raster_backend_new();
void sc_raster_backend_update(ScUiBackendState state);
void sc_raster_backend_render();
ScUiInput* sc_raster_backend_get_input();

/* DOCS: Растер бэкенда (для blit-а готового кадра в окно). */
ScRaster* sc_raster_backend_get_raster();

/*
  DOCS: Регистрирует текстуру по имени и возвращает её id.
  Повторная заливка того же имени возвращает уже выданный id
  (pData/размеры не обновляются). ScInvalidId - ошибка.
*/
i64 sc_raster_backend_load_texture(char* pTextureName, void* pData, u32 width, u32 height, u8 channel);

/* DOCS: Данные текстуры по id; NULL, если id невалиден. */
ScRasterImage* sc_raster_backend_get_texture_by_id(i64 textureId);

/* DOCS: Освобождает запись текстуры (pData не освобождается). */
void sc_raster_backend_unload_texture(i64 textureId);

/*
  DOCS: Загружает шрифт из файла и возвращает его id.
  Ключ регистрации - "путь#размер", поэтому один и тот же файл
  с разными размерами даёт разные шрифты. ScInvalidId - ошибка.
  NOTE: текст Ui (ScUiBackendRender.DrawText) берёт первый загруженный
  шрифт подходящего размера, поэтому до отрисовки нужно загрузить
  хотя бы один шрифт.
*/
i64 sc_raster_backend_load_font(char* pFontPath, i32 fontSize);

/*
  DOCS: То же, что sc_raster_backend_load_font, но с явным диапазоном
  Unicode-кодов для атласа (например, 32..0x45F - ASCII + кириллица).
  Нужно для языков вне базовой латиницы: DrawText выбирает шрифт только
  по размеру, поэтому диапазон задаётся при загрузке, а не при отрисовке.
  NOTE: ключ регистрации остаётся "путь#размер" - повторная загрузка
  того же файла с тем же размером вернёт уже существующий шрифт
  (первый загруженный диапазон и побеждает).
*/
i64 sc_raster_backend_load_font_ext(char* pFontPath, i32 fontSize, i32 rangeMin, i32 rangeMax);

/* DOCS: Данные шрифта по id; NULL, если id невалиден. */
ScFont* sc_raster_backend_get_font_by_id(i64 fontId);

/* DOCS: Совместимость со старым именем; делает то же, что get_font_by_id. */
void* sc_raster_backend_load_font_by_id(i64 fontId);

/* DOCS: Освобождает шрифт (bitmap + таблицу глифов). */
void sc_raster_backend_unload_font(i64 fontId);

/* DOCS: Освобождает все ресурсы бэкенда. */
void sc_raster_backend_free();

#endif // SC_RASTER_BACKEND_H
