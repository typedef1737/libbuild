/*
  DOCS: RasterBackend - бэкенд ui (ScUiBackendRender из Gfx/Ui.h)
  поверх программного рендерера ScRaster (Gfx/Raster.h). Растер
  принадлежит бэкенду, окно забирает готовый кадр через
  sc_raster_backend_get_raster() + sc_raster_swap().
*/
#ifndef SC_RASTER_BACKEND_H
#define SC_RASTER_BACKEND_H

#include "../Raster.h"
#include "../Ui.h"

void sc_raster_backend_new();
void sc_raster_backend_update(ScUiBackendState state);
void sc_raster_backend_render();
ScUiInput* sc_raster_backend_get_input();

/* DOCS: Растер бэкенда (для blit-а готового кадра в окно). */
ScRaster* sc_raster_backend_get_raster();

/* DOCS: Освобождает буферы растера (sc_raster_free). */
void sc_raster_backend_free();

#endif // SC_RASTER_BACKEND_H
