/*
  DOCS: RasterBackend - реализация ScUiBackendRender (Gfx/Ui.h)
  поверх программного рендерера ScRaster (Gfx/Raster.h).

  Ui и растер используют одну систему координат: origin - левый
  НИЖНИЙ угол, Y-вверх (position.Y - верх виджета, см.
  sc_ui_is_hovered/текст). Бэкенду остаётся пересчитать верх
  прямоугольника в его низ (top - height) и конвертировать цвет
  v4 RGBA (0..1) -> 0xAARRGGBB. Z (z-order) игнорируем - рисуем в
  порядке вызова (Ui обходит виджеты в порядке отрисовки).

  Растер принадлежит бэкенду: оба буфера аллоцируются сразу на
  MaxSize, sc_raster_backend_update() подгоняет размеры под
  DisplaySize окна без реаллокаций. Забрать готовый кадр для
  вывода: sc_raster_backend_get_raster() + sc_raster_swap().

  Ассеты (текстуры/шрифты) хранятся по той же схеме, что и в
  MrqlAssety:
    - aImages / aFonts - массивы записей, id = индекс в массиве;
    - aRemovedIds - свободные id, которые переиспользуются;
    - hRegistrationTable - ключ (имя/путь) -> id;
    - данные по id отдаются только после проверки границ и IsAlive.
*/
#include "RasterBackend.h"
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>
#include <string.h>

/* DOCS: Стартовый размер буферов и запас под resize окна. */
#define ScRasterBackendStartWidth 800
#define ScRasterBackendStartHeight 600
#define ScRasterBackendMaxWidth 1920
#define ScRasterBackendMaxHeight 1080

/* DOCS: Запасной размер шрифта: Ui иногда зовёт GetTextMetrics с 0. */
#define ScRasterBackendDefaultFontSize 16

/* DOCS: Диапазон глифов по умолчанию для шрифтов бэкенда. */
#define ScRasterBackendFontRangeMin 32
#define ScRasterBackendFontRangeMax 126

/*     #####################################
  DOCS ##           Asset storage         ##
       #####################################*/

/*
  DOCS: Внутренняя запись текстуры. Публичная часть (ScRasterImage)
  отдаётся наружу через sc_raster_backend_get_texture_by_id(),
  pKey/IsAlive - служебные поля.
*/
typedef struct
{
    ScRasterImage Image;
    char* pKey;
    i32 IsAlive;
} ScRasterBackendImageEntry;

/*
  DOCS: Внутренняя запись шрифта: сам ScFont + ключ регистрации
  ("путь#размер") и флаг жизни слота.
*/
typedef struct
{
    ScFont Font;
    char* pKey;
    i32 IsAlive;
} ScRasterBackendFontEntry;

/*
  DOCS: Запись хеш-таблицы: Key - имя/путь (char*, ключ dict-а),
  Value - id ассета. Тип нужен sc_dict_s_*-макросам.
*/
typedef struct
{
    char* Key;
    i64 Value;
} ScRasterBackendImageRecord;

typedef struct
{
    char* Key;
    i64 Value;
} ScRasterBackendFontRecord;

typedef struct
{
    ScRasterBackendImageEntry* aImages;
    i64* aRemovedIds;
    ScRasterBackendImageRecord* hRegistrationTable;
} ScRasterBackendImageStorage;

typedef struct
{
    ScRasterBackendFontEntry* aFonts;
    i64* aRemovedIds;
    ScRasterBackendFontRecord* hRegistrationTable;
} ScRasterBackendFontStorage;

typedef struct
{
    ScRaster Raster;
    ScRasterBackendImageStorage Image;
    ScRasterBackendFontStorage Font;
} ScRasterBackendGlobal;

static ScRasterBackendGlobal g = {};

/*     #####################################
  DOCS ##              Utils              ##
       #####################################*/

// DOCS: v4 RGBA (0..1) -> u32-пиксель растера 0xAARRGGBB.
// В памяти little-endian это байты B,G,R,A - формат xcb_put_image
// (Z_PIXMAP, red_mask 0xFF0000) и 32bpp BI_RGB DIB у GDI.
static u32
sc_raster_backend_color_to_u32(v4 color)
{
    u32 a = f32_to_byte(color.A);
    u32 r = f32_to_byte(color.R);
    u32 g = f32_to_byte(color.G);
    u32 b = f32_to_byte(color.B);
    return ScColor_ARGB(a, r, g, b);
}

/*
  DOCS: Ui-координаты и растр - оба Y-вверх (origin - левый НИЖНИЙ
  угол, position.Y - верх виджета: см. sc_ui_is_hovered - мышь в
  [pos.Y - height, pos.Y]). Для заливки нужен низ виджета:
  bottom = top - height. X не конвертируется: он совпадает.
*/
static i32
sc_raster_backend_rect_bottom(f32 top, f32 height)
{
    return to_i32(top - height);
}

/*
  DOCS: Выдаёт свободный id: сначала из aRemovedIds, иначе - новый
  индекс в конце массива. Логика как mrql_assety_get_id.
*/
static i64
sc_raster_backend_get_id(i64* aRemovedIds, void* aItems)
{
    if (sc_list_count(aRemovedIds) > 0)
        return sc_list_pop(aRemovedIds);

    return sc_list_count(aItems);
}

/*
  DOCS: Кладёт запись в слот id. Если id == count - это новый слот
  (append), иначе переиспользуем ранее удалённый слот.
*/
static i32
sc_raster_backend_store_image(i64 id, ScRasterBackendImageEntry entry)
{
    i64 count = sc_list_count(g.Image.aImages);
    if (id == count)
    {
        g.Image.aImages = sc_list_add(g.Image.aImages, entry);
        return 1;
    }

    if (id >= 0 && id < count)
    {
        g.Image.aImages[id] = entry;
        return 1;
    }

    return 0;
}

static i32
sc_raster_backend_store_font(i64 id, ScRasterBackendFontEntry entry)
{
    i64 count = sc_list_count(g.Font.aFonts);
    if (id == count)
    {
        g.Font.aFonts = sc_list_add(g.Font.aFonts, entry);
        return 1;
    }

    if (id >= 0 && id < count)
    {
        g.Font.aFonts[id] = entry;
        return 1;
    }

    return 0;
}

static ScRasterBackendImageEntry*
sc_raster_backend_get_image_entry(i64 textureId)
{
    i64 count = sc_list_count(g.Image.aImages);
    if (textureId < 0 || textureId >= count)
        return ScNull;

    ScRasterBackendImageEntry* pEntry = &g.Image.aImages[textureId];
    return pEntry->IsAlive ? pEntry : ScNull;
}

static ScRasterBackendFontEntry*
sc_raster_backend_get_font_entry(i64 fontId)
{
    i64 count = sc_list_count(g.Font.aFonts);
    if (fontId < 0 || fontId >= count)
        return ScNull;

    ScRasterBackendFontEntry* pEntry = &g.Font.aFonts[fontId];
    return pEntry->IsAlive ? pEntry : ScNull;
}

static char*
sc_raster_backend_font_key_new(char* pFontPath, i32 fontSize)
{
    i64 pathLength = sc_string_get_length(pFontPath);
    i64 bufferSize = pathLength + 32;
    char* pBuffer = sc_memory_allocate(bufferSize);
    if (pBuffer == ScNull)
        return ScNull;

    snprintf(pBuffer, (size_t)bufferSize, "%s#%d", pFontPath, fontSize);

    char* pKey = sc_string_new(pBuffer);
    sc_memory_free(pBuffer);
    return pKey;
}

/*
  DOCS: Ui не передаёт путь шрифта в DrawText (только размер), поэтому
  бэкенд ищет уже загруженный шрифт (sc_raster_backend_load_font):
  сначала точное совпадение FontSize, потом первый живой. NULL -
  шрифтов нет, текст пропускается.
*/
static ScFont*
sc_raster_backend_find_font_by_size(i32 fontSize)
{
    i64 count = sc_list_count(g.Font.aFonts);

    for (i64 i = 0; i < count; ++i)
    {
        ScRasterBackendFontEntry* pEntry = &g.Font.aFonts[i];
        if (pEntry->IsAlive && pEntry->Font.FontSize == fontSize)
            return &pEntry->Font;
    }

    for (i64 i = 0; i < count; ++i)
    {
        ScRasterBackendFontEntry* pEntry = &g.Font.aFonts[i];
        if (pEntry->IsAlive)
            return &pEntry->Font;
    }

    return ScNull;
}

/*
  DOCS: Метрики тем же обходом, что и sc_raster_draw_text: ширина
  строки - сумма Xadvance (пробел - из метрик шрифта), высота - по
  фактическим глифам относительно baseline, '\n' добавляет строку.
  Символы, которых нет в шрифте, пропускаются (sc_font_get_metrics на
  них ругается и уходит в sc_guard), поэтому функция безопасна для
  любого UTF-8.
*/
static v2
sc_raster_backend_font_metrics(ScFont* pFont, char* pText)
{
    f32 lineWidth = 0;
    f32 maxWidth = 0;
    f32 top = 0;    /* максимальный подъём над baseline */
    f32 bottom = 0; /* максимальный спуск под baseline */
    i32 linesCount = 1;

    char* pIter = pText;
    while (*pIter != '\0')
    {
        i32 bytesCount = 0;
        u32 codepoint = sc_utf8_decode(pIter, &bytesCount);
        if (bytesCount <= 0)
            break;

        if (codepoint == (u32)'\n')
        {
            maxWidth = ScMax(maxWidth, lineWidth);
            lineWidth = 0;
            ++linesCount;
        }
        else if (codepoint == (u32)' ')
        {
            lineWidth += sc_font_get_space_metrics(*pFont).X;
        }
        else if ((i32)codepoint >= pFont->RangeMin && (i32)codepoint <= pFont->RangeMax
            && sc_dict_i_contains(pFont->hCharTable, (i32)codepoint))
        {
            ScFontChar fontChar = sc_dict_get_current(pFont->hCharTable);
            f32 glyphHeight = to_f32((i32)fontChar.Y1 - (i32)fontChar.Y0);

            lineWidth += fontChar.Xadvance;
            top = ScMax(top, -fontChar.Yoff);
            bottom = ScMax(bottom, -(fontChar.Yoff + glyphHeight));
        }

        pIter += bytesCount;
    }

    maxWidth = ScMax(maxWidth, lineWidth);

    f32 lineHeight = to_f32(pFont->FontSize > 0 ? pFont->FontSize : 1);
    f32 height = top + bottom + lineHeight * (f32)(linesCount - 1);

    return v2_new(maxWidth, height);
}

/*     #####################################
  DOCS ##        UiBackend Render         ##
       #####################################*/

static void
_sc_raster_backend_draw_rect(v3 position, v2 size, v4 color)
{
    i32 x = to_i32(position.X);
    i32 y = sc_raster_backend_rect_bottom(position.Y, size.Height);
    u32 rasterColor = sc_raster_backend_color_to_u32(color);

    /* клиппинг внутри sc_raster_fill_rect */
    sc_raster_fill_rect(&g.Raster, x, y, to_i32(size.Width), to_i32(size.Height), rasterColor);
}

static void
_sc_raster_backend_draw_empty_rect(v3 position, v2 size, real thickness, v4 color)
{
    i32 x = to_i32(position.X);
    i32 width = to_i32(size.Width);
    i32 height = to_i32(size.Height);
    i32 y = sc_raster_backend_rect_bottom(position.Y, size.Height);
    i32 t = ScMax(to_i32(thickness), 1);
    u32 rasterColor = sc_raster_backend_color_to_u32(color);

    /* рамка из 4 заливок: клиппинг внутри sc_raster_fill_rect.
       y - низ виджета, y + height - верх (растр Y-вверх). */
    sc_raster_fill_rect(&g.Raster, x, y, width, t, rasterColor);              /* низ  */
    sc_raster_fill_rect(&g.Raster, x, y + height - t, width, t, rasterColor); /* верх */
    sc_raster_fill_rect(&g.Raster, x, y, t, height, rasterColor);             /* лево */
    sc_raster_fill_rect(&g.Raster, x + width - t, y, t, height, rasterColor); /* право */
}

static void
_sc_raster_backend_draw_image(v3 position, v2 size, v4 color, i64 textureId)
{
    ScRasterImage* pImage = sc_raster_backend_get_texture_by_id(textureId);
    if (pImage == ScNull || pImage->pData == ScNull)
        return;

    // todo: impl (blit ScRasterImage в g.Raster)
}

static void
_sc_raster_backend_draw_image_atlas_item(v3 position, v2 size, v4 color, i64 textureId, i32 index)
{
    // todo: impl (нужны атласы: Image/* + менеджер)
}

static void
_sc_raster_backend_draw_text(char* pText, i32 fontSize, v3 position, v4 color)
{
    if (pText == ScNull)
        return;

    /* DOCS: шрифт должен быть загружен приложением (load_font) */
    ScFont* pFont = sc_raster_backend_find_font_by_size(fontSize);
    if (pFont == ScNull)
        return;

    /*
      DOCS: Ui отдаёт position.Y уже за вычетом высоты строки
      (см. Ui.c: pos.Y -= metrics.Height), т.е. базовую линию текста -
      как и в референсе (Rendy/2d.c draw_text_ext_2). Поэтому position.Y
      передаётся в растеризатор как есть.
    */
    u32 rasterColor = sc_raster_backend_color_to_u32(color);
    sc_raster_draw_text(
        &g.Raster,
        pFont,
        to_i32(position.X),
        to_i32(position.Y),
        rasterColor,
        pText);
}

static void
_sc_raster_backend_set_viewport(i32 x0, i32 y0, i32 width, i32 height)
{
    // todo: impl (клип-регион для scrollable-панелей)
}

// note: если шрифт нужного размера загружен (sc_raster_backend_load_font),
// метрики считаются по атласу тем же обходом, что и sc_raster_draw_text;
// иначе - грубая оценка моноширинной сеткой fontSize * 0.5 на символ.
static v2
_sc_raster_backend_get_text_metrics(char* pText, i32 fontSize, char* pFontPath)
{
    if (pText == ScNull)
        return v2_0();

    if (fontSize <= 0)
        fontSize = ScRasterBackendDefaultFontSize;

    ScFont* pFont = ScNull;

    /* DOCS: Ui иногда знает путь шрифта (pFontPath) - ищем по "путь#размер" */
    if (pFontPath != ScNull)
    {
        char* pKey = sc_raster_backend_font_key_new(pFontPath, fontSize);
        if (pKey != ScNull)
        {
            if (sc_dict_s_contains(g.Font.hRegistrationTable, pKey))
            {
                i64 ind = sc_dict_index(g.Font.hRegistrationTable);
                pFont = sc_raster_backend_get_font_by_id(g.Font.hRegistrationTable[ind].Value);
            }
            sc_string_destroy(pKey);
        }
    }

    if (pFont == ScNull)
        pFont = sc_raster_backend_find_font_by_size(fontSize);

    if (pFont != ScNull)
        return sc_raster_backend_font_metrics(pFont, pText);

    i64 charsCount = sc_utf8_length(pText);
    f32 charWidth = fontSize * 0.5f;
    return v2_new(charWidth * (f32)charsCount, (f32)fontSize);
}

/*     #####################################
  DOCS ##          Raster Backend         ##
       #####################################*/

void
sc_raster_backend_new()
{
    /*
      DOCS: Растер бэкенда: оба буфера сразу на MaxSize - resize при
      sc_raster_backend_update() не делает реаллокаций.
    */
    ScResult rasterResult = sc_raster_init(
        &g.Raster,
        ScRasterBackendStartWidth,
        ScRasterBackendStartHeight,
        ScRasterBackendMaxWidth,
        ScRasterBackendMaxHeight);
    if (rasterResult != ScResult_Success)
    {
        sc_log_erro("sc_raster_backend_new: sc_raster_init failed!\n");
        return;
    }

    ScUiBackendRender renderCfg = {
        .DrawRect = _sc_raster_backend_draw_rect,
        .DrawEmptyRect = _sc_raster_backend_draw_empty_rect,
        .DrawImage = _sc_raster_backend_draw_image,
        .DrawImageAtlasItem = _sc_raster_backend_draw_image_atlas_item,
        .DrawText = _sc_raster_backend_draw_text,
        .SetViewport = _sc_raster_backend_set_viewport,
        .GetTextMetrics = _sc_raster_backend_get_text_metrics,
    };

    sc_ui_backend_new((ScUiBackendConfig) { .Render = renderCfg });
}

void
sc_raster_backend_update(ScUiBackendState state)
{
    /*
      DOCS: DisplaySize = размер окна: подгоняем буферы растера
      (память уже на MaxSize, меняются только поля) и прокидываем
      state в ui.
    */
    i32 width = to_i32(state.DisplaySize.Width);
    i32 height = to_i32(state.DisplaySize.Height);
    if (width > 0 && height > 0)
        sc_raster_resize(&g.Raster, width, height);

    sc_ui_backend_update(state);
}

void
sc_raster_backend_render()
{
    sc_ui_backend_render();
}

ScUiInput*
sc_raster_backend_get_input()
{
    return sc_ui_backend_get_input();
}

/*     #####################################
  DOCS ##           Texture API           ##
       #####################################*/

static i64
sc_raster_backend_load_image_by_data(char* pName, void* pData, u32 width, u32 height, u8 channel)
{
    i64 id = sc_raster_backend_get_id(g.Image.aRemovedIds, g.Image.aImages);
    char* pKey = sc_string_new(pName);
    if (pKey == ScNull)
        return ScInvalidId;

    ScRasterBackendImageEntry entry = {
        .Image = {
            .Id = id,
            .pData = pData,
            .Width = width,
            .Height = height,
            .Channels = channel,
        },
        .pKey = pKey,
        .IsAlive = 1,
    };

    if (!sc_raster_backend_store_image(id, entry))
    {
        sc_string_destroy(pKey);
        return ScInvalidId;
    }

    sc_dict_s_add(g.Image.hRegistrationTable, pKey, id);
    return id;
}

i64
sc_raster_backend_load_texture(char* pTextureName, void* pData, u32 width, u32 height, u8 channel)
{
    if (pTextureName == ScNull || pData == ScNull || width == 0 || height == 0
        || channel < 1 || channel > 4)
    {
        sc_log_erro("sc_raster_backend_load_texture: invalid args (name=%p data=%p %ux%u ch=%d)\n",
            pTextureName,
            pData,
            width,
            height,
            channel);
        return ScInvalidId;
    }

    if (sc_dict_s_contains(g.Image.hRegistrationTable, pTextureName))
    {
        i64 ind = sc_dict_index(g.Image.hRegistrationTable);
        i64 id = g.Image.hRegistrationTable[ind].Value;
        if (sc_raster_backend_get_image_entry(id) != ScNull)
            return id;
    }

    return sc_raster_backend_load_image_by_data(pTextureName, pData, width, height, channel);
}

ScRasterImage*
sc_raster_backend_get_texture_by_id(i64 textureId)
{
    ScRasterBackendImageEntry* pEntry = sc_raster_backend_get_image_entry(textureId);
    return pEntry != ScNull ? &pEntry->Image : ScNull;
}

void
sc_raster_backend_unload_texture(i64 textureId)
{
    ScRasterBackendImageEntry* pEntry = sc_raster_backend_get_image_entry(textureId);
    if (pEntry == ScNull)
        return;

    if (pEntry->pKey != ScNull)
    {
        sc_dict_s_remove(g.Image.hRegistrationTable, pEntry->pKey);
        sc_string_destroy(pEntry->pKey);
        pEntry->pKey = ScNull;
    }

    /* pData принадлежит вызывающему - только забываем запись */
    pEntry->Image.pData = ScNull;
    pEntry->Image.Width = 0;
    pEntry->Image.Height = 0;
    pEntry->Image.Channels = 0;
    pEntry->IsAlive = 0;

    if (sc_list_index_of(g.Image.aRemovedIds, item == textureId) == -1)
        sc_list_add(g.Image.aRemovedIds, textureId);
}

/*     #####################################
  DOCS ##            Font API             ##
       #####################################*/

i64
sc_raster_backend_load_font(char* pFontPath, i32 fontSize)
{
    return sc_raster_backend_load_font_ext(
        pFontPath,
        fontSize,
        ScRasterBackendFontRangeMin,
        ScRasterBackendFontRangeMax);
}

i64
sc_raster_backend_load_font_ext(char* pFontPath, i32 fontSize, i32 rangeMin, i32 rangeMax)
{
    if (pFontPath == ScNull || fontSize <= 0 || rangeMin < 0 || rangeMax < rangeMin)
        return ScInvalidId;

    char* pKey = sc_raster_backend_font_key_new(pFontPath, fontSize);
    if (pKey == ScNull)
        return ScInvalidId;

    if (sc_dict_s_contains(g.Font.hRegistrationTable, pKey))
    {
        i64 ind = sc_dict_index(g.Font.hRegistrationTable);
        i64 id = g.Font.hRegistrationTable[ind].Value;
        sc_string_destroy(pKey);
        return id;
    }

    ScFont font = sc_font_new((ScFontConfig) {
        .pPath = pFontPath,
        .FontSize = fontSize,
        .RangeMin = rangeMin,
        .RangeMax = rangeMax,
    });
    if (font.pBitmap == ScNull)
    {
        sc_string_destroy(pKey);
        return ScInvalidId;
    }

    i64 id = sc_raster_backend_get_id(g.Font.aRemovedIds, g.Font.aFonts);
    ScRasterBackendFontEntry entry = {
        .Font = font,
        .pKey = pKey,
        .IsAlive = 1,
    };

    if (!sc_raster_backend_store_font(id, entry))
    {
        sc_font_destroy(font);
        sc_string_destroy(pKey);
        return ScInvalidId;
    }

    sc_dict_s_add(g.Font.hRegistrationTable, pKey, id);
    return id;
}

ScFont*
sc_raster_backend_get_font_by_id(i64 fontId)
{
    ScRasterBackendFontEntry* pEntry = sc_raster_backend_get_font_entry(fontId);
    return pEntry != ScNull ? &pEntry->Font : ScNull;
}

void*
sc_raster_backend_load_font_by_id(i64 fontId)
{
    return (void*)sc_raster_backend_get_font_by_id(fontId);
}

void
sc_raster_backend_unload_font(i64 fontId)
{
    ScRasterBackendFontEntry* pEntry = sc_raster_backend_get_font_entry(fontId);
    if (pEntry == ScNull)
        return;

    if (pEntry->pKey != ScNull)
    {
        sc_dict_s_remove(g.Font.hRegistrationTable, pEntry->pKey);
        sc_string_destroy(pEntry->pKey);
        pEntry->pKey = ScNull;
    }

    sc_font_destroy(pEntry->Font);
    memset(pEntry, 0, sizeof(*pEntry));

    if (sc_list_index_of(g.Font.aRemovedIds, item == fontId) == -1)
        sc_list_add(g.Font.aRemovedIds, fontId);
}

/*     #####################################
  DOCS ##             Backend            ##
       #####################################*/

ScRaster*
sc_raster_backend_get_raster()
{
    return &g.Raster;
}

static void
sc_raster_backend_free_images()
{
    /* DOCS: dict не владеет ключами - сначала освобождаем его,
       потом сами ключи из записей. */
    sc_dict_free(g.Image.hRegistrationTable);
    g.Image.hRegistrationTable = ScNull;

    i64 imagesCount = sc_list_count(g.Image.aImages);
    for (i64 i = 0; i < imagesCount; ++i)
    {
        ScRasterBackendImageEntry* pEntry = &g.Image.aImages[i];
        if (pEntry->pKey != ScNull)
        {
            sc_string_destroy(pEntry->pKey);
            pEntry->pKey = ScNull;
        }
        /* pData принадлежит вызывающему - не освобождаем */
    }

    sc_list_free(g.Image.aImages);
    g.Image.aImages = ScNull;

    sc_list_free(g.Image.aRemovedIds);
    g.Image.aRemovedIds = ScNull;
}

static void
sc_raster_backend_free_fonts()
{
    sc_dict_free(g.Font.hRegistrationTable);
    g.Font.hRegistrationTable = ScNull;

    i64 fontsCount = sc_list_count(g.Font.aFonts);
    for (i64 i = 0; i < fontsCount; ++i)
    {
        ScRasterBackendFontEntry* pEntry = &g.Font.aFonts[i];
        if (pEntry->pKey != ScNull)
        {
            sc_string_destroy(pEntry->pKey);
            pEntry->pKey = ScNull;
        }

        if (pEntry->IsAlive)
        {
            sc_font_destroy(pEntry->Font);
            pEntry->IsAlive = 0;
        }
    }

    sc_list_free(g.Font.aFonts);
    g.Font.aFonts = ScNull;

    sc_list_free(g.Font.aRemovedIds);
    g.Font.aRemovedIds = ScNull;
}

void
sc_raster_backend_free()
{
    sc_raster_backend_free_images();
    sc_raster_backend_free_fonts();
    sc_raster_free(&g.Raster);
}
