/*
  DOCS: RasterBackend - реализация ScUiBackendRender (Gfx/Ui.h)
  поверх программного рендерера ScRaster (Gfx/Raster.h).

  Ui отдаёт виджеты в Ui-координатах: origin - левый НИЖНИЙ угол,
  Y-вверх (position.Y - верх виджета, см. sc_ui_is_hovered/текст),
  цвет - v4 (RGBA, 0..1). Растер хранит пиксели как u32
  0xAABBGGRR с тем же origin-ом (Y-вверх): бэкенд конвертирует
  только цвет. Z (z-order) игнорируем - рисуем в порядке вызова
  (Ui сам обходит виджеты по убыванию).

  Растер принадлежит бэкенду: оба буфера аллоцируются сразу на
  MaxSize, sc_raster_backend_update() подгоняет размеры под
  DisplaySize окна без реаллокаций. Забрать готовый кадр для
  вывода: sc_raster_backend_get_raster() + sc_raster_swap().
*/
#include "RasterBackend.h"
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <string.h>

/* DOCS: Стартовый размер буферов и запас под resize окна. */
#define ScRasterBackendStartWidth 800
#define ScRasterBackendStartHeight 600
#define ScRasterBackendMaxWidth 1920
#define ScRasterBackendMaxHeight 1080

/* DOCS: Запасной размер шрифта: Ui иногда зовёт GetTextMetrics с 0. */
#define ScRasterBackendDefaultFontSize 16

/*
  DOCS: Картинка, залитая в бэкенд (sc_raster_backend_upload_texture).
  pData - сырые пиксели width*height*channel байт (строки подряд).
  Живёт в таблице до sc_raster_backend_free; бэкенд память не
  копирует: pData принадлежит вызывающему.
  Id - стабильный хендл текстуры: dict при grow реаллоцирует
  хранилище (индексы/указатели записей плывут), поэтому id -
  монотонный счётчик, а не индекс в таблице.
*/
typedef struct
{
    i64 Id;
    void* pData;
    u32 Width;
    u32 Height;
    u8 Channels;
} ScRasterImage;

/*
  DOCS: Запись хеш-таблицы текстур: Key - имя (char*, ключ dict-а),
  Value - сама картинка. Тип нужен sc_dict_s_*-макросам.
*/
typedef struct
{
    char* Key;
    ScRasterImage Value;
} ScRasterBackendImageRecord;

typedef struct
{
    ScRaster Raster;
    struct
    {
        /* hTable текстур: ScRasterBackendImageRecord[dict] по имени */
        ScRasterBackendImageRecord* hTable;
        /* монотонный счётчик текстурных id (1, 2, ...; 0 - невалиден) */
        i64 NextId;
    } Image;
} ScRasterBackendGlobal;

static ScRasterBackendGlobal g = {};

/*     #####################################
  DOCS ##              Utils              ##
       #####################################*/

// DOCS: v4 RGBA (0..1) -> u32-пиксель растера 0xAABBGGRR.
static u32
sc_raster_backend_color_to_u32(v4 color)
{
    u32 a = f32_to_byte(color.A);
    u32 r = f32_to_byte(color.R);
    u32 g = f32_to_byte(color.G);
    u32 b = f32_to_byte(color.B);
    return (a << 24) | (b << 16) | (g << 8) | r;
}

/*
  DOCS: Ui-координаты уже Y-вверх (origin - левый НИЖНИЙ угол,
  position.Y - верх виджета: см. sc_ui_is_hovered - мышь в
  [pos.Y - height, pos.Y] - и pos.Y -= height у текста). Низ
  виджета = top - height. X не конвертируется: он совпадает.
*/
static i32
sc_raster_backend_y_to_raster(f32 top, f32 height)
{
    return to_i32(top - height);
}

/*     #####################################
  DOCS ##        UiBackend Render         ##
       #####################################*/

static void
_sc_raster_backend_draw_rect(v3 position, v2 size, v4 color)
{
    i32 x = to_i32(position.X);
    i32 y = sc_raster_backend_y_to_raster(position.Y, size.Height);
    u32 rasterColor = sc_raster_backend_color_to_u32(color);

    /* клиппинг внутри sc_raster_fill_rect */
    sc_raster_fill_rect(&g.Raster, x, y, to_i32(size.Width), to_i32(size.Height), rasterColor);
}

static void
_sc_raster_backend_draw_empty_rect(v3 position, v2 size, real thickness, v4 color)
{
    i32 x = to_i32(position.X);
    i32 width = to_i32(size.Width);
    i32 height = to_i32(size.Height);
    i32 y = sc_raster_backend_y_to_raster(position.Y, size.Height);
    i32 t = ScMax(to_i32(thickness), 1);
    u32 rasterColor = sc_raster_backend_color_to_u32(color);

    /* рамка из 4 заливок: клиппинг внутри sc_raster_fill_rect */
    sc_raster_fill_rect(&g.Raster, x, y, width, t, rasterColor);              /* верх */
    sc_raster_fill_rect(&g.Raster, x, y + height - t, width, t, rasterColor); /* низ  */
    sc_raster_fill_rect(&g.Raster, x, y, t, height, rasterColor);             /* лево */
    sc_raster_fill_rect(&g.Raster, x + width - t, y, t, height, rasterColor); /* право */
}

static void
_sc_raster_backend_draw_image(v3 position, v2 size, v4 color, i64 textureId)
{
    // todo: impl (нужна текстуры/ассеты: Image/* + менеджер)
}

static void
_sc_raster_backend_draw_image_atlas_item(v3 position, v2 size, v4 color, i64 textureId, i32 index)
{
    // todo: impl (нужны атласы: Image/* + менеджер)
}

static void
_sc_raster_backend_draw_text(char* pText, i32 fontSize, v3 position, v4 color)
{
    // todo: impl (растеризация глифов через Text/Font)
}

static void
_sc_raster_backend_set_viewport(i32 x0, i32 y0, i32 width, i32 height)
{
    // todo: impl (клип-регион для scrollable-панелей)
}

// note: грубая оценка, пока нет растеризации текста (Text/Font):
// моноширинная сетка (fontSize * 0.5) x fontSize на символ.
static v2
_sc_raster_backend_get_text_metrics(char* pText, i32 fontSize, char* pFontPath)
{
    if (pText == ScNull)
        return v2_0();

    if (fontSize <= 0)
        fontSize = ScRasterBackendDefaultFontSize;

    i64 charsCount = sc_utf8_length(pText);
    f32 charWidth = fontSize * 0.5f;
    return v2_new(charWidth * (f32)charsCount, (f32)fontSize);
}

/*     #####################################
  DOCS ##          Raster Backend         ##
       #####################################*/

void
sc_raster_backend_new()
{
    /*
      DOCS: Растер бэкенда: оба буфера сразу на MaxSize - resize при
      sc_raster_backend_update() не делает реаллокаций.
    */
    ScResult rasterResult = sc_raster_init(
        &g.Raster,
        ScRasterBackendStartWidth,
        ScRasterBackendStartHeight,
        ScRasterBackendMaxWidth,
        ScRasterBackendMaxHeight);
    if (rasterResult != ScResult_Success)
    {
        sc_log_erro("sc_raster_backend_new: sc_raster_init failed!\n");
        return;
    }

    ScUiBackendRender renderCfg = {
        .DrawRect = _sc_raster_backend_draw_rect,
        .DrawEmptyRect = _sc_raster_backend_draw_empty_rect,
        .DrawImage = _sc_raster_backend_draw_image,
        .DrawImageAtlasItem = _sc_raster_backend_draw_image_atlas_item,
        .DrawText = _sc_raster_backend_draw_text,
        .SetViewport = _sc_raster_backend_set_viewport,
        .GetTextMetrics = _sc_raster_backend_get_text_metrics,
    };

    sc_ui_backend_new((ScUiBackendConfig) { .Render = renderCfg });
}

void
sc_raster_backend_update(ScUiBackendState state)
{
    /*
      DOCS: DisplaySize = размер окна: подгоняем буферы растера
      (память уже на MaxSize, меняются только поля) и прокидываем
      state в ui.
    */
    i32 width = to_i32(state.DisplaySize.Width);
    i32 height = to_i32(state.DisplaySize.Height);
    if (width > 0 && height > 0)
        sc_raster_resize(&g.Raster, width, height);

    sc_ui_backend_update(state);
}

void
sc_raster_backend_render()
{
    sc_ui_backend_render();
}

ScUiInput*
sc_raster_backend_get_input()
{
    return sc_ui_backend_get_input();
}

i64
sc_raster_backend_upload_texture(char* pTextureName, void* pData, u32 width, u32 height, u8 channel)
{
    if (pTextureName == ScNull || pData == ScNull || width == 0 || height == 0
        || channel < 1 || channel > 4)
    {
        sc_log_erro("sc_raster_backend_upload_texture: invalid args (name=%p data=%p %ux%u ch=%d)\n",
            pTextureName, pData, width, height, channel);
        return ScInvalidId;
    }

    /*
      DOCS: Текстура уже залита - отдаём её id. sc_dict_s_contains
      прокидывает индекс в заголовок (sc_dict_calc_ind_string ->
      pHdr->Index), поэтому дальше - ровно
      hTable[sc_dict_index(hTable)].Value.
    */
    if (sc_dict_s_contains(g.Image.hTable, pTextureName))
    {
        ScRasterImage* pExist = &g.Image.hTable[sc_dict_index(g.Image.hTable)].Value;
        return pExist->Id;
    }

    /* DOCS: Новая запись: dict не копирует ключ - держим свою копию. */
    i64 id = ++g.Image.NextId;
    ScRasterImage image = {
        .Id = id,
        .pData = pData,
        .Width = width,
        .Height = height,
        .Channels = channel,
    };

    char* pTextureNameAllocated = sc_string_new(pTextureName);
    sc_dict_s_add(g.Image.hTable, pTextureNameAllocated, image);

    /* DOCS: dict вернул индекс добавленной записи (для asserts). */
    i64 ind = sc_dict_index(g.Image.hTable);
    if (ind == -1)
    {
        sc_log_erro("sc_raster_backend_upload_texture: dict add failed for '%s'\n", pTextureName);
        return ScInvalidId;
    }

    return id;
}

ScRaster*
sc_raster_backend_get_raster()
{
    return &g.Raster;
}

void
sc_raster_backend_free()
{
    /* DOCS: ключи-копии (sc_string_new) + само хранилище dict-а. */
    if (g.Image.hTable != ScNull)
    {
        for (i64 i = 0; i < sc_dict_capacity(g.Image.hTable); ++i)
        {
            ScRasterBackendImageRecord* pRecord = &g.Image.hTable[i];
            if (pRecord->Key != ScNull)
                sc_string_destroy(pRecord->Key);
        }

        sc_dict_free(g.Image.hTable);
        g.Image.hTable = ScNull;
    }

    g.Image.NextId = 0;

    sc_raster_free(&g.Raster);
}
