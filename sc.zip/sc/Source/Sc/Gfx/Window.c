#include "Sc/Gfx/Window.h"
#include "Sc/Sc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(SC_WINDOW_XCB)

#include <X11/keysym.h>
// not sure i need this
#include <X11/X.h>
#include <X11/Xutil.h>
// not sure i need this
#include <sys/select.h>

#include <xcb/bigreq.h> // Заголовочный файл для Big Requests
#include <xcb/xcb.h>
#include <xcb/xcb_icccm.h>
#include <xcb/xcb_keysyms.h> // xcb_key_symbols_t
#include <xcb/xkb.h>
#include <xcb/xproto.h>

typedef struct
{
    xcb_window_t Window;
    xcb_screen_t* pScreen;
    xcb_connection_t* pConnection;
    xcb_key_symbols_t* pSymbols;
    xcb_cursor_t BlankCursor;
    v2 MousePrev; /* прошлая позиция мыши для grab-режима (-1 = нет) */
} ScWindowXcbLinux;

/*
  DOCS: Платформенный blit-бэкенд XCB: растер общий (ScRaster в
  pWindow->pGraphics), blit-ресурсы (pixmap/gc/maxRequestSize) - в
  отдельной структуре, указатель лежит в pBackend после ScWindowXcbLinux.
*/
typedef struct
{
    i32 MaxRequestSize;
    xcb_gcontext_t Gc;
    xcb_pixmap_t Pixmap;
} ScWindowXcbLinuxGraphics;

//////                               //
//            XCB Window             //
//                               //////

static void xcb_sc_window_create(ScWindow*, ScWindowConfig);
static void xcb_sc_window_destroy(ScWindow*);
static void xcb_sc_window_update(ScWindow*);
static void xcb_sc_window_set_title(ScWindow*, char*);
static void xcb_sc_window_set_headless(ScWindow*, i32);
static void xcb_sc_window_set_fullscreen(ScWindow*, i32);
static void xcb_sc_window_set_above(ScWindow*, i32);
static void xcb_sc_window_set_cursor_visibilite(ScWindow*, i32);
static void xcb_sc_window_set_cursor_position(ScWindow*, i32, i32);
static void xcb_sc_window_set_position(ScWindow* pWindow, i32 x, i32 y);
static ScKey xcb_sc_key_from_native(i32 native);
static void xcb_create_blank_cursor(ScWindowXcbLinux*);
static ScKeyMod xcb_sc_key_mod_from_native(i32);
static ScMouseKey xcb_sc_mouse_key_from_native(i32);
static xcb_atom_t xcb_get_atom(xcb_connection_t* pXcb, const char* pName);
static ScWindowXcbLinux* xcb_sc_window_get_platform(ScWindow* pWindow);
static ScWindowXcbLinuxGraphics* xcb_sc_window_get_platform_graphics(ScWindow* pWindow);

//////                               //
//           XCB Graphics            //
//                               //////

static void xcb_sc_window_graphics_init(ScWindow* pWindow);
static void xcb_sc_window_graphics_resize(ScWindow* pWindow);
static void xcb_sc_window_graphics_swap_buffers(ScWindow* pWindow);


#elif defined(SC_WINDOW_WIN32) // SC_WINDOW_XCB

/*
  DOCS: WIN32-бэкенд (Windows: окно + GDI-blit). Растер общий
  (ScRaster в pWindow->pGraphics), здесь HWND, WndProc, события и
  вывод через DIB/BitBlt. Реализация - в WIN32-секции внизу.
*/
static void win32_sc_window_create(ScWindow*, ScWindowConfig);
static void win32_sc_window_destroy(ScWindow*);
static void win32_sc_window_update(ScWindow*);
static void win32_sc_window_set_title(ScWindow*, char*);
static void win32_sc_window_set_headless(ScWindow*, i32);
static void win32_sc_window_set_fullscreen(ScWindow*, i32);
static void win32_sc_window_set_above(ScWindow*, i32);
static void win32_sc_window_set_cursor_visibilite(ScWindow*, i32);
static void win32_sc_window_set_cursor_position(ScWindow*, i32, i32);
static void win32_sc_window_set_position(ScWindow*, i32, i32);
static ScKey win32_sc_key_from_native(i32 native);
static ScKeyMod win32_sc_key_mod_from_native(void);
static void win32_sc_window_graphics_init(ScWindow* pWindow);
static void win32_sc_window_graphics_resize(ScWindow* pWindow);
static void win32_sc_window_graphics_swap_buffers(ScWindow* pWindow);

#endif                         // SC_WINDOW_WIN32

ScKeyMod sc_key_mod_from_native(i32 native);
ScMouseKey sc_mouse_key_from_native(i32 native);

void
sc_window_fatal(const char* pMessage)
{
    printf("Error: %s\n", pMessage);
    sc_guard(0);
}

void
sc_window_create(ScWindow* pWindow, ScWindowConfig conf)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_create(pWindow, conf);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_create(pWindow, conf);
#endif
    pWindow->IsAlive = 1;
}

void
sc_window_destroy(ScWindow* pWindow)
{
    if (!pWindow)
        return;

#if defined(SC_WINDOW_XCB)
    xcb_sc_window_destroy(pWindow);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_destroy(pWindow);
#endif // SC_WINDOW_WIN32
}

void
sc_window_update(ScWindow* pWindow)
{
    if (!pWindow)
        return;

#if defined(SC_WINDOW_XCB)
    xcb_sc_window_update(pWindow);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_update(pWindow);
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_event_call(ScWindow* pWindow, ScCall call)
{
    pWindow->OnEvent = call;
}

void
sc_window_set_title(ScWindow* pWindow, char* pTitle)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_title(pWindow, pTitle);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_title(pWindow, pTitle);
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_headless(ScWindow* pWindow, i32 isSet)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_headless(pWindow, isSet);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_headless(pWindow, isSet);
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_fullscreen(pWindow, isSet);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_fullscreen(pWindow, isSet);
#endif // SC_WINDOW_WIN32
}

// WIP
void
sc_window_set_above(ScWindow* pWindow, i32 isSet)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_above(pWindow, isSet);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_above(pWindow, isSet);
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_grabed_ext(ScWindow* pWindow, i32 flag)
{
    pWindow->IsGrabed = flag;
}

void
sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_cursor_visibilite(pWindow, isVisible);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_cursor_visibilite(pWindow, isVisible);
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_cursor_position(pWindow, x, y);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_cursor_position(pWindow, x, y);
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_position(ScWindow* pWindow, i32 x, i32 y)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_position(pWindow, x, y);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_set_position(pWindow, x, y);
#endif // SC_WINDOW_WIN32
}

ScKey
sc_key_from_native(i32 native)
{
#if defined(SC_WINDOW_XCB)
    return xcb_sc_key_from_native(native);
#elif defined(SC_WINDOW_WIN32)
    return win32_sc_key_from_native(native);
#endif // SC_WINDOW_WIN32
}

//////                               //
//             Graphics              //
//                               //////

/*
  DOCS: Общая диспетчеризация graphics-API на платформенные blit-бэкенды.
  Сама отрисовка - в ScRaster (Gfx/Raster.h), общий для всех платформ.
*/

void
sc_window_graphics_init(ScWindow* pWindow)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_init(pWindow);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_graphics_init(pWindow);
#endif
}

void
sc_window_graphics_resize(ScWindow* pWindow)
{
    if (!pWindow || !pWindow->pGraphics)
        return;

#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_resize(pWindow);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_graphics_resize(pWindow);
#endif
}

ScRaster*
sc_window_get_raster(ScWindow* pWindow)
{
    if (!pWindow)
        return ScNull;

    return (ScRaster*)pWindow->pGraphics;
}

void
sc_window_graphics_swap_buffers(ScWindow* pWindow)
{
    if (!pWindow || !pWindow->pGraphics)
        return;

#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_swap_buffers(pWindow);
#elif defined(SC_WINDOW_WIN32)
    win32_sc_window_graphics_swap_buffers(pWindow);
#endif
}

//////                               //
//       DOCS: Utils & Helpers       //
//                               //////

const char*
sc_window_key_to_string(ScKey key)
{
    switch (key)
    {

    case ScKey_None:
        return "None";

    // DOCS: Numbers
    case ScKey_0:
        return "0";
    case ScKey_1:
        return "1";
    case ScKey_2:
        return "2";
    case ScKey_3:
        return "3";
    case ScKey_4:
        return "4";
    case ScKey_5:
        return "5";
    case ScKey_6:
        return "6";
    case ScKey_7:
        return "7";
    case ScKey_8:
        return "8";
    case ScKey_9:
        return "9";

    // DOCS: Numpad Numbers
    case ScKey_NP_0:
        return "NP_0";
    case ScKey_NP_1:
        return "NP_1";
    case ScKey_NP_2:
        return "NP_2";
    case ScKey_NP_3:
        return "NP_3";
    case ScKey_NP_4:
        return "NP_4";
    case ScKey_NP_5:
        return "NP_5";
    case ScKey_NP_6:
        return "NP_6";
    case ScKey_NP_7:
        return "NP_7";
    case ScKey_NP_8:
        return "NP_8";
    case ScKey_NP_9:
        return "NP_9";

    // DOCS: Numpad Keys
    case ScKey_NP_Lock:
        return "NP_Lock";
    case ScKey_NP_Div:
        return "NP_Div";
    case ScKey_NP_Mul:
        return "NP_Mul";
    case ScKey_NP_Min:
        return "NP_Min";
    case ScKey_NP_Add:
        return "NP_Add";
    case ScKey_NP_Enter:
        return "NP_Enter";
    case ScKey_NP_Comma:
        return "NP_Comma";

    // DOCS: Upper right panel
    case ScKey_PrintScreen:
        return "PrintScreen";
    case ScKey_ScrollLock:
        return "ScrollLock";
    case ScKey_PauseBreak:
        return "PauseBreak";

    // DOCS: Mid right panel
    case ScKey_Insert:
        return "Insert";
    case ScKey_Delete:
        return "Delete";
    case ScKey_Home:
        return "Home";
    case ScKey_End:
        return "End";
    case ScKey_PageUp:
        return "PageUp";
    case ScKey_PageDown:
        return "PageDown";
    case ScKey_CapsLock:
        return "CapsLock";

    // DOCS: Lower right panel
    case ScKey_Up:
        return "Up";
    case ScKey_Left:
        return "Left";
    case ScKey_Down:
        return "Down";
    case ScKey_Right:
        return "Right";

        // DOCS: Characters

    case ScKey_Q:
        return "Q";
    case ScKey_W:
        return "W";
    case ScKey_E:
        return "E";
    case ScKey_R:
        return "R";
    case ScKey_T:
        return "T";
    case ScKey_Y:
        return "Y";
    case ScKey_U:
        return "U";
    case ScKey_I:
        return "I";
    case ScKey_O:
        return "O";
    case ScKey_P:
        return "P";

    case ScKey_A:
        return "A";
    case ScKey_S:
        return "S";
    case ScKey_D:
        return "D";
    case ScKey_F:
        return "F";
    case ScKey_G:
        return "G";
    case ScKey_H:
        return "H";
    case ScKey_J:
        return "J";
    case ScKey_K:
        return "K";
    case ScKey_L:
        return "L";

    case ScKey_Z:
        return "Z";
    case ScKey_X:
        return "X";
    case ScKey_C:
        return "C";
    case ScKey_V:
        return "V";
    case ScKey_B:
        return "B";
    case ScKey_N:
        return "N";
    case ScKey_M:
        return "M";

    // DOCS: Functional
    case ScKey_Grave:
        return "Grave";
    case ScKey_Min:
        return "Min";
    case ScKey_Equal:
        return "Equal";
    case ScKey_Tab:
        return "Tab";
    case ScKey_Shift:
        return "Shift";
    case ScKey_Ctrl:
        return "Ctrl";
    case ScKey_Alt:
        return "Alt";
    case ScKey_Super:
        return "Super";
    case ScKey_Space:
        return "Space";

    case ScKey_Comma:
        return "Comma";
    case ScKey_Dot:
        return "Dot";
    case ScKey_Slash:
        return "Slash";

    case ScKey_Shift_Right:
        return "Shift_Right";
    case ScKey_Alt_Right:
        return "Alt_Right";
    case ScKey_Ctrl_Right:
        return "Ctrl_Right";
    case ScKey_Super_Right:
        return "Super_Right";
    case ScKey_Command_Right:
        return "Command_Right";

    case ScKey_Escape:
        return "Escape";

    // DOCS: Press F
    case ScKey_F1:
        return "F1";
    case ScKey_F2:
        return "F2";
    case ScKey_F3:
        return "F3";
    case ScKey_F4:
        return "F4";
    case ScKey_F5:
        return "F5";
    case ScKey_F6:
        return "F6";
    case ScKey_F7:
        return "F7";
    case ScKey_F8:
        return "F8";
    case ScKey_F9:
        return "F9";
    case ScKey_F10:
        return "F10";
    case ScKey_F11:
        return "F11";
    case ScKey_F12:
        return "F12";

    // DOCS: Extra
    case ScKey_Bracket_Left:
        return "Bracket_Left";
    case ScKey_Bracket_Right:
        return "Bracket_Right";
    case ScKey_Semicolon:
        return "Semicolon";
    case ScKey_Apostrophe:
        return "Apostrophe";
    case ScKey_Backslash:
        return "Backslash";
    case ScKey_Enter:
        return "Enter";

    case ScKey_F13:
        return "F13";
    case ScKey_F14:
        return "F14";
    case ScKey_F15:
        return "F15";
    case ScKey_F16:
        return "F16";
    case ScKey_F17:
        return "F17";
    case ScKey_F18:
        return "F18";
    case ScKey_F19:
        return "F19";
    case ScKey_F20:
        return "F20";
    case ScKey_F21:
        return "F21";
    case ScKey_F22:
        return "F22";
    case ScKey_F23:
        return "F23";
    case ScKey_F24:
        return "F24";
    case ScKey_F25:
        return "F25";

    case ScKey_Backspace:
        return "Backspace";
    case ScKey_Menu:
        return "Menu";

    case ScKey_Count:
        return "Count";

    default:
        return "Undefined";
    }
}

ScKeyMod
sc_key_mod_from_native(i32 native)
{
#if defined(SC_WINDOW_XCB)
    return xcb_sc_key_mod_from_native(native);
#elif defined(SC_WINDOW_WIN32)
    return win32_sc_key_mod_from_native();
#endif // SC_WINDOW_WIN32
}

const char*
sc_mouse_key_to_string(ScMouseKey key)
{
    switch (key)
    {
    case ScMouseKey_None:
        return "None";
    case ScMouseKey_Left:
        return "Left";
    case ScMouseKey_Right:
        return "Right";
    case ScMouseKey_Middle:
        return "Middle";
    case ScMouseKey_Ext_0:
        return "Ext_0";
    case ScMouseKey_Ext_1:
        return "Ext_1";
    case ScMouseKey_Ext_2:
        return "Ext_2";
    case ScMouseKey_Ext_3:
        return "Ext_3";
    case ScMouseKey_Ext_4:
        return "Ext_4";
    case ScMouseKey_Ext_5:
        return "Ext_5";
    case ScMouseKey_Ext_6:
        return "Ext_6";
    case ScMouseKey_Ext_7:
        return "Ext_7";
    case ScMouseKey_Ext_8:
        return "Ext_8";
    case ScMouseKey_Ext_9:
        return "Ext_9";
    default:
        return "Undefined";
    }
}

const char*
sc_event_type_to_string(ScEventType type)
{
    switch (type)
    {
    case ScEventType_None:
        return "None";
    case ScEventType_KeyType:
        return "KeyType";
    case ScEventType_KeyPress:
        return "KeyPress";
    case ScEventType_KeyRelease:
        return "KeyRelease";
    case ScEventType_MousePress:
        return "MousePress";
    case ScEventType_MouseRelease:
        return "MouseRelease";
    case ScEventType_KeyboardMapping:
        return "KeyboardMapping";
    case ScEventType_MouseMove:
        return "MouseMove";
    case ScEventType_MouseScroll:
        return "MouseScroll";
    case ScEventType_WindowMoved:
        return "WindowMoved";
    case ScEventType_WindowResized:
        return "WindowResized";
    case ScEventType_WindowClosed:
        return "WindowClosed";
    case ScEventType_WindowMaximized:
        return "WindowMaximized";
    case ScEventType_WindowFocused:
        return "WindowFocused";
    case ScEventType_WindowEnter:
        return "WindowEnter";
    case ScEventType_WindowHidden:
        return "WindowHidden";
    case ScEventType_Count:
        return "Count";
    default:
        return "Unknown";
    }
}

i32
sc_window_key_is_printable(ScKey key)
{
    static ScKey aCheckTables[ScKey_Count] = {};
    static i32 isNotInit = 1;
    if (isNotInit)
    {
        for (i32 i = ScKey_0; i <= ScKey_9; ++i)
            aCheckTables[i] = 1;

        for (i32 i = ScKey_NP_0; i <= ScKey_NP_9; ++i)
            aCheckTables[i] = 1;

        for (i32 i = ScKey_Q; i <= ScKey_M; ++i)
            aCheckTables[i] = 1;

        aCheckTables[ScKey_NP_Div] = 1;
        aCheckTables[ScKey_NP_Mul] = 1;
        aCheckTables[ScKey_NP_Min] = 1;
        aCheckTables[ScKey_NP_Add] = 1;
        aCheckTables[ScKey_NP_Comma] = 1;

        aCheckTables[ScKey_Grave] = 1;
        aCheckTables[ScKey_Min] = 1;
        aCheckTables[ScKey_Equal] = 1;
        aCheckTables[ScKey_Comma] = 1;
        aCheckTables[ScKey_Dot] = 1;
        aCheckTables[ScKey_Slash] = 1;
        aCheckTables[ScKey_Bracket_Left] = 1;
        aCheckTables[ScKey_Bracket_Right] = 1;
        aCheckTables[ScKey_Semicolon] = 1;
        aCheckTables[ScKey_Apostrophe] = 1;
        aCheckTables[ScKey_Backslash] = 1;

        isNotInit = 0;
    }

    i32 isPrintable = aCheckTables[key];
    return isPrintable;
}

//////                               //
//            XCB Window             //
//                               //////

#if defined(SC_WINDOW_XCB)

void*
xcb_sc_window_get_window(ScWindow* pWindow)
{
    return (void*)&xcb_sc_window_get_platform(pWindow)->Window;
}

void*
xcb_sc_window_get_connection(ScWindow* pWindow)
{
    return (void*)xcb_sc_window_get_platform(pWindow)->pConnection;
}

static void
xcb_sc_window_create(ScWindow* pScWindow, ScWindowConfig conf)
{
    xcb_connection_t* pConnection = xcb_connect(NULL, NULL);
    if (xcb_connection_has_error(pConnection))
    {
        sc_window_fatal("Xcb con has error\n");
        return;
    }

    { // DOCS: init xcb
        const xcb_query_extension_reply_t* pExtReply = xcb_get_extension_data(pConnection, &xcb_xkb_id);
        if (!pExtReply || !pExtReply->present)
        {
            sc_window_fatal("XKB extension not available\n");
        }

        xcb_xkb_use_extension_cookie_t useCookie = xcb_xkb_use_extension(pConnection, XCB_XKB_MAJOR_VERSION, XCB_XKB_MINOR_VERSION);

        xcb_xkb_use_extension_reply_t* pUseReply = xcb_xkb_use_extension_reply(pConnection, useCookie, NULL);

        if (!pUseReply || !pUseReply->supported)
        {
            sc_window_fatal("XKB extension not supported!\n");
            free(pUseReply);
            return;
        }

        u16 map_parts = XCB_XKB_MAP_PART_KEY_TYPES | XCB_XKB_MAP_PART_KEY_SYMS;
        i16 events = XCB_XKB_EVENT_TYPE_NEW_KEYBOARD_NOTIFY | XCB_XKB_EVENT_TYPE_MAP_NOTIFY;

        xcb_xkb_select_events(pConnection, XCB_XKB_ID_USE_CORE_KBD, events, 0, events, map_parts, map_parts, NULL);
    }

    const xcb_setup_t* pSetup = xcb_get_setup(pConnection);
    xcb_screen_t* pScreen = xcb_setup_roots_iterator(pSetup).data;

    xcb_window_t window = xcb_generate_id(pConnection);

    u32 windowMask = XCB_CW_BACK_PIXEL | XCB_CW_EVENT_MASK;
    u32 masksList[2] = {
        [0] = pScreen->black_pixel,
        [1] = XCB_EVENT_MASK_EXPOSURE | XCB_EVENT_MASK_KEY_PRESS | XCB_EVENT_MASK_KEY_RELEASE | XCB_EVENT_MASK_FOCUS_CHANGE | XCB_EVENT_MASK_VISIBILITY_CHANGE | XCB_EVENT_MASK_POINTER_MOTION | XCB_EVENT_MASK_BUTTON_PRESS | XCB_EVENT_MASK_BUTTON_RELEASE | XCB_EVENT_MASK_ENTER_WINDOW | XCB_EVENT_MASK_LEAVE_WINDOW |
              // Конфигурация, видимость
              XCB_EVENT_MASK_STRUCTURE_NOTIFY |
              // Изменение свойств окна
              XCB_EVENT_MASK_PROPERTY_CHANGE |

              // Maybe comment
              // Перехват изменения размера
              // XCB_EVENT_MASK_RESIZE_REDIRECT |
              // События дочерних окон
              XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY
    };

    /*
      DOCS: Позиция по умолчанию (0,0) = центр экрана. Заданная
      позиция используется как есть.
    */
    i32 posX = conf.Position.X;
    i32 posY = conf.Position.Y;
    if (posX == 0 && posY == 0)
    {
        posX = ((i32)pScreen->width_in_pixels - conf.Size.Width) / 2;
        posY = ((i32)pScreen->height_in_pixels - conf.Size.Height) / 2;
    }

    // Create borderless window
    xcb_create_window(
        pConnection,
        XCB_COPY_FROM_PARENT,
        window,
        pScreen->root,
        posX,
        posY,
        conf.Size.Width,
        conf.Size.Height,
        1, // Border width = 0 for no border
        XCB_WINDOW_CLASS_INPUT_OUTPUT,
        pScreen->root_visual,
        windowMask,
        masksList);

    pScWindow->Size = conf.Size;

    xcb_atom_t normalHintAtom = xcb_get_atom(pConnection, "WM_NORMAL_HINTS");
    if (normalHintAtom != XCB_NONE)
    {
        xcb_size_hints_t hints = {};
        hints.flags = XCB_ICCCM_SIZE_HINT_P_MIN_SIZE | XCB_ICCCM_SIZE_HINT_P_MAX_SIZE;
        hints.min_width = conf.MinSize.Width;
        hints.min_height = conf.MinSize.Height;
        if (conf.MaxSize.Width > 0)
            hints.max_width = conf.MaxSize.Width;
        else
            hints.max_width = 10000;
        if (conf.MaxSize.Height > 0)
            hints.max_height = conf.MaxSize.Height;
        else
            hints.max_height = 10000;

        xcb_change_property(
            pConnection,
            XCB_PROP_MODE_REPLACE,
            window,
            normalHintAtom,
            XCB_ATOM_WM_SIZE_HINTS,
            32,
            sizeof(hints) / 4,
            &hints);

        pScWindow->MaxSize = conf.MaxSize;
    }

    u64 allocatedSize = sizeof(ScWindowXcbLinux);
    if (conf.UseGraphics)
        allocatedSize += sizeof(ScWindowXcbLinuxGraphics);

    void* pShared = sc_memory_allocate(allocatedSize);
    pScWindow->pBackend = pShared;

    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pScWindow);
    pXcbLinux->Window = window;
    pXcbLinux->pScreen = pScreen;
    pXcbLinux->pConnection = pConnection;
    pXcbLinux->pSymbols = xcb_key_symbols_alloc(pConnection);
    pXcbLinux->MousePrev = v2_new(-1, -1);

    if (conf.UseGraphics)
    {
        /*
          DOCS: pBackend = [ScWindowXcbLinux][ScWindowXcbLinuxGraphics],
          blit-бэкенд достаётся как pXcb + 1. Растер (общий, без xcb)
          аллоцируется отдельно и вешается в pGraphics.
        */
        pScWindow->pGraphics = sc_memory_allocate(sizeof(ScRaster));
        sc_window_graphics_init(pScWindow);
    }

    // 2. Устанавливаем тип окна (обычное окно)
    {
        xcb_atom_t net_wm_window_type = xcb_get_atom(pConnection, "_NET_WM_WINDOW_TYPE");
        xcb_atom_t net_wm_window_type_normal = xcb_get_atom(pConnection, "_NET_WM_WINDOW_TYPE_NORMAL");

        xcb_change_property(pConnection,
            XCB_PROP_MODE_REPLACE,
            window,
            net_wm_window_type,
            XCB_ATOM_ATOM,
            32,
            1,
            &net_wm_window_type_normal);
    }

    { // Устанавливаем протокол для x-btn to woke.
        xcb_intern_atom_cookie_t pc = xcb_intern_atom(pConnection, 1, 12, "WM_PROTOCOLS");
        xcb_intern_atom_cookie_t dc = xcb_intern_atom(pConnection, 0, 16, "WM_DELETE_WINDOW");

        xcb_intern_atom_reply_t* pProtocolRep = xcb_intern_atom_reply(pConnection, pc, NULL);
        xcb_intern_atom_reply_t* pDeleteRep = xcb_intern_atom_reply(pConnection, dc, NULL);

        xcb_change_property(pConnection, XCB_PROP_MODE_REPLACE, window, pProtocolRep->atom, XCB_ATOM_ATOM, 32, 1, &pDeleteRep->atom);
    }

    xcb_create_blank_cursor(pXcbLinux);

    xcb_map_window(pConnection, window);
    xcb_flush(pConnection);
}

static void
xcb_sc_window_destroy(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);

    /* общий растер */
    if (pWindow->pGraphics)
    {
        sc_raster_free((ScRaster*)pWindow->pGraphics);
        sc_memory_free(pWindow->pGraphics);
        pWindow->pGraphics = ScNull;
    }

    xcb_destroy_window(pXcbLinux->pConnection, pXcbLinux->Window);
    xcb_disconnect(pXcbLinux->pConnection);
    sc_memory_free(pWindow->pBackend);
    pWindow->pBackend = ScNull;
    pWindow->IsAlive = 0;
}

static void
xcb_sc_window_update(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);

    // Process all available events
    xcb_generic_event_t* pEvent;
    while ((pEvent = xcb_poll_for_event(pXcbLinux->pConnection)))
    {
        // printf("Event!\n");
        switch (pEvent->response_type & ~0x80)
        {

        case XCB_KEY_PRESS:
        {
            xcb_key_press_event_t* pKeyPress = (xcb_key_press_event_t*)pEvent;
            xcb_keysym_t keySymbol = xcb_key_press_lookup_keysym(pXcbLinux->pSymbols, pKeyPress, 0);

            ScKey key = sc_key_from_native((i32)keySymbol);
            ScKeyMod mod = sc_key_mod_from_native(pKeyPress->state);

            /* DOCS: клавиша вне ScKey (напр. Cyrillic keysym) - в таблицу
               не пишем: aKeys[ScKey_None] (-1) - выход за границы. */
            if (key == ScKey_None)
                break;

            pWindow->aKeys[key] = ScAction_Press;
            pWindow->aKeyCounter[key] += 1;

            ScKeyPressEvent pressEvent = {
                .Base = (ScEvent) {
                    .IsHandled = 0,
                    .Type = ScEventType_KeyPress },
                .Key = key,
                .KeyMod = mod
            };

            if (pWindow->OnEvent)
            {
                pWindow->OnEvent((ScEvent*)&pressEvent);
            }
            break;
        }

        case XCB_KEY_RELEASE:
        {
            xcb_key_release_event_t* pKeyRelease = (xcb_key_release_event_t*)pEvent;
            xcb_keysym_t keySymbol = xcb_key_release_lookup_keysym(pXcbLinux->pSymbols, pKeyRelease, 0);

            ScKey key = sc_key_from_native((i32)keySymbol);
            ScKeyMod mod = sc_key_mod_from_native(pKeyRelease->state);

            if (key == ScKey_None)
                break;

            ScKeyReleaseEvent releaseEvent = {
                .Base = (ScEvent) {
                    .IsHandled = 0,
                    .Type = ScEventType_KeyRelease },
                .Key = key,
                .KeyMod = mod
            };

            pWindow->aKeys[key] = ScAction_Release;
            pWindow->aKeyCounter[key] = 0;

            if (pWindow->OnEvent)
            {
                pWindow->OnEvent((ScEvent*)&releaseEvent);
            }
            break;
        }

        /*
          DOCS: Кнопки мыши. Без этих case'ов ScEventType_MousePress/
          MouseRelease не приходили бы вообще: ScUiInput.aKeys[Mouse_*]
          оставались None и ui-виджеты на Linux не нажимались.
          Номера кнопок X11: 1/2/3 - левая/средняя/правая, 4/5 - колесо
          вверх/вниз, 6/7 - колесо влево/вправо, 8/9 - боковые.
        */
        case XCB_BUTTON_PRESS:
        case XCB_BUTTON_RELEASE:
        {
            i32 isPress = ((pEvent->response_type & ~0x80) == XCB_BUTTON_PRESS);
            xcb_button_press_event_t* pButton = (xcb_button_press_event_t*)pEvent;

            /*
              DOCS: курсор мог войти в окно сразу с нажатием, без
              MotionNotify, - берём позицию из самого события и отдаём
              как MouseMove, чтобы ui знал, где мышь.
            */
            pWindow->Mouse = v2_new(pButton->event_x, pWindow->Size.Height - 1 - pButton->event_y);

            if (isPress && pWindow->OnEvent)
            {
                ScMouseMoveEvent moveEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_MouseMove },
                    .X = pButton->event_x,
                    .Y = to_i32(pWindow->Mouse.Y)
                };
                pWindow->OnEvent((ScEvent*)&moveEvent);
            }

            /* колесо: вверх +1, вниз -1, вправо +1, влево -1 */
            if (pButton->detail >= 4 && pButton->detail <= 7)
            {
                if (isPress && pWindow->OnEvent)
                {
                    i32 value = (pButton->detail == 5 || pButton->detail == 6) ? -1 : 1;
                    ScMouseScrollEvent scrollEvent = {
                        .Base = { .IsHandled = 0, .Type = ScEventType_MouseScroll },
                        .Value = value
                    };
                    pWindow->OnEvent((ScEvent*)&scrollEvent);
                }
                break;
            }

            ScMouseKey key = xcb_sc_mouse_key_from_native(pButton->detail);
            if (key == ScMouseKey_None)
                break;

            pWindow->aMouseKeys[key] = isPress ? ScAction_Press : ScAction_Release;

            if (isPress)
            {
                ScMousePressEvent pressEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_MousePress },
                    .Key = key
                };
                if (pWindow->OnEvent)
                    pWindow->OnEvent((ScEvent*)&pressEvent);
            }
            else
            {
                ScMouseReleaseEvent releaseEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_MouseRelease },
                    .Key = key
                };
                if (pWindow->OnEvent)
                    pWindow->OnEvent((ScEvent*)&releaseEvent);
            }
            break;
        }

        case XCB_ENTER_NOTIFY:
        {
            xcb_enter_notify_event_t* pEnter = (xcb_enter_notify_event_t*)pEvent;
            pWindow->Mouse = v2_new(pEnter->event_x, pWindow->Size.Height - 1 - pEnter->event_y);

            if (pWindow->OnEvent)
            {
                /* DOCS: мышь вошла в окно: отдаём позицию + IsInside=1,
                   иначе первый hover без движения не сработает. */
                ScMouseMoveEvent moveEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_MouseMove },
                    .X = pEnter->event_x,
                    .Y = to_i32(pWindow->Mouse.Y)
                };
                pWindow->OnEvent((ScEvent*)&moveEvent);

                ScWindowEnterEvent enterEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_WindowEnter },
                    .IsInside = 1
                };
                pWindow->OnEvent((ScEvent*)&enterEvent);
            }
            break;
        }

        case XCB_LEAVE_NOTIFY:
        {
            if (pWindow->OnEvent)
            {
                ScWindowEnterEvent enterEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_WindowEnter },
                    .IsInside = 0
                };
                pWindow->OnEvent((ScEvent*)&enterEvent);
            }
            break;
        }

        case XCB_FOCUS_IN:
        case XCB_FOCUS_OUT:
        {
            if (pWindow->OnEvent)
            {
                ScWindowFocusedEvent focusEvent = {
                    .Base = { .IsHandled = 0, .Type = ScEventType_WindowFocused },
                    .Focused = ((pEvent->response_type & ~0x80) == XCB_FOCUS_IN) ? 1 : 0
                };
                pWindow->OnEvent((ScEvent*)&focusEvent);
            }
            break;
        }

        case XCB_XKB_MAP_NOTIFY:
        {
            xcb_xkb_map_notify_event_t* pMapNotify = (xcb_xkb_map_notify_event_t*)pEvent;
            sc_log_info("Keyboard mapping changed via XKB");

            // Обновляем key symbols
            xcb_key_symbols_free(pXcbLinux->pSymbols);
            pXcbLinux->pSymbols = xcb_key_symbols_alloc(pXcbLinux->pConnection);

            ScKeyboardMappingEvent mapEvent = { .Base.Type = ScEventType_KeyboardMapping };
            if (pWindow->OnEvent)
            {
                pWindow->OnEvent((ScEvent*)&mapEvent);
            }
            break;
        }

        case XCB_MOTION_NOTIFY:
        {
            xcb_motion_notify_event_t* pMotion = (xcb_motion_notify_event_t*)pEvent;
            /* DOCS: Y-вверх, origin - левый НИЗ (как у Win32) */
            pWindow->Mouse = v2_new(pMotion->event_x, pWindow->Size.Height - 1 - pMotion->event_y);

            if (pWindow->IsGrabed)
            {
                i32 dx = 0, dy = 0;

                if (pXcbLinux->MousePrev.X != -1 && pXcbLinux->MousePrev.Y != -1)
                {
                    dx = pWindow->Mouse.X - pXcbLinux->MousePrev.X;
                    dy = pWindow->Mouse.Y - pXcbLinux->MousePrev.Y;
                    if (dx == 0 && dy == 0)
                        continue;
                }

                pWindow->Mouse = v2_new(pWindow->Size.Width / 2, pWindow->Size.Height / 2);
                ScMouseMoveEvent posEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_MouseMove },
                    .X = dx,
                    .Y = -dy // make a flag for inverted Y
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&posEvent);
                }

                // === ВАЖНО: Центрируем курсор ===
                uint16_t centerX = pWindow->Size.Width / 2;
                uint16_t centerY = pWindow->Size.Height / 2;

                xcb_warp_pointer(pXcbLinux->pConnection,
                    XCB_NONE,          // from_window
                    pXcbLinux->Window, // to_window
                    0,
                    0,
                    0,
                    0, // src x,y,w,h
                    centerX,
                    centerY); // новая позиция

                xcb_flush(pXcbLinux->pConnection);

                // Обновляем предыдущую позицию — теперь она центр
                pXcbLinux->MousePrev = v2_new(centerX, centerY);
            }
            else
            {

                ScMouseMoveEvent posEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_MouseMove },
                    .X = pWindow->Mouse.X,
                    .Y = pWindow->Mouse.Y
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&posEvent);
                }
            }

            break;
        }

        case XCB_CONFIGURE_NOTIFY:
        {
            xcb_configure_notify_event_t* pCfg = (xcb_configure_notify_event_t*)pEvent;
            // printf("Conf notify\n");

            // Window resize event
            v2 siz = pWindow->Size;
            v2 pos = pWindow->Position;
            if (siz.Width != pCfg->width || siz.Height != pCfg->height)
            {
                pWindow->Size = v2_new(pCfg->width, pCfg->height);
                if (pWindow->pGraphics)
                    sc_window_graphics_resize(pWindow);

                ScWindowResizeEvent resizeEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_WindowResized },
                    .Width = pCfg->width,
                    .Height = pCfg->height
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&resizeEvent);
                }
            }
            else if (pos.X != pCfg->x || pos.Y != pCfg->y)
            {
                pWindow->Position = v2_new(pCfg->x, pCfg->y);
                ScWindowPositionEvent posEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_WindowMoved },
                    .Position = pWindow->Position
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&posEvent);
                }
            }
            break;
        }

        case XCB_CLIENT_MESSAGE:
        {
            xcb_client_message_event_t* pMsg = (xcb_client_message_event_t*)pEvent;


            ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
            xcb_connection_t* pConnection = pXcbLinux->pConnection;

            xcb_atom_t deleteWindow = xcb_get_atom(pConnection, "WM_DELETE_WINDOW");
            xcb_atom_t wmState = xcb_get_atom(pConnection, "_NET_WM_STATE");
            xcb_atom_t wmStateFull = xcb_get_atom(pConnection, "_NET_WM_STATE_FULLSCREEN");
            xcb_atom_t wmStateHidden = xcb_get_atom(pConnection, "_NET_WM_STATE_HIDDEN");

            if (pMsg->type == wmState)
            {
                // Fullscreen toggle
                if (pMsg->data.data32[1] == wmStateFull || pMsg->data.data32[2] == wmStateFull)
                {
                    i32 is_fullscreen = (pMsg->data.data32[0] == 1); // _NET_WM_STATE_ADD

                    ScWindowMaximizedEvent maxEvent = {
                        .Base = {
                            .IsHandled = 0,
                            .Type = ScEventType_WindowMaximized },
                    };

                    if (pWindow->OnEvent)
                    {
                        pWindow->OnEvent((ScEvent*)&maxEvent);
                    }
                }
                // Minimize (window hidden)
                else if (pMsg->data.data32[1] == wmStateHidden || pMsg->data.data32[2] == wmStateHidden)
                {

                    i32 is_minimized = (pMsg->data.data32[0] == 1); // _NET_WM_STATE_ADD

                    ScWindowHiddenEvent hiddenEvent = {
                        .Base = {
                            .IsHandled = 0,
                            .Type = ScEventType_WindowHidden },
                    };

                    if (pWindow->OnEvent)
                    {
                        pWindow->OnEvent((ScEvent*)&hiddenEvent);
                    }
                }
            }
            else if (deleteWindow == pMsg->data.data32[0])
            {
                ScWindowCloseEvent close = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_WindowClosed }
                };
                pWindow->OnEvent((ScEvent*)&close);
            }

            break;
        }

        default:
        {
            // printf("Event that doesnot have 'case'\n");
            break;
        }
        }

        free(pEvent);
    }
}

static void
xcb_sc_window_set_title(ScWindow* pWindow, char* pTitle)
{
    // First get the UTF8_STRING atom

    i64 titleLength = sc_string_get_length(pTitle);
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
    xcb_connection_t* conn = pXcbLinux->pConnection;

    xcb_intern_atom_cookie_t utf8Atom = xcb_intern_atom(conn, 0, sc_string_get_length("UTF8_STRING"), "UTF8_STRING");
    xcb_intern_atom_cookie_t wmNetNameAtom = xcb_intern_atom(conn, 0, sc_string_get_length("_NET_WM_NAME"), "_NET_WM_NAME");
    xcb_intern_atom_cookie_t wmNameAtom = xcb_intern_atom(conn, 0, sc_string_get_length("WM_NAME"), "WM_NAME");

    xcb_intern_atom_reply_t* pUtf8NameReplay = xcb_intern_atom_reply(conn, utf8Atom, NULL);
    xcb_intern_atom_reply_t* wmNameReply = xcb_intern_atom_reply(conn, wmNetNameAtom, NULL);
    xcb_intern_atom_reply_t* pWmNameReply = xcb_intern_atom_reply(conn, wmNameAtom, NULL);

    if (!pUtf8NameReplay || !wmNameReply || !pWmNameReply)
    {
        free(pUtf8NameReplay);
        free(wmNameReply);
        free(pWmNameReply);
        // handle error
        return;
    }

    // Set UTF-8 window title using _NET_WM_NAME
    xcb_change_property(pXcbLinux->pConnection,
        XCB_PROP_MODE_REPLACE,
        pXcbLinux->Window,
        wmNameReply->atom,     // _NET_WM_NAME
        pUtf8NameReplay->atom, // UTF8_STRING
        8,                     // format
        titleLength,
        pTitle);

    // Also set legacy WM_NAME property (some old apps might look for this)
    xcb_change_property(pXcbLinux->pConnection,
        XCB_PROP_MODE_REPLACE,
        pXcbLinux->Window,
        pWmNameReply->atom, // WM_NAME
        XCB_ATOM_STRING,
        8, // format
        titleLength,
        pTitle);

    free(pUtf8NameReplay);
    free(wmNameReply);
    free(pWmNameReply);

    // Flush the connection to ensure the request is sent
    xcb_flush(pXcbLinux->pConnection);
}

static void
xcb_sc_window_set_headless(ScWindow* pWindow, i32 isSet)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);

    xcb_connection_t* pConnection = pXcb->pConnection;

    // Set _MOTIF_WM_HINTS to disable decorations
    xcb_atom_t motifWmHint = xcb_get_atom(pConnection, "_MOTIF_WM_HINTS");

    if (motifWmHint == XCB_NONE)
    {
        sc_log_erro("motifWmHint not found");
        return;
    }

    const u32 MWM_HINTS_DECORATIONS = (1L << 1);

    struct
    {
        u32 Flags;
        u32 Functions;
        u32 Decorations;
        i32 InputMode;
        u32 HintsStatus;
    } hints = {
        .Flags = MWM_HINTS_DECORATIONS,
        .Decorations = isSet // 0 = no decorations (borderless)
    };
    xcb_change_property(
        pConnection,
        XCB_PROP_MODE_REPLACE,
        pXcb->Window,
        motifWmHint,
        motifWmHint,
        32,
        sizeof(hints) / 4,
        &hints);

    xcb_flush(pConnection);
}

static void
xcb_sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    xcb_connection_t* pConnection = pXcb->pConnection;
    xcb_window_t window = pXcb->Window;

    xcb_atom_t wmState = xcb_get_atom(pConnection, "_NET_WM_STATE");
    xcb_atom_t wmStateHidden = xcb_get_atom(pConnection, "_NET_WM_STATE_FULLSCREEN");

    xcb_client_message_event_t event = {
        .response_type = XCB_CLIENT_MESSAGE,
        .format = 32,
        .sequence = 0,
        .window = window,
        .type = wmState,
        .data = {
            .data32 = {
                isSet, // _NET_WM_STATE_ADD/_REMOVE
                wmStateHidden,
                0,
                0,
                0 } }
    };

    xcb_send_event(pConnection, 0, xcb_setup_roots_iterator(xcb_get_setup(pConnection)).data->root, XCB_EVENT_MASK_SUBSTRUCTURE_REDIRECT | XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY, (const char*)&event);

    xcb_flush(pConnection);
}

static void
xcb_sc_window_set_above(ScWindow* pWindow, i32 isSet)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
    xcb_atom_t wmAtom = xcb_get_atom(pXcbLinux->pConnection, "_NET_WM_STATE");
    xcb_atom_t wmAboveAtom = xcb_get_atom(pXcbLinux->pConnection, "_NET_WM_STATE_ABOVE");

    if (wmAtom == XCB_NONE || wmAboveAtom == XCB_NONE)
    {
        sc_log_erro("wm atoms failed");
        sc_guard(0);
        return;
    }

    xcb_client_message_event_t event = {
        .response_type = XCB_CLIENT_MESSAGE,
        .format = 32,
        .sequence = 0,
        .window = pXcbLinux->Window,
        .type = wmAtom,
        .data = {
            .data32 = {
                isSet, // _NET_WM_STATE_ADD (1) or _NET_WM_STATE_REMOVE (0)
                wmAboveAtom,
                0, // Second property (none)
                0, // Source indication (0 = normal application)
                0 } }
    };

    // Send the event to the root window
    xcb_send_event(pXcbLinux->pConnection, 0, xcb_setup_roots_iterator(xcb_get_setup(pXcbLinux->pConnection)).data->root, XCB_EVENT_MASK_SUBSTRUCTURE_REDIRECT | XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY, (const char*)&event);

    xcb_flush(pXcbLinux->pConnection);
}

static void
xcb_sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    if (isVisible)
    {
        xcb_change_window_attributes(pXcb->pConnection, pXcb->Window, XCB_CW_CURSOR, (uint32_t[]) { XCB_NONE });
    }
    else
    {
        xcb_change_window_attributes(pXcb->pConnection, pXcb->Window, XCB_CW_CURSOR, (uint32_t[]) { pXcb->BlankCursor });
    }
    xcb_flush(pXcb->pConnection);
}

static void
xcb_sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    // Мгновенно возвращаем курсор в центр
    xcb_warp_pointer(pXcb->pConnection, XCB_NONE, pXcb->Window, 0, 0, 0, 0, x, y);
    xcb_flush(pXcb->pConnection);
}

static void
xcb_sc_window_set_position(ScWindow* pWindow, i32 x, i32 y)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);

    // Values array for X and Y position
    u32 values[] = { (u32)x, (u32)y };

    // Configure window position
    xcb_configure_window(
        pXcbLinux->pConnection,
        pXcbLinux->Window,
        XCB_CONFIG_WINDOW_X | XCB_CONFIG_WINDOW_Y,
        values);

    // Update window's position in our struct
    pWindow->Position = v2_new(x, y);

    // Flush the request to ensure it's sent
    xcb_flush(pXcbLinux->pConnection);
}

static ScKey
xcb_sc_key_from_native(i32 native)
{
    switch (native)
    {
        // Numbers
    case XK_0:
        return ScKey_0;
    case XK_1:
        return ScKey_1;
    case XK_2:
        return ScKey_2;
    case XK_3:
        return ScKey_3;
    case XK_4:
        return ScKey_4;
    case XK_5:
        return ScKey_5;
    case XK_6:
        return ScKey_6;
    case XK_7:
        return ScKey_7;
    case XK_8:
        return ScKey_8;
    case XK_9:
        return ScKey_9;

    // Numpad Numbers
    case XK_KP_0:
        return ScKey_NP_0;
    case XK_KP_1:
        return ScKey_NP_1;
    case XK_KP_2:
        return ScKey_NP_2;
    case XK_KP_3:
        return ScKey_NP_3;
    case XK_KP_4:
        return ScKey_NP_4;
    case XK_KP_5:
        return ScKey_NP_5;
    case XK_KP_6:
        return ScKey_NP_6;
    case XK_KP_7:
        return ScKey_NP_7;
    case XK_KP_8:
        return ScKey_NP_8;
    case XK_KP_9:
        return ScKey_NP_9;

    // Numpad Keys
    case XK_Num_Lock:
        return ScKey_NP_Lock;
    case XK_KP_Divide:
        return ScKey_NP_Div;
    case XK_KP_Multiply:
        return ScKey_NP_Mul;
    case XK_KP_Subtract:
        return ScKey_NP_Min;
    case XK_KP_Add:
        return ScKey_NP_Add;
    case XK_KP_Enter:
        return ScKey_NP_Enter;
    case XK_KP_Separator:
    case XK_KP_Decimal:
        return ScKey_NP_Comma;

    // Upper right panel
    case XK_Print:
        return ScKey_PrintScreen;
    case XK_Scroll_Lock:
        return ScKey_ScrollLock;
    case XK_Pause:
        return ScKey_PauseBreak;

    // Mid right panel
    case XK_Insert:
        return ScKey_Insert;
    case XK_Delete:
        return ScKey_Delete;
    case XK_Home:
        return ScKey_Home;
    case XK_End:
        return ScKey_End;
    case XK_Page_Up:
        return ScKey_PageUp;
    case XK_Page_Down:
        return ScKey_PageDown;
    case XK_Caps_Lock:
        return ScKey_CapsLock;

    // Arrow keys
    case XK_Up:
        return ScKey_Up;
    case XK_Left:
        return ScKey_Left;
    case XK_Down:
        return ScKey_Down;
    case XK_Right:
        return ScKey_Right;

    // Letters (lowercase and uppercase map to same ScKey)
    case XK_q:
    case XK_Q:
        return ScKey_Q;
    case XK_w:
    case XK_W:
        return ScKey_W;
    case XK_e:
    case XK_E:
        return ScKey_E;
    case XK_r:
    case XK_R:
        return ScKey_R;
    case XK_t:
    case XK_T:
        return ScKey_T;
    case XK_y:
    case XK_Y:
        return ScKey_Y;
    case XK_u:
    case XK_U:
        return ScKey_U;
    case XK_i:
    case XK_I:
        return ScKey_I;
    case XK_o:
    case XK_O:
        return ScKey_O;
    case XK_p:
    case XK_P:
        return ScKey_P;

    case XK_a:
    case XK_A:
        return ScKey_A;
    case XK_s:
    case XK_S:
        return ScKey_S;
    case XK_d:
    case XK_D:
        return ScKey_D;
    case XK_f:
    case XK_F:
        return ScKey_F;
    case XK_g:
    case XK_G:
        return ScKey_G;
    case XK_h:
    case XK_H:
        return ScKey_H;
    case XK_j:
    case XK_J:
        return ScKey_J;
    case XK_k:
    case XK_K:
        return ScKey_K;
    case XK_l:
    case XK_L:
        return ScKey_L;

    case XK_z:
    case XK_Z:
        return ScKey_Z;
    case XK_x:
    case XK_X:
        return ScKey_X;
    case XK_c:
    case XK_C:
        return ScKey_C;
    case XK_v:
    case XK_V:
        return ScKey_V;
    case XK_b:
    case XK_B:
        return ScKey_B;
    case XK_n:
    case XK_N:
        return ScKey_N;
    case XK_m:
    case XK_M:
        return ScKey_M;

    // Functional keys
    case XK_grave:
    case XK_asciitilde:
        return ScKey_Grave;
    case XK_minus:
    case XK_underscore:
        return ScKey_Min;
    case XK_equal:
    case XK_plus:
        return ScKey_Equal;
    case XK_Tab:
        return ScKey_Tab;
    case XK_Shift_L:
        return ScKey_Shift;
    case XK_Control_L:
        return ScKey_Ctrl;
    case XK_Alt_L:
        return ScKey_Alt;
    case XK_Super_L:
        return ScKey_Super;
    case XK_space:
        return ScKey_Space;

    case XK_comma:
    case XK_less:
        return ScKey_Comma;
    case XK_period:
    case XK_greater:
        return ScKey_Dot;
    case XK_slash:
    case XK_question:
        return ScKey_Slash;

    case XK_Shift_R:
        return ScKey_Shift_Right;
    case XK_Alt_R:
        return ScKey_Alt_Right;
    case XK_Control_R:
        return ScKey_Ctrl_Right;
    case XK_Super_R:
        return ScKey_Super_Right;
    case XK_Menu:
        return ScKey_Menu;
    case XK_BackSpace:
        return ScKey_Backspace;

    case XK_Escape:
        return ScKey_Escape;

    // Function keys
    case XK_F1:
        return ScKey_F1;
    case XK_F2:
        return ScKey_F2;
    case XK_F3:
        return ScKey_F3;
    case XK_F4:
        return ScKey_F4;
    case XK_F5:
        return ScKey_F5;
    case XK_F6:
        return ScKey_F6;
    case XK_F7:
        return ScKey_F7;
    case XK_F8:
        return ScKey_F8;
    case XK_F9:
        return ScKey_F9;
    case XK_F10:
        return ScKey_F10;
    case XK_F11:
        return ScKey_F11;
    case XK_F12:
        return ScKey_F12;

    // Extra keys
    case XK_bracketleft:
    case XK_braceleft:
        return ScKey_Bracket_Left;
    case XK_bracketright:
    case XK_braceright:
        return ScKey_Bracket_Right;
    case XK_semicolon:
    case XK_colon:
        return ScKey_Semicolon;
    case XK_apostrophe:
    case XK_quotedbl:
        return ScKey_Apostrophe;
    case XK_backslash:
    case XK_bar:
        return ScKey_Backslash;
    case XK_Return:
        return ScKey_Enter;

    // Extended function keys
    case XK_F13:
        return ScKey_F13;
    case XK_F14:
        return ScKey_F14;
    case XK_F15:
        return ScKey_F15;
    case XK_F16:
        return ScKey_F16;
    case XK_F17:
        return ScKey_F17;
    case XK_F18:
        return ScKey_F18;
    case XK_F19:
        return ScKey_F19;
    case XK_F20:
        return ScKey_F20;
    case XK_F21:
        return ScKey_F21;
    case XK_F22:
        return ScKey_F22;
    case XK_F23:
        return ScKey_F23;
    case XK_F24:
        return ScKey_F24;
    case XK_F25:
        return ScKey_F25;

    default:
        return ScKey_None;
    }
}

static void
xcb_create_blank_cursor(ScWindowXcbLinux* pWindow)
{
    xcb_connection_t* pConnection = pWindow->pConnection;
    xcb_screen_t* pScreen = pWindow->pScreen;

    // Создаём пустой pixmap 1x1
    xcb_pixmap_t pixmap = xcb_generate_id(pConnection);
    xcb_create_pixmap(pConnection, 1, pixmap, pScreen->root, 1, 1);

    // Создаём курсор из этого pixmap (чёрный и маска — полностью прозрачные)
    xcb_cursor_t cursor = xcb_generate_id(pConnection);
    uint32_t values[] = { 0, 0 }; // fore/red, back/blue — не важно, т.к. маска пустая

    xcb_create_cursor(pConnection,
        cursor,
        pixmap, // source
        pixmap, // mask (тот же, но можно создать отдельный полностью чёрный)
        values[0],
        values[0],
        values[0], // foreground RGB
        values[1],
        values[1],
        values[1], // background RGB
        0,
        0); // x, y hotspot

    // Освобождаем pixmap (курсор держит ссылку)
    xcb_free_pixmap(pConnection, pixmap);

    pWindow->BlankCursor = cursor;
}

static ScKeyMod
xcb_sc_key_mod_from_native(i32 native)
{
    ScKeyMod mod = ScKeyMod_None;

    if (native & XCB_MOD_MASK_SHIFT)
        mod |= ScKeyMod_Shift;
    if (native & XCB_MOD_MASK_CONTROL)
        mod |= ScKeyMod_Ctrl;
    if (native & XCB_MOD_MASK_1)
        mod |= ScKeyMod_Alt;
    if (native & XCB_MOD_MASK_4)
        mod |= ScKeyMod_Super;
    if (native & XCB_MOD_MASK_LOCK)
        mod |= ScKeyMod_CapsLock;
    if (native & XCB_MOD_MASK_2)
        mod |= ScKeyMod_NumLock;
    return mod;
}

static ScMouseKey
xcb_sc_mouse_key_from_native(i32 native)
{
    /*
      DOCS: Номера кнопок X11: 1/2/3 - левая/средняя/правая, 4..7 -
      колесо (обрабатывается как ScEventType_MouseScroll), 8/9 - боковые
      (back/forward, как XButton1/2 у Win32), дальше - прочие.
    */
    switch (native)
    {
    case 1:
        return ScMouseKey_Left;
    case 2:
        return ScMouseKey_Middle;
    case 3:
        return ScMouseKey_Right;
    default:
        break;
    }

    if (native >= 8 && native < 8 + (ScMouseKey_Count - ScMouseKey_Ext_0))
        return ScMouseKey_Ext_0 + (native - 8);

    return ScMouseKey_None;
}

static xcb_atom_t
xcb_get_atom(xcb_connection_t* pXcb, const char* pName)
{
    xcb_intern_atom_cookie_t cookie = xcb_intern_atom(pXcb, 0, sc_string_get_length((char*)pName), pName);
    xcb_intern_atom_reply_t* pReply = xcb_intern_atom_reply(pXcb, cookie, NULL);

    if (!pReply)
    {
        sc_log_erro("Could not get atom %s", pName);
        return XCB_NONE;
    }

    xcb_atom_t atom = pReply->atom;
    free(pReply);
    return atom;
}

static ScWindowXcbLinux*
xcb_sc_window_get_platform(ScWindow* pWindow)
{
    return (ScWindowXcbLinux*)pWindow->pBackend;
}

static ScWindowXcbLinuxGraphics*
xcb_sc_window_get_platform_graphics(ScWindow* pWindow)
{
    /* blit-бэкенд лежит в блоке pBackend сразу после ScWindowXcbLinux */
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    return (ScWindowXcbLinuxGraphics*)(pXcb + 1);
}

//////                               //
//           XCB Graphics            //
//                               //////

/*
  DOCS: XCB blit-бэкенд. Растер общий (ScRaster в pWindow->pGraphics),
  здесь только создание pixmap/gc и вывод готового буфера чанками
  через xcb_put_image (Big Requests).
*/

static void
xcb_sc_window_create_pixmap_gc(ScWindow* pWindow, i32 width, i32 height)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    // Создание пиксмапа
    xcb_pixmap_t pixmap = xcb_generate_id(pXcb->pConnection);
    xcb_create_pixmap(pXcb->pConnection, pXcb->pScreen->root_depth, pixmap, pXcb->Window, width, height);
    // Создание графического контекста
    xcb_gcontext_t gc = xcb_generate_id(pXcb->pConnection);
    uint32_t gc_values = pXcb->pScreen->black_pixel;
    xcb_create_gc(pXcb->pConnection, gc, pixmap, XCB_GC_FOREGROUND, &gc_values);

    pGraphics->Pixmap = pixmap;
    pGraphics->Gc = gc;

    xcb_flush(pXcb->pConnection);
}

static void
xcb_sc_window_graphics_init(ScWindow* pWindow)
{
    // DOCS: Init big request if possible,
    //  otherwise use small batches
    ScWindowXcbLinuxGraphics* pXcbGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    ScWindowXcbLinux* pXcbBackend = xcb_sc_window_get_platform(pWindow);
    const xcb_query_extension_reply_t* pExtReply = xcb_get_extension_data(pXcbBackend->pConnection, &xcb_big_requests_id);

    i32 maxReqSize = 256 * 1024;
    if (pExtReply && pExtReply->present)
    {
        xcb_big_requests_enable_cookie_t enableRequest = xcb_big_requests_enable(pXcbBackend->pConnection);

        xcb_generic_error_t* pError = NULL;
        xcb_big_requests_enable_reply_t* pReply = xcb_big_requests_enable_reply(pXcbBackend->pConnection,
            enableRequest,
            &pError);

        if (pError)
        {
            sc_log_erro("BigRequests activation failed: %d", pError->error_code);
            free(pError);
        }

        if (pReply)
        {
            maxReqSize = pReply->maximum_request_length;
            sc_log_info("XCB max request size: %d Kb", maxReqSize / 1024);
            free(pReply);
        }
    }

    pXcbGraphics->MaxRequestSize = maxReqSize;

    // DOCS: общий растер: буферы сразу на MaxSize окна
    ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;
    i32 maxWidth = pWindow->MaxSize.Width > 0 ? pWindow->MaxSize.Width : pWindow->Size.Width;
    i32 maxHeight = pWindow->MaxSize.Height > 0 ? pWindow->MaxSize.Height : pWindow->Size.Height;
    ScResult res = sc_raster_init(pRaster, pWindow->Size.Width, pWindow->Size.Height, maxWidth, maxHeight);
    if (res != ScResult_Success)
    {
        sc_log_erro("sc_raster_init failed");
        return;
    }

    xcb_sc_window_create_pixmap_gc(pWindow, pWindow->Size.Width, pWindow->Size.Height);
}

static void
xcb_sc_window_graphics_resize(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;

    i32 width = ScMin(pWindow->Size.Width, pRaster->MaxWidth);
    i32 height = ScMin(pWindow->Size.Height, pRaster->MaxHeight);

    /* общий растер: меняет только текущие размеры, память не трогаем */
    sc_raster_resize(pRaster, width, height);

    if (pGraphics->Pixmap)
    {
        xcb_free_pixmap(pXcb->pConnection, pGraphics->Pixmap);
    }

    if (pGraphics->Gc)
    {
        xcb_free_gc(pXcb->pConnection, pGraphics->Gc);
    }

    xcb_sc_window_create_pixmap_gc(pWindow, width, height);
}

static void
xcb_sc_window_graphics_swap_buffers(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;

    /* забираем готовый кадр у растера, рисование идёт дальше */
    ScRasterBuffer frame = sc_raster_swap(pRaster);

    u32 chunkSize = pGraphics->MaxRequestSize;
    u32 width = frame.Width;
    u32 height = frame.Height;

    i32 chunkHeight = chunkSize / (width * 4);
    u32 stride = width * 4;
    u8* pRead = (u8*)frame.pData;

    for (i32 y = 0; y < (i32)height; y += chunkHeight)
    {
        u32 currentHeight = ScMin(chunkHeight, (i32)height - y);
        xcb_put_image(pXcb->pConnection,
            XCB_IMAGE_FORMAT_Z_PIXMAP,
            pGraphics->Pixmap,
            pGraphics->Gc,
            width,
            currentHeight,
            0,
            y,
            0,
            pXcb->pScreen->root_depth,
            currentHeight * stride,
            (const u8*)pRead);
        pRead += currentHeight * stride;
    }

    xcb_copy_area(pXcb->pConnection,
        pGraphics->Pixmap,
        pXcb->Window,
        pGraphics->Gc,
        0,
        0,
        0,
        0,
        pWindow->Size.Width,
        pWindow->Size.Height);

    xcb_flush(pXcb->pConnection);
}

#endif // SC_WINDOW_XCB

#if defined(SC_WINDOW_WIN32)

/*
  DOCS: WIN32-бэкенд (Windows): окно через RegisterClassExA/
  CreateWindowExA, события через WndProc/PeekMessageA, вывод
  растера через CreateDIBSection (32bpp top-down DIB) + BitBlt.
  Растер общий (ScRaster в pWindow->pGraphics).

  NOTE: машина без GPU - software rendering через GDI, Vulkan
  не используется. Y-ориентация растера (origin слева внизу)
  совпадает с top-down DIB (biHeight < 0).
*/

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <windowsx.h> /* GET_X_LPARAM / GET_Y_LPARAM */

typedef struct
{
    HWND Hwnd;
    v2 MousePrev;     /* прошлая позиция мыши для grab-режима (-1 = нет) */
    i32 IsTrackingMouse; /* TrackMouseEvent уже включён */
} ScWindowWin32;

/*
  DOCS: Платформенный blit-бэкенд WIN32: DIB, в который копируется
  готовый кадр растера, и memory-DC для BitBlt в окно.
*/
typedef struct
{
    HDC MemDc;
    HBITMAP Dib;
    HBITMAP DibOld;    /* что было в DC до нашего DIB (вернуть при удалении) */
    void* pDibBits;    /* указатель на пиксели DIB */
    BITMAPINFO BmpInfo;
} ScWindowWin32Graphics;

static ScKeyMod win32_sc_key_mod_from_native(void);
static ScWindowWin32* win32_sc_window_get_platform(ScWindow* pWindow);
static ScWindowWin32Graphics* win32_sc_window_get_platform_graphics(ScWindow* pWindow);
static LRESULT CALLBACK win32_sc_wnd_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

/*
  DOCS: Достаёт ScWindow из HWND: GWLP_USERDATA указывает на окно,
  ставится при WM_NCCREATE/WM_CREATE.
*/
static ScWindow*
win32_sc_wnd_get_window(HWND hwnd)
{
    return (ScWindow*)GetWindowLongPtrA(hwnd, GWLP_USERDATA);
}

static void
win32_sc_wnd_send_event(ScWindow* pWindow, ScEvent* pEvent)
{
    if (pWindow->OnEvent)
        pWindow->OnEvent(pEvent);
}

/*
  DOCS: Обработчик сообщений окна. Транслирует WIN32-сообщения в
  ScEvent (KeyPress/Release/Type, MouseMove/Press/Release/Scroll,
  WindowResized/Moved/Closed/Maximized/Focused/Enter/Hidden).
*/
static LRESULT CALLBACK
win32_sc_wnd_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    ScWindow* pWindow = win32_sc_wnd_get_window(hwnd);

    switch (msg)
    {
    case WM_NCCREATE:
    {
        /* привязываем окно к HWND до любой другой обработки */
        CREATESTRUCTA* pCreate = (CREATESTRUCTA*)lParam;
        SetWindowLongPtrA(hwnd, GWLP_USERDATA, (LONG_PTR)pCreate->lpCreateParams);
        return DefWindowProcA(hwnd, msg, wParam, lParam);
    }

    case WM_DESTROY:
    {
        SetWindowLongPtrA(hwnd, GWLP_USERDATA, 0);
        return 0;
    }

    case WM_CLOSE:
    {
        if (pWindow)
        {
            ScWindowCloseEvent closeEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_WindowClosed }
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&closeEvent);
            pWindow->IsAlive = 0;
        }
        return 0;
    }

    case WM_SIZE:
    {
        if (!pWindow)
            break;

        i32 width = LOWORD(lParam);
        i32 height = HIWORD(lParam);
        pWindow->Size = v2_new(width, height);

        if (wParam == SIZE_MAXIMIZED)
        {
            pWindow->IsMaximized = 1;
            ScWindowMaximizedEvent maxEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_WindowMaximized }
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&maxEvent);
        }
        else if (wParam == SIZE_MINIMIZED)
        {
            ScWindowHiddenEvent hiddenEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_WindowHidden }
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&hiddenEvent);
        }

        ScWindowResizeEvent resizeEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_WindowResized },
            .Width = width,
            .Height = height
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&resizeEvent);
        return 0;
    }

    case WM_MOVE:
    {
        if (!pWindow)
            break;

        i32 x = (i16)LOWORD(lParam);
        i32 y = (i16)HIWORD(lParam);
        pWindow->Position = v2_new(x, y);

        ScWindowPositionEvent posEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_WindowMoved },
            .Position = pWindow->Position
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&posEvent);
        return 0;
    }

    case WM_SETFOCUS:
    {
        if (!pWindow)
            break;

        ScWindowFocusedEvent focusEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_WindowFocused },
            .Focused = 1
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&focusEvent);
        return 0;
    }

    case WM_KILLFOCUS:
    {
        if (!pWindow)
            break;

        ScWindowFocusedEvent focusEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_WindowFocused },
            .Focused = 0
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&focusEvent);
        return 0;
    }

    case WM_MOUSEMOVE:
    {
        if (!pWindow)
            break;

        i32 x = GET_X_LPARAM(lParam);
        i32 y = GET_Y_LPARAM(lParam);
        /* Y-инверсия: как в XCB-бэкенде, origin слева внизу */
        pWindow->Mouse = v2_new(x, pWindow->Size.Height - 1 - y);

        /* включаем enter/leave один раз */
        ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
        if (pWin32 && !pWin32->IsTrackingMouse)
        {
            TRACKMOUSEEVENT track = {
                .cbSize = sizeof(TRACKMOUSEEVENT),
                .dwFlags = TME_LEAVE,
                .hwndTrack = hwnd
            };
            if (TrackMouseEvent(&track))
                pWin32->IsTrackingMouse = 1;
        }

        if (pWindow->IsGrabed)
        {
            /* grab: двигаем дельтой, курсор - в центр */
            i32 dx = 0;
            i32 dy = 0;
            if (pWin32->MousePrev.X != -1 && pWin32->MousePrev.Y != -1)
            {
                dx = pWindow->Mouse.X - pWin32->MousePrev.X;
                dy = pWindow->Mouse.Y - pWin32->MousePrev.Y;
            }

            ScMouseMoveEvent posEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_MouseMove },
                .X = dx,
                .Y = -dy
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&posEvent);

            i32 centerX = pWindow->Size.Width / 2;
            i32 centerY = pWindow->Size.Height / 2;
            POINT center = { centerX, centerY };
            ClientToScreen(hwnd, &center);
            SetCursorPos(center.x, center.y);

            pWin32->MousePrev = v2_new(centerX, centerY);
            /* реальная позиция курсора теперь центр */
            pWindow->Mouse = v2_new(centerX, centerY);
        }
        else
        {
            ScMouseMoveEvent posEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_MouseMove },
                .X = pWindow->Mouse.X,
                .Y = pWindow->Mouse.Y
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&posEvent);
        }
        return 0;
    }

    case WM_MOUSELEAVE:
    {
        if (!pWindow)
            break;

        ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
        if (pWin32)
            pWin32->IsTrackingMouse = 0;

        ScWindowEnterEvent enterEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_WindowEnter },
            .IsInside = 0
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&enterEvent);
        return 0;
    }

    case WM_LBUTTONDOWN:
    case WM_MBUTTONDOWN:
    case WM_RBUTTONDOWN:
    case WM_XBUTTONDOWN:
    {
        if (!pWindow)
            break;

        ScMouseKey key = ScMouseKey_None;
        if (msg == WM_LBUTTONDOWN)
            key = ScMouseKey_Left;
        else if (msg == WM_MBUTTONDOWN)
            key = ScMouseKey_Middle;
        else if (msg == WM_RBUTTONDOWN)
            key = ScMouseKey_Right;
        else
            key = ScMouseKey_Ext_0 + HIWORD(wParam) - 1;

        if (key < ScMouseKey_Count)
            pWindow->aMouseKeys[key] = ScAction_Press;

        ScMousePressEvent pressEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_MousePress },
            .Key = key
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&pressEvent);
        return 0;
    }

    case WM_LBUTTONUP:
    case WM_MBUTTONUP:
    case WM_RBUTTONUP:
    case WM_XBUTTONUP:
    {
        if (!pWindow)
            break;

        ScMouseKey key = ScMouseKey_None;
        if (msg == WM_LBUTTONUP)
            key = ScMouseKey_Left;
        else if (msg == WM_MBUTTONUP)
            key = ScMouseKey_Middle;
        else if (msg == WM_RBUTTONUP)
            key = ScMouseKey_Right;
        else
            key = ScMouseKey_Ext_0 + HIWORD(wParam) - 1;

        if (key < ScMouseKey_Count)
            pWindow->aMouseKeys[key] = ScAction_Release;

        ScMouseReleaseEvent releaseEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_MouseRelease },
            .Key = key
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&releaseEvent);
        return 0;
    }

    case WM_MOUSEWHEEL:
    {
        if (!pWindow)
            break;

        ScMouseScrollEvent scrollEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_MouseScroll },
            .Value = GET_WHEEL_DELTA_WPARAM(wParam) / WHEEL_DELTA
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&scrollEvent);
        return 0;
    }

    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
    {
        if (!pWindow)
            break;

        ScKey key = win32_sc_key_from_native((i32)wParam);
        if (key != ScKey_None)
        {
            /* бит 0x40000000 lParam - не первый кадр нажатия => repeat */
            ScAction action = (lParam & (1 << 30)) ? ScAction_Repeat : ScAction_Press;
            pWindow->aKeys[key] = action;
            if (action == ScAction_Press)
                pWindow->aKeyCounter[key] += 1;

            ScKeyPressEvent pressEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_KeyPress },
                .Key = key,
                .KeyMod = win32_sc_key_mod_from_native()
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&pressEvent);
        }

        /* WM_SYSKEYDOWN без обработки: Alt+F4 и т.п. пусть идут в систему */
        if (msg == WM_SYSKEYDOWN)
            return DefWindowProcA(hwnd, msg, wParam, lParam);
        return 0;
    }

    case WM_KEYUP:
    case WM_SYSKEYUP:
    {
        if (!pWindow)
            break;

        ScKey key = win32_sc_key_from_native((i32)wParam);
        if (key != ScKey_None)
        {
            pWindow->aKeys[key] = ScAction_Release;
            pWindow->aKeyCounter[key] = 0;

            ScKeyReleaseEvent releaseEvent = {
                .Base = { .IsHandled = 0, .Type = ScEventType_KeyRelease },
                .Key = key,
                .KeyMod = win32_sc_key_mod_from_native()
            };
            win32_sc_wnd_send_event(pWindow, (ScEvent*)&releaseEvent);
        }

        if (msg == WM_SYSKEYUP)
            return DefWindowProcA(hwnd, msg, wParam, lParam);
        return 0;
    }

    case WM_CHAR:
    {
        if (!pWindow)
            break;

        ScKeyTypeEvent typeEvent = {
            .Base = { .IsHandled = 0, .Type = ScEventType_KeyType },
            .CodePoint = (u32)wParam
        };
        win32_sc_wnd_send_event(pWindow, (ScEvent*)&typeEvent);
        return 0;
    }

    case WM_GETMINMAXINFO:
    {
        if (!pWindow)
            break;

        /* мин/макс размер окна из ScWindowConfig (как WM_NORMAL_HINTS у XCB) */
        MINMAXINFO* pInfo = (MINMAXINFO*)lParam;
        if (pWindow->MinSize.Width > 0)
        {
            pInfo->ptMinTrackSize.x = pWindow->MinSize.Width;
            pInfo->ptMinTrackSize.y = pWindow->MinSize.Height;
        }
        if (pWindow->MaxSize.Width > 0)
        {
            pInfo->ptMaxTrackSize.x = pWindow->MaxSize.Width;
            pInfo->ptMaxTrackSize.y = pWindow->MaxSize.Height;
        }
        return 0;
    }

    case WM_PAINT:
    {
        if (!pWindow)
            break;

        /*
          DOCS: Перерисовка expose: блитим последний показанный кадр
          растера (без swap - активный буфер может быть недорисован).
        */
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        ScWindowWin32Graphics* pGraphics = win32_sc_window_get_platform_graphics(pWindow);
        ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;
        if (pGraphics && pRaster && pGraphics->MemDc && pGraphics->Dib)
        {
            BitBlt(hdc,
                0,
                0,
                pRaster->Width,
                pRaster->Height,
                pGraphics->MemDc,
                0,
                0,
                SRCCOPY);
        }
        EndPaint(hwnd, &ps);
        return 0;
    }

    default:
        break;
    }

    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

/*
  DOCS: Таблица VK_* -> ScKey (полное покрытие ScKey-энума).
*/
static ScKey
win32_sc_key_from_native(i32 native)
{
    switch (native)
    {
        // Numbers
    case '0': return ScKey_0;
    case '1': return ScKey_1;
    case '2': return ScKey_2;
    case '3': return ScKey_3;
    case '4': return ScKey_4;
    case '5': return ScKey_5;
    case '6': return ScKey_6;
    case '7': return ScKey_7;
    case '8': return ScKey_8;
    case '9': return ScKey_9;

        // Numpad Numbers
    case VK_NUMPAD0: return ScKey_NP_0;
    case VK_NUMPAD1: return ScKey_NP_1;
    case VK_NUMPAD2: return ScKey_NP_2;
    case VK_NUMPAD3: return ScKey_NP_3;
    case VK_NUMPAD4: return ScKey_NP_4;
    case VK_NUMPAD5: return ScKey_NP_5;
    case VK_NUMPAD6: return ScKey_NP_6;
    case VK_NUMPAD7: return ScKey_NP_7;
    case VK_NUMPAD8: return ScKey_NP_8;
    case VK_NUMPAD9: return ScKey_NP_9;

        // Numpad Keys
    case VK_NUMLOCK: return ScKey_NP_Lock;
    case VK_DIVIDE: return ScKey_NP_Div;
    case VK_MULTIPLY: return ScKey_NP_Mul;
    case VK_SUBTRACT: return ScKey_NP_Min;
    case VK_ADD: return ScKey_NP_Add;

        // Upper right panel
    case VK_SNAPSHOT: return ScKey_PrintScreen;
    case VK_SCROLL: return ScKey_ScrollLock;
    case VK_PAUSE: return ScKey_PauseBreak;

        // Mid right panel
    case VK_INSERT: return ScKey_Insert;
    case VK_DELETE: return ScKey_Delete;
    case VK_HOME: return ScKey_Home;
    case VK_END: return ScKey_End;
    case VK_PRIOR: return ScKey_PageUp;
    case VK_NEXT: return ScKey_PageDown;
    case VK_CAPITAL: return ScKey_CapsLock;

        // Arrow keys
    case VK_UP: return ScKey_Up;
    case VK_LEFT: return ScKey_Left;
    case VK_DOWN: return ScKey_Down;
    case VK_RIGHT: return ScKey_Right;

        // Letters
    case 'Q': return ScKey_Q;
    case 'W': return ScKey_W;
    case 'E': return ScKey_E;
    case 'R': return ScKey_R;
    case 'T': return ScKey_T;
    case 'Y': return ScKey_Y;
    case 'U': return ScKey_U;
    case 'I': return ScKey_I;
    case 'O': return ScKey_O;
    case 'P': return ScKey_P;
    case 'A': return ScKey_A;
    case 'S': return ScKey_S;
    case 'D': return ScKey_D;
    case 'F': return ScKey_F;
    case 'G': return ScKey_G;
    case 'H': return ScKey_H;
    case 'J': return ScKey_J;
    case 'K': return ScKey_K;
    case 'L': return ScKey_L;
    case 'Z': return ScKey_Z;
    case 'X': return ScKey_X;
    case 'C': return ScKey_C;
    case 'V': return ScKey_V;
    case 'B': return ScKey_B;
    case 'N': return ScKey_N;
    case 'M': return ScKey_M;

        // Functional keys
    case VK_OEM_3: return ScKey_Grave; /* ` ~ */
    case VK_OEM_MINUS: return ScKey_Min;
    case VK_OEM_PLUS: return ScKey_Equal;
    case VK_TAB: return ScKey_Tab;
    case VK_SHIFT: return ScKey_Shift;
    case VK_CONTROL: return ScKey_Ctrl;
    case VK_MENU: return ScKey_Alt;
    case VK_LWIN: return ScKey_Super;
    case VK_SPACE: return ScKey_Space;

    case VK_OEM_COMMA: return ScKey_Comma;
    case VK_OEM_PERIOD: return ScKey_Dot;
    case VK_OEM_2: return ScKey_Slash; /* / ? */

    case VK_RSHIFT: return ScKey_Shift_Right;
    case VK_RMENU: return ScKey_Alt_Right;
    case VK_RCONTROL: return ScKey_Ctrl_Right;
    case VK_RWIN: return ScKey_Super_Right;
    case VK_APPS: return ScKey_Menu;
    case VK_BACK: return ScKey_Backspace;

    case VK_ESCAPE: return ScKey_Escape;

        // Function keys
    case VK_F1: return ScKey_F1;
    case VK_F2: return ScKey_F2;
    case VK_F3: return ScKey_F3;
    case VK_F4: return ScKey_F4;
    case VK_F5: return ScKey_F5;
    case VK_F6: return ScKey_F6;
    case VK_F7: return ScKey_F7;
    case VK_F8: return ScKey_F8;
    case VK_F9: return ScKey_F9;
    case VK_F10: return ScKey_F10;
    case VK_F11: return ScKey_F11;
    case VK_F12: return ScKey_F12;

        // Extra keys
    case VK_OEM_4: return ScKey_Bracket_Left;  /* [ { */
    case VK_OEM_6: return ScKey_Bracket_Right; /* ] } */
    case VK_OEM_1: return ScKey_Semicolon;     /* ; : */
    case VK_OEM_7: return ScKey_Apostrophe;    /* ' " */
    case VK_OEM_5: return ScKey_Backslash;     /* \ | */
    case VK_RETURN: return ScKey_Enter;

        // Extended function keys
    case VK_F13: return ScKey_F13;
    case VK_F14: return ScKey_F14;
    case VK_F15: return ScKey_F15;
    case VK_F16: return ScKey_F16;
    case VK_F17: return ScKey_F17;
    case VK_F18: return ScKey_F18;
    case VK_F19: return ScKey_F19;
    case VK_F20: return ScKey_F20;
    case VK_F21: return ScKey_F21;
    case VK_F22: return ScKey_F22;
    case VK_F23: return ScKey_F23;
    case VK_F24: return ScKey_F24;

    default:
        return ScKey_None;
    }
}

/*
  DOCS: Модификаторы из текущего состояния клавиатуры
  (GetKeyState, вызывается из WndProc при key-событиях).
*/
static ScKeyMod
win32_sc_key_mod_from_native(void)
{
    ScKeyMod mod = ScKeyMod_None;

    if (GetKeyState(VK_SHIFT) & 0x8000)
        mod |= ScKeyMod_Shift;
    if (GetKeyState(VK_CONTROL) & 0x8000)
        mod |= ScKeyMod_Ctrl;
    if (GetKeyState(VK_MENU) & 0x8000)
        mod |= ScKeyMod_Alt;
    if ((GetKeyState(VK_LWIN) | GetKeyState(VK_RWIN)) & 0x8000)
        mod |= ScKeyMod_Super;
    if (GetKeyState(VK_CAPITAL) & 0x0001)
        mod |= ScKeyMod_CapsLock;
    if (GetKeyState(VK_NUMLOCK) & 0x0001)
        mod |= ScKeyMod_NumLock;

    return mod;
}

static ScWindowWin32*
win32_sc_window_get_platform(ScWindow* pWindow)
{
    return (ScWindowWin32*)pWindow->pBackend;
}

static ScWindowWin32Graphics*
win32_sc_window_get_platform_graphics(ScWindow* pWindow)
{
    /* blit-бэкенд лежит в блоке pBackend сразу после ScWindowWin32 */
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    return (ScWindowWin32Graphics*)(pWin32 + 1);
}

static void
win32_sc_window_create(ScWindow* pScWindow, ScWindowConfig conf)
{
    static i32 isClassRegistered = 0;
    if (!isClassRegistered)
    {
        WNDCLASSEXA wc = {
            .cbSize = sizeof(WNDCLASSEXA),
            .style = CS_HREDRAW | CS_VREDRAW,
            .lpfnWndProc = win32_sc_wnd_proc,
            .hInstance = GetModuleHandleA(NULL),
            .hCursor = LoadCursorA(NULL, (LPCSTR)IDC_ARROW),
            .lpszClassName = "ScWindowClass",
        };
        if (!RegisterClassExA(&wc))
        {
            sc_window_fatal("RegisterClassExA failed");
            return;
        }
        isClassRegistered = 1;
    }

    /*
      DOCS: Создаём окно с обычным стилем (resize-рамка), размер в
      клиентских координатах через AdjustWindowRect (у XCB Size -
      это клиентская область).
    */
    DWORD style = WS_OVERLAPPEDWINDOW | WS_VISIBLE;
    DWORD styleEx = 0;

    RECT rect = {
        .left = 0,
        .top = 0,
        .right = conf.Size.Width,
        .bottom = conf.Size.Height
    };
    AdjustWindowRect(&rect, style, FALSE);

    i32 outerWidth = rect.right - rect.left;
    i32 outerHeight = rect.bottom - rect.top;

    /*
      DOCS: Позиция по умолчанию (0,0) = центр экрана рабочего
      стола. Заданная позиция используется как есть.
    */
    i32 posX = conf.Position.X;
    i32 posY = conf.Position.Y;
    if (posX == 0 && posY == 0)
    {
        posX = (GetSystemMetrics(SM_CXSCREEN) - outerWidth) / 2;
        posY = (GetSystemMetrics(SM_CYSCREEN) - outerHeight) / 2;
    }

    HWND hwnd = CreateWindowExA(
        styleEx,
        "ScWindowClass",
        conf.pName ? conf.pName : "Sc",
        style,
        posX,
        posY,
        outerWidth,
        outerHeight,
        NULL, NULL, GetModuleHandleA(NULL),
        pScWindow /* GWLP_USERDATA через WM_NCCREATE */
    );

    if (!hwnd)
    {
        sc_window_fatal("CreateWindowExA failed");
        return;
    }

    pScWindow->Size = conf.Size;
    pScWindow->MinSize = conf.MinSize;
    pScWindow->MaxSize = conf.MaxSize;
    pScWindow->pName = conf.pName;

    /*
      DOCS: pBackend = [ScWindowWin32][ScWindowWin32Graphics],
      растер (общий) аллоцируется отдельно в pGraphics.
    */
    u64 allocatedSize = sizeof(ScWindowWin32);
    if (conf.UseGraphics)
        allocatedSize += sizeof(ScWindowWin32Graphics);

    void* pShared = sc_memory_allocate(allocatedSize);
    memset(pShared, 0, (size_t)allocatedSize);
    pScWindow->pBackend = pShared;

    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pScWindow);
    pWin32->Hwnd = hwnd;
    pWin32->MousePrev = v2_new(-1, -1);

    if (conf.UseGraphics)
    {
        pScWindow->pGraphics = sc_memory_allocate(sizeof(ScRaster));
        sc_window_graphics_init(pScWindow);
    }

    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);
}

static void
win32_sc_window_destroy(ScWindow* pWindow)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (!pWin32 || !pWin32->Hwnd)
        return;

    /* blit-ресурсы */
    if (pWindow->pGraphics)
    {
        ScWindowWin32Graphics* pGraphics = win32_sc_window_get_platform_graphics(pWindow);
        if (pGraphics->MemDc && pGraphics->Dib)
        {
            SelectObject(pGraphics->MemDc, pGraphics->DibOld);
            DeleteObject(pGraphics->Dib);
        }
        if (pGraphics->MemDc)
            DeleteDC(pGraphics->MemDc);

        /* общий растер */
        sc_raster_free((ScRaster*)pWindow->pGraphics);
        sc_memory_free(pWindow->pGraphics);
        pWindow->pGraphics = ScNull;
    }

    DestroyWindow(pWin32->Hwnd);
    pWin32->Hwnd = NULL;

    sc_memory_free(pWindow->pBackend);
    pWindow->pBackend = ScNull;
    pWindow->IsAlive = 0;
}

static void
win32_sc_window_update(ScWindow* pWindow)
{
    MSG msg;
    while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE))
    {
        if (msg.message == WM_QUIT)
        {
            pWindow->IsAlive = 0;
            break;
        }

        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
}

static void
win32_sc_window_set_title(ScWindow* pWindow, char* pTitle)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (pWin32 && pWin32->Hwnd)
        SetWindowTextA(pWin32->Hwnd, pTitle);
}

static void
win32_sc_window_set_headless(ScWindow* pWindow, i32 isSet)
{
    /*
      DOCS: Headless = без декораций (как _MOTIF_WM_HINTS у XCB).
      Стиль меняем на месте, размер клиента сохраняем.
    */
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (!pWin32 || !pWin32->Hwnd)
        return;

    DWORD style = (DWORD)GetWindowLongPtrA(pWin32->Hwnd, GWL_STYLE);
    if (isSet)
        style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
    else
        style |= WS_OVERLAPPEDWINDOW;

    RECT rect = { .left = 0, .top = 0, .right = pWindow->Size.Width, .bottom = pWindow->Size.Height };
    AdjustWindowRect(&rect, style, FALSE);

    SetWindowLongPtrA(pWin32->Hwnd, GWL_STYLE, (LONG_PTR)style);
    SetWindowPos(pWin32->Hwnd, NULL,
        0, 0,
        rect.right - rect.left, rect.bottom - rect.top,
        SWP_NOMOVE | SWP_NOZORDER | SWP_FRAMECHANGED);
}

static void
win32_sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (!pWin32 || !pWin32->Hwnd)
        return;

    if (isSet)
    {
        MONITORINFO monitorInfo = { .cbSize = sizeof(MONITORINFO) };
        HMONITOR monitor = MonitorFromWindow(pWin32->Hwnd, MONITOR_DEFAULTTONEAREST);
        if (GetMonitorInfoA(monitor, &monitorInfo))
        {
            SetWindowPos(pWin32->Hwnd, HWND_TOP,
                monitorInfo.rcMonitor.left,
                monitorInfo.rcMonitor.top,
                monitorInfo.rcMonitor.right - monitorInfo.rcMonitor.left,
                monitorInfo.rcMonitor.bottom - monitorInfo.rcMonitor.top,
                SWP_NOOWNERZORDER);
            pWindow->IsFullscreen = 1;
        }
    }
    else
    {
        /* обратно: обычный стиль + стартовый размер */
        DWORD style = (DWORD)GetWindowLongPtrA(pWin32->Hwnd, GWL_STYLE) | WS_OVERLAPPEDWINDOW;
        SetWindowLongPtrA(pWin32->Hwnd, GWL_STYLE, (LONG_PTR)style);

        RECT rect = { .left = 0, .top = 0, .right = pWindow->Size.Width, .bottom = pWindow->Size.Height };
        AdjustWindowRect(&rect, style, FALSE);
        SetWindowPos(pWin32->Hwnd, NULL,
            pWindow->Position.X, pWindow->Position.Y,
            rect.right - rect.left, rect.bottom - rect.top,
            SWP_NOZORDER | SWP_FRAMECHANGED);
        pWindow->IsFullscreen = 0;
    }
}

static void
win32_sc_window_set_above(ScWindow* pWindow, i32 isSet)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (!pWin32 || !pWin32->Hwnd)
        return;

    SetWindowPos(pWin32->Hwnd,
        isSet ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE);
}

static void
win32_sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible)
{
    /* ShowCursor считает ссылки: выравниваем по флагу */
    while (ShowCursor(isVisible ? TRUE : FALSE) < (isVisible ? 0 : -1))
    {
    }
}

static void
win32_sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (!pWin32 || !pWin32->Hwnd)
        return;

    POINT pos = { x, y };
    ClientToScreen(pWin32->Hwnd, &pos);
    SetCursorPos(pos.x, pos.y);
}

static void
win32_sc_window_set_position(ScWindow* pWindow, i32 x, i32 y)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    if (!pWin32 || !pWin32->Hwnd)
        return;

    SetWindowPos(pWin32->Hwnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    pWindow->Position = v2_new(x, y);
}

//////                               //
//           WIN32 Graphics           //
//                               //////

/*
  DOCS: WIN32 blit-бэкенд: DIB 32bpp top-down (biHeight < 0) в
  memory-DC. Пиксели DIB напрямую становятся буферами растера -
  нулевое копирование, рисуем прямо в DIB, swap = BitBlt в окно.
*/

static void
win32_sc_window_graphics_init(ScWindow* pWindow)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    ScWindowWin32Graphics* pGraphics = win32_sc_window_get_platform_graphics(pWindow);

    ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;
    i32 maxWidth = pWindow->MaxSize.Width > 0 ? pWindow->MaxSize.Width : pWindow->Size.Width;
    i32 maxHeight = pWindow->MaxSize.Height > 0 ? pWindow->MaxSize.Height : pWindow->Size.Height;

    if (sc_raster_init(pRaster, pWindow->Size.Width, pWindow->Size.Height, maxWidth, maxHeight) != ScResult_Success)
    {
        sc_log_erro("sc_raster_init failed");
        return;
    }

    /* заголовок DIB: 32bpp, top-down: строки в памяти сверху вниз,
       как и у растра (его API при этом Y-вверх) */
    pGraphics->BmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    pGraphics->BmpInfo.bmiHeader.biPlanes = 1;
    pGraphics->BmpInfo.bmiHeader.biBitCount = 32;
    pGraphics->BmpInfo.bmiHeader.biCompression = BI_RGB;
    pGraphics->BmpInfo.bmiHeader.biSizeImage = 0;
    pGraphics->BmpInfo.bmiHeader.biXPelsPerMeter = 0;
    pGraphics->BmpInfo.bmiHeader.biYPelsPerMeter = 0;
    pGraphics->BmpInfo.bmiHeader.biClrUsed = 0;
    pGraphics->BmpInfo.bmiHeader.biClrImportant = 0;

    HDC windowDc = GetDC(pWin32->Hwnd);
    pGraphics->MemDc = CreateCompatibleDC(windowDc);
    ReleaseDC(pWin32->Hwnd, windowDc);

    win32_sc_window_graphics_resize(pWindow);
}

static void
win32_sc_window_graphics_resize(ScWindow* pWindow)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    ScWindowWin32Graphics* pGraphics = win32_sc_window_get_platform_graphics(pWindow);
    ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;

    if (!pWin32 || !pGraphics || !pRaster)
        return;

    i32 width = ScMin(pWindow->Size.Width, pRaster->MaxWidth);
    i32 height = ScMin(pWindow->Size.Height, pRaster->MaxHeight);

    /* общий растер: меняет только текущие размеры */
    sc_raster_resize(pRaster, width, height);

    /* DIB пересоздаётся на оба буфера растера сразу (MaxSize) */
    if (pGraphics->Dib)
    {
        SelectObject(pGraphics->MemDc, pGraphics->DibOld);
        DeleteObject(pGraphics->Dib);
        pGraphics->Dib = NULL;
    }

    pGraphics->BmpInfo.bmiHeader.biWidth = pRaster->MaxWidth;
    /* top-down: первая строка DIB = верхняя строка экрана */
    pGraphics->BmpInfo.bmiHeader.biHeight = -(i32)pRaster->MaxHeight;

    HDC windowDc = GetDC(pWin32->Hwnd);
    pGraphics->Dib = CreateDIBSection(windowDc,
        &pGraphics->BmpInfo,
        DIB_RGB_COLORS,
        &pGraphics->pDibBits,
        NULL,
        0);
    ReleaseDC(pWin32->Hwnd, windowDc);

    if (!pGraphics->Dib)
    {
        sc_log_erro("CreateDIBSection failed");
        return;
    }

    pGraphics->DibOld = (HBITMAP)SelectObject(pGraphics->MemDc, pGraphics->Dib);
}

static void
win32_sc_window_graphics_swap_buffers(ScWindow* pWindow)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    ScWindowWin32Graphics* pGraphics = win32_sc_window_get_platform_graphics(pWindow);
    ScRaster* pRaster = (ScRaster*)pWindow->pGraphics;

    if (!pWin32 || !pGraphics || !pRaster)
        return;

    /* готовый кадр у растера */
    ScRasterBuffer frame = sc_raster_swap(pRaster);

    if (!pGraphics->Dib)
        return;

    /*
      DOCS: Копируем кадр в DIB (memcpy по строкам - растер и DIB
      оба top-down 32bpp), затем BitBlt в окно. Прямой рендер в DIB
      возможен, но буферы растера уже аллоцированы - копия одного
      кадра дешевле усложнения Ownership.
    */
    u32 stride = (u32)frame.Width * 4;
    u8* pWrite = (u8*)pGraphics->pDibBits;
    u8* pRead = (u8*)frame.pData;
    i64 rowBytes = (i64)pRaster->MaxWidth * 4;
    i64 copyBytes = (i64)stride;

    for (i32 y = 0; y < frame.Height; ++y)
    {
        memcpy(pWrite, pRead, copyBytes);
        pWrite += rowBytes;
        pRead += stride;
    }

    HDC windowDc = GetDC(pWin32->Hwnd);
    BitBlt(windowDc,
        0,
        0,
        frame.Width,
        frame.Height,
        pGraphics->MemDc,
        0,
        0,
        SRCCOPY);
    ReleaseDC(pWin32->Hwnd, windowDc);
}

void*
win32_sc_window_get_window(ScWindow* pWindow)
{
    ScWindowWin32* pWin32 = win32_sc_window_get_platform(pWindow);
    return pWin32 ? (void*)pWin32->Hwnd : NULL;
}

void*
win32_sc_window_get_connection(ScWindow* pWindow)
{
    /* у WIN32 нет connection - возвращаем HINSTANCE */
    return (void*)GetModuleHandleA(NULL);
}

#endif // SC_WINDOW_WIN32
