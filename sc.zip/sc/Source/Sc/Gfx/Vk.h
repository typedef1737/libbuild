#if !defined(SC_VK_H) && !defined(SC_NO_GPU)
#define SC_VK_H

#include "Sc/Types.h"
// #include "vulkan_core.h"
// #include <vulkan.h>
#include "Sc/Gfx/Vulkan.h"

/*
  TODO:
  * Smarter physical device pick, use i32 rating for devices and pick the best option
  * IMPL sc_vk_destroy()

*/

#define ScVkInfiniteTime (18446744073709551615ULL)

typedef void (*ScVkMessageDelegate)(const char* pMessage, void* pData);

typedef enum
{
    ScVkWindowPlatform_None = 0,
    ScVkWindowPlatform_Xcb,
    ScVkWindowPlatform_Win64,
} ScVkWindowPlatform;

// TODO: SC_VK_XCB_WINDOW, SC_VK_WIN32_WINDOW
typedef struct
{
#if defined(SC_PLATFORM_WINDOWS)
#elif defined(SC_PLATFORM_LINUX)
    void* pXcbConnection;
    void* pXcbWindow;
#endif // SC_PLATFORM_LINUX
} ScVkWindowBackend;

typedef struct
{
    VkImage Image;
    VkDeviceMemory Memory;
} ScVkImage;

typedef struct
{
    VkImage Image;
    VkDeviceMemory Memory;
    VkImageView View;
} ScTexture;
typedef struct
{
    ScVkImage Image;
    VkImageView View;
    VkSampler Sampler;
} Sc2dTexture;

typedef struct
{
    VkSwapchainKHR Swapchain;
    VkExtent2D Resolution;
    VkSurfaceFormatKHR SurfaceFormat;
    // Put into final render pass
    // VkImage* aImages;
    // VkImageView* aViews;
} ScVkSwapObject;

typedef struct
{
    i8 IsDebug;
    i8 IsVsync;
    v2 WindowSize;
    u32 VulkanVersion;
    i64 UniformBufferSize;
    char* pName;
    ScVkWindowBackend WindowBackend;
    ScVkMessageDelegate OnError;
    ScVkMessageDelegate OnWarning;
} ScVkConfig;

typedef struct
{
    i32 IsVsync;
    VkExtent2D Resolution;
    VkSurfaceFormatKHR SurfaceFormat;
    // DOCS: Can be VK_NULL_HANDLE or 0
    VkSwapchainKHR PrevSwapchain;
} ScVkSwapchainConfig;

typedef struct
{
    VkBuffer Buffer;
    VkDeviceMemory Memory;
} ScVkBuffer;

typedef struct
{
    ScVkBuffer CpuBuffer;
    ScVkBuffer GpuBuffer;
} ScVkSharedBuffer;

typedef struct
{
    const char* pPath;
    VkShaderModule Module;
} ScVkShaderModule;

typedef enum
{
    ScVkStageType_Vertex = 0,
    ScVkStageType_Fragment,
    ScVkStageType_Tesselation_Control,
    ScVkStageType_Tesselation_Evaluation,
} ScVkStageType;

typedef enum
{ // note: mb creatae _Image_Wo_Sample, _Sampler ? :?
    ScVkDescriptorType_Uniform = 0,
    ScVkDescriptorType_Image,
    ScVkDescriptorType_Ssbo,
} ScVkDescriptorType;

typedef struct
{
    ScVkDescriptorType Type;
    char* pName;
    i64 Binding;
    i64 Count;
    u64 Size;
} ScVkDescriptorConfig;

typedef struct
{
    ScVkStageType Type;
    const char* pShaderPath;
    ScVkDescriptorConfig* aDescriptors;
    i32 PipelineIndex;
    i8 PatchControlPoints;
    // DOCS: Fill inside
    i8 DescriptorsCount;
} ScVkStageConfig;

typedef struct
{
    char* pName;
    u64 Size;
    i64 Offset;
    i32 ItemSize;
    i32 BindingIndex;
    i32 PipelineIndex;
} ScVkUniformConfig;

typedef struct
{
    char* pName;
    u64 Size;
    i64 Offset;
    i32 ItemSize;
    i32 BindingIndex;
    i32 PipelineIndex;
} ScVkUniform;

typedef struct
{
    ScVkStageType Type;
    ScVkShaderModule Shader;
    ScVkDescriptorConfig* aDescriptors;
    ScVkUniform* aUniforms;
} ScVkStage;

typedef struct
{
    ScVkStage* aStages;
    VkDescriptorSet Set;
    VkDescriptorSetLayout SetLayout;
    VkDescriptorPool Pool;
} ScVkShaderBridge;

typedef struct
{
    VkFormat Format;
    i32 Offset;
} ScVkAttribute;

struct ScVkRenderPass;

typedef enum
{
    ScVkTopologyType_TriangleList = 0,
    ScVkTopologyType_PointList,
    ScVkTopologyType_LineList,
    ScVkTopologyType_LineStrip,
    ScVkTopologyType_TriangleStrip,
    ScVkTopologyType_TriangleFan,
    ScVkTopologyType_LineListWithAdjacency,
    ScVkTopologyType_LineStripWithAdjacency,
    ScVkTopologyType_TriangleListWithAdjacency,
    ScVkTopologyType_TriangleStripWithAdjacency,
    ScVkTopologyType_PatchList,
} ScVkTopologyType;

VkPrimitiveTopology sc_vk_topology_type_to_vk(ScVkTopologyType type);

typedef enum
{
    ScVkBlendState_Enabled = 0,
    ScVkBlendState_Disabled
} ScVkBlendState;

typedef struct
{
    i8 IsDepthWriteEnabled;
    i32 RenderPassId;
    ScVkStageConfig* aStages;
    ScVkAttribute* aAttributes;
    ScVkTopologyType Topology;

    // DOCS: Can be default value;s
    VkPolygonMode PolygonMode;
    i64 Stride;
    i64 VerticesCount;
    i64 IndicesCount;

    struct
    {
        ScVkBlendState State;
    } Blend;

    // DOCS: Calculated automatically
    i8 StagesCount;
    i8 AttributesCount;
} ScVkPipelineConfig;

typedef struct
{
    i8 IsEnabled;
    i8 IsDepthEnabled;
    char* pName;
    i64 Id;
    i64 RenderPassId;
    VkPipeline Handle;
    VkPipelineLayout Layout;
    ScVkShaderBridge ShaderBridge;
    // todo: remove
    i32 BufferId;
    struct
    {
        i64 IndicesCount;
    } State;
    // ScVkPipelineConfig Config;
} ScVkPipeline;

typedef enum
{
    ScVkAttachmentType_Color = 0,
    ScVkAttachmentType_Depth,
    ScVkAttachmentType_ResolveMultisample
} ScVkAttachmentType;

typedef struct
{
    ScVkAttachmentType Type;
    VkAttachmentDescription Description;
    VkAttachmentReference Reference;
} ScVkAttachment;

typedef enum
{
    ScVkRenderPassBufferingType_None = 0,
    ScVkRenderPassBufferingType_Single = 1,
    ScVkRenderPassBufferingType_Double = 2,
    ScVkRenderPassBufferingType_Triple = 3,
} ScVkRenderPassBufferingType;

typedef struct
{
    ScVkAttachment* aAttachments;
    VkSubpassDependency Dependency;

    v2 Resolution;

    ScVkRenderPassBufferingType BufferingType;

    // AUTO FILLED
    i64 AttachmentsCount;
} ScVkRenderPassConfig;

typedef enum
{
    ScVkRenderPassType_Invalid = 0,
    ScVkRenderPassType_Final,
    ScVkRenderPassType_Custom,
    ScVkRenderPassType_Count
} ScVkRenderPassType;

typedef struct
{
    VkFramebuffer Framebuffer;
    VkImageView* aViews;
    VkImage* aImages;
    VkDeviceMemory* aMemories;
} ScVkFramebuffer;

typedef struct
{
    i64 VerticesOffset;
    i64 IndicesOffset;
    i64 VerticesSize;
    i64 IndicesSize;
} ScVkBufferView;

typedef struct
{
    i32 Id;
    ScVkRenderPassType Type;
    VkRenderPass Handle;
    VkSampleCountFlagBits Samples;
    ScVkFramebuffer* aFramebuffers;
    VkDeviceMemory* aMemories;

    ScVkRenderPassBufferingType BufferingType;
    i64* aPipelineIds;
    i8 FrameIndex;

    ScVkSharedBuffer Vertex;
    ScVkSharedBuffer Index;
    ScVkBufferView* aBufferViews;
} ScVkRenderPass;

typedef struct
{
    struct
    {
        i8 IsDebug;
        i8 IsVsync;
    } Flags;

    struct
    {
        ScVkMessageDelegate OnError;
        ScVkMessageDelegate OnWarning;
    } Messages;

    VkAllocationCallbacks* pAllocator;
    ScVkWindowPlatform WindowPlatform;

#if defined(SC_BUILD_DEBUG)
    struct
    {
        VkDebugUtilsMessengerEXT UtilMessager;
    } Debug;
#endif // SC_BUILD_DEBUG

    VkInstance Handle;
    VkSurfaceKHR Surface;
    VkPhysicalDevice PhysicalDevice;

    VkDevice Device;
    i32 GraphicsQueueIndex;
    i32 PresentationQueueIndex;
    VkQueue GraphicsQueue;
    VkQueue PresentationQueue;

    // todo: place into FINAL-PASS
    VkSemaphore* aImageAvailableSemaphores;
    VkSemaphore* aRenderFinishedSemaphores;
    VkFence* aFrameFences;

    struct
    {
        VkCommandPool GraphicsPool;
        VkCommandBuffer GraphicsBuffer;
        VkCommandBuffer* aList;
    } Cmd;

    ScVkSwapObject Swap;

    struct
    {
        u64 TotalSize;
        ScVkSharedBuffer Buffer;
    } Uniform;

    v2 WindowSize;

    i64 FinalPassId;
    i64 FinalPipeId;
    VkDescriptorImageInfo* aImages;
    i32 SyncIndex;
    Sc2dTexture* aPassesTextures;
    VkSampler DefaultLinearSampler;

    ScVkRenderPass* aRenderPasses;
    ScVkPipeline* aPipelines;
    ScVkUniform* aUniforms;
} ScVk;

/*

  ###################################
  ###################################
  sc_vk
  ###################################
  ###################################

*/

ScVk sc_vk_new(ScVkConfig config);
void sc_vk_destroy(ScVk* pScVk);
void sc_vk_destroy_pipes_and_passes(ScVk* pScVk);
void sc_vk_set_passes_images(ScVk* pScVk, Sc2dTexture* aTextures, i32 texturesCount);
void sc_vk_draw(ScVk* pScVk, i64* aRenderPassIds, i32 renderPassesCount);
void sc_vk_uniform_buffer_allocate(ScVk* pScVk);
void sc_vk_uniform_buffer_free(ScVk* pScVk);

i32 sc_vk_get_next_pipeline_index(ScVk* pScVk);
ScVkPipeline* sc_vk_get_pipeline(ScVk* pScVk, i32 pipeId);
i32 sc_vk_set_pipeline(ScVk* pScVk, i32 pipeId, ScVkPipeline pipe);
i32 sc_vk_get_next_render_pass_index(ScVk* pScVk);
ScVkRenderPass* sc_vk_get_render_pass(ScVk* pScVk, i32 passId);
i32 sc_vk_register_render_pass(ScVk* pScVk, ScVkRenderPass* pPass);

// void sc_vk_final_pass_create(ScVk* pScVk);
// void sc_vk_final_pass_destroy(ScVk* pScVk);

/*

  ###################################
  ###################################
  sc_vk_sync
  ###################################
  ###################################

*/

VkSemaphore sc_vk_sync_semaphore_new(ScVk* pScVk, VkSemaphoreCreateFlags createFlags);
VkFence sc_vk_fence_new(ScVk* pScVk, VkFenceCreateFlags fenceFlags);

/*

  ###################################
  ###################################
  sc_vk_cmd
  ###################################
  ###################################

*/

VkCommandPool sc_vk_cmd_pool_new(ScVk* pScVk, i32 queueIndex);
VkCommandBuffer sc_vk_cmd_buffer_new(ScVk* pScVk, VkCommandPool vkCommandPool);

/*

  ###################################
  ###################################
  sc_vk_swapchain
  ###################################
  ###################################

*/

ScVkSwapObject sc_vk_swapchain_new(ScVk* pScVk, ScVkSwapchainConfig config);
void sc_vk_swapchain_destroy(ScVk* pScVk, ScVkSwapObject object);

/*

  ###################################
  ###################################
  sc_vk_image/view
  ###################################
  ###################################

*/

ScVkImage sc_vk_image_new(ScVk* pScVk, VkImageCreateInfo vkImageCreateInfo, VkMemoryPropertyFlags memoryProperyFlag);
void sc_vk_image_destroy(ScVk* pScVk, VkImage image);
VkImageView sc_vk_image_view_new(ScVk* pScVk, VkImageViewCreateInfo vkImageViewCreateInfo);
void sc_vk_image_change_layout(ScVk* pScVk, VkImage vkImage, VkImageLayout vkOldLayout, VkImageLayout vkNewLayout, VkFormat vkFormat, i32 mipLevels);
void sc_vk_image_change_layout_ext(ScVk* pScVk, VkImage vkImage, VkImageLayout vkOldLayout, VkImageLayout vkNewLayout, VkPipelineStageFlags srcPipe, VkPipelineStageFlags dstPipe, i32 mipLevels);
void sc_vk_image_from_buffer(ScVk* pScVk, VkImage vkImage, VkBuffer vkBuffer, i32 width, i32 height);

/*

  ###################################
  ###################################
  sc_vk_texture
  ###################################
  ###################################

*/

ScTexture sc_vk_texture_new(ScVk* pScVk, VkImageCreateInfo imageCreateInfo, VkImageViewCreateInfo imageViewCreateInfo, VkMemoryPropertyFlags memoryProperyFlag);
void sc_vk_texture_destroy(ScVk* pScVk, ScTexture texture);
VkSampler sc_vk_sampler_create(ScVk* pScVk, VkFilter minFilter, VkFilter maxFilter, i32 mipLevels);
void sc_vk_sampler_destroy(ScVk* pScVk, VkSampler sampler);
Sc2dTexture sc_vk_2d_texture_new(ScVk* pScVk, void* pData, i32 width, i32 height, VkFormat vkFormat);
void sc_vk_2d_texture_destroy(ScVk* pScVk, Sc2dTexture sc2dTexture);

/*

  ###################################
  ###################################
  sc_vk_get
  ###################################
  ###################################

*/

VkPhysicalDevice* sc_vk_get_devices(ScVk* pScVk);
VkExtensionProperties* sc_vk_get_device_extensions(ScVk* pScVk, VkPhysicalDevice device);
const char* sc_vk_device_type_to_string(VkPhysicalDeviceType type);
VkQueueFamilyProperties* sc_vk_get_queues_family_properties(ScVk* pScVk);
VkSurfaceFormatKHR* sc_vk_get_device_surface_formats(ScVk* pScVk);
VkPresentModeKHR* sc_vk_get_device_surface_modes(ScVk* pScVk);
VkSurfaceCapabilitiesKHR sc_vk_get_surface_capabilities(ScVk* pScVk);
VkImage* sc_vk_get_swap_images(ScVk* pScVk, VkSwapchainKHR swapchain);
i32 sc_vk_get_memory_type(ScVk* pScVk, VkMemoryRequirements memoryRequirements, VkMemoryPropertyFlags vkMemoryPropertyFlags);

/*

  ###################################
  ###################################
  sc_vk_shader
  ###################################
  ###################################

*/

typedef struct
{
    ScVk* pScVk;
    char* pSourcePath;
    char* pBinPath;
    i32 IsOmpimize;
} ScVkShaderCompileConfig;

VkShaderModule sc_vk_shader_new(ScVkShaderCompileConfig config);
void sc_vk_shader_destroy(ScVk* pScVk, VkShaderModule shaderModule);

/*

  ###################################
  ###################################
  sc_vk_buffer
  ###################################
  ###################################

*/

ScVkBuffer sc_vk_buffer_new(ScVk* pScVk, u64 size, VkBufferUsageFlags usage, VkMemoryPropertyFlags memoryPropertyFlags);

ScVkSharedBuffer sc_vk_vertex_buffer_new(ScVk* pScVk, u64 size);
ScVkSharedBuffer sc_vk_index_buffer_new(ScVk* pScVk, u64 size);
ScVkSharedBuffer sc_vk_uniform_buffer_new(ScVk* pScVk, u64 size);

void sc_vk_buffer_destroy(ScVk* pScVk, ScVkBuffer buffer);
void sc_vk_vertex_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer buffer);
void sc_vk_index_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer index);

// note: mb we don;t need uniform buffer creation as separate function
void sc_vk_uniform_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer uniform);

void sc_vk_shared_buffer_set_data(ScVk* pScVk, ScVkSharedBuffer* pScVkSharedBuffer, void* pData, u64 offset, u64 dataSize);
void sc_vk_shared_buffer_destroy(ScVk* pScVk, ScVkSharedBuffer buffer);

/*

  ###################################
  ###################################
  sc_vk_uniform
  ###################################
  ###################################

*/

ScVkUniform sc_vk_uniform_new(ScVk* pScVk, ScVkUniformConfig cfg);
void sc_vk_uniform_destroy(ScVk* pScVk, ScVkUniform uniform);
i32 sc_vk_uniform_set(ScVk* pScVk, ScVkUniform* pUniform, void* pData, u64 offset, u64 size);

/*

  ###################################
  ###################################
  sc_vk_cmd
  ###################################
  ###################################

*/

VkCommandBuffer sc_vk_cmd_begin(ScVk* pScVk);
void sc_vk_cmd_end(ScVk* pScVk, VkCommandBuffer vkCmdBuffer);

/*

  ###################################
  ###################################
  sc_vk_frame_buffer
  ###################################
  ###################################

*/

ScVkFramebuffer sc_vk_framebuffer_new_swapchain(ScVk* pScVk, VkRenderPass pass, VkImageView* aAttachmentViews, i32 attachmentsCount);
ScVkFramebuffer sc_vk_framebuffer_new_offscreen(ScVk* pScVk, VkRenderPass pass, ScTexture* aTextures);
void sc_vk_framebuffer_destroy(ScVk* pScVk, ScVkFramebuffer scVkFrame);

/*

  ###################################
  ###################################
  sc_vk_render_pass
  ###################################
  ###################################

*/

i32 sc_vk_render_pass_new(ScVk* pScVk, ScVkRenderPassConfig renderPassCfg);
i32 sc_vk_render_pass_final_new(ScVk* pScVk);
void sc_vk_render_pass_destroy(ScVk* pScVk, i32 id);
Sc2dTexture sc_vk_render_pass_get_current_image_as_texture(ScVkRenderPass* pPass, VkSampler sampler);
const char* sc_vk_render_pass_type_to_string(ScVkRenderPassType type);
void sc_vk_render_pass_draw(ScVk* pScVk, ScVkRenderPass* pPass, VkSemaphore* aSemaphores, i32 semaphoresCount);
void sc_vk_render_pass_draw_v2(ScVk* pScVk, ScVkRenderPass* pPass, VkCommandBuffer cmdBuffer);
i32 sc_vk_render_pass_request_buffer(ScVk* pScVk, ScVkRenderPass* pPass, i64 verticesSize, i64 indicesCount);
void sc_vk_render_pass_create_buffers(ScVk* pScVk, i32 renderPassId);

/*

  ###################################
  ###################################
  sc_vk_pipe
  ###################################
  ###################################

*/

void sc_vk_pipeline_config_print(ScVk* pScVk, ScVkPipelineConfig cfg);

ScVkPipelineConfig sc_vk_pipeline_config_new_ext(ScVkPipelineConfig cfg);
i32 sc_vk_pipeline_new(ScVk* pScVk, ScVkPipelineConfig cfg);
void sc_vk_pipeline_destroy(ScVk* pScVk, ScVkPipeline pipeline);
void sc_vk_pipeline_destroy_by_id(ScVk* pScVk, i64 pipeId);
ScVkUniform* sc_vk_pipeline_get_uniform(ScVkPipeline* pPipeline, const char* pName);
i32 sc_vk_pipeline_set_uniform(ScVk* pScVk, i64 pipeId, const char* pName, void* pData, u64 offset, u64 dataSize);
ScVkDescriptorConfig* sc_vk_pipeline_get_descriptor(ScVkPipeline* pPipeline, const char* pName);
void sc_vk_pipeline_set_vertices(ScVk* pScVk, ScVkPipeline* pPipeline, void* pData, u64 size);
void sc_vk_pipeline_set_vertices_ext(ScVk* pScVk, ScVkPipeline* pPipeline, void* pData, u64 size, u64 offset);

#define sc_vk_pipeline_config_new(aStages, aAttributes, ...) \
    ({                                                       \
        ScVkPipelineConfig cfg = (ScVkPipelineConfig) {      \
            .aStages = (ScVkStageConfig*)aStages,            \
            .aAttributes = (ScVkAttribute*)aAttributes,      \
            .StagesCount = ScArrayCount(aStages),            \
            .AttributesCount = ScArrayCount(aAttributes),    \
            __VA_ARGS__                                      \
        };                                                   \
                                                             \
        cfg = sc_vk_pipeline_config_new_ext(cfg);            \
        cfg;                                                 \
    })

void sc_vk_test_pipe(ScVk* pScVk, ScVkRenderPass renderPass);

/*

  ###################################
  ###################################
  sc_vk_frame
  ###################################
  ###################################

*/

typedef enum
{
    ScVkFrameResult_Created = 0,
    ScVkFrameResult_SwapchainNeedsRecreation, // DOCS: Image out of date
    ScVkFrameResult_SurfaceChanged            // DOCS: Image suboptimal
} ScVkFrameResult;

ScVkFrameResult sc_vk_frame_start(ScVk* pScVk, VkCommandBuffer cmd, u32* pImageIndex);
void sc_vk_frame_end(ScVk* pScVk, VkCommandBuffer cmd, u32* pImageIndex);

/*

  ###################################
  ###################################
  sc_vk_helpers
  ###################################
  ###################################

*/

u64 sc_vk_format_get_size(VkFormat vkFormat);
const char* sc_vk_format_to_string(VkFormat vkFormat);
VkShaderStageFlagBits sc_vk_stage_type_to_native(ScVkStageType type);
const char* sc_vk_stage_type_to_string(ScVkStageType type);
VkDescriptorType sc_vk_descriptor_type_to_native(ScVkDescriptorType type);
const char* sc_vk_descriptor_type_to_string(ScVkDescriptorType type);
const char* sc_vk_n_descriptor_type_to_string(VkDescriptorType type);
const char* sc_vk_sample_count_to_string(VkSampleCountFlagBits sampleCount);
const char* sc_vk_polygon_mode_to_string(VkPolygonMode vkPolygonMode);

#endif // SC_VULKAN_H
