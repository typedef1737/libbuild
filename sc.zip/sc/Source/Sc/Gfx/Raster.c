/*
  DOCS: Raster - программный рендерер, общий для всех платформ.
  Весь код без единого #if на ОС: окно (Window.c) только берёт
  буфер через sc_raster_get_buffer/sc_raster_swap и блитит его
  на экран (xcb_put_image / BitBlt).

  Координаты API - Y-вверх, как в Ui: origin в левом нижнем углу,
  y = 0 - нижняя граница, y = Height - 1 - верхняя. В памяти строки
  лежат сверху вниз (row 0 - верхняя): так их напрямую принимают
  xcb_put_image и top-down DIB. Переворот Y делают set_pixel и
  fill_rect (line/rect идут через них), поэтому окно блитит буфер
  без изменений.

  NOTE: перенос CPU-части из XCB Graphics Window.c с фиксами:
  клиппинг верхней границы в set_pixel (раньше - порча кучи при
  draw_line за краем), Bresenham вместо float-шага с
  oversampling'ом 2x, линейный clear вместо двойного цикла.

  Текст (sc_raster_draw_text) - блит глифов из атласа Text/Font с
  альфа-смешиванием; позиционирование повторяет ui-рендерер
  (Rendy/2d.c, draw_text_ext_2): baseline + Xoff/Yoff/Xadvance.
*/
#include "Sc/Gfx/Raster.h"

#include "Sc/Sc.h"
#include "Sc/Text/Font.h"
#include <math.h>

ScResult
sc_raster_init(ScRaster* pRaster, i32 width, i32 height, i32 maxWidth, i32 maxHeight)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return ScResult_Error;

    if (width <= 0 || height <= 0)
        return ScResult_Error;

    /* запас на resize: 0 = без запаса */
    if (maxWidth <= 0)
        maxWidth = width;
    if (maxHeight <= 0)
        maxHeight = height;
    if (width > maxWidth)
        width = maxWidth;
    if (height > maxHeight)
        height = maxHeight;

    u64 bufferSize = (u64)maxWidth * maxHeight * 4;
    if (bufferSize > 0xffffffff)
        return ScResult_Error;

    for (i32 b = 0; b < 2; ++b)
    {
        ScRasterBuffer* pBuffer = &pRaster->aBuffers[b];
        pBuffer->pData = sc_memory_allocate(bufferSize);
        if (pBuffer->pData == ScNull)
        {
            sc_raster_free(pRaster);
            return ScResult_Error;
        }
        pBuffer->Width = (u16)width;
        pBuffer->Height = (u16)height;
    }

    pRaster->BufferCurrent = 0;
    pRaster->BuffersCount = 2;
    pRaster->Width = (u16)width;
    pRaster->Height = (u16)height;
    pRaster->MaxWidth = (u16)maxWidth;
    pRaster->MaxHeight = (u16)maxHeight;

    return ScResult_Success;
}

void
sc_raster_resize(ScRaster* pRaster, i32 width, i32 height)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull || width <= 0 || height <= 0)
        return;

    /* память выделена на MaxSize: только меняем текущие размеры */
    if (width > pRaster->MaxWidth)
        width = pRaster->MaxWidth;
    if (height > pRaster->MaxHeight)
        height = pRaster->MaxHeight;

    for (i32 b = 0; b < pRaster->BuffersCount; ++b)
    {
        pRaster->aBuffers[b].Width = (u16)width;
        pRaster->aBuffers[b].Height = (u16)height;
    }

    pRaster->Width = (u16)width;
    pRaster->Height = (u16)height;
}

ScRasterBuffer
sc_raster_get_buffer(ScRaster* pRaster)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
    {
        ScRasterBuffer empty = {};
        return empty;
    }

    return pRaster->aBuffers[pRaster->BufferCurrent];
}

ScRasterBuffer
sc_raster_swap(ScRaster* pRaster)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
    {
        ScRasterBuffer empty = {};
        return empty;
    }

    /* возвращаем ЗАКОНЧЕННЫЙ кадр, рисование продолжится в следующем */
    ScRasterBuffer finished = pRaster->aBuffers[pRaster->BufferCurrent];
    pRaster->BufferCurrent = (pRaster->BufferCurrent + 1) % pRaster->BuffersCount;
    return finished;
}

void
sc_raster_set_pixel(ScRasterBuffer buffer, i32 x, i32 y, u32 color)
{
    /* полный клиппинг, включая верхнюю границу */
    if (x < 0 || y < 0 || x >= buffer.Width || y >= buffer.Height)
        return;

    /*
      DOCS: Y-вверх: y = 0 - нижняя строка окна, а память растера
      хранит строки сверху вниз (row 0 - верхняя).
    */
    i32 row = (i32)buffer.Height - 1 - y;
    u32* aPixels = (u32*)buffer.pData;
    aPixels[row * buffer.Width + x] = color;
}

void
sc_raster_clear_color(ScRaster* pRaster, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];
    u32* pWrite = (u32*)buffer.pData;
    i64 count = (i64)buffer.Width * buffer.Height;

    /* линейное заполнение: строки в памяти подряд */
    for (i64 i = 0; i < count; ++i)
        pWrite[i] = color;
}

void
sc_raster_draw_line(ScRaster* pRaster, i32 x0, i32 y0, i32 x1, i32 y1, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];

    /*
      DOCS: Брезенхэм с "прогрессивным" целочисленным шагом. Классика:
      error = dx + dy (dy отрицательный), на каждом шаге идём по
      младшей оси, когда error переваливает - сдвиг по старшей.
    */
    i32 dx = x1 - x0;
    i32 dy = y1 - y0;
    i32 adx = sc_i32_abs(dx);
    i32 ady = sc_i32_abs(dy);

    i32 stepX = dx >= 0 ? 1 : -1;
    i32 stepY = dy >= 0 ? 1 : -1;
    i32 error = adx - ady;

    i32 x = x0;
    i32 y = y0;

    while (1)
    {
        sc_raster_set_pixel(buffer, x, y, color);

        if (x == x1 && y == y1)
            break;

        i32 error2 = error * 2;
        if (error2 > -ady) /* сдвиг по X */
        {
            error -= ady;
            x += stepX;
        }
        if (error2 < adx) /* сдвиг по Y */
        {
            error += adx;
            y += stepY;
        }
    }
}

void
sc_raster_draw_rect(ScRaster* pRaster, i32 x, i32 y, i32 width, i32 height, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull || width <= 0 || height <= 0)
        return;

    i32 right = x + width - 1;
    i32 top = y + height - 1;

    /* стороны через линии: клиппинг внутри set_pixel */
    sc_raster_draw_line(pRaster, x, y, right, y, color);
    sc_raster_draw_line(pRaster, x, top, right, top, color);
    sc_raster_draw_line(pRaster, x, y, x, top, color);
    sc_raster_draw_line(pRaster, right, y, right, top, color);
}

void
sc_raster_fill_rect(ScRaster* pRaster, i32 x, i32 y, i32 width, i32 height, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull || width <= 0 || height <= 0)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];

    /* клиппинг прямоугольника к буферу */
    i32 clipRight = ScMin(x + width, (i32)buffer.Width);
    i32 clipTop = ScMin(y + height, (i32)buffer.Height);
    i32 startX = ScMax(x, 0);
    i32 startY = ScMax(y, 0);

    /* построчное линейное заполнение; в памяти строка = Height - 1 - y */
    for (i32 row = startY; row < clipTop; ++row)
    {
        i32 memoryRow = (i32)buffer.Height - 1 - row;
        u32* pWrite = (u32*)buffer.pData + (i64)memoryRow * buffer.Width + startX;
        i64 count = clipRight - startX;
        for (i64 i = 0; i < count; ++i)
            pWrite[i] = color;
    }
}

/*
  DOCS: Покомпонентное смешивание (source-over) цвета глифа с пикселем
  буфера. coverage - покрытие пикселя глифом из альфа-канала атласа
  (0..255), умножается на альфу color. Целочисленно, как остальной
  растеризатор.
*/
static u32
sc_raster_blend_glyph_pixel(u32 dst, u32 src, u32 coverage)
{
    u32 srcAlpha = (src >> 24) & 0xFF;
    u32 alpha = (coverage * srcAlpha + 127) / 255;

    if (alpha == 0)
        return dst;
    if (alpha == 255)
        return src;

    u32 inv = 255 - alpha;
    u32 r = (((src >> 16) & 0xFF) * alpha + ((dst >> 16) & 0xFF) * inv + 127) / 255;
    u32 g = (((src >> 8) & 0xFF) * alpha + ((dst >> 8) & 0xFF) * inv + 127) / 255;
    u32 b = ((src & 0xFF) * alpha + (dst & 0xFF) * inv + 127) / 255;
    u32 a = (255 * alpha + ((dst >> 24) & 0xFF) * inv + 127) / 255;

    return ScColor_ARGB(a, r, g, b);
}

/*
  DOCS: Блиттит один глиф из атласа шрифта в буфер. (x, yTop) - верхний
  левый угол глифа в координатах Y-вверх (yTop получается из baseline
  и Yoff, см. sc_raster_draw_text). Атлас - RGBA (sc_font_new всегда
  конвертирует в RGBA), строки в памяти сверху вниз, как и у буфера,
  поэтому по Y обе картинки идут в одном направлении и достаточно
  перевернуть только координату строки буфера.
*/
static void
sc_raster_blit_glyph(ScRasterBuffer buffer, ScFont* pFont, ScFontChar fontChar, i32 x, i32 yTop, u32 color)
{
    i32 glyphWidth = (i32)fontChar.X1 - (i32)fontChar.X0;
    i32 glyphHeight = (i32)fontChar.Y1 - (i32)fontChar.Y0;
    if (glyphWidth <= 0 || glyphHeight <= 0)
        return;

    i32 atlasWidth = to_i32(pFont->Size.Width);

    /* горизонтальный клиппинг один раз на весь глиф */
    i32 startX = ScMax(x, 0);
    i32 endX = ScMin(x + glyphWidth, (i32)buffer.Width);
    if (startX >= endX)
        return;

    const u8* pAtlas = (const u8*)pFont->pBitmap;
    u32* aPixels = (u32*)buffer.pData;

    const i32 c_is_debug = 1;

    if (c_is_debug)
    {
        for (i32 gy = 0; gy < glyphHeight; ++gy)
        {
            /* gy = 0 - верхняя строка глифа */
            i32 dstY = yTop - 1 - gy;
            if (dstY < 0 || dstY >= (i32)buffer.Height)
                continue;

            /* Y-вверх: y = 0 - нижняя строка, а в памяти строки сверху вниз */
            i32 memoryRow = (i32)buffer.Height - 1 - dstY;
            u32* pWrite = aPixels + (i64)memoryRow * buffer.Width;
            const u8* pRead = pAtlas + ((i64)(fontChar.Y0 + gy) * atlasWidth + fontChar.X0) * 4;

            for (i32 dstX = startX; dstX < endX; ++dstX)
            {
                i32 gx = dstX - x;
                u32 coverage = pRead[gx * 4 + 3];
                pWrite[dstX] = ScColor_ARGB(255, 255, 255, 255);
            }
        }
    }
    else
    {
        for (i32 gy = 0; gy < glyphHeight; ++gy)
        {
            /* gy = 0 - верхняя строка глифа */
            i32 dstY = yTop - 1 - gy;
            if (dstY < 0 || dstY >= (i32)buffer.Height)
                continue;

            /* Y-вверх: y = 0 - нижняя строка, а в памяти строки сверху вниз */
            i32 memoryRow = (i32)buffer.Height - 1 - dstY;
            u32* pWrite = aPixels + (i64)memoryRow * buffer.Width;
            const u8* pRead = pAtlas + ((i64)(fontChar.Y0 + gy) * atlasWidth + fontChar.X0) * 4;

            for (i32 dstX = startX; dstX < endX; ++dstX)
            {
                i32 gx = dstX - x;
                u32 coverage = pRead[gx * 4 + 3];
                if (coverage != 0)
                    pWrite[dstX] = sc_raster_blend_glyph_pixel(pWrite[dstX], color, coverage);
            }
        }
    }
}

void
sc_raster_draw_text(ScRaster* pRaster, ScFont* pFont, i32 x, i32 y, u32 color, char* pText)
{
    sc_assert_not_null(pRaster);
    sc_assert_not_null(pFont);

    if (pRaster == ScNull || pFont == ScNull)
        return;

    if (pFont->pBitmap == ScNull || pFont->hCharTable == ScNull || pText == ScNull)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];

    /*
      DOCS: offset.X - текущая позиция пера (как в Rendy/2d.c), y -
      baseline. Шаг строки приблизительный - FontSize: точные
      ascent/descent в ScFont не сохраняются.
    */
    f32 offsetX = to_f32(x);
    i32 baselineY = y;
    i32 lineHeight = pFont->FontSize > 0 ? pFont->FontSize : 1;

    char* pIter = pText;
    while (*pIter != '\0')
    {
        i32 bytesCount = 0;
        u32 codepoint = sc_utf8_decode(pIter, &bytesCount);
        if (bytesCount <= 0)
            break;

        if (codepoint == (u32)'\n')
        {
            offsetX = to_f32(x);
            baselineY -= lineHeight;
        }
        else if (codepoint == (u32)' ')
        {
            offsetX += sc_font_get_space_metrics(*pFont).X;
        }
        else if ((i32)codepoint >= pFont->RangeMin && (i32)codepoint <= pFont->RangeMax
                 && sc_dict_i_contains(pFont->hCharTable, (i32)codepoint))
        {
            ScFontChar fontChar = sc_dict_get_current(pFont->hCharTable);

            /*
              DOCS: Позиционирование как в ui-рендерере (Rendy/2d.c
              draw_text_ext_2): Xoff - левый side bearing, Yoff -
              верх глифа относительно baseline (отрицательный); после
              отрисовки курсор сдвигается на advance.
            */
            i32 roundX = (i32)floorf(offsetX + fontChar.Xoff + 0.5f);
            i32 roundY = (i32)floorf(to_f32(baselineY) - fontChar.Yoff);
            offsetX += fontChar.Xadvance;

            /* roundY - верх глифа (Y-вверх) */
            sc_raster_blit_glyph(buffer, pFont, fontChar, roundX, roundY, color);
        }

        pIter += bytesCount;
    }
}

void
sc_raster_free(ScRaster* pRaster)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return;

    for (i32 b = 0; b < 2; ++b)
    {
        sc_memory_free(pRaster->aBuffers[b].pData);
        pRaster->aBuffers[b].pData = ScNull;
    }
}
