/*
  DOCS: Raster - программный рендерер, общий для всех платформ.
  Весь код без единого #if на ОС: окно (Window.c) только берёт
  буфер через sc_raster_get_buffer/sc_raster_swap и блитит его
  на экран (xcb_put_image / BitBlt).

  NOTE: перенос CPU-части из XCB Graphics Window.c с фиксами:
  клиппинг верхней границы в set_pixel (раньше - порча кучи при
  draw_line за краем), Bresenham вместо float-шага с
  oversampling'ом 2x, линейный clear вместо двойного цикла.
*/
#include "Sc/Gfx/Raster.h"

#include "Sc/Sc.h"

i32
sc_raster_init(ScRaster* pRaster, i32 width, i32 height, i32 maxWidth, i32 maxHeight)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return ScResult_Error;

    if (width <= 0 || height <= 0)
        return ScResult_Error;

    /* запас на resize: 0 = без запаса */
    if (maxWidth <= 0)
        maxWidth = width;
    if (maxHeight <= 0)
        maxHeight = height;
    if (width > maxWidth)
        width = maxWidth;
    if (height > maxHeight)
        height = maxHeight;

    u64 bufferSize = (u64)maxWidth * maxHeight * 4;
    if (bufferSize > 0xffffffff)
        return ScResult_Error;

    for (i32 b = 0; b < 2; ++b)
    {
        ScRasterBuffer* pBuffer = &pRaster->aBuffers[b];
        pBuffer->pData = sc_memory_allocate(bufferSize);
        if (pBuffer->pData == ScNull)
        {
            sc_raster_free(pRaster);
            return ScResult_Error;
        }
        pBuffer->Width = (u16)width;
        pBuffer->Height = (u16)height;
    }

    pRaster->BufferCurrent = 0;
    pRaster->BuffersCount = 2;
    pRaster->Width = (u16)width;
    pRaster->Height = (u16)height;
    pRaster->MaxWidth = (u16)maxWidth;
    pRaster->MaxHeight = (u16)maxHeight;

    return ScResult_Success;
}

void
sc_raster_resize(ScRaster* pRaster, i32 width, i32 height)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull || width <= 0 || height <= 0)
        return;

    /* память выделена на MaxSize: только меняем текущие размеры */
    if (width > pRaster->MaxWidth)
        width = pRaster->MaxWidth;
    if (height > pRaster->MaxHeight)
        height = pRaster->MaxHeight;

    for (i32 b = 0; b < pRaster->BuffersCount; ++b)
    {
        pRaster->aBuffers[b].Width = (u16)width;
        pRaster->aBuffers[b].Height = (u16)height;
    }

    pRaster->Width = (u16)width;
    pRaster->Height = (u16)height;
}

ScRasterBuffer
sc_raster_get_buffer(ScRaster* pRaster)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
    {
        ScRasterBuffer empty = {};
        return empty;
    }

    return pRaster->aBuffers[pRaster->BufferCurrent];
}

ScRasterBuffer
sc_raster_swap(ScRaster* pRaster)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
    {
        ScRasterBuffer empty = {};
        return empty;
    }

    /* возвращаем ЗАКОНЧЕННЫЙ кадр, рисование продолжится в следующем */
    ScRasterBuffer finished = pRaster->aBuffers[pRaster->BufferCurrent];
    pRaster->BufferCurrent = (pRaster->BufferCurrent + 1) % pRaster->BuffersCount;
    return finished;
}

void
sc_raster_set_pixel(ScRasterBuffer buffer, i32 x, i32 y, u32 color)
{
    /* полный клиппинг, включая верхнюю границу */
    if (x < 0 || y < 0 || x >= buffer.Width || y >= buffer.Height)
        return;

    u32* aPixels = (u32*)buffer.pData;
    aPixels[y * buffer.Width + x] = color;
}

void
sc_raster_clear_color(ScRaster* pRaster, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];
    u32* pWrite = (u32*)buffer.pData;
    i64 count = (i64)buffer.Width * buffer.Height;

    /* линейное заполнение: строки в памяти подряд */
    for (i64 i = 0; i < count; ++i)
        pWrite[i] = color;
}

void
sc_raster_draw_line(ScRaster* pRaster, i32 x0, i32 y0, i32 x1, i32 y1, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];

    /*
      DOCS: Брезенхэм с "прогрессивным" целочисленным шагом. Классика:
      error = dx + dy (dy отрицательный), на каждом шаге идём по
      младшей оси, когда error переваливает - сдвиг по старшей.
    */
    i32 dx = x1 - x0;
    i32 dy = y1 - y0;
    i32 adx = sc_i32_abs(dx);
    i32 ady = sc_i32_abs(dy);

    i32 stepX = dx >= 0 ? 1 : -1;
    i32 stepY = dy >= 0 ? 1 : -1;
    i32 error = adx - ady;

    i32 x = x0;
    i32 y = y0;

    while (1)
    {
        sc_raster_set_pixel(buffer, x, y, color);

        if (x == x1 && y == y1)
            break;

        i32 error2 = error * 2;
        if (error2 > -ady) /* сдвиг по X */
        {
            error -= ady;
            x += stepX;
        }
        if (error2 < adx) /* сдвиг по Y */
        {
            error += adx;
            y += stepY;
        }
    }
}

void
sc_raster_draw_rect(ScRaster* pRaster, i32 x, i32 y, i32 width, i32 height, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull || width <= 0 || height <= 0)
        return;

    i32 right = x + width - 1;
    i32 top = y + height - 1;

    /* стороны через линии: клиппинг внутри set_pixel */
    sc_raster_draw_line(pRaster, x, y, right, y, color);
    sc_raster_draw_line(pRaster, x, top, right, top, color);
    sc_raster_draw_line(pRaster, x, y, x, top, color);
    sc_raster_draw_line(pRaster, right, y, right, top, color);
}

void
sc_raster_fill_rect(ScRaster* pRaster, i32 x, i32 y, i32 width, i32 height, u32 color)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull || width <= 0 || height <= 0)
        return;

    ScRasterBuffer buffer = pRaster->aBuffers[pRaster->BufferCurrent];

    /* клиппинг прямоугольника к буферу */
    i32 clipRight = ScMin(x + width, (i32)buffer.Width);
    i32 clipTop = ScMin(y + height, (i32)buffer.Height);
    i32 startX = ScMax(x, 0);
    i32 startY = ScMax(y, 0);

    /* построчное линейное заполнение */
    for (i32 row = startY; row < clipTop; ++row)
    {
        u32* pWrite = (u32*)buffer.pData + (i64)row * buffer.Width + startX;
        i64 count = clipRight - startX;
        for (i64 i = 0; i < count; ++i)
            pWrite[i] = color;
    }
}

void
sc_raster_free(ScRaster* pRaster)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return;

    for (i32 b = 0; b < 2; ++b)
    {
        sc_memory_free(pRaster->aBuffers[b].pData);
        pRaster->aBuffers[b].pData = ScNull;
    }
}
