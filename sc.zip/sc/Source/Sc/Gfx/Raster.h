/*
  Raster - программный (software) рендерер: CPU-фреймбуферы, клир,
  пиксель, линия. Общий для Linux (XCB) и Windows (WIN32/GDI): окно
  только блитит готовый буфер на экран (xcb_put_image / BitBlt).

  Формат пикселя: 32 bpp, 0xAARRGGBB (little endian: байты B,G,R,A).
  Такой порядок ожидают xcb_put_image с Z_PIXMAP (red_mask 0xFF0000)
  и 32bpp BI_RGB DIB у GDI.

  Y-ориентация: координаты API - origin в левом НИЖНЕМ углу,
  Y-вверх: y = 0 - нижняя граница, y = Height - 1 - верхняя.
  В памяти строки лежат сверху вниз (row 0 - верхняя) - так их
  принимают blit-бэкенды; sc_raster_set_pixel/fill_rect
  переворачивают Y, остальные функции идут через них.

  Двойная буферизация: рендерим в активный буфер, sc_raster_swap()
  отдаёт его на вывод и переключает на следующий. Память под оба
  выделяется сразу на MaxSize - resize меняет только Width/Height,
  без реаллокаций.
*/
#ifndef SC_RASTER_H
#define SC_RASTER_H

#include "Sc/Text/Font.h"
#include "Sc/Types.h"

/*
  DOCS: Один фреймбуфер. pData - Width * Height * 4 байт (строки
  подряд, в памяти сверху вниз); сама память выделена на MaxSize
  (см. ScRaster). Координаты функций - Y-вверх (y = 0 - низ).
*/
typedef struct
{
    void* pData;
    u16 Width;
    u16 Height;
} ScRasterBuffer;

/*
  DOCS: Состояние программного рендерера. Публично, чтобы окно могло
  получить blit-бэкенду доступ к буферам (aBuffers + индекс).
*/
typedef struct
{
    i32 BufferCurrent; /* индекс активного (рисуемого) буфера */
    i32 BuffersCount;  /* всегда 2 */
    u16 Width;         /* текущая ширина (<= MaxWidth) */
    u16 Height;        /* текущая высота (<= MaxHeight) */
    u16 MaxWidth;
    u16 MaxHeight;
    ScRasterBuffer aBuffers[2];
} ScRaster;

/*
  DOCS: Создаёт рендерер на width x height с запасом до maxWidth x
  maxHeight (0 = без запаса, берётся текущий размер). Оба буфера
  аллоцируются сразу на MaxSize. Возвращает ScResult_Error при ошибке
  (невалидные аргументы, нехватка памяти), иначе ScResult_Success.
*/
ScResult sc_raster_init(ScRaster* pRaster, i32 width, i32 height, i32 maxWidth, i32 maxHeight);

/*
  DOCS: Меняет текущий размер (например, при resize окна). Память не
  трогается: если новый размер больше MaxSize, он обрезается до него.
*/
void sc_raster_resize(ScRaster* pRaster, i32 width, i32 height);

/*
  DOCS: Активный (рисуемый) буфер.
*/
ScRasterBuffer sc_raster_get_buffer(ScRaster* pRaster);

/*
  DOCS: Заканчивает кадр: переключает активный буфер и возвращает
  ЗАКОНЧЕННЫЙ (готовый к выводу на экран) буфер. Вызывается окном в
  sc_window_graphics_swap_buffers().
*/
ScRasterBuffer sc_raster_swap(ScRaster* pRaster);

/*
  DOCS: Рисует пиксель в активный буфер. Координаты за пределами
  буфера игнорируются (в т.ч. верхняя граница - клиппинг).
*/
void sc_raster_set_pixel(ScRasterBuffer buffer, i32 x, i32 y, u32 color);

/*
  DOCS: Заполняет активный буфер цветом.
*/
void sc_raster_clear_color(ScRaster* pRaster, u32 color);

/*
  DOCS: Линия по алгоритму Брезенхэма (целочисленный, без float)
  в активный буфер, с клиппингом по границам буфера.
*/
void sc_raster_draw_line(ScRaster* pRaster, i32 x0, i32 y0, i32 x1, i32 y1, u32 color);

/*
  DOCS: Контур прямоугольника (1px, стороны параллельны осям) в
  активный буфер, с клиппингом по границам буфера.
*/
void sc_raster_draw_rect(ScRaster* pRaster, i32 x, i32 y, i32 width, i32 height, u32 color);

/*
  DOCS: Залитый прямоугольник в активный буфер: построчное
  линейное заполнение с клиппингом по границам буфера.
*/
void sc_raster_fill_rect(ScRaster* pRaster, i32 x, i32 y, i32 width, i32 height, u32 color);

/*
  DOCS: Рисует UTF-8 текст шрифтом pFont (атлас глифов из Text/Font,
  см. sc_font_new) в активный буфер. (x, y) - базовая линия (baseline)
  первого ряда: координаты Y-вверх, как у остальных функций растера.

  Позиционирование глифов повторяет рендеринг ui (Rendy/2d.c
  draw_text_ext_2): курсор X идёт по Xadvance, глиф ставится по
  Xoff/Yoff с округлением floor(v + 0.5). Пиксели глифа берутся из
  атласа шрифта (RGBA, альфа = покрытие) и смешиваются с буфером
  (source-over) с учётом альфы color. Пробел - advance из метрик,
  '\n' - перевод строки (x сбрасывается, y -= FontSize), символы вне
  RangeMin..RangeMax и отсутствующие в шрифте пропускаются. Клиппинг -
  по границам буфера.
*/
void sc_raster_draw_text(ScRaster* pRaster, ScFont* pFont, i32 x, i32 y, u32 color, char* pText);

/*
  DOCS: Освобождает буферы (память - sc_memory_free). Саму структуру
  не трогает.
*/
void sc_raster_free(ScRaster* pRaster);

#endif // SC_RASTER_H
