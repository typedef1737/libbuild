#include "Sc/Gfx/Vulkan.h"
#include "Sc/Sc.h"
#include <dlfcn.h>

#define scv_load(lib, method, type) \
    (type) scv_load_ext(lib, method)
void* scv_load_ext(void* pLib, const char* pMethod);

PFN_vkCreateInstance vkCreateInstance = NULL;
PFN_vkDestroyInstance vkDestroyInstance = NULL;
PFN_vkEnumerateInstanceExtensionProperties vkEnumerateInstanceExtensionProperties = NULL;
PFN_vkEnumerateInstanceLayerProperties vkEnumerateInstanceLayerProperties = NULL;
PFN_vkGetInstanceProcAddr vkGetInstanceProcAddr = NULL;
PFN_vkGetDeviceProcAddr vkGetDeviceProcAddr = NULL;
PFN_vkCreateDevice vkCreateDevice = NULL;
PFN_vkDestroyDevice vkDestroyDevice = NULL;
PFN_vkDeviceWaitIdle vkDeviceWaitIdle = NULL;

// Функции физического устройства
PFN_vkEnumeratePhysicalDevices vkEnumeratePhysicalDevices = NULL;
PFN_vkGetPhysicalDeviceProperties vkGetPhysicalDeviceProperties = NULL;
PFN_vkGetPhysicalDeviceFeatures vkGetPhysicalDeviceFeatures = NULL;
PFN_vkGetPhysicalDeviceQueueFamilyProperties vkGetPhysicalDeviceQueueFamilyProperties = NULL;
PFN_vkGetPhysicalDeviceMemoryProperties vkGetPhysicalDeviceMemoryProperties = NULL;
PFN_vkGetPhysicalDeviceFormatProperties vkGetPhysicalDeviceFormatProperties = NULL;
PFN_vkGetPhysicalDeviceImageFormatProperties vkGetPhysicalDeviceImageFormatProperties = NULL;
PFN_vkEnumerateDeviceExtensionProperties vkEnumerateDeviceExtensionProperties = NULL;
PFN_vkEnumerateDeviceLayerProperties vkEnumerateDeviceLayerProperties = NULL;

// Функции устройства
PFN_vkGetDeviceQueue vkGetDeviceQueue = NULL;
PFN_vkQueueSubmit vkQueueSubmit = NULL;
PFN_vkQueueWaitIdle vkQueueWaitIdle = NULL;
PFN_vkQueuePresentKHR vkQueuePresentKHR = NULL;
PFN_vkWaitForFences vkWaitForFences = NULL;
PFN_vkResetFences vkResetFences = NULL;
PFN_vkCreateFence vkCreateFence = NULL;
PFN_vkDestroyFence vkDestroyFence = NULL;
PFN_vkCreateSemaphore vkCreateSemaphore = NULL;
PFN_vkDestroySemaphore vkDestroySemaphore = NULL;

// Командные буферы
PFN_vkCreateCommandPool vkCreateCommandPool = NULL;
PFN_vkDestroyCommandPool vkDestroyCommandPool = NULL;
PFN_vkAllocateCommandBuffers vkAllocateCommandBuffers = NULL;
PFN_vkFreeCommandBuffers vkFreeCommandBuffers = NULL;
PFN_vkBeginCommandBuffer vkBeginCommandBuffer = NULL;
PFN_vkEndCommandBuffer vkEndCommandBuffer = NULL;
PFN_vkResetCommandBuffer vkResetCommandBuffer = NULL;
PFN_vkResetCommandPool vkResetCommandPool = NULL;
PFN_vkCmdBeginRenderPass vkCmdBeginRenderPass = NULL;
PFN_vkCmdEndRenderPass vkCmdEndRenderPass = NULL;
PFN_vkCmdBindPipeline vkCmdBindPipeline = NULL;
PFN_vkCmdBindDescriptorSets vkCmdBindDescriptorSets = NULL;
PFN_vkCmdBindVertexBuffers vkCmdBindVertexBuffers = NULL;
PFN_vkCmdBindIndexBuffer vkCmdBindIndexBuffer = NULL;
PFN_vkCmdDraw vkCmdDraw = NULL;
PFN_vkCmdDrawIndexed vkCmdDrawIndexed = NULL;
PFN_vkCmdDrawIndirect vkCmdDrawIndirect = NULL;
PFN_vkCmdDrawIndexedIndirect vkCmdDrawIndexedIndirect = NULL;
PFN_vkCmdSetViewport vkCmdSetViewport = NULL;
PFN_vkCmdSetScissor vkCmdSetScissor = NULL;
PFN_vkCmdPipelineBarrier vkCmdPipelineBarrier = NULL;
PFN_vkCmdCopyBuffer vkCmdCopyBuffer = NULL;
PFN_vkCmdCopyBufferToImage vkCmdCopyBufferToImage = NULL;
PFN_vkCmdCopyImageToBuffer vkCmdCopyImageToBuffer = NULL;
PFN_vkCmdBlitImage vkCmdBlitImage = NULL;

// Swapchain функции
PFN_vkCreateSwapchainKHR vkCreateSwapchainKHR = NULL;
PFN_vkDestroySwapchainKHR vkDestroySwapchainKHR = NULL;
PFN_vkGetSwapchainImagesKHR vkGetSwapchainImagesKHR = NULL;
PFN_vkAcquireNextImageKHR vkAcquireNextImageKHR = NULL;
PFN_vkAcquireNextImage2KHR vkAcquireNextImage2KHR = NULL;

// Surface функции
PFN_vkDestroySurfaceKHR vkDestroySurfaceKHR = NULL;
PFN_vkGetPhysicalDeviceSurfaceSupportKHR vkGetPhysicalDeviceSurfaceSupportKHR = NULL;
PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR vkGetPhysicalDeviceSurfaceCapabilitiesKHR = NULL;
PFN_vkGetPhysicalDeviceSurfaceFormatsKHR vkGetPhysicalDeviceSurfaceFormatsKHR = NULL;
PFN_vkGetPhysicalDeviceSurfacePresentModesKHR vkGetPhysicalDeviceSurfacePresentModesKHR = NULL;

// Память и буферы
PFN_vkCreateBuffer vkCreateBuffer = NULL;
PFN_vkDestroyBuffer vkDestroyBuffer = NULL;
PFN_vkGetBufferMemoryRequirements vkGetBufferMemoryRequirements = NULL;
PFN_vkBindBufferMemory vkBindBufferMemory = NULL;
PFN_vkCreateImage vkCreateImage = NULL;
PFN_vkDestroyImage vkDestroyImage = NULL;
PFN_vkGetImageMemoryRequirements vkGetImageMemoryRequirements = NULL;
PFN_vkBindImageMemory vkBindImageMemory = NULL;
PFN_vkCreateImageView vkCreateImageView = NULL;
PFN_vkDestroyImageView vkDestroyImageView = NULL;
PFN_vkAllocateMemory vkAllocateMemory = NULL;
PFN_vkFreeMemory vkFreeMemory = NULL;
PFN_vkMapMemory vkMapMemory = NULL;
PFN_vkUnmapMemory vkUnmapMemory = NULL;
PFN_vkFlushMappedMemoryRanges vkFlushMappedMemoryRanges = NULL;
PFN_vkInvalidateMappedMemoryRanges vkInvalidateMappedMemoryRanges = NULL;

// Шейдеры и пайплайны
PFN_vkCreateShaderModule vkCreateShaderModule = NULL;
PFN_vkDestroyShaderModule vkDestroyShaderModule = NULL;
PFN_vkCreatePipelineLayout vkCreatePipelineLayout = NULL;
PFN_vkDestroyPipelineLayout vkDestroyPipelineLayout = NULL;
PFN_vkCreateGraphicsPipelines vkCreateGraphicsPipelines = NULL;
PFN_vkCreateComputePipelines vkCreateComputePipelines = NULL;
PFN_vkDestroyPipeline vkDestroyPipeline = NULL;
PFN_vkCreateDescriptorSetLayout vkCreateDescriptorSetLayout = NULL;
PFN_vkDestroyDescriptorSetLayout vkDestroyDescriptorSetLayout = NULL;
PFN_vkCreateDescriptorPool vkCreateDescriptorPool = NULL;
PFN_vkDestroyDescriptorPool vkDestroyDescriptorPool = NULL;
PFN_vkAllocateDescriptorSets vkAllocateDescriptorSets = NULL;
PFN_vkFreeDescriptorSets vkFreeDescriptorSets = NULL;
PFN_vkUpdateDescriptorSets vkUpdateDescriptorSets = NULL;

// Рендерпассы и фреймбуферы
PFN_vkCreateRenderPass vkCreateRenderPass = NULL;
PFN_vkDestroyRenderPass vkDestroyRenderPass = NULL;
PFN_vkCreateFramebuffer vkCreateFramebuffer = NULL;
PFN_vkDestroyFramebuffer vkDestroyFramebuffer = NULL;
PFN_vkCreateSampler vkCreateSampler = NULL;
PFN_vkDestroySampler vkDestroySampler = NULL;

void
sc_vulkan_init()
{
    const char* pVulkanPath;

    void* pVulkanLib = NULL;
    i32 mode = RTLD_NOW | RTLD_LOCAL | RTLD_DEEPBIND;

    pVulkanLib = dlopen("libvulkan.so.1", mode);
    if (!pVulkanLib)
    {
        pVulkanLib = dlopen("libvulkan.so.1", mode);
        sc_guard_not_null(pVulkanLib);
    }

    // Загрузка основных функций
    vkCreateInstance = scv_load(pVulkanLib, "vkCreateInstance", PFN_vkCreateInstance);
    vkDestroyInstance = scv_load(pVulkanLib, "vkDestroyInstance", PFN_vkDestroyInstance);
    vkEnumerateInstanceExtensionProperties = scv_load(pVulkanLib, "vkEnumerateInstanceExtensionProperties", PFN_vkEnumerateInstanceExtensionProperties);
    vkEnumerateInstanceLayerProperties = scv_load(pVulkanLib, "vkEnumerateInstanceLayerProperties", PFN_vkEnumerateInstanceLayerProperties);

    vkGetInstanceProcAddr = scv_load(pVulkanLib, "vkGetInstanceProcAddr", PFN_vkGetInstanceProcAddr);
    vkGetDeviceProcAddr = scv_load(pVulkanLib, "vkGetDeviceProcAddr", PFN_vkGetDeviceProcAddr);

    vkCreateDevice = scv_load(pVulkanLib, "vkCreateDevice", PFN_vkCreateDevice);
    vkDestroyDevice = scv_load(pVulkanLib, "vkDestroyDevice", PFN_vkDestroyDevice);
    vkDeviceWaitIdle = scv_load(pVulkanLib, "vkDeviceWaitIdle", PFN_vkDeviceWaitIdle);

    // Функции физического устройства
    vkEnumeratePhysicalDevices = scv_load(pVulkanLib, "vkEnumeratePhysicalDevices", PFN_vkEnumeratePhysicalDevices);
    vkGetPhysicalDeviceProperties = scv_load(pVulkanLib, "vkGetPhysicalDeviceProperties", PFN_vkGetPhysicalDeviceProperties);
    vkGetPhysicalDeviceFeatures = scv_load(pVulkanLib, "vkGetPhysicalDeviceFeatures", PFN_vkGetPhysicalDeviceFeatures);
    vkGetPhysicalDeviceQueueFamilyProperties = scv_load(pVulkanLib, "vkGetPhysicalDeviceQueueFamilyProperties", PFN_vkGetPhysicalDeviceQueueFamilyProperties);
    vkGetPhysicalDeviceMemoryProperties = scv_load(pVulkanLib, "vkGetPhysicalDeviceMemoryProperties", PFN_vkGetPhysicalDeviceMemoryProperties);
    vkGetPhysicalDeviceFormatProperties = scv_load(pVulkanLib, "vkGetPhysicalDeviceFormatProperties", PFN_vkGetPhysicalDeviceFormatProperties);
    vkGetPhysicalDeviceImageFormatProperties = scv_load(pVulkanLib, "vkGetPhysicalDeviceImageFormatProperties", PFN_vkGetPhysicalDeviceImageFormatProperties);
    vkEnumerateDeviceExtensionProperties = scv_load(pVulkanLib, "vkEnumerateDeviceExtensionProperties", PFN_vkEnumerateDeviceExtensionProperties);
    vkEnumerateDeviceLayerProperties = scv_load(pVulkanLib, "vkEnumerateDeviceLayerProperties", PFN_vkEnumerateDeviceLayerProperties);

    // Функции устройства
    vkGetDeviceQueue = scv_load(pVulkanLib, "vkGetDeviceQueue", PFN_vkGetDeviceQueue);
    vkQueueSubmit = scv_load(pVulkanLib, "vkQueueSubmit", PFN_vkQueueSubmit);
    vkQueueWaitIdle = scv_load(pVulkanLib, "vkQueueWaitIdle", PFN_vkQueueWaitIdle);
    vkQueuePresentKHR = scv_load(pVulkanLib, "vkQueuePresentKHR", PFN_vkQueuePresentKHR);
    vkWaitForFences = scv_load(pVulkanLib, "vkWaitForFences", PFN_vkWaitForFences);
    vkResetFences = scv_load(pVulkanLib, "vkResetFences", PFN_vkResetFences);
    vkCreateFence = scv_load(pVulkanLib, "vkCreateFence", PFN_vkCreateFence);
    vkDestroyFence = scv_load(pVulkanLib, "vkDestroyFence", PFN_vkDestroyFence);
    vkCreateSemaphore = scv_load(pVulkanLib, "vkCreateSemaphore", PFN_vkCreateSemaphore);
    vkDestroySemaphore = scv_load(pVulkanLib, "vkDestroySemaphore", PFN_vkDestroySemaphore);

    // Командные буферы
    vkCreateCommandPool = scv_load(pVulkanLib, "vkCreateCommandPool", PFN_vkCreateCommandPool);
    vkDestroyCommandPool = scv_load(pVulkanLib, "vkDestroyCommandPool", PFN_vkDestroyCommandPool);
    vkAllocateCommandBuffers = scv_load(pVulkanLib, "vkAllocateCommandBuffers", PFN_vkAllocateCommandBuffers);
    vkFreeCommandBuffers = scv_load(pVulkanLib, "vkFreeCommandBuffers", PFN_vkFreeCommandBuffers);
    vkBeginCommandBuffer = scv_load(pVulkanLib, "vkBeginCommandBuffer", PFN_vkBeginCommandBuffer);
    vkEndCommandBuffer = scv_load(pVulkanLib, "vkEndCommandBuffer", PFN_vkEndCommandBuffer);
    vkResetCommandBuffer = scv_load(pVulkanLib, "vkResetCommandBuffer", PFN_vkResetCommandBuffer);
    vkResetCommandPool = scv_load(pVulkanLib, "vkResetCommandPool", PFN_vkResetCommandPool);
    vkCmdBeginRenderPass = scv_load(pVulkanLib, "vkCmdBeginRenderPass", PFN_vkCmdBeginRenderPass);
    vkCmdEndRenderPass = scv_load(pVulkanLib, "vkCmdEndRenderPass", PFN_vkCmdEndRenderPass);
    vkCmdBindPipeline = scv_load(pVulkanLib, "vkCmdBindPipeline", PFN_vkCmdBindPipeline);
    vkCmdBindDescriptorSets = scv_load(pVulkanLib, "vkCmdBindDescriptorSets", PFN_vkCmdBindDescriptorSets);
    vkCmdBindVertexBuffers = scv_load(pVulkanLib, "vkCmdBindVertexBuffers", PFN_vkCmdBindVertexBuffers);
    vkCmdBindIndexBuffer = scv_load(pVulkanLib, "vkCmdBindIndexBuffer", PFN_vkCmdBindIndexBuffer);
    vkCmdDraw = scv_load(pVulkanLib, "vkCmdDraw", PFN_vkCmdDraw);
    vkCmdDrawIndexed = scv_load(pVulkanLib, "vkCmdDrawIndexed", PFN_vkCmdDrawIndexed);
    vkCmdDrawIndirect = scv_load(pVulkanLib, "vkCmdDrawIndirect", PFN_vkCmdDrawIndirect);
    vkCmdDrawIndexedIndirect = scv_load(pVulkanLib, "vkCmdDrawIndexedIndirect", PFN_vkCmdDrawIndexedIndirect);
    vkCmdSetViewport = scv_load(pVulkanLib, "vkCmdSetViewport", PFN_vkCmdSetViewport);
    vkCmdSetScissor = scv_load(pVulkanLib, "vkCmdSetScissor", PFN_vkCmdSetScissor);
    vkCmdPipelineBarrier = scv_load(pVulkanLib, "vkCmdPipelineBarrier", PFN_vkCmdPipelineBarrier);
    vkCmdCopyBuffer = scv_load(pVulkanLib, "vkCmdCopyBuffer", PFN_vkCmdCopyBuffer);
    vkCmdCopyBufferToImage = scv_load(pVulkanLib, "vkCmdCopyBufferToImage", PFN_vkCmdCopyBufferToImage);
    vkCmdCopyImageToBuffer = scv_load(pVulkanLib, "vkCmdCopyImageToBuffer", PFN_vkCmdCopyImageToBuffer);
    vkCmdBlitImage = scv_load(pVulkanLib, "vkCmdBlitImage", PFN_vkCmdBlitImage);

    // Swapchain функции
    vkCreateSwapchainKHR = scv_load(pVulkanLib, "vkCreateSwapchainKHR", PFN_vkCreateSwapchainKHR);
    vkDestroySwapchainKHR = scv_load(pVulkanLib, "vkDestroySwapchainKHR", PFN_vkDestroySwapchainKHR);
    vkGetSwapchainImagesKHR = scv_load(pVulkanLib, "vkGetSwapchainImagesKHR", PFN_vkGetSwapchainImagesKHR);
    vkAcquireNextImageKHR = scv_load(pVulkanLib, "vkAcquireNextImageKHR", PFN_vkAcquireNextImageKHR);
    vkAcquireNextImage2KHR = scv_load(pVulkanLib, "vkAcquireNextImage2KHR", PFN_vkAcquireNextImage2KHR);

    // Surface функции
    vkDestroySurfaceKHR = scv_load(pVulkanLib, "vkDestroySurfaceKHR", PFN_vkDestroySurfaceKHR);
    vkGetPhysicalDeviceSurfaceSupportKHR = scv_load(pVulkanLib, "vkGetPhysicalDeviceSurfaceSupportKHR", PFN_vkGetPhysicalDeviceSurfaceSupportKHR);
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR = scv_load(pVulkanLib, "vkGetPhysicalDeviceSurfaceCapabilitiesKHR", PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR);
    vkGetPhysicalDeviceSurfaceFormatsKHR = scv_load(pVulkanLib, "vkGetPhysicalDeviceSurfaceFormatsKHR", PFN_vkGetPhysicalDeviceSurfaceFormatsKHR);
    vkGetPhysicalDeviceSurfacePresentModesKHR = scv_load(pVulkanLib, "vkGetPhysicalDeviceSurfacePresentModesKHR", PFN_vkGetPhysicalDeviceSurfacePresentModesKHR);

    // Память и буферы
    vkCreateBuffer = scv_load(pVulkanLib, "vkCreateBuffer", PFN_vkCreateBuffer);
    vkDestroyBuffer = scv_load(pVulkanLib, "vkDestroyBuffer", PFN_vkDestroyBuffer);
    vkGetBufferMemoryRequirements = scv_load(pVulkanLib, "vkGetBufferMemoryRequirements", PFN_vkGetBufferMemoryRequirements);
    vkBindBufferMemory = scv_load(pVulkanLib, "vkBindBufferMemory", PFN_vkBindBufferMemory);
    vkCreateImage = scv_load(pVulkanLib, "vkCreateImage", PFN_vkCreateImage);
    vkDestroyImage = scv_load(pVulkanLib, "vkDestroyImage", PFN_vkDestroyImage);
    vkGetImageMemoryRequirements = scv_load(pVulkanLib, "vkGetImageMemoryRequirements", PFN_vkGetImageMemoryRequirements);
    vkBindImageMemory = scv_load(pVulkanLib, "vkBindImageMemory", PFN_vkBindImageMemory);
    vkCreateImageView = scv_load(pVulkanLib, "vkCreateImageView", PFN_vkCreateImageView);
    vkDestroyImageView = scv_load(pVulkanLib, "vkDestroyImageView", PFN_vkDestroyImageView);
    vkAllocateMemory = scv_load(pVulkanLib, "vkAllocateMemory", PFN_vkAllocateMemory);
    vkFreeMemory = scv_load(pVulkanLib, "vkFreeMemory", PFN_vkFreeMemory);
    vkMapMemory = scv_load(pVulkanLib, "vkMapMemory", PFN_vkMapMemory);
    vkUnmapMemory = scv_load(pVulkanLib, "vkUnmapMemory", PFN_vkUnmapMemory);
    vkFlushMappedMemoryRanges = scv_load(pVulkanLib, "vkFlushMappedMemoryRanges", PFN_vkFlushMappedMemoryRanges);
    vkInvalidateMappedMemoryRanges = scv_load(pVulkanLib, "vkInvalidateMappedMemoryRanges", PFN_vkInvalidateMappedMemoryRanges);

    // Шейдеры и пайплайны
    vkCreateShaderModule = scv_load(pVulkanLib, "vkCreateShaderModule", PFN_vkCreateShaderModule);
    vkDestroyShaderModule = scv_load(pVulkanLib, "vkDestroyShaderModule", PFN_vkDestroyShaderModule);
    vkCreatePipelineLayout = scv_load(pVulkanLib, "vkCreatePipelineLayout", PFN_vkCreatePipelineLayout);
    vkDestroyPipelineLayout = scv_load(pVulkanLib, "vkDestroyPipelineLayout", PFN_vkDestroyPipelineLayout);
    vkCreateGraphicsPipelines = scv_load(pVulkanLib, "vkCreateGraphicsPipelines", PFN_vkCreateGraphicsPipelines);
    vkCreateComputePipelines = scv_load(pVulkanLib, "vkCreateComputePipelines", PFN_vkCreateComputePipelines);
    vkDestroyPipeline = scv_load(pVulkanLib, "vkDestroyPipeline", PFN_vkDestroyPipeline);
    vkCreateDescriptorSetLayout = scv_load(pVulkanLib, "vkCreateDescriptorSetLayout", PFN_vkCreateDescriptorSetLayout);
    vkDestroyDescriptorSetLayout = scv_load(pVulkanLib, "vkDestroyDescriptorSetLayout", PFN_vkDestroyDescriptorSetLayout);
    vkCreateDescriptorPool = scv_load(pVulkanLib, "vkCreateDescriptorPool", PFN_vkCreateDescriptorPool);
    vkDestroyDescriptorPool = scv_load(pVulkanLib, "vkDestroyDescriptorPool", PFN_vkDestroyDescriptorPool);
    vkAllocateDescriptorSets = scv_load(pVulkanLib, "vkAllocateDescriptorSets", PFN_vkAllocateDescriptorSets);
    vkFreeDescriptorSets = scv_load(pVulkanLib, "vkFreeDescriptorSets", PFN_vkFreeDescriptorSets);
    vkUpdateDescriptorSets = scv_load(pVulkanLib, "vkUpdateDescriptorSets", PFN_vkUpdateDescriptorSets);

    // Рендерпассы и фреймбуферы
    vkCreateRenderPass = scv_load(pVulkanLib, "vkCreateRenderPass", PFN_vkCreateRenderPass);
    vkDestroyRenderPass = scv_load(pVulkanLib, "vkDestroyRenderPass", PFN_vkDestroyRenderPass);
    vkCreateFramebuffer = scv_load(pVulkanLib, "vkCreateFramebuffer", PFN_vkCreateFramebuffer);
    vkDestroyFramebuffer = scv_load(pVulkanLib, "vkDestroyFramebuffer", PFN_vkDestroyFramebuffer);
    vkCreateSampler = scv_load(pVulkanLib, "vkCreateSampler", PFN_vkCreateSampler);
    vkDestroySampler = scv_load(pVulkanLib, "vkDestroySampler", PFN_vkDestroySampler);
}

void*
scv_load_ext(void* pLib, const char* pMethod)
{
    dlerror();
    void* pLoadedMethod = dlsym(pLib, pMethod);
    if (!pLoadedMethod)
    {
        sc_log_erro("Can't load method %s\n", pMethod);
        sc_guard(0);
        return NULL;
    }

    const char* pErr = dlerror();
    if (pErr)
    {
        sc_log_erro("dlsym:%s\n", pErr);
        sc_guard(0);
        return NULL;
    }

    return pLoadedMethod;
}
