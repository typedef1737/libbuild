/*
  DOCS: TrueType/OpenType - нативный парсер и растеризатор глифов
  (без stb, семантика stb_truetype). Разделы:

    - чтение big-endian полей (u8/u16/i16/u32/i32) по смещению;
    - ScTrueTypeBuffer - курсорный чтец для CFF-данных (вместо
      stbtt__buf): get8/peek8/seek/skip/get/get16/get32/range;
    - поиск таблиц sfnt-каталога, isfont/коллекции .ttc;
    - init: cmap/hmtx/hhea/head/loca/glyf (TrueType) или CFF/Type2
      (OTF), выбор cmap-подтаблицы (MS/Unicode), numGlyphs (maxp);
    - find_glyph_index: cmap форматы 0, 4 (бинарный поиск сегментов),
      6, 12/13 (бинарный поиск групп);
    - контур глифа: glyf (простые - флаги/дельты координат,
      compound - рекурсия с матрицей 2x2), CFF Type2 charstrings
      (два прохода: подсчёт и вывод, subr/gsubr, CID fdselect);
    - метрики: hmtx (numOfLongHorMetrics), hhea, head, OS/2;
    - растеризатор v2 (DirectAA): тесселяция кривых во флэтнесе,
      сортировка рёбер, active edge list, точное покрытие пикселей.

  Математика как у stb: floor/ceil/sqrt/fabs - double (важно для
  бит-в-бит совместимости растеризатора).
*/
#include "TrueType.h"

#include "Sc/Sc.h"
#include <math.h>
#include <string.h>

/* //////////////////////////////////////////////////////////////////////// */
/* Чтение big-endian полей */

static u8
sc_true_type_u8_at(u8* p)
{
    return p[0];
}

static i8
sc_true_type_i8_at(u8* p)
{
    return (i8)p[0];
}

static u16
sc_true_type_u16_at(u8* p)
{
    return (u16)(p[0] * 256 + p[1]);
}

static i16
sc_true_type_i16_at(u8* p)
{
    return (i16)(p[0] * 256 + p[1]);
}

static u32
sc_true_type_u32_at(u8* p)
{
    return ((u32)p[0] << 24) + ((u32)p[1] << 16) + ((u32)p[2] << 8) + (u32)p[3];
}

static i32
sc_true_type_i32_at(u8* p)
{
    return (i32)((p[0] << 24) + (p[1] << 16) + (p[2] << 8) + p[3]);
}

static i32
sc_true_type_tag_is(u8* p, const char* pTag)
{
    return p[0] == (u8)pTag[0] && p[1] == (u8)pTag[1]
        && p[2] == (u8)pTag[2] && p[3] == (u8)pTag[3];
}

/* //////////////////////////////////////////////////////////////////////// */
/* CFF-чтец */

typedef struct
{
    u8* pData;
    i32 Cursor;
    i32 Size;
} ScTrueTypeBuffer;

static ScTrueTypeBuffer
sc_true_type_buffer_new(void* pData, i64 size)
{
    ScTrueTypeBuffer buffer;
    buffer.pData = (u8*)pData;
    buffer.Size = (i32)size;
    buffer.Cursor = 0;
    return buffer;
}

static u8
sc_true_type_buffer_get8(ScTrueTypeBuffer* pBuffer)
{
    if (pBuffer->Cursor >= pBuffer->Size)
        return 0;
    return pBuffer->pData[pBuffer->Cursor++];
}

static u8
sc_true_type_buffer_peek8(ScTrueTypeBuffer* pBuffer)
{
    if (pBuffer->Cursor >= pBuffer->Size)
        return 0;
    return pBuffer->pData[pBuffer->Cursor];
}

static void
sc_true_type_buffer_seek(ScTrueTypeBuffer* pBuffer, i32 offset)
{
    pBuffer->Cursor = (offset > pBuffer->Size || offset < 0) ? pBuffer->Size : offset;
}

static void
sc_true_type_buffer_skip(ScTrueTypeBuffer* pBuffer, i32 offset)
{
    sc_true_type_buffer_seek(pBuffer, pBuffer->Cursor + offset);
}

static u32
sc_true_type_buffer_get(ScTrueTypeBuffer* pBuffer, i32 count)
{
    u32 value = 0;
    for (i32 i = 0; i < count; ++i)
        value = (value << 8) | sc_true_type_buffer_get8(pBuffer);
    return value;
}

static ScTrueTypeBuffer
sc_true_type_buffer_range(ScTrueTypeBuffer* pBuffer, i32 offset, i32 size)
{
    ScTrueTypeBuffer result = sc_true_type_buffer_new(ScNull, 0);
    if (offset < 0 || size < 0 || offset > pBuffer->Size || size > pBuffer->Size - offset)
        return result;
    result.pData = pBuffer->pData + offset;
    result.Size = size;
    return result;
}

static u32
sc_true_type_buffer_get16(ScTrueTypeBuffer* pBuffer)
{
    return sc_true_type_buffer_get(pBuffer, 2);
}

static u32
sc_true_type_buffer_get32(ScTrueTypeBuffer* pBuffer)
{
    return sc_true_type_buffer_get(pBuffer, 4);
}

/*
  DOCS: CFF INDEX: количество, offSize, смещения элементов. Возвращает
  диапазон от начала INDEX (start) до конца его последнего элемента.
*/
static ScTrueTypeBuffer
sc_true_type_cff_get_index(ScTrueTypeBuffer* pBuffer)
{
    i32 start = pBuffer->Cursor;
    u32 count = sc_true_type_buffer_get16(pBuffer);
    if (count != 0)
    {
        u32 offSize = sc_true_type_buffer_get8(pBuffer);
        sc_true_type_buffer_skip(pBuffer, (i32)offSize * (i32)count);
        sc_true_type_buffer_skip(pBuffer, (i32)sc_true_type_buffer_get(pBuffer, (i32)offSize) - 1);
    }
    return sc_true_type_buffer_range(pBuffer, start, pBuffer->Cursor - start);
}

static u32
sc_true_type_cff_int(ScTrueTypeBuffer* pBuffer)
{
    i32 b0 = sc_true_type_buffer_get8(pBuffer);
    if (b0 >= 32 && b0 <= 246)       return b0 - 139;
    if (b0 >= 247 && b0 <= 250) return (b0 - 247) * 256 + sc_true_type_buffer_get8(pBuffer) + 108;
    if (b0 >= 251 && b0 <= 254) return -(b0 - 251) * 256 - sc_true_type_buffer_get8(pBuffer) - 108;
    if (b0 == 28)               return sc_true_type_buffer_get16(pBuffer);
    if (b0 == 29)               return sc_true_type_buffer_get32(pBuffer);
    return 0;
}

static void
sc_true_type_cff_skip_operand(ScTrueTypeBuffer* pBuffer)
{
    u8 b0 = sc_true_type_buffer_peek8(pBuffer);
    if (b0 == 30)
    {
        sc_true_type_buffer_skip(pBuffer, 1);
        while (pBuffer->Cursor < pBuffer->Size)
        {
            u8 v = sc_true_type_buffer_get8(pBuffer);
            if ((v & 0xF) == 0xF || (v >> 4) == 0xF)
                break;
        }
    }
    else
    {
        sc_true_type_cff_int(pBuffer);
    }
}

/*
  DOCS: Значение ключа top/private DICT. Ищет первый оператор key
  (12 x - двухбайтовый), возвращает диапазон его операндов.
*/
static ScTrueTypeBuffer
sc_true_type_dict_get(ScTrueTypeBuffer* pBuffer, i32 key)
{
    sc_true_type_buffer_seek(pBuffer, 0);
    while (pBuffer->Cursor < pBuffer->Size)
    {
        i32 start = pBuffer->Cursor;
        while (sc_true_type_buffer_peek8(pBuffer) >= 28)
            sc_true_type_cff_skip_operand(pBuffer);
        i32 end = pBuffer->Cursor;
        i32 op = sc_true_type_buffer_get8(pBuffer);
        if (op == 12)
            op = sc_true_type_buffer_get8(pBuffer) | 0x100;
        if (op == key)
            return sc_true_type_buffer_range(pBuffer, start, end - start);
    }
    return sc_true_type_buffer_range(pBuffer, 0, 0);
}

static void
sc_true_type_dict_get_ints(ScTrueTypeBuffer* pBuffer, i32 key, i32 outCount, u32* pOut)
{
    ScTrueTypeBuffer operands = sc_true_type_dict_get(pBuffer, key);
    for (i32 i = 0; i < outCount && operands.Cursor < operands.Size; ++i)
        pOut[i] = sc_true_type_cff_int(&operands);
}

static i32
sc_true_type_cff_index_count(ScTrueTypeBuffer* pBuffer)
{
    sc_true_type_buffer_seek(pBuffer, 0);
    return (i32)sc_true_type_buffer_get16(pBuffer);
}

/*
  DOCS: Элемент i CFF INDEX (диапазон его байт).
*/
static ScTrueTypeBuffer
sc_true_type_cff_index_get(ScTrueTypeBuffer buffer, i32 index)
{
    sc_true_type_buffer_seek(&buffer, 0);
    u32 count = sc_true_type_buffer_get16(&buffer);
    u32 offSize = sc_true_type_buffer_get8(&buffer);
    sc_true_type_buffer_skip(&buffer, index * (i32)offSize);
    u32 start = sc_true_type_buffer_get(&buffer, (i32)offSize);
    u32 end = sc_true_type_buffer_get(&buffer, (i32)offSize);
    return sc_true_type_buffer_range(&buffer, (i32)(2 + (count + 1) * offSize + start), (i32)(end - start));
}

/* //////////////////////////////////////////////////////////////////////// */
/* sfnt-каталог, коллекции */

static i32
sc_true_type_is_font(u8* pFont)
{
    if (pFont[0] == '1' && pFont[1] == 0 && pFont[2] == 0 && pFont[3] == 0) return 1;
    if (sc_true_type_tag_is(pFont, "typ1")) return 1;
    if (sc_true_type_tag_is(pFont, "OTTO")) return 1;
    if (pFont[0] == 0 && pFont[1] == 1 && pFont[2] == 0 && pFont[3] == 0) return 1;
    if (sc_true_type_tag_is(pFont, "true")) return 1;
    return 0;
}

static u32
sc_true_type_find_table(u8* pData, u32 fontStart, const char* pTag)
{
    i32 numTables = sc_true_type_u16_at(pData + fontStart + 4);
    u32 tableDir = fontStart + 12;
    for (i32 i = 0; i < numTables; ++i)
    {
        u32 loc = tableDir + 16 * i;
        if (sc_true_type_tag_is(pData + loc, pTag))
            return sc_true_type_u32_at(pData + loc + 8);
    }
    return 0;
}

i32
sc_true_type_get_number_of_fonts(u8* pCollection)
{
    if (sc_true_type_is_font(pCollection))
        return 1;
    if (sc_true_type_tag_is(pCollection, "ttcf"))
    {
        u32 version = sc_true_type_u32_at(pCollection + 4);
        if (version == 0x00010000 || version == 0x00020000)
            return sc_true_type_i32_at(pCollection + 8);
    }
    return 0;
}

i32
sc_true_type_get_font_offset_for_index(u8* pCollection, i32 index)
{
    if (sc_true_type_is_font(pCollection))
        return index == 0 ? 0 : -1;
    if (sc_true_type_tag_is(pCollection, "ttcf"))
    {
        u32 version = sc_true_type_u32_at(pCollection + 4);
        if (version == 0x00010000 || version == 0x00020000)
        {
            i32 n = sc_true_type_i32_at(pCollection + 8);
            if (index >= n)
                return -1;
            return (i32)sc_true_type_u32_at(pCollection + 12 + index * 4);
        }
    }
    return -1;
}

/*
  DOCS: Private DICT шрифта -> диапазон его local subr INDEX.
*/
static ScTrueTypeBuffer
sc_true_type_get_subrs(ScTrueTypeBuffer cff, ScTrueTypeBuffer fontDict)
{
    u32 subrsOffset = 0;
    u32 privateLoc[2] = { 0, 0 };
    sc_true_type_dict_get_ints(&fontDict, 18, 2, privateLoc);
    if (privateLoc[1] == 0 || privateLoc[0] == 0)
        return sc_true_type_buffer_new(ScNull, 0);
    ScTrueTypeBuffer pDict = sc_true_type_buffer_range(&cff, (i32)privateLoc[1], (i32)privateLoc[0]);
    sc_true_type_dict_get_ints(&pDict, 19, 1, &subrsOffset);
    if (subrsOffset == 0)
        return sc_true_type_buffer_new(ScNull, 0);
    sc_true_type_buffer_seek(&cff, (i32)privateLoc[1] + (i32)subrsOffset);
    return sc_true_type_cff_get_index(&cff);
}

i32
sc_true_type_init(ScTrueTypeFontInfo* pInfo, u8* pData, i32 fontStart)
{
    pInfo->pData = pData;
    pInfo->FontStart = fontStart;

    pInfo->CffData = ScNull;
    pInfo->CffSize = 0;
    pInfo->Charstrings = ScNull;
    pInfo->CharstringsSize = 0;
    pInfo->Gsubrs = ScNull;
    pInfo->GsubrsSize = 0;
    pInfo->Subrs = ScNull;
    pInfo->SubrsSize = 0;
    pInfo->FontDicts = ScNull;
    pInfo->FontDictsSize = 0;
    pInfo->FdSelect = ScNull;
    pInfo->FdSelectSize = 0;

    u32 cmap = sc_true_type_find_table(pData, fontStart, "cmap");
    pInfo->Loca = (i32)sc_true_type_find_table(pData, fontStart, "loca");
    pInfo->Head = (i32)sc_true_type_find_table(pData, fontStart, "head");
    pInfo->Glyf = (i32)sc_true_type_find_table(pData, fontStart, "glyf");
    pInfo->Hhea = (i32)sc_true_type_find_table(pData, fontStart, "hhea");
    pInfo->Hmtx = (i32)sc_true_type_find_table(pData, fontStart, "hmtx");
    pInfo->Kern = (i32)sc_true_type_find_table(pData, fontStart, "kern");
    pInfo->Gpos = (i32)sc_true_type_find_table(pData, fontStart, "GPOS");

    if (cmap == 0 || pInfo->Head == 0 || pInfo->Hhea == 0 || pInfo->Hmtx == 0)
        return 0;

    if (pInfo->Glyf != 0)
    {
        if (pInfo->Loca == 0)
            return 0;
    }
    else
    {
        /* CFF / Type2 (OTF) */
        u32 cff = sc_true_type_find_table(pData, fontStart, "CFF ");
        if (cff == 0)
            return 0;

        /*
          NOTE: stb передаёт в buf весь rest файла (512MB cap). Точный
          размер CFF-таблицы из каталога sfnt: последний отрезок
          таблицы - до следующей записи каталога. Здесь тоже весь
          rest (совместимость со stb).
        */
        pInfo->CffData = pData + cff;
        pInfo->CffSize = 512 * 1024 * 1024;

        ScTrueTypeBuffer buffer = sc_true_type_buffer_new(pInfo->CffData, pInfo->CffSize);

        sc_true_type_buffer_skip(&buffer, 2);
        sc_true_type_buffer_seek(&buffer, sc_true_type_buffer_get8(&buffer));

        sc_true_type_cff_get_index(&buffer); /* name INDEX */
        ScTrueTypeBuffer topDictIdx = sc_true_type_cff_get_index(&buffer);
        ScTrueTypeBuffer topDict = sc_true_type_cff_index_get(topDictIdx, 0);
        sc_true_type_cff_get_index(&buffer); /* string INDEX */
        ScTrueTypeBuffer gsubrs = sc_true_type_cff_get_index(&buffer);
        pInfo->Gsubrs = gsubrs.pData;
        pInfo->GsubrsSize = gsubrs.Size;

        u32 charstrings = 0;
        u32 cstype = 2;
        u32 fdArrayOffset = 0;
        u32 fdSelectOffset = 0;
        sc_true_type_dict_get_ints(&topDict, 17, 1, &charstrings);
        sc_true_type_dict_get_ints(&topDict, 0x100 | 6, 1, &cstype);
        sc_true_type_dict_get_ints(&topDict, 0x100 | 36, 1, &fdArrayOffset);
        sc_true_type_dict_get_ints(&topDict, 0x100 | 37, 1, &fdSelectOffset);
        ScTrueTypeBuffer subrs = sc_true_type_get_subrs(buffer, topDict);
        pInfo->Subrs = subrs.pData;
        pInfo->SubrsSize = subrs.Size;

        /* поддерживаем только Type2 charstrings */
        if (cstype != 2)
            return 0;
        if (charstrings == 0)
            return 0;

        if (fdArrayOffset != 0)
        {
            /* CID-шрифт */
            if (fdSelectOffset == 0)
                return 0;
            sc_true_type_buffer_seek(&buffer, (i32)fdArrayOffset);
            ScTrueTypeBuffer fontDicts = sc_true_type_cff_get_index(&buffer);
            pInfo->FontDicts = fontDicts.pData;
            pInfo->FontDictsSize = fontDicts.Size;
            ScTrueTypeBuffer fdSelect = sc_true_type_buffer_range(&buffer, (i32)fdSelectOffset, buffer.Size - (i32)fdSelectOffset);
            pInfo->FdSelect = fdSelect.pData;
            pInfo->FdSelectSize = fdSelect.Size;
        }

        sc_true_type_buffer_seek(&buffer, (i32)charstrings);
        ScTrueTypeBuffer charstringsBuf = sc_true_type_cff_get_index(&buffer);
        pInfo->Charstrings = charstringsBuf.pData;
        pInfo->CharstringsSize = charstringsBuf.Size;
    }

    u32 t = sc_true_type_find_table(pData, fontStart, "maxp");
    if (t != 0)
        pInfo->NumGlyphs = sc_true_type_u16_at(pData + t + 4);
    else
        pInfo->NumGlyphs = 0xffff;

    /* выбор cmap-подтаблицы: MS/Unicode-платформы */
    i32 numTables = sc_true_type_u16_at(pData + cmap + 2);
    pInfo->IndexMap = 0;
    for (i32 i = 0; i < numTables; ++i)
    {
        u32 encodingRecord = cmap + 4 + 8 * i;
        switch (sc_true_type_u16_at(pData + encodingRecord))
        {
        case 3: /* Microsoft */
            switch (sc_true_type_u16_at(pData + encodingRecord + 2))
            {
            case 1:  /* Unicode BMP */
            case 10: /* Unicode full */
                pInfo->IndexMap = (i32)(cmap + sc_true_type_u32_at(pData + encodingRecord + 4));
                break;
            }
            break;
        case 0: /* Unicode */
            pInfo->IndexMap = (i32)(cmap + sc_true_type_u32_at(pData + encodingRecord + 4));
            break;
        }
    }
    if (pInfo->IndexMap == 0)
        return 0;

    pInfo->IndexToLocFormat = sc_true_type_u16_at(pData + pInfo->Head + 50);
    return 1;
}

/* //////////////////////////////////////////////////////////////////////// */
/* cmap */

i32
sc_true_type_find_glyph_index(ScTrueTypeFontInfo* pInfo, i32 codepoint)
{
    u8* pData = pInfo->pData;
    u32 indexMap = pInfo->IndexMap;

    u16 format = sc_true_type_u16_at(pData + indexMap);
    if (format == 0)
    {
        i32 bytes = sc_true_type_u16_at(pData + indexMap + 2);
        if (codepoint >= 0 && codepoint < bytes - 6)
            return sc_true_type_u8_at(pData + indexMap + 6 + codepoint);
        return 0;
    }
    else if (format == 6)
    {
        u32 first = sc_true_type_u16_at(pData + indexMap + 6);
        u32 count = sc_true_type_u16_at(pData + indexMap + 8);
        if ((u32)codepoint >= first && (u32)codepoint < first + count)
            return sc_true_type_u16_at(pData + indexMap + 10 + (codepoint - first) * 2);
        return 0;
    }
    else if (format == 4)
    {
        u16 segcount = sc_true_type_u16_at(pData + indexMap + 6) >> 1;
        u16 searchRange = sc_true_type_u16_at(pData + indexMap + 8) >> 1;
        u16 entrySelector = sc_true_type_u16_at(pData + indexMap + 10);
        u16 rangeShift = sc_true_type_u16_at(pData + indexMap + 12) >> 1;

        u32 endCount = indexMap + 14;
        u32 search = endCount;

        if (codepoint > 0xffff)
            return 0;

        if (codepoint >= sc_true_type_u16_at(pData + search + rangeShift * 2))
            search += rangeShift * 2;

        search -= 2;
        while (entrySelector != 0)
        {
            searchRange >>= 1;
            u16 end = sc_true_type_u16_at(pData + search + searchRange * 2);
            if (codepoint > end)
                search += searchRange * 2;
            --entrySelector;
        }
        search += 2;

        u16 item = (u16)((search - endCount) >> 1);
        u16 start = sc_true_type_u16_at(pData + indexMap + 14 + segcount * 2 + 2 + 2 * item);
        u16 last = sc_true_type_u16_at(pData + endCount + 2 * item);
        if (codepoint < start || codepoint > last)
            return 0;

        u16 offset = sc_true_type_u16_at(pData + indexMap + 14 + segcount * 6 + 2 + 2 * item);
        if (offset == 0)
            return (u16)(codepoint + sc_true_type_i16_at(pData + indexMap + 14 + segcount * 4 + 2 + 2 * item));

        return sc_true_type_u16_at(pData + offset + (codepoint - start) * 2 + indexMap + 14 + segcount * 6 + 2 + 2 * item);
    }
    else if (format == 12 || format == 13)
    {
        u32 ngroups = sc_true_type_u32_at(pData + indexMap + 12);
        i32 low = 0;
        i32 high = (i32)ngroups;
        while (low < high)
        {
            i32 mid = low + ((high - low) >> 1);
            u32 startChar = sc_true_type_u32_at(pData + indexMap + 16 + mid * 12);
            u32 endChar = sc_true_type_u32_at(pData + indexMap + 16 + mid * 12 + 4);
            if ((u32)codepoint < startChar)
                high = mid;
            else if ((u32)codepoint > endChar)
                low = mid + 1;
            else
            {
                u32 startGlyph = sc_true_type_u32_at(pData + indexMap + 16 + mid * 12 + 8);
                if (format == 12)
                    return (i32)(startGlyph + (u32)codepoint - startChar);
                return (i32)startGlyph;
            }
        }
        return 0;
    }

    return 0;
}

/* //////////////////////////////////////////////////////////////////////// */
/* glyf/loca */

static i32
sc_true_type_get_glyf_offset(ScTrueTypeFontInfo* pInfo, i32 glyphIndex)
{
    if (glyphIndex >= pInfo->NumGlyphs)
        return -1;
    if (pInfo->IndexToLocFormat >= 2)
        return -1;

    i32 g1;
    i32 g2;
    if (pInfo->IndexToLocFormat == 0)
    {
        g1 = pInfo->Glyf + sc_true_type_u16_at(pInfo->pData + pInfo->Loca + glyphIndex * 2) * 2;
        g2 = pInfo->Glyf + sc_true_type_u16_at(pInfo->pData + pInfo->Loca + glyphIndex * 2 + 2) * 2;
    }
    else
    {
        g1 = pInfo->Glyf + (i32)sc_true_type_u32_at(pInfo->pData + pInfo->Loca + glyphIndex * 4);
        g2 = pInfo->Glyf + (i32)sc_true_type_u32_at(pInfo->pData + pInfo->Loca + glyphIndex * 4 + 4);
    }

    return g1 == g2 ? -1 : g1;
}

static void
sc_true_type_set_vertex(ScTrueTypeVertex* pVertex, u8 type, i32 x, i32 y, i32 cx, i32 cy, i32 cx1, i32 cy1)
{
    pVertex->Type = type;
    pVertex->X = (i16)x;
    pVertex->Y = (i16)y;
    pVertex->ControlX = (i16)cx;
    pVertex->ControlY = (i16)cy;
    pVertex->ControlX1 = (i16)cx1;
    pVertex->ControlY1 = (i16)cy1;
}

static i32
sc_true_type_close_shape(ScTrueTypeVertex* pVertices, i32 numVertices, i32 wasOff, i32 startOff,
                          i32 sx, i32 sy, i32 scx, i32 scy, i32 cx, i32 cy)
{
    if (startOff)
    {
        if (wasOff)
            sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Curve, (cx + scx) >> 1, (cy + scy) >> 1, cx, cy, 0, 0);
        sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Curve, sx, sy, scx, scy, 0, 0);
    }
    else
    {
        if (wasOff)
            sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Curve, sx, sy, cx, cy, 0, 0);
        else
            sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Line, sx, sy, 0, 0, 0, 0);
    }
    return numVertices;
}

/*
  DOCS: Контур простого глифа: флаги (с repeat), дельты x/y, сборка
  контуров (on-curve/off-curve пары -> линии/кривые). Семантика
  stbtt__GetGlyphShapeTT.
*/
static i32
sc_true_type_get_glyph_shape_simple(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, ScTrueTypeVertex** ppVertices)
{
    u8* pData = pInfo->pData;
    ScTrueTypeVertex* pVertices = ScNull;
    i32 numVertices = 0;
    i32 g = sc_true_type_get_glyf_offset(pInfo, glyphIndex);

    *ppVertices = ScNull;

    if (g < 0)
        return 0;

    i16 numberOfContours = sc_true_type_i16_at(pData + g);

    if (numberOfContours > 0)
    {
        u8* endPtsOfContours = pData + g + 10;
        i32 ins = sc_true_type_u16_at(pData + g + 10 + numberOfContours * 2);
        u8* pPoints = pData + g + 10 + numberOfContours * 2 + 2 + ins;

        i32 n = 1 + sc_true_type_u16_at(endPtsOfContours + numberOfContours * 2 - 2);

        i32 m = n + 2 * numberOfContours;
        pVertices = (ScTrueTypeVertex*)sc_memory_allocate(sizeof(ScTrueTypeVertex) * m);
        if (pVertices == ScNull)
            return 0;

        i32 nextMove = 0;
        u8 flags = 0;
        u8 flagCount = 0;
        i32 j = 0;

        /* рба (как у stb): сначала сырые флаги/координаты грузим в хвост массива */
        i32 off = m - n;

        for (i32 i = 0; i < n; ++i)
        {
            if (flagCount == 0)
            {
                flags = *pPoints++;
                if (flags & 8)
                    flagCount = *pPoints++;
            }
            else
            {
                --flagCount;
            }
            pVertices[off + i].Type = flags;
        }

        /* x-координаты */
        i32 x = 0;
        for (i32 i = 0; i < n; ++i)
        {
            flags = pVertices[off + i].Type;
            if (flags & 2)
            {
                i16 dx = *pPoints++;
                x += (flags & 16) ? dx : -dx;
            }
            else
            {
                if ((flags & 16) == 0)
                {
                    x = x + (i16)(pPoints[0] * 256 + pPoints[1]);
                    pPoints += 2;
                }
            }
            pVertices[off + i].X = (i16)x;
        }

        /* y-координаты */
        i32 y = 0;
        for (i32 i = 0; i < n; ++i)
        {
            flags = pVertices[off + i].Type;
            if (flags & 4)
            {
                i16 dy = *pPoints++;
                y += (flags & 32) ? dy : -dy;
            }
            else
            {
                if ((flags & 32) == 0)
                {
                    y = y + (i16)(pPoints[0] * 256 + pPoints[1]);
                    pPoints += 2;
                }
            }
            pVertices[off + i].Y = (i16)y;
        }

        /* сборка контуров */
        numVertices = 0;
        i32 sx = 0, sy = 0, cx = 0, cy = 0, scx = 0, scy = 0;
        i32 wasOff = 0;
        i32 startOff = 0;
        for (i32 i = 0; i < n; ++i)
        {
            flags = pVertices[off + i].Type;
            x = (i16)pVertices[off + i].X;
            y = (i16)pVertices[off + i].Y;

            if (nextMove == i)
            {
                if (i != 0)
                    numVertices = sc_true_type_close_shape(pVertices, numVertices, wasOff, startOff, sx, sy, scx, scy, cx, cy);

                startOff = !(flags & 1);
                if (startOff)
                {
                    scx = x;
                    scy = y;
                    if ((pVertices[off + i + 1].Type & 1) == 0)
                    {
                        sx = (x + (i32)pVertices[off + i + 1].X) >> 1;
                        sy = (y + (i32)pVertices[off + i + 1].Y) >> 1;
                    }
                    else
                    {
                        sx = (i32)pVertices[off + i + 1].X;
                        sy = (i32)pVertices[off + i + 1].Y;
                        ++i;
                    }
                }
                else
                {
                    sx = x;
                    sy = y;
                }
                sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Move, sx, sy, 0, 0, 0, 0);
                wasOff = 0;
                nextMove = 1 + sc_true_type_u16_at(endPtsOfContours + j * 2);
                ++j;
            }
            else
            {
                if ((flags & 1) == 0)
                {
                    if (wasOff)
                        sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Curve, (cx + x) >> 1, (cy + y) >> 1, cx, cy, 0, 0);
                    cx = x;
                    cy = y;
                    wasOff = 1;
                }
                else
                {
                    if (wasOff)
                        sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Curve, x, y, cx, cy, 0, 0);
                    else
                        sc_true_type_set_vertex(&pVertices[numVertices++], ScTrueTypeVertexType_Line, x, y, 0, 0, 0, 0);
                    wasOff = 0;
                }
            }
        }
        numVertices = sc_true_type_close_shape(pVertices, numVertices, wasOff, startOff, sx, sy, scx, scy, cx, cy);
    }
    else if (numberOfContours < 0)
    {
        /* compound-глиф: рекурсия по компонентам с матрицей 2x2 */
        u8* pComp = pData + g + 10;
        i32 more = 1;
        while (more)
        {
            u16 flags = sc_true_type_u16_at(pComp);
            pComp += 2;
            u16 glyphIndex2 = sc_true_type_u16_at(pComp);
            pComp += 2;

            f32 mtx[6] = { 1, 0, 0, 1, 0, 0 };

            if (flags & 2)
            {
                if (flags & 1)
                {
                    mtx[4] = sc_true_type_i16_at(pComp);
                    mtx[5] = sc_true_type_i16_at(pComp + 2);
                    pComp += 4;
                }
                else
                {
                    mtx[4] = sc_true_type_i8_at(pComp);
                    mtx[5] = sc_true_type_i8_at(pComp + 1);
                    pComp += 2;
                }
            }
            else
            {
                /* matching-point: не поддерживается (как у stb) */
                sc_log_erro("sc_true_type_get_glyph_shape: compound matching-point is not supported\n");
                if (pVertices != ScNull)
                    sc_memory_free(pVertices);
                *ppVertices = ScNull;
                return 0;
            }

            if (flags & (1 << 3))
            {
                mtx[0] = mtx[3] = sc_true_type_i16_at(pComp) / 16384.0f;
                mtx[1] = mtx[2] = 0;
                pComp += 2;
            }
            else if (flags & (1 << 6))
            {
                mtx[0] = sc_true_type_i16_at(pComp) / 16384.0f;
                mtx[1] = mtx[2] = 0;
                mtx[3] = sc_true_type_i16_at(pComp + 2) / 16384.0f;
                pComp += 4;
            }
            else if (flags & (1 << 7))
            {
                mtx[0] = sc_true_type_i16_at(pComp) / 16384.0f;
                mtx[1] = sc_true_type_i16_at(pComp + 2) / 16384.0f;
                mtx[2] = sc_true_type_i16_at(pComp + 4) / 16384.0f;
                mtx[3] = sc_true_type_i16_at(pComp + 6) / 16384.0f;
                pComp += 8;
            }

            f32 m = (f32)sqrt((f64)(mtx[0] * mtx[0] + mtx[1] * mtx[1]));
            f32 n = (f32)sqrt((f64)(mtx[2] * mtx[2] + mtx[3] * mtx[3]));

            ScTrueTypeVertex* pCompVerts = ScNull;
            i32 compNumVerts = sc_true_type_get_glyph_shape(pInfo, glyphIndex2, &pCompVerts);
            if (compNumVerts > 0 && pCompVerts != ScNull)
            {
                ScTrueTypeVertex* pTmp = (ScTrueTypeVertex*)sc_memory_allocate((numVertices + compNumVerts) * sizeof(ScTrueTypeVertex));
                if (pTmp == ScNull)
                {
                    sc_memory_free(pCompVerts);
                    if (pVertices != ScNull)
                        sc_memory_free(pVertices);
                    *ppVertices = ScNull;
                    return 0;
                }

                for (i32 i = 0; i < compNumVerts; ++i)
                {
                    ScTrueTypeVertex* v = &pCompVerts[i];
                    f32 x = v->X;
                    f32 y = v->Y;
                    v->X = (i16)(m * (mtx[0] * x + mtx[2] * y + mtx[4]));
                    v->Y = (i16)(n * (mtx[1] * x + mtx[3] * y + mtx[5]));
                    x = v->ControlX;
                    y = v->ControlY;
                    v->ControlX = (i16)(m * (mtx[0] * x + mtx[2] * y + mtx[4]));
                    v->ControlY = (i16)(n * (mtx[1] * x + mtx[3] * y + mtx[5]));
                    x = v->ControlX1;
                    y = v->ControlY1;
                    v->ControlX1 = (i16)(m * (mtx[0] * x + mtx[2] * y + mtx[4]));
                    v->ControlY1 = (i16)(n * (mtx[1] * x + mtx[3] * y + mtx[5]));
                }

                if (numVertices > 0 && pVertices != ScNull)
                    memcpy(pTmp, pVertices, numVertices * sizeof(ScTrueTypeVertex));
                memcpy(pTmp + numVertices, pCompVerts, compNumVerts * sizeof(ScTrueTypeVertex));
                if (pVertices != ScNull)
                    sc_memory_free(pVertices);
                pVertices = pTmp;
                sc_memory_free(pCompVerts);
                numVertices += compNumVerts;
            }
            else
            {
                sc_true_type_free_shape(pCompVerts);
            }

            more = flags & (1 << 5);
        }
    }

    *ppVertices = pVertices;
    return numVertices;
}

/* //////////////////////////////////////////////////////////////////////// */
/* CFF Type2 charstrings */

typedef struct
{
    i32 Bounds;
    i32 Started;
    f32 FirstX, FirstY;
    f32 X, Y;
    i32 MinX, MaxX, MinY, MaxY;

    ScTrueTypeVertex* pVertices;
    i32 NumVertices;
} ScTrueTypeCsContext;

#define SC_TRUE_TYPE_CS_CONTEXT_INIT(bounds) { bounds, 0, 0, 0, 0, 0, 0, 0, 0, 0, ScNull, 0 }

static void
sc_true_type_track_vertex(ScTrueTypeCsContext* pCtx, i32 x, i32 y)
{
    if (x > pCtx->MaxX || !pCtx->Started) pCtx->MaxX = x;
    if (y > pCtx->MaxY || !pCtx->Started) pCtx->MaxY = y;
    if (x < pCtx->MinX || !pCtx->Started) pCtx->MinX = x;
    if (y < pCtx->MinY || !pCtx->Started) pCtx->MinY = y;
    pCtx->Started = 1;
}

static void
sc_true_type_cs_context_v(ScTrueTypeCsContext* pCtx, u8 type, i32 x, i32 y, i32 cx, i32 cy, i32 cx1, i32 cy1)
{
    if (pCtx->Bounds)
    {
        sc_true_type_track_vertex(pCtx, x, y);
        if (type == ScTrueTypeVertexType_Cubic)
        {
            sc_true_type_track_vertex(pCtx, cx, cy);
            sc_true_type_track_vertex(pCtx, cx1, cy1);
        }
    }
    else
    {
        sc_true_type_set_vertex(&pCtx->pVertices[pCtx->NumVertices], type, x, y, cx, cy, cx1, cy1);
    }
    ++pCtx->NumVertices;
}

static void
sc_true_type_cs_context_close_shape(ScTrueTypeCsContext* pCtx)
{
    if (pCtx->FirstX != pCtx->X || pCtx->FirstY != pCtx->Y)
        sc_true_type_cs_context_v(pCtx, ScTrueTypeVertexType_Line, (i32)pCtx->FirstX, (i32)pCtx->FirstY, 0, 0, 0, 0);
}

static void
sc_true_type_cs_context_rmove_to(ScTrueTypeCsContext* pCtx, f32 dx, f32 dy)
{
    sc_true_type_cs_context_close_shape(pCtx);
    pCtx->FirstX = pCtx->X = pCtx->X + dx;
    pCtx->FirstY = pCtx->Y = pCtx->Y + dy;
    sc_true_type_cs_context_v(pCtx, ScTrueTypeVertexType_Move, (i32)pCtx->X, (i32)pCtx->Y, 0, 0, 0, 0);
}

static void
sc_true_type_cs_context_rline_to(ScTrueTypeCsContext* pCtx, f32 dx, f32 dy)
{
    pCtx->X += dx;
    pCtx->Y += dy;
    sc_true_type_cs_context_v(pCtx, ScTrueTypeVertexType_Line, (i32)pCtx->X, (i32)pCtx->Y, 0, 0, 0, 0);
}

static void
sc_true_type_cs_context_rccurve_to(ScTrueTypeCsContext* pCtx, f32 dx1, f32 dy1, f32 dx2, f32 dy2, f32 dx3, f32 dy3)
{
    f32 cx1 = pCtx->X + dx1;
    f32 cy1 = pCtx->Y + dy1;
    f32 cx2 = cx1 + dx2;
    f32 cy2 = cy1 + dy2;
    pCtx->X = cx2 + dx3;
    pCtx->Y = cy2 + dy3;
    sc_true_type_cs_context_v(pCtx, ScTrueTypeVertexType_Cubic, (i32)pCtx->X, (i32)pCtx->Y, (i32)cx1, (i32)cy1, (i32)cx2, (i32)cy2);
}

static ScTrueTypeBuffer
sc_true_type_get_subr(ScTrueTypeBuffer idx, i32 n)
{
    i32 count = sc_true_type_cff_index_count(&idx);
    i32 bias = 107;
    if (count >= 33900)
        bias = 32768;
    else if (count >= 1240)
        bias = 1131;
    n += bias;
    if (n < 0 || n >= count)
        return sc_true_type_buffer_new(ScNull, 0);
    return sc_true_type_cff_index_get(idx, n);
}

/*
  DOCS: local subr глифа для CID-шрифта (fdselect -> fontdict -> subrs).
*/
static ScTrueTypeBuffer
sc_true_type_cid_get_glyph_subrs(ScTrueTypeFontInfo* pInfo, i32 glyphIndex)
{
    ScTrueTypeBuffer fdselect = sc_true_type_buffer_new(pInfo->FdSelect, pInfo->FdSelectSize);
    i32 fdselector = -1;

    sc_true_type_buffer_seek(&fdselect, 0);
    i32 fmt = sc_true_type_buffer_get8(&fdselect);
    if (fmt == 0)
    {
        sc_true_type_buffer_skip(&fdselect, glyphIndex);
        fdselector = sc_true_type_buffer_get8(&fdselect);
    }
    else if (fmt == 3)
    {
        i32 nranges = (i32)sc_true_type_buffer_get16(&fdselect);
        i32 start = (i32)sc_true_type_buffer_get16(&fdselect);
        for (i32 i = 0; i < nranges; ++i)
        {
            i32 v = sc_true_type_buffer_get8(&fdselect);
            i32 end = (i32)sc_true_type_buffer_get16(&fdselect);
            if (glyphIndex >= start && glyphIndex < end)
            {
                fdselector = v;
                break;
            }
            start = end;
        }
    }

    if (fdselector == -1)
        return sc_true_type_buffer_new(ScNull, 0);
    return sc_true_type_get_subrs(sc_true_type_buffer_new(pInfo->CffData, pInfo->CffSize),
                                  sc_true_type_cff_index_get(sc_true_type_buffer_new(pInfo->FontDicts, pInfo->FontDictsSize), fdselector));
}

/*
  DOCS: Интерпретатор Type2 charstring (rmoveto/rlineto/curveto/flex/
  callsubr/callgsubr/endchar...). Контекст - счётчик (bounds) или
  выходной массив вершин. Возвращает 0 при ошибке.
*/
static i32
sc_true_type_run_charstring(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, ScTrueTypeCsContext* pCtx)
{
    i32 inHeader = 1;
    i32 maskbits = 0;
    i32 subrStackHeight = 0;
    i32 sp = 0;
    i32 hasSubrs = 0;
    i32 clearStack;
    f32 s[48];
    ScTrueTypeBuffer subrStack[10];
    ScTrueTypeBuffer subrs = sc_true_type_buffer_new(pInfo->Subrs, pInfo->SubrsSize);
    ScTrueTypeBuffer b = sc_true_type_cff_index_get(sc_true_type_buffer_new(pInfo->Charstrings, pInfo->CharstringsSize), glyphIndex);
    f32 f;

    while (b.Cursor < b.Size)
    {
        i32 i = 0;
        clearStack = 1;
        i32 b0 = sc_true_type_buffer_get8(&b);
        switch (b0)
        {
        case 0x13: /* hintmask */
        case 0x14: /* cntrmask */
            if (inHeader)
                maskbits += (sp / 2);
            inHeader = 0;
            sc_true_type_buffer_skip(&b, (maskbits + 7) / 8);
            break;

        case 0x01: /* hstem */
        case 0x03: /* vstem */
        case 0x12: /* hstemhm */
        case 0x17: /* vstemhm */
            maskbits += (sp / 2);
            break;

        case 0x15: /* rmoveto */
            inHeader = 0;
            if (sp < 2) return 0;
            sc_true_type_cs_context_rmove_to(pCtx, s[sp - 2], s[sp - 1]);
            break;
        case 0x04: /* vmoveto */
            inHeader = 0;
            if (sp < 1) return 0;
            sc_true_type_cs_context_rmove_to(pCtx, 0, s[sp - 1]);
            break;
        case 0x16: /* hmoveto */
            inHeader = 0;
            if (sp < 1) return 0;
            sc_true_type_cs_context_rmove_to(pCtx, s[sp - 1], 0);
            break;

        case 0x05: /* rlineto */
            if (sp < 2) return 0;
            for (; i + 1 < sp; i += 2)
                sc_true_type_cs_context_rline_to(pCtx, s[i], s[i + 1]);
            break;

        case 0x07: /* vlineto */
            if (sp < 1) return 0;
            goto vlineto;
        case 0x06: /* hlineto */
            if (sp < 1) return 0;
            for (;;)
            {
                if (i >= sp) break;
                sc_true_type_cs_context_rline_to(pCtx, s[i], 0);
                ++i;
            vlineto:
                if (i >= sp) break;
                sc_true_type_cs_context_rline_to(pCtx, 0, s[i]);
                ++i;
            }
            break;

        case 0x1F: /* hvcurveto */
            if (sp < 4) return 0;
            goto hvcurveto;
        case 0x1E: /* vhcurveto */
            if (sp < 4) return 0;
            for (;;)
            {
                if (i + 3 >= sp) break;
                sc_true_type_cs_context_rccurve_to(pCtx, 0, s[i], s[i + 1], s[i + 2], s[i + 3], (sp - i == 5) ? s[i + 4] : 0.0f);
                i += 4;
            hvcurveto:
                if (i + 3 >= sp) break;
                sc_true_type_cs_context_rccurve_to(pCtx, s[i], 0, s[i + 1], s[i + 2], (sp - i == 5) ? s[i + 4] : 0.0f, s[i + 3]);
                i += 4;
            }
            break;

        case 0x08: /* rrcurveto */
            if (sp < 6) return 0;
            for (; i + 5 < sp; i += 6)
                sc_true_type_cs_context_rccurve_to(pCtx, s[i], s[i + 1], s[i + 2], s[i + 3], s[i + 4], s[i + 5]);
            break;

        case 0x18: /* rcurveline */
            if (sp < 8) return 0;
            for (; i + 5 < sp - 2; i += 6)
                sc_true_type_cs_context_rccurve_to(pCtx, s[i], s[i + 1], s[i + 2], s[i + 3], s[i + 4], s[i + 5]);
            if (i + 1 >= sp) return 0;
            sc_true_type_cs_context_rline_to(pCtx, s[i], s[i + 1]);
            break;

        case 0x19: /* rlinecurve */
            if (sp < 8) return 0;
            for (; i + 1 < sp - 6; i += 2)
                sc_true_type_cs_context_rline_to(pCtx, s[i], s[i + 1]);
            if (i + 5 >= sp) return 0;
            sc_true_type_cs_context_rccurve_to(pCtx, s[i], s[i + 1], s[i + 2], s[i + 3], s[i + 4], s[i + 5]);
            break;

        case 0x1A: /* vvcurveto */
        case 0x1B: /* hhcurveto */
            if (sp < 4) return 0;
            f = 0.0f;
            if (sp & 1) { f = s[i]; ++i; }
            for (; i + 3 < sp; i += 4)
            {
                if (b0 == 0x1B)
                    sc_true_type_cs_context_rccurve_to(pCtx, s[i], f, s[i + 1], s[i + 2], s[i + 3], 0.0f);
                else
                    sc_true_type_cs_context_rccurve_to(pCtx, f, s[i], s[i + 1], s[i + 2], 0.0f, s[i + 3]);
                f = 0.0f;
            }
            break;

        case 0x0A: /* callsubr */
            if (!hasSubrs)
            {
                if (pInfo->FdSelectSize != 0)
                    subrs = sc_true_type_cid_get_glyph_subrs(pInfo, glyphIndex);
                hasSubrs = 1;
            }
            /* fallthrough */
        case 0x1D: /* callgsubr */
            if (sp < 1) return 0;
            {
                i32 v = (i32)s[--sp];
                if (subrStackHeight >= 10) return 0;
                subrStack[subrStackHeight++] = b;
                b = sc_true_type_get_subr(b0 == 0x0A ? subrs : sc_true_type_buffer_new(pInfo->Gsubrs, pInfo->GsubrsSize), v);
                if (b.Size == 0) return 0;
                b.Cursor = 0;
                clearStack = 0;
            }
            break;

        case 0x0B: /* return */
            if (subrStackHeight <= 0) return 0;
            b = subrStack[--subrStackHeight];
            clearStack = 0;
            break;

        case 0x0E: /* endchar */
            sc_true_type_cs_context_close_shape(pCtx);
            return 1;

        case 0x0C: /* escape */
            {
                f32 dx1, dx2, dx3, dx4, dx5, dx6;
                f32 dy1, dy2, dy3, dy4, dy5, dy6;
                f32 dx, dy;
                i32 b1 = sc_true_type_buffer_get8(&b);
                switch (b1)
                {
                case 0x22: /* hflex */
                    if (sp < 7) return 0;
                    dx1 = s[0]; dx2 = s[1]; dy2 = s[2];
                    dx3 = s[3]; dx4 = s[4]; dx5 = s[5]; dx6 = s[6];
                    sc_true_type_cs_context_rccurve_to(pCtx, dx1, 0, dx2, dy2, dx3, 0);
                    sc_true_type_cs_context_rccurve_to(pCtx, dx4, 0, dx5, -dy2, dx6, 0);
                    break;

                case 0x23: /* flex */
                    if (sp < 13) return 0;
                    dx1 = s[0]; dy1 = s[1]; dx2 = s[2]; dy2 = s[3]; dx3 = s[4]; dy3 = s[5];
                    dx4 = s[6]; dy4 = s[7]; dx5 = s[8]; dy5 = s[9]; dx6 = s[10]; dy6 = s[11];
                    /* fd is s[12] */
                    sc_true_type_cs_context_rccurve_to(pCtx, dx1, dy1, dx2, dy2, dx3, dy3);
                    sc_true_type_cs_context_rccurve_to(pCtx, dx4, dy4, dx5, dy5, dx6, dy6);
                    break;

                case 0x24: /* hflex1 */
                    if (sp < 9) return 0;
                    dx1 = s[0]; dy1 = s[1]; dx2 = s[2]; dy2 = s[3]; dx3 = s[4];
                    dx4 = s[5]; dx5 = s[6]; dy5 = s[7]; dx6 = s[8];
                    sc_true_type_cs_context_rccurve_to(pCtx, dx1, dy1, dx2, dy2, dx3, 0);
                    sc_true_type_cs_context_rccurve_to(pCtx, dx4, 0, dx5, dy5, dx6, -(dy1 + dy2 + dy5));
                    break;

                case 0x25: /* flex1 */
                    if (sp < 11) return 0;
                    dx1 = s[0]; dy1 = s[1]; dx2 = s[2]; dy2 = s[3]; dx3 = s[4]; dy3 = s[5];
                    dx4 = s[6]; dy4 = s[7]; dx5 = s[8]; dy5 = s[9];
                    dx6 = dy6 = s[10];
                    dx = dx1 + dx2 + dx3 + dx4 + dx5;
                    dy = dy1 + dy2 + dy3 + dy4 + dy5;
                    if (fabs((f64)dx) > fabs((f64)dy))
                        dy6 = -dy;
                    else
                        dx6 = -dx;
                    sc_true_type_cs_context_rccurve_to(pCtx, dx1, dy1, dx2, dy2, dx3, dy3);
                    sc_true_type_cs_context_rccurve_to(pCtx, dx4, dy4, dx5, dy5, dx6, dy6);
                    break;

                default:
                    return 0;
                }
            }
            break;

        default:
            if (b0 != 255 && b0 != 28 && b0 < 32)
                return 0;

            /* push immediate */
            if (b0 == 255)
            {
                f = (f32)(i32)sc_true_type_buffer_get32(&b) / 0x10000l;
            }
            else
            {
                sc_true_type_buffer_skip(&b, -1);
                f = (f32)(i16)sc_true_type_cff_int(&b);
            }
            if (sp >= 48) return 0;
            s[sp++] = f;
            clearStack = 0;
            break;
        }
        if (clearStack)
            sp = 0;
    }
    return 0;
}

static i32
sc_true_type_get_glyph_shape_cff(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, ScTrueTypeVertex** ppVertices)
{
    /* два прохода: сначала подсчёт, затем вывод (без realloc) */
    ScTrueTypeCsContext countCtx = SC_TRUE_TYPE_CS_CONTEXT_INIT(1);
    ScTrueTypeCsContext outputCtx = SC_TRUE_TYPE_CS_CONTEXT_INIT(0);
    *ppVertices = ScNull;
    if (sc_true_type_run_charstring(pInfo, glyphIndex, &countCtx))
    {
        *ppVertices = (ScTrueTypeVertex*)sc_memory_allocate(countCtx.NumVertices * sizeof(ScTrueTypeVertex));
        if (*ppVertices == ScNull)
            return 0;
        outputCtx.pVertices = *ppVertices;
        if (sc_true_type_run_charstring(pInfo, glyphIndex, &outputCtx))
            return outputCtx.NumVertices;
    }
    if (*ppVertices != ScNull)
    {
        sc_memory_free(*ppVertices);
        *ppVertices = ScNull;
    }
    return 0;
}

static i32
sc_true_type_get_glyph_info_cff(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, i32* pX0, i32* pY0, i32* pX1, i32* pY1)
{
    ScTrueTypeCsContext ctx = SC_TRUE_TYPE_CS_CONTEXT_INIT(1);
    i32 r = sc_true_type_run_charstring(pInfo, glyphIndex, &ctx);
    if (pX0) *pX0 = r ? ctx.MinX : 0;
    if (pY0) *pY0 = r ? ctx.MinY : 0;
    if (pX1) *pX1 = r ? ctx.MaxX : 0;
    if (pY1) *pY1 = r ? ctx.MaxY : 0;
    return r ? ctx.NumVertices : 0;
}

i32
sc_true_type_get_glyph_shape(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, ScTrueTypeVertex** ppVertices)
{
    if (pInfo->CffSize == 0)
        return sc_true_type_get_glyph_shape_simple(pInfo, glyphIndex, ppVertices);
    return sc_true_type_get_glyph_shape_cff(pInfo, glyphIndex, ppVertices);
}

void
sc_true_type_free_shape(ScTrueTypeVertex* pVertices)
{
    if (pVertices != ScNull)
        sc_memory_free(pVertices);
}

i32
sc_true_type_is_glyph_empty(ScTrueTypeFontInfo* pInfo, i32 glyphIndex)
{
    if (pInfo->CffSize != 0)
        return sc_true_type_get_glyph_info_cff(pInfo, glyphIndex, ScNull, ScNull, ScNull, ScNull) == 0;
    i32 g = sc_true_type_get_glyf_offset(pInfo, glyphIndex);
    if (g < 0)
        return 1;
    return sc_true_type_i16_at(pInfo->pData + g) == 0;
}

i32
sc_true_type_get_glyph_box(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, i32* pX0, i32* pY0, i32* pX1, i32* pY1)
{
    if (pInfo->CffSize != 0)
    {
        sc_true_type_get_glyph_info_cff(pInfo, glyphIndex, pX0, pY0, pX1, pY1);
        return 1;
    }

    i32 g = sc_true_type_get_glyf_offset(pInfo, glyphIndex);
    if (g < 0)
        return 0;

    if (pX0) *pX0 = sc_true_type_i16_at(pInfo->pData + g + 2);
    if (pY0) *pY0 = sc_true_type_i16_at(pInfo->pData + g + 4);
    if (pX1) *pX1 = sc_true_type_i16_at(pInfo->pData + g + 6);
    if (pY1) *pY1 = sc_true_type_i16_at(pInfo->pData + g + 8);
    return 1;
}

/* //////////////////////////////////////////////////////////////////////// */
/* Метрики */

void
sc_true_type_get_glyph_h_metrics(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, i32* pAdvanceWidth, i32* pLeftSideBearing)
{
    u16 numOfLongHorMetrics = sc_true_type_u16_at(pInfo->pData + pInfo->Hhea + 34);
    if (glyphIndex < numOfLongHorMetrics)
    {
        if (pAdvanceWidth)    *pAdvanceWidth = sc_true_type_i16_at(pInfo->pData + pInfo->Hmtx + 4 * glyphIndex);
        if (pLeftSideBearing) *pLeftSideBearing = sc_true_type_i16_at(pInfo->pData + pInfo->Hmtx + 4 * glyphIndex + 2);
    }
    else
    {
        if (pAdvanceWidth)    *pAdvanceWidth = sc_true_type_i16_at(pInfo->pData + pInfo->Hmtx + 4 * (numOfLongHorMetrics - 1));
        if (pLeftSideBearing) *pLeftSideBearing = sc_true_type_i16_at(pInfo->pData + pInfo->Hmtx + 4 * numOfLongHorMetrics + 2 * (glyphIndex - numOfLongHorMetrics));
    }
}

void
sc_true_type_get_font_v_metrics(ScTrueTypeFontInfo* pInfo, i32* pAscent, i32* pDescent, i32* pLineGap)
{
    if (pAscent)  *pAscent = sc_true_type_i16_at(pInfo->pData + pInfo->Hhea + 4);
    if (pDescent) *pDescent = sc_true_type_i16_at(pInfo->pData + pInfo->Hhea + 6);
    if (pLineGap) *pLineGap = sc_true_type_i16_at(pInfo->pData + pInfo->Hhea + 8);
}

void
sc_true_type_get_font_bounding_box(ScTrueTypeFontInfo* pInfo, i32* pX0, i32* pY0, i32* pX1, i32* pY1)
{
    if (pX0) *pX0 = sc_true_type_i16_at(pInfo->pData + pInfo->Head + 36);
    if (pY0) *pY0 = sc_true_type_i16_at(pInfo->pData + pInfo->Head + 38);
    if (pX1) *pX1 = sc_true_type_i16_at(pInfo->pData + pInfo->Head + 40);
    if (pY1) *pY1 = sc_true_type_i16_at(pInfo->pData + pInfo->Head + 42);
}

f32
sc_true_type_scale_for_pixel_height(ScTrueTypeFontInfo* pInfo, f32 pixelHeight)
{
    i32 fontHeight = sc_true_type_i16_at(pInfo->pData + pInfo->Hhea + 4)
        - sc_true_type_i16_at(pInfo->pData + pInfo->Hhea + 6);
    return pixelHeight / (f32)fontHeight;
}

/* //////////////////////////////////////////////////////////////////////// */
/* Bitmap box */

i32
sc_true_type_get_glyph_bitmap_box_subpixel(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, f32 scaleX, f32 scaleY, f32 shiftX, f32 shiftY, i32* pIx0, i32* pIy0, i32* pIx1, i32* pIy1)
{
    i32 x0 = 0, y0 = 0, x1 = 0, y1 = 0;
    if (!sc_true_type_get_glyph_box(pInfo, glyphIndex, &x0, &y0, &x1, &y1))
    {
        /* например пробел */
        if (pIx0) *pIx0 = 0;
        if (pIy0) *pIy0 = 0;
        if (pIx1) *pIx1 = 0;
        if (pIy1) *pIy1 = 0;
        return 0;
    }

    if (pIx0) *pIx0 = (i32)floor((f64)(x0 * scaleX + shiftX));
    if (pIy0) *pIy0 = (i32)floor((f64)(-y1 * scaleY + shiftY));
    if (pIx1) *pIx1 = (i32)ceil((f64)(x1 * scaleX + shiftX));
    if (pIy1) *pIy1 = (i32)ceil((f64)(-y0 * scaleY + shiftY));
    return 1;
}

i32
sc_true_type_get_glyph_bitmap_box(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, f32 scaleX, f32 scaleY, i32* pIx0, i32* pIy0, i32* pIx1, i32* pIy1)
{
    return sc_true_type_get_glyph_bitmap_box_subpixel(pInfo, glyphIndex, scaleX, scaleY, 0.0f, 0.0f, pIx0, pIy0, pIx1, pIy1);
}

/* //////////////////////////////////////////////////////////////////////// */
/* Растеризатор v2 (DirectAA) */

typedef struct ScTrueTypeHHeapChunk
{
    struct ScTrueTypeHHeapChunk* pNext;
} ScTrueTypeHHeapChunk;

typedef struct
{
    ScTrueTypeHHeapChunk* pHead;
    void* pFirstFree;
    i32 NumRemainingInHeadChunk;
} ScTrueTypeHHeap;

static void*
sc_true_type_hheap_alloc(ScTrueTypeHHeap* pHeap, i64 size)
{
    if (pHeap->pFirstFree)
    {
        void* p = pHeap->pFirstFree;
        pHeap->pFirstFree = *(void**)p;
        return p;
    }
    else
    {
        if (pHeap->NumRemainingInHeadChunk == 0)
        {
            i32 count = (size < 32) ? 2000 : (size < 128) ? 800 : 100;
            ScTrueTypeHHeapChunk* pChunk = (ScTrueTypeHHeapChunk*)sc_memory_allocate(sizeof(ScTrueTypeHHeapChunk) + size * count);
            if (pChunk == ScNull)
                return ScNull;
            pChunk->pNext = pHeap->pHead;
            pHeap->pHead = pChunk;
            pHeap->NumRemainingInHeadChunk = count;
        }
        --pHeap->NumRemainingInHeadChunk;
        return (char*)pHeap->pHead + sizeof(ScTrueTypeHHeapChunk) + size * pHeap->NumRemainingInHeadChunk;
    }
}

static void
sc_true_type_hheap_free(ScTrueTypeHHeap* pHeap, void* p)
{
    *(void**)p = pHeap->pFirstFree;
    pHeap->pFirstFree = p;
}

static void
sc_true_type_hheap_cleanup(ScTrueTypeHHeap* pHeap)
{
    ScTrueTypeHHeapChunk* pChunk = pHeap->pHead;
    while (pChunk != ScNull)
    {
        ScTrueTypeHHeapChunk* pNext = pChunk->pNext;
        sc_memory_free(pChunk);
        pChunk = pNext;
    }
}

typedef struct
{
    f32 X0, Y0, X1, Y1;
    i32 Invert;
} ScTrueTypeEdge;

typedef struct ScTrueTypeActiveEdge
{
    struct ScTrueTypeActiveEdge* pNext;
    f32 Fx, Fdx, Fdy;
    f32 Direction;
    f32 Sy, Ey;
} ScTrueTypeActiveEdge;

static ScTrueTypeActiveEdge*
sc_true_type_new_active(ScTrueTypeHHeap* pHeap, ScTrueTypeEdge* pEdge, i32 offX, f32 startPoint)
{
    ScTrueTypeActiveEdge* pZ = (ScTrueTypeActiveEdge*)sc_true_type_hheap_alloc(pHeap, sizeof(ScTrueTypeActiveEdge));
    f32 dxdy = (pEdge->X1 - pEdge->X0) / (pEdge->Y1 - pEdge->Y0);
    if (pZ == ScNull)
        return pZ;

    pZ->Fdx = dxdy;
    pZ->Fdy = dxdy != 0.0f ? (1.0f / dxdy) : 0.0f;
    pZ->Fx = pEdge->X0 + dxdy * (startPoint - pEdge->Y0);
    pZ->Fx -= offX;
    pZ->Direction = pEdge->Invert ? 1.0f : -1.0f;
    pZ->Sy = pEdge->Y0;
    pZ->Ey = pEdge->Y1;
    pZ->pNext = ScNull;
    return pZ;
}

/*
  DOCS: Ребро уже клипнуто к вертикальным линиям x и x+1.
*/
static void
sc_true_type_handle_clipped_edge(f32* pScanline, i32 x, ScTrueTypeActiveEdge* pEdge, f32 x0, f32 y0, f32 x1, f32 y1)
{
    if (y0 == y1) return;
    if (y0 > pEdge->Ey) return;
    if (y1 < pEdge->Sy) return;
    if (y0 < pEdge->Sy)
    {
        x0 += (x1 - x0) * (pEdge->Sy - y0) / (y1 - y0);
        y0 = pEdge->Sy;
    }
    if (y1 > pEdge->Ey)
    {
        x1 += (x1 - x0) * (pEdge->Ey - y1) / (y1 - y0);
        y1 = pEdge->Ey;
    }

    if (x0 <= x && x1 <= x)
        pScanline[x] += pEdge->Direction * (y1 - y0);
    else if (x0 >= x + 1 && x1 >= x + 1)
    {
        /* правее пикселя: ничего */
    }
    else
    {
        pScanline[x] += pEdge->Direction * (y1 - y0) * (1 - ((x0 - x) + (x1 - x)) / 2); /* coverage = 1 - средняя позиция x */
    }
}

static f32
sc_true_type_sized_trapezoid_area(f32 height, f32 topWidth, f32 bottomWidth)
{
    return (topWidth + bottomWidth) / 2.0f * height;
}

static f32
sc_true_type_position_trapezoid_area(f32 height, f32 tx0, f32 tx1, f32 bx0, f32 bx1)
{
    return sc_true_type_sized_trapezoid_area(height, tx1 - tx0, bx1 - bx0);
}

static f32
sc_true_type_sized_triangle_area(f32 height, f32 width)
{
    return height * width / 2;
}

static void
sc_true_type_fill_active_edges(f32* pScanline, f32* pScanlineFill, i32 len, ScTrueTypeActiveEdge* pEdge, f32 yTop)
{
    f32 yBottom = yTop + 1;

    while (pEdge)
    {
        if (pEdge->Fdx == 0)
        {
            f32 x0 = pEdge->Fx;
            if (x0 < len)
            {
                if (x0 >= 0)
                {
                    sc_true_type_handle_clipped_edge(pScanline, (i32)x0, pEdge, x0, yTop, x0, yBottom);
                    sc_true_type_handle_clipped_edge(pScanlineFill - 1, (i32)x0 + 1, pEdge, x0, yTop, x0, yBottom);
                }
                else
                {
                    sc_true_type_handle_clipped_edge(pScanlineFill - 1, 0, pEdge, x0, yTop, x0, yBottom);
                }
            }
        }
        else
        {
            f32 x0 = pEdge->Fx;
            f32 dx = pEdge->Fdx;
            f32 xb = x0 + dx;
            f32 xTop, xBottom;
            f32 sy0, sy1;
            f32 dy = pEdge->Fdy;

            if (pEdge->Sy > yTop)
            {
                xTop = x0 + dx * (pEdge->Sy - yTop);
                sy0 = pEdge->Sy;
            }
            else
            {
                xTop = x0;
                sy0 = yTop;
            }
            if (pEdge->Ey < yBottom)
            {
                xBottom = x0 + dx * (pEdge->Ey - yTop);
                sy1 = pEdge->Ey;
            }
            else
            {
                xBottom = xb;
                sy1 = yBottom;
            }

            if (xTop >= 0 && xBottom >= 0 && xTop < len && xBottom < len)
            {
                if ((i32)xTop == (i32)xBottom)
                {
                    /* один пиксель */
                    i32 x = (i32)xTop;
                    f32 height = (sy1 - sy0) * pEdge->Direction;
                    pScanline[x] += sc_true_type_position_trapezoid_area(height, xTop, x + 1.0f, xBottom, x + 1.0f);
                    pScanlineFill[x] += height;
                }
                else
                {
                    i32 x, x1, x2;
                    f32 yCrossing, yFinal, step, sign, area;

                    if (xTop > xBottom)
                    {
                        /* переворачиваем; знак площади не меняется */
                        f32 t;
                        sy0 = yBottom - (sy0 - yTop);
                        sy1 = yBottom - (sy1 - yTop);
                        t = sy0; sy0 = sy1; sy1 = t;
                        t = xBottom; xBottom = xTop; xTop = t;
                        dx = -dx;
                        dy = -dy;
                        t = x0; x0 = xb; xb = t;
                    }

                    x1 = (i32)xTop;
                    x2 = (i32)xBottom;
                    yCrossing = yTop + dy * (x1 + 1 - x0);
                    yFinal = yTop + dy * (x2 - x0);

                    if (yCrossing > yBottom)
                        yCrossing = yBottom;

                    sign = pEdge->Direction;

                    area = sign * (yCrossing - sy0);
                    pScanline[x1] += sc_true_type_sized_triangle_area(area, x1 + 1 - xTop);

                    if (yFinal > yBottom)
                    {
                        yFinal = yBottom;
                        dy = (yFinal - yCrossing) / (x2 - (x1 + 1));
                    }

                    step = sign * dy * 1;

                    for (x = x1 + 1; x < x2; ++x)
                    {
                        pScanline[x] += area + step / 2;
                        area += step;
                    }

                    pScanline[x2] += area + sign * sc_true_type_position_trapezoid_area(sy1 - yFinal, (f32)x2, x2 + 1.0f, xBottom, x2 + 1.0f);
                    pScanlineFill[x2] += sign * (sy1 - sy0);
                }
            }
            else
            {
                /* ребро вне битмапы: медленный brute force по всем пикселям */
                for (i32 x = 0; x < len; ++x)
                {
                    f32 y0 = yTop;
                    f32 x1 = (f32)x;
                    f32 x2 = (f32)(x + 1);
                    f32 x3 = xb;
                    f32 y3 = yBottom;

                    f32 y1 = (x - x0) / dx + yTop;
                    f32 y2 = (x + 1 - x0) / dx + yTop;

                    if (x0 < x1 && x3 > x2)
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x1, y1);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x1, y1, x2, y2);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x2, y2, x3, y3);
                    }
                    else if (x3 < x1 && x0 > x2)
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x2, y2);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x2, y2, x1, y1);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x1, y1, x3, y3);
                    }
                    else if (x0 < x1 && x3 > x1)
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x1, y1);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x1, y1, x3, y3);
                    }
                    else if (x3 < x1 && x0 > x1)
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x1, y1);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x1, y1, x3, y3);
                    }
                    else if (x0 < x2 && x3 > x2)
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x2, y2);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x2, y2, x3, y3);
                    }
                    else if (x3 < x2 && x0 > x2)
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x2, y2);
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x2, y2, x3, y3);
                    }
                    else
                    {
                        sc_true_type_handle_clipped_edge(pScanline, x, pEdge, x0, y0, x3, y3);
                    }
                }
            }
        }
        pEdge = pEdge->pNext;
    }
}

static void
sc_true_type_rasterize_sorted_edges(ScTrueTypeBitmap* pResult, ScTrueTypeEdge* pEdges, i32 n, i32 offX, i32 offY)
{
    ScTrueTypeHHeap heap = { ScNull, ScNull, 0 };
    ScTrueTypeActiveEdge* pActive = ScNull;
    i32 y = offY;
    i32 j = 0;
    f32 scanlineData[129];
    f32* pScanline;
    f32* pScanline2;

    if (pResult->Width > 64)
        pScanline = (f32*)sc_memory_allocate((pResult->Width * 2 + 1) * sizeof(f32));
    else
        pScanline = scanlineData;

    pScanline2 = pScanline + pResult->Width;

    pEdges[n].Y0 = (f32)(offY + pResult->Height) + 1;

    while (j < pResult->Height)
    {
        f32 scanYTop = (f32)y + 0.0f;
        f32 scanYBottom = (f32)y + 1.0f;
        ScTrueTypeActiveEdge** ppStep = &pActive;

        memset(pScanline, 0, pResult->Width * sizeof(f32));
        memset(pScanline2, 0, (pResult->Width + 1) * sizeof(f32));

        /* удалить завершившиеся рёбра */
        while (*ppStep)
        {
            ScTrueTypeActiveEdge* pZ = *ppStep;
            if (pZ->Ey <= scanYTop)
            {
                *ppStep = pZ->pNext;
                pZ->Direction = 0;
                sc_true_type_hheap_free(&heap, pZ);
            }
            else
            {
                ppStep = &(*ppStep)->pNext;
            }
        }

        /* вставить начинающиеся рёбра */
        while (pEdges->Y0 <= scanYBottom)
        {
            if (pEdges->Y0 != pEdges->Y1)
            {
                ScTrueTypeActiveEdge* pZ = sc_true_type_new_active(&heap, pEdges, offX, scanYTop);
                if (pZ != ScNull)
                {
                    if (j == 0 && offY != 0)
                    {
                        if (pZ->Ey < scanYTop)
                            pZ->Ey = scanYTop;
                    }
                    pZ->pNext = pActive;
                    pActive = pZ;
                }
            }
            ++pEdges;
        }

        if (pActive != ScNull)
            sc_true_type_fill_active_edges(pScanline, pScanline2 + 1, pResult->Width, pActive, scanYTop);

        {
            f32 sum = 0;
            for (i32 i = 0; i < pResult->Width; ++i)
            {
                f32 k;
                i32 m;
                sum += pScanline2[i];
                k = pScanline[i] + sum;
                k = (f32)fabs((f64)k) * 255 + 0.5f;
                m = (i32)k;
                if (m > 255) m = 255;
                pResult->pPixels[j * pResult->Stride + i] = (u8)m;
            }
        }

        /* сдвинуть рёбра */
        ppStep = &pActive;
        while (*ppStep)
        {
            ScTrueTypeActiveEdge* pZ = *ppStep;
            pZ->Fx += pZ->Fdx;
            ppStep = &(*ppStep)->pNext;
        }

        ++y;
        ++j;
    }

    sc_true_type_hheap_cleanup(&heap);

    if (pScanline != scanlineData)
        sc_memory_free(pScanline);
}

#define SC_TRUE_TYPE_EDGE_COMPARE(a, b) ((a)->Y0 < (b)->Y0)

static void
sc_true_type_sort_edges_ins_sort(ScTrueTypeEdge* p, i32 n)
{
    for (i32 i = 1; i < n; ++i)
    {
        ScTrueTypeEdge t = p[i];
        ScTrueTypeEdge* a = &t;
        i32 j = i;
        while (j > 0)
        {
            ScTrueTypeEdge* b = &p[j - 1];
            i32 c = SC_TRUE_TYPE_EDGE_COMPARE(a, b);
            if (!c) break;
            p[j] = p[j - 1];
            --j;
        }
        if (i != j)
            p[j] = t;
    }
}

static void
sc_true_type_sort_edges_quicksort(ScTrueTypeEdge* p, i32 n)
{
    while (n > 12)
    {
        ScTrueTypeEdge t;
        i32 c01, c12, c, m, i, j;

        m = n >> 1;
        c01 = SC_TRUE_TYPE_EDGE_COMPARE(&p[0], &p[m]);
        c12 = SC_TRUE_TYPE_EDGE_COMPARE(&p[m], &p[n - 1]);
        if (c01 != c12)
        {
            i32 z;
            c = SC_TRUE_TYPE_EDGE_COMPARE(&p[0], &p[n - 1]);
            z = (c == c12) ? 0 : n - 1;
            t = p[z];
            p[z] = p[m];
            p[m] = t;
        }
        t = p[0];
        p[0] = p[m];
        p[m] = t;

        i = 1;
        j = n - 1;
        for (;;)
        {
            for (;; ++i)
                if (!SC_TRUE_TYPE_EDGE_COMPARE(&p[i], &p[0])) break;
            for (;; --j)
                if (!SC_TRUE_TYPE_EDGE_COMPARE(&p[0], &p[j])) break;
            if (i >= j) break;
            t = p[i];
            p[i] = p[j];
            p[j] = t;

            ++i;
            --j;
        }
        if (j < (n - i))
        {
            sc_true_type_sort_edges_quicksort(p, j);
            p = p + i;
            n = n - i;
        }
        else
        {
            sc_true_type_sort_edges_quicksort(p + i, n - i);
            n = j;
        }
    }
}

static void
sc_true_type_sort_edges(ScTrueTypeEdge* p, i32 n)
{
    sc_true_type_sort_edges_quicksort(p, n);
    sc_true_type_sort_edges_ins_sort(p, n);
}

typedef struct
{
    f32 X, Y;
} ScTrueTypePoint;

static void
sc_true_type_rasterize(ScTrueTypeBitmap* pResult, ScTrueTypePoint* pPts, i32* pWCount, i32 windings, f32 scaleX, f32 scaleY, f32 shiftX, f32 shiftY, i32 offX, i32 offY, i32 invert)
{
    f32 yScaleInv = invert ? -scaleY : scaleY;
    ScTrueTypeEdge* pEdges;
    i32 n = 0;
    i32 i, j, k, m;

    for (i = 0; i < windings; ++i)
        n += pWCount[i];

    /* +1 sentinel */
    pEdges = (ScTrueTypeEdge*)sc_memory_allocate(sizeof(ScTrueTypeEdge) * (n + 1));
    if (pEdges == ScNull)
        return;
    n = 0;

    m = 0;
    for (i = 0; i < windings; ++i)
    {
        ScTrueTypePoint* p = pPts + m;
        m += pWCount[i];
        j = pWCount[i] - 1;
        for (k = 0; k < pWCount[i]; j = k++)
        {
            i32 a = k, b = j;
            if (p[j].Y == p[k].Y)
                continue;
            pEdges[n].Invert = 0;
            if (invert ? p[j].Y > p[k].Y : p[j].Y < p[k].Y)
            {
                pEdges[n].Invert = 1;
                a = j;
                b = k;
            }
            pEdges[n].X0 = p[a].X * scaleX + shiftX;
            pEdges[n].Y0 = (p[a].Y * yScaleInv + shiftY);
            pEdges[n].X1 = p[b].X * scaleX + shiftX;
            pEdges[n].Y1 = (p[b].Y * yScaleInv + shiftY);
            ++n;
        }
    }

    sc_true_type_sort_edges(pEdges, n);
    sc_true_type_rasterize_sorted_edges(pResult, pEdges, n, offX, offY);

    sc_memory_free(pEdges);
}

static void
sc_true_type_add_point(ScTrueTypePoint* pPoints, i32 n, f32 x, f32 y)
{
    if (!pPoints) return;
    pPoints[n].X = x;
    pPoints[n].Y = y;
}

/*
  DOCS: Тесселяция квадратичной кривой до флэтнеса (рекурсия де
  Кастельжо).
*/
static i32
sc_true_type_tesselate_curve(ScTrueTypePoint* pPoints, i32* pNumPoints, f32 x0, f32 y0, f32 x1, f32 y1, f32 x2, f32 y2, f32 objspaceFlatnessSquared, i32 n)
{
    f32 mx = (x0 + 2 * x1 + x2) / 4;
    f32 my = (y0 + 2 * y1 + y2) / 4;
    f32 dx = (x0 + x2) / 2 - mx;
    f32 dy = (y0 + y2) / 2 - my;
    if (n > 16)
        return 1;
    if (dx * dx + dy * dy > objspaceFlatnessSquared)
    {
        sc_true_type_tesselate_curve(pPoints, pNumPoints, x0, y0, (x0 + x1) / 2.0f, (y0 + y1) / 2.0f, mx, my, objspaceFlatnessSquared, n + 1);
        sc_true_type_tesselate_curve(pPoints, pNumPoints, mx, my, (x1 + x2) / 2.0f, (y1 + y2) / 2.0f, x2, y2, objspaceFlatnessSquared, n + 1);
    }
    else
    {
        sc_true_type_add_point(pPoints, *pNumPoints, x2, y2);
        *pNumPoints = *pNumPoints + 1;
    }
    return 1;
}

static void
sc_true_type_tesselate_cubic(ScTrueTypePoint* pPoints, i32* pNumPoints, f32 x0, f32 y0, f32 x1, f32 y1, f32 x2, f32 y2, f32 x3, f32 y3, f32 objspaceFlatnessSquared, i32 n)
{
    f32 dx0 = x1 - x0;
    f32 dy0 = y1 - y0;
    f32 dx1 = x2 - x1;
    f32 dy1 = y2 - y1;
    f32 dx2 = x3 - x2;
    f32 dy2 = y3 - y2;
    f32 dx = x3 - x0;
    f32 dy = y3 - y0;
    f32 longlen = (f32)(sqrt((f64)(dx0 * dx0 + dy0 * dy0)) + sqrt((f64)(dx1 * dx1 + dy1 * dy1)) + sqrt((f64)(dx2 * dx2 + dy2 * dy2)));
    f32 shortlen = (f32)sqrt((f64)(dx * dx + dy * dy));
    f32 flatnessSquared = longlen * longlen - shortlen * shortlen;

    if (n > 16)
        return;

    if (flatnessSquared > objspaceFlatnessSquared)
    {
        f32 x01 = (x0 + x1) / 2;
        f32 y01 = (y0 + y1) / 2;
        f32 x12 = (x1 + x2) / 2;
        f32 y12 = (y1 + y2) / 2;
        f32 x23 = (x2 + x3) / 2;
        f32 y23 = (y2 + y3) / 2;

        f32 xa = (x01 + x12) / 2;
        f32 ya = (y01 + y12) / 2;
        f32 xb = (x12 + x23) / 2;
        f32 yb = (y12 + y23) / 2;

        f32 mx = (xa + xb) / 2;
        f32 my = (ya + yb) / 2;

        sc_true_type_tesselate_cubic(pPoints, pNumPoints, x0, y0, x01, y01, xa, ya, mx, my, objspaceFlatnessSquared, n + 1);
        sc_true_type_tesselate_cubic(pPoints, pNumPoints, mx, my, xb, yb, x23, y23, x3, y3, objspaceFlatnessSquared, n + 1);
    }
    else
    {
        sc_true_type_add_point(pPoints, *pNumPoints, x3, y3);
        *pNumPoints = *pNumPoints + 1;
    }
}

/*
  DOCS: Контур -> точки (тесселяция кривых), два прохода (подсчёт +
  вывод, как у stb).
*/
static ScTrueTypePoint*
sc_true_type_flatten_curves(ScTrueTypeVertex* pVertices, i32 numVerts, f32 objspaceFlatness, i32** ppContourLengths, i32* pNumContours)
{
    ScTrueTypePoint* pPoints = ScNull;
    i32 numPoints = 0;

    f32 objspaceFlatnessSquared = objspaceFlatness * objspaceFlatness;
    i32 i, n = 0, start = 0;
    i32 pass;

    for (i = 0; i < numVerts; ++i)
        if (pVertices[i].Type == ScTrueTypeVertexType_Move)
            ++n;

    *pNumContours = n;
    if (n == 0)
        return ScNull;

    *ppContourLengths = (i32*)sc_memory_allocate(sizeof(i32) * n);
    if (*ppContourLengths == ScNull)
    {
        *pNumContours = 0;
        return ScNull;
    }

    for (pass = 0; pass < 2; ++pass)
    {
        f32 x = 0, y = 0;
        if (pass == 1)
        {
            pPoints = (ScTrueTypePoint*)sc_memory_allocate(numPoints * sizeof(ScTrueTypePoint));
            if (pPoints == ScNull)
                goto error;
        }
        numPoints = 0;
        n = -1;
        for (i = 0; i < numVerts; ++i)
        {
            switch (pVertices[i].Type)
            {
            case ScTrueTypeVertexType_Move:
                if (n >= 0)
                    (*ppContourLengths)[n] = numPoints - start;
                ++n;
                start = numPoints;

                x = pVertices[i].X;
                y = pVertices[i].Y;
                sc_true_type_add_point(pPoints, numPoints++, x, y);
                break;
            case ScTrueTypeVertexType_Line:
                x = pVertices[i].X;
                y = pVertices[i].Y;
                sc_true_type_add_point(pPoints, numPoints++, x, y);
                break;
            case ScTrueTypeVertexType_Curve:
                sc_true_type_tesselate_curve(pPoints, &numPoints, x, y,
                                             pVertices[i].ControlX, pVertices[i].ControlY,
                                             pVertices[i].X, pVertices[i].Y,
                                             objspaceFlatnessSquared, 0);
                x = pVertices[i].X;
                y = pVertices[i].Y;
                break;
            case ScTrueTypeVertexType_Cubic:
                sc_true_type_tesselate_cubic(pPoints, &numPoints, x, y,
                                             pVertices[i].ControlX, pVertices[i].ControlY,
                                             pVertices[i].ControlX1, pVertices[i].ControlY1,
                                             pVertices[i].X, pVertices[i].Y,
                                             objspaceFlatnessSquared, 0);
                x = pVertices[i].X;
                y = pVertices[i].Y;
                break;
            }
        }
        (*ppContourLengths)[n] = numPoints - start;
    }

    return pPoints;

error:
    sc_memory_free(pPoints);
    sc_memory_free(*ppContourLengths);
    *ppContourLengths = ScNull;
    *pNumContours = 0;
    return ScNull;
}

/*
  DOCS: Растеризация вершин глифа в битмапу (flattening + scanline).
*/
static void
sc_true_type_rasterize_vertices(ScTrueTypeBitmap* pResult, f32 flatnessInPixels, ScTrueTypeVertex* pVertices, i32 numVerts, f32 scaleX, f32 scaleY, f32 shiftX, f32 shiftY, i32 xOff, i32 yOff, i32 invert)
{
    f32 scale = scaleX > scaleY ? scaleY : scaleX;
    i32 windingCount = 0;
    i32* pWindingLengths = ScNull;
    ScTrueTypePoint* pWindings = sc_true_type_flatten_curves(pVertices, numVerts, flatnessInPixels / scale, &pWindingLengths, &windingCount);
    if (pWindings != ScNull)
    {
        sc_true_type_rasterize(pResult, pWindings, pWindingLengths, windingCount, scaleX, scaleY, shiftX, shiftY, xOff, yOff, invert);
        sc_memory_free(pWindingLengths);
        sc_memory_free(pWindings);
    }
}

void
sc_true_type_make_glyph_bitmap_subpixel(ScTrueTypeFontInfo* pInfo, u8* pOutput, i32 outWidth, i32 outHeight, i32 outStride, f32 scaleX, f32 scaleY, f32 shiftX, f32 shiftY, i32 glyphIndex)
{
    i32 ix0, iy0;
    ScTrueTypeVertex* pVertices;
    i32 numVerts = sc_true_type_get_glyph_shape(pInfo, glyphIndex, &pVertices);
    ScTrueTypeBitmap gbm;

    sc_true_type_get_glyph_bitmap_box_subpixel(pInfo, glyphIndex, scaleX, scaleY, shiftX, shiftY, &ix0, &iy0, ScNull, ScNull);
    gbm.pPixels = pOutput;
    gbm.Width = outWidth;
    gbm.Height = outHeight;
    gbm.Stride = outStride;

    if (gbm.Width != 0 && gbm.Height != 0)
        sc_true_type_rasterize_vertices(&gbm, 0.35f, pVertices, numVerts, scaleX, scaleY, shiftX, shiftY, ix0, iy0, 1);

    sc_true_type_free_shape(pVertices);
}

void
sc_true_type_make_glyph_bitmap(ScTrueTypeFontInfo* pInfo, u8* pOutput, i32 outWidth, i32 outHeight, i32 outStride, f32 scaleX, f32 scaleY, i32 glyphIndex)
{
    sc_true_type_make_glyph_bitmap_subpixel(pInfo, pOutput, outWidth, outHeight, outStride, scaleX, scaleY, 0.0f, 0.0f, glyphIndex);
}

i32
sc_true_type_get_glyph_bitmap(ScTrueTypeFontInfo* pInfo, f32 scaleX, f32 scaleY, i32 glyphIndex, i32* pWidth, i32* pHeight, i32* pXoff, i32* pYoff, ScTrueTypeBitmap* pBitmapOut)
{
    i32 ix0, iy0, ix1, iy1;
    ScTrueTypeVertex* pVertices;
    i32 numVerts = sc_true_type_get_glyph_shape(pInfo, glyphIndex, &pVertices);

    if (scaleX == 0) scaleX = scaleY;
    if (scaleY == 0)
    {
        if (scaleX == 0)
        {
            sc_true_type_free_shape(pVertices);
            return 0;
        }
        scaleY = scaleX;
    }

    sc_true_type_get_glyph_bitmap_box_subpixel(pInfo, glyphIndex, scaleX, scaleY, 0.0f, 0.0f, &ix0, &iy0, &ix1, &iy1);

    pBitmapOut->Width = ix1 - ix0;
    pBitmapOut->Height = iy1 - iy0;
    pBitmapOut->pPixels = ScNull;

    if (pWidth)  *pWidth = pBitmapOut->Width;
    if (pHeight) *pHeight = pBitmapOut->Height;
    if (pXoff)   *pXoff = ix0;
    if (pYoff)   *pYoff = iy0;

    if (pBitmapOut->Width != 0 && pBitmapOut->Height != 0)
    {
        pBitmapOut->pPixels = (u8*)sc_memory_allocate(pBitmapOut->Width * pBitmapOut->Height);
        if (pBitmapOut->pPixels != ScNull)
        {
            pBitmapOut->Stride = pBitmapOut->Width;
            sc_true_type_rasterize_vertices(pBitmapOut, 0.35f, pVertices, numVerts, scaleX, scaleY, 0.0f, 0.0f, ix0, iy0, 1);
        }
    }

    sc_true_type_free_shape(pVertices);
    return pBitmapOut->pPixels != ScNull ? 1 : 0;
}

void
sc_true_type_free_bitmap(ScTrueTypeBitmap* pBitmap)
{
    if (pBitmap->pPixels != ScNull)
        sc_memory_free(pBitmap->pPixels);
    pBitmap->pPixels = ScNull;
}
