/*
  DOCS: TrueType/OpenType - нативный парсер и растеризатор глифов
  (без stb, по мотивам stb_truetype).

  Поддерживается:
    - контейнеры sfnt: TrueType 1.0, OpenType 1.0, Apple "true",
      TrueType Collection (.ttc), CFF/Type2 (.otf);
    - cmap: форматы 0, 4, 6, 12, 13 (MS/Unicode-платформы);
    - глифы: TrueType glyf/loca (простые + compound), CFF Type2
      charstrings (включая CID/subr);
    - горизонтальные метрики: hmtx/hhea, OS/2, bounding box шрифта;
    - растеризация глифов в 8-битную coverage-маску (антиалиасинг,
      DirectAA scanline-алгоритм stb_truetype v2).

  Контракт: pFontInfo ссылается на pData (копия не делается, буфер
  должен жить пока жив ScTrueTypeFontInfo); глифы и метрики в
  "несмасштабированных" координатах шрифта (unitsPerEm).
*/
#ifndef SC_TRUE_TYPE_H
#define SC_TRUE_TYPE_H

#include "Sc/Types.h"

/*
  DOCS: Тип контура глифа: vmove - начало контура, vline - линия,
  vcurve - квадратичная кривая Безье, vcubic - кубическая.
*/
typedef enum
{
    ScTrueTypeVertexType_Move = 1,
    ScTrueTypeVertexType_Line,
    ScTrueTypeVertexType_Curve,
    ScTrueTypeVertexType_Cubic,
} ScTrueTypeVertexType;

/*
  DOCS: Вершина контура глифа в несмасштабированных координатах.
  Для Curve ControlX/Y - контрольная точка, для Cubic - обе.
*/
typedef struct
{
    i16 X, Y;
    i16 ControlX, ControlY;
    i16 ControlX1, ControlY1;
    u8 Type;
    u8 Padding;
} ScTrueTypeVertex;

/*
  DOCS: 8-битная битмапа глифа (одноканальная coverage-маска).
  Pixels выделяется sc_memory_allocate / освобождается sc_memory_free.
*/
typedef struct
{
    i32 Width;
    i32 Height;
    i32 Stride;
    u8* pPixels;
} ScTrueTypeBitmap;

/*
  DOCS: Контекст загруженного шрифта. Заполняется sc_true_type_init,
  поле pData должно быть валидно всё время использования. Остальные
  поля - внутренние, не менять вручную.
*/
typedef struct
{
    u8* pData;     // DOCS: указатель на данные шрифта (не копируется)
    i32 FontStart; // DOCS: смещение начала шрифта (для .ttc - индекс)

    i32 NumGlyphs;

    i32 Loca, Head, Glyf, Hhea, Hmtx, Kern, Gpos; // смещения таблиц
    i32 IndexMap;      // выбранная cmap-подтаблица
    i32 IndexToLocFormat;

    /* CFF (Type2) данные: нулевой Size - шрифт не CFF */
    u8* CffData;
    i64 CffSize;
    u8* Charstrings;
    i64 CharstringsSize;
    u8* Gsubrs;
    i64 GsubrsSize;
    u8* Subrs;
    i64 SubrsSize;
    u8* FontDicts;
    i64 FontDictsSize;
    u8* FdSelect;
    i64 FdSelectSize;
} ScTrueTypeFontInfo;

/*
  DOCS: Инициализирует шрифт по pData (содержимое .ttf/.ttc/.otf) со
  смещением fontStart (0 для обычного .ttf/.otf; для .ttc - смещение
  из sc_true_type_get_font_offset_for_index). Возвращает 0 при ошибке
  (нет обязательных таблиц/кодировки), 1 - успех.
*/
i32 sc_true_type_init(ScTrueTypeFontInfo* pInfo, u8* pData, i32 fontStart);

/*
  DOCS: Возвращает число шрифтов в коллекции (.ttc содержит несколько,
  обычный .ttf - один) или 0 при ошибке.
*/
i32 sc_true_type_get_number_of_fonts(u8* pCollection);

/*
  DOCS: Смещение index-ного шрифта в .ttc (0 для одиночного шрифта),
  -1 если index вне диапазона.
*/
i32 sc_true_type_get_font_offset_for_index(u8* pCollection, i32 index);

/*
  DOCS: Индекс глифа по unicode codepoint, 0 (notdef) если не найден.
*/
i32 sc_true_type_find_glyph_index(ScTrueTypeFontInfo* pInfo, i32 codepoint);

/*
  DOCS: Контур глифа в несмасштабированных координатах. Возвращает
  число вершин, *ppVertices - массив (sc_memory_allocate /
  sc_memory_free), NULL/0 для пустого глифа.
*/
i32 sc_true_type_get_glyph_shape(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, ScTrueTypeVertex** ppVertices);

/*
  DOCS: Освобождает контур глифа (sc_memory_free).
*/
void sc_true_type_free_shape(ScTrueTypeVertex* pVertices);

/*
  DOCS: 1 если глиф ничего не рисует (пробел, отсутствует).
*/
i32 sc_true_type_is_glyph_empty(ScTrueTypeFontInfo* pInfo, i32 glyphIndex);

/*
  DOCS: Bounding box глифа в несмасштабированных координатах.
  Возвращает 0 если глиф пуст (координаты обнулены), иначе 1.
*/
i32 sc_true_type_get_glyph_box(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, i32* pX0, i32* pY0, i32* pX1, i32* pY1);

/*
  DOCS: Горизонтальные метрики глифа (hmtx): advanceWidth - смещение
  до следующего глифа, leftSideBearing - до левой кромки глифа.
*/
void sc_true_type_get_glyph_h_metrics(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, i32* pAdvanceWidth, i32* pLeftSideBearing);

/*
  DOCS: Вертикальные метрики шрифта (hhea): ascent, descent, lineGap.
*/
void sc_true_type_get_font_v_metrics(ScTrueTypeFontInfo* pInfo, i32* pAscent, i32* pDescent, i32* pLineGap);

/*
  DOCS: Bounding box шрифта (head): xMin/yMin/xMax/yMax.
*/
void sc_true_type_get_font_bounding_box(ScTrueTypeFontInfo* pInfo, i32* pX0, i32* pY0, i32* pX1, i32* pY1);

/*
  DOCS: Масштаб для целевой высоты строки в пикселях (pixelHeight -
  расстояние ascent..descent в пикселях).
*/
f32 sc_true_type_scale_for_pixel_height(ScTrueTypeFontInfo* pInfo, f32 pixelHeight);

/*
  DOCS: Целочисленный bounding box растеризованного глифа: пиксели
  [ix0..ix1) x [iy0..iy1), y вниз. Возвращает 0 если глиф пуст
  (координаты обнулены), иначе 1. shift - субпиксельный сдвиг.
*/
i32 sc_true_type_get_glyph_bitmap_box_subpixel(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, f32 scaleX, f32 scaleY, f32 shiftX, f32 shiftY, i32* pIx0, i32* pIy0, i32* pIx1, i32* pIy1);

/*
  DOCS: То же без субпиксельного сдвига.
*/
i32 sc_true_type_get_glyph_bitmap_box(ScTrueTypeFontInfo* pInfo, i32 glyphIndex, f32 scaleX, f32 scaleY, i32* pIx0, i32* pIy0, i32* pIx1, i32* pIy1);

/*
  DOCS: Растеризует глиф в буфер pOutput (8-бит на пиксель, ширина
  outWidth, высота outHeight, строка outStride байт). Размер буфера
  должен соответствовать sc_true_type_get_glyph_bitmap_box. y вниз,
  фон 0.
*/
void sc_true_type_make_glyph_bitmap_subpixel(ScTrueTypeFontInfo* pInfo, u8* pOutput, i32 outWidth, i32 outHeight, i32 outStride, f32 scaleX, f32 scaleY, f32 shiftX, f32 shiftY, i32 glyphIndex);

/*
  DOCS: То же без субпиксельного сдвига.
*/
void sc_true_type_make_glyph_bitmap(ScTrueTypeFontInfo* pInfo, u8* pOutput, i32 outWidth, i32 outHeight, i32 outStride, f32 scaleX, f32 scaleY, i32 glyphIndex);

/*
  DOCS: Растеризует глиф в новую битмапу (sc_memory_allocate,
  sc_memory_free). Возвращает 0 при ошибке/пустом глифе, иначе 1
  (размер в pWidth/pHeight, смещение при отрисовке в pXoff/pYoff).
*/
i32 sc_true_type_get_glyph_bitmap(ScTrueTypeFontInfo* pInfo, f32 scaleX, f32 scaleY, i32 glyphIndex, i32* pWidth, i32* pHeight, i32* pXoff, i32* pYoff, ScTrueTypeBitmap* pBitmapOut);

/*
  DOCS: Освобождает битмапу глифа (sc_memory_free).
*/
void sc_true_type_free_bitmap(ScTrueTypeBitmap* pBitmap);

#endif // SC_TRUE_TYPE_H
