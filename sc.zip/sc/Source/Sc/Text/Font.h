#ifndef SC_FONT_H
#define SC_FONT_H

#include "Sc/Types.h"

typedef struct
{
    const char* pPath;
    void* pData;
    i32 FontSize;
    i32 RangeMin;
    i32 RangeMax;
} ScFontConfig;

typedef struct
{
    // DOCS: Unicode codepoint
    i32 Codepoint;
    u16 X0, Y0, X1, Y1;
    // f32 Fx0, Fy0, Fx1, Fy1;

    // leftSideBearing - is the offset from the current horizontal position to the left edge of the character.
    // advanceWidth - is the offset from the current horizontal position to the next horizontal position.
    // these are expressed in unscaled coordinates
    f32 Xoff, Yoff, Xadvance;
} ScFontChar;

typedef struct
{
    i64 Key;
    ScFontChar Value;
} ScFontCharTable;

typedef struct
{
    char* pName;                 // DOCS: Font name
    ScFontCharTable* hCharTable; // DOCS: Characters table
    i32 RangeMin;                // DOCS: Min unicode
    i32 RangeMax;                // DOCS: Max unicode
    void* pBitmap;               // DOCS: Bitmap to put inside image
    v2 Size;                     // DOCS: Bitmap size
    i32 FontSize;                // DOCS: Font size in pixel 32px
    i32 MaxHeight;               // DOCS: Max font character height
    i32 MaxYOffset;              // NOTE: not sure we need this
} ScFont;

ScFont sc_font_new(ScFontConfig cfg);
void sc_font_destroy(ScFont safFont);

v2 sc_font_get_space_metrics(ScFont safFont);
v2 sc_font_get_metrics(ScFont safFont, char* pText);

typedef struct
{
    f32 WrapWidth;
    char* pFullText;
    ScFont* pFont;
} ScFontWrapperConfig;

typedef enum
{
    ScFontWrapState_Empty = 0,
    ScFontWrapState_Newline,
    ScFontWrapState_Wrapped,
} ScFontWrapState;

typedef struct
{
    // ### Static block ###
    ScFont* pFont;
    // DOCS: Указатель на всю строку.
    char* pFullText;
    f32 WrapWidth;

    // ### Dynamic block ###
    char* pIterText;
    char* pPrevIterText;
    ScStringView View;
} ScFontWrapper;

ScFontWrapper sc_font_wrapper_new(ScFontWrapperConfig cfg);

// DOCS: ScFontWrapState_Wrapped если строка обернута по ширине,
// ScFontWrapState_Newline если встречен \n,
// ScFontWrapState_Empty если достигнут конец текста.
// pWrapper->View содержит текущую обернутую строку во всех случаях кроме Empty.
ScFontWrapState sc_font_wrap_text(ScFontWrapper* pWrapper);

#endif // SC_FONT_H
