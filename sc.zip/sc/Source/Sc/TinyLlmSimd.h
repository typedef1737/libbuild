#ifndef SC_TINY_LLM_SIMD_H
#define SC_TINY_LLM_SIMD_H

#include "Types.h"

/*
  CPU-бэкенд для TinyLlm: скалярный эталон и AVX2+FMA ядра с выбором
  во время выполнения.

  Почему runtime dispatch, а не -mavx2 на весь проект: один и тот же
  бинарник должен запускаться и на старых CPU без AVX2. Ядра AVX2
  помечены __attribute__((target("avx2,fma"))), поэтому компилятор
  генерирует их отдельно, а обычный код остаётся baseline x86-64.
*/

typedef enum
{
    ScTinyLlmCpu_Scalar = 0,
    ScTinyLlmCpu_Avx2 = 1,
} ScTinyLlmCpuBackend;

// DOCS: Инициализация/переинициализация выбора бэкенда. Вызывается лениво
// из публичного API TinyLlm; повторный вызов безопасен.
void sc_tiny_llm_simd_init(void);

// DOCS: Текущий выбранный бэкенд и его человекочитаемое имя.
ScTinyLlmCpuBackend sc_tiny_llm_simd_backend(void);
const char* sc_tiny_llm_simd_backend_name(void);

// DOCS: Поддержка CPU (не выбор бэкенда): AVX2 и FMA отдельно.
i32 sc_tiny_llm_simd_has_avx2(void);
i32 sc_tiny_llm_simd_has_fma(void);

// DOCS: Принудительно выбрать бэкенд. Возвращает 1 при успехе:
// Scalar доступен всегда, Avx2 - только если CPU его поддерживает.
i32 sc_tiny_llm_simd_force_backend(ScTinyLlmCpuBackend backend);

// DOCS: Сравнить скалярные и AVX2 ядра на детерминированных данных.
// Возвращает 1, если все проверки прошли (или AVX2 недоступен: тогда
// проверять нечего, но это не ошибка). tolerance - относительный допуск.
i32 sc_tiny_llm_simd_self_test(f32 tolerance);

/*
  Ядра. Скалярные и AVX2 реализации имеют одинаковые сигнатуры;
  вызывающий код не знает, какая выбрана.
*/

void sc_tiny_llm_simd_ln_forward(const f32* pX, f32* pY, f32* pXhat, f32* pInvStd,
    const f32* pGamma, const f32* pBeta, i32 T, i32 D);

void sc_tiny_llm_simd_ln_backward_add(const f32* pDy, const f32* pXhat, const f32* pInvStd,
    const f32* pGamma, f32* pGammaGrad, f32* pBetaGrad, f32* pDx, i32 T, i32 D);

void sc_tiny_llm_simd_linear_forward(const f32* pX, const f32* pW, const f32* pB, f32* pY,
    i32 T, i32 K, i32 N);

// DOCS: pDw/pDb - уже разыменованные pGrad; pDb может быть NULL.
void sc_tiny_llm_simd_linear_backward_weight(const f32* pX, const f32* pDy,
    f32* pDw, f32* pDb, i32 T, i32 K, i32 N);

void sc_tiny_llm_simd_linear_backward_input(const f32* pDy, const f32* pW, f32* pDx,
    i32 T, i32 K, i32 N);

// DOCS: Скалярное произведение и y += alpha * x (attention, тесты).
f32 sc_tiny_llm_simd_dot(const f32* pA, const f32* pB, i32 N);
void sc_tiny_llm_simd_axpy(f32* pY, const f32* pX, f32 alpha, i32 N);

#endif // SC_TINY_LLM_SIMD_H
