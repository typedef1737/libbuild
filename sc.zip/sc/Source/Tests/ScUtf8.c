#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_utf8_unicode_size_test()
{
    u32 aUnicode[] = { 0x24 /* $, 1 byte */ };
    sc_test_i32_equal(sc_utf8_unicode_size(aUnicode, 1), 1);

    u32 aUnicode2[] = { 0xA2 /* ¢, 2 bytes */ };
    sc_test_i32_equal(sc_utf8_unicode_size(aUnicode2, 1), 2);

    u32 aUnicode3[] = { 0x20AC /* €, 3 bytes */ };
    sc_test_i32_equal(sc_utf8_unicode_size(aUnicode3, 1), 3);

    u32 aUnicode4[] = { 0x10348 /* 𐍈, 4 bytes */ };
    sc_test_i32_equal(sc_utf8_unicode_size(aUnicode4, 1), 4);
}

void
sc_utf8_unicode_size__ascii_string_test()
{
    u32 aUnicode[] = { 'H', 'e', 'l', 'l', 'o' };
    u64 size = sc_utf8_unicode_size(aUnicode, 5);
    sc_test_condition(size == 5);
}

void
sc_utf8_unicode_size__mixed_string_test()
{
    u32 aUnicode[] = { 'H', 0xA2 /* ¢ */, 0x20AC /* € */, 0x10348 /* 𐍈 */ };
    u64 size = sc_utf8_unicode_size(aUnicode, 4);
    sc_test_condition(size == 1 + 2 + 3 + 4); // 10 bytes
}

void
sc_utf8_length_test()
{
    i64 length = sc_utf8_length("Hello");
    sc_test_condition(length == 5);

    length = sc_utf8_length("");
    sc_test_condition(length == 0);
}

void
sc_utf8_length__russian_test()
{
    char* pRussian = "Привет мир!";
    // П=2, р=2, и=2, в=2, е=2, т=2, ' '=1, м=2, и=2, р=2, !=1
    // Total unicode chars: 11
    i64 length = sc_utf8_length(pRussian);
    sc_test_condition(length == 11);
}

void
sc_utf8_length__multi_byte_test()
{
    char buf[32] = {};

    // 2-byte: ¢ (U+00A2)
    i32 n = sc_utf8_encode(buf, 0xA2);
    sc_test_condition(n == 2);

    // 3-byte: € (U+20AC)
    n = sc_utf8_encode(buf + n, 0x20AC);
    sc_test_condition(n == 3);

    // 4-byte: 𐍈 (U+10348)
    n = sc_utf8_encode(buf + 5, 0x10348);
    sc_test_condition(n == 4);

    i64 length = sc_utf8_length(buf);
    sc_test_condition(length == 3);
}

void
sc_utf8_size_test()
{
    u64 size = sc_utf8_size("Hello");
    sc_test_condition(size == 5);

    size = sc_utf8_size("");
    sc_test_condition(size == 0);
}

void
sc_utf8_size_russian_test()
{
    // DOCS: (6 + 3) * 2 (ru) + 2 * 1 (ascii)
    char* pRussian = "Привет мир!";
    u64 size = sc_utf8_size(pRussian);
    sc_test_i32_equal(size, 20); // 10 russian chars x 2 bytes + 1 space + 1 '!'
}

void
sc_utf8_size__multi_byte_test()
{
    char buf[32] = {};

    // $ (1 byte) + ¢ (2 bytes) + € (3 bytes) + 𐍈 (4 bytes)
    i32 n = sc_utf8_encode(buf, 0x24);
    n += sc_utf8_encode(buf + n, 0xA2);
    n += sc_utf8_encode(buf + n, 0x20AC);
    n += sc_utf8_encode(buf + n, 0x10348);

    u64 size = sc_utf8_size(buf);
    sc_test_condition(size == 1 + 2 + 3 + 4); // 10 bytes
}

void
sc_utf8_encode_test()
{
    char buf[32] = {};

    // 1 byte: $ (U+0024)
    i32 n = sc_utf8_encode(buf, 0x24);
    sc_test_condition(n == 1);
    sc_test_condition((u8)buf[0] == 0x24);
    sc_test_condition(buf[1] == 0);

    // 2 byte: ¢ (U+00A2)
    char buf2[32] = {};
    n = sc_utf8_encode(buf2, 0xA2);
    sc_test_condition(n == 2);
    sc_test_condition((u8)buf2[0] == 0xC2);
    sc_test_condition((u8)buf2[1] == 0xA2);

    // 3 byte: € (U+20AC)
    char buf3[32] = {};
    n = sc_utf8_encode(buf3, 0x20AC);
    sc_test_condition(n == 3);
    sc_test_condition((u8)buf3[0] == 0xE2);
    sc_test_condition((u8)buf3[1] == 0x82);
    sc_test_condition((u8)buf3[2] == 0xAC);

    // 4 byte: 𐍈 (U+10348)
    char buf4[32] = {};
    n = sc_utf8_encode(buf4, 0x10348);
    sc_test_condition(n == 4);
    sc_test_condition((u8)buf4[0] == 0xF0);
    sc_test_condition((u8)buf4[1] == 0x90);
    sc_test_condition((u8)buf4[2] == 0x8D);
    sc_test_condition((u8)buf4[3] == 0x88);
}

void
sc_utf8_decode_test()
{
    // 1 byte: $ (0x24)
    i32 bytesCount = 0;
    u32 codepoint = sc_utf8_decode("$", &bytesCount);
    sc_test_condition(codepoint == 0x24);
    sc_test_condition(bytesCount == 1);

    // 2 byte: ¢ -> 0xC2 0xA2
    char buf2[32] = {};
    sc_utf8_encode(buf2, 0xA2);
    bytesCount = 0;
    codepoint = sc_utf8_decode(buf2, &bytesCount);
    sc_test_condition(codepoint == 0xA2);
    sc_test_condition(bytesCount == 2);

    // 3 byte: €
    char buf3[32] = {};
    sc_utf8_encode(buf3, 0x20AC);
    bytesCount = 0;
    codepoint = sc_utf8_decode(buf3, &bytesCount);
    sc_test_condition(codepoint == 0x20AC);
    sc_test_condition(bytesCount == 3);

    // 4 byte: 𐍈
    char buf4[32] = {};
    sc_utf8_encode(buf4, 0x10348);
    bytesCount = 0;
    codepoint = sc_utf8_decode(buf4, &bytesCount);
    sc_test_condition(codepoint == 0x10348);
    sc_test_condition(bytesCount == 4);
}

void
sc_utf8_decode__null_bytes_test()
{
    i32 bytesCount = 0;
    u32 codepoint = sc_utf8_decode("$", NULL);
    sc_test_condition(codepoint == 0x24);
}

void
sc_utf8_get_unicode_text_test()
{
    char* pUtf8 = "Hello";
    i64 textLength = 0;
    i32 aUnicodeText[32] = {};

    sc_utf8_get_unicode_text(aUnicodeText, pUtf8, &textLength);
    sc_test_condition(textLength == 5);
    sc_test_condition(aUnicodeText[0] == 'H');
    sc_test_condition(aUnicodeText[1] == 'e');
    sc_test_condition(aUnicodeText[2] == 'l');
    sc_test_condition(aUnicodeText[3] == 'l');
    sc_test_condition(aUnicodeText[4] == 'o');
}

void
sc_utf8_get_unicode_text__russian_test()
{
    char* pUtf8 = "Привет";
    i64 textLength = 0;
    i32 aUnicodeText[32] = {};

    sc_utf8_get_unicode_text(aUnicodeText, pUtf8, &textLength);
    sc_test_condition(textLength == 6);

    // Check first char 'П' (U+041F)
    sc_test_condition(aUnicodeText[0] == 0x041F);
    // Check last char 'т' (U+0442)
    sc_test_condition(aUnicodeText[5] == 0x0442);
}

void
sc_utf8_get_unicode_text__multi_byte_test()
{
    char buf[32] = {};
    i32 n = sc_utf8_encode(buf, 0x24);    // $
    n += sc_utf8_encode(buf + n, 0xA2);   // ¢
    n += sc_utf8_encode(buf + n, 0x20AC); // €

    i64 textLength = 0;
    i32 aUnicodeText[32] = {};

    sc_utf8_get_unicode_text(aUnicodeText, buf, &textLength);
    sc_test_condition(textLength == 3);
    sc_test_condition((u32)aUnicodeText[0] == 0x24);
    sc_test_condition((u32)aUnicodeText[1] == 0xA2);
    sc_test_condition((u32)aUnicodeText[2] == 0x20AC);
}

extern void
sc_auto_utf8()
{
    sc_test_file();

    sc_test_func(sc_utf8_unicode_size_test());
    sc_test_func(sc_utf8_unicode_size__ascii_string_test());
    sc_test_func(sc_utf8_unicode_size__mixed_string_test());
    sc_test_func(sc_utf8_length_test());
    sc_test_func(sc_utf8_length__russian_test());
    sc_test_func(sc_utf8_length__multi_byte_test());
    sc_test_func(sc_utf8_size_test());
    sc_test_func(sc_utf8_size_russian_test());
    sc_test_func(sc_utf8_size__multi_byte_test());
    sc_test_func(sc_utf8_encode_test());
    sc_test_func(sc_utf8_decode_test());
    sc_test_func(sc_utf8_decode__null_bytes_test());
    sc_test_func(sc_utf8_get_unicode_text_test());
    sc_test_func(sc_utf8_get_unicode_text__russian_test());
    sc_test_func(sc_utf8_get_unicode_text__multi_byte_test());
}
