#include "Sc/Sc.h"
#include <Sc/Test.h>

void
sc_grid_basic()
{
    // Создаем сетку 3x4x5 для int
    ScGrid* pGrid = sc_grid_reserve(sizeof(i32), 3, 4, 5);

    // Проверяем размеры
    sc_test_condition(pGrid->X == 3);
    sc_test_condition(pGrid->Y == 4);
    sc_test_condition(pGrid->Z == 5);
    sc_test_condition(pGrid->ItemSize == sizeof(i32));

    // Записываем значения
    i32 value = 42;
    sc_grid_set(pGrid, 0, 0, 0, &value);

    value = 100;
    sc_grid_set(pGrid, 2, 3, 4, &value);

    value = 255;
    sc_grid_set(pGrid, 1, 2, 3, &value);

    // Читаем и проверяем
    i32* pValue = (i32*)sc_grid_get(pGrid, 0, 0, 0);
    sc_test_condition(*pValue == 42);

    pValue = (i32*)sc_grid_get(pGrid, 2, 3, 4);
    sc_test_condition(*pValue == 100);

    pValue = (int*)sc_grid_get(pGrid, 1, 2, 3);
    sc_test_condition(*pValue == 255);

    // Проверяем что память линейная (опционально)
    i32* pData = (i32*)pGrid->pData;
    sc_test_condition(pData[0] == 42);                      // [0,0,0]
    sc_test_condition(pData[3 * 4 * 5 - 1] == 100);         // [2,3,4]
    sc_test_condition(pData[1 * 4 * 5 + 2 * 5 + 3] == 255); // [1,2,3]

    sc_grid_free(pGrid);
}

void
sc_grid_fill_test()
{
    // Создаем сетку 2x3x4
    ScGrid* pGrid = sc_grid_reserve(sizeof(i32), 2, 3, 4);

    // Заполняем значениями-счетчиками
    int counter = 0;
    for (int x = 0; x < pGrid->X; x++)
    {
        for (int y = 0; y < pGrid->Y; y++)
        {
            for (int z = 0; z < pGrid->Z; z++)
            {
                sc_grid_set(pGrid, x, y, z, &counter);
                counter++;
            }
        }
    }

    // Проверяем что всего записей X*Y*Z
    sc_test_condition(counter == 2 * 3 * 4);

    // Проверяем каждое значение
    counter = 0;
    for (int x = 0; x < pGrid->X; x++)
    {
        for (int y = 0; y < pGrid->Y; y++)
        {
            for (int z = 0; z < pGrid->Z; z++)
            {
                int* pValue = (int*)sc_grid_get(pGrid, x, y, z);
                sc_test_condition(*pValue == counter);
                counter++;
            }
        }
    }

    // Проверка через линейный доступ
    int* pData = (int*)pGrid->pData;
    for (int i = 0; i < 2 * 3 * 4; i++)
    {
        sc_test_condition(pData[i] == i);
    }

    sc_grid_free(pGrid);
}

extern void
sc_auto_grid()
{
    sc_test_file();
    sc_test_func(sc_grid_basic());
    sc_test_func(sc_grid_fill_test());
}
