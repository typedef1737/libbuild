#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <stdio.h>
#include <string.h>

/*
  Проверяет production-пайплайн микро-LLM:
  - BPE с расширенными спецтокенами;
  - dataset с условной разметкой;
  - численную проверку градиента;
  - обучение с маскированием prompt;
  - генерацию и чекпоинт (weights + встроенный BPE).
*/

static const char* cTinyLlmCorpus =
    "<BOS><PERSONA>мужчина 30<CHAR>добрый<EMO>спокойно<SIT>дорога<SEP>Здравствуй, путник!<EOS>"
    "<BOS><PERSONA>женщина 25<CHAR>весёлая<EMO>радостно<SIT>ярмарка<SEP>Покупайте яблоки!<EOS>"
    "<BOS><PERSONA>стражник 40<CHAR>суровый<EMO>строго<SIT>ворота<SEP>Проходите мимо.<EOS>"
    "<BOS><PERSONA>знахарка 35<CHAR>тихая<EMO>устало<SIT>дом<SEP>Дайте воды.<EOS>";

static const char* cTinyLlmPrompt =
    "<BOS><PERSONA>мужчина 30<CHAR>добрый<EMO>спокойно<SIT>дорога<SEP>";

void
sc_tiny_llm_pipeline_test()
{
    // DOCS: отдельно проверяем слияние (A,A): в этом случае соседняя пара
    // может совпасть с выбранной и её нельзя освобождать во время обхода.
    char repeatedCorpus[257] = {};
    for (i32 i = 0; i < 256; ++i)
        repeatedCorpus[i] = i < 128 ? 'a' : 'b';

    ScAiBpe repeatedBpe = sc_ai_bpe_new_fast((ScAiBpeConfig) {
        .pText = repeatedCorpus,
        .TextLength = 256,
        .MergesCount = 16,
    });
    sc_test_condition(sc_list_count(repeatedBpe.aMerges) > 0);

    ScAiTokenizeConfig repeatedTokenizeConfig = {
        .pText = repeatedCorpus,
        .TextLength = 256,
        .Bpe = repeatedBpe,
    };
    i32* aRepeatedTokens = sc_ai_bpe_tokenize(repeatedTokenizeConfig);
    char* pRepeatedDecoded = sc_ai_bpe_decode(repeatedBpe, aRepeatedTokens);
    sc_test_string_equals(pRepeatedDecoded, repeatedCorpus);
    sc_string_destroy(pRepeatedDecoded);
    sc_list_free(aRepeatedTokens);
    sc_ai_bpe_destroy(&repeatedBpe);

    ScAiBpeConfig bpeConfig = {
        .pText = (char*)cTinyLlmCorpus,
        .TextLength = sc_string_get_length((char*)cTinyLlmCorpus),
        .MergesCount = 16,
    };

    // DOCS: reference и fast BPE должны одинаково проходить round-trip.
    ScAiBpe referenceBpe = sc_ai_bpe_new(bpeConfig);
    ScAiBpe bpe = sc_ai_bpe_new_fast(bpeConfig);

    sc_test_condition(sc_list_count(referenceBpe.aMerges) > 0);
    sc_test_condition(sc_list_count(bpe.aMerges) > 0);
    sc_test_condition(sc_list_count(bpe.aVocab) >= (i64)ScAiSpecialToken_Sit + 1);

    ScAiTokenizeConfig tokenizeConfig = {
        .pText = (char*)cTinyLlmCorpus,
        .TextLength = sc_string_get_length((char*)cTinyLlmCorpus),
    };

    tokenizeConfig.Bpe = referenceBpe;
    i32* aReferenceTokens = sc_ai_bpe_tokenize(tokenizeConfig);
    char* pReferenceDecoded = sc_ai_bpe_decode(referenceBpe, aReferenceTokens);
    sc_test_string_equals(pReferenceDecoded, cTinyLlmCorpus);
    sc_string_destroy(pReferenceDecoded);
    sc_list_free(aReferenceTokens);

    tokenizeConfig.Bpe = bpe;
    i32* aFastTokens = sc_ai_bpe_tokenize(tokenizeConfig);
    char* pFastDecoded = sc_ai_bpe_decode(bpe, aFastTokens);
    sc_test_string_equals(pFastDecoded, cTinyLlmCorpus);
    sc_string_destroy(pFastDecoded);
    sc_list_free(aFastTokens);

    sc_ai_bpe_destroy(&referenceBpe);

    const char* bpePath = "tiny_llm_test.bpe";
    sc_ai_bpe_save_to_disk((ScAiBpeSaveToDiskConfig) {
        .Bpe = bpe,
        .pFilePath = (char*)bpePath,
        .TotalTextLength = sc_string_get_length((char*)cTinyLlmCorpus),
        .TotalTextLengthCompressed = (i64)sc_list_count(bpe.aTokens),
    });

    ScAiBpe loadedV1 = sc_ai_bpe_load_from_disk((char*)bpePath);
    sc_test_condition(sc_list_count(loadedV1.aVocab) == sc_list_count(bpe.aVocab));
    sc_test_condition(sc_list_count(loadedV1.aMerges) == sc_list_count(bpe.aMerges));
    sc_ai_bpe_destroy(&loadedV1);
    remove(bpePath);

    ScTinyLlmDataset dataset = sc_tiny_llm_dataset_new();

    // Каждый пример заканчивается <EOS>; режем корпус по этому маркеру.
    char* pCursor = (char*)cTinyLlmCorpus;
    char* pEnd = pCursor + sc_string_get_length((char*)cTinyLlmCorpus);
    while (pCursor < pEnd)
    {
        char* pEos = strstr(pCursor, "<EOS>");
        if (!pEos)
            break;

        i64 length = (i64)(pEos + 5 - pCursor);
        char* pPart = sc_string_new_ext_ext_r(pCursor, length, length);
        sc_tiny_llm_dataset_add(&dataset, bpe, pPart);
        sc_string_destroy(pPart);
        pCursor = pEos + 5;
    }

    sc_test_condition(dataset.Count >= 2);

    ScTinyLlmModelConfig modelConfig = sc_tiny_llm_model_config_default((i32)sc_list_count(bpe.aVocab));
    modelConfig.NumLayers = 1;
    modelConfig.DModel = 32;
    modelConfig.NumHeads = 2;
    modelConfig.DFf = 64;
    modelConfig.ContextLength = 64;
    modelConfig.Seed = 1234;

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    sc_test_condition(pModel != NULL);
    if (!pModel)
    {
        sc_tiny_llm_dataset_destroy(&dataset);
        sc_ai_bpe_destroy(&bpe);
        return;
    }

    sc_test_condition(sc_tiny_llm_grad_check(pModel, &dataset, 5, 1e-3f, 5e-2f));

    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = 400;
    trainConfig.BatchSize = 2;
    trainConfig.LearningRate = 0.01f;
    trainConfig.WarmupSteps = 0;
    trainConfig.LogEvery = 0;
    trainConfig.GradClip = 1.0f;
    trainConfig.EvalEvery = 100;
    trainConfig.EvalBatches = 2;
    trainConfig.Patience = 1;
    trainConfig.RestoreBest = 1;
    trainConfig.Seed = 777;

    f32 before = sc_tiny_llm_eval(pModel, &dataset, 8, ScTinyLlmLossMask_Prompt, 1);
    sc_test_condition(sc_tiny_llm_train(pModel, bpe, &dataset, &dataset, &trainConfig) == 1);
    f32 after = sc_tiny_llm_eval(pModel, &dataset, 8, ScTinyLlmLossMask_Prompt, 1);

    sc_test_string_value("tiny-llm train");
    sc_test_condition(after <= before + 0.05f);

    ScTinyLlmGenerateConfig genConfig = sc_tiny_llm_generate_config_default();
    genConfig.MaxTokens = 24;
    genConfig.Temperature = 0.0f;
    genConfig.TopK = 1;

    char* pAnswer = sc_tiny_llm_generate(pModel, bpe, cTinyLlmPrompt, &genConfig);
    sc_test_condition(pAnswer != NULL);
    sc_test_condition(sc_string_get_length(pAnswer) > 0);
    sc_test_string_value(pAnswer);
    sc_string_destroy(pAnswer);

    const char* checkpointPath = "tiny_llm_test.ckpt";
    sc_test_condition(sc_tiny_llm_save_checkpoint(pModel, bpe, checkpointPath) == 1);

    ScAiBpe loadedBpe = {};
    ScTinyLlmModel* pLoaded = sc_tiny_llm_load_checkpoint(checkpointPath, &loadedBpe);
    sc_test_condition(pLoaded != NULL);
    sc_test_condition(sc_list_count(loadedBpe.aVocab) == sc_list_count(bpe.aVocab));

    if (pLoaded)
    {
        char* pLoadedAnswer = sc_tiny_llm_generate(pLoaded, loadedBpe, cTinyLlmPrompt, &genConfig);
        sc_test_condition(pLoadedAnswer != NULL);
        sc_test_condition(sc_string_get_length(pLoadedAnswer) > 0);
        sc_test_string_value(pLoadedAnswer);
        sc_string_destroy(pLoadedAnswer);
        sc_tiny_llm_destroy(pLoaded);
    }

    sc_ai_bpe_destroy(&loadedBpe);
    remove(checkpointPath);

    sc_tiny_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&dataset);
    sc_ai_bpe_destroy(&bpe);
}

extern void
sc_auto_tiny_llm()
{
    sc_test_file();
    sc_test_func(sc_tiny_llm_pipeline_test());
}
