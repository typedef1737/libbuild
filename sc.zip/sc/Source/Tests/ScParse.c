#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_parse_int_while_int_test()
{
    char input[] = "123abc";
    ScParsedInt parsed = sc_parse_int_while_int(input);

    sc_test_i32_equal((i32)parsed.IntValue, 123);
    sc_test_condition(parsed.pInput == input);
    sc_test_condition(parsed.pOutput == input + 3);
    sc_test_condition(*parsed.pOutput == 'a');

    char input0[] = "0";
    parsed = sc_parse_int_while_int(input0);
    sc_test_i32_equal((i32)parsed.IntValue, 0);
    sc_test_condition(parsed.pOutput == input0 + 1);

    char input999[] = "999";
    parsed = sc_parse_int_while_int(input999);
    sc_test_i32_equal((i32)parsed.IntValue, 999);
    sc_test_condition(parsed.pOutput == input999 + 3);

    char noDigits[] = "abc";
    parsed = sc_parse_int_while_int(noDigits);
    sc_test_i32_equal((i32)parsed.IntValue, 0);
    sc_test_condition(parsed.pOutput == NULL);
    sc_test_condition(parsed.pInput == noDigits);
}

void
sc_parse_int_test()
{
    char input[] = "12345";
    sc_test_i32_equal((i32)sc_parse_int(input, 5), 12345);

    char input7[] = "7";
    sc_test_i32_equal((i32)sc_parse_int(input7, 1), 7);

    char input100[] = "100";
    sc_test_i32_equal((i32)sc_parse_int(input100, 3), 100);
}

void
sc_parse_float_test()
{
    char input[] = "3.14";
    sc_test_f32_equal((f32)sc_parse_float(input, 4), 3.14f);

    char input05[] = "0.5";
    sc_test_f32_equal((f32)sc_parse_float(input05, 3), 0.5f);

    char input123[] = "123";
    sc_test_f32_equal((f32)sc_parse_float(input123, 3), 123.0f);

    char inputNeg[] = "-2.5";
    sc_test_f32_equal((f32)sc_parse_float(inputNeg, 4), -2.5f);
}

void
sc_parse_skip_space_test()
{
    char input[] = "   hi";
    char* pResult = sc_parse_skip_space(input);
    sc_test_condition(pResult == input + 3);
    sc_test_condition(*pResult == 'h');

    char inputTabs[] = "\t\n  x";
    pResult = sc_parse_skip_space(inputTabs);
    sc_test_condition(*pResult == 'x');

    char noSpace[] = "start";
    pResult = sc_parse_skip_space(noSpace);
    sc_test_condition(pResult == noSpace);

    char empty[] = "";
    pResult = sc_parse_skip_space(empty);
    sc_test_condition(pResult == empty);

    sc_test_condition(sc_parse_skip_space(NULL) == NULL);
}

void
sc_parse_skip_while_test()
{
    char input[] = "aabbXcc";
    char aSymbols[] = { 'a', 'b' };
    char* pResult = sc_parse_skip_while(input, aSymbols, 2);
    sc_test_condition(pResult == input + 4);
    sc_test_condition(*pResult == 'X');

    sc_test_condition(sc_parse_skip_while(input, aSymbols, 0) == input);
    sc_test_condition(sc_parse_skip_while(input, NULL, 2) == input);
    sc_test_condition(sc_parse_skip_while(NULL, aSymbols, 2) == NULL);

    char noMatch[] = "xyz";
    pResult = sc_parse_skip_while(noMatch, aSymbols, 2);
    sc_test_condition(pResult == noMatch);
}

void
sc_auto_parse()
{
    sc_test_file();

    sc_test_func(sc_parse_int_while_int_test());
    sc_test_func(sc_parse_int_test());
    sc_test_func(sc_parse_float_test());
    sc_test_func(sc_parse_skip_space_test());
    sc_test_func(sc_parse_skip_while_test());
}