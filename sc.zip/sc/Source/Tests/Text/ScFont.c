#include <Sc/Text/Font.h>
#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

static ScFont
load_test_font()
{
    ScFontConfig cfg = {
        .pPath = "/home/tdef/Big/programming/C/miracle/Resources/Fonts/MartianMono-sWdRg.ttf",
        .FontSize = 32,
        .RangeMin = 32,
        .RangeMax = 126,
    };
    return sc_font_new(cfg);
}

void
sc_font_wrap_single_word_test()
{
    ScFont font = load_test_font();
    char* pText = "hello";

    ScFontWrapper wrapper = sc_font_wrapper_new((ScFontWrapperConfig) {
        .WrapWidth = 500,
        .pFullText = pText,
        .pFont = &font,
    });

    ScFontWrapState state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_i32_equal(wrapper.View.Length, 5);
    sc_test_condition(wrapper.View.pData == pText);

    // DOCS: second call — no more text
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Empty);

    sc_font_destroy(font);
}

void
sc_font_wrap_word_boundary_test()
{
    ScFont font = load_test_font();
    char text[] = "hello world from bigger test";

    // DOCS: width just enough for "hello" but not "hello world"
    v2 helloMetrics = sc_font_get_metrics(font, "hello");
    f32 narrowWidth = helloMetrics.X + 10;

    ScFontWrapper wrapper = sc_font_wrapper_new((ScFontWrapperConfig) {
        .WrapWidth = narrowWidth,
        .pFullText = text,
        .pFont = &font,
    });

    // DOCS: line 1 — "hello"
    ScFontWrapState state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text);
    sc_test_i32_equal(wrapper.View.Length, 5);

    // DOCS: line 2 — "world"
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 6);
    sc_test_i32_equal(wrapper.View.Length, 5);

    // DOCS: line 3 — "from"
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 12);
    sc_test_i32_equal(wrapper.View.Length, 4);

    // DOCS: line 4 — "bigger"
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 17);
    sc_test_i32_equal(wrapper.View.Length, 6);

    // DOCS: line 5 — "test"
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 24);
    sc_test_i32_equal(wrapper.View.Length, 4);

    // DOCS: done
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Empty);

    sc_font_destroy(font);
}

void
sc_font_wrap_newline_test()
{
    ScFont font = load_test_font();
    char text[] = "hello\nworld";

    ScFontWrapper wrapper = sc_font_wrapper_new((ScFontWrapperConfig) {
        .WrapWidth = 500,
        .pFullText = text,
        .pFont = &font,
    });

    // DOCS: first line before \n
    ScFontWrapState state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Newline);
    sc_test_condition(wrapper.View.pData == text);
    sc_test_i32_equal(wrapper.View.Length, 5);

    // DOCS: second line after \n
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 6); // after \n
    sc_test_i32_equal(wrapper.View.Length, 5);

    // DOCS: done
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Empty);

    sc_font_destroy(font);
}

void
sc_font_wrap_hard_break_test()
{
    ScFont font = load_test_font();
    char text[] = "SuperLongWordWithoutSpaces";

    // DOCS: width smaller than a single character
    v2 spaceMetrics = sc_font_get_space_metrics(font);
    f32 tinyWidth = spaceMetrics.X * 0.5f;

    ScFontWrapper wrapper = sc_font_wrapper_new((ScFontWrapperConfig) {
        .WrapWidth = tinyWidth,
        .pFullText = text,
        .pFont = &font,
    });

    // DOCS: even first char doesn't fit — but it's emitted anyway
    ScFontWrapState state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.Length > 0);
    sc_test_condition(wrapper.View.pData == text);

    sc_test_string_value("hard break emitted first char");
    sc_test_i32_value(wrapper.View.Length);

    sc_font_destroy(font);
}

void
sc_font_wrap_leading_whitespace_test()
{
    ScFont font = load_test_font();
    char text[] = "   hello";

    ScFontWrapper wrapper = sc_font_wrapper_new((ScFontWrapperConfig) {
        .WrapWidth = 500,
        .pFullText = text,
        .pFont = &font,
    });

    // DOCS: leading spaces are trimmed, "hello" remains
    ScFontWrapState state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 3); // after 3 spaces
    sc_test_i32_equal(wrapper.View.Length, 5);

    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Empty);

    sc_font_destroy(font);
}

void
sc_font_wrap_multiple_newlines_test()
{
    ScFont font = load_test_font();
    char text[] = "a\n\nb";

    ScFontWrapper wrapper = sc_font_wrapper_new((ScFontWrapperConfig) {
        .WrapWidth = 500,
        .pFullText = text,
        .pFont = &font,
    });

    // DOCS: "a"
    ScFontWrapState state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Newline);
    sc_test_condition(wrapper.View.pData == text);
    sc_test_i32_equal(wrapper.View.Length, 1);

    // DOCS: empty line between \n\n — should emit empty View
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Newline);
    sc_test_i32_equal(wrapper.View.Length, 0);

    // DOCS: "b"
    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Wrapped);
    sc_test_condition(wrapper.View.pData == text + 3); // after "\n\n"
    sc_test_i32_equal(wrapper.View.Length, 1);

    state = sc_font_wrap_text(&wrapper);
    sc_test_i32_equal(state, ScFontWrapState_Empty);

    sc_font_destroy(font);
}

extern void
sc_auto_font()
{
    sc_test_file();

    sc_test_func(sc_font_wrap_single_word_test());
    sc_test_func(sc_font_wrap_word_boundary_test());
    sc_test_func(sc_font_wrap_newline_test());
    sc_test_func(sc_font_wrap_hard_break_test());
    sc_test_func(sc_font_wrap_leading_whitespace_test());
    sc_test_func(sc_font_wrap_multiple_newlines_test());
}
