#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_builder_append_char_test()
{
    char* sb = NULL;
    sc_builder_append_char(sb, 'h');
    sc_builder_append_char(sb, 'e');
    sc_builder_append_char(sb, 'l');
    sc_builder_append_char(sb, 'l');
    sc_builder_append_char(sb, 'o');
    sc_builder_append_char(sb, '\0');

    sc_test_condition(sc_builder_count(sb) == 6);
    sc_test_condition(sc_builder_capacity(sb) == 31);

    i32 isAllCapedCharsIsZeroed = 1;
    for (i32 s = sc_builder_count(sb); s < 31; ++s)
    {
        if (sb[s] != 0)
            isAllCapedCharsIsZeroed = 0;
    }
    sc_test_condition(isAllCapedCharsIsZeroed);

    sc_test_string_value(sb);
    sc_test_string_equals(sb, "hello");
}

void
sc_builder_append_string_test()
{
    char* sb = NULL;

    sc_builder_append_string(sb, "Hello", 5);
    sc_builder_append_string(sb, " World", 6);
    sc_builder_append_string(sb, "\0", 1);

    sc_test_string_equals(sb, "Hello World");
    sc_test_string_value(sb);
}

void
sc_builder_append_format_test()
{
    char* sb = NULL;
    sc_builder_append_format(sb, "{\n\t\"api\": \"%s\",\n\t\"key\": %f\n}", "https://www.web.com/api", 3.14);
    sc_test_string_value(sb);
}

void
sc_builder_append_format_realloc_test()
{

}

extern void
sc_auto_builder()
{
    sc_test_file();
    sc_test_func(sc_builder_append_char_test());
    sc_test_func(sc_builder_append_string_test());
    sc_test_func(sc_builder_append_format_test());
}
