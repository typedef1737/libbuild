#include <Sc/Data/Hash.h>
#include <Sc/Sc.h>
#include <Sc/Test.h>

/*
 Векторы получены вызовом эталонных функций rapidhash V3:
 rapidhash, rapidhashMicro, rapidhashNano и их *_withSeed из
 rapidhash-rapidhash_v3/rapidhash.h (release-windows, clang).
 Буфер заполняется так же, как в генераторе:
 byte[i] = (u8)(i * 131 + 17).
*/

typedef struct
{
    u64 Length;
    u64 Hash;
    u64 Micro;
    u64 Nano;
} ScHashVector;

static void
sc_hash_fill_buffer(u8* pBuffer, u64 size)
{
    for (u64 i = 0; i < size; ++i)
        pBuffer[i] = to_u8(i * 131u + 17u);
}

static void
sc_hash_vectors_seed_zero_test()
{
    static const ScHashVector aVectors[] = {
        { 0, 0x0338dc4be2cecdaeULL, 0x0338dc4be2cecdaeULL, 0x0338dc4be2cecdaeULL },
        { 1, 0x46911692db77b8aaULL, 0x46911692db77b8aaULL, 0x46911692db77b8aaULL },
        { 2, 0x2fe388953a79680eULL, 0x2fe388953a79680eULL, 0x2fe388953a79680eULL },
        { 3, 0x4681631b0268bdaeULL, 0x4681631b0268bdaeULL, 0x4681631b0268bdaeULL },
        { 4, 0xffd257fe10b451ddULL, 0xffd257fe10b451ddULL, 0xffd257fe10b451ddULL },
        { 7, 0x9aea172b6dd14b40ULL, 0x9aea172b6dd14b40ULL, 0x9aea172b6dd14b40ULL },
        { 8, 0xcb63385f26fb064eULL, 0xcb63385f26fb064eULL, 0xcb63385f26fb064eULL },
        { 15, 0x04448b895e0f96afULL, 0x04448b895e0f96afULL, 0x04448b895e0f96afULL },
        { 16, 0xddd5b9d42bf20f35ULL, 0xddd5b9d42bf20f35ULL, 0xddd5b9d42bf20f35ULL },
        { 17, 0x4d3c0b9b9c4ed98eULL, 0x4d3c0b9b9c4ed98eULL, 0x4d3c0b9b9c4ed98eULL },
        { 31, 0xbab1ae1d477c6a63ULL, 0xbab1ae1d477c6a63ULL, 0xbab1ae1d477c6a63ULL },
        { 32, 0x7b1a19ca6d34cd0dULL, 0x7b1a19ca6d34cd0dULL, 0x7b1a19ca6d34cd0dULL },
        { 33, 0xfc208bc3eb0bb07eULL, 0xfc208bc3eb0bb07eULL, 0xfc208bc3eb0bb07eULL },
        { 47, 0x569020dacb7e99f3ULL, 0x569020dacb7e99f3ULL, 0x569020dacb7e99f3ULL },
        { 48, 0xf07d49050a3c34eeULL, 0xf07d49050a3c34eeULL, 0xf07d49050a3c34eeULL },
        { 49, 0x66f9fa0959d4c84cULL, 0x66f9fa0959d4c84cULL, 0xa4899997e3d92539ULL },
        { 63, 0x7fc8d3005ce18ab6ULL, 0x7fc8d3005ce18ab6ULL, 0xe6129a734dd267fbULL },
        { 64, 0x54509a0ff905068aULL, 0x54509a0ff905068aULL, 0xe876a73ae2e97b2fULL },
        { 80, 0x048e4a0936098b98ULL, 0x048e4a0936098b98ULL, 0xfac79f0dd7189225ULL },
        { 111, 0x3d9a4c27cbb7d0e1ULL, 0x5822108eaf2217e8ULL, 0x42f2f55ab2161990ULL },
        { 112, 0xf8c7e88e1335f998ULL, 0x45f3d567aa756037ULL, 0xb16e42fbc6dc2b8eULL },
        { 113, 0x10d240519c63662fULL, 0x669e57eb565d378fULL, 0xe834411c5e74bb99ULL },
        { 223, 0x52be554be9e76617ULL, 0x35c28465f9ce1c1cULL, 0xa01a0bbc5bd721ccULL },
        { 224, 0x4650a27367d49f49ULL, 0xc04715f2e5a87856ULL, 0x3b875b255b9e4afdULL },
        { 225, 0x2cf3e0bd3e404d75ULL, 0x4da874d863390da3ULL, 0xdb2521613ee9f2b4ULL },
        { 255, 0x909b87bd3caa7828ULL, 0x7b741a1e06ec7ec8ULL, 0xeee79bb44d7de018ULL },
        { 256, 0x530856ca654b4776ULL, 0xcf4e3da05d3f8f35ULL, 0xca42d30303216748ULL },
        { 511, 0x8fbbc5aece29117dULL, 0xf26a4c26b0678a82ULL, 0xa2bac4005bb8187fULL },
        { 512, 0xf1380d4f7cd338c0ULL, 0xebb7289f6900776bULL, 0x393ab879de4de903ULL },
        { 1024, 0x21cf5a8e9af78a6bULL, 0xaf5e79ca397d04d0ULL, 0xe2771548c168dbfeULL },
    };

    u8 aBuffer[1024] = {};
    sc_hash_fill_buffer(aBuffer, sizeof(aBuffer));

    const i32 c_count = to_i32(ScArrayCount(aVectors));
    for (i32 i = 0; i < c_count; ++i)
    {
        const ScHashVector* pVector = &aVectors[i];
        sc_test_condition(sc_hash(aBuffer, pVector->Length) == pVector->Hash);
        sc_test_condition(sc_hash_micro(aBuffer, pVector->Length) == pVector->Micro);
        sc_test_condition(sc_hash_nano(aBuffer, pVector->Length) == pVector->Nano);
    }
}

static void
sc_hash_vectors_seed_test()
{
    static const ScHashVector aVectors[] = {
        { 0, 0x565ef32cd8efb3ddULL, 0x565ef32cd8efb3ddULL, 0x565ef32cd8efb3ddULL },
        { 1, 0xc573fbeb3fba0e83ULL, 0xc573fbeb3fba0e83ULL, 0xc573fbeb3fba0e83ULL },
        { 2, 0x3222f3fd9dfe0648ULL, 0x3222f3fd9dfe0648ULL, 0x3222f3fd9dfe0648ULL },
        { 3, 0xdb0d3c076ee8cb1bULL, 0xdb0d3c076ee8cb1bULL, 0xdb0d3c076ee8cb1bULL },
        { 4, 0x0d1f768e34415b45ULL, 0x0d1f768e34415b45ULL, 0x0d1f768e34415b45ULL },
        { 7, 0xe4f6e919677017acULL, 0xe4f6e919677017acULL, 0xe4f6e919677017acULL },
        { 8, 0x11ceea2609447849ULL, 0x11ceea2609447849ULL, 0x11ceea2609447849ULL },
        { 15, 0x30affe007caf01dfULL, 0x30affe007caf01dfULL, 0x30affe007caf01dfULL },
        { 16, 0xad0695c771a3b561ULL, 0xad0695c771a3b561ULL, 0xad0695c771a3b561ULL },
        { 17, 0x4343af322371f509ULL, 0x4343af322371f509ULL, 0x4343af322371f509ULL },
        { 31, 0xfaf2c3f78c802a10ULL, 0xfaf2c3f78c802a10ULL, 0xfaf2c3f78c802a10ULL },
        { 32, 0x1b3f879d9c1e8bacULL, 0x1b3f879d9c1e8bacULL, 0x1b3f879d9c1e8bacULL },
        { 33, 0x57a20f13ea5e2fb4ULL, 0x57a20f13ea5e2fb4ULL, 0x57a20f13ea5e2fb4ULL },
        { 47, 0x626a291f49fe5334ULL, 0x626a291f49fe5334ULL, 0x626a291f49fe5334ULL },
        { 48, 0x4e53824ba53f265cULL, 0x4e53824ba53f265cULL, 0x4e53824ba53f265cULL },
        { 49, 0x1baca26f512fb009ULL, 0x1baca26f512fb009ULL, 0xd9587d65d528404fULL },
        { 63, 0xe798ee878ec4b083ULL, 0xe798ee878ec4b083ULL, 0xa0a469f727dfca50ULL },
        { 64, 0x4940e6ba3b4c0628ULL, 0x4940e6ba3b4c0628ULL, 0x21dea1803f14a82bULL },
        { 80, 0x2a6b003405ac8df8ULL, 0x2a6b003405ac8df8ULL, 0xcd4ed665f9fb649fULL },
        { 111, 0xf3528b27ae2afaa4ULL, 0xb521424163bae487ULL, 0x320a12f451e34568ULL },
        { 112, 0xbdb9626c326e9f92ULL, 0xf078def0a9495589ULL, 0x642f62729f8e6e3eULL },
        { 113, 0x39e8621e94acf6e1ULL, 0x5b7d5bde531eb582ULL, 0xeafdf19319ac686eULL },
        { 223, 0x0713cbe4448cd4e2ULL, 0x7e66267001200063ULL, 0x7ed0634bf5961bbaULL },
        { 224, 0xe9a955aebdb69dfbULL, 0x0731c971cca58599ULL, 0xcf15d2b7b00540ebULL },
        { 225, 0x8c9c89b4fd8082dcULL, 0xd72bed9bab6c3898ULL, 0x425d2d255e901856ULL },
        { 255, 0x23edbacf326d29aaULL, 0x9494b3362a482222ULL, 0xb136950c3b5fd4b5ULL },
        { 256, 0x391e3c33268c159cULL, 0x9933d1af079b9496ULL, 0x61ee8d672aa1400fULL },
        { 511, 0x1de40c1cea2ad8baULL, 0xb71a90ebbabe483bULL, 0xcb2d78e1dd20b41eULL },
        { 512, 0xff303ed75c20ea52ULL, 0x0a2d4b1e85a4298eULL, 0x1cc0463447a93ebfULL },
        { 1024, 0x4f9d6336f6ef5f35ULL, 0xe7a1fcf15ba45082ULL, 0x29b1584c17f7a404ULL },
    };

    const u64 c_seed = 0x0123456789abcdefULL;
    u8 aBuffer[1024] = {};
    sc_hash_fill_buffer(aBuffer, sizeof(aBuffer));

    const i32 c_count = to_i32(ScArrayCount(aVectors));
    for (i32 i = 0; i < c_count; ++i)
    {
        const ScHashVector* pVector = &aVectors[i];
        sc_test_condition(sc_hash_with_seed(aBuffer, pVector->Length, c_seed) == pVector->Hash);
        sc_test_condition(sc_hash_micro_with_seed(aBuffer, pVector->Length, c_seed) == pVector->Micro);
        sc_test_condition(sc_hash_nano_with_seed(aBuffer, pVector->Length, c_seed) == pVector->Nano);
    }
}

static void
sc_hash_short_inputs_equal_test()
{
    u8 aBuffer[1024] = {};
    sc_hash_fill_buffer(aBuffer, sizeof(aBuffer));

    for (u64 size = 0; size <= 80; ++size)
        sc_test_condition(sc_hash(aBuffer, size) == sc_hash_micro(aBuffer, size));

    for (u64 size = 0; size <= 48; ++size)
    {
        sc_test_condition(sc_hash(aBuffer, size) == sc_hash_nano(aBuffer, size));
        sc_test_condition(sc_hash_micro(aBuffer, size) == sc_hash_nano(aBuffer, size));
    }
}

static void
sc_hash_empty_test()
{
    sc_test_condition(sc_hash(ScNull, 0) == 0x0338dc4be2cecdaeULL);
    sc_test_condition(sc_hash_micro(ScNull, 0) == 0x0338dc4be2cecdaeULL);
    sc_test_condition(sc_hash_nano(ScNull, 0) == 0x0338dc4be2cecdaeULL);
}

void
sc_auto_hash()
{
    sc_test_file();

    sc_test_func(sc_hash_vectors_seed_zero_test());
    sc_test_func(sc_hash_vectors_seed_test());
    sc_test_func(sc_hash_short_inputs_equal_test());
    sc_test_func(sc_hash_empty_test());
}
