#ifndef SC_AUTO_H
#define SC_AUTO_H

void sc_auto();

#endif // SC_AUTO_H
