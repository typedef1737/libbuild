#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>
#include <stdio.h>

/*
 * Test structures for sc_dict
 * Must have Key as first field (matching key type) and Value as second field.
 */

typedef struct
{
    i64 Key;
    i64 Value;
} ScDictLongItem;

typedef struct
{
    char* Key;
    i32 Value;
} ScDictStringItem;

void
sc_dict_add_long_test()
{
    ScDictLongItem* hTable = ScNull;
    for (i64 i = 0; i < 100; ++i)
    {
        i64 key = i | (i + 1) << 32;
        sc_dict_i_add(hTable, key, i);
    }

    sc_test_i32_equal(sc_dict_count(hTable), 100);

    for (i64 i = 0; i < 100; ++i)
    {
        i64 key = i | (i + 1) << 32;
        i64 val = sc_dict_i_get(hTable, key);
        sc_test_i32_equal(val, i);
    }

    sc_dict_free(hTable);
}

void
sc_dict_add_string_test()
{
    ScDictStringItem* hTable = ScNull;
    char* aKeys[] = { "apple", "banana", "cherry", "date", "elderberry" };
    i32 aValues[] = { 10, 20, 30, 40, 50 };
    i32 keysCount = ScArrayCount(aKeys);

    for (i32 i = 0; i < keysCount; ++i)
        sc_dict_s_add(hTable, aKeys[i], aValues[i]);

    sc_test_i32_equal(sc_dict_count(hTable), keysCount);

    for (i32 i = 0; i < keysCount; ++i)
    {
        i32 val = sc_dict_s_get(hTable, aKeys[i]);
        sc_test_i32_equal(val, aValues[i]);
    }

    sc_dict_free(hTable);
}

void
sc_dict_grow_test()
{
    ScDictLongItem* hTable = ScNull;

    // Add enough items to trigger growth multiple times
    for (i32 i = 0; i < 1000; ++i)
        sc_dict_i_add(hTable, i, i);

    i32 finalCapacity = sc_dict_capacity(hTable);
    sc_test_condition(finalCapacity >= 1000);
    sc_test_i32_equal(sc_dict_count(hTable), 1000);

    for (i32 i = 0; i < 1000; ++i)
    {
        i32 val = sc_dict_i_get(hTable, i);
        if (val != i)
        {
            sc_test_i32_value(val);
            sc_test_i32_value(i);
            sc_test_i32_equal(val, i);
        }
    }

    sc_dict_free(hTable);
}

void
sc_dict_perf_test()
{
    i64 keyCount = 1000000;

    ScDictLongItem* hTable = ScNull;

    ScProfiler scPf = {};
    sc_profiler_start(&scPf);

    for (i64 i = 0; i < keyCount; ++i)
        sc_dict_i_add(hTable, i, i);

    sc_profiler_end(&scPf);

    char buf[256] = {};
    snprintf(buf, 256, "Время отработки добавления 1млн ключей: %s", sc_profiler_get_string(&scPf));
    sc_test_string_value(buf);

    sc_test_i32_equal(sc_dict_count(hTable), keyCount);

    sc_dict_free(hTable);
}

void
sc_dict_remove_key_string_test()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } TempKeyValue;

    TempKeyValue* hTable = NULL;

    sc_dict_s_add(hTable, "Key0", ScKb(1));
    sc_dict_s_add(hTable, "Key1", ScKb(2));
    sc_dict_s_add(hTable, "Key2", ScKb(3));
    sc_dict_s_add(hTable, "Key3", ScKb(4));

    sc_dict_s_remove(hTable, "Key2");
    sc_dict_s_remove(hTable, "Key1");
    sc_dict_s_remove(hTable, "Key3");

    sc_test_i32_equal(sc_dict_s_contains(hTable, "Key0"), 1);
    sc_test_i32_equal(sc_dict_s_contains(hTable, "Key1"), 0);
    sc_test_i32_equal(sc_dict_s_contains(hTable, "Key2"), 0);
    sc_test_i32_equal(sc_dict_s_contains(hTable, "Key3"), 0);
    sc_test_i32_equal(sc_dict_s_contains(hTable, "Key4"), 0);
}

/* ================================================================
 * String key remove tests
 * ================================================================ */

void
sc_dict_remove_string_single_element()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } Item;

    Item* d = NULL;
    sc_dict_s_add(d, "only", 42);

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_s_contains(d, "only"), 1);

    sc_dict_s_remove(d, "only");

    sc_test_i32_equal(sc_dict_count(d), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "only"), 0);
}

void
sc_dict_remove_string_all_elements()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } Item;

    Item* d = NULL;
    sc_dict_s_add(d, "a", 1);
    sc_dict_s_add(d, "b", 2);
    sc_dict_s_add(d, "c", 3);

    sc_test_i32_equal(sc_dict_count(d), 3);

    sc_dict_s_remove(d, "a");
    sc_dict_s_remove(d, "b");
    sc_dict_s_remove(d, "c");

    sc_test_i32_equal(sc_dict_count(d), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "a"), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "b"), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "c"), 0);
}

void
sc_dict_remove_string_non_existent_key()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } Item;

    Item* d = NULL;
    sc_dict_s_add(d, "key", 100);

    sc_test_i32_equal(sc_dict_count(d), 1);

    // Removing a key that doesn't exist should be a no-op
    sc_dict_s_remove(d, "non_existent");

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_s_contains(d, "key"), 1);
}

void
sc_dict_remove_string_from_empty_dict()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } Item;

    Item* d = NULL;

    sc_test_i32_equal(sc_dict_count(d), 0);

    // Removing from an empty dict should be a no-op
    sc_dict_s_remove(d, "anything");

    sc_test_i32_equal(sc_dict_count(d), 0);
}

void
sc_dict_remove_string_then_re_add()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } Item;

    Item* d = NULL;
    sc_dict_s_add(d, "x", 10);
    sc_dict_s_add(d, "y", 20);

    sc_dict_s_remove(d, "x");

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_s_contains(d, "x"), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "y"), 1);
    sc_test_i32_equal(sc_dict_s_get(d, "y"), 20);

    // Re-add the removed key with a new value
    sc_dict_s_add(d, "x", 99);

    sc_test_i32_equal(sc_dict_count(d), 2);
    sc_test_i32_equal(sc_dict_s_contains(d, "x"), 1);
    sc_test_i32_equal(sc_dict_s_get(d, "x"), 99);
    sc_test_i32_equal(sc_dict_s_get(d, "y"), 20);
}

void
sc_dict_remove_string_remaining_values_preserved()
{
    typedef struct
    {
        char* Key;
        i64 Value;
    } Item;

    Item* d = NULL;
    sc_dict_s_add(d, "first", 1);
    sc_dict_s_add(d, "second", 2);
    sc_dict_s_add(d, "third", 3);
    sc_dict_s_add(d, "fourth", 4);
    sc_dict_s_add(d, "fifth", 5);

    // Remove middle elements
    sc_dict_s_remove(d, "second");
    sc_dict_s_remove(d, "fourth");

    sc_test_i32_equal(sc_dict_count(d), 3);
    sc_test_i32_equal(sc_dict_s_contains(d, "first"), 1);
    sc_test_i32_equal(sc_dict_s_contains(d, "second"), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "third"), 1);
    sc_test_i32_equal(sc_dict_s_contains(d, "fourth"), 0);
    sc_test_i32_equal(sc_dict_s_contains(d, "fifth"), 1);

    sc_test_i32_equal(sc_dict_s_get(d, "first"), 1);
    sc_test_i32_equal(sc_dict_s_get(d, "third"), 3);
    sc_test_i32_equal(sc_dict_s_get(d, "fifth"), 5);
}

/* ================================================================
 * Numeric (long) key remove tests
 * ================================================================ */

void
sc_dict_remove_long_single_element()
{
    ScDictLongItem* d = NULL;
    sc_dict_i_add(d, 1, 100);

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 1), 1);

    sc_dict_i_remove(d, 1);

    sc_test_i32_equal(sc_dict_count(d), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 1), 0);
}

void
sc_dict_remove_long_all_elements()
{
    ScDictLongItem* d = NULL;
    sc_dict_i_add(d, 10, 10);
    sc_dict_i_add(d, 20, 20);
    sc_dict_i_add(d, 30, 30);

    sc_test_i32_equal(sc_dict_count(d), 3);

    sc_dict_i_remove(d, 10);
    sc_dict_i_remove(d, 20);
    sc_dict_i_remove(d, 30);

    sc_test_i32_equal(sc_dict_count(d), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 10), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 20), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 30), 0);
}

void
sc_dict_remove_long_non_existent_key()
{
    ScDictLongItem* d = NULL;
    sc_dict_i_add(d, 5, 500);

    sc_test_i32_equal(sc_dict_count(d), 1);

    // Removing a key that doesn't exist should be a no-op
    sc_dict_i_remove(d, 999);

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 5), 1);
    sc_test_i32_equal(sc_dict_i_get(d, 5), 500);
}

void
sc_dict_remove_long_from_empty_dict()
{
    ScDictLongItem* d = NULL;

    sc_test_i32_equal(sc_dict_count(d), 0);

    // Removing from an empty dict should be a no-op
    sc_dict_i_remove(d, 42);

    sc_test_i32_equal(sc_dict_count(d), 0);
}

void
sc_dict_remove_long_then_re_add()
{
    ScDictLongItem* d = NULL;
    sc_dict_i_add(d, 100, 1);
    sc_dict_i_add(d, 200, 2);

    sc_dict_i_remove(d, 100);

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 100), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 200), 1);
    sc_test_i32_equal(sc_dict_i_get(d, 200), 2);

    // Re-add the removed key with a new value
    sc_dict_i_add(d, 100, 999);

    sc_test_i32_equal(sc_dict_count(d), 2);
    sc_test_i32_equal(sc_dict_i_contains(d, 100), 1);
    sc_test_i32_equal(sc_dict_i_get(d, 100), 999);
    sc_test_i32_equal(sc_dict_i_get(d, 200), 2);
}

void
sc_dict_remove_long_remaining_values_preserved()
{
    ScDictLongItem* d = NULL;
    sc_dict_i_add(d, 0, 0);
    sc_dict_i_add(d, 1, 10);
    sc_dict_i_add(d, 2, 20);
    sc_dict_i_add(d, 3, 30);
    sc_dict_i_add(d, 4, 40);

    // Remove first, middle, and last
    sc_dict_i_remove(d, 0);
    sc_dict_i_remove(d, 2);
    sc_dict_i_remove(d, 4);

    sc_test_i32_equal(sc_dict_count(d), 2);
    sc_test_i32_equal(sc_dict_i_contains(d, 0), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 1), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 2), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 3), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 4), 0);

    sc_test_i32_equal(sc_dict_i_get(d, 1), 10);
    sc_test_i32_equal(sc_dict_i_get(d, 3), 30);
}

void
sc_dict_remove_long_negative_keys()
{
    ScDictLongItem* d = NULL;
    sc_dict_i_add(d, -5, 50);
    sc_dict_i_add(d, -1, 10);
    sc_dict_i_add(d, 0, 0);

    sc_test_i32_equal(sc_dict_count(d), 3);

    sc_dict_i_remove(d, -5);

    sc_test_i32_equal(sc_dict_count(d), 2);
    sc_test_i32_equal(sc_dict_i_contains(d, -5), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, -1), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 0), 1);
    sc_test_i32_equal(sc_dict_i_get(d, -1), 10);
    sc_test_i32_equal(sc_dict_i_get(d, 0), 0);

    sc_dict_i_remove(d, -1);

    sc_test_i32_equal(sc_dict_count(d), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, -1), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, 0), 1);
    sc_test_i32_equal(sc_dict_i_get(d, 0), 0);
}

void
sc_dict_remove_long_large_keys()
{
    ScDictLongItem* d = NULL;
    i64 largeKey1 = (i64)1 << 62;
    i64 largeKey2 = (i64)1 << 61;

    sc_dict_i_add(d, largeKey1, 100);
    sc_dict_i_add(d, largeKey2, 200);
    sc_dict_i_add(d, 42, 300);

    sc_test_i32_equal(sc_dict_count(d), 3);

    sc_dict_i_remove(d, largeKey1);

    sc_test_i32_equal(sc_dict_count(d), 2);
    sc_test_i32_equal(sc_dict_i_contains(d, largeKey1), 0);
    sc_test_i32_equal(sc_dict_i_contains(d, largeKey2), 1);
    sc_test_i32_equal(sc_dict_i_contains(d, 42), 1);
    sc_test_i32_equal(sc_dict_i_get(d, largeKey2), 200);
    sc_test_i32_equal(sc_dict_i_get(d, 42), 300);
}

void
sc_dict_remove_long_after_growth()
{
    ScDictLongItem* d = NULL;

    // Add many items to trigger growth
    for (i64 i = 0; i < 500; ++i)
        sc_dict_i_add(d, i, i * 2);

    sc_test_i32_equal(sc_dict_count(d), 500);

    // Remove every other key
    for (i64 i = 0; i < 500; i += 2)
        sc_dict_i_remove(d, i);

    sc_test_i32_equal(sc_dict_count(d), 250);

    // Verify remaining keys
    for (i64 i = 0; i < 500; ++i)
    {
        if (i % 2 == 0)
            sc_test_i32_equal(sc_dict_i_contains(d, i), 0);
        else
        {
            sc_test_i32_equal(sc_dict_i_contains(d, i), 1);
            sc_test_i32_equal(sc_dict_i_get(d, i), i * 2);
        }
    }

    // Remove all remaining
    for (i64 i = 1; i < 500; i += 2)
        sc_dict_i_remove(d, i);

    sc_test_i32_equal(sc_dict_count(d), 0);
}

extern void
sc_auto_dict()
{
    sc_test_file();

    sc_test_func(sc_dict_add_long_test());
    sc_test_func(sc_dict_add_string_test());
    sc_test_func(sc_dict_grow_test());
    sc_test_func(sc_dict_perf_test());

    // String key remove tests
    sc_test_func(sc_dict_remove_key_string_test());
    sc_test_func(sc_dict_remove_string_single_element());
    sc_test_func(sc_dict_remove_string_all_elements());
    sc_test_func(sc_dict_remove_string_non_existent_key());
    sc_test_func(sc_dict_remove_string_from_empty_dict());
    sc_test_func(sc_dict_remove_string_then_re_add());
    sc_test_func(sc_dict_remove_string_remaining_values_preserved());

    // Numeric (long) key remove tests
    sc_test_func(sc_dict_remove_long_single_element());
    sc_test_func(sc_dict_remove_long_all_elements());
    sc_test_func(sc_dict_remove_long_non_existent_key());
    sc_test_func(sc_dict_remove_long_from_empty_dict());
    sc_test_func(sc_dict_remove_long_then_re_add());
    sc_test_func(sc_dict_remove_long_remaining_values_preserved());
    sc_test_func(sc_dict_remove_long_negative_keys());
    sc_test_func(sc_dict_remove_long_large_keys());
    sc_test_func(sc_dict_remove_long_after_growth());
}