#include <Sc/Reflect.h>
#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

/*

  Тесты для Sc/Reflect.h / Reflect.c

  Проверяем:
    * регистрацию простых (базовых) типов;
    * регистрацию структур вместе с описанием полей;
    * получение типа по имени и его размер;
    * корректность Offset/Size у полей (читаем реальные данные по Offset);
    * повторную регистрацию (дубликат не должен попадать в реестр);
    * получение незарегистрированного типа;
    * обработку NULL-реестра;
    * sc_reflect_free.

*/

typedef struct
{
    f32 X;
    f32 Y;
} ScReflectTestVec2;

typedef struct
{
    ScReflectTestVec2 Position;
    f32 Radius;
    i32 Id;
} ScReflectTestCircle;

typedef struct
{
    i8 A;
    i64 B;
    f32 C;
} ScReflectTestMixed;

/* ================================================================
 * Базовые типы
 * ================================================================ */

void
sc_reflect_register_basic_types_test()
{
    ScReflect reflect = {};

    sc_reflect_register_type(&reflect, i8);
    sc_reflect_register_type(&reflect, u8);
    sc_reflect_register_type(&reflect, i16);
    sc_reflect_register_type(&reflect, u16);
    sc_reflect_register_type(&reflect, i32);
    sc_reflect_register_type(&reflect, u32);
    sc_reflect_register_type(&reflect, i64);
    sc_reflect_register_type(&reflect, u64);
    sc_reflect_register_type(&reflect, f32);
    sc_reflect_register_type(&reflect, f64);

    sc_test_i32_equal(sc_dict_count(reflect.hReg), 10);

    ScReflectType i8Type = sc_reflect_get_type(&reflect, i8);
    sc_test_string_equals(i8Type.pName, "i8");
    sc_test_i32_equal(i8Type.Size, sizeof(i8));
    sc_test_condition(i8Type.aFields == ScNull);

    ScReflectType u16Type = sc_reflect_get_type(&reflect, u16);
    sc_test_string_equals(u16Type.pName, "u16");
    sc_test_i32_equal(u16Type.Size, sizeof(u16));
    sc_test_condition(u16Type.aFields == ScNull);

    ScReflectType i32Type = sc_reflect_get_type(&reflect, i32);
    sc_test_string_equals(i32Type.pName, "i32");
    sc_test_i32_equal(i32Type.Size, sizeof(i32));
    sc_test_condition(i32Type.aFields == ScNull);

    ScReflectType u64Type = sc_reflect_get_type(&reflect, u64);
    sc_test_string_equals(u64Type.pName, "u64");
    sc_test_i32_equal(u64Type.Size, sizeof(u64));
    sc_test_condition(u64Type.aFields == ScNull);

    ScReflectType f32Type = sc_reflect_get_type(&reflect, f32);
    sc_test_string_equals(f32Type.pName, "f32");
    sc_test_i32_equal(f32Type.Size, sizeof(f32));
    sc_test_condition(f32Type.aFields == ScNull);

    ScReflectType f64Type = sc_reflect_get_type(&reflect, f64);
    sc_test_string_equals(f64Type.pName, "f64");
    sc_test_i32_equal(f64Type.Size, sizeof(f64));
    sc_test_condition(f64Type.aFields == ScNull);

    sc_reflect_free(&reflect);
    sc_test_condition(reflect.hReg == ScNull);
}

/* ================================================================
 * Структуры
 * ================================================================ */

void
sc_reflect_register_struct_test()
{
    ScReflect reflect = {};

    sc_reflect_register_type(&reflect, f32);
    sc_reflect_register_type(&reflect, i32);

    ScReflectFieldInfo aVec2Fields[] = {
        {
            .pName = "X",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestVec2, X),
        },
        {
            .pName = "Y",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestVec2, Y),
        },
    };

    sc_reflect_register_type(
        &reflect,
        ScReflectTestVec2,
        .FieldInfoCount = ScArrayCount(aVec2Fields),
        .aFieldInfos = aVec2Fields);

    ScReflectFieldInfo aCircleFields[] = {
        {
            .pName = "Position",
            .TypeInfo = sc_reflect_get_type(&reflect, ScReflectTestVec2),
            .Size = sizeof(ScReflectTestVec2),
            .Offset = ScOffsetOf(ScReflectTestCircle, Position),
        },
        {
            .pName = "Radius",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestCircle, Radius),
        },
        {
            .pName = "Id",
            .TypeInfo = sc_reflect_get_type(&reflect, i32),
            .Size = sizeof(i32),
            .Offset = ScOffsetOf(ScReflectTestCircle, Id),
        },
    };

    sc_reflect_register_type(
        &reflect,
        ScReflectTestCircle,
        .FieldInfoCount = ScArrayCount(aCircleFields),
        .aFieldInfos = aCircleFields);

    // DOCS: f32, i32, Vec2, Circle
    sc_test_i32_equal(sc_dict_count(reflect.hReg), 4);

    ScReflectType vec2Type = sc_reflect_get_type(&reflect, ScReflectTestVec2);
    sc_test_string_equals(vec2Type.pName, "ScReflectTestVec2");
    sc_test_i32_equal(vec2Type.Size, sizeof(ScReflectTestVec2));
    sc_test_i32_equal(sc_list_count(vec2Type.aFields), 2);

    sc_test_string_equals(vec2Type.aFields[0].pName, "X");
    sc_test_i32_equal(vec2Type.aFields[0].Size, sizeof(f32));
    sc_test_i32_equal(vec2Type.aFields[0].Offset, ScOffsetOf(ScReflectTestVec2, X));
    sc_test_string_equals(vec2Type.aFields[0].TypeInfo.pName, "f32");
    sc_test_i32_equal(vec2Type.aFields[0].TypeInfo.Size, sizeof(f32));

    sc_test_string_equals(vec2Type.aFields[1].pName, "Y");
    sc_test_i32_equal(vec2Type.aFields[1].Offset, ScOffsetOf(ScReflectTestVec2, Y));

    ScReflectType circleType = sc_reflect_get_type(&reflect, ScReflectTestCircle);
    sc_test_string_equals(circleType.pName, "ScReflectTestCircle");
    sc_test_i32_equal(circleType.Size, sizeof(ScReflectTestCircle));
    sc_test_i32_equal(sc_list_count(circleType.aFields), 3);

    sc_test_string_equals(circleType.aFields[0].pName, "Position");
    sc_test_i32_equal(circleType.aFields[0].Size, sizeof(ScReflectTestVec2));
    sc_test_i32_equal(circleType.aFields[0].Offset, ScOffsetOf(ScReflectTestCircle, Position));

    // DOCS: Вложенный тип поля должен ссылаться на зарегистрированную структуру.
    sc_test_string_equals(circleType.aFields[0].TypeInfo.pName, "ScReflectTestVec2");
    sc_test_i32_equal(sc_list_count(circleType.aFields[0].TypeInfo.aFields), 2);

    sc_test_string_equals(circleType.aFields[1].pName, "Radius");
    sc_test_i32_equal(circleType.aFields[1].Offset, ScOffsetOf(ScReflectTestCircle, Radius));
    sc_test_string_equals(circleType.aFields[1].TypeInfo.pName, "f32");

    sc_test_string_equals(circleType.aFields[2].pName, "Id");
    sc_test_i32_equal(circleType.aFields[2].Offset, ScOffsetOf(ScReflectTestCircle, Id));
    sc_test_string_equals(circleType.aFields[2].TypeInfo.pName, "i32");

    sc_reflect_free(&reflect);
}

/* ================================================================
 * Чтение данных через Offset
 * ================================================================ */

void
sc_reflect_field_offset_read_test()
{
    ScReflect reflect = {};

    sc_reflect_register_type(&reflect, f32);
    sc_reflect_register_type(&reflect, i32);

    ScReflectFieldInfo aVec2Fields[] = {
        {
            .pName = "X",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestVec2, X),
        },
        {
            .pName = "Y",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestVec2, Y),
        },
    };
    sc_reflect_register_type(
        &reflect,
        ScReflectTestVec2,
        .FieldInfoCount = ScArrayCount(aVec2Fields),
        .aFieldInfos = aVec2Fields);

    ScReflectFieldInfo aCircleFields[] = {
        {
            .pName = "Position",
            .TypeInfo = sc_reflect_get_type(&reflect, ScReflectTestVec2),
            .Size = sizeof(ScReflectTestVec2),
            .Offset = ScOffsetOf(ScReflectTestCircle, Position),
        },
        {
            .pName = "Radius",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestCircle, Radius),
        },
        {
            .pName = "Id",
            .TypeInfo = sc_reflect_get_type(&reflect, i32),
            .Size = sizeof(i32),
            .Offset = ScOffsetOf(ScReflectTestCircle, Id),
        },
    };
    sc_reflect_register_type(
        &reflect,
        ScReflectTestCircle,
        .FieldInfoCount = ScArrayCount(aCircleFields),
        .aFieldInfos = aCircleFields);

    ScReflectTestCircle circle = (ScReflectTestCircle) {
        .Position = (ScReflectTestVec2) { .X = 1.5f, .Y = -2.5f },
        .Radius = 3.25f,
        .Id = 42,
    };

    ScReflectType circleType = sc_reflect_get_type(&reflect, ScReflectTestCircle);
    char* pInstance = (char*)&circle;

    ScReflectTestVec2* pPosition = (ScReflectTestVec2*)(pInstance + circleType.aFields[0].Offset);
    f32* pRadius = (f32*)(pInstance + circleType.aFields[1].Offset);
    i32* pId = (i32*)(pInstance + circleType.aFields[2].Offset);

    sc_test_f32_equal(pPosition->X, 1.5f);
    sc_test_f32_equal(pPosition->Y, -2.5f);
    sc_test_f32_equal(*pRadius, 3.25f);
    sc_test_i32_equal(*pId, 42);

    sc_reflect_free(&reflect);
}

void
sc_reflect_struct_layout_test()
{
    ScReflect reflect = {};

    sc_reflect_register_type(&reflect, i8);
    sc_reflect_register_type(&reflect, i64);
    sc_reflect_register_type(&reflect, f32);

    ScReflectFieldInfo aFields[] = {
        {
            .pName = "A",
            .TypeInfo = sc_reflect_get_type(&reflect, i8),
            .Size = sizeof(i8),
            .Offset = ScOffsetOf(ScReflectTestMixed, A),
        },
        {
            .pName = "B",
            .TypeInfo = sc_reflect_get_type(&reflect, i64),
            .Size = sizeof(i64),
            .Offset = ScOffsetOf(ScReflectTestMixed, B),
        },
        {
            .pName = "C",
            .TypeInfo = sc_reflect_get_type(&reflect, f32),
            .Size = sizeof(f32),
            .Offset = ScOffsetOf(ScReflectTestMixed, C),
        },
    };
    sc_reflect_register_type(
        &reflect,
        ScReflectTestMixed,
        .FieldInfoCount = ScArrayCount(aFields),
        .aFieldInfos = aFields);

    ScReflectType mixedType = sc_reflect_get_type(&reflect, ScReflectTestMixed);
    sc_test_i32_equal(mixedType.Size, sizeof(ScReflectTestMixed));
    sc_test_i32_equal(sc_list_count(mixedType.aFields), 3);

    // DOCS: Offsets не обязаны идти подряд из-за выравнивания.
    sc_test_condition(mixedType.aFields[0].Offset < mixedType.aFields[1].Offset);
    sc_test_condition(mixedType.aFields[1].Offset < mixedType.aFields[2].Offset);

    ScReflectTestMixed value = (ScReflectTestMixed) {
        .A = -7,
        .B = (i64)1 << 40,
        .C = 0.5f,
    };

    char* pInstance = (char*)&value;
    i8 a = *(i8*)(pInstance + mixedType.aFields[0].Offset);
    i64 b = *(i64*)(pInstance + mixedType.aFields[1].Offset);
    f32 c = *(f32*)(pInstance + mixedType.aFields[2].Offset);

    sc_test_i32_equal(a, -7);
    sc_test_condition(b == ((i64)1 << 40));
    sc_test_f32_equal(c, 0.5f);

    sc_reflect_free(&reflect);
}

/* ================================================================
 * Дубликаты, отсутствующие и некорректные типы
 * ================================================================ */

void
sc_reflect_register_duplicate_test()
{
    ScReflect reflect = {};

    sc_reflect_register_type(&reflect, i32);
    sc_test_i32_equal(sc_dict_count(reflect.hReg), 1);

    // DOCS: Повторная регистрация не должна создавать вторую запись.
    sc_reflect_register_type(&reflect, i32);
    sc_test_i32_equal(sc_dict_count(reflect.hReg), 1);

    // DOCS: Размер ранее зарегистрированного типа не должен пострадать.
    ScReflectType i32Type = sc_reflect_get_type(&reflect, i32);
    sc_test_i32_equal(i32Type.Size, sizeof(i32));

    sc_reflect_free(&reflect);
}

void
sc_reflect_get_unregistered_test()
{
    ScReflect reflect = {};

    ScReflectType type = sc_reflect_get_type(&reflect, f64);
    sc_test_condition(type.pName == ScNull);
    sc_test_i32_equal(type.Size, 0);
    sc_test_condition(type.aFields == ScNull);

    sc_reflect_register_type(&reflect, i32);

    // DOCS: Тип по-прежнему не зарегистрирован.
    ScReflectType f64Type = sc_reflect_get_type(&reflect, f64);
    sc_test_condition(f64Type.pName == ScNull);
    sc_test_i32_equal(f64Type.Size, 0);

    sc_reflect_free(&reflect);
}

void
sc_reflect_null_registry_test()
{
    ScReflect reflect = {};

    // DOCS: NULL-реестр не должен падать.
    sc_reflect_register_type(ScNull, i32);

    // DOCS: NULL-реестр не должен ломать получение типа.
    ScReflectType nullReflectType = sc_reflect_get_type(ScNull, i32);
    sc_test_condition(nullReflectType.pName == ScNull);
    sc_test_i32_equal(nullReflectType.Size, 0);

    // DOCS: Пустой реестр остаётся пустым.
    sc_test_i32_equal(sc_dict_count(reflect.hReg), 0);

    sc_reflect_free(&reflect);
    // DOCS: Повторный free не должен падать.
    sc_reflect_free(&reflect);
}

void
sc_reflect_free_empty_test()
{
    ScReflect reflect = {};

    sc_test_condition(reflect.hReg == ScNull);
    sc_reflect_free(&reflect);
    sc_test_condition(reflect.hReg == ScNull);
}

/* ================================================================
 * Entry point
 * ================================================================ */

extern void
sc_auto_reflect()
{
    sc_test_file();

    sc_test_func(sc_reflect_register_basic_types_test());
    sc_test_func(sc_reflect_register_struct_test());
    sc_test_func(sc_reflect_field_offset_read_test());
    sc_test_func(sc_reflect_struct_layout_test());
    sc_test_func(sc_reflect_register_duplicate_test());
    sc_test_func(sc_reflect_get_unregistered_test());
    sc_test_func(sc_reflect_null_registry_test());
    sc_test_func(sc_reflect_free_empty_test());
}
