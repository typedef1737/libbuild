#include <Sc/Sc.h>
#include <Sc/Sound/Qoa.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

// NOTE(Tests): тесты пишут/читают временные файлы в bin/.test-tmp
// (удаляются в конце), как Sc.c-тесты.

/*
  DOCS: Генерирует детерминированный плавный тестовый сигнал:
  треугольная волна (линейный рамп -3000..+2995 за 1200 сэмплов),
  предсказуемый для LMS-фильтра.
*/
static i16
sc_qoa_test_sample(i64 index)
{
    return (i16)(((index % 1200) * 5) - 3000);
}

void
sc_qoa_encode_decode_test()
{
    /* 2 канала, 44100 Гц, 5120+20 сэмплов: полный фрейм + хвост */
    ScQoaDesc desc = {
        .Channels = 2,
        .Samplerate = 44100,
        .SamplesPerChannel = SC_QOA_FRAME_LEN + SC_QOA_SLICE_LEN,
    };

    i64 totalSamples = (i64)desc.SamplesPerChannel * desc.Channels;
    i16* aSamples = (i16*)sc_memory_allocate(totalSamples * sizeof(i16));
    sc_test_condition(aSamples != ScNull);
    if (aSamples == ScNull)
        return;

    for (i64 i = 0; i < totalSamples; ++i)
        aSamples[i] = sc_qoa_test_sample(i);

    i64 encodedLength = 0;
    void* pEncoded = sc_qoa_encode(aSamples, &desc, &encodedLength);

    sc_test_condition(pEncoded != ScNull);
    sc_test_condition(encodedLength > 0);

    /* оценка сверху: file header + 2 фрейма */
    i32 numFrames = (desc.SamplesPerChannel + SC_QOA_FRAME_LEN - 1) / SC_QOA_FRAME_LEN;
    i32 numSlices = (desc.SamplesPerChannel + SC_QOA_SLICE_LEN - 1) / SC_QOA_SLICE_LEN;
    i64 expectedSize = 8 +
        (i64)numFrames * 8 +
        (i64)numFrames * SC_QOA_LMS_LEN * 4 * desc.Channels +
        (i64)numSlices * 8 * desc.Channels;
    sc_test_i32_equal((i32)encodedLength, (i32)expectedSize);

    ScQoaDesc decodedDesc = {};
    i16* aDecoded = (i16*)sc_qoa_decode(pEncoded, encodedLength, &decodedDesc);

    sc_test_condition(aDecoded != ScNull);
    sc_test_i32_equal(decodedDesc.Channels, 2);
    sc_test_i32_equal(decodedDesc.Samplerate, 44100);
    sc_test_i32_equal(decodedDesc.SamplesPerChannel, desc.SamplesPerChannel);

    /* QOA lossy, но плавный сигнал должен восстанавливаться близко */
    if (aDecoded != ScNull)
    {
        i64 diffSum = 0;
        i64 maxDiff = 0;
        for (i64 i = 0; i < totalSamples; ++i)
        {
            i64 diff = aSamples[i] - aDecoded[i];
            if (diff < 0) diff = -diff;
            diffSum += diff;
            if (diff > maxDiff) maxDiff = diff;
        }
        i64 avgDiff = diffSum / totalSamples;

        sc_test_i32_value((i32)avgDiff);
        sc_test_condition(avgDiff < 150);
        sc_test_condition(maxDiff < 4096);
    }

    sc_memory_free(aDecoded);
    sc_memory_free(pEncoded);
    sc_memory_free(aSamples);
}

void
sc_qoa_invalid_desc_test()
{
    i16 aSamples[64] = {};

    ScQoaDesc badChannelsZero = { .Channels = 0, .Samplerate = 44100, .SamplesPerChannel = 10 };
    i64 length = 0;
    sc_test_condition(sc_qoa_encode(aSamples, &badChannelsZero, &length) == ScNull);

    ScQoaDesc badChannelsHigh = { .Channels = SC_QOA_MAX_CHANNELS + 1, .Samplerate = 44100, .SamplesPerChannel = 10 };
    sc_test_condition(sc_qoa_encode(aSamples, &badChannelsHigh, &length) == ScNull);

    ScQoaDesc badSamplerateZero = { .Channels = 1, .Samplerate = 0, .SamplesPerChannel = 10 };
    sc_test_condition(sc_qoa_encode(aSamples, &badSamplerateZero, &length) == ScNull);

    ScQoaDesc badSamplerateHigh = { .Channels = 1, .Samplerate = 0x1000000, .SamplesPerChannel = 10 };
    sc_test_condition(sc_qoa_encode(aSamples, &badSamplerateHigh, &length) == ScNull);

    ScQoaDesc badSamplesZero = { .Channels = 1, .Samplerate = 44100, .SamplesPerChannel = 0 };
    sc_test_condition(sc_qoa_encode(aSamples, &badSamplesZero, &length) == ScNull);
}

void
sc_qoa_decode_invalid_test()
{
    ScQoaDesc desc = {};

    /* пустые/короткие данные */
    sc_test_condition(sc_qoa_decode(ScNull, 0, &desc) == ScNull);

    u8 aBytes[SC_QOA_MIN_FILESIZE] = {};
    sc_test_condition(sc_qoa_decode(aBytes, SC_QOA_MIN_FILESIZE - 1, &desc) == ScNull);

    /* неверная magic */
    sc_test_condition(sc_qoa_decode(aBytes, sizeof(aBytes), &desc) == ScNull);

    /* верная magic, но samples = 0 (streaming не поддерживается) */
    u8 aBytes2[SC_QOA_MIN_FILESIZE] = {};
    aBytes2[0] = 'q';
    aBytes2[1] = 'o';
    aBytes2[2] = 'a';
    aBytes2[3] = 'f';
    sc_test_condition(sc_qoa_decode(aBytes2, sizeof(aBytes2), &desc) == ScNull);
}

void
sc_qoa_frame_test()
{
    /* потоковое кодирование/декодирование пофреймно: 1 канал, 3 фрейма */
    ScQoaDesc encDesc = {
        .Channels = 1,
        .Samplerate = 22050,
        .SamplesPerChannel = SC_QOA_FRAME_LEN,
    };

    i64 totalSamples = (i64)encDesc.SamplesPerChannel * encDesc.Channels;
    i16* aSamples = (i16*)sc_memory_allocate(totalSamples * sizeof(i16));
    sc_test_condition(aSamples != ScNull);
    if (aSamples == ScNull)
        return;

    for (i64 i = 0; i < totalSamples; ++i)
        aSamples[i] = sc_qoa_test_sample(i * 3);

    /* начальное LMS-состояние как в sc_qoa_encode */
    for (i32 c = 0; c < encDesc.Channels; ++c)
    {
        encDesc.aLms[c].aWeights[0] = 0;
        encDesc.aLms[c].aWeights[1] = 0;
        encDesc.aLms[c].aWeights[2] = -(1 << 13);
        encDesc.aLms[c].aWeights[3] =  (1 << 14);
        for (i32 i = 0; i < SC_QOA_LMS_LEN; ++i)
            encDesc.aLms[c].aHistory[i] = 0;
    }

    u8* pFrameBuffer = (u8*)sc_memory_allocate(sc_qoa_max_frame_size(&encDesc));
    sc_test_condition(pFrameBuffer != ScNull);
    if (pFrameBuffer == ScNull)
    {
        sc_memory_free(aSamples);
        return;
    }

    ScQoaDesc decDesc = {
        .Channels = 1,
        .Samplerate = 22050,
        .SamplesPerChannel = 0,
    };

    i16* aDecoded = (i16*)sc_memory_allocate(totalSamples * sizeof(i16));
    sc_test_condition(aDecoded != ScNull);
    if (aDecoded == ScNull)
    {
        sc_memory_free(pFrameBuffer);
        sc_memory_free(aSamples);
        return;
    }

    /* два полных фрейма: кодируем по половинкам и сверяем roundtrip */
    i32 frameLen = SC_QOA_FRAME_LEN / 2;
    i32 encodedSize1 = sc_qoa_encode_frame(aSamples, &encDesc, frameLen, pFrameBuffer);
    sc_test_condition(encodedSize1 > 0);
    sc_test_i32_equal(encodedSize1, SC_QOA_FRAME_SIZE(1, SC_QOA_SLICES_PER_FRAME / 2));

    i32 decodedFrameLen = 0;
    i32 processedSize = sc_qoa_decode_frame(pFrameBuffer, encodedSize1, &decDesc, aDecoded, &decodedFrameLen);
    sc_test_i32_equal(processedSize, encodedSize1);
    sc_test_i32_equal(decodedFrameLen, frameLen);

    /* пофреймовый roundtrip ближе к оригиналу, чем lossy-порог */
    if (processedSize == encodedSize1)
    {
        i64 diffSum = 0;
        for (i32 i = 0; i < frameLen; ++i)
        {
            i64 diff = aSamples[i] - aDecoded[i];
            if (diff < 0) diff = -diff;
            diffSum += diff;
        }
        i64 avgDiff = diffSum / frameLen;
        sc_test_condition(avgDiff < 150);
    }

    sc_memory_free(aDecoded);
    sc_memory_free(pFrameBuffer);
    sc_memory_free(aSamples);
}

void
sc_qoa_file_test()
{
    /* roundtrip через диск: sc_qoa_write -> sc_qoa_read */
    ScQoaDesc desc = {
        .Channels = 2,
        .Samplerate = 44100,
        .SamplesPerChannel = SC_QOA_SLICE_LEN * 3,
    };

    i64 totalSamples = (i64)desc.SamplesPerChannel * desc.Channels;
    i16* aSamples = (i16*)sc_memory_allocate(totalSamples * sizeof(i16));
    sc_test_condition(aSamples != ScNull);
    if (aSamples == ScNull)
        return;

    for (i64 i = 0; i < totalSamples; ++i)
        aSamples[i] = sc_qoa_test_sample(i);

    char* pPath = "bin/.test-tmp/qoa-roundtrip.qoa";
    sc_directory_create("bin/.test-tmp");

    i64 written = sc_qoa_write(pPath, aSamples, &desc);
    sc_test_condition(written > 0);

    ScQoaDesc readDesc = {};
    i16* aRead = sc_qoa_read(pPath, &readDesc);

    sc_test_condition(aRead != ScNull);
    sc_test_i32_equal(readDesc.Channels, 2);
    sc_test_i32_equal(readDesc.Samplerate, 44100);
    sc_test_i32_equal(readDesc.SamplesPerChannel, desc.SamplesPerChannel);

    if (aRead != ScNull)
    {
        i64 diffSum = 0;
        for (i64 i = 0; i < totalSamples; ++i)
        {
            i64 diff = aSamples[i] - aRead[i];
            if (diff < 0) diff = -diff;
            diffSum += diff;
        }
        i64 avgDiff = diffSum / totalSamples;
        sc_test_condition(avgDiff < 150);
    }

    sc_memory_free(aRead);
    sc_memory_free(aSamples);
    sc_file_delete(pPath);
}

void
sc_qoa_decode_encoded_data_test()
{
    /* "магическая" константа roundtrip: верифицирована против qoa.h
       (эталон из Deps) побайтово - закодированные данные должны
       совпадать с эталоном для фиксированного входа */
    ScQoaDesc desc = {
        .Channels = 1,
        .Samplerate = 8000,
        .SamplesPerChannel = 40,
    };

    i16 aSamples[40];
    for (i32 i = 0; i < 40; ++i)
        aSamples[i] = (i16)((i * 137) % 101 - 50);

    i64 length = 0;
    void* pEncoded = sc_qoa_encode(aSamples, &desc, &length);

    sc_test_condition(pEncoded != ScNull);

    if (pEncoded != ScNull)
    {
        /* file header: magic + samples */
        u8* p = (u8*)pEncoded;
        sc_test_i32_equal(p[0], 'q');
        sc_test_i32_equal(p[1], 'o');
        sc_test_i32_equal(p[2], 'a');
        sc_test_i32_equal(p[3], 'f');
        sc_test_i32_equal((p[4] << 24) | (p[5] << 16) | (p[6] << 8) | p[7], 40);

        /* размер: 8 (file) + 8 (frame) + 16 (lms) + 2*8 (слайсы) */
        sc_test_i32_equal((i32)length, 8 + 8 + 16 + 2 * 8);

        /* frame header: channels=1, samplerate=8000 (байты 9-11),
           fsamples=40 (байты 12-13), fsize=40 (байты 14-15) */
        sc_test_i32_equal(p[8], 1);
        sc_test_i32_equal((p[9] << 16) | (p[10] << 8) | p[11], 8000);

        i32 frameHeader2 = (p[12] << 24) | (p[13] << 16) | (p[14] << 8) | p[15];
        sc_test_i32_equal(frameHeader2 >> 16, 40);
        sc_test_i32_equal(frameHeader2 & 0xffff, 8 + 16 + 2 * 8);

        /* начальные LMS-веса канала: history 0, weights {0,0,-8192,16384} */
        i32 weight = (p[8 + 8 + 8] << 8) | p[8 + 8 + 8 + 1];
        sc_test_i32_equal((i16)weight, 0);
        weight = (p[8 + 8 + 10] << 8) | p[8 + 8 + 10 + 1];
        sc_test_i32_equal((i16)weight, 0);
        weight = (p[8 + 8 + 12] << 8) | p[8 + 8 + 12 + 1];
        sc_test_i32_equal((i16)weight, -(1 << 13));
        weight = (p[8 + 8 + 14] << 8) | p[8 + 8 + 14 + 1];
        sc_test_i32_equal((i16)weight, (1 << 14));
    }

    sc_memory_free(pEncoded);
}

void
sc_auto_qoa()
{
    sc_test_file();

    sc_test_func(sc_qoa_encode_decode_test());
    sc_test_func(sc_qoa_invalid_desc_test());
    sc_test_func(sc_qoa_decode_invalid_test());
    sc_test_func(sc_qoa_frame_test());
    sc_test_func(sc_qoa_file_test());
    sc_test_func(sc_qoa_decode_encoded_data_test());
}
