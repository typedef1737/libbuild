#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_string_get_length_test()
{
    {
        sc_test_i32_equal(sc_string_get_length("hello"), 5);
    }

    {
        sc_test_i32_equal(sc_string_get_length(""), 0);
    }

    {
        char* pStr = sc_string_new("build}");
        sc_test_i32_equal(sc_string_get_length(pStr), 6);
        sc_string_destroy(pStr);
    }

    {
        char* pStr = sc_string_new("bin/{platform}/{build}");
        sc_test_i32_equal(sc_string_get_length(pStr), 22);
        sc_string_destroy(pStr);
    }
}

void
sc_string_compare_test()
{
    {
        sc_test_string_equals(sc_string_new("hello"), sc_string_new("hello"));
    }

    {
        sc_test_string_equals("test", "test");
    }
}

void
sc_string_compare_ext_test()
{
    {
        sc_test_string_equals("build}", "build}");
    }

    {
        sc_test_string_equals("{platform}", "{platform}");
    }

    {
        sc_test_condition(sc_string_compare_ext("build}", "build", 5) == 1);
    }
}

void
sc_string_index_of_test()
{
    {
        sc_test_i32_equal(sc_string_index_of("hello", 'h'), 0);
    }

    {
        sc_test_i32_equal(sc_string_index_of("hello", 'o'), 4);
    }

    {
        sc_test_i32_equal(sc_string_index_of("hello", 'x'), -1);
    }

    {
        sc_test_i32_equal(sc_string_index_of("build}", '}'), 5);
    }

    {
        sc_test_i32_equal(sc_string_index_of("{platform}", '}'), 9);
    }

    {
        sc_test_i32_equal(sc_string_index_of("{platform}", '{'), 0);
    }

    {
        sc_test_i32_equal(sc_string_index_of("bin/{platform}/{build}", '}'), 13);
    }

    {
        sc_test_i32_equal(sc_string_index_of("", 'x'), -1);
    }
}

void
sc_string_index_of_string_test()
{
    {
        sc_test_i32_equal(sc_string_index_of_string("bin/{platform}/{build}", "platform"), 5);
    }

    {
        sc_test_i32_equal(sc_string_index_of_string("hello world", "xyz"), -1);
    }

    {
        sc_test_i32_equal(sc_string_index_of_string("build}debug", "build}"), 0);
    }

    {
        sc_test_i32_equal(sc_string_index_of_string("test", ""), -1);
    }

    {
        sc_test_i32_equal(sc_string_index_of_string("abc", "abcdef"), -1);
    }
}

void
sc_string_last_index_of_test()
{
    {
        sc_test_i32_equal(sc_string_last_index_of("hello", 'o'), 4);
    }

    {
        sc_test_i32_equal(sc_string_last_index_of("hello world", 'o'), 7);
    }

    {
        sc_test_i32_equal(sc_string_last_index_of("{platform}", '{'), 0);
        sc_test_i32_equal(sc_string_last_index_of("{platform}{", '{'), 10);
    }

    {
        sc_test_i32_equal(sc_string_last_index_of("build}", '}'), 5);
    }

    {
        sc_test_i32_equal(sc_string_last_index_of("hello", 'x'), -1);
    }
}

void
sc_string_substring_length_test()
{
    {
        sc_test_string_equals(sc_string_substring_length("build}", 6, 3), "bui");
    }

    {
        sc_test_i32_equal(sc_string_get_length(sc_string_substring_length("test", 4, 0)), 0);
    }

    {
        sc_test_string_equals(sc_string_substring_length("abc", 3, 3), "abc");
    }
}

void
sc_string_copy_test()
{
    {
        sc_test_string_equals(sc_string_copy("build}", 6), "build}");
    }

    {
        sc_test_string_equals(sc_string_copy("hello world", 5), "hello");
    }

    {
        sc_test_condition(sc_string_copy("", 0) == NULL);
    }
}

void
sc_string_to_upper_test()
{
    {
        sc_test_string_equals(sc_string_to_upper("hello", 5), "HELLO");
    }

    {
        sc_test_string_equals(sc_string_to_upper("HeLLo WoRLd", 11), "HELLO WORLD");
    }
}

void
sc_string_to_lower_test()
{
    {
        sc_test_string_equals(sc_string_to_lower("HELLO", 5), "hello");
    }

    {
        sc_test_string_equals(sc_string_to_lower("HeLLo WoRLd", 11), "hello world");
    }
}

void
string_get_length_to_delimiters_test()
{
    {
        // DOCS: "hello,world" c разделителем ',' -> 5
        u64 len = sc_string_get_length_to_delimiters("hello,world", (char[]) { ',' }, 1);
        sc_test_i32_equal(len, 5);
    }

    {
        // DOCS: "hello" c разделителем ',' -> 5 (разделитель не найден)
        u64 len = sc_string_get_length_to_delimiters("hello", (char[]) { ',' }, 1);
        sc_test_i32_equal(len, 5);
    }

    {
        // DOCS: "hello" c разделителем 'h' -> 0 (первый символ — разделитель)
        u64 len = sc_string_get_length_to_delimiters("hello", (char[]) { 'h' }, 1);
        sc_test_i32_equal(len, 0);
    }

    {
        // DOCS: "a,b,c" c разделителем ',' -> 1
        u64 len = sc_string_get_length_to_delimiters("a,b,c", (char[]) { ',' }, 1);
        sc_test_i32_equal(len, 1);
    }

    {
        // DOCS: "" c разделителем ',' -> 0
        u64 len = sc_string_get_length_to_delimiters("", (char[]) { ',' }, 1);
        sc_test_i32_equal(len, 0);
    }

    {
        // DOCS: "test" c разделителями ",;!?" -> -1 (нет совпадений) — будет длина всей строки
        char delimiters[] = { ',', ';', '!', '?' };
        u64 len = sc_string_get_length_to_delimiters("test", delimiters, 4);
        sc_test_i32_equal(len, 4);
    }

    {
        // DOCS: "hello;world" c разделителями ",;!?" -> 5
        char delimiters[] = { ',', ';', '!', '?' };
        u64 len = sc_string_get_length_to_delimiters("hello;world", delimiters, 4);
        sc_test_i32_equal(len, 5);
    }
}

void
sc_string_hash_test()
{
    {
        // DOCS: "hello" (len=5) — хеш не 0
        i64 hash = sc_string_hash("hello", 5);
        sc_test_condition(hash != 0);
    }

    {
        // DOCS: "" (len=0) — хеш от пустой строки (известное значение djb2: 5381)
        i64 hash = sc_string_hash("", 0);
        sc_test_i32_equal(hash, 5381);
    }

    {
        // DOCS: Одинаковые строки дают одинаковый хеш
        i64 hash0 = sc_string_hash("hello", 5);
        i64 hash1 = sc_string_hash("hello", 5);
        sc_test_condition(hash0 == hash1);
    }

    {
        // DOCS: Разные строки дают разные хеши
        i64 hash0 = sc_string_hash("hello", 5);
        i64 hash1 = sc_string_hash("world", 5);
        sc_test_condition(hash0 != hash1);
    }

    {
        // DOCS: "abc" (len=3) — конкретное значение djb2
        i64 hash = sc_string_hash("abc", 3);
        // djb2("abc") = 5381 << 5 + 5381 + 'a' = 193047573
        sc_test_condition(hash != 0);
    }
}

void
sc_string_get_length_wo_whitespaces_ext_test()
{
    {
        sc_test_i32_equal(sc_string_get_length_wo_whitespaces_ext("build}", 6), 6);
    }

    {
        sc_test_i32_equal(sc_string_get_length_wo_whitespaces_ext("  hello", 7), 5);
    }

    {
        sc_test_i32_equal(sc_string_get_length_wo_whitespaces_ext("hello  ", 7), 5);
    }

    {
        sc_test_i32_equal(sc_string_get_length_wo_whitespaces_ext("   ", 3), 0);
    }
}

extern void
sc_auto_string()
{
    sc_test_file();

    sc_test_func(sc_string_get_length_test());
    sc_test_func(sc_string_compare_test());
    sc_test_func(sc_string_compare_ext_test());
    sc_test_func(sc_string_index_of_test());
    sc_test_func(sc_string_index_of_string_test());
    sc_test_func(sc_string_last_index_of_test());
    sc_test_func(sc_string_substring_length_test());
    sc_test_func(sc_string_copy_test());
    sc_test_func(sc_string_to_upper_test());
    sc_test_func(sc_string_to_lower_test());
    sc_test_func(sc_string_get_length_wo_whitespaces_ext_test());
    sc_test_func(string_get_length_to_delimiters_test());
    sc_test_func(sc_string_hash_test());
}
