#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

static i32*
create_indices_array(i32 count)
{
    i32* aIndices = sc_list_reserve(aIndices, count);
    for (i32 i = 0; i < count; ++i)
        sc_list_add(aIndices, i);
    return aIndices;
}

void
sc_list_add_and_remove_test()
{
    i32* aIndices = create_indices_array(10);

    sc_test_condition(sc_list_count(aIndices) == 10);
    sc_list_remove_index(aIndices, 5);
    sc_test_condition(sc_list_count(aIndices) == 9);

    sc_test_condition(aIndices[0] == 0);
    sc_test_condition(aIndices[1] == 1);
    sc_test_condition(aIndices[2] == 2);
    sc_test_condition(aIndices[3] == 3);
    sc_test_condition(aIndices[4] == 4);
    sc_test_condition(aIndices[5] == 6);
    sc_test_condition(aIndices[6] == 7);
    sc_test_condition(aIndices[7] == 8);
    sc_test_condition(aIndices[8] == 9);

    char buf[128] = {};
    sc_format(buf, 128, "count: %d(%d)", sc_list_count(aIndices), sc_list_capacity(aIndices));
    sc_test_string_value(buf);
}

void
sc_list_add_multiple_test()
{
    i32* aIndices = create_indices_array(3);
    i32* aIndices2 = create_indices_array(4);

    sc_list_add_multiple(aIndices, aIndices2, sizeof(i32), sc_list_count(aIndices2));

    sc_test_condition(aIndices[0] == 0);
    sc_test_condition(aIndices[1] == 1);
    sc_test_condition(aIndices[2] == 2);
    sc_test_condition(aIndices[3] == 0);
    sc_test_condition(aIndices[4] == 1);
    sc_test_condition(aIndices[5] == 2);
    sc_test_condition(aIndices[6] == 3);
    sc_test_condition(sc_list_count(aIndices) == 7);
    sc_test_condition(sc_list_capacity(aIndices) == 9);
}

void
sc_list_remove_test()
{
    i32* aIndices = create_indices_array(3);
    sc_list_remove(aIndices, 2);
    sc_test_condition(aIndices[0] == 0);
    sc_test_condition(aIndices[1] == 1);

    i32 cap = sc_list_capacity(aIndices);
    sc_test_condition(cap == 3);
    i32 count = sc_list_count(aIndices);
    sc_test_condition(count == 2);
}

void
sc_list_for_each_test()
{
    i32* aIndices = create_indices_array(7);
    i32 ind = 0;
    sc_list_for_each(aIndices, pInd)
    {
        ++ind;
    }
    sc_test_condition(ind == 7);
}

void
sc_list_pop_test()
{
    i32* aIndices = create_indices_array(7);
    i32 ind = sc_list_pop(aIndices);
    sc_test_condition(ind == 0);

    sc_test_condition(sc_list_count(aIndices) == 6);

    i32 cnt = sc_list_count(aIndices);
    for (i32 i = 0; i < cnt; ++i)
        (void)sc_list_pop(aIndices);

    sc_test_condition(sc_list_count(aIndices) == 0);
    sc_test_condition(sc_list_capacity(aIndices) == 7);
}

void
sc_list_reserve_test()
{
    i32* aIndices = ScNull;
    sc_list_reserve(aIndices, 5);

    sc_test_condition(sc_list_capacity(aIndices) == 5);
    sc_test_condition(sc_list_count(aIndices) == 0);

    for (i32 i = 0; i < 5; ++i)
        aIndices[i] = 0;

    sc_memory_allocate(1);

    sc_test_i32_value(1);
}

void
sc_list_clear_test()
{
    i32* aIndices = create_indices_array(11);
    sc_list_clear(aIndices);

    sc_test_condition(sc_list_count(aIndices) == 0);
    sc_test_condition(sc_list_capacity(aIndices) == 11);
}

void
sc_list_deep_copy_test()
{
    i32* aIndices = create_indices_array(11);
    i32* aNewIndices = sc_list_deep_copy(aIndices);

    for (i32 i = 0; i < sc_list_count(aIndices); ++i)
        sc_test_condition(aIndices[i] == aNewIndices[i]);

    sc_test_condition(aIndices != aNewIndices);
    sc_test_condition(sc_list_count(aIndices) == 11);
    sc_test_condition(sc_list_count(aNewIndices) == 11);
    sc_test_condition(sc_list_capacity(aIndices) == 11);
    sc_test_condition(sc_list_capacity(aNewIndices) == 11);
}

extern void
sc_auto_list()
{
    sc_test_file();

    sc_test_func(sc_list_add_and_remove_test());
    sc_test_func(sc_list_remove_test());
    sc_test_func(sc_list_for_each_test());
    sc_test_func(sc_list_pop_test());
    sc_test_func(sc_list_add_multiple_test());
    sc_test_func(sc_list_reserve_test());
    sc_test_func(sc_list_clear_test());
    sc_test_func(sc_list_deep_copy_test());
}
