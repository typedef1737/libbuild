#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_format_limited_length_test()
{
    char buf[41] = {};
    ScFormatResult r = sc_format(buf, 41, "%d sad sad sd 123456789 0011 0110 very_1long string with different words etc", 1024);
    sc_test_i32_equal(r.IsFinished, 1);

    sc_test_string_equals(buf, "1024 sad sad sd 123456789 0011 0110 very");
    sc_test_string_value(buf);
}

extern void
sc_auto_format()
{
    sc_test_file();

    sc_test_func(sc_format_limited_length_test());
}
