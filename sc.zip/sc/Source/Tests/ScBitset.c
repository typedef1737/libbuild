#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_bitset_set_get_test()
{
    bitset512 bitset = {};
    i32 bitsCount = sc_bits_count(bitset);

    i32 aBitsToSet[] = { 0, 1, 63, 64, 65, 127, 128, 255, 511 };
    for (i32 i = 0; i < ScArrayCount(aBitsToSet); ++i)
        sc_bitset_set_1(bitset.Mask, bitsCount, aBitsToSet[i]);

    for (i32 i = 0; i < ScArrayCount(aBitsToSet); ++i)
        sc_test_condition(sc_bitset_get(bitset.Mask, bitsCount, aBitsToSet[i]) == 1);

    i32 aBitsToCheckZero[] = { 2, 62, 66, 126, 256, 300 };
    for (i32 i = 0; i < ScArrayCount(aBitsToCheckZero); ++i)
        sc_test_condition(sc_bitset_get(bitset.Mask, bitsCount, aBitsToCheckZero[i]) == 0);

    // DOCS: Bits are stored as u64 array, [0] - bits 0-63, [1] - 64-127, etc.
    sc_test_condition((bitset.Mask[0] & sc_bitset_get_bit_mask(0)) != 0);
    sc_test_condition((bitset.Mask[0] & sc_bitset_get_bit_mask(63)) != 0);
    sc_test_condition((bitset.Mask[1] & sc_bitset_get_bit_mask(64)) != 0);
    sc_test_condition((bitset.Mask[1] & sc_bitset_get_bit_mask(127)) != 0);
    sc_test_condition((bitset.Mask[2] & sc_bitset_get_bit_mask(128)) != 0);
    sc_test_condition((bitset.Mask[3] & sc_bitset_get_bit_mask(255)) != 0);
    sc_test_condition((bitset.Mask[7] & sc_bitset_get_bit_mask(511)) != 0);
}

void
sc_bitset_set_0_test()
{
    bitset512 bitset = {};
    i32 bitsCount = sc_bits_count(bitset);

    sc_bitset_set_1(bitset.Mask, bitsCount, 0);
    sc_bitset_set_1(bitset.Mask, bitsCount, 300);

    sc_bitset_set_0(bitset.Mask, bitsCount, 0);
    sc_test_condition(sc_bitset_get(bitset.Mask, bitsCount, 0) == 0);
    sc_test_condition(sc_bitset_get(bitset.Mask, bitsCount, 300) == 1);

    sc_bitset_set_0(bitset.Mask, bitsCount, 300);
    sc_test_condition(sc_bitset_get(bitset.Mask, bitsCount, 300) == 0);
}

void
sc_bitset_contains_test()
{
    bitset512 bitset0 = {};
    bitset512 bitset1 = {};
    i32 bitsCount = sc_bits_count(bitset0);

    i32 aBits[] = { 0, 1, 63, 64, 128, 255, 300, 511 };
    for (i32 i = 0; i < ScArrayCount(aBits); ++i)
    {
        sc_bitset_set_1(bitset0.Mask, bitsCount, aBits[i]);
        sc_bitset_set_1(bitset1.Mask, bitsCount, aBits[i]);
    }

    sc_test_condition(sc_bitset_contains(bitset0.Mask, bitsCount, bitset1.Mask, bitsCount) == 1);
    sc_test_condition(sc_bitset_contains(bitset1.Mask, bitsCount, bitset0.Mask, bitsCount) == 1);

    // DOCS: Missing bit in pBitset0 -> not contained.
    sc_bitset_set_0(bitset0.Mask, bitsCount, 300);
    sc_test_condition(sc_bitset_contains(bitset0.Mask, bitsCount, bitset1.Mask, bitsCount) == 0);

    // DOCS: Empty bitset is contained by any bitset.
    bitset512 empty = {};
    sc_test_condition(sc_bitset_contains(bitset0.Mask, bitsCount, empty.Mask, bitsCount) == 1);
}

void
sc_bitset_contains_more_flags_test()
{
    bitset512 bitset0 = {};
    bitset512 bitset1 = {};
    i32 bitsCount = sc_bits_count(bitset0);

    sc_bitset_set_1(bitset1.Mask, bitsCount, 64);
    sc_bitset_set_1(bitset1.Mask, bitsCount, 300);

    // DOCS: pBitset0 has all pBitset1 flags plus extra ones in different words.
    sc_bitset_set_1(bitset0.Mask, bitsCount, 64);
    sc_bitset_set_1(bitset0.Mask, bitsCount, 300);
    sc_bitset_set_1(bitset0.Mask, bitsCount, 0);
    sc_bitset_set_1(bitset0.Mask, bitsCount, 127);
    sc_bitset_set_1(bitset0.Mask, bitsCount, 511);

    sc_test_condition(sc_bitset_contains(bitset0.Mask, bitsCount, bitset1.Mask, bitsCount) == 1);

    // DOCS: pBitset1 bit from a higher word missing in pBitset0.
    sc_bitset_set_0(bitset0.Mask, bitsCount, 300);
    sc_test_condition(sc_bitset_contains(bitset0.Mask, bitsCount, bitset1.Mask, bitsCount) == 0);
}

void
sc_bitset_types_test()
{
    bitset64 b64 = {};
    bitset256 b256 = {};
    bitset512 b512 = {};
    bitset1024 b1024 = {};

    sc_test_i32_equal(sc_bits_count(b64), 64);
    sc_test_i32_equal(sc_bits_count(b256), 256);
    sc_test_i32_equal(sc_bits_count(b512), 512);
    sc_test_i32_equal(sc_bits_count(b1024), 1024);

    sc_bitset_set_1(b64.Mask0, sc_bits_count(b64), 63);
    sc_test_condition(sc_bitset_get(b64.Mask0, sc_bits_count(b64), 63) == 1);

    sc_bitset_set_1(b256.Mask, sc_bits_count(b256), 255);
    sc_test_condition(sc_bitset_get(b256.Mask, sc_bits_count(b256), 255) == 1);

    sc_bitset_set_1(b1024.Mask, sc_bits_count(b1024), 1023);
    sc_test_condition(sc_bitset_get(b1024.Mask, sc_bits_count(b1024), 1023) == 1);
}

void
sc_auto_bitset()
{
    sc_test_file();

    sc_test_func(sc_bitset_set_get_test());
    sc_test_func(sc_bitset_set_0_test());
    sc_test_func(sc_bitset_contains_test());
    sc_test_func(sc_bitset_contains_more_flags_test());
    sc_test_func(sc_bitset_types_test());
}
