#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>
#include <stdlib.h>

void
sc_directory_create_recursive_test()
{
    char* pRandTemp = sc_path_get_random_temp_ext(7, 17);
    sc_test_string_value(pRandTemp);

    ScResult scRes = sc_directory_create_recursive(pRandTemp);
    sc_test_condition(scRes == ScResult_Success);

    i32* pCheck = (i32*)malloc(sizeof(i32));
    *pCheck = 1337;
}

extern void
sc_auto_directory()
{
    sc_test_file();

    sc_test_func(sc_directory_create_recursive_test());
}
