#include <Sc/Math.h>
#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>
#include <string.h>

void
sc_int_to_string_test()
{
    char buf[64] = {};
    i64 len = sc_int_to_string(buf, 64, 12937);
    sc_test_i32_equal((i32)len, 5);
    sc_test_string_equals(buf, "12937");

    memset(buf, 0, sizeof(buf));
    len = sc_int_to_string(buf, 64, 0);
    sc_test_i32_equal((i32)len, 1);
    sc_test_string_equals(buf, "0");

    memset(buf, 0, sizeof(buf));
    len = sc_int_to_string(buf, 64, -123);
    sc_test_i32_equal((i32)len, 4);
    sc_test_string_equals(buf, "-123");
}

void
sc_float_to_string_test()
{
    char buf[64] = {};
    i64 len = sc_float_to_string_ext(buf, 64, 123.0, 0.01);
    sc_test_i32_equal((i32)len, 6);
    sc_test_string_equals(buf, "123.00");

    memset(buf, 0, sizeof(buf));
    len = sc_float_to_string_ext(buf, 64, 0.5, 0.01);
    sc_test_i32_equal((i32)len, 3);
    sc_test_string_equals(buf, "0.5");

    memset(buf, 0, sizeof(buf));
    len = sc_float_to_string(buf, 64, 3.5f);
    sc_test_i32_equal((i32)len, 3);
    sc_test_string_equals(buf, "3.5");
}

void
sc_v2_to_string_test()
{
    char buf[64] = {};
    i32 len = sc_v2_to_string(buf, 64, v2_new(1, 2), 0);
    sc_test_i32_equal(len, 10);
    sc_test_string_equals(buf, "{1.0, 2.0}");
}

void
sc_v3_to_string_test()
{
    char buf[64] = {};
    i32 len = sc_v3_to_string(buf, 64, v3_new(1, 2, 3), 0);
    sc_test_i32_equal(len, 15);
    sc_test_string_equals(buf, "{1.0, 2.0, 3.0}");
}

void
sc_v4_to_string_test()
{
    char buf[64] = {};
    i32 len = sc_v4_to_string(buf, 64, v4_new(1, 2, 3, 4), 0);
    sc_test_i32_equal(len, 20);
    sc_test_string_equals(buf, "{1.0, 2.0, 3.0, 4.0}");
}

void
sc_quat_to_string_test()
{
    char buf[64] = {};
    quat q = quat_new(0.0f, v3_new(0, 0, 1));
    i32 len = sc_quat_to_string(buf, 64, q, 0);
    sc_test_i32_equal(len, 20);
    sc_test_string_equals(buf, "{0.0, 0.0, 0.0, 1.0}");
}

void
sc_auto_to_string()
{
    sc_test_file();

    sc_test_func(sc_int_to_string_test());
    sc_test_func(sc_float_to_string_test());
    sc_test_func(sc_v2_to_string_test());
    sc_test_func(sc_v3_to_string_test());
    sc_test_func(sc_v4_to_string_test());
    sc_test_func(sc_quat_to_string_test());
}