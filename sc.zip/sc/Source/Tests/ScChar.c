#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_char_is_whitespace_test()
{
    sc_test_condition(sc_char_is_whitespace(' ') == 1);
    sc_test_condition(sc_char_is_whitespace('\n') == 1);
    sc_test_condition(sc_char_is_whitespace('\t') == 1);
    sc_test_condition(sc_char_is_whitespace('\v') == 1);
    sc_test_condition(sc_char_is_whitespace('\r') == 0);
    sc_test_condition(sc_char_is_whitespace('a') == 0);
    sc_test_condition(sc_char_is_whitespace('0') == 0);
    sc_test_condition(sc_char_is_whitespace('\0') == 0);
}

void
sc_char_is_upper_test()
{
    sc_test_condition(sc_char_is_upper('A') == 1);
    sc_test_condition(sc_char_is_upper('Z') == 1);
    sc_test_condition(sc_char_is_upper('M') == 1);
    sc_test_condition(sc_char_is_upper('a') == 0);
    sc_test_condition(sc_char_is_upper('0') == 0);
    sc_test_condition(sc_char_is_upper(' ') == 0);
}

void
sc_char_is_lower_test()
{
    sc_test_condition(sc_char_is_lower('a') == 1);
    sc_test_condition(sc_char_is_lower('z') == 1);
    sc_test_condition(sc_char_is_lower('m') == 1);
    sc_test_condition(sc_char_is_lower('A') == 0);
    sc_test_condition(sc_char_is_lower('0') == 0);
    sc_test_condition(sc_char_is_lower(' ') == 0);
}

void
sc_char_is_letter_test()
{
    sc_test_condition(sc_char_is_letter('a') == 1);
    sc_test_condition(sc_char_is_letter('z') == 1);
    sc_test_condition(sc_char_is_letter('A') == 1);
    sc_test_condition(sc_char_is_letter('Z') == 1);
    sc_test_condition(sc_char_is_letter('0') == 0);
    sc_test_condition(sc_char_is_letter('_') == 0);
    sc_test_condition(sc_char_is_letter(' ') == 0);
}

void
sc_char_is_integer_test()
{
    sc_test_condition(sc_char_is_integer('0') == 1);
    sc_test_condition(sc_char_is_integer('5') == 1);
    sc_test_condition(sc_char_is_integer('9') == 1);
    sc_test_condition(sc_char_is_integer('a') == 0);
    sc_test_condition(sc_char_is_integer(' ') == 0);
    sc_test_condition(sc_char_is_integer('.') == 0);
}

void
sc_char_to_upper_test()
{
    sc_test_condition(sc_char_to_upper('a') == 'A');
    sc_test_condition(sc_char_to_upper('z') == 'Z');
    sc_test_condition(sc_char_to_upper('m') == 'M');
    sc_test_condition(sc_char_to_upper('A') == 'A');
    sc_test_condition(sc_char_to_upper('0') == '0');
    sc_test_condition(sc_char_to_upper(' ') == ' ');
}

void
sc_char_to_lower_test()
{
    sc_test_condition(sc_char_to_lower('A') == 'a');
    sc_test_condition(sc_char_to_lower('Z') == 'z');
    sc_test_condition(sc_char_to_lower('M') == 'm');
    sc_test_condition(sc_char_to_lower('a') == 'a');
    sc_test_condition(sc_char_to_lower('0') == '0');
    sc_test_condition(sc_char_to_lower(' ') == ' ');
}

void
sc_auto_char()
{
    sc_test_file();

    sc_test_func(sc_char_is_whitespace_test());
    sc_test_func(sc_char_is_upper_test());
    sc_test_func(sc_char_is_lower_test());
    sc_test_func(sc_char_is_letter_test());
    sc_test_func(sc_char_is_integer_test());
    sc_test_func(sc_char_to_upper_test());
    sc_test_func(sc_char_to_lower_test());
}