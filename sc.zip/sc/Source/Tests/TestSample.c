#include <Sc/Types.h>
#include <stdio.h>

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include "ScAuto.h"
#include <Sc/Test.h>

extern void msk_auto();

void
demo_log_ext(const char* pOutFile, const char* pData, i64 dataLength)
{
    sc_file_append_string(pOutFile, (char*)pData, dataLength);
}
void
demo_log(const char* pOutFile, const char* pData)
{
    demo_log_ext(pOutFile, (char*)pData, sc_string_get_length((char*)pData));
}

i32
main()
{
    sc_log_init_default();
    sc_system_info_print();

#if 0
    i32 isEquals = sc_file_compare("/home/tdef/Big/programming/C/miracle/21:39:25 07.07.2026.bpe", "/home/tdef/Big/programming/C/miracle/21:24:36 07.07.2026.bpe");

    sc_log_info("File is equals %d\n", isEquals);
    return 0;
#elif 0
    ScProfiler scProf = {};
    sc_profiler_start(&scProf);
    ScAiBpe bpeLoaded = sc_ai_bpe_load_from_disk("/home/tdef/Ult/Ai/LLM Models/my/perf/1mb-1000m-22s-21:02:09 07.07.2026.bpe");
    sc_profiler_end(&scProf);
    ScAiBpeSaveToDiskConfig ddcfg = (ScAiBpeSaveToDiskConfig) {
        .pProfiler = &scProf,
        .Bpe = bpeLoaded,
        .TotalTextLength = 100,
        .TotalTextLengthCompressed = sc_list_count(bpeLoaded.aTokens),
        .pFilePath = "saved.bpe",
    };

    sc_ai_bpe_save_to_disk(ddcfg);

    return 0;

#endif

#if 0
    const i32 c_should_add_text = 0;
    const i32 c_should_add_tokens = 0;

    // char* pRuTest = "Привет мир!";
    // u8 b0 = (u8)pRuTest[0];
    // u8 b1 = (u8)pRuTest[1];
    // printf("bytes: %d %d\n", b0, b1);
    // return 0;

    ScDateTime dt = sc_date_time_now();
    const char* pTime = sc_date_time_to_string(dt);
    char buf[256] = {};
    snprintf(buf, 256, "%s.bpe", pTime);

    char* pPath = "/home/tdef/Ult/Ai/LLM Models/endata/TinyStories-train-13-mln.txt";
    // char* pPath = "/home/tdef/Ult/Ai/LLM Models/rudata/RussianNovels/corpus/total.txt";
    i64 fileLength = 0;
    char* pText = sc_file_read_ext(pPath, &fileLength);
    ScAiBpeConfig cfg = {
        .pText = pText,
        .TextLength = ScMb(1),
        .MergesCount = 1000
    };

    ScProfiler scprf = {};
    sc_profiler_start(&scprf);
    ScAiBpe bpe = sc_ai_bpe_new(cfg);
    sc_profiler_end(&scprf);

    i64 cnt = 0;
    sc_list_for_each(bpe.aTokens, pToken)
    {
        if (*pToken != -1337)
            ++cnt;
    }
    sc_ai_bpe_save_to_disk((ScAiBpeSaveToDiskConfig) {
        .Bpe = bpe,
        .pProfiler = (void*)&scprf,
        .TotalTextLength = cfg.TextLength,
        .TotalTextLengthCompressed = cnt,
        .pFilePath = buf,

    });
    return 0;

    f32 ratio = (i64)(((f32)cnt) / cfg.TextLength * 100);

    char sbuf[256] = {};
    snprintf(sbuf, 256, "# processing-time: %s\n# compression: %lld/%lld (%0.1f%%)\n", sc_profiler_get_string(&scprf), cnt, cfg.TextLength, 100 - ratio);
    demo_log(buf, sbuf);

    snprintf(sbuf, 256, "# corpus-size %lld\n# vocab-size %lld\n# merges-size %lld\n# tokens-size %lld\n\n", cfg.TextLength, sc_list_count(bpe.aVocab), sc_list_count(bpe.aMerges), cnt);
    demo_log(buf, sbuf);

    demo_log(buf, "# merges\n```\n");
    sc_list_for_each(bpe.aMerges, pMerge)
    {
        char mbuf[256] = {};
        snprintf(mbuf, 256, "%d %d %d\n", pMerge->T0, pMerge->T1, pMerge->Tf);
        demo_log(buf, mbuf);
    }
    demo_log(buf, "\n```\n# end merges\n");

    demo_log(buf, "# vocab\n```\n");
    sc_list_for_each(bpe.aVocab, pVocab)
    {
        char mbuf[256] = {};
        snprintf(mbuf, 256, "%s\n", pVocab->pValue);
        demo_log(buf, mbuf);
    }
    demo_log(buf, "\n```\n# end vocab\n");

    if (c_should_add_text)
    {
        demo_log(buf, "# text\n```\n");
        demo_log_ext(buf, cfg.pText, cfg.TextLength);
        demo_log(buf, "\n```\n# end text\n");
    }

    if (c_should_add_tokens)
    {
        demo_log(buf, "# tokens\n```\n");
        sc_list_for_each(bpe.aTokens, pTokens)
        {
            i32 token = *pTokens;
            if (token != -1337)
            {
                if (token == 259)
                {
                    demo_log(buf, "[EOS]\n");
                }
                else
                {
                    char mbuf[256] = {};
                    snprintf(mbuf, 256, "[%d]", token);
                    demo_log(buf, mbuf);
                }
            }
        }
        demo_log(buf, "\n```\n# end tokens\n");
    }
    return 0;
#endif

    sc_auto();

    char** aLongPrintFuncs = NULL;
    // sc_list_add(aLongPrintFuncs, "path_get_directory_test()");
    // sc_list_add(aLongPrintFuncs, "sc_list_add_multiple_test()");
    // sc_list_add(aLongPrintFuncs, "sc_grid_basic()");
    // sc_list_add(aLongPrintFuncs, "sc_directory_create_recursive_test()");
    // sc_list_add(aLongPrintFuncs, "sc_dict_grow_test()");

    sc_test_visualize(sc_test_get(), (ScTestVisualizeConfig) { .IsShort = 2, .aLongPrintFuncs = aLongPrintFuncs });

    return 0;
}
