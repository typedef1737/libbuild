#include "ScAuto.h"

extern void sc_auto_path();
extern void sc_auto_list();
extern void sc_auto_builder();
extern void sc_auto_format();
extern void sc_auto_grid();
extern void sc_auto_hash();
extern void sc_auto_crypt();
extern void sc_auto_directory();
extern void sc_auto_dict();
extern void sc_auto_string();
extern void sc_auto_utf8();
extern void sc_auto_ecs();
extern void sc_auto_bitset();
extern void sc_auto_parse();
extern void sc_auto_char();
extern void sc_auto_to_string();
extern void sc_auto_date_time();
extern void sc_auto_random();
extern void sc_auto_reflect();
extern void sc_auto_ai();
extern void sc_auto_qoa();
extern void sc_auto_raster();

// NOTE(Tests): sc_auto_font() временно исключён — ScFont.c зашивает
// linux-путь к шрифту. stb-зависимости больше не нужны (Text/Font.c и
// Text/TrueType.c нативные). Вернуть, когда путь станет параметром.

void
sc_auto()
{
    sc_auto_path();
    sc_auto_list();
    sc_auto_builder();
    sc_auto_format();
    sc_auto_grid();
    sc_auto_hash();
    sc_auto_crypt();
    sc_auto_directory();
    // NOTE(Tests): sc_auto_font() — см. комментарий выше.
    sc_auto_dict();
    sc_auto_string();
    sc_auto_utf8();
    sc_auto_ecs();
    sc_auto_bitset();
    sc_auto_parse();
    sc_auto_char();
    sc_auto_to_string();
    sc_auto_date_time();
    sc_auto_random();
    sc_auto_reflect();
    sc_auto_qoa();
    sc_auto_raster();
}
