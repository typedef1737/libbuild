#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_random_test()
{
    u64 first = sc_random();
    u64 distinctCount = 1;
    u64 aValues[16] = {};
    aValues[0] = first;

    for (i32 i = 1; i < 16; ++i)
    {
        u64 value = sc_random();
        aValues[i] = value;

        i32 isDistinct = 1;
        for (i32 j = 0; j < i; ++j)
        {
            if (aValues[j] == value)
            {
                isDistinct = 0;
                break;
            }
        }

        if (isDistinct)
            ++distinctCount;
    }

    sc_test_condition(distinctCount >= 2);
}

void
sc_random_ext_test()
{
    u64 first = sc_random_ext(0);
    u64 second = sc_random_ext(0);
    sc_test_condition(first != second || first != 0);
}

void
sc_auto_random()
{
    sc_test_file();

    sc_test_func(sc_random_test());
    sc_test_func(sc_random_ext_test());
}