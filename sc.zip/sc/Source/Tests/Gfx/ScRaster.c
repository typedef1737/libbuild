#include <Sc/Gfx/Raster.h>
#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

// NOTE(Tests): Raster тестируется полностью headless - окно не нужно.
// Оконный smoke (create/swap/destroy) требует дисплея, здесь только
// CPU-часть.

/*
  DOCS: Доступ к пикселю в памяти растра. API растра - Y-вверх
  (y = 0 - нижняя строка), а физически строки лежат сверху вниз:
  строка в памяти = Height - 1 - y.
*/
#define SC_TEST_PIXEL(aPixels, width, height, x, y) \
    ((aPixels)[((height) - 1 - (y)) * (width) + (x)])

void
sc_raster_init_test()
{
    ScRaster raster = {};
    ScResult res = sc_raster_init(&raster, 64, 48, 128, 96);
    sc_test_condition(res == ScResult_Success);
    sc_test_i32_equal(raster.Width, 64);
    sc_test_i32_equal(raster.Height, 48);
    sc_test_i32_equal(raster.MaxWidth, 128);
    sc_test_i32_equal(raster.MaxHeight, 96);
    sc_test_i32_equal(raster.BuffersCount, 2);
    sc_test_i32_equal(raster.BufferCurrent, 0);
    sc_test_condition(raster.aBuffers[0].pData != ScNull);
    sc_test_condition(raster.aBuffers[1].pData != ScNull);
    sc_test_condition(raster.aBuffers[0].pData != raster.aBuffers[1].pData);

    ScRasterBuffer buf = sc_raster_get_buffer(&raster);
    sc_test_i32_equal(buf.Width, 64);
    sc_test_i32_equal(buf.Height, 48);

    sc_raster_free(&raster);
}

void
sc_raster_init__invalid_args_test()
{
    ScRaster raster = {};

    ScResult res = sc_raster_init(&raster, 0, 48, 128, 96);
    sc_test_condition(res == ScResult_Error);

    res = sc_raster_init(&raster, 64, 0, 128, 96);
    sc_test_condition(res == ScResult_Error);

    res = sc_raster_init(&raster, -1, -1, 128, 96);
    sc_test_condition(res == ScResult_Error);
}

void
sc_raster_init__no_max_test()
{
    /* maxWidth/maxHeight = 0: без запаса, берётся текущий размер */
    ScRaster raster = {};
    ScResult res = sc_raster_init(&raster, 32, 16, 0, 0);
    sc_test_condition(res == ScResult_Success);
    sc_test_i32_equal(raster.MaxWidth, 32);
    sc_test_i32_equal(raster.MaxHeight, 16);

    sc_raster_free(&raster);
}

void
sc_raster_set_pixel_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 16, 16, 0, 0);
    ScRasterBuffer buf = sc_raster_get_buffer(&raster);

    u32* aPixels = (u32*)buf.pData;

    /* обычная запись */
    sc_raster_clear_color(&raster, 0);
    sc_raster_set_pixel(buf, 3, 5, 0xFF00FF00);
    sc_test_i32_equal((i32)SC_TEST_PIXEL(aPixels, 16, 16, 3, 5), (i32)0xFF00FF00);

    /* углы буфера */
    sc_raster_set_pixel(buf, 0, 0, 1);
    sc_test_i32_equal((i32)SC_TEST_PIXEL(aPixels, 16, 16, 0, 0), 1);
    sc_raster_set_pixel(buf, 15, 15, 2);
    sc_test_i32_equal((i32)SC_TEST_PIXEL(aPixels, 16, 16, 15, 15), 2);

    /* соседние пиксели не задеты */
    sc_test_condition(SC_TEST_PIXEL(aPixels, 16, 16, 2, 5) == 0);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 16, 16, 4, 5) == 0);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 16, 16, 3, 4) == 0);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 16, 16, 3, 6) == 0);

    /* клиппинг всех границ: за буфером - игнор, no crash */
    sc_raster_set_pixel(buf, -1, 0, 0xFFFFFFFF);
    sc_raster_set_pixel(buf, 0, -1, 0xFFFFFFFF);
    sc_raster_set_pixel(buf, 16, 0, 0xFFFFFFFF);
    sc_raster_set_pixel(buf, 0, 16, 0xFFFFFFFF);
    sc_raster_set_pixel(buf, 1000, 1000, 0xFFFFFFFF);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 16, 16, 0, 0) == 1);   /* не перезаписан */
    sc_test_condition(SC_TEST_PIXEL(aPixels, 16, 16, 15, 15) == 2);

    sc_raster_free(&raster);
}

void
sc_raster_clear_color_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 20, 10, 0, 0);

    sc_raster_clear_color(&raster, 0xAABBCCDD);

    ScRasterBuffer buf = sc_raster_get_buffer(&raster);
    u32* aPixels = (u32*)buf.pData;
    i64 count = (i64)buf.Width * buf.Height;

    i32 allEquals = 1;
    for (i64 i = 0; i < count; ++i)
    {
        if (aPixels[i] != 0xAABBCCDD)
        {
            allEquals = 0;
            break;
        }
    }
    sc_test_condition(allEquals);

    sc_raster_free(&raster);
}

void
sc_raster_draw_line_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 32, 32, 0, 0);

    u32 lineColor = 0xFFFFFFFF;

    /* горизонталь */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_line(&raster, 4, 10, 12, 10, lineColor);
    {
        ScRasterBuffer buf = sc_raster_get_buffer(&raster);
        u32* aPixels = (u32*)buf.pData;
        i32 allSet = 1;
        for (i32 x = 4; x <= 12; ++x)
        {
            if (SC_TEST_PIXEL(aPixels, 32, 32, x, 10) != lineColor)
            {
                allSet = 0;
                break;
            }
        }
        sc_test_condition(allSet);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 3, 10) == 0);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 13, 10) == 0);
    }

    /* вертикаль */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_line(&raster, 7, 2, 7, 20, lineColor);
    {
        ScRasterBuffer buf = sc_raster_get_buffer(&raster);
        u32* aPixels = (u32*)buf.pData;
        i32 allSet = 1;
        for (i32 y = 2; y <= 20; ++y)
        {
            if (SC_TEST_PIXEL(aPixels, 32, 32, 7, y) != lineColor)
            {
                allSet = 0;
                break;
            }
        }
        sc_test_condition(allSet);
    }

    /* диагональ */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_line(&raster, 0, 0, 31, 31, lineColor);
    {
        ScRasterBuffer buf = sc_raster_get_buffer(&raster);
        u32* aPixels = (u32*)buf.pData;
        i32 allSet = 1;
        for (i32 i = 0; i < 32; ++i)
        {
            if (SC_TEST_PIXEL(aPixels, 32, 32, i, i) != lineColor)
            {
                allSet = 0;
                break;
            }
        }
        sc_test_condition(allSet);
    }

    /* точка (нулевая длина) */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_line(&raster, 5, 6, 5, 6, lineColor);
    {
        ScRasterBuffer buf = sc_raster_get_buffer(&raster);
        u32* aPixels = (u32*)buf.pData;
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 5, 6) == lineColor);
    }

    /* обратное направление: те же концы, связная линия
       (классический Брезенхэм не обязан давать пиксель-в-пиксель
       симметрию при реверсе - диагональный шаг зеркалится) */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_line(&raster, 20, 10, 0, 0, lineColor);
    {
        ScRasterBuffer buf = sc_raster_get_buffer(&raster);
        u32* aPixels = (u32*)buf.pData;
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 20, 10) == lineColor); /* конец 1 */
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 0, 0) == lineColor);    /* конец 2 */

        /* связность: в каждой колонке 0..20 есть хотя бы один пиксель */
        i32 allColumnsCovered = 1;
        for (i32 x = 0; x <= 20; ++x)
        {
            i32 hasPixel = 0;
            for (i32 y = 0; y <= 10; ++y)
            {
                if (SC_TEST_PIXEL(aPixels, 32, 32, x, y) == lineColor)
                {
                    hasPixel = 1;
                    break;
                }
            }
            if (!hasPixel)
            {
                allColumnsCovered = 0;
                break;
            }
        }
        sc_test_condition(allColumnsCovered);
    }

    /* за границами буфера: no crash, ничего внутри не затёрто */
    sc_raster_draw_line(&raster, -10, -10, 5, 5, lineColor);
    sc_raster_draw_line(&raster, 0, 0, 100, 100, lineColor);
    sc_test_condition(1);

    sc_raster_free(&raster);
}

void
sc_raster_swap_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 8, 8, 0, 0);

    /* рисуем маркер в активный (0-й) буфер */
    ScRasterBuffer active = sc_raster_get_buffer(&raster);
    sc_raster_set_pixel(active, 1, 1, 0xAB);

    /* swap: возвращает законченный буфер (с маркером) */
    ScRasterBuffer finished = sc_raster_swap(&raster);
    sc_test_condition(finished.pData == active.pData);
    u32* aPixels = (u32*)finished.pData;
    sc_test_condition(SC_TEST_PIXEL(aPixels, 8, 8, 1, 1) == 0xAB);

    /* активным стал другой буфер */
    ScRasterBuffer next = sc_raster_get_buffer(&raster);
    sc_test_condition(next.pData != finished.pData);
    sc_test_i32_equal(raster.BufferCurrent, 1);

    /* второй swap: возвращаемся к первому */
    finished = sc_raster_swap(&raster);
    sc_test_condition(finished.pData == next.pData);
    sc_test_i32_equal(raster.BufferCurrent, 0);

    sc_raster_free(&raster);
}

void
sc_raster_resize_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 10, 10, 50, 50);

    void* pBefore0 = raster.aBuffers[0].pData;
    void* pBefore1 = raster.aBuffers[1].pData;

    sc_raster_resize(&raster, 30, 40);
    sc_test_i32_equal(raster.Width, 30);
    sc_test_i32_equal(raster.Height, 40);
    sc_test_i32_equal(raster.aBuffers[0].Width, 30);
    sc_test_i32_equal(raster.aBuffers[0].Height, 40);
    sc_test_i32_equal(raster.aBuffers[1].Width, 30);
    sc_test_i32_equal(raster.aBuffers[1].Height, 40);

    /* память не тронута: обе аллокации на MaxSize */
    sc_test_condition(raster.aBuffers[0].pData == pBefore0);
    sc_test_condition(raster.aBuffers[1].pData == pBefore1);

    /* больше Max - обрезается */
    sc_raster_resize(&raster, 1000, 1000);
    sc_test_i32_equal(raster.Width, 50);
    sc_test_i32_equal(raster.Height, 50);

    /* невалидные размеры игнорируются */
    sc_raster_resize(&raster, 0, 0);
    sc_test_i32_equal(raster.Width, 50);
    sc_test_i32_equal(raster.Height, 50);

    sc_raster_free(&raster);
}

void
sc_raster_fill_rect_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 32, 32, 0, 0);

    u32* aPixels = (u32*)sc_raster_get_buffer(&raster).pData;
    u32 color = 0xFF00FF00;

    /* обычная заливка 4x3 в (2,5) */
    sc_raster_clear_color(&raster, 0);
    sc_raster_fill_rect(&raster, 2, 5, 4, 3, color);
    {
        i32 allSet = 1;
        for (i32 y = 5; y < 8; ++y)
            for (i32 x = 2; x < 6; ++x)
                if (SC_TEST_PIXEL(aPixels, 32, 32, x, y) != color)
                    allSet = 0;
        sc_test_condition(allSet);

        /* соседние пиксели не задеты */
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 1, 5) == 0);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 2, 8) == 0);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 6, 5) == 0);
    }

    /* клиппинг: частично за буфером */
    sc_raster_clear_color(&raster, 0);
    sc_raster_fill_rect(&raster, 30, 30, 10, 10, color);
    {
        /* видимая часть: (30..31, 30..31) */
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 30, 30) == color);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 31, 31) == color);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 29, 29) == 0);
    }

    /* клиппинг: полностью за буфером / невалидный размер - no crash */
    sc_raster_fill_rect(&raster, -10, -10, 5, 5, color);
    sc_raster_fill_rect(&raster, 0, 0, 0, 5, color);
    sc_raster_fill_rect(&raster, 0, 0, 5, -1, color);
    sc_test_condition(1);

    /* весь буфер */
    sc_raster_clear_color(&raster, 0);
    sc_raster_fill_rect(&raster, 0, 0, 32, 32, color);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 0, 0) == color);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 31, 31) == color);

    sc_raster_free(&raster);
}

void
sc_raster_draw_rect_test()
{
    ScRaster raster = {};
    sc_raster_init(&raster, 32, 32, 0, 0);

    u32* aPixels = (u32*)sc_raster_get_buffer(&raster).pData;
    u32 color = 0xFFFF0000;

    /* контур 6x4 в (3,6): рамка есть, центр пустой */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_rect(&raster, 3, 6, 6, 4, color);
    {
        /* углы */
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 3, 6) == color);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 8, 6) == color);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 3, 9) == color);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 8, 9) == color);

        /* стороны: низ/верх полные (y = 6 - низ, y = 9 - верх) */
        i32 bottomSet = 1, topSet = 1;
        for (i32 x = 3; x <= 8; ++x)
        {
            if (SC_TEST_PIXEL(aPixels, 32, 32, x, 6) != color)
                bottomSet = 0;
            if (SC_TEST_PIXEL(aPixels, 32, 32, x, 9) != color)
                topSet = 0;
        }
        sc_test_condition(bottomSet);
        sc_test_condition(topSet);

        /* лево/право полные */
        i32 leftSet = 1, rightSet = 1;
        for (i32 y = 6; y <= 9; ++y)
        {
            if (SC_TEST_PIXEL(aPixels, 32, 32, 3, y) != color)
                leftSet = 0;
            if (SC_TEST_PIXEL(aPixels, 32, 32, 8, y) != color)
                rightSet = 0;
        }
        sc_test_condition(leftSet);
        sc_test_condition(rightSet);

        /* центр пустой */
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 5, 7) == 0);
        sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 6, 8) == 0);
    }

    /* 1x1: единственный пиксель */
    sc_raster_clear_color(&raster, 0);
    sc_raster_draw_rect(&raster, 10, 10, 1, 1, color);
    sc_test_condition(SC_TEST_PIXEL(aPixels, 32, 32, 10, 10) == color);

    /* за границами / невалидный размер - no crash */
    sc_raster_draw_rect(&raster, -5, -5, 3, 3, color);
    sc_raster_draw_rect(&raster, 30, 30, 100, 100, color);
    sc_raster_draw_rect(&raster, 0, 0, 0, 0, color);
    sc_test_condition(1);

    sc_raster_free(&raster);
}

void
sc_auto_raster()
{
    sc_test_file();

    sc_test_func(sc_raster_init_test());
    sc_test_func(sc_raster_init__invalid_args_test());
    sc_test_func(sc_raster_init__no_max_test());
    sc_test_func(sc_raster_set_pixel_test());
    sc_test_func(sc_raster_clear_color_test());
    sc_test_func(sc_raster_draw_line_test());
    sc_test_func(sc_raster_fill_rect_test());
    sc_test_func(sc_raster_draw_rect_test());
    sc_test_func(sc_raster_swap_test());
    sc_test_func(sc_raster_resize_test());
}
