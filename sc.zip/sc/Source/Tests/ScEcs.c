#include <Sc/Ecs.h>
#include <Sc/Math.h>
#include <Sc/Test.h>

typedef struct
{
    i32 A;
    i32 B;
} CmpAB;

typedef struct
{
    i32 A;
    i32 B;
    i32 C;
} CmpABC;

// DOCS: 3D object position, rotation and scale
typedef struct
{
    v3 Position;
    v3 Scale;
    quat Rotation;
} Pozy;

static i32
pozy_equal(Pozy p0, Pozy p1)
{
    i32 isPosition = v3_equal(p0.Position, p1.Position);
    i32 isScale = v3_equal(p0.Scale, p1.Scale);
    i32 isQuat = quat_equal(p0.Rotation, p1.Rotation);
    return isPosition && isScale && isQuat;
}

static i32
cmpab_equal(CmpAB c0, CmpAB c1)
{
    return (c0.A == c1.A) && (c0.B == c1.B);
}

void
sc_ecs_base()
{
    // DOCS: Validation data
    Pozy v_aPozies[] = {
        (Pozy) { v3_new(1, 2, 3), v3_new(1, 1, 1), quat_new(0, v3_new(0, 0, 1)) },
        (Pozy) { v3_new(3, 2, 1), v3_new(2, 2, 2), quat_new(0, v3_new(0, 0, 1)) }
    };
    i64 v_PoziesCount = ScArrayCount(v_aPozies);

    sc_ecs_world_create();

    sc_ecs_world_register_component(Pozy);
    sc_ecs_world_register_component(CmpAB);
    sc_ecs_world_register_component(CmpABC);

    ScEcsEntityId entity = sc_ecs_entity_new();
    sc_ecs_entity_set(entity, Pozy, (Pozy) { v3_new(1, 2, 3), v3_new(1, 1, 1), quat_new(0, v3_new(0, 0, 1)) });
    sc_ecs_entity_set(entity, CmpAB, (CmpAB) { 1, 2 });

    ScEcsEntityId entity0 = sc_ecs_entity_new();
    sc_ecs_entity_set(entity0, Pozy, (Pozy) { v3_new(3, 2, 1), v3_new(2, 2, 2), quat_new(0, v3_new(0, 0, 1)) });
    sc_ecs_entity_set(entity0, CmpABC, (CmpABC) { 3, 4, 5 });

    Pozy* aPozies = sc_ecs_world_get_all_component_data(Pozy);
    sc_test_i32_equal(sc_list_count(aPozies), v_PoziesCount);

    if (sc_list_count(aPozies) == v_PoziesCount)
    {
        for (i32 p = 0; p < v_PoziesCount; ++p)
        {
            sc_test_condition(pozy_equal(aPozies[p], v_aPozies[p]));
        }
    }

    void* pAllComponents = sc_ecs_world_get_all_components_ext("Pozy");
    sc_test_condition(pAllComponents == (void*)aPozies);

    {
        Pozy* pPozy = sc_ecs_entity_get(entity, Pozy);
        sc_test_v3_equal(pPozy->Position, v3_new(1, 2, 3));
        sc_test_v3_equal(pPozy->Scale, v3_new(1, 1, 1));
        sc_test_quat_equal(pPozy->Rotation, quat_new(0, v3_new(0, 0, 1)));
    }
    {
        Pozy* pPozy = sc_ecs_entity_get(entity0, Pozy);
        sc_test_v3_equal(pPozy->Position, v3_new(3, 2, 1));
        sc_test_v3_equal(pPozy->Scale, v3_new(2, 2, 2));
        sc_test_quat_equal(pPozy->Rotation, quat_new(0, v3_new(0, 0, 1)));
    }

    sc_test_condition(sc_ecs_entity_has(entity, Pozy) == 1);
    sc_test_condition(sc_ecs_entity_has(entity, CmpABC) == 0);
    sc_test_condition(sc_ecs_entity_has(entity0, CmpABC) == 1);

    sc_ecs_world_destroy();
}

void
sc_ecs_entity_set_update_test()
{
    sc_ecs_world_create();

    sc_ecs_world_register_component(CmpAB);

    ScEcsEntityId entity = sc_ecs_entity_new();
    sc_ecs_entity_set(entity, CmpAB, (CmpAB) { 1, 2 });

    // DOCS: Setting same component again updates data in place, count stays 1.
    i32 isSet = sc_ecs_entity_set(entity, CmpAB, (CmpAB) { 7, 8 });
    sc_test_condition(isSet == 1);

    CmpAB* pCmp = sc_ecs_entity_get(entity, CmpAB);
    sc_test_condition(cmpab_equal(*pCmp, (CmpAB) { 7, 8 }));

    CmpAB* aCmp = sc_ecs_world_get_all_component_data(CmpAB);
    sc_test_i32_equal(sc_list_count(aCmp), 1);

    sc_ecs_world_destroy();
}

void
sc_ecs_entity_remove_component_test()
{
    sc_ecs_world_create();

    sc_ecs_world_register_component(CmpAB);
    sc_ecs_world_register_component(CmpABC);

    ScEcsEntityId entity = sc_ecs_entity_new();
    sc_ecs_entity_set(entity, CmpAB, (CmpAB) { 1, 2 });
    sc_ecs_entity_set(entity, CmpABC, (CmpABC) { 3, 4, 5 });

    sc_test_condition(sc_ecs_entity_has(entity, CmpAB) == 1);

    i32 isRemoved = sc_ecs_entity_remove_component(entity, CmpAB);
    sc_test_condition(isRemoved == 1);
    sc_test_condition(sc_ecs_entity_has(entity, CmpAB) == 0);

    // DOCS: Removing already removed component should fail.
    isRemoved = sc_ecs_entity_remove_component(entity, CmpAB);
    sc_test_condition(isRemoved == 0);

    // DOCS: Setting again should reuse freed offset, data count stays 1.
    i32 isSet = sc_ecs_entity_set(entity, CmpAB, (CmpAB) { 9, 10 });
    sc_test_condition(isSet == 1);

    CmpAB* pCmp = sc_ecs_entity_get(entity, CmpAB);
    sc_test_condition(cmpab_equal(*pCmp, (CmpAB) { 9, 10 }));

    CmpAB* aCmp = sc_ecs_world_get_all_component_data(CmpAB);
    sc_test_i32_equal(sc_list_count(aCmp), 1);

    sc_ecs_world_destroy();
}

void
sc_ecs_entity_destroy_test()
{
    sc_ecs_world_create();

    sc_ecs_world_register_component(CmpAB);

    ScEcsEntityId entity0 = sc_ecs_entity_new();
    ScEcsEntityId entity1 = sc_ecs_entity_new();
    sc_ecs_entity_set(entity0, CmpAB, (CmpAB) { 1, 2 });
    sc_ecs_entity_set(entity1, CmpAB, (CmpAB) { 3, 4 });

    ScEcsEntityId* aEntities = sc_ecs_get_all_entity_ids(CmpAB);
    sc_test_i32_equal(sc_list_count(aEntities), 2);
    sc_list_free(aEntities);

    sc_ecs_entity_destroy(entity0);

    // DOCS: Dead entity should not match the filter.
    aEntities = sc_ecs_get_all_entity_ids(CmpAB);
    sc_test_i32_equal(sc_list_count(aEntities), 1);
    if (sc_list_count(aEntities) == 1)
    {
        sc_test_condition(aEntities[0] == entity1);
    }
    sc_list_free(aEntities);

    // DOCS: Operations on destroyed entity should fail.
    sc_test_condition(sc_ecs_entity_has(entity0, CmpAB) == 0);
    sc_test_condition(sc_ecs_entity_get(entity0, CmpAB) == NULL);
    i32 isSet = sc_ecs_entity_set(entity0, CmpAB, (CmpAB) { 5, 6 });
    sc_test_condition(isSet == 0);

    // DOCS: Destroying already destroyed entity is a no-op.
    sc_ecs_entity_destroy(entity0);

    sc_ecs_world_destroy();
}

void
sc_ecs_component_name_id_test()
{
    sc_ecs_world_create();

    sc_ecs_world_register_component(CmpAB);
    sc_ecs_world_register_component(CmpABC);

    ScEcsComponentId abId = sc_ecs_component_name_to_id("CmpAB");
    sc_test_condition(abId == ScEcsComponentBeginId);
    ScEcsComponentId abcId = sc_ecs_component_name_to_id("CmpABC");
    sc_test_condition(abcId == ScEcsComponentBeginId + 1);

    const char* pName = sc_ecs_component_id_to_name(abId);
    sc_test_string_equals(pName, "CmpAB");

    sc_test_condition(sc_ecs_component_name_to_id("NotRegistered") == ScEcsInvalidId);
    sc_test_condition(sc_ecs_component_id_to_name(ScEcsInvalidId) == NULL);
    sc_test_condition(sc_ecs_component_name_to_id(NULL) == ScEcsInvalidId);

    sc_ecs_world_destroy();
}

void
sc_auto_ecs()
{
    sc_test_file();

    sc_test_func(sc_ecs_base());
    sc_test_func(sc_ecs_entity_set_update_test());
    sc_test_func(sc_ecs_entity_remove_component_test());
    sc_test_func(sc_ecs_entity_destroy_test());
    sc_test_func(sc_ecs_component_name_id_test());
}
