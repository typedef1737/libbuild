#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_path_combine_test()
{
    char* pCombined = sc_path_combine("/home/dir", "file.c");
    sc_test_string_equals(pCombined, "/home/dir/file.c");
    sc_test_condition(sc_string_get_length(pCombined) == 16);
    sc_test_condition(pCombined[16] == 0);
}

void
sc_path_combine__weird_test()
{
    char* pCombined = sc_path_combine("/home/dir", ".");
    sc_test_string_equals(pCombined, "/home/dir");
    sc_test_string_value(pCombined);
    sc_test_condition(sc_string_get_length(pCombined) == 9);
    sc_test_condition(pCombined[9] == 0);
}

void
sc_path_get_directory_test()
{
    char* pDir = sc_path_get_directory("/home/dir/subdir/file.c");
    sc_test_string_equals(pDir, "/home/dir/subdir");
}

void
sc_path_get_name_wo_extension_test()
{
    char* pNameWoExt = sc_path_get_name_wo_extension("/home/dir/subdir/file_wo_ext.c");
    sc_test_string_equals(pNameWoExt, "file_wo_ext");
    sc_test_condition(pNameWoExt[11] == 0);
}

void
sc_path_get_name_test()
{
    char* pName = sc_path_get_name_wo_alloc("/home/dir/subdir/file_wo_alloc.c");
    sc_test_string_equals(pName, "file_wo_alloc.c");
}

extern void
sc_auto_path()
{
    sc_test_file();

    sc_test_func(sc_path_combine_test());
    sc_test_func(sc_path_combine__weird_test());
    sc_test_func(sc_path_get_directory_test());
    sc_test_func(sc_path_get_name_wo_extension_test());
    sc_test_func(sc_path_get_name_test());
}
