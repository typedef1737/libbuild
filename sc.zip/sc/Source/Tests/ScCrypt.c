#include <Sc/Data/Crypt.h>
#include <Sc/Sc.h>
#include <Sc/Test.h>

#include <string.h>

/*
 Векторы получены вызовом эталонной реализации BLAKE3:
 blake3_hasher_init, blake3_hasher_init_keyed,
 blake3_hasher_init_derive_key и blake3_hasher_finalize
 из BLAKE3-master/c (release-windows, clang).
 Вход: byte[i] = (u8)(i % 251).
 Key: "whats the Elvish word for friend".
 Context: "BLAKE3 2019-12-27 16:29:52 test vectors context".
*/

typedef struct
{
    u64 Length;
    const char* pHash;
    const char* pKeyed;
    const char* pDerive;
} ScCryptVector;

static const char* c_key = "whats the Elvish word for friend";
static const char* c_context = "BLAKE3 2019-12-27 16:29:52 test vectors context";

static const ScCryptVector c_vectors[] = {
    { 0, "af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262", "92b2b75604ed3c761f9d6f62392c8a9227ad0ea3f09573e783f1498a4ed60d26", "2cc39783c223154fea8dfb7c1b1660f2ac2dcbd1c1de8277b0b0dd39b7e50d7d" },
    { 1, "2d3adedff11b61f14c886e35afa036736dcd87a74d27b5c1510225d0f592e213", "6d7878dfff2f485635d39013278ae14f1454b8c0a3a2d34bc1ab38228a80c95b", "b3e2e340a117a499c6cf2398a19ee0d29cca2bb7404c73063382693bf66cb06c" },
    { 2, "7b7015bb92cf0b318037702a6cdd81dee41224f734684c2c122cd6359cb1ee63", "5392ddae0e0a69d5f40160462cbd9bd889375082ff224ac9c758802b7a6fd20a", "1f166565a7df0098ee65922d7fea425fb18b9943f19d6161e2d17939356168e6" },
    { 3, "e1be4d7a8ab5560aa4199eea339849ba8e293d55ca0a81006726d184519e647f", "39e67b76b5a007d4921969779fe666da67b5213b096084ab674742f0d5ec62b9", "440aba35cb006b61fc17c0529255de438efc06a8c9ebf3f2ddac3b5a86705797" },
    { 4, "f30f5ab28fe047904037f77b6da4fea1e27241c5d132638d8bedce9d40494f32", "7671dde590c95d5ac9616651ff5aa0a27bee5913a348e053b8aa9108917fe070", "f46085c8190d69022369ce1a18880e9b369c135eb93f3c63550d3e7630e91060" },
    { 7, "3f8770f387faad08faa9d8414e9f449ac68e6ff0417f673f602a646a891419fe", "af0a7ec382aedc0cfd626e49e7628bc7a353a4cb108855541a5651bf64fbb28a", "dc3b6485f9d94935329442916b0d059685ba815a1fa2a14107217453a7fc9f0e" },
    { 8, "2351207d04fc16ade43ccab08600939c7c1fa70a5c0aaca76063d04c3228eaeb", "be2f5495c61cba1bb348a34948c004045e3bd4dae8f0fe82bf44d0da245a0600", "2b166978cef14d9d438046c720519d8b1cad707e199746f1562d0c87fbd32940" },
    { 15, "163475fc98871015d19097d29536653bdeac6a9c3a18ad4b3a629cfaa1bbf32e", "e9b508261287d4eda665e73067b9db7ca0a0e4183ccfe6a27013a9403ddaf590", "0f5db63279719f941fa1443a16b0f20994cba6f5703e85b77e4be99ebd5fb93f" },
    { 16, "a6a492965517a830cb75fdb713465aa465f2f098233896fea44c1d98268bf9e3", "ebf2f6371efa50708aa47be314c8def04edb32f3b937385fae13163ac2f1266d", "2e1ad92496a1b229d732e18e74f5474bdfb92dc90736ed19bb9960fc27d962ca" },
    { 31, "bda80c7fe2db38be6387b35c870bd7728d67b7b6cc5eb9b0e5c7dcb21ea754c2", "f2a25a28508f949efb1f003f44835be683c0a7b203bde0918224fa4ab5e3a37b", "501ef2c6cc5c9c541f52fd320e5312c8b198dfe07fa94c13e69ab626af498c35" },
    { 32, "e528e95798037df410543d9f31e396ecdd458d71b157d6014398bae32fb56c65", "5c839dfe62acb270bf88d25872f144a81d2291b5fa5780b01ac7495e91511bd5", "3a3811745f2befb9405149346551dada955d268929e5d9111fa86c3d505526cd" },
    { 33, "4f4e6c1dffd3a6c9959876d15aa96b5fb0da8632b995f6ca2e30503f2829fa29", "252573d0542352f56b8d764f7541700c11dd0b735f93f93bec1cf6d8ec12439e", "e3dbf5f95f462687481de1747ccea4949ee253bceace7089a86acfb660b2355f" },
    { 63, "e9bc37a594daad83be9470df7f7b3798297c3d834ce80ba85d6e207627b7db7b", "bb1eb5d4afa793c1ebdd9fb08def6c36d10096986ae0cfe148cd101170ce37ae", "b6451e30b953c206e34644c6803724e9d2725e0893039cfc49584f991f451af3" },
    { 64, "4eed7141ea4a5cd4b788606bd23f46e212af9cacebacdc7d1f4c6dc7f2511b98", "ba8ced36f327700d213f120b1a207a3b8c04330528586f414d09f2f7d9ccb7e6", "a5c4a7053fa86b64746d4bb688d06ad1f02a18fce9afd3e818fefaa7126bf73e" },
    { 65, "de1e5fa0be70df6d2be8fffd0e99ceaa8eb6e8c93a63f2d8d1c30ecb6b263dee", "c0a4edefa2d2accb9277c371ac12fcdbb52988a86edc54f0716e1591b4326e72", "51fd05c3c1cfbc8ed67d139ad76f5cf8236cd2acd26627a30c104dfd9d3ff8a8" },
    { 127, "d81293fda863f008c09e92fc382a81f5a0b4a1251cba1634016a0f86a6bd640d", "c64200ae7dfaf35577ac5a9521c47863fb71514a3bcad18819218b818de85818", "c91c090ceee3a3ac81902da31838012625bbcd73fcb92e7d7e56f78deba4f0c3" },
    { 128, "f17e570564b26578c33bb7f44643f539624b05df1a76c81f30acd548c44b45ef", "b04fe15577457267ff3b6f3c947d93be581e7e3a4b018679125eaf86f6a628ec", "81720f34452f58a0120a58b6b4608384b5c51d11f39ce97161a0c0e442ca0225" },
    { 129, "683aaae9f3c5ba37eaaf072aed0f9e30bac0865137bae68b1fde4ca2aebdcb12", "d4a64dae6cdccbac1e5287f54f17c5f985105457c1a2ec1878ebd4b57e20d38f", "938d2d4435be30eafdbb2b7031f7857c98b04881227391dc40db3c7b21f41fc1" },
    { 1023, "10108970eeda3eb932baac1428c7a2163b0e924c9a9e25b35bba72b28f70bd11", "c951ecdf03288d0fcc96ee3413563d8a6d3589547f2c2fb36d9786470f1b9d6e", "74a16c1c3d44368a86e1ca6df64be6a2f64cce8f09220787450722d85725dea5" },
    { 1024, "42214739f095a406f3fc83deb889744ac00df831c10daa55189b5d121c855af7", "75c46f6f3d9eb4f55ecaaee480db732e6c2105546f1e675003687c31719c7ba4", "7356cd7720d5b66b6d0697eb3177d9f8d73a4a5c5e968896eb6a689684302706" },
    { 1025, "d00278ae47eb27b34faecf67b4fe263f82d5412916c1ffd97c8cb7fb814b8444", "357dc55de0c7e382c900fd6e320acc04146be01db6a8ce7210b7189bd664ea69", "effaa245f065fbf82ac186839a249707c3bddf6d3fdda22d1b95a3c970379bcb" },
    { 2048, "e776b6028c7cd22a4d0ba182a8bf62205d2ef576467e838ed6f2529b85fba24a", "879cf1fa2ea0e79126cb1063617a05b6ad9d0b696d0d757cf053439f60a99dd1", "7b2945cb4fef70885cc5d78a87bf6f6207dd901ff239201351ffac04e1088a23" },
    { 3072, "b98cb0ff3623be03326b373de6b9095218513e64f1ee2edd2525c7ad1e5cffd2", "044a0e7b172a312dc02a4c9a818c036ffa2776368d7f528268d2e6b5df191770", "050df97f8c2ead654d9bb3ab8c9178edcd902a32f8495949feadcc1e0480c46b" },
    { 8192, "aae792484c8efe4f19e2ca7d371d8c467ffb10748d8a5a1ae579948f718a2a63", "dc9637c8845a770b4cbf76b8daec0eebf7dc2eac11498517f08d44c8fc00d58a", "ad01d7ae4ad059b0d33baa3c01319dcf8088094d0359e5fd45d6aeaa8b2d0c3d" },
    { 102400, "bc3e3d41a1146b069abffad3c0d44860cf664390afce4d9661f7902e7943e085", "1c35d1a5811083fd7119f5d5d1ba027b4d01c0c6c49fb6ff2cf75393ea5db4a7", "4652cff7a3f385a6103b5c260fc1593e13c778dbe608efb092fe7ee69df6e9c6" },
};

static const char* c_xof_hash_131 = "af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262e00f03e7b69af26b7faaf09fcd333050338ddfe085b8cc869ca98b206c08243a26f5487789e8f660afe6c99ef9e0c52b92e7393024a80459cf91f476f9ffdbda7001c22e159b402631f277ca96f2defdf1078282314e763699a31c5363165421cce14d";
static const char* c_xof_keyed_131 = "92b2b75604ed3c761f9d6f62392c8a9227ad0ea3f09573e783f1498a4ed60d26b18171a2f22a4b94822c701f107153dba24918c4bae4d2945c20ece13387627d3b73cbf97b797d5e59948c7ef788f54372df45e45e4293c7dc18c1d41144a9758be58960856be1eabbe22c2653190de560ca3b2ac4aa692a9210694254c371e851bc8f";
static const char* c_xof_derive_131 = "2cc39783c223154fea8dfb7c1b1660f2ac2dcbd1c1de8277b0b0dd39b7e50d7d905630c8be290dfcf3e6842f13bddd573c098c3f17361f1f206b8cad9d088aa4a3f746752c6b0ce6a83b0da81d59649257cdf8eb3e9f7d4998e41021fac119deefb896224ac99f860011f73609e6e0e4540f93b273e56547dfd3aa1a035ba6689d89a0";
static const char* c_xof_1024_131 = "42214739f095a406f3fc83deb889744ac00df831c10daa55189b5d121c855af71cf8107265ecdaf8505b95d8fcec83a98a6a96ea5109d2c179c47a387ffbb404756f6eeae7883b446b70ebb144527c2075ab8ab204c0086bb22b7c93d465efc57f8d917f0b385c6df265e77003b85102967486ed57db5c5ca170ba441427ed9afa684e";

static void
sc_crypt_fill_input(u8* pData, u64 size)
{
    for (u64 i = 0; i < size; ++i)
        pData[i] = to_u8(i % 251);
}

static void
sc_crypt_bytes_to_hex(const u8* pData, u64 size, char* pOut)
{
    static const char* pHex = "0123456789abcdef";

    for (u64 i = 0; i < size; ++i)
    {
        pOut[i * 2] = pHex[pData[i] >> 4];
        pOut[i * 2 + 1] = pHex[pData[i] & 0x0f];
    }

    pOut[size * 2] = '\0';
}

static void
sc_crypt_vectors_test()
{
    u8 aBuffer[102400];
    sc_crypt_fill_input(aBuffer, sizeof(aBuffer));

    const i32 c_count = to_i32(ScArrayCount(c_vectors));
    for (i32 i = 0; i < c_count; ++i)
    {
        const ScCryptVector* pVector = &c_vectors[i];
        u8 aOut[SC_CRYPT_HASH_SIZE];
        char aHex[SC_CRYPT_HASH_SIZE * 2 + 1];

        sc_crypt_hash(aBuffer, pVector->Length, aOut);
        sc_crypt_bytes_to_hex(aOut, sizeof(aOut), aHex);
        sc_test_string_equals(aHex, pVector->pHash);

        sc_crypt_hash_keyed(aBuffer, pVector->Length, (const u8*)c_key, aOut);
        sc_crypt_bytes_to_hex(aOut, sizeof(aOut), aHex);
        sc_test_string_equals(aHex, pVector->pKeyed);

        sc_crypt_derive_key(c_context, aBuffer, pVector->Length, aOut);
        sc_crypt_bytes_to_hex(aOut, sizeof(aOut), aHex);
        sc_test_string_equals(aHex, pVector->pDerive);
    }
}

static void
sc_crypt_xof_test()
{
    u8 aBuffer[102400];
    sc_crypt_fill_input(aBuffer, sizeof(aBuffer));

    const u64 c_xof_size = 131;
    u8 aOut[131];
    char aHex[131 * 2 + 1];

    sc_crypt_hash_xof(aBuffer, 0, aOut, c_xof_size);
    sc_crypt_bytes_to_hex(aOut, c_xof_size, aHex);
    sc_test_string_equals(aHex, c_xof_hash_131);

    sc_crypt_hash_xof(aBuffer, 1024, aOut, c_xof_size);
    sc_crypt_bytes_to_hex(aOut, c_xof_size, aHex);
    sc_test_string_equals(aHex, c_xof_1024_131);

    ScCryptHasher hasher;
    sc_crypt_hasher_init_keyed(&hasher, (const u8*)c_key);
    sc_crypt_hasher_update(&hasher, aBuffer, 0);
    sc_crypt_hasher_finalize(&hasher, aOut, c_xof_size);
    sc_crypt_bytes_to_hex(aOut, c_xof_size, aHex);
    sc_test_string_equals(aHex, c_xof_keyed_131);

    sc_crypt_hasher_init_derive_key(&hasher, c_context);
    sc_crypt_hasher_update(&hasher, aBuffer, 0);
    sc_crypt_hasher_finalize(&hasher, aOut, c_xof_size);
    sc_crypt_bytes_to_hex(aOut, c_xof_size, aHex);
    sc_test_string_equals(aHex, c_xof_derive_131);

    u8 aSeek[64];
    char aSeekHex[64 * 2 + 1];
    char aExpected[64 * 2 + 1];
    memcpy(aExpected, c_xof_hash_131 + 32 * 2, 64 * 2);
    aExpected[64 * 2] = '\0';

    sc_crypt_hasher_init(&hasher);
    sc_crypt_hasher_update(&hasher, aBuffer, 0);
    sc_crypt_hasher_finalize_seek(&hasher, 32, aSeek, sizeof(aSeek));
    sc_crypt_bytes_to_hex(aSeek, sizeof(aSeek), aSeekHex);
    sc_test_string_equals(aSeekHex, aExpected);
}

static void
sc_crypt_streaming_test()
{
    u8 aBuffer[102400];
    sc_crypt_fill_input(aBuffer, sizeof(aBuffer));

    const u64 c_lengths[] = { 0, 1, 63, 64, 65, 1023, 1024, 1025, 2048, 2049, 3072, 8192, 102400 };
    const u64 c_count = ScArrayCount(c_lengths);

    for (u64 i = 0; i < c_count; ++i)
    {
        u64 size = c_lengths[i];
        u8 aOneShot[SC_CRYPT_HASH_SIZE];
        u8 aStream[SC_CRYPT_HASH_SIZE];

        sc_crypt_hash(aBuffer, size, aOneShot);

        ScCryptHasher hasher;
        sc_crypt_hasher_init(&hasher);

        u64 offset = 0;
        u64 step = 1;
        while (offset < size)
        {
            u64 take = step;
            if (take > size - offset)
                take = size - offset;

            sc_crypt_hasher_update(&hasher, aBuffer + offset, take);
            offset += take;
            step = step % 997 + 1;
        }

        sc_crypt_hasher_finalize(&hasher, aStream, sizeof(aStream));
        sc_test_condition(memcmp(aOneShot, aStream, sizeof(aOneShot)) == 0);
    }

    ScCryptHasher hasher;
    u8 aOut[SC_CRYPT_HASH_SIZE];
    char aHex[SC_CRYPT_HASH_SIZE * 2 + 1];

    sc_crypt_hasher_init(&hasher);
    sc_crypt_hasher_update(&hasher, aBuffer, 1024);
    sc_crypt_hasher_update(&hasher, aBuffer + 1024, 1024);
    sc_crypt_hasher_update(&hasher, aBuffer + 2048, 1024);
    sc_crypt_hasher_finalize(&hasher, aOut, sizeof(aOut));
    sc_crypt_bytes_to_hex(aOut, sizeof(aOut), aHex);
    sc_test_string_equals(aHex, c_vectors[22].pHash);
}

static void
sc_crypt_reset_test()
{
    u8 aBuffer[1024];
    sc_crypt_fill_input(aBuffer, sizeof(aBuffer));

    ScCryptHasher hasher;
    sc_crypt_hasher_init(&hasher);
    sc_crypt_hasher_update(&hasher, aBuffer, 7);
    sc_crypt_hasher_reset(&hasher);
    sc_crypt_hasher_update(&hasher, aBuffer, sizeof(aBuffer));

    u8 aOut[SC_CRYPT_HASH_SIZE];
    char aHex[SC_CRYPT_HASH_SIZE * 2 + 1];
    sc_crypt_hasher_finalize(&hasher, aOut, sizeof(aOut));
    sc_crypt_bytes_to_hex(aOut, sizeof(aOut), aHex);
    sc_test_string_equals(aHex, c_vectors[19].pHash);
}

static void
sc_crypt_empty_test()
{
    u8 aOut[SC_CRYPT_HASH_SIZE];
    char aHex[SC_CRYPT_HASH_SIZE * 2 + 1];

    sc_crypt_hash(ScNull, 0, aOut);
    sc_crypt_bytes_to_hex(aOut, sizeof(aOut), aHex);
    sc_test_string_equals(aHex, c_vectors[0].pHash);

    sc_crypt_hash_xof(ScNull, 0, ScNull, 0);
}

void
sc_auto_crypt()
{
    sc_test_file();

    sc_test_func(sc_crypt_vectors_test());
    sc_test_func(sc_crypt_xof_test());
    sc_test_func(sc_crypt_streaming_test());
    sc_test_func(sc_crypt_reset_test());
    sc_test_func(sc_crypt_empty_test());
}
