#include <Sc/Sc.h>
#include <Sc/Test.h>
#include <Sc/Types.h>

void
sc_date_time_now_seconds_test()
{
    i64 nowSeconds = sc_date_time_now_seconds();
    sc_test_condition(nowSeconds > 1600000000);
}

void
sc_date_time_now_test()
{
    ScDateTime dt = sc_date_time_now();

    sc_test_condition(dt.Year >= 2020);
    sc_test_condition(dt.Month >= 1 && dt.Month <= 12);
    sc_test_condition(dt.Day >= 1 && dt.Day <= 31);
    sc_test_condition(dt.Hours >= 0 && dt.Hours <= 23);
    sc_test_condition(dt.Minutes >= 0 && dt.Minutes <= 59);
    sc_test_condition(dt.Seconds >= 0 && dt.Seconds <= 59);
    sc_test_condition(dt.DayOfTheWeek >= 0 && dt.DayOfTheWeek <= 6);
}

void
sc_date_time_to_string_test()
{
    ScDateTime dt = { .Hours = 9, .Minutes = 30, .Seconds = 5, .Day = 15, .Month = 7, .Year = 2026 };
    sc_test_string_equals(sc_date_time_to_string(dt), "09:30:05 15.07.2026");
}

void
sc_date_time_to_date_string_test()
{
    ScDateTime dt = { .Hours = 9, .Minutes = 30, .Seconds = 5, .Day = 15, .Month = 7, .Year = 2026 };
    sc_test_string_equals(sc_date_time_to_date_string(dt), "15:07:2026");
}

void
sc_date_time_to_time_string_test()
{
    ScDateTime dt = { .Hours = 9, .Minutes = 30, .Seconds = 5, .Day = 15, .Month = 7, .Year = 2026 };
    sc_test_string_equals(sc_date_time_to_time_string(dt), "09:30:05");
}

void
sc_date_time_add_seconds_seconds_to_minutes_test()
{
    ScDateTime dt = { .Hours = 9, .Minutes = 30, .Seconds = 50, .Day = 15, .Month = 7, .Year = 2026 };
    sc_date_time_add_seconds(&dt, 20);
    sc_test_condition(dt.Seconds == 10);
    sc_test_condition(dt.Minutes == 31);
    sc_test_condition(dt.Hours == 9 && dt.Day == 15 && dt.Month == 7 && dt.Year == 2026);
}

void
sc_date_time_add_seconds_minutes_to_hours_test()
{
    ScDateTime dt = { .Hours = 9, .Minutes = 30, .Seconds = 5, .Day = 15, .Month = 7, .Year = 2026 };
    sc_date_time_add_seconds(&dt, 3600);
    sc_test_condition(dt.Hours == 10 && dt.Minutes == 30 && dt.Seconds == 5);
    sc_test_condition(dt.Day == 15 && dt.Month == 7 && dt.Year == 2026);
}

void
sc_date_time_add_seconds_hours_to_days_test()
{
    ScDateTime dt = { .Hours = 23, .Minutes = 30, .Seconds = 0, .Day = 15, .Month = 7, .Year = 2026 };
    sc_date_time_add_seconds(&dt, 7200);
    sc_test_condition(dt.Hours == 1 && dt.Minutes == 30 && dt.Seconds == 0);
    sc_test_condition(dt.Day == 16 && dt.Month == 7 && dt.Year == 2026);
}

void
sc_date_time_add_seconds_days_to_months_test()
{
    ScDateTime dt = { .Hours = 23, .Minutes = 59, .Seconds = 0, .Day = 31, .Month = 7, .Year = 2026 };
    sc_date_time_add_seconds(&dt, 3720);
    sc_test_condition(dt.Day == 1 && dt.Month == 8 && dt.Year == 2026);
    sc_test_condition(dt.Hours == 1 && dt.Minutes == 1 && dt.Seconds == 0);
}

void
sc_date_time_add_seconds_months_to_year_test()
{
    ScDateTime dt = { .Hours = 23, .Minutes = 0, .Seconds = 0, .Day = 31, .Month = 12, .Year = 2026 };
    sc_date_time_add_seconds(&dt, 7200);
    sc_test_condition(dt.Year == 2027 && dt.Month == 1 && dt.Day == 1);
    sc_test_condition(dt.Hours == 1 && dt.Minutes == 0 && dt.Seconds == 0);
}

void
sc_date_time_add_seconds_leap_year_test()
{
    // DOCS: 2024 — високосный, в феврале 29 дней
    ScDateTime leapDt = { .Hours = 0, .Minutes = 0, .Seconds = 0, .Day = 28, .Month = 2, .Year = 2024 };
    sc_date_time_add_seconds(&leapDt, 86400);
    sc_test_condition(leapDt.Day == 29 && leapDt.Month == 2 && leapDt.Year == 2024);

    // DOCS: 2025 — не високосный, в феврале 28 дней
    ScDateTime nonLeapDt = { .Hours = 0, .Minutes = 0, .Seconds = 0, .Day = 28, .Month = 2, .Year = 2025 };
    sc_date_time_add_seconds(&nonLeapDt, 86400);
    sc_test_condition(nonLeapDt.Day == 1 && nonLeapDt.Month == 3 && nonLeapDt.Year == 2025);
}

void
sc_auto_date_time()
{
    sc_test_file();

    sc_test_func(sc_date_time_now_seconds_test());
    sc_test_func(sc_date_time_now_test());
    sc_test_func(sc_date_time_to_string_test());
    sc_test_func(sc_date_time_to_date_string_test());
    sc_test_func(sc_date_time_to_time_string_test());
    sc_test_func(sc_date_time_add_seconds_seconds_to_minutes_test());
    sc_test_func(sc_date_time_add_seconds_minutes_to_hours_test());
    sc_test_func(sc_date_time_add_seconds_hours_to_days_test());
    sc_test_func(sc_date_time_add_seconds_days_to_months_test());
    sc_test_func(sc_date_time_add_seconds_months_to_year_test());
    sc_test_func(sc_date_time_add_seconds_leap_year_test());
}