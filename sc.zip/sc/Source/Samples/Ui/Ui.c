/*
  DOCS: Сэмпл UI: imGui-подобный ScUi (Sc/Gfx/Ui.h) с бэкендом
  ScRasterBackend (Sc/Gfx/UiBackends/RasterBackend.h) поверх
  программного растера ScRaster + окно с blit-ом готового кадра
  (Linux: xcb, Windows: WIN32/GDI). Крест-платформенно.

  Что демонстрируется:
    - окно (UseGraphics=1) + RasterBackend: окно отдаёт размеры,
      бэкенд ui рисует виджеты в свой ScRaster;
    - sc_raster_backend_new/update/render: полный ui-цикл
      (frame_begin -> виджеты -> frame_end -> layout -> render);
    - виджеты: панель, вложенные прямоугольники, hover-подсветка
      (ScUiColor Idle/Hovered), текст (атлас Text/Font через
      sc_raster_backend_load_font), скроллбар;
    - input: все события окна (мышь, клавиатура, колесо, состояние
      окна) приходят в callback sc_window_set_event_call; пользователь
      раскладывает их в ScUiInput через sc_ui_backend_get_input(),
      клик ловится через состояние виджета;
    - FPS-счётчик.

  Сцена: панель 400x600 в центре с 4 цветными прямоугольниками
  (подсветка при наведении), текст-заголовок, скроллбар справа.
  Выход: закрыть окно или Esc.
*/
#include <Sc/Gfx/UiBackends/RasterBackend.h>
#include <Sc/Gfx/Ui.h>
#include <Sc/Gfx/Window.h>
#include <Sc/Math.h>
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>

/*
  DOCS: ScKey окна -> ScUiKey. ScUiKey знает только клавиши навигации
  и редактирования; остальные (буквы, Escape, Enter, ...) в ui-инпут
  не кладутся - их обрабатывает пользовательский код.
*/
static ScUiKey
ui_sample_ui_key_from_window_key(ScKey key)
{
    switch (key)
    {
    case ScKey_Tab:
        return ScUiKey_Tab;
    case ScKey_Backspace:
        return ScUiKey_Backspace;
    case ScKey_Left:
        return ScUiKey_LeftArrow;
    case ScKey_Right:
        return ScUiKey_RightArrow;
    case ScKey_Up:
        return ScUiKey_UpArrow;
    case ScKey_Down:
        return ScUiKey_DownArrow;
    case ScKey_Home:
        return ScUiKey_Home;
    case ScKey_End:
        return ScUiKey_End;
    case ScKey_Delete:
        return ScUiKey_Delete;
    default:
        return ScUiKey_Undefined;
    }
}

/*
  DOCS: ScMouseKey окна -> ScUiKey. ScUiKey знает только три основные
  кнопки; Ext_* (дополнительные) в ui-инпут не попадают.
*/
static ScUiKey
ui_sample_ui_key_from_mouse_key(ScMouseKey key)
{
    switch (key)
    {
    case ScMouseKey_Left:
        return ScUiKey_Mouse_Left_Button;
    case ScMouseKey_Right:
        return ScUiKey_Mouse_Right_Button;
    case ScMouseKey_Middle:
        return ScUiKey_Mouse_Middle_Button;
    default:
        return ScUiKey_Undefined;
    }
}

/*
  DOCS: Кладёт состояние клавиши в ScUiInput. IsHandled сбрасываем:
  новый ввод снимает "уже обработано" с прошлого кадра. ScUiKey_Undefined
  (клавиша вне модели ui) пропускается.
*/
static void
ui_sample_set_key(ScUiInput* pInput, ScUiKey key, ScUiKeyState state)
{
    if (key == ScUiKey_Undefined)
        return;

    pInput->aKeys[key].State = state;
    pInput->aKeys[key].IsHandled = 0;
}

/*
  DOCS: Окно сэмпла - нужно в callback, чтобы закрыть его по
  ScEventType_WindowClosed (ScCall не передаёт user-data; на XCB окно
  само IsAlive не сбрасывает, в отличие от WIN32).
*/
static ScWindow* g_pSampleWindow = ScNull;

/*
  DOCS: Отпускает все нажатые клавиши ui: окно потеряло фокус или мышь
  ушла за его пределы, и события Release уже не придут - без этого
  кнопка "залипнет" в Pressed.
*/
static void
ui_sample_release_all_keys(ScUiInput* pInput, i32 releaseMouseOnly)
{
    for (i32 k = 0; k < ScUiKey_Count; ++k)
    {
        i32 isMouseKey = (k == ScUiKey_Mouse_Left_Button
            || k == ScUiKey_Mouse_Right_Button
            || k == ScUiKey_Mouse_Middle_Button);
        if (releaseMouseOnly && !isMouseKey)
            continue;

        if (pInput->aKeys[k].State == ScUiKeyState_Pressed)
        {
            pInput->aKeys[k].State = ScUiKeyState_Released;
            pInput->aKeys[k].IsHandled = 0;
        }
    }
}

/*
  DOCS: Прокидывает ВСЕ события окна в ui-input. Вызывается окном
  через sc_window_set_event_call (см. main). Состояния клавиш ui
  снимает сам в sc_ui_process_input (Released -> None), поэтому здесь
  достаточно выставлять Pressed/Released по событиям.

  События без поля в ScUiInput (прокрутка, текстовый ввод, изменение
  раскладки, состояние окна) остаются в пользовательском коде - в ui
  их класть некуда; место, где их можно обработать, помечено NOTE.
*/
static void
ui_sample_on_event(ScEvent* pEvent)
{
    ScUiInput* pInput = sc_ui_backend_get_input();
    if (pInput == ScNull)
        return;

    switch (pEvent->Type)
    {
    case ScEventType_MouseMove:
    {
        ScMouseMoveEvent* pMouse = (ScMouseMoveEvent*)pEvent;
        /* окно уже отдаёт MouseMove в Y-вверх (origin - левый низ) */
        pInput->MousePosition = v2_new((f32)pMouse->X, (f32)pMouse->Y);
        break;
    }
    case ScEventType_MousePress:
    {
        ScMousePressEvent* pMouse = (ScMousePressEvent*)pEvent;
        ui_sample_set_key(pInput, ui_sample_ui_key_from_mouse_key(pMouse->Key), ScUiKeyState_Pressed);
        break;
    }
    case ScEventType_MouseRelease:
    {
        ScMouseReleaseEvent* pMouse = (ScMouseReleaseEvent*)pEvent;
        ui_sample_set_key(pInput, ui_sample_ui_key_from_mouse_key(pMouse->Key), ScUiKeyState_Released);
        break;
    }
    case ScEventType_KeyPress:
    {
        ScKeyPressEvent* pKey = (ScKeyPressEvent*)pEvent;
        ui_sample_set_key(pInput, ui_sample_ui_key_from_window_key(pKey->Key), ScUiKeyState_Pressed);
        break;
    }
    case ScEventType_KeyRelease:
    {
        ScKeyReleaseEvent* pKey = (ScKeyReleaseEvent*)pEvent;
        ui_sample_set_key(pInput, ui_sample_ui_key_from_window_key(pKey->Key), ScUiKeyState_Released);
        break;
    }
    case ScEventType_MouseScroll:
    {
        /* NOTE: у ScUiInput нет поля прокрутки. Значение колеса здесь -
           ScMouseScrollEvent.Value; кладите его в свою логику/скролл. */
        break;
    }
    case ScEventType_KeyType:
    {
        /* NOTE: у ScUiInput нет текстового ввода. Codepoint - здесь -
           ScKeyTypeEvent.CodePoint (для полей ввода в пользовательском коде). */
        break;
    }
    case ScEventType_KeyboardMapping:
        /* раскладка изменилась - в ScUiInput состояния не хранятся */
        break;
    case ScEventType_WindowResized:
        /* размер ui получает в sc_raster_backend_update(DisplaySize) */
        break;
    case ScEventType_WindowEnter:
    {
        ScWindowEnterEvent* pEnter = (ScWindowEnterEvent*)pEvent;
        if (!pEnter->IsInside)
        {
            /* мышь ушла из окна: Release мог не прийти */
            ui_sample_release_all_keys(pInput, 1);
        }
        break;
    }
    case ScEventType_WindowFocused:
    {
        ScWindowFocusedEvent* pFocus = (ScWindowFocusedEvent*)pEvent;
        if (!pFocus->Focused)
        {
            /* фокус потерян: снимаем все нажатия, иначе они "залипнут" */
            ui_sample_release_all_keys(pInput, 0);
        }
        break;
    }
    case ScEventType_WindowClosed:
        if (g_pSampleWindow != ScNull)
            g_pSampleWindow->IsAlive = 0;
        break;
    case ScEventType_WindowMoved:
    case ScEventType_WindowMaximized:
    case ScEventType_WindowHidden:
        /* состояние окна - вне модели ScUiInput */
        break;
    case ScEventType_None:
    default:
        break;
    }
}

i32
main()
{
    /*
        I/O Not Buffered: не буферизовать. Каждый printf / fputs / putchar немедленно уходит в файловый дескриптор (write(2)), без накопления в памяти.
    */
    setvbuf(stdout, NULL, _IONBF, 0);

    ScWindowConfig conf = {
        .pName = "Sc Ui Sample",
        .NameLength = 13,
        .UseGraphics = 1, /* окно + растер (blit готового кадра) */
        .Size = { .Width = 800, .Height = 600 },
        .MinSize = { .Width = 320, .Height = 240 },
        /* MaxSize: буферы растера аллоцируются сразу на него */
        .MaxSize = { .Width = 1600, .Height = 1200 },
        /* {0,0} = центр экрана */
        .Position = { .X = 0, .Y = 0 },
    };

    ScWindow window = {};
    sc_window_create(&window, conf);
    if (!window.IsAlive)
    {
        printf("Window creation failed!\n");
        return 1;
    }

    /*
      DOCS: RasterBackend - бэкенд ui поверх программного растера:
      создаёт свой ScRaster, регистрирует коллбеки отрисовки в
      sc_ui_backend. Окно должно блитить кадр именно этого растера
      (pWindow->pGraphics указывает на свой, а бэкенд - на свой).
    */
    sc_raster_backend_new();
    ScRaster* pUiRaster = sc_raster_backend_get_raster();
    if (pUiRaster == ScNull)
    {
        printf("Raster backend creation failed!\n");
        sc_window_destroy(&window);
        return 1;
    }

    g_pSampleWindow = &window;
    sc_window_set_event_call(&window, ui_sample_on_event);

    /*
      DOCS: Шрифт для текста ui: DrawText/GetTextMetrics бэкенда берут
      загруженный шрифт подходящего размера (см. RasterBackend.h). Без
      загрузки текст не рисуется, а метрики - грубая оценка. Ищем
      сначала шрифт из Rendy, затем системный.
    */
    static const char* aFontCandidates[] = {
        "Resources/Fonts/MartianMono-sWdRg.ttf",
        "C:/Windows/Fonts/consola.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/TTF/DejaVuSans.ttf",
    };

    i64 fontId = ScInvalidId;
    for (i32 f = 0; f < ScArrayCount(aFontCandidates); ++f)
    {
        if (sc_file_get_size(aFontCandidates[f]) == 0)
            continue;

        fontId = sc_raster_backend_load_font((char*)aFontCandidates[f], 24);
        if (fontId != ScInvalidId)
        {
            printf("Font: %s\n", aFontCandidates[f]);
            break;
        }
    }

    if (fontId == ScInvalidId)
        printf("Font: not found, text disabled\n");

    printf("Ui rendering. ESC to exit.\n");

    i64 frame = 0;
    i64 fpsFrames = 0;
    i64 fpsStart = sc_date_time_now_seconds();

    while (window.IsAlive)
    {
        sc_window_update(&window);

        if (window.aKeys[ScKey_Escape] == ScAction_Press)
        {
            window.IsAlive = 0;
            break;
        }

        /* размер окна -> ui (layout: Fit/Grow считают от DisplaySize) */
        i32 width = to_i32(window.Size.Width);
        i32 height = to_i32(window.Size.Height);
        sc_raster_backend_update((ScUiBackendState) {
            .DisplaySize = v2_new((f32)width, (f32)height),
        });

        /* DOCS: Кадр ui: begin -> виджеты -> layout -> input -> render
           -> frame_end (он чистит виджеты и arena, render обязан быть
           до него: строки текста живут в arena). */
        sc_ui_frame_begin();
        {
            /*
              DOCS: Корневая панель: позиция в долях экрана
              (Fixed <= 1.0 = проценты от DisplaySize). Ui - Y-вверх,
              Position.Y = ВЕРХ панели, поэтому центр:
              top = DisplayHeight / 2 + PanelHeight / 2.
              Пересчитываем каждый кадр (актуально при resize).
            */
            const f32 panelW = 400.0f;
            const f32 panelH = 600.0f;
            f32 panelX = (f32)width / 2 - panelW / 2;
            f32 panelY = (f32)height / 2 + panelH / 2;
            ScUiState panelState = sc_ui_widget_begin({
                .pName = "MainPanel",
                .Type = ScUiWidgetType_Rectangle,
                .Flag = ScUiFlag_Alive,
                .Color = {
                    .ShouldUseGradient = 0,
                    .Idle = v4_rgb(29, 38, 47),
                    .Hovered = v4_rgb(29, 38, 47),
                },
                .Size = { .Width = Fixed(panelW), .Height = Fixed(panelH) },
                .Position = { .X = Fixed(panelX), .Y = Fixed(panelY) },
                .Layout = {
                    .Direction = ScUiDirection_Vertical,
                    .Padding = ScUiPadAll(16),
                    .ChildGap = 12,
                },
            });

            /* DOCS: Заголовок-текст (пока метрики заглушкой). */
            sc_ui_text({
                .pName = "Title",
                .pText = "Sc Ui Sample",
                .FontSize = 24,
                .Horizontal = ScUiTextAlign_X_Center,
                .Color = { .Idle = v4_rgb(230, 230, 240) },
            });

            /* DOCS: Ряд цветных прямоугольников 2x2 с hover. */
            static const v4 aColors[4] = {
                { .R = 0.90f, .G = 0.30f, .B = 0.30f, .A = 1.0f }, /* красный   */
                { .R = 0.30f, .G = 0.75f, .B = 0.35f, .A = 1.0f }, /* зелёный   */
                { .R = 0.35f, .G = 0.55f, .B = 0.95f, .A = 1.0f }, /* синий     */
                { .R = 0.95f, .G = 0.75f, .B = 0.25f, .A = 1.0f }, /* жёлтый    */
            };

            static const char* aNames[4] = {
                "RedButton", "GreenButton", "BlueButton", "YellowButton"
            };

            ScUiState aChildStates[4] = {};
            for (i32 row = 0; row < 2; ++row)
            {
                ScUiState rowState = sc_ui_widget_begin({
                    .pName = row == 0 ? "Row0" : "Row1",
                    .Type = ScUiWidgetType_Rectangle,
                    .Flag = ScUiFlag_Alive,
                    .Size = { .Width = Grow(1), .Height = Fit(0) },
                    .Layout = {
                        .Direction = ScUiDirection_Horizontal,
                        .ChildGap = 12,
                    },
                });

                for (i32 col = 0; col < 2; ++col)
                {
                    i32 ind = row * 2 + col;
                    aChildStates[ind] = sc_ui_widget_begin({
                        .pName = (char*)aNames[ind],
                        .Type = ScUiWidgetType_Rectangle,
                        .Flag = ScUiFlag_Alive,
                        .Color = {
                            .Idle = aColors[ind],
                            /* hover: чуть темнее idle */
                            .Hovered = v4_mulv(aColors[ind], 0.75f),
                            .Clicked = v4_mulv(aColors[ind], 0.5f),
                        },
                        .Size = { .Width = Grow(1), .Height = Fixed(80) },
                    });

                    if (aChildStates[ind] == ScUiState_Clicked)
                        printf("[%s] clicked!\n", aNames[ind]);

                    sc_ui_widget_end();
                }

                sc_ui_widget_end();
            }

            /* DOCS: Скроллбар-полоса внизу панели. */
            sc_ui_widget_begin({
                .pName = "Scrollbar",
                .Type = ScUiWidgetType_Rectangle,
                .Flag = ScUiFlag_Alive,
                .Color = {
                    .Idle = v4_rgb(70, 70, 90),
                    .Hovered = v4_rgb(90, 90, 115),
                },
                .Size = { .Width = Grow(1), .Height = Fixed(8) },
            });
            sc_ui_widget_end();

            /* DOCS: Корень закрывается последним. */
            sc_ui_widget_end();
        }

        sc_ui_layout();

        /* input обрабатывается после layout-а: widget-ы уже с позами */
        sc_ui_process_input();

        /* DOCS: Кадр ui -> растер бэкенда. */
        sc_raster_backend_render();

        sc_ui_frame_end();

        /*
          DOCS: Blit: окно блитит СВОЙ растер (window.pGraphics), а ui
          рисует в растер бэкенда. Для простоты копируем кадр ui в
          растер окна (размеры одинаковые после update-а) и блитим.
        */
        ScRaster* pWindowRaster = sc_window_get_raster(&window);
        if (pWindowRaster != ScNull)
        {
            ScRasterBuffer uiBuffer = sc_raster_get_buffer(pUiRaster);
            ScRasterBuffer windowBuffer = sc_raster_get_buffer(pWindowRaster);

            if (uiBuffer.pData != ScNull && windowBuffer.pData != ScNull
                && uiBuffer.Width == windowBuffer.Width
                && uiBuffer.Height == windowBuffer.Height)
            {
                sc_copy(windowBuffer.pData, uiBuffer.pData,
                    (u64)uiBuffer.Width * uiBuffer.Height * 4);
            }
        }

        /* показать кадр */
        sc_window_graphics_swap_buffers(&window);

        /* FPS раз в секунду */
        ++frame;
        ++fpsFrames;
        i64 now = sc_date_time_now_seconds();
        if (now > fpsStart)
        {
            // printf("fps: %lld, size: %dx%d\n", (long long)fpsFrames, width, height);
            fpsFrames = 0;
            fpsStart = now;
        }
    }

    sc_raster_backend_free();
    sc_window_destroy(&window);
    printf("Bye!\n");
    return 0;
}
