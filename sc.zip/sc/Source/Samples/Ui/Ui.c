/*
  DOCS: Сэмпл UI: imGui-подобный ScUi (Sc/Gfx/Ui.h) с бэкендом
  ScRasterBackend (Sc/Gfx/UiBackends/RasterBackend.h) поверх
  программного растера ScRaster + окно с blit-ом готового кадра
  (Linux: xcb, Windows: WIN32/GDI). Крест-платформенно.

  Что демонстрируется:
    - окно (UseGraphics=1) + RasterBackend: окно отдаёт размеры,
      бэкенд ui рисует виджеты в свой ScRaster;
    - sc_raster_backend_new/update/render: полный ui-цикл
      (frame_begin -> виджеты -> frame_end -> layout -> render);
    - виджеты: панель, вложенные прямоугольники, hover-подсветка
      (ScUiColor Idle/Hovered), текст (пока как заглушка метрик),
      скроллбар;
    - input: позиция мыши и кнопки из окна прокидываются в ui
      (sc_raster_backend_get_input), клик ловится через состояние
      виджета;
    - FPS-счётчик.

  Сцена: панель 400x300 в центре с 4 цветными прямоугольниками
  (подсветка при наведении), текст-заголовок, скроллбар справа.
  Выход: закрыть окно или Esc.
*/
#include <Sc/Gfx/UiBackends/RasterBackend.h>
#include <Sc/Gfx/Ui.h>
#include <Sc/Gfx/Window.h>
#include <Sc/Math.h>
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>

/*
  DOCS: Прокидывает события окна в ui-input: позиция мыши,
  нажатие/отпускание левой кнопки. Ui хранит состояние в
  ScUiInput бэкенда (ключи чистятся самим ui в sc_ui_frame_end).
*/
static void
ui_sample_on_event(ScEvent* pEvent)
{
    ScUiInput* pInput = sc_raster_backend_get_input();

    switch (pEvent->Type)
    {
    case ScEventType_MouseMove:
    {
        ScMouseMoveEvent* pMouse = (ScMouseMoveEvent*)pEvent;
        /* окно: Y-вниз от верха - ui ждёт ровно это */
        pInput->MousePosition = v2_new((f32)pMouse->X, (f32)pMouse->Y);
        break;
    }
    case ScEventType_MousePress:
    {
        ScMousePressEvent* pMouse = (ScMousePressEvent*)pEvent;
        if (pMouse->Key == ScMouseKey_Left)
            pInput->aKeys[ScUiKey_Mouse_Left_Button].State = ScUiKeyState_Pressed;
        break;
    }
    case ScEventType_MouseRelease:
    {
        ScMouseReleaseEvent* pMouse = (ScMouseReleaseEvent*)pEvent;
        if (pMouse->Key == ScMouseKey_Left)
            pInput->aKeys[ScUiKey_Mouse_Left_Button].State = ScUiKeyState_Released;
        break;
    }
    default:
        break;
    }
}

i32
main()
{
    setvbuf(stdout, NULL, _IONBF, 0);

    ScWindowConfig conf = {
        .pName = "Sc Ui Sample",
        .NameLength = 13,
        .UseGraphics = 1, /* окно + растер (blit готового кадра) */
        .Size = { .Width = 800, .Height = 600 },
        .MinSize = { .Width = 320, .Height = 240 },
        /* MaxSize: буферы растера аллоцируются сразу на него */
        .MaxSize = { .Width = 1600, .Height = 1200 },
        /* {0,0} = центр экрана */
        .Position = { .X = 0, .Y = 0 },
    };

    ScWindow window = {};
    sc_window_create(&window, conf);
    if (!window.IsAlive)
    {
        printf("Window creation failed!\n");
        return 1;
    }

    /*
      DOCS: RasterBackend - бэкенд ui поверх программного растера:
      создаёт свой ScRaster, регистрирует коллбеки отрисовки в
      sc_ui_backend. Окно должно блитить кадр именно этого растера
      (pWindow->pGraphics указывает на свой, а бэкенд - на свой).
    */
    sc_raster_backend_new();
    ScRaster* pUiRaster = sc_raster_backend_get_raster();
    if (pUiRaster == ScNull)
    {
        printf("Raster backend creation failed!\n");
        sc_window_destroy(&window);
        return 1;
    }

    sc_window_set_event_call(&window, ui_sample_on_event);
    printf("Ui rendering. ESC to exit.\n");

    i64 frame = 0;
    i64 fpsFrames = 0;
    i64 fpsStart = sc_date_time_now_seconds();

    while (window.IsAlive)
    {
        sc_window_update(&window);

        if (window.aKeys[ScKey_Escape] == ScAction_Press)
        {
            window.IsAlive = 0;
            break;
        }

        /* размер окна -> ui (layout: Fit/Grow считают от DisplaySize) */
        i32 width = to_i32(window.Size.Width);
        i32 height = to_i32(window.Size.Height);
        sc_raster_backend_update((ScUiBackendState) {
            .DisplaySize = v2_new((f32)width, (f32)height),
        });

        /* DOCS: Кадр ui: begin -> виджеты -> layout -> input -> render
           -> frame_end (он чистит виджеты и arena, render обязан быть
           до него: строки текста живут в arena). */
        sc_ui_frame_begin();
        {
            /*
              DOCS: Корневая панель: позиция в долях экрана
              (Fixed <= 1.0 = проценты от DisplaySize). Держим
              центр: половина экрана минус половина панели,
              пересчитываем каждый кадр (актуально при resize).
            */
            f32 panelX = (f32)width / 2 - 200;
            f32 panelY = (f32)height / 2 - 150;
            ScUiState panelState = sc_ui_widget_begin({
                .pName = "MainPanel",
                .Type = ScUiWidgetType_Rectangle,
                .Flag = ScUiFlag_Alive,
                .Color = {
                    .ShouldUseGradient = 0,
                    .Idle = v4_rgb(34, 34, 46),
                    .Hovered = v4_rgb(44, 44, 58),
                },
                .Size = { .Width = Fixed(400), .Height = Fixed(300) },
                .Position = { .X = Fixed(panelX), .Y = Fixed(panelY) },
                .Layout = {
                    .Direction = ScUiDirection_Vertical,
                    .Padding = ScUiPadAll(16),
                    .ChildGap = 12,
                },
            });

            /* DOCS: Заголовок-текст (пока метрики заглушкой). */
            sc_ui_text({
                .pName = "Title",
                .pText = "Sc Ui Sample",
                .FontSize = 24,
                .Horizontal = ScUiTextAlign_X_Center,
                .Color = { .Idle = v4_rgb(230, 230, 240) },
            });

            /* DOCS: Ряд цветных прямоугольников 2x2 с hover. */
            static const v4 aColors[4] = {
                { .R = 0.90f, .G = 0.30f, .B = 0.30f, .A = 1.0f }, /* красный   */
                { .R = 0.30f, .G = 0.75f, .B = 0.35f, .A = 1.0f }, /* зелёный   */
                { .R = 0.35f, .G = 0.55f, .B = 0.95f, .A = 1.0f }, /* синий     */
                { .R = 0.95f, .G = 0.75f, .B = 0.25f, .A = 1.0f }, /* жёлтый    */
            };

            static const char* aNames[4] = {
                "RedButton", "GreenButton", "BlueButton", "YellowButton"
            };

            ScUiState aChildStates[4] = {};
            for (i32 row = 0; row < 2; ++row)
            {
                ScUiState rowState = sc_ui_widget_begin({
                    .pName = row == 0 ? "Row0" : "Row1",
                    .Type = ScUiWidgetType_Rectangle,
                    .Flag = ScUiFlag_Alive,
                    .Size = { .Width = Grow(1), .Height = Fit(0) },
                    .Layout = {
                        .Direction = ScUiDirection_Horizontal,
                        .ChildGap = 12,
                    },
                });

                for (i32 col = 0; col < 2; ++col)
                {
                    i32 ind = row * 2 + col;
                    aChildStates[ind] = sc_ui_widget_begin({
                        .pName = (char*)aNames[ind],
                        .Type = ScUiWidgetType_Rectangle,
                        .Flag = ScUiFlag_Alive,
                        .Color = {
                            .Idle = aColors[ind],
                            /* hover: чуть темнее idle */
                            .Hovered = v4_mulv(aColors[ind], 0.75f),
                            .Clicked = v4_mulv(aColors[ind], 0.5f),
                        },
                        .Size = { .Width = Grow(1), .Height = Fixed(80) },
                    });

                    if (aChildStates[ind] == ScUiState_Clicked)
                        printf("[%s] clicked!\n", aNames[ind]);

                    sc_ui_widget_end();
                }

                sc_ui_widget_end();
            }

            /* DOCS: Скроллбар-полоса внизу панели. */
            sc_ui_widget_begin({
                .pName = "Scrollbar",
                .Type = ScUiWidgetType_Rectangle,
                .Flag = ScUiFlag_Alive,
                .Color = {
                    .Idle = v4_rgb(70, 70, 90),
                    .Hovered = v4_rgb(90, 90, 115),
                },
                .Size = { .Width = Grow(1), .Height = Fixed(8) },
            });
            sc_ui_widget_end();

            /* DOCS: Корень закрывается последним. */
            sc_ui_widget_end();
        }

        sc_ui_layout();

        /* input обрабатывается после layout-а: widget-ы уже с позами */
        sc_ui_process_input();

        /* DOCS: Кадр ui -> растер бэкенда. */
        sc_raster_backend_render();

        sc_ui_frame_end();

        /*
          DOCS: Blit: окно блитит СВОЙ растер (window.pGraphics), а ui
          рисует в растер бэкенда. Для простоты копируем кадр ui в
          растер окна (размеры одинаковые после update-а) и блитим.
        */
        ScRaster* pWindowRaster = sc_window_get_raster(&window);
        if (pWindowRaster != ScNull)
        {
            ScRasterBuffer uiBuffer = sc_raster_get_buffer(pUiRaster);
            ScRasterBuffer windowBuffer = sc_raster_get_buffer(pWindowRaster);

            if (uiBuffer.pData != ScNull && windowBuffer.pData != ScNull
                && uiBuffer.Width == windowBuffer.Width
                && uiBuffer.Height == windowBuffer.Height)
            {
                sc_copy(windowBuffer.pData, uiBuffer.pData,
                    (u64)uiBuffer.Width * uiBuffer.Height * 4);
            }
        }

        /* показать кадр */
        sc_window_graphics_swap_buffers(&window);

        /* FPS раз в секунду */
        ++frame;
        ++fpsFrames;
        i64 now = sc_date_time_now_seconds();
        if (now > fpsStart)
        {
            printf("fps: %lld, size: %dx%d\n", (long long)fpsFrames, width, height);
            fpsFrames = 0;
            fpsStart = now;
        }
    }

    sc_raster_backend_free();
    sc_window_destroy(&window);
    printf("Bye!\n");
    return 0;
}
