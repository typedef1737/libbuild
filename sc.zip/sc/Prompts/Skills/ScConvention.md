# Конвенции кода Sc (Simple C)

Документ описывает правила, которые уже применяются в `Source/Sc/**`, `Source/Tests/**`,
`Source/Samples/**` и зафиксированы в `.clang-format`. При добавлении нового кода
следуйте этим правилам, а не общим «книжным» соглашениям C.

Кратко о проекте:

- C99 + расширения GNU/Clang (`__typeof__`, statement expressions `({ ... })`).
- Сборка через Masuka (`*.masuka`), компилятор `clang`, `-std=c99`.
- Публичный include: `#include <Sc/Sc.h>`, `#include <Sc/Math.h>` и т.п.
- Основа — явные имена, явное владение памятью, минимум скрытой магии.

---

## 1. Файлы, каталоги, include

### 1.1 Имена файлов

| Что | Правило | Примеры |
|---|---|---|
| Модуль библиотеки | PascalCase, пара `.h` + `.c` | `Sc.c/.h`, `Ecs.c/.h`, `Math.c/.h`, `ImageBuffer.c/.h` |
| Домен | каталог-существительное | `Data/`, `Gfx/`, `Image/`, `Parsers/`, `Sound/`, `Text/` |
| Тест | `Sc<Модуль>.c` | `Source/Tests/ScList.c`, `ScDict.c`, `Gfx/ScRaster.c` |
| Пример | `<SampleName>.c/.masuka` | `Source/Samples/Ui/Ui.c`, `Render/Render.c` |

Один модуль — одна пара `.h/.c`. `.h` содержит публичный контракт, `.c` — реализацию.
Заголовок и исходник называются одинаково.

### 1.2 Include guards

```c
#ifndef SC_PNG_H
#define SC_PNG_H
...
#endif // SC_PNG_H
```

Формат: `SC_<FILE_NAME>_H`, где имя файла в верхнем регистре.
Исторические исключения: `UI.h` использует `UI_H`, `Vk.h` — `SC_VK_H`.
Новый код должен следовать формату `SC_<NAME>_H`.

### 1.3 Порядок include

В `.c`:

1. Собственный заголовок модуля.
2. Заголовки Sc (`"Sc/Sc.h"`, `"Sc/Math.h"`).
3. Платформенные заголовки (`<Windows.h>`, `<pthread.h>` и т.п.).
4. Стандартная библиотека C (`<stdio.h>`, `<string.h>`, ...).

`SortIncludes: true` — включения сортируются clang-format.
Внутри библиотеки используйте `"Sc/..."`; потребители — `<Sc/...>`.

### 1.4 Состав модуля

Порядок в `.h`:

1. Guard.
2. Краткое описание модуля/контракта в комментарии.
3. `#include` зависимостей.
4. Типы (`typedef`, `struct`, `enum`).
5. Константы/макросы.
6. Объявления функций.
7. `#endif`.

Порядок в `.c`:

1. Include.
2. `static`-глобальные состояния.
3. `static`-хелперы.
4. Публичные функции.
5. Секции отделяются баннерами-комментариями (см. §5).

---

## 2. Базовые типы

### 2.1 Целочисленные и вещественные типы

Всегда используются собственные типы из `Types.h`, а не `int`/`float`:

```c
typedef char i8;
typedef short i16;
typedef int i32;
typedef long long int i64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef float f32;
typedef double f64;
```

- `real` — `f32` по умолчанию, `f64` при `SC_REAL_64_BIT`.
- Приведение — через макросы `to_i32(x)`, `to_u64(x)`, `to_f32(x)` и т.п.
- Для размеров/индексов в API обычно `i64`; для счётчиков в структурах — `i32`/`i64`
  в зависимости от контейнера.

### 2.2 Векторная математика

Простые типы — **нижний регистр без префикса `Sc`**:

`v2`, `v2i`, `v2o`, `v3`, `v3i`, `v3o`, `v4`, `v4i`, `v4o`,
`m3`, `m4`, `quat`, `v3a`, `v4a`, `m3a`, `m4a`, `bitset64`, `bitset256`,
`bitset512`, `bitset1024`.

Поля векторов: `X`, `Y`, `Z`, `W`; альтернативные имена через union:
`Width/Height`, `Min/Max`, `R/G/B/A`, `Hue/Saturation/Value`,
`Pitch/Yaw/Roll`. Матрицы: `M00..M33`, строки `R0..R3`, массивы `V[4]`.

### 2.3 Составные публичные типы

Сложные сущности — **PascalCase с префиксом `Sc`**:

```c
ScString, ScStringView, ScListHeader, ScDictHeader,
ScWindow, ScRaster, ScFont, ScUiWidget, ScUiWidgetConfig,
ScJsonToken, ScGltf, ScQoaDesc, ScTrueTypeFontInfo,
ScEcsEntityId, ScEcsComponentId
```

Исключения: внутренние структуры реализации могут называться без `Sc`
(например `EarrHeader` в `Sc.c`, `ScJobStorage` — тоже `Sc`), но новый
публичный тип должен быть `ScXxx`.

### 2.4 Перечисления

Имя типа — `Sc<Домен>`, значения — `<ИмяТипа>_<Значение>` в PascalCase:

```c
typedef enum
{
    ScResult_Error = 0,
    ScResult_Success = 1,
    ScResult_Warning = 2
} ScResult;

typedef enum
{
    ScLogLevel_Info,
    ScLogLevel_Debug,
    ScLogLevel_Warn,
    ScLogLevel_Error
} ScLogLevel;
```

Часто встречающиеся домены: `ScResult_*`, `ScLogLevel_*`, `ScUiState_*`,
`ScUiWidgetType_*`, `ScUiMetricType_*`, `ScEventType_*`, `ScKey_*`,
`ScMouseKey_*`, `ScJsonTokenType_*`, `ScJsonError_*`, `ScDirectoryItemType_*`,
`ScPathItemType_*`, `ScMimeType_*`.

Не используйте голые `RED`, `SUCCESS`, `TYPE_FOO` — всегда с префиксом типа.

---

## 3. Именование функций

### 3.1 Публичный API

Формат:

```text
sc_<module>_<verb>[_<qualifier>]
```

`<module>` совпадает с именем файла/домена в нижнем регистре:

| Модуль | Префикс | Примеры |
|---|---|---|
| `Sc.c` | `sc_` | `sc_sleep_ms`, `sc_format`, `sc_file_read`, `sc_path_combine` |
| `Ecs.c` | `sc_ecs_` | `sc_ecs_world_create`, `sc_ecs_entity_set` |
| `Ui.c` | `sc_ui_` | `sc_ui_widget_begin`, `sc_ui_layout` |
| `Raster.c` | `sc_raster_` | `sc_raster_fill_rect` |
| `Window.c` | `sc_window_` | `sc_window_create`, `sc_window_update` |
| `Png.c` | `sc_png_` | `sc_png_read`, `sc_png_write` |
| `Json.c` | `sc_json_` | `sc_json_parse`, `sc_json_token_int` |
| `Qoa.c` | `sc_qoa_` | `sc_qoa_encode`, `sc_qoa_decode` |
| `Font.c` | `sc_font_` | `sc_font_new`, `sc_font_wrap_text` |

Используемые глаголы (порядок важен):

`new`, `create`, `init`, `destroy`, `free`, `deinit`,
`get`, `set`, `add`, `remove`, `clear`, `reserve`, `pop`,
`read`, `write`, `append`, `load`, `unload`,
`encode`, `decode`, `parse`, `format`,
`copy`, `compare`, `index_of`, `last_index_of`, `substring`,
`to_upper`, `to_lower`, `replace`, `combine`,
`print`, `validate`, `start`, `end`,
`lock`, `unlock`, `try_read_lock`, `wait`, `signal`, `broadcast`,
`bind`, `unbind`, `attach`, `cancel`.

### 3.2 Суффиксы и их смысл

| Суффикс | Значение |
|---|---|
| `_new` | конструктор, возвращает значение (или указатель на выделенный объект) |
| `_init` | инициализация существующего объекта, обычно `void` |
| `_create` | создание ресурса/хендла; часто возвращает `ScResult` или хендл |
| `_destroy` | освобождение ресурса (парный к `_create`/`_new`) |
| `_free` | освобождение памяти контейнера/буфера |
| `_get` | получить значение/указатель |
| `_set` | установить значение |
| `_add` / `_remove` | добавить/удалить элемент |
| `_read` / `_write` | файловый или потоковый ввод-вывод |
| `_load` / `_unload` | загрузка/выгрузка ресурса целиком |
| `_decode` / `_encode` | преобразование формата в памяти |
| `_ext` | расширенная версия с дополнительными аргументами |
| `_ext_r` | «raw»-реализация для debug-extension pattern |
| `_ext_d` | debug-версия с `__FILE__`, `__LINE__`, `__FUNCTION__` |
| `_wo_alloc` | результат не выделяется в куче (заимствованный/статический указатель) |
| `_by_id`, `_by_index` | доступ по идентификатору/индексу |
| `_recursive` | рекурсивная операция |
| `_as_float`, `_as_string` | альтернативное представление результата |
| `_v2`, `_2`, `_3` | альтернативная реализация; используйте только для совместимости |

Пример полной цепочки:

```c
sc_string_compare(...)          // публичный макрос
sc_string_compare_ext_r(...)    // raw-реализация
sc_string_compare_ext_d(...)    // debug-реализация с диагностикой
sc_string_compare_ext_ext_r(...) // raw-реализация версии с длиной
```

### 3.3 Математические функции

Математика — исключение: **без префикса `sc_`**, с префиксом типа:

```c
v2_new, v2_add, v2_dot, v2_normalize
v3_cross, v3_length, v3_lerp
v4_rgba, v4_mulv
m3_inverse, m4_perspective
quat_new, quat_slerp, quat_to_m4
real_sqrt, real_equal, i32_pow, isqrt
```

Исторические исключения: `ROUND_MAX`, `ROUND_MIN`, `view_get`,
`view_projection_get_frustrum`, `alt_hash`.

### 3.4 Макросы

Три категории:

1. **Константы** — `SC_UPPER_SNAKE`:
   `SC_I32_MAX`, `SC_U64_MAX`, `SC_F32_EPSILON`, `SC_IMAGE_DATA_SIZE_MAX`,
   `SC_QOA_FRAME_LEN`, `SC_BUILD_DEBUG`, `SC_PLATFORM_LINUX`.

2. **Типоподобные/общие макросы** — `ScPascalCase`:
   `ScNull`, `ScInvalidId`, `ScMax`, `ScMin`, `ScSwap`, `ScArrayCount`,
   `ScOffsetOf`, `ScAlign`, `ScKb`, `ScMb`, `ScGb`,
   `ScColor_RGBA`, `ScColor_ARGB`.

3. **Функциональные макросы модуля** — `sc_<module>_<name>`:
   `sc_list_add`, `sc_list_for_each`, `sc_dict_i_get`,
   `sc_builder_append_char`, `sc_string_new`, `sc_ui_widget_begin`,
   `sc_test_condition`.

Правила для функциональных макросов:

- Возвращают значение через statement expression:
  ```c
  #define sc_list_add(pList, ...)                        \
      ({                                                 \
          __typeof__(*pList) localItem = __VA_ARGS__;    \
          pList = sc_list_add_ext(                       \
              pList, (void*)&localItem, sizeof(*pList)); \
          pList;                                         \
      })
  ```
- Первый аргумент-контейнер часто переприсваивается внутри макроса — передавайте
  **lvalue** (`pList = sc_list_add(pList, item)` не нужно, макрос сам обновит
  `pList`; но `pList` должен быть переменной).
- Не добавляйте побочные эффекты в аргументы: они могут вычисляться несколько раз.
- Для макросов-предикатов используйте `is_`/`has_`/`contains`:
  `sc_dict_s_contains`, `sc_mutex_is_locked`.
- Не используйте `do { ... } while (0)` — в проекте принят GNU statement
  expression. Это осознанное решение: код собирается clang с GNU-расширениями.

### 3.5 Локальные/статические функции

Даже `static`-функции в `.c` сохраняют префикс модуля:

```c
static void sc_json_add_token(...);
static u32 sc_json_str4_to_u32(...);
static ScEcsEntity* sc_ecs_entity_by_id(...);
```

Платформенные реализации в `Window.c` используют префикс платформы:

```c
static void xcb_sc_window_create(...);
static void win32_sc_window_create(...);
static ScKey xcb_sc_key_from_native(...);
```

Внутренние общие функции, не попавшие в публичный заголовок, могут начинаться
с `_sc_` (`_sc_dict_set_int_storage_to_default`, `_sc_test_create_string_expected`).
Новый код должен по возможности избегать такого стиля и делать функцию `static`.

---

## 4. Именование переменных, полей и констант

### 4.1 Поля структур

**PascalCase**, префиксы по смыслу:

| Префикс/имя | Значение | Примеры |
|---|---|---|
| `p` | указатель | `pData`, `pName`, `pBackend`, `pGraphics`, `pPath` |
| `a` | массив/список | `aKeys`, `aBuffers`, `aChildren`, `aTokens`, `aDelims` |
| `h` | хеш-таблица/словарь/хендл | `hReg`, `hCharTable`, `hNameToId` |
| `Is` | булев флаг (`i8`/`i32`) | `IsAlive`, `IsHandled`, `IsFinished`, `IsVsync` |
| `Should` | намерение/флаг | `ShouldUseGradient`, `ShouldAddText` |
| `Has` | наличие | `HasFont` (в примерах) |
| `Count` | количество | `Count`, `JobsCount`, `Frames` |
| `Capacity` | ёмкость | `Capacity` |
| `Size` | размер в байтах/единицах | `Size`, `NameLength`, `MessageSize` |
| `Length` | длина (часто в кодпоинтах) | `Length`, `TextLength` |
| `Id` | идентификатор | `Id`, `AssetId`, `PanelId` |
| `Min`/`Max` | границы | `RangeMin`, `RangeMax`, `MinSize`, `MaxSize` |
| `Type` | тип/вариант | `Type`, `KeyType`, `WidgetType` |
| `Flag` | режим/флаг | `Flag`, `ArenaFlag` |

Пример из `ScWindow`:

```c
typedef struct
{
    i8 IsAlive;
    i8 IsMaximized;
    i8 IsFullscreen;
    i8 IsGrabed;
    i8 aKeyCounter[ScKey_Count];

    const char* pName;
    v2 Size;
    v2 MinSize;
    v2 MaxSize;
    v2 Position;
    v2 Mouse;
    ScCall OnEvent;
    ScAction aKeys[ScKey_Count];
    ScAction aMouseKeys[ScMouseKey_Count];
    void* pBackend;
    void* pGraphics;
} ScWindow;
```

### 4.2 Локальные переменные

- Новый код: **PascalCase** (`bufferSize`, `pNewHdr`, `itemsLeft`, `isFinished`).
- В старом коде встречается lowerCamel (`stringLength`, `textLength`) — не
  копируйте это в новый код, но и не переименовывайте без необходимости.
- Индексы: `i`, `j`, `k`, `row`, `col`, `ind`, `index`.
- Указатели: `pXxx`; массивы: `aXxx`; булевы: `isXxx`, `shouldXxx`, `hasXxx`.
- Локальные константы: `c_xxx` в нижнем регистре:
  ```c
  const i32 c_convert_to_rgba = 1;
  const f32 c_bitmap_width = ...;
  const i32 c_max_size = 2 * 1024;
  ```
- Глобальное состояние модуля: `g` или `gXxx`:
  ```c
  static struct { ... } g = {};
  static ScLogStorage gScLog = {};
  static ScJobStorage gJobStorage = {};
  ```
  `g_`-префикс (`g_TimeString`) встречается в старом коде.

### 4.3 Константы и sentinel-значения

- `ScInvalidId` (`-1337`) — невалидный id ассета/шрифта/текстуры.
- `ScEcsInvalidId` (`-1`) — невалидный id ECS.
- `SC_DICT_EMPTY_KEY` — пустой ключ целочисленного словаря.
- `ScNull` (`(void*)0`) — нулевой указатель; в новом коде используйте `ScNull`,
  не `NULL` (оба допустимы, но `ScNull` — стиль проекта).
- Невалидный индекс — `-1`.
- Размеры — `ScKb`, `ScMb`, `ScGb` (осторожно: это `i64`-выражения).

---

## 5. Форматирование

Правила зафиксированы в `.clang-format`:

| Параметр | Значение |
|---|---|
| Standard | Auto (C99) |
| IndentWidth / TabWidth | 4 / 4 |
| UseTab | Never |
| ColumnLimit | 0 (переносы вручную) |
| PointerAlignment | Left (`real* p`, `ScFont* pFont`) |
| AlignAfterOpenBracket | DontAlign |
| BinPackParameters | false |
| BreakBeforeBraces | Custom |
| AfterFunction / AfterStruct / AfterEnum / AfterUnion | true |
| AfterControlStatement | Always |
| BeforeElse / BeforeWhile | true |
| AfterCaseLabel | true |
| AllowShortIfStatements / Loops / Blocks | false |
| SortIncludes | true |
| AlignConsecutiveAssignments | false |
| Cpp11BracedListStyle | false |
| SpacesInContainerLiterals | true |

Практические следствия:

```c
ScResult
sc_raster_init(ScRaster* pRaster, i32 width, i32 height)
{
    sc_assert_not_null(pRaster);

    if (pRaster == ScNull)
        return ScResult_Error;

    for (i32 b = 0; b < 2; ++b)
    {
        ScRasterBuffer* pBuffer = &pRaster->aBuffers[b];
        pBuffer->pData = sc_memory_allocate(bufferSize);
    }

    return ScResult_Success;
}
```

- Тип возвращаемого значения — на отдельной строке, имя функции — на следующей.
- Фигурная скобка функции/структуры/`if`/`for`/`switch` — на новой строке.
- `else` — с новой строки.
- `case` — на одном уровне с блоком `switch`, после метки — новая строка.
- Однострочные `if`/`for` без скобок допустимы, но только с одним оператором;
  `AllowShortBlocksOnASingleLine: false` запрещает `{ ... }` в одну строку.
- Инициализация структур — designated initializers:
  ```c
  ScWindowConfig conf = {
      .pName = "Sc Ui Sample",
      .UseGraphics = 1,
      .Size = { .Width = 800, .Height = 600 },
  };
  ```
- Пустая инициализация — `= {};` или `= { 0 };`.
- Compound literal в вызове:
  ```c
  sc_window_create(&window, (ScWindowConfig) {
      .pName = "App",
      .Size = { .Width = 1280, .Height = 720 },
  });
  ```
- Не выравнивайте `=` в группах.
- Комментарии — `//` для коротких строковых заметок, `/* ... */` для блоков
  документации (см. §6).
- Между функциями — одна пустая строка.
- Внутри функции логические блоки можно разделять пустой строкой; вложенные
  блоки часто оформляются `{ ... }` даже без необходимости (стиль проекта).

---

## 6. Комментарии и документация

Комментарий — обычный блок `/* ... */`. Содержимое пишется с одним
ведущим пробелом, без звёздочек, `@param` и декоративных рамок.

Пример:

```c
/*
 key - Buffer to be hashed.
 len - @key length, in bytes.
 seed - 64-bit seed used to alter the hash result predictably.
 secret - Triplet of 64-bit secrets used to alter hash result predictably.
 Returns a 64-bit hash.
 */
```

Правила:

- Открывающая строка — `/*`.
- Каждая строка содержимого начинается с одного пробела.
- Закрывающая строка — ` */` (один пробел перед `*/`).
- Параметр оформляется как `имя - описание.` — без выравнивания и без `@param`.
- Возвращаемое значение — строкой `Returns ...`.
- Сводное описание/назначение идёт первыми строками блока, до параметров.
- Пустая строка внутри блока — действительно пустая, без `*`.
- Не используйте `*`-префиксы, `@param`, декоративные баннеры из `#`/`===`.
- В начале `.c`/`.h` — краткое описание модуля: назначение, платформа,
  владение памятью, известные ограничения.
- Публичные функции в `.h` документируются: что делают, что возвращают,
  кто владеет памятью, что можно передать `NULL`.
- Внутри `.c` секции и группы функций разделяются таким же блоком.
- Для важных замечаний допустимы теги `NOTE:`, `TODO:`, `FIX:` в начале
  строки внутри блока.
- Не комментируйте очевидное (`i++ // увеличиваем i`).
- Русский и английский в комментариях допустимы; идентификаторы — только
  латиница. Новые публичные комментарии лучше писать по-русски.
- Сторонний код (`Hash.c`, `RapidHash.c`, `Crypt.c`) сохраняет свои
  лицензионные комментарии; комментарии Sc оформляются отдельными блоками
  вокруг публичных обёрток.

---

## 7. Проектирование API

### 7.1 Общие принципы

- Явность важнее краткости: лучше длинное имя, чем неоднозначное.
- Один модуль — одна ответственность; не смешивайте UI, файлы и математику.
- Публичный API — в `.h`; всё остальное — `static` в `.c`.
- Конфигурация сложных объектов — отдельная `ScXxxConfig` + `..._new(cfg)` /
  `..._ext(cfg)`.
- Для >3 аргументов предпочтительна config-структура с designated initializer.
- Маленькие значения (`v2`, `v3`, `m4`, `quat`, `ScFont`, `ScGltf`,
  `ScGifAnim`) возвращаются по значению.
- Несколько результатов — через out-параметры:
  ```c
  i32 m4_transform_decompose(m4 transform, v3* translation, v3* rotation, v3* scale);
  ```
- Идентификаторы ресурсов — `i64` + sentinel `ScInvalidId`/`-1`.
- Строки — `char*`, обычно NUL-terminated; длина передаётся отдельно, если
  строка может быть не NUL-terminated.
- Для read-only входов используйте `const char*`/`const void*`; в легаси-API
  часто `char*` — не ломайте существующие сигнатуры без причины.

### 7.2 Владение памятью

- Всё, что выделено `sc_memory_allocate`, освобождается `sc_memory_free`.
- Контейнеры (`ScList`, `ScDict`, `ScString`, `ScBuilder`, `ScGrid`) имеют
  собственные функции освобождения: `sc_list_free`, `sc_dict_free`,
  `sc_string_destroy`, `sc_builder_destroy`, `sc_grid_free`.
- Функции, возвращающие `char*`, обычно возвращают **новый** буфер. Если
  функция возвращает заимствованный указатель, это фиксируется в имени
  (`_wo_alloc`) и/или комментарии.
- `sc_file_read` возвращает NUL-terminated буфер, выделенный в куче.
- `sc_string_*` (кроме `_wo_alloc` и view) возвращают новый объект.
- `sc_list_*` и `sc_dict_*` переприсваивают указатель-контейнер; исходный
  указатель после роста невалиден.

### 7.3 Ошибки и статусы

- `ScResult_Success` / `ScResult_Error` / `ScResult_Warning` — для операций,
  где важен статус.
- Функции, возвращающие указатель, при ошибке возвращают `ScNull`.
- Функции, возвращающие число/размер, при ошибке возвращают `0` или `-1`
  (см. комментарий конкретной функции).
- В debug-сборке на границах API — `sc_assert_not_null`/`sc_assert`.
- `sc_guard`/`sc_guard_not_null` — для ситуаций «программист сломал инвариант»;
  в отличие от `sc_assert`, работает и в release.
- `sc_break` не вызывайте напрямую; используйте `sc_assert`/`sc_guard`.
- Диагностика — через `sc_log_warn`/`sc_log_erro`, а не `printf`, в библиотечном
  коде. В сэмплах `printf` допустим.

### 7.4 Глобальное состояние

Допускается только документированный модульный singleton:

- ECS: одно глобальное `ScEcsWorld` (`sc_ecs_world_create/destroy`).
- UI: глобальное состояние `g` (`sc_ui_frame_begin/end`).
- Log: `gScLog` (`sc_log_init_default`/`sc_log_deinit`).
- Memory: `gSm` (арены/аллокатор).
- Test: `g` (реестр тестов).

Правила:

- Инициализация — явная, один раз.
- Повторная инициализация должна либо игнорироваться, либо логировать ошибку.
- Освобождение — парной `..._destroy`/`..._deinit`.
- Не добавляйте новое глобальное состояние без необходимости.

### 7.5 Debug extension pattern

Для функций, которым нужны проверки аргументов с диагностикой, используется
паттерн:

```c
#if SC_DEBUG_EXTENSION_PATTERN_DEBUG == 1
#define sc_string_get_length(str) \
    sc_string_get_length_ext_d(str, #str, __FILE__, __LINE__, __FUNCTION__)
#else
#define sc_string_get_length(str) sc_string_get_length_ext_r(str)
#endif
```

- `_ext_r` — реальная реализация.
- `_ext_d` — обёртка, проверяющая аргументы и логирующая `[file:line -> func]`.
- `SC_DEBUG_EXTENSION_PATTERN_DEEP_DEBUG` — более медленная и подробная
  валидация.
- Новые API по возможности следуют этому паттерну, если важна диагностика
  ошибок вызова.

---

## 8. Память и арены

- В библиотечном коде **не используйте `malloc`/`free` напрямую**; исключения:
  реализация аллокатора/арен и сторонние файлы (`Hash.c`, `RapidHash.c`).
- `sc_memory_allocate` идёт в текущую арену, если она привязана
  (`sc_arena_bind`), иначе в `malloc`.
- `sc_memory_free` **ничего не делает**, если привязана арена. Это важно:
  не полагайтесь на освобождение внутри арены, очищайте арену целиком
  (`sc_arena_clear`) или уничтожайте её (`sc_arena_destroy`).
- Арена не растёт: при переполнении `sc_arena_allocate` вернёт `ScNull`
  и сработает `sc_guard`.
- Не смешивайте память, выделенную разными механизмами.

---

## 9. Тесты и примеры

### 9.1 Тесты

- Файл: `Source/Tests/Sc<Модуль>.c` (для подмодулей — `Gfx/ScRaster.c`,
  `Sound/ScQoa.c`, `Text/ScFont.c`).
- Функции тестов: `sc_<module>_<case>_test` или `sc_<module>_<case>`:
  `sc_list_add_and_remove_test`, `sc_dict_grow_test`, `sc_grid_basic`.
- Групповой запуск:

  ```c
  void
  sc_auto_raster()
  {
      sc_test_file();

      sc_test_func(sc_raster_init_test());
      sc_test_func(sc_raster_set_pixel_test());
  }
  ```

- Регистрация в `Source/Tests/ScAuto.c` (extern + вызов в `sc_auto()`).
- Проверки: `sc_test_condition`, `sc_test_i32_equal`, `sc_test_f32_equal`,
  `sc_test_string_equals`, `sc_test_v2_equal`/`v3`/`v4`, `sc_test_quat_equal`.
- Для диагностики значений: `sc_test_i32_value`, `sc_test_string_value`,
  `sc_test_f32_value`, `sc_test_v3_value` и т.п.
- Тестовый файл добавляется в `Source/Tests/Test.masuka` → `source: [...]`.

### 9.2 Примеры

- `Source/Samples/<Name>/<Name>.c` + `<Name>.masuka`.
- Пример должен быть самодостаточным `main()` и демонстрировать один сценарий.
- Комментарии в примере объясняют порядок вызовов и подводные камни.
- Регистрация проекта — в корневом `vince.masuka`/`vince_build.sh` (генерируется
  Masuka).

---

## 10. Сборка и новые модули

Новый модуль:

1. Создать `Source/Sc/<Домен>/<Name>.h` и `.c` с guard `SC_<NAME>_H`.
2. Добавить `.c` в `Source/Sc/Sc.masuka` → `source: [...]`.
3. При необходимости добавить системные библиотеки в `linux.links` /
   `windows.links`.
4. Публичный API — в `.h`; `#include "Sc/<Домен>/<Name>.h"`.
5. Добавить тесты и зарегистрировать их в `ScAuto.c` + `Test.masuka`.
6. Обновить `Prompts/Skills/ScUsage.md` (кратко) и комментарий в начале `.h`.
7. Не добавлять `.c` в сборку, если модуль экспериментальный; тогда явно
   пометить его как WIP в заголовке.

Текущие ограничения сборки:

- `Gfx/Vk.c`, `Gfx/Vulkan.c` не входят в `Sc.masuka` (нужен Vulkan SDK,
  Linux-реализация; Windows — `#error`).
- `Data/Asset.c`, `Data/RapidHash.c` не входят
  в `Sc.masuka` (WIP/сторонний код).
- `Math.c` пуст: математика реализована inline в `Math.h`.

---

## 11. Чек-лист перед коммитом

- [ ] Имена типов/функций/макросов соответствуют §2–§4.
- [ ] Публичные функции имеют префикс модуля `sc_<module>_`.
- [ ] Структуры инициализируются designated initializers.
- [ ] Память выделяется/освобождается через `sc_memory_*` или API контейнера.
- [ ] Владение и возврат при ошибке описаны в комментарии.
- [ ] Нет `malloc`/`free` в новом библиотечном коде.
- [ ] Нет скрытых глобальных состояний без `..._init`/`..._destroy`.
- [ ] `sc_assert`/`sc_guard`/`sc_log_*` использованы по назначению.
- [ ] Код отформатирован по `.clang-format` (4 пробела, Allman, `real* p`).
- [ ] Файл добавлен в соответствующий `.masuka`.
- [ ] Тест добавлен и зарегистрирован в `ScAuto.c`.
- [ ] Для новых подводных камней добавлен `NOTE:`/`TODO:`.

---

## 12. Известные исторические отступления

Не копируйте эти места как образец; при правках можно постепенно приводить их
к общим правилам:

- `UI.h` использует guard `UI_H`, а не `SC_UI_H`.
- `Math.h`: `ROUND_MAX`, `ROUND_MIN`, `view_get`, `view_projection_get_frustrum`
  без `sc_`-префикса; `i32_pow`/`isqrt` без префикса типа.
- `sc_dict_i_get`/`sc_dict_s_get` опасны при отсутствующем ключе: сначала
  проверяйте `sc_dict_i_contains`/`sc_dict_s_contains`.
- `sc_list_pop` удаляет **первый** элемент (реализация копирует с `pList + stride`),
  а не последний; имя историческое.
- `sc_list_deep_copy` на самом деле побайтово копирует массив; вложенные
  указатели не копируются.
- `sc_string_new_trimed` содержит ошибку записи за границу буфера; не используйте
  без исправления.
- `sc_builder_append_string` помечен в заголовке как содержащий баг; для
  надёжности используйте `pSb = sc_builder_append_string_ext(...)`.
- `sc_to_string`-функции не добавляют `\0`; буфер должен быть обнулён заранее.
- `sc_directory_get_items` на Linux при `IsAbsolutePath = 0` возвращает указатели
  внутрь `dirent`, которые инвалидируются следующим `readdir`; используйте
  абсолютные пути.
- `sc_job_*` — экспериментальный код: `sc_job_init` не создаёт мьютекс/condition,
  `sc_job_deinit` не объявлен в заголовке. Не используйте в продакшене без
  доработки.
- `ScRaster`/`Ui`/`Window` — активно развивающиеся модули; проверяйте
  актуальные комментарии в `.h`.
