# Sc (Simple C) — руководство по API и использованию

Документ описывает **фактическое** поведение публичного API `Source/Sc/**`:
сигнатуры, владение памятью, порядок вызовов и известные ограничения.
Он дополняет `Convention.md` (правила написания кода) и не заменяет чтение
заголовков.

Обозначения статусов модулей:

| Статус | Значение |
|---|---|
| `READY` | проверено тестами/сэмплами, можно использовать |
| `TEST` | есть автотесты, но API может меняться |
| `WIP` | экспериментальный код, возможны ошибки и утечки |
| `EXCLUDED` | не входит в `Source/Sc/Sc.masuka` |

Важно: в проекте есть исторические баги, которые нельзя «исправлять молча»
в чужом коде. В документе они помечены **NOTE** и описывают, как обойти
проблему, а не как «правильно» её использовать.

---

## 0. Подключение и сборка

Библиотека собирается как `StaticLib` через `Source/Sc/Sc.masuka`.
Потребитель получает каталог `Source` и пишет:

```c
#include <Sc/Sc.h>       // базовый API: строки, списки, файлы, память...
#include <Sc/Types.h>    // базовые типы (обычно уже включён из Sc.h)
#include <Sc/Math.h>     // векторы, матрицы, кватернионы
```

Внутри самой библиотеки используются include вида `"Sc/Sc.h"`,
`"Sc/Math.h"` (см. `Convention.md`).

Подключение к проекту Masuka:

```text
include: [ "Dependencies/Sc/Source" ]
links:   [ "pathcch", "shell32", "bcrypt", "user32", "gdi32" ] // Windows
links:   [ "m", "pthread", "dl", "xcb", "xcb-icccm", "xcb-keysyms",
           "xcb-xkb", "xcb-shm" ]                              // Linux
```

Что реально входит в сборку (актуальный список — `source:` в
`Sc.masuka`):

- ядро: `Sc.c`, `Types.c`, `Math.c`, `MathPrint.c`, `Ecs.c`, `Reflect.c`,
  `Test.c`, `Ai.c`;
- `Data/Crypt.c`, `Data/Hash.c`, `Data/Mime.c`;
- `Gfx/Raster.c`, `Gfx/Ui.c`, `Gfx/UiBackends/RasterBackend.c`,
  `Gfx/Window.c`;
- `Image/Gif.c`, `Image/Image.c`, `Image/ImageBuffer.c`, `Image/Jpg.c`,
  `Image/Png.c`, `Image/Qoi.c`;
- `Parsers/Gltf.c`, `Parsers/Json.c`;
- `Sound/Qoa.c`;
- `Text/Font.c`, `Text/TrueType.c`.

Не входят в сборку: `Gfx/Vk.c`, `Gfx/Vulkan.c`, `Data/Asset.c`,
`Data/RapidHash.c`.
Комментарий в начале `Sc.masuka` про исключённый `Gfx/Window.c` устарел:
`Window.c`, `Font.c` и `TrueType.c` уже перечислены в `source:`.

---

## 1. Базовые типы, макросы и система

### 1.1 Целочисленные типы

`Types.h` объявляет:

```c
typedef char i8;               typedef unsigned char u8;
typedef short i16;             typedef unsigned short u16;
typedef int i32;               typedef unsigned int u32;
typedef long long int i64;     typedef unsigned long long u64;
typedef float f32;             typedef double f64;
```

`real` — это `f32`, если не определён `SC_REAL_64_BIT`; иначе `f64`.
Приведения делайте через `to_i32(x)`, `to_u64(x)`, `to_f32(x)` и т.п.

Полезные константы: `SC_I32_MAX`, `SC_I64_MAX`, `SC_I64_MIN`,
`SC_U32_MAX`, `SC_U64_MAX`, `SC_F32_EPSILON`, `SC_F32_MAX`.
`ScNull` — `(void*)0`; в новом коде используйте его вместо `NULL`.

### 1.2 Системная информация

```c
typedef struct
{
    ScBuild Build;       // Debug / Release / Distribution
    ScOs Os;             // Linux / Windows
    ScReal Real;         // 32 / 64 bit
    ScEndian Endian;     // Little / Big
} ScSystemInfo;

ScSystemInfo sc_system_info_get();
void sc_system_info_print();
i32 sc_system_cpu_count();  // всегда >= 1
```

Строковые представления:

```c
const char* sc_build_to_string(ScBuild build);
const char* sc_os_to_string(ScOs os);
const char* sc_real_to_string(ScReal scReal);
const char* sc_endian_to_string(ScEndian scEndian);
```

### 1.3 Цвет

```c
typedef struct { u8 R, G, B, A; } ScColor;

// Упаковка в 32-битное значение.
ScColor_RGBA(r, g, b, a); // (a << 24) | (b << 16) | (g << 8) | r
ScColor_ARGB(a, r, g, b); // (a << 24) | (r << 16) | (g << 8) | b
```

`ScColor_R/G/B/A(x)` читают поля по указателю.

Терминальные цвета — строковые макросы:
`ScTerminalRed("text")`, `ScTerminalGreen`, `ScTerminalYellow`,
`ScTerminalBlue`, `ScTerminalWhite`, `ScTerminalMagneta`,
`ScTerminalOrange`, `ScTerminalRedActive`.

### 1.4 Общие утилиты

```c
void sc_copy(void* pvWrite, void* pvRead, u64 size);
i32  sc_i32_sign(i32 v);
i32  sc_i32_abs(i32 v);
i32  sc_f32_sign(f32 v);
f32  sc_f32_abs(f32 v);
i32  sc_bits_count(typeOrValue); // sizeof(...) * 8
```

Макросы:

```c
ScSwap(x, y);                    // обмен значениями
ScMax(x, y); ScMin(x, y);
ScMinMax(x, min, max);
ScMinMaxV2(x, v);                // v.Min / v.Max
sc_if_null(ptr, fallback);       // ptr ? ptr : fallback
sc_helper_tonr(n);               // true первые n вызовов
sc_helper_tofr();                // true только при первом вызове
sc_helper_fofr();                // false только при первом вызове
```

Размеры:

```c
ScKb(4);  // 4 * 1024
ScMb(2);  // 2 * 1024 * 1024
ScGb(1);
ScToKb(bytes); ScToMb(bytes); ScToGb(bytes); // обратно, f64
```

Прочее:

```c
ScOffsetOf(Type, Field)
ScAlign(byte)                    // __attribute__((aligned(byte)))
ScAlignOf(Type)
ScArrayCount(array)
ScBitAnd(flag, bit)
ScBitNotAnd(flag, bit)
sc_char_array_set(charArr, pString); // копирует строку с завершающим '\0'
```

### 1.5 Проверки и падения

```c
void sc_break(const char* msg, const char* file, int line, const char* condition);

sc_assert(cond);          // только Debug
sc_assert_not_null(p);
sc_assert_null(p);
sc_assert_break();

sc_guard(cond);           // Debug и Release
sc_guard_not_null(p);
sc_guard_null(p);
sc_guard_not_impl();
sc_guard_not_used();
sc_guard_call_once();
```

`sc_assert` в release превращается в `((void)0)`.
`sc_guard`/`sc_guard_not_null` вызывают `sc_break` всегда, поэтому это
«инвариант сломан» — не используйте для ожидаемых ошибок ввода.

### 1.6 Строковые/контейнерные типы

```c
typedef struct { i32 Length; i32 Size; char* pData; } ScString;
typedef struct { i32 Length; i32 Size; char* pData; } ScStringView;
typedef struct { i64 Length; void* pData; } ScData;

typedef enum
{
    ScResult_Error = 0,
    ScResult_Success = 1,
    ScResult_Warning = 2
} ScResult;
```

Важно: `ScString` — это **заголовок, который лежит в памяти перед
символами**. Пользователь обычно держит `char*`, а не `ScString*`
(см. §3.4).

### 1.7 Векторные типы

`v2`, `v2i`, `v2o`, `v3`, `v3i`, `v3o`, `v4`, `v4i`, `v4o`, `m3`, `m4`,
`quat`, `v3a`, `v4a`, `m3a`, `m4a`.

Поля: `X/Y/Z/W`, алиасы `Width/Height`, `Min/Max`, `R/G/B/A`,
`Hue/Saturation/Value`, `Pitch/Yaw/Roll`; массивы `V[2..4]`.
Матрицы: `M00..M33`, строки `R0..R3`, массив `V[4]`, `M[4][4]`.

Конструкторы и преобразования:

```c
v2_new(x, y); v2_0(); v2_v3(v); v2_array(a);
v3_new(x, y, z); v3_v2(v); v3_v2v(v, z); v3_v4(v); v3_rgb(r, g, b);
v4_new(x, y, z, w); v4_v3(v); v4_v3v(v, w);
v4_to_argb(color);
```

**NOTE:** в `Types.h` есть сломанные исторические макросы:
`v2i_new(v)` (использует неопределённые `x`, `y`), `v4_array(aVals)` и
`v4_array_w(aVals, s)` (нет закрывающих скобок). Не используйте их;
создавайте значения через compound literal:

```c
v2i a = { .X = 1, .Y = 2 };
v4 b = { .X = 1, .Y = 2, .Z = 3, .W = 4 };
```

Сравнения: `f32_equal`, `v2_equal`, `v3_equal`, `v4_equal`, `quat_equal`.
`ScAabb` — `{ v3 Min; v3 Max; }`.
`ScSimpleTimer` — `{ f32 _CountSeconds; f32 WaitSeconds; }` (простой
аккумулятор, не путать с `ScTimer`).

### 1.8 Пути к ресурсам (макросы)

```c
asset("models/a.gltf")            // "assets/models/a.gltf"
asset_shader("a.glsl")
asset_texture("a.png")            // "assets/textures/a.png"
asset_cubemap("a.png")
asset_font("a.ttf")
asset_model("a.gltf")
asset_sound("a.qoa")
asset_scene("a")
asset_db("a.db")
asset_localization("a.json")

resource("Models/a.gltf")         // "Resources/Models/a.gltf"
resource_shader("a.glsl")
resource_font("a.ttf")
resource_texture("a.png")
resource_model("a.gltf")          // "Resources/Models/a.gltf"
```

Это только строковые литералы; существование файлов не проверяется.

---

## 2. Память и арены

### 2.1 Обычный аллокатор

```c
void* sc_memory_allocate(u64 size);   // malloc, если арена не привязана
void sc_memory_free(void* pMemory);   // no-op, если арена привязана
```

В Debug можно включить `SC_MEMORY_DEBUG`; тогда используются
`sc_memory_debug_allocate/free` и доступны проверки:

```c
sc_memory_debug_validate();
sc_memory_debug_validate_buffer_overflow();
sc_memory_debug_validate_buffer_underflow();
sc_memory_debug_validate_double_free();
sc_memory_debug_validate_writing_to_free();
```

Правило: всё, что выделено `sc_memory_allocate`, освобождается
`sc_memory_free`. Контейнеры (`ScList`, `ScDict`, `ScString`,
`ScBuilder`, `ScGrid`) имеют собственные `_free`/`_destroy`.

`sc_file_read` возвращает буфер, выделенный этим аллокатором.

### 2.2 Арены

```c
typedef struct
{
    u64 Size;
    i32 Line;
    ScArenaFlag Flag;       // None / DeepClean
    const char* pFile;
} ScArenaConfig;

ScArena* sc_arena_new({ .Size = ScMb(1) }); // макрос, добавит __LINE__/__FILE__
ScArena* sc_arena_new_ext(ScArenaConfig config);
void sc_arena_destroy(ScArena* pArena);
void sc_arena_clear(ScArena* pArena);
void* sc_arena_allocate(ScArena* pArena, u64 size);
void sc_arena_bind(ScArena* pArena);
void sc_arena_unbind();
ScArena* sc_arena_get();
```

Семантика:

- `sc_arena_bind` кладёт арену в стек; `sc_memory_allocate` начинает
  выделять из верхней арены.
- Пока арена привязана, `sc_memory_free` **ничего не делает**. Память
  освобождается только `sc_arena_clear` (сбрасывает `Offset`) или
  `sc_arena_destroy`.
- Арена не растёт. При переполнении `sc_arena_allocate` вернёт `NULL`
  и вызовет `sc_guard`.
- `ScArenaFlag_DeepClean` заставляет `sc_arena_clear` занулять всю память.

**NOTE (баг):** `sc_arena_bind`/`sc_arena_unbind` передают
`&gSm.ArenaStack.Mutex` в `sc_mutex_lock`, тогда как `sc_mutex_lock`
ожидает сам handle (`ScMutex`). В текущем виде привязка арен
небезопасна. Используйте арены без bind — например, `sc_ui_frame_begin`
делает это внутри себя, но и там это историческая реализация.
Для нового кода предпочтительнее явные `sc_arena_allocate` + `clear`.

---

## 3. Строки, UTF-8, разбор и форматирование

### 3.1 UTF-8

```c
u64 sc_utf8_unicode_size(u32* aUnicodes, u64 length); // байт для code points
i64 sc_utf8_length(char* pInput);                     // число code points
u64 sc_utf8_size(char* pInput);                       // число байт до '\0'
i32 sc_utf8_encode(char* pOutput, u32 codepoint);     // записано байт
u32 sc_utf8_decode(char* pInput, i32* pBytesCount);   // code point
void sc_utf8_get_unicode_text(i32* pUnicodeText, char* pUtf8Text, i64* pTextLength);
```

`sc_utf8_length` считает **символы**, `sc_utf8_size` — **байты**.
Не путайте их с `sc_string_get_length`, которая тоже считает байты.

### 3.2 C-строки (без объекта)

```c
i64 sc_string_get_length(char* pStr);                 // байты до '\0'
u64 sc_string_get_length_to_delimiters(char* pStr, char aDelims[], u64 delimsLen);
i64 sc_string_hash(char* pString, i32 length);        // djb2
i32 sc_string_compare(char* s0, char* s1);            // 1 = равны, 0 = нет
i32 sc_string_compare_ext(char* s0, char* s1, i64 s0Length); // сравнить первые N
i64 sc_string_index_of(char* pString, char character);       // -1
i64 sc_string_index_of_string(char* pInput, char* pString);  // -1
i64 sc_string_last_index_of(char* pString, char character);  // -1

char* sc_string_substring_length(char* pInput, u64 inputLength, i32 lengthToCut);
char* sc_string_copy(char* pString, i64 stringLength);
char* sc_string_to_upper(char* pString, i64 stringLength);
char* sc_string_to_lower(char* pString, i64 stringLength);
```

Возвращаемые `char*` у `substring_length`, `copy`, `to_upper`, `to_lower`
— это **обычные выделенные C-строки**, не `ScString`. Освобождайте
`sc_memory_free`.

**NOTE:** `sc_string_compare` возвращает `1` только если строки непустые
и полностью совпадают; для пустых строк возвращается `0`. Это
историческое поведение, не `strcmp`-подобное.
`sc_string_compare_ext` с `s0Length == 0` тоже возвращает `0`.

**NOTE:** `sc_string_get_length` — это макрос debug-extension pattern.
Он принимает `char*`; для `const char*` будет предупреждение о
квалификаторах. При необходимости копируйте в `char*` или используйте
`strlen`.

**NOTE:** `sc_string_last_index_of` для непустой строки без искомого
символа корректно возвращает `-1`. Для **пустой** строки реализация
заходит в `do { --pIter; ... }` и читает `pString[-1]` — это выход за
границу буфера. Не вызывайте функцию для пустых строк.

### 3.3 Разбор чисел

```c
typedef struct { i64 IntValue; char* pInput; char* pOutput; } ScParsedInt;

ScParsedInt sc_parse_int_while_int(char* pInput);
i64 sc_parse_int(char* pBuffer, i64 bufferLength);
f64 sc_parse_float(char* pBuffer, i64 bufferLength);
char* sc_parse_skip_space(char* pString);
char* sc_parse_skip_while(char* pString, char* aSymbols, i32 symbolsCount);
```

- `sc_parse_int` идёт с конца и обрабатывает **только цифры**. `'-'`
  приводит к `sc_guard`, поэтому отрицательные числа так не парсятся.
- `sc_parse_float` понимает ведущий `'-'`, точку и цифры, но **не
  понимает экспоненту** (`1e-3`) и не валидирует хвост после точки.
- `sc_parse_int_while_int` читает подряд идущие цифры, возвращает
  `pOutput` на первый нецифровой символ.

Простые указательные макросы:

```c
sc_ptr_skip_until(ptr, ch, stopChar);
sc_ptr_skip_until_two(ptr, ch, stop0, stop1);
sc_ptr_next(ptr, ch);
sc_ptr_next_n(ptr, ch, n);
sc_ptr_diff(ptr0, ptr1); // разница + 1
```

### 3.4 `ScString` — строка с заголовком

Пользователь держит `char* pString`, указывающий на данные сразу после
заголовка `ScString`. Заголовок достаётся так:

```c
ScString* sc_string_header(char* pString);
i64 sc_string_length(char* pString); // длина в code points (поле Length)
i64 sc_string_size(char* pString);   // размер в байтах (поле Size)
```

Создание/уничтожение:

```c
char* sc_string_new(char* pString);                    // копия всей строки
char* sc_string_new_ext(char* pString, i64 length, i64 size);
char* sc_string_new_trimed(char* pString);             // НЕ ИСПОЛЬЗОВАТЬ
void  sc_string_destroy(char* pString);
```

- `sc_string_new` считает `Length` как число UTF-8 code points, а `Size`
  как число байт. `pData` завершается `'\0'`.
- `sc_string_new_ext_ext_r` доверяет переданным `length`/`size`:
  копируется ровно `size` байт, `pString` должен содержать `size` байт.
- **NOTE (баг):** `sc_string_new_trimed` выделяет
  `sizeof(ScString) + lenWoSpaces + 1`, но пишет `pData[siz] = '\0'`,
  где `siz` — исходный размер. Если в строке есть пробелы, это запись за
  границей буфера. Не используйте без исправления.
- **NOTE (баг):** `sc_string_replace` и
  `sc_string_replace_string_to_char` итерируются по `Length` (code points)
  как по байтам, теряют многобайтовые символы и не освобождают builder.
  Не используйте.

Проверка длины без пробелов:

```c
i64 sc_string_get_length_wo_whitespaces_ext(char* pString, i64 size);
```

### 3.5 `ScStringView`

```c
ScStringView sc_string_view_new(char* pData, i64 length);
ScStringView sc_string_view_new_ext(char* pData, i64 length, i64 size);
```

View **не владеет** памятью; `pData` должен жить, пока используется view.
Удобно для разбора без копирования.

### 3.6 Числа в строку

```c
i64 sc_int_to_string(char* pBuffer, i64 bufferLength, i64 intValue);
i64 sc_float_to_string(char* pBuffer, i64 bufferLength, f64 floatValue);
i64 sc_float_to_string_ext(char* pBuffer, i64 bufferLength, f64 floatValue, f64 threshold);
i32 sc_v_to_string(char* pBuf, u64 bufSize, real* pArr, i32 arrCount, f64 accuracy);
i32 sc_v2_to_string(char* pBuf, u64 bufSize, v2 v, f64 accuracy);
i32 sc_v3_to_string(char* pBuf, u64 bufSize, v3 v, f64 accuracy);
i32 sc_v4_to_string(char* pBuf, u64 bufSize, v4 v, f64 accuracy);
i32 sc_quat_to_string(char* pBuf, u64 bufSize, quat q, f64 accuracy);
```

**NOTE:**
- функции **не добавляют `'\0'`**; буфер нужно заранее обнулить;
- `sc_int_to_string` возвращает требуемую длину даже если буфер меньше и
  строка обрезана;
- `sc_float_to_string` может писать за границу маленького буфера —
  давайте не меньше 64 байт.

### 3.7 `sc_format`

```c
typedef struct
{
    i8 IsFinished;
    u64 Size;          // сколько байт записано
    const char* pFormat; // где остановились
} ScFormatResult;

ScFormatResult sc_format(char* pBuf, u64 bufSize, const char* pFormat, ...);
ScFormatResult sc_format_ext(char* pBuf, u64 bufSize, const char* pFormat, va_list args);
```

Поддерживаемые спецификаторы:

| Спецификатор | Аргумент | Примечание |
|---|---|---|
| `%s` | `char*` | длина по `sc_utf8_length` |
| `%ss` | `char*` (объект `ScString`) | длина по `sc_string_length` |
| `%d` | `i32` | |
| `%ld`, `%lld` | `i64` | после `l` режим `isLong` остаётся включённым |
| `%f` | `f64` | |
| `%v2`, `%v3`, `%v4` | `v2/v3/v4` | |
| `%p` | `void*` | |
| `%c` | — | **пишет литерал `c`**, аргумент не читается |

Чего нет: ширины, точности, `%x`, `%u`, `%e`, `%%` как escape
(второй `%` просто выключает режим формата). Строка **не завершается
`'\0'`**; инициализируйте буфер нулями.

Пример:

```c
char buf[128] = {};
sc_format(buf, sizeof(buf), "id=%d name=%s v=%v3", id, name, pos);
```

Из-за «залипания» `isLong` не смешивайте `%ld` и `%d` в одной строке:
после первого `%ld` последующие `%d` тоже будут читать `i64`.

### 3.8 Символы

```c
sc_char_is_whitespace(c);
sc_char_is_upper(c);
sc_char_is_lower(c);
sc_char_is_letter(c);
sc_char_is_integer(c);
sc_char_to_upper(c);
sc_char_to_lower(c);
```

Работают только с ASCII.

### 3.9 Хеши и степени

```c
sc_i32_hash(i32 key);
sc_i64_hash(i64 key);
sc_u64_hash(u64 key);
alt_hash(u32 a, u32 b);

// rapidhash V3: 64-битный некриптографический хеш буфера.
// Подключение: #include <Sc/Data/Hash.h>
// pData может быть NULL только при size == 0.
u64 sc_hash(const void* pData, u64 size);
u64 sc_hash_with_seed(const void* pData, u64 size, u64 seed);
u64 sc_hash_micro(const void* pData, u64 size);
u64 sc_hash_micro_with_seed(const void* pData, u64 size, u64 seed);
u64 sc_hash_nano(const void* pData, u64 size);
u64 sc_hash_nano_with_seed(const void* pData, u64 size, u64 seed);

// BLAKE3: криптографический хеш.
// Подключение: #include <Sc/Data/Crypt.h>
// pData может быть NULL только при size == 0; pOut - минимум 32 байта
// (SC_CRYPT_HASH_SIZE) для обычного хеша и outSize байт для XOF.
void sc_crypt_hash(const void* pData, u64 size, u8* pOut);
void sc_crypt_hash_keyed(const void* pData, u64 size, const u8* pKey, u8* pOut);
void sc_crypt_derive_key(const char* pContext, const void* pData, u64 size, u8* pOut);
void sc_crypt_hash_xof(const void* pData, u64 size, u8* pOut, u64 outSize);

// Потоковый интерфейс BLAKE3. ScCryptHasher можно держать на стеке.
void sc_crypt_hasher_init(ScCryptHasher* pHasher);
void sc_crypt_hasher_init_keyed(ScCryptHasher* pHasher, const u8* pKey);
void sc_crypt_hasher_init_derive_key(ScCryptHasher* pHasher, const char* pContext);
void sc_crypt_hasher_update(ScCryptHasher* pHasher, const void* pData, u64 size);
void sc_crypt_hasher_finalize(const ScCryptHasher* pHasher, u8* pOut, u64 outSize);
void sc_crypt_hasher_finalize_seek(const ScCryptHasher* pHasher, u64 seek, u8* pOut, u64 outSize);
void sc_crypt_hasher_reset(ScCryptHasher* pHasher);

i32 sc_get_int_digit(i64 intValue);
i64 sc_int_power(i64 intValue, i32 powerValue);
f64 sc_float_npow(i32 exponent);
```

BLAKE3 использует только portable-путь без SIMD и не тянет внешних
зависимостей. `SC_CRYPT_HASH_SIZE` и `SC_CRYPT_KEY_SIZE` равны 32.
`pKey` — 32 байта, `pContext` — NUL-terminated строка. `finalize_seek`
позволяет получить произвольный диапазон XOF-вывода без пересчёта хеша.
`ScCryptHasher` — обычная структура (~1.8 КБ), её можно держать на стеке;
`sc_crypt_hasher_reset` возвращает её в начальное состояние.

---

## 4. Списки, словари, сетка, builder, bitset

### 4.1 `ScList` — динамический массив

Список — это указатель на первый элемент; заголовок лежит перед ним.

```c
typedef struct { i64 Count; i64 Capacity; void* pData; } ScListHeader;

ScListHeader* sc_list_header(void* pList);
i64 sc_list_count(void* pList);      // 0 для NULL
i64 sc_list_capacity(void* pList);   // 0 для NULL

void sc_list_free(void* pList);
void* sc_list_add_ext(void* pList, void* pData, i32 stride);
void* sc_list_add_multiple_ext(void* pList, void* pData, i32 stride, i64 count);
void* sc_list_remove_ext(void* pList, void* pItem, i32 stride);
void* sc_list_remove_index_ext(void* pList, i32 ind, i32 stride);
void* sc_list_reserve_ext(void* pList, i32 stride, i64 count);
void* sc_list_clear_ext(void* pList, i32 stride);
void* sc_list_deep_copy_ext(void* pList, i32 stride);
void* sc_list_pop_ext(void* pList, i32 stride);
```

Макросы (первый аргумент должен быть **lvalue** — макрос переприсваивает
указатель):

```c
sc_list_add(pList, item);                 // pList = ...
sc_list_add_list(pList, otherList);
sc_list_add_multiple(pList, pData, stride, count);
sc_list_remove(pList, item);              // удаляет первый равный элемент
sc_list_remove_index(pList, index);
sc_list_pop(pList);                       // возвращает pList[0] и удаляет ЕГО
sc_list_reserve(pList, count);
sc_list_clear(pList);
sc_list_deep_copy(pList);
```

Итерация:

```c
sc_list_for_each(aItems, pItem)
{
    // pItem — указатель на текущий элемент; index объявлен макросом
    printf("%d\n", pItem->Id);
}
```

Поиск/выборка:

```c
i64 index = sc_list_index_of(aItems, item.Id == 42); // item объявлен макросом
Type* aField = sc_list_select(aItems, Field);        // копирует значения Field
```

**NOTE (важные особенности):**
- `sc_list_pop` удаляет **первый** элемент (сдвигает массив), а не
  последний. Имя историческое.
- `sc_list_reserve` **выделяет новый пустой список** и теряет старые
  данные; это не «резерв с сохранением».
- `sc_list_clear` зануляет всю ёмкость и ставит `Count = 0`.
- `sc_list_deep_copy` — побайтовая копия массива; вложенные указатели
  не копируются.
- `sc_list_index_of` объявляет внутри переменную `item`; не создавайте
  конфликтующую переменную с тем же именем в условии.

Пример:

```c
typedef struct { i32 Id; v2 Position; } Enemy;

Enemy* aEnemies = NULL;
Enemy e = { .Id = 1, .Position = v2_new(10, 20) };
sc_list_add(aEnemies, e);

sc_list_for_each(aEnemies, pEnemy)
    pEnemy->Position = v2_add(pEnemy->Position, v2_new(1, 0));

sc_list_free(aEnemies);
```

### 4.2 `ScDict` — словарь с int или string ключом

Запись словаря должна иметь поля **`Key` первым** и **`Value` вторым**:

```c
typedef struct { char* Key; i32 Value; } NameToInt;
typedef struct { i64 Key; v2 Value; } IdToPos;
```

Функции/макросы:

```c
sc_dict_init(recordSize, valueOffset, keyType, startInd);
sc_dict_free(dict);
sc_dict_clear(dict);
sc_dict_grow_ext(dict);

sc_dict_calc_ind_long(header, key, isGetFunc);
sc_dict_calc_ind_string(header, key, isGetFunc);
sc_dict_calc_ind(table, key);
```

Макросы:

```c
sc_dict_s_add(dict, key, value);      // string key
sc_dict_i_add(dict, key, value);      // integer key
sc_dict_s_contains(dict, key);
sc_dict_i_contains(dict, key);
sc_dict_s_get(dict, key);             // возвращает .Value
sc_dict_i_get(dict, key);
sc_dict_s_remove(dict, key);
sc_dict_i_remove(dict, key);
sc_dict_get_current(dict);
sc_dict_count(dict);
sc_dict_capacity(dict);
sc_dict_item_size(dict);
sc_dict_index(dict);
sc_dict_should_grow(dict);
```

Пример:

```c
typedef struct { char* Key; i32 Value; } NameToInt;

NameToInt* h = NULL;
sc_dict_s_add(h, "hp", 100);
sc_dict_s_add(h, "mp", 50);

if (sc_dict_s_contains(h, "hp"))
    printf("hp = %d\n", sc_dict_s_get(h, "hp"));

sc_dict_s_remove(h, "mp");
sc_dict_free(h);
```

**NOTE:**
- `sc_dict_*_get` **не проверяет наличие ключа**. Если ключа нет и таблица
  полна, `ind` может быть `-1`, и произойдёт выход за границу. Всегда
  сначала вызывайте `sc_dict_*_contains`.
- Словарь автоматически инициализируется при первом `_add`, если
  указатель `NULL`.
- Строковый ключ **не копируется**: хранится указатель. Ключ должен жить
  дольше словаря (литерал или долгоживущий буфер).
- `_add` с существующим ключом обновляет значение.
- `sc_dict_get_current` использует `Index`, выставленный последним
  `_add`/`_get`/`_calc_ind`; без него — assert.

### 4.3 `ScGrid` — трёхмерная сетка

```c
typedef struct
{
    i32 X, Y, Z;
    i32 ItemSize;
    void* pData;
} ScGrid;

ScGrid* sc_grid_reserve(itemSize, x, y, z); // макрос
ScGrid* sc_grid_reserve_ext(i32 itemSize, i32 x, i32 y, i32 z);
void sc_grid_set(ScGrid* pGrid, i32 x, i32 y, i32 z, void* pData);
void* sc_grid_get(ScGrid* pGrid, i32 x, i32 y, i32 z);
void sc_grid_free(ScGrid* pGrid);
```

Индекс: `x * Y * Z + y * Z + z`.

**NOTE:** `sc_grid_get` проверяет границы через `>`, а не `>=`, поэтому
запрос ровно по `x == X` (или `y == Y`, `z == Z`) проходит проверку и
читает за границей. Не выходите за диапазоны.

### 4.4 `ScBuilder` — сборка строки

```c
char* sc_builder_new();
void  sc_builder_destroy(char* pSb);
char* sc_builder_append_char(char* pSb, char c);
char* sc_builder_append_string(char* pSb, char* pString, i64 len);
char* sc_builder_append_format(char* pSb, char* pFormat, ...);
i64   sc_builder_count(char* pSb);
i64   sc_builder_capacity(char* pSb);
```

`sc_builder_new()` создаёт builder длины 0 с capacity 31 (по умолчанию).
Builder — это тот же `ScList<char>`, поэтому его можно передавать в
`sc_list_free` (но используйте `sc_builder_destroy`).

**NOTE (баг):** `sc_builder_append_format_ext`:
1. вызывает `sc_list_add_multiple(pSb, ...)` без переприсваивания `pSb`,
   поэтому при росте буфера возвращается старый указатель;
2. повторно использует уже израсходованный `va_list` в цикле `do/while`.
Не используйте `sc_builder_append_format` для длинных строк. Надёжный
вариант — явно переприсваивать результат:

```c
pSb = sc_builder_append_string_ext(pSb, "text", 4);
```

`sc_builder_append_string` помечен в заголовке как содержащий баг, но
макрос переприсваивает `pSb`; для обычных коротких строк он работает.
Для гарантии используйте `_ext` с присваиванием.

### 4.5 Битовые наборы

```c
typedef struct { u64 Mask0[1]; }  bitset64;
typedef struct { u64 Mask[4]; }   bitset256;
typedef struct { u64 Mask[8]; }   bitset512;
typedef struct { u64 Mask[16]; }  bitset1024;

void sc_bitset_set_0(u64* pBitset, u16 bitSetSize, u16 bit);
void sc_bitset_set_1(u64* pBitset, u16 bitSetSize, u16 bit);
u8   sc_bitset_get(const u64* pBitset, u16 bitSetSize, u16 bit);
i32  sc_bitset_contains(u64* b0, u16 size0, u64* b1, u16 size1);
void sc_bitset_test();

#define sc_bitset_get_bit_index(bit) ((bit) / 64)
#define sc_bitset_get_bit_mask(bit)  ((u64)1 << ((bit) % 64))
```

Размер передаётся в битах (`sc_bits_count(bitset)`).
`bitset64` использует поле `.Mask0`, остальные — `.Mask`.
`bitset128` нет.

**NOTE:** `sc_bitset_validate` работает только в Debug; в Release
`sc_bitset_get` для `bit >= bitSetSize` просто вернёт `0`, а `set_*`
может писать за границу. Следите за диапазоном сами.

---

## 5. Файлы, каталоги, пути, MIME

### 5.1 Файлы

```c
typedef struct
{
    u64 LastAccessTime;
    u64 LastCreateTime;
    u64 LastModificationTime;
} ScFileTime;

ScResult    sc_file_delete(const char* pPath);
ScFileTime  sc_file_get_time(const char* pPath);
u64         sc_file_get_size(const char* pPath);   // 0 при ошибке
char*       sc_file_read(const char* pFilePath);   // NUL-terminated, sc_memory_free
char*       sc_file_read_ext(const char* pFilePath, i64* pLength);
void        sc_file_write(const char* pFilePath, void* pData, u64 dataLength);
void        sc_file_append_string(const char* pFilePath, char* pData, u64 dataLength);
i32         sc_file_compare(char* p0, char* p1);    // 1 = равны
```

- `sc_file_read` читает бинарно и добавляет `'\0'`.
- `sc_file_write` **перезаписывает** файл; при ошибке открытия вызывает
  `sc_assert_break`.
- `sc_file_append_string` открывает `"a+b"` (бинарный append).
- `sc_file_get_time` на Windows возвращает только секунды
  (`SYSTEMTIME.wSecond`), а не полную дату.

Пример:

```c
i64 len = 0;
char* pText = sc_file_read_ext("data.json", &len);
if (pText)
{
    // ...
    sc_memory_free(pText);
}
```

### 5.2 Каталоги

```c
typedef enum
{
    ScDirectoryItemType_None = 0,
    ScDirectoryItemType_File,
    ScDirectoryItemType_Directory,
    ScDirectoryItemType_Symlink
} ScDirectoryItemType;

typedef struct
{
    ScDirectoryItemType Type;
    char* pPath;
} ScDirectoryItem;

typedef struct
{
    i8 IsAbsolutePath;
    ScDirectoryItemType Type;
} ScDirectoryGetConfig;

ScResult sc_directory_create(const char* pPath);
ScResult sc_directory_create_recursive(const char* pPath);
ScResult sc_directory_delete_recursive(const char* pPath);
ScResult sc_directory_set_current(const char* pPath);
char*    sc_directory_get_current();               // sc_memory_free

ScDirectoryItem* sc_directory_get_items(const char* pPath, ScDirectoryGetConfig config);
char** sc_directory_get_files(const char* pPath, i32 isAbsolute);
char** sc_directory_get_directories(const char* pPath, i32 isAbsolute);
```

Освобождение:

```c
ScDirectoryItem* aItems = sc_directory_get_items(".", (ScDirectoryGetConfig) {
    .IsAbsolutePath = 1,
    .Type = ScDirectoryItemType_None,
});

for (i64 i = 0; i < sc_list_count(aItems); ++i)
{
    printf("%s\n", aItems[i].pPath);
    sc_memory_free(aItems[i].pPath);
}
sc_list_free(aItems);
```

**NOTE:**
- На Linux при `IsAbsolutePath = 0` `pPath` указывает внутрь `struct
  dirent` и инвалидируется следующим `readdir`. Используйте
  `IsAbsolutePath = 1`.
- На Windows `pPath` выделяется в обоих режимах.
- `sc_directory_get_items` на Linux не закрывает `DIR*` (утечка).
- `sc_directory_get_files/get_directories` возвращают `char**`
  (`ScList<char*>`); освобождайте `sc_list_free` + каждый указатель,
  если он вам принадлежит. Внутри они уже освобождают список
  `ScDirectoryItem`, но **не** строки.

### 5.3 Пути

```c
typedef enum
{
    ScPathItemType_Undefined = 0,
    ScPathItemType_File,
    ScPathItemType_Directory,
} ScPathItemType;

ScPathItemType sc_path(const char* pPath);
char* sc_path_get_home_directory_wo_alloc();
char* sc_path_get_extension_wo_alloc(char* pPath);
char* sc_path_get_name_wo_alloc(char* pPath);
char* sc_path_get_name_wo_extension(char* path);       // выделяет
ScStringView sc_path_get_name_view_wo_extension(char* path);
char* sc_path_get_directory(char* pPath);              // выделяет
char* sc_path_combine(char* pLeft, char* pRight);      // выделяет
char* sc_path_get_random(char* pBuf, u64 bufSize, i32 minLen, i32 maxLen);
char* sc_path_get_random_temp();
char* sc_path_get_random_temp_ext(i64 min, i64 max);
```

**NOTE:**
- `sc_path_get_extension_wo_alloc` при отсутствии `.` возвращает
  `pPath - 1` (указатель на байт перед строкой). Проверяйте результат
  через `sc_string_last_index_of` самостоятельно.
- `sc_path_get_name_wo_alloc` ищет только `/`, не `\`.
- `sc_path_get_name_wo_extension` и `..._view_wo_extension` при имени
  без точки используют `-1` как длину — результат некорректен.
- `sc_path_get_directory` понимает и `/`, и `\`, возвращает `NULL`,
  если разделителя нет.
- `sc_path_get_random_temp_ext(min, max)` (и внутренний
  `sc_path_get_random`) вычисляет `sc_random() % (max - min)`; при
  `max == min` деление на ноль. Также `sc_random` — не seeded PRNG
  (см. §6.5).

### 5.4 MIME

```c
typedef enum
{
    ScMimeType_Undefined = 0,
    ScMimeType_Png, ScMimeType_Jpg, ScMimeType_Gif,
    ScMimeType_Qoi, ScMimeType_Qoa, ScMimeType_Gltf,
} ScMimeType;

ScMimeType sc_mime_type_new(const char* pPath, const void* pData, i32 dataSize);
ScMimeType sc_mime_type_new_from_path(const char* pPath);
ScMimeType sc_mime_type_new_from_data(const void* pData, i32 dataSize);
```

`sc_mime_type_new` сначала пробует данные, затем путь. Это
предпочтительный способ.

**NOTE (баг именования):** `sc_mime_type_new_from_path` фактически
пропускает первый символ и ожидает строку-**расширение** вида `.png`,
`.jpg`, `.gltf`, а не полный путь. Полный путь `"file.png"` даст
`ScMimeType_Undefined`. Используйте `sc_mime_type_new_from_data` или
передавайте расширение с точкой.

`sc_mime_type_new_from_data` требует минимум 8 байт и распознаёт PNG,
JPEG, GIF, QOI, QOA, GLB (`glTF`) и текстовый JSON-объект (`{`).

---

## 6. Потоки, время, логи, случайные числа

### 6.1 Потоки и синхронизация

```c
typedef void* ScThread;
typedef void* (*ScThreadDelegate)(void* arg);

ScThread sc_thread_create(ScThreadDelegate fn, u64 stackSize, void* pData);
void     sc_thread_attach(ScThread thread);
ScResult sc_thread_cancel(ScThread thread);

typedef void* ScMutex;
ScMutex  sc_mutex_create();
ScResult sc_mutex_destroy(ScMutex pMutex);
ScResult sc_mutex_lock(ScMutex pMutex);
ScResult sc_mutex_unlock(ScMutex pMutex);
i32      sc_mutex_is_locked(ScMutex scMutex);

typedef struct { void* pHandle; } ScCondition;
ScCondition sc_condition_create(void);
void sc_condition_destroy(ScCondition condition);
void sc_condition_wait(ScCondition* pCondition, ScMutex scMutex);
void sc_condition_signal(ScCondition* pCondition);
void sc_condition_broadcast(ScCondition* pCondition);

typedef struct ScRWLockInternal* ScRwLock;
ScRwLock sc_rwlock_create(void);
ScResult sc_rwlock_destroy(ScRwLock lock);
ScResult sc_rwlock_read_lock(ScRwLock lock);
ScResult sc_rwlock_read_unlock(ScRwLock lock);
ScResult sc_rwlock_write_lock(ScRwLock lock);
ScResult sc_rwlock_write_unlock(ScRwLock lock);
ScResult sc_rwlock_try_read_lock(ScRwLock lock);
ScResult sc_rwlock_try_write_lock(ScRwLock lock);

void sc_sleep_ms(i32 ms); // блокирующий sleep текущего потока
```

`sc_thread_create` возвращает handle; код возврата потока — `void*`.
`sc_thread_attach` нужен для join/detach-семантики платформы (см.
реализацию `Sc.c`).

**NOTE:** `sc_mutex_is_locked` отражает только последний
lock/unlock на обёртке, а не реальную конкуренцию.

### 6.2 Job system (WIP)

```c
typedef void (*ScJobAction)();
typedef struct { i32 JobsCount; } ScJobConfig;

void sc_job_init(ScJobConfig cfg);
void sc_job_new(ScJobAction jobAction);
```

**NOTE:** `sc_job_init` не создаёт мьютекс/condition, `sc_job_deinit`
вообще не объявлен в заголовке. Система экспериментальная; не
используйте в продакшене без доработки.

### 6.3 Профайлер

```c
typedef struct { i64 Result; } ScProfiler;

void sc_profiler_start(ScProfiler* pProfiler);
void sc_profiler_end(ScProfiler* pProfiler);
ScProfilerTimeType sc_profiler_get_time_type(ScProfiler* pProfiler);
i64 sc_profiler_get_nanoseconds(ScProfiler* pProfiler);
i64 sc_profiler_get_microseconds(ScProfiler* pProfiler);
i64 sc_profiler_get_milliseconds(ScProfiler* pProfiler);
i64 sc_profiler_get_seconds(ScProfiler* pProfiler);
f64 sc_profiler_get_microseconds_as_float(ScProfiler* pProfiler);
f64 sc_profiler_get_milliseconds_as_float(ScProfiler* pProfiler);
f64 sc_profiler_get_seconds_as_float(ScProfiler* pProfiler);
void sc_profiler_print(ScProfiler* pProfiler);
void sc_profiler_print_as_float(ScProfiler* pProfiler);
char* sc_profiler_get_string(ScProfiler* pProfiler);        // статический буфер
char* sc_profiler_get_string_as_float(ScProfiler* pProfiler); // статический буфер
```

`NsToS`, `NsToMs`, `NsToMcs` и float-версии — макросы перевода.

**NOTE:** на Linux используется `CLOCK_REALTIME`, а не монотонные часы;
время может прыгнуть. `sc_profiler_get_time_type` делает assert, если
`pProfiler->Result == 0` — не вызывайте её до `start`/`end` или после
обнуления профайлера. `sc_profiler_get_string*` возвращают указатели на
статические буферы, а не новую память.

### 6.4 Дата/время и таймер

```c
typedef struct
{
    u8 DayOfTheWeek, Seconds, Minutes, Hours;
    u8 Day, Month;
    u16 Year;
} ScDateTime;

i64 sc_date_time_now_seconds();
void sc_date_time_add_seconds(ScDateTime* pDt, f32 seconds);
extern ScDateTime sc_date_time_now();
const char* sc_date_time_to_string(ScDateTime dt);
const char* sc_date_time_to_date_string(ScDateTime dt);
const char* sc_date_time_to_time_string(ScDateTime dt);
```

**NOTE:**
- строковые функции возвращают указатели на **статические** буферы;
  копируйте результат, если нужно хранить несколько значений;
- `sc_date_time_add_seconds` игнорирует `seconds <= 0` и отбрасывает
  дробную часть (`(i64)seconds`);
- `sc_date_time_to_date_string` форматирует `Day:Month:Year` как
  `"DD:MM:YYYY"`, а не `YYYY-MM-DD`.

Таймер:

```c
typedef struct { f32 SecondsToWait; } ScTimer;

ScTimer sc_timer_new(f32 secondsToWait);
i32 sc_timer_interval(ScTimer* pTimer, f32 timestep);
void sc_timer_reset(ScTimer* pTimer, f32 secondsToWait);
```

`sc_timer_interval` возвращает `1` при каждом вызове после истечения
интервала, пока не вызван `sc_timer_reset`. Типичный цикл:

```c
ScTimer timer = sc_timer_new(1.0f);
while (running)
{
    f32 dt = 0.016f;
    if (sc_timer_interval(&timer, dt))
    {
        // раз в секунду
        sc_timer_reset(&timer, 1.0f);
    }
}
```

### 6.5 Случайные числа

```c
u64 sc_random();
u64 sc_random_ext(u32 flags);
```

Это **криптостойкий источник ОС** (`BCryptGenRandom` / `getrandom`),
а не seeded PRNG. Диапазона в API нет; используйте остаток сами,
учитывая смещение. `sc_path_get_random_temp_ext(min, max)` делает
`% (max - min)` и ломается при `max == min`.

### 6.6 Логи

```c
typedef enum
{
    ScLogLevel_Info, ScLogLevel_Debug, ScLogLevel_Success,
    ScLogLevel_Warn, ScLogLevel_Error, ScLogLevel_Count
} ScLogLevel;

typedef struct { /* ... */ } ScLogItem;
typedef enum { ScLogFormat_None = 0, ScLogFormat_Level, /* ... */ } ScLogFormat;
typedef void (*ScBackendDelegate)(ScLogItem item, ScLogFormat* aFormats, u32 formatsCount);
typedef struct { ScBackendDelegate Action; u32 FormatsCount; ScLogFormat aFormats[ScLogFormat_Count]; } ScLogBackend;
typedef struct { i32 BackendsCount; ScLogBackend* aBackends; } ScLogConfig;

void sc_log_init(ScLogConfig config);
void sc_log_init_default();
void sc_log_deinit();
void sc_log_base(ScLogLevel type, const char* pFile, i32 line,
                 const char* pFunction, const char* pFormat, ...);

ScLogBackend sc_log_get_terminal_backend();
ScLogBackend sc_log_get_file_backend();

sc_log_info(...); sc_log_warn(...); sc_log_erro(...); sc_log_succ(...);
const char* sc_log_level_to_color(ScLogLevel level);
const char* sc_log_level_to_string(ScLogLevel level);
```

`sc_log_init_default` подключает терминал и файл `sc.log`.
Формат сообщений — тот же `sc_format` (`%s`, `%d`, `%f`, `%v3`, ...).

**NOTE:**
- До `sc_log_init*` логирование не падает (ноль бэкендов), но ничего
  не выводит.
- **`sc_log_deinit` освобождает `aBackends`, но не сбрасывает
  `BackendsCount`.** Последующий лог может обратиться к освобождённой
  памяти. После `sc_log_deinit` не логируйте (или сразу вызывайте
  `sc_log_init` заново).
- `sc_log_init_default` не проверяет повторную инициализацию.

---

## 7. Математика

Заголовок `Math.h` — **inline-реализация**, `Math.c` пуст.
Соглашение: **векторы-строки**, `v * M`; перенос хранится в
`M30/M31/M32`. Поэтому `m4_mul_v4(m, v)` фактически считает `v * m`.

### 7.1 Общие функции

```c
i32_pow(x, n); real_pow2(x);
isqrt(x);                      // приближённый 1/sqrt
real_abs(x); real_sqrt(x); real_equal(a, b); real_equal_epsilon(a, b, eps);
sc_is_sign_equal(x, y);      // ((x * y) >= 0)
sc_math_radians_to_degrees(r); sc_math_degrees_to_radians(d);
ROUND_MAX(x); ROUND_MIN(x);
```

`REAL_CUSTOM_EPSILON` = `1E-5f`. Константы: `ScMathPi`, `ScMathPiDiv2`,
`ScMathRad360`, `ScMathRad180`, `ScMathRad90`, `ScMathSqrt2` и др.

### 7.2 `v2`

```c
v2_equal_zero(v); v2_dot(a, b); v2_skew(a, b);
v2_perpendicular_clock_wise(a); v2_perpendicular_counter_clock_wise(a);
v2_length(v); v2_distance(a, b); v2_distance2(a, b); v2_distance_pow(a, b);
v2_normalize(v); v2_copy(v);
v2_add(a, b); v2_add_x(a, x); v2_add_y(a, y); v2_addi(a, v2i);
v2_sub(a, b); v2_sub_x(a, x); v2_sub_y(a, y); v2_sub_yr(a, y);
v2_mul(a, b); v2_div(a, b);
v2_addv(a, num); v2_subv(a, num); v2_mulv(a, num); v2_divv(a, num);
v2_v4(v);
v2_equal_epsilon(a, b, eps); v2_not_equal_epsilon(a, b, eps);
v2_get_direction(object, eye, forward);
v2_is_right_direction(object, eye);
v2_lerpx(start, end, percent);
```

**NOTE (баги):** `v2_addv` **вычитает** `num` (как `v2_subv`);
`v2_skew` считает `a.X*b.Y + a.Y*b.X`, а не определитель
`a.X*b.Y - a.Y*b.X`.

### 7.3 `v3`

```c
v3_equal_zero(v); v3_to_degree(v); v3_invert(v); v3_negative(v);
v3_negativec(x, y, z); v3_negative_to(v); v3_copy(v);
v3_length(v); v3_length_array(a);
v3_dot(a, b); v3_cross(a, b); v3_cross_normalized(a, b);
v3_distance(a, b); v3_distance2(a, b); v3_distance_pow(a, b);
v3_normalize(v);
v3_add(a, b); v3_addx(a, x); v3_addy(a, y); v3_addz(a, z);
v3_sub(a, b); v3_sub_x(a, x); v3_sub_y(a, y); v3_sub_z(a, z);
v3_mul(a, b); v3_scale(a, num); v3_div(a, b);
v3_addv(a, num); v3_subv(a, num); v3_mulv(a, num); v3_divv(a, num);
v3_mulv_as_v4(a, num); v3_mulv_ref(dest, a, num);
v3_negate(v);
```

**NOTE (баг):** `v3_divv` **вычитает** `num` вместо деления.

### 7.4 `v4`

```c
v4_is_direction(v); v4_is_position(v); v4_copy(v); v4a_copy(dst, src);
v4_assignv(v, x, y, z, w); // принимает v4 по значению — изменения не вернутся
v4_length(v); v4_distance(a, b); v4_distance2(a, b);
v4_negative(v); v4_normalize(v);
v4_add(a, b); v4_addv(a, num); v4_sub(a, b); v4_subv(a, num);
v4_mul(a, b); v4_mulv(a, num); v4_scale(a, num); v4_div(a, b);
v4a_scale(a, num, dst); v4_scale_array(a, num);
v4_dot(a, b); v4_negate(v); v4_lerp(from, to, t);
v4_rgba(r, g, b, a); v4_rgb(r, g, b); v4_v(s);
```

`v4_rgba/rgb` принимают `u8` (0..255), `v4_v` — `f32` в шкале
0..255; все возвращают нормализованные компоненты `0..1`.

### 7.5 Матрицы

```c
m3_array(a); m3_double_array(a); m3_m4(m4); m3_t(m); m3_mul(a, b);
m3_mul_v3(m, v); m3_mul_v(m, num); m3_copy(m); m3_det(m); m3_adj(m);
m3_inverse(m);

m4_m3_array(a); m4_array(a); m4_double_array(a); m4_identity();
m4_copy(m); m4_copy_array(a); m4_zero();
m4_rotation_matrix(axis, angle);
m4_mul_real(m, v); m4_mul_v4a(m, v, out); m4_mul_v4(m, v);
m4_mul_v3a(m, v, out); m4_mul_v3(m, v);
m4_mul(a, b); m4_mul_rot(a, b);
m4_translate(m, t); m4_translate_identity(t);
m4_scale_v3(m, scale);
m4_rotate_x(m, rad); m4_rotate_y(m, rad); m4_rotate_z(m, rad);
m4_rotate(m, axis, angle); m4_rotate_at(m, axis, pivot, angle);
m4_transform(position, rotation, scale);
m4_transform_wo_rotation(position, scale);
m4_inverse(m); m4_determinant(m); m4_t(m);
m4_orthographic(l, r, b, t, n, f);
m4_perspective(n, f, aspect, fovRadians);
m4_perspective_lh_opengl(n, f, aspect, fovRadians);
m4_look_at(eye, center, up);
```

**NOTE (важные особенности):**
- `m4_transform` использует `sc_math_radians_to_degrees(rotation.Z)`,
  хотя `m4_rotate_z` ожидает радианы. Передавайте радианы (функция
  ошибочно конвертирует их в градусы).
- `m4_rotate_at` использует исходную матрицу `m` во втором и третьем
  `m4_translate`, а не результат предыдущих шагов. Для сложных
  иерархий проверяйте результат.
- `m4_perspective` — под Vulkan (RH, инверсия Y); для OpenGL есть
  `m4_perspective_lh_opengl`.
- `m4_determinant` реализован только для 3x3-подобной части и не
  учитывает полную 4x4-матрицу.

### 7.6 Кватернионы

```c
quat_new(angle, axis); quat_v3(v); quat_xyz(x, y, z); quat_xyzw(x, y, z, w);
quat_array(arr); quat_array_negative(arr);
quat_pitch_yaw_roll(pitch, yaw, roll); quat_to_euler_angles(q);
quat_euler(v); quat_identity();
quat_dot(a, b); quat_length(q); quat_magnitude(q); quat_normalize(q);
quat_mul(a, b); quat_cross(a, b);
quat_add(a, b); quat_sub(a, b); quat_scale(a, value); quat_negate(a);
quat_to_m4(q); quat_float(q);
quat_conjugate(q); quat_invert(q); quat_inverse(q);
quat_imaginary(q); quat_imaginary_length(q); quat_angle(q);
v3_rotate_quat(v, q); quat_rotate_v3(q, v);
quat_to_view(q, cameraPosition);
quat_rotate_m4(q, m); quat_rotate_m4_identity(q);
quat_look(q, eye); quat_look_at(q, pos);
quat_transform_short(position, rotation);
quat_transform(position, rotation, scale);
quat_transform_wo_scale(position, rotation);
quat_new_pitch_yaw(pitch, yaw);
quat_new_pitch_yaw_roll(pitch, yaw, roll);
quat_lerp(from, to, t); quat_slerp(from, to, t);
```

**NOTE (баги):**
- `quat_angle` использует `quat_imaginary_length`, которая возвращает
  **квадрат** длины мнимой части, а не длину.
- `quat_inverse` умножает сопряжённый кватернион на длину, а не делит
  на неё. Для нормализованного кватерниона это совпадает с
  сопряжением; для остальных — нет.
- `quat_lerp` — линейная интерполяция, не slerp. Для корректного
  вращения используйте `quat_slerp`.

### 7.7 Разложение и view

```c
v3_decompose_rotation_xyz(m3 rot);   // возвращает градусы
view_get(position, rotationX, rotationY);
view_get2(position, orientation);
view_projection_get_frustrum(viewProjection, v4 dest[6]);
m4_transform_decompose(transform, &translation, &rotation, &scale);
m4_transform_decompose_2(...);
m4_transform_decompose_3(...);
```

Разные варианты декомпозиции исторически расходятся по соглашениям
(градусы/радианы, порядок осей). Для нового кода выбирайте один вариант
и покрывайте его тестом.

### 7.8 Печать

```c
v2_print(v); v3_print(v); v4_print(v);
v2_printa(v, 3); v3_printa(v, 3); v4_printa(v, 3);
M4_PRINT(m);
```

`MathPrint.h` выводит в stdout с цветом терминала. Только для отладки.

---

## 8. ECS

ECS — **глобальный singleton**. Мир создаётся один раз:

```c
void sc_ecs_world_create();
void sc_ecs_world_destroy();
```

Повторный `sc_ecs_world_create` ничего не делает, если мир уже создан.

### 8.1 Компоненты

```c
typedef i64 ScEcsEntityId;
typedef i16 ScEcsComponentId;

i32 sc_ecs_world_register_component(ComponentType); // макрос, имя = #Type
i32 sc_ecs_world_register_component_ext(const char* pName, u64 size);

#define sc_ecs_ctos(ComponentType) \
    ({ (void)sizeof(ComponentType); #ComponentType; }) // compile-time проверка типа

ScEcsComponentId sc_ecs_component_name_to_id(const char* pName);
const char*      sc_ecs_component_id_to_name(ScEcsComponentId id);
u64              sc_ecs_component_size(ScEcsComponentId id);
i32              sc_ecs_components_count();
```

`sc_ecs_world_register_component(Position)` разворачивается в
`..._ext("Position", sizeof(Position))`. `pName` — это строковый
литерал `#comp`; он должен жить всё время работы мира (литералы живут).

### 8.2 Сущности и данные

```c
ScEcsEntityId sc_ecs_entity_new();
void          sc_ecs_entity_destroy(ScEcsEntityId id);

sc_ecs_entity_set(entity, Comp, value);        // создать/обновить
sc_ecs_entity_has(entity, Comp);               // i32
sc_ecs_entity_get(entity, Comp);               // Comp*
sc_ecs_entity_remove_component(entity, Comp);  // i32

sc_ecs_entity_set_by_id(entity, compId, Comp, value);
sc_ecs_entity_has_by_id(entity, compId);
sc_ecs_entity_get_by_id(entity, compId);       // void*
```

Пример:

```c
typedef struct { v2 Position; } Position;
typedef struct { v2 Velocity; } Velocity;

sc_ecs_world_create();
sc_ecs_world_register_component(Position);
sc_ecs_world_register_component(Velocity);

ScEcsEntityId e = sc_ecs_entity_new();
sc_ecs_entity_set(e, Position, { .Position = v2_new(10, 20) });
sc_ecs_entity_set(e, Velocity, { .Velocity = v2_new(1, 0) });

if (sc_ecs_entity_has(e, Position))
{
    Position* p = sc_ecs_entity_get(e, Position);
    p->Position = v2_add(p->Position, v2_new(1, 1));
}

sc_ecs_entity_destroy(e);
sc_ecs_world_destroy();
```

### 8.3 Выборки

```c
#define sc_ecs_get_all_entity_ids(...) \
    sc_ecs_world_get_all_entity_ids_ext(#__VA_ARGS__)

ScEcsEntityId* sc_ecs_world_get_all_entity_ids_ext(const char* pComponents);
#define sc_ecs_world_get_all_component_data(Comp) \
    (Comp*)sc_ecs_world_get_all_component_data_ext(#Comp)
void* sc_ecs_world_get_all_component_data_ext(const char* pComponent);
```

`sc_ecs_get_all_entity_ids(Position, Velocity)` передаёт строку
`"Position, Velocity"` и возвращает `ScList<ScEcsEntityId>` (указатель).
Освобождайте `sc_list_free`.

`sc_ecs_world_get_all_component_data(Comp)` возвращает сырой массив
компонентов (`Comp*`), но **без количества**.
`sc_ecs_world_get_all_components_ext` в текущей реализации возвращает
то же самое (не список сущностей).

### 8.4 Валидация и индексы

```c
i32 sc_ecs_entity_id_validate(ScEcsEntityId id);       // только диапазон
i32 sc_ecs_component_id_validate(ScEcsComponentId id);  // только < 512

i64 sc_ecs_entity_id_to_index(ScEcsEntityId id);
i64 sc_ecs_component_id_to_index(ScEcsComponentId id);
ScEcsEntityId sc_ecs_entity_index_to_id(i64 index);
ScEcsComponentId sc_ecs_component_index_to_id(i64 index);
```

**NOTE:**
- `sc_ecs_entity_id_validate` проверяет только диапазон, а не то, что
  ID был выдан и жив. Уничтоженные ID не переиспользуются:
  `aDeletedEntities` только пополняется и не читается при выдаче
  новых ID.
- `sc_ecs_component_id_validate` проверяет только `< 512`, а не факт
  регистрации компонента.
- `sc_ecs_entity_get_by_id_ext` при отсутствии компонента в Debug
  логирует и вызывает `sc_assert_break`. Сначала проверяйте
  `sc_ecs_entity_has`.
- `sc_ecs_entity_destroy` возвращает offsets компонентов в пул и
  обнуляет запись сущности, но ID и индекс записи не переиспользуются:
  `aDeletedEntities` не участвует в выдаче новых ID.
- Мир не защищает данные; для многопоточности нужна внешняя
  синхронизация.

---

## 9. Reflect и Test

### 9.1 Reflect

```c
typedef struct ScReflectType ScReflectType;
typedef struct ScReflectFieldInfo ScReflectFieldInfo;

struct ScReflectType {
    char* pName;
    u16 Size;
    ScReflectFieldInfo* aFields;
};

struct ScReflectFieldInfo {
    char* pName;
    ScReflectType TypeInfo;
    u16 Size;
    u16 Offset;
};

typedef struct {
    char* Key;
    ScReflectType Value;
} ScReflectEntry;

typedef struct {
    ScReflectEntry* hReg;
} ScReflect;

typedef struct {
    char* pName;
    u16 Size;
    i64 FieldInfoCount;
    ScReflectFieldInfo* aFieldInfos;
} ScReflectTypeConfig;

sc_reflect_register_type(&reflect, Type, ...);
sc_reflect_get_type(&reflect, Type);
void sc_reflect_register_type_ext(ScReflect* pReflect, ScReflectTypeConfig cfg);
ScReflectType sc_reflect_get_type_ext(ScReflect* pReflect, const char* pName);
void sc_reflect_free(ScReflect* pReflect);
```

Пример регистрации структуры:

```c
typedef struct { f32 X, Y; } Vec2;

ScReflectFieldInfo aFields[] = {
    { .pName = "X", .TypeInfo = { .pName = "f32", .Size = sizeof(f32) },
      .Size = sizeof(f32), .Offset = ScOffsetOf(Vec2, X) },
    { .pName = "Y", .TypeInfo = { .pName = "f32", .Size = sizeof(f32) },
      .Size = sizeof(f32), .Offset = ScOffsetOf(Vec2, Y) },
};

ScReflect reflect = {};
sc_reflect_register_type(&reflect, Vec2,
    .FieldInfoCount = ScArrayCount(aFields),
    .aFieldInfos = aFields);

ScReflectType t = sc_reflect_get_type(&reflect, Vec2);
sc_reflect_free(&reflect);
```

`pName` (строка `#type`) должен жить дольше реестра; литералы подходят.

### 9.2 Test

```c
typedef struct { i64 Code; char* pMessage; } ScTestRecr;
typedef struct { char* pName; ScTestRecr* aRecords; } ScTestFunc;
typedef struct { char* pFileName; ScTestFunc* aFuncs; } ScTestFile;
typedef struct {
    i8 IsShort;              // 0/1/2 — режим вывода
    char** aLongPrintFuncs;
} ScTestVisualizeConfig;

ScTestFile* sc_test_get();
i32         sc_test_is_function_was_failed();
void        sc_test_visualize(ScTestFile* aFiles, ScTestVisualizeConfig cfg);
void        sc_test_set_file(const char* pFilePath);
void        sc_test_set_func(const char* pFunction);
void        sc_test_set_record(ScTestRecr testRecord);

sc_test_file();                       // задать текущий файл (__FILE__)
sc_test_func(test_fn());              // задать имя функции и вызвать её
sc_test_condition(cond);
sc_test_i32_equal(a, b);
sc_test_string_equals(s0, s1);
sc_test_f32_equal(a, b);
sc_test_v2_equal(a, b);
sc_test_v3_equal(a, b);
sc_test_v4_equal(a, b);
sc_test_quat_equal(a, b);

sc_test_i32_value(v);
sc_test_f32_value(v);
sc_test_v2_value(v);
sc_test_v3_value(v);
sc_test_v4_value(v);
sc_test_quat_value(v);
sc_test_string_value(s);
```

Тестовая функция обычно возвращает `void`:

```c
static void
sc_list_add_test()
{
    i32* a = NULL;
    sc_list_add(a, 10);
    sc_test_i32_equal(sc_list_count(a), 1);
    sc_test_i32_equal(a[0], 10);
    sc_list_free(a);
}

void
sc_auto_list()
{
    sc_test_file();
    sc_test_func(sc_list_add_test());
}
```

Регистрация — в `Source/Tests/ScAuto.c` (`extern void sc_auto_list();` и
вызов в `sc_auto()`), файл — в `Source/Tests/Test.masuka`.

**NOTE (баги тестового API):**
- `sc_test_v4_equal` вызывает `v3_equal`, поэтому проверяет только
  `X/Y/Z`, игнорируя `W`.
- `sc_test_string_equal_ext` (макрос `sc_test_string_equals`) создаёт
  временные подстроки и не освобождает их (утечка). Для больших тестов
  это может накапливаться.
- Две пустые строки считаются **не равными**:
  `sc_string_compare_ext(..., 0)` сразу возвращает `0`.
- `sc_test_string_value(NULL)` записывает литерал `"<NULL>"`; не
  передавайте его в `sc_string_destroy`/`sc_memory_free`.

---

## 10. JSON

```c
typedef enum { /* ... */ } ScJsonTokenType;
typedef enum { /* ... */ } ScJsonError;

typedef struct
{
    ScJsonTokenType Type;
    i32 Parent;
    union { i32 Start; i32 StartInd; };
    union { i32 End;   i32 EndInd; };
} ScJsonToken;

typedef struct
{
    const char* pText;
    u64 TextLength;
    u64 TokensCount;
    ScJsonToken* aTokens;
    ScJsonError ErrorType;
} ScJsonConfig;

void sc_json_parse(ScJsonConfig* pCfg);
```

Токены — это **срезы** исходного текста: `Start..End` — индексы в
`pText` (включая границы). Строковые токены не включают кавычки;
escape-последовательности и `\uXXXX` **не декодируются**.

Использование:

```c
char* pJson = sc_file_read("data.json");
i64 jsonLength = sc_string_get_length(pJson);
i64 tokenCapacity = 1024;

ScJsonToken* aTokens = sc_memory_allocate(sizeof(ScJsonToken) * tokenCapacity);
ScJsonConfig cfg = {
    .pText = pJson,
    .TextLength = (u64)jsonLength,
    .TokensCount = tokenCapacity,
    .aTokens = aTokens,
};
sc_json_parse(&cfg);

if (cfg.ErrorType != ScJsonError_None)
    printf("json error: %s\n", sc_json_error_to_string(cfg.ErrorType));

// cfg.TokensCount теперь = число данных токенов
for (i64 i = 0; i < (i64)cfg.TokensCount; ++i)
    printf("%s\n", sc_json_token_type_to_string(aTokens[i].Type));

sc_memory_free(aTokens);
sc_memory_free(pJson);
```

**NOTE:**
- В `TokensCount` при вызове передаётся **ёмкость** массива. Парсеру
  нужно место под все данные-токены **плюс** `ScJsonTokenType_End`.
  После разбора `TokensCount` перезаписывается числом данных-токенов.
- `aTokens` должен быть заранее выделен; иначе
  `ScJsonError_TokensArrayIsNotAllocated`.
- `sc_json_object_token_length`, `sc_json_object_token_keys_count`
  жёстко используют `aTokens[0]` (работают только для корневого
  объекта).
- `sc_json_token_int` использует `sc_parse_int`, поэтому отрицательные
  числа небезопасны.
- `sc_json_token_string` возвращает `char*` с заголовком `ScString`
  (освобождать `sc_string_destroy`), а не `ScStringView`.
- `sc_json_token_float_array/int_array` по типу возвращают `f32*`/`i32*`,
  но фактически это указатель на `ScList`; освобождайте `sc_list_free`.
- `sc_json_token_v3o/v4o` возвращают `v3o/v4o` и внутри теряют
  временный список (утечка).

Хелперы:

```c
#define sc_json_token_length(token) ((token).End - (token).Start + 1)
#define sc_json_text(pText, ind) ((char*)(pText) + (ind))

i32 sc_json_object_token_length(ScJsonToken* aTokens, i32 objIndex, i32 tokensCount);
i32 sc_json_array_token_length(ScJsonToken* aTokens, i32 tokensCount, i32 arrayIndex);
i32 sc_json_object_token_keys_count(ScJsonToken* aTokens, i32 objIndex, i32 tokensCount);
const char* sc_json_token_type_to_string(ScJsonTokenType type);
const char* sc_json_error_to_string(ScJsonError type);

char* sc_json_token_string(ScJsonToken* aTokens, i32* pInd, char* pJson);
i32 sc_json_token_int(ScJsonToken* aTokens, i32* pInd, char* pJson);
f32 sc_json_token_float(ScJsonToken* aTokens, i32* pInd, char* pJson);
f32* sc_json_token_float_array(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
i32* sc_json_token_int_array(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
v3o sc_json_token_v3o(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
v4o sc_json_token_v4o(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
```

`pInd` — курсор по массиву токенов; функции продвигают его.

---

## 11. glTF

```c
typedef struct { char* pGenerator; char* pVersion; } ScGltfAsset;
typedef struct { char* pName; i32* aNodes; } ScGltfScene;
typedef struct { char* pName; i32 Mesh; v4o Rotation; } ScGltfNode;
typedef struct { i32 Position, Normal, Uv0; } ScGltfAttribute;
typedef struct { ScGltfAttribute Attributes; i32 Indices; } ScGltfPrimitive;
typedef struct { char* pName; ScGltfPrimitive* aPrimitives; } ScGltfMesh;

typedef struct
{
    i32 BufferView;
    ScGltfComponentType ComponentType;
    i32 Count;
    v3o Max, Min;
    i32 ComponentsCount;
} ScGltfAccessor;

typedef struct { i32 Buffer, ByteLength, ByteOffset, Target; } ScGltfBufferView;
typedef struct { i32 ByteLength; char* pUri; void* pData; } ScGltfBuffer;

typedef struct
{
    char* pPath;
    ScGltfAsset Asset;
    i32 Scene;
    ScGltfScene* aScenes;
    ScGltfNode* aNodes;
    ScGltfMesh* aMeshes;
    ScGltfAccessor* aAccessors;
    ScGltfBufferView* aBufferViews;
    ScGltfBuffer* aBuffers;
} ScGltf;

ScGltf sc_gltf_load(const char* pPath);
void sc_gltf_unload(ScGltf gltf);
void sc_gltf_load_buffers(ScGltf* pGltf);
const char* sc_gltf_component_type_to_string(ScGltfComponentType type);
```

`sc_gltf_load` читает `.gltf` (JSON) и заполняет массивы. `Rotation` —
это `v4o` (кватернион `X/Y/Z/W`).

**NOTE (WIP, много ограничений):**
- парсер эвристический и рассчитан на простые glTF; сложные файлы
  (extensions, sparse accessors, Draco, KHR-материалы) не
  поддерживаются;
- `sc_gltf_load` теряет содержимое JSON и токены (утечки), а вложенные
  массивы/строки/`pData` буферов освобождаются не полностью;
- `sc_gltf_unload` освобождает только верхнеуровневые списки;
- `sc_gltf_load_buffers` загружает внешние `.bin`/`pUri`, но
  рассчитывайте на простые случаи;
- для продакшена используйте специализированный загрузчик.

---

## 12. Изображения

Все модули изображений следуют одному контракту: пиксели — строки
сверху вниз, каналы interleaved; возвращаемые буферы выделены
`sc_memory_allocate` и освобождаются `sc_memory_free`.

### 12.1 Общие типы

```c
#define SC_IMAGE_DATA_SIZE_MAX 0x7fffffff

typedef enum
{
    ScImageChannels_Grey = 1,
    ScImageChannels_GreyAlpha = 2,
    ScImageChannels_Rgb = 3,
    ScImageChannels_Rgba = 4,
} ScImageChannels;

typedef struct { i32 Width, Height, Channels; } ScImageDesc;

i32 sc_image_data_size_is_valid(i64 dataSize);
i32 sc_image_decode_channels_is_valid(i32 channels);
i32 sc_image_desc_is_valid_for_encode(ScImageDesc desc);
void sc_image_desc_fill(ScImageDesc* pDesc, i32 w, i32 h, i32 fileChannels, i32 channels);
```

`channels == 0` при декодировании означает «взять из файла»;
`1..4` — принудительное число каналов.

### 12.2 `ScImageBuffer`

```c
typedef struct { u8* pData; i64 Count; i64 Capacity; } ScImageBuffer;

void sc_image_buffer_init(ScImageBuffer* pBuffer, i64 capacity);
void sc_image_buffer_destroy(ScImageBuffer* pBuffer);
void sc_image_buffer_write(ScImageBuffer* pBuffer, void* pData, i32 size);
```

Растущий приёмник байтов для энкодеров. При нехватке памяти
`pData = NULL`, `Count = 0`.

### 12.3 PNG

```c
void* sc_png_decode(void* pData, i64 dataSize, ScImageDesc* pDesc, i32 channels);
void* sc_png_read(char* pPath, ScImageDesc* pDesc, i32 channels);
void* sc_png_encode(void* pData, ScImageDesc desc, i64* pLength);
i64   sc_png_write(char* pPath, void* pData, ScImageDesc desc);
```

Декодирование: 1/2/4/8/16 бит, палитры + tRNS, Adam7, все фильтры.
Кодирование: 8 бит на канал, `comp` 1..4. При ошибке — `NULL`/`0`.

### 12.4 JPEG

```c
void* sc_jpg_decode(void* pData, i64 dataSize, ScImageDesc* pDesc, i32 channels);
void* sc_jpg_read(char* pPath, ScImageDesc* pDesc, i32 channels);
void* sc_jpg_encode(void* pData, ScImageDesc desc, i32 quality, i64* pLength);
i64   sc_jpg_write(char* pPath, void* pData, ScImageDesc desc, i32 quality);
```

Только **baseline** JPEG (не progressive). Кодирование: `comp` 1..4,
alpha игнорируется, `quality` 1..100 (`0` → 90). Формат с потерями.

### 12.5 GIF

```c
typedef struct
{
    i32 Width, Height, Frames, Channels; // Channels = 4
    void* pData;      // Frames * W * H * 4, RGBA
    i32* aDelays;     // Frames задержек, мс
} ScGifAnim;

ScGifAnim sc_gif_decode(void* pData, i64 dataSize);
ScGifAnim sc_gif_read(char* pPath);
```

Только чтение. Все кадры склеены в один RGBA-буфер; `aDelays[i]` —
задержка i-го кадра. При ошибке `pData == NULL`.

### 12.6 QOI

```c
typedef enum { ScQoiColorspace_Srgb = 0, ScQoiColorspace_Linear = 1 } ScQoiColorspace;
typedef enum { ScQoiChannels_Rgb = 3, ScQoiChannels_Rgba = 4 } ScQoiChannels;
typedef struct { i32 Width, Height, Channels, Colorspace; } ScQoiDesc;

void* sc_qoi_encode(void* pData, ScQoiDesc desc, i64* pLength);
void* sc_qoi_decode(void* pData, i64 dataSize, ScQoiDesc* pDesc, i32 channels);
void* sc_qoi_read(char* pPath, ScQoiDesc* pDesc, i32 channels);
i64   sc_qoi_write(char* pPath, void* pData, ScQoiDesc desc);
```

Lossless, RGB/RGBA. `channels` при декодировании: `0` — из заголовка,
`3/4` — принудительно. `Colorspace` пишется в файл, но не влияет на
кодирование.

Пример:

```c
ScImageDesc desc = { .Width = 64, .Height = 64, .Channels = 4 };
u8* pixels = sc_memory_allocate(64 * 64 * 4);
i64 pngSize = 0;
void* png = sc_png_encode(pixels, desc, &pngSize);
if (png)
{
    sc_file_write("out.png", png, (u64)pngSize);
    sc_memory_free(png);
}
sc_memory_free(pixels);
```

---

## 13. QOA (аудио)

```c
#define SC_QOA_FRAME_LEN 5120
#define SC_QOA_MAX_CHANNELS 8
#define SC_QOA_LMS_LEN 4
#define SC_QOA_MAGIC 0x716f6166

typedef struct { i32 aHistory[4]; i32 aWeights[4]; } ScQoaLms;

typedef struct
{
    i32 Channels;          // 1..8
    i32 Samplerate;        // 1..16777215
    i32 SamplesPerChannel; // 0 = streaming
    ScQoaLms aLms[8];
} ScQoaDesc;

void* sc_qoa_encode(i16* pSampleData, ScQoaDesc* pDesc, i64* pLength);
i16*  sc_qoa_decode(void* pData, i64 dataSize, ScQoaDesc* pDesc);
i64   sc_qoa_write(char* pPath, i16* pSampleData, ScQoaDesc* pDesc);
i16*  sc_qoa_read(char* pPath, ScQoaDesc* pDesc);

i32 sc_qoa_max_frame_size(ScQoaDesc* pDesc);
i32 sc_qoa_encode_frame(i16* pSampleData, ScQoaDesc* pDesc, i32 frameLen, u8* pBytes);
i32 sc_qoa_decode_frame(void* pData, i64 dataSize, ScQoaDesc* pDesc,
                        i16* pSampleData, i32* pFrameLen);
```

PCM — `i16`, каналы interleaved. Полные функции кодируют/декодируют
весь буфер; `_frame` — для потока.

**NOTE:**
- `sc_qoa_decode` округляет размер вверх до целых фреймов; хвост
  заполнен нулями, реальное число сэмплов — в `pDesc->SamplesPerChannel`.
- `sc_qoa_encode` сбрасывает LMS-состояние в `pDesc` в начальное и
  обновляет его по ходу.
- `sc_qoa_decode_frame` требует, чтобы `Channels`/`Samplerate` в
  `pDesc` совпадали с фреймом.

---

## 14. TrueType и шрифты

### 14.1 `ScTrueTypeFontInfo` — низкий уровень

```c
typedef struct
{
    u8* pData;       // данные шрифта, НЕ копируются
    i32 FontStart;
    i32 NumGlyphs;
    /* внутренние смещения таблиц ... */
} ScTrueTypeFontInfo;
```

Контракт: `pData` должен жить всё время использования
`ScTrueTypeFontInfo`. Глифы и метрики — в **несмасштабированных**
координатах (`unitsPerEm`).

```c
i32 sc_true_type_init(ScTrueTypeFontInfo* pInfo, u8* pData, i32 fontStart);
i32 sc_true_type_get_number_of_fonts(u8* pCollection);
i32 sc_true_type_get_font_offset_for_index(u8* pCollection, i32 index);

i32 sc_true_type_find_glyph_index(ScTrueTypeFontInfo* pInfo, i32 codepoint);

i32 sc_true_type_get_glyph_shape(ScTrueTypeFontInfo* pInfo, i32 glyphIndex,
                                 ScTrueTypeVertex** ppVertices);
void sc_true_type_free_shape(ScTrueTypeVertex* pVertices);

i32 sc_true_type_is_glyph_empty(ScTrueTypeFontInfo* pInfo, i32 glyphIndex);
i32 sc_true_type_get_glyph_box(ScTrueTypeFontInfo* pInfo, i32 glyphIndex,
                               i32* pX0, i32* pY0, i32* pX1, i32* pY1);
void sc_true_type_get_glyph_h_metrics(ScTrueTypeFontInfo* pInfo, i32 glyphIndex,
                                      i32* pAdvanceWidth, i32* pLeftSideBearing);
void sc_true_type_get_font_v_metrics(ScTrueTypeFontInfo* pInfo,
                                     i32* pAscent, i32* pDescent, i32* pLineGap);
void sc_true_type_get_font_bounding_box(ScTrueTypeFontInfo* pInfo,
                                        i32* pX0, i32* pY0, i32* pX1, i32* pY1);
f32 sc_true_type_scale_for_pixel_height(ScTrueTypeFontInfo* pInfo, f32 pixelHeight);

i32 sc_true_type_get_glyph_bitmap_box_subpixel(..., f32 shiftX, f32 shiftY, ...);
i32 sc_true_type_get_glyph_bitmap_box(...);
void sc_true_type_make_glyph_bitmap_subpixel(..., u8* pOutput, ...);
void sc_true_type_make_glyph_bitmap(...);
i32 sc_true_type_get_glyph_bitmap(..., ScTrueTypeBitmap* pBitmapOut);
void sc_true_type_free_bitmap(ScTrueTypeBitmap* pBitmap);
```

`ScTrueTypeVertex` — вершина контура (`Move/Line/Curve/Cubic`) в
несмасштабированных координатах. `ScTrueTypeBitmap` — 8-битная
coverage-маска (`sc_memory_free`).

### 14.2 `ScFont` — атлас и обёртка текста

```c
typedef struct
{
    const char* pPath;
    void* pData;
    i32 FontSize;
    i32 RangeMin;
    i32 RangeMax;
} ScFontConfig;

typedef struct
{
    i32 Codepoint;
    u16 X0, Y0, X1, Y1;
    f32 Xoff, Yoff, Xadvance;
} ScFontChar;

typedef struct { i64 Key; ScFontChar Value; } ScFontCharTable;

typedef struct
{
    char* pName;
    ScFontCharTable* hCharTable;
    i32 RangeMin, RangeMax;
    void* pBitmap;
    v2 Size;
    i32 FontSize;
    i32 MaxHeight;
    i32 MaxYOffset;
} ScFont;

ScFont sc_font_new(ScFontConfig cfg);
void   sc_font_destroy(ScFont safFont);

v2 sc_font_get_space_metrics(ScFont safFont);
v2 sc_font_get_metrics(ScFont safFont, char* pText);
```

`ScFontConfig` требует:
- либо `pPath` (файл читается внутри), либо `pData` (буфер шрифта);
- `FontSize > 0`;
- `RangeMin`/`RangeMax` — диапазон Unicode для атласа (например,
  `32..126` для ASCII или `32..0x45F` для ASCII+кириллицы).

`sc_font_new` на отсутствующем файле уходит в `sc_guard`. После
создания проверяйте `pBitmap`/`hCharTable`: при ошибке/пустом шрифте
они могут быть `NULL`. В режиме только `pData` поле `pName` будет
`NULL`.

`pBitmap` — RGBA (`R=G=B=A=coverage`), готов для блита с
альфа-смешиванием. `sc_font_destroy(font)` освобождает bitmap и
таблицу.

**NOTE:**
- `sc_font_get_metrics` читает значение из `hCharTable` до проверки
  индекса; для отсутствующего code point возможен выход за границы.
  Бэкенд `RasterBackend` поэтому сначала проверяет
  `sc_dict_i_contains`.
- для строк не длиннее 1024 code point используется общий статический
  буфер (не потокобезопасно); для более длинных — временная аллокация;
- `\n` в текущей реализации не добавляет высоту строки
  (соответствующий код закомментирован).

Обёртка:

```c
typedef struct
{
    f32 WrapWidth;
    char* pFullText;
    ScFont* pFont;
} ScFontWrapperConfig;

typedef enum
{
    ScFontWrapState_Empty = 0,
    ScFontWrapState_Newline,
    ScFontWrapState_Wrapped,
} ScFontWrapState;

typedef struct
{
    ScFont* pFont; char* pFullText; f32 WrapWidth;
    char* pIterText; char* pPrevIterText;
    ScStringView View;
} ScFontWrapper;

ScFontWrapper sc_font_wrapper_new(ScFontWrapperConfig cfg);
ScFontWrapState sc_font_wrap_text(ScFontWrapper* pWrapper);
```

`pWrapper->View` — view в исходную строку; жив, пока жива строка.
`sc_font_wrapper_new` требует ненулевой `pFont`, непустой `pFullText`
и `WrapWidth > 0` (иначе assert). Слишком длинные слова режутся
принудительно.

---

## 15. Raster и Window

### 15.1 `ScRaster`

Формат пикселя: 32 bpp, `0xAARRGGBB` (в памяти little-endian байты
`B,G,R,A`). Координаты API — **Y-вверх**: `y = 0` — низ, `y = Height-1`
— верх. В памяти строки лежат сверху вниз; `set_pixel`/`fill_rect`
переворачивают Y.

```c
typedef struct
{
    void* pData;
    u16 Width, Height;
} ScRasterBuffer;

typedef struct
{
    i32 BufferCurrent;
    i32 BuffersCount; // 2
    u16 Width, Height;
    u16 MaxWidth, MaxHeight;
    ScRasterBuffer aBuffers[2];
} ScRaster;

ScResult sc_raster_init(ScRaster* pRaster, i32 width, i32 height,
                        i32 maxWidth, i32 maxHeight); // 0 = без запаса
void sc_raster_resize(ScRaster* pRaster, i32 width, i32 height);
ScRasterBuffer sc_raster_get_buffer(ScRaster* pRaster);
ScRasterBuffer sc_raster_swap(ScRaster* pRaster);
void sc_raster_set_pixel(ScRasterBuffer buffer, i32 x, i32 y, u32 color);
void sc_raster_clear_color(ScRaster* pRaster, u32 color);
void sc_raster_draw_line(ScRaster*, i32 x0, i32 y0, i32 x1, i32 y1, u32 color);
void sc_raster_draw_rect(ScRaster*, i32 x, i32 y, i32 w, i32 h, u32 color);
void sc_raster_fill_rect(ScRaster*, i32 x, i32 y, i32 w, i32 h, u32 color);
void sc_raster_draw_text(ScRaster*, ScFont* pFont, i32 x, i32 y,
                         u32 color, char* pText);
void sc_raster_free(ScRaster* pRaster);
```

`MaxSize` — это максимальный размер, на который сразу выделяются оба
буфера. `sc_raster_resize` меняет только `Width/Height`; если новый
размер больше `MaxSize`, он обрезается. `sc_raster_swap` возвращает
**готовый** (законченный) буфер и переключает активный.

`sc_raster_draw_text`: `(x, y)` — базовая линия (baseline) первого
ряда; координаты Y-вверх. `'\n'` сбрасывает `x` и делает `y -= FontSize`.
Символы вне `RangeMin..RangeMax` и отсутствующие в шрифте пропускаются.

### 15.2 `ScWindow`

```c
typedef struct
{
    const char* pName;
    i32 NameLength;
    i32 UseGraphics;
    v2 Size, MinSize, MaxSize;
    v2 Position; // {0,0} = центр экрана
} ScWindowConfig;

typedef struct
{
    i8 IsAlive, IsMaximized, IsFullscreen, IsGrabed;
    i8 aKeyCounter[ScKey_Count];
    const char* pName;
    v2 Size, MinSize, MaxSize, Position, Mouse;
    ScCall OnEvent;
    ScAction aKeys[ScKey_Count];
    ScAction aMouseKeys[ScMouseKey_Count];
    void* pBackend;
    void* pGraphics;
} ScWindow;

void sc_window_create(ScWindow* pScWindow, ScWindowConfig set);
void sc_window_destroy(ScWindow* pWindow);
void sc_window_update(ScWindow* pWindow);
void sc_window_set_event_call(ScWindow* pWindow, ScCall call);
void sc_window_set_title(ScWindow* pWindow, char* pTitle);
void sc_window_set_headless(ScWindow* pWindow, i32 isSet);
void sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet);
void sc_window_set_above(ScWindow* pWindow, i32 isSet);
void sc_window_set_grabed_ext(ScWindow* pWindow, i32 flag);
void sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible);
void sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y);
void sc_window_set_position(ScWindow* pWindow, i32 x, i32 y);

// Платформенные getters (только соответствующая платформа)
void* xcb_sc_window_get_window(ScWindow* pWindow);
void* xcb_sc_window_get_connection(ScWindow* pWindow);
void* win32_sc_window_get_window(ScWindow* pWindow);
void* win32_sc_window_get_connection(ScWindow* pWindow);
```

События:

```c
typedef enum { ScEventType_None = 0, /* ... */ } ScEventType;
typedef struct { i32 IsHandled; ScEventType Type; } ScEvent;
typedef void (*ScCall)(ScEvent*);
```

Типы событий: `KeyType`, `KeyPress`, `KeyRelease`, `MousePress`,
`MouseRelease`, `KeyboardMapping`, `MouseMove`, `MouseScroll`,
`WindowMoved`, `WindowResized`, `WindowClosed`, `WindowMaximized`,
`WindowFocused`, `WindowEnter`, `WindowHidden`.

Поля событий: `ScKeyPressEvent { Key, KeyMod }`,
`ScKeyTypeEvent { CodePoint }`, `ScMousePressEvent { Key }`,
`ScMouseScrollEvent { Value }`, `ScMouseMoveEvent { X, Y }`,
`ScWindowResizeEvent { Width, Height }`,
`ScWindowEnterEvent { IsInside }`, `ScWindowFocusedEvent { Focused }`.

Хелперы:

```c
const char* sc_window_key_to_string(ScKey key);
const char* sc_mouse_key_to_string(ScMouseKey key);
const char* sc_event_type_to_string(ScEventType type);
ScKeyMod sc_key_mod_from_native(i32 native);
ScKey sc_key_from_native(i32 native);
i32 sc_window_key_is_printable(ScKey key);

sc_window_key_press(event);    // ScKey или ScKey_None
sc_window_key_release(event);
sc_window_mouse_press(event);
sc_window_mouse_release(event);
```

**NOTE:**
- `sc_window_create` в конце **безусловно** ставит `IsAlive = 1`, даже
  если платформа не создала окно. Проверяйте `pWindow->pBackend` /
  `pGraphics` или ответ платформы.
- На XCB событие закрытия окна не сбрасывает `IsAlive`
  автоматически — сэмпл делает это вручную в callback. На WIN32
  обработчик закрытия сбрасывает.
- `aKeys[ScKey_X] == ScAction_Press` остаётся `Press`, пока клавиша
  удерживается. Для «нажатие в этом кадре» используйте callback или
  `aKeyCounter` (увеличивается на press, сбрасывается на release).
- `Mouse` и координаты `MouseMove` — Y-вверх.
- `sc_window_destroy` освобождает платформенные ресурсы, но сама
  структура `ScWindow` остаётся во владении вызывающего.

### 15.3 Графика окна

```c
ScRaster* sc_window_get_raster(ScWindow* pWindow);
void sc_window_graphics_init(ScWindow* pWindow);
void sc_window_graphics_resize(ScWindow* pWindow);
void sc_window_graphics_swap_buffers(ScWindow* pWindow);
```

При `UseGraphics != 0` окно создаёт собственный `ScRaster`.
`sc_window_graphics_swap_buffers` забирает готовый буфер у растера
окна (`sc_raster_swap`) и блитит его. Если вы рисуете в другом растре
(например, в растре UI-бэкенда), скопируйте кадр в растер окна перед
вызовом swap (см. сэмпл `Source/Samples/Ui/Ui.c`).

Минимальный цикл окна:

```c
ScWindow window = {};
sc_window_create(&window, (ScWindowConfig) {
    .pName = "App",
    .NameLength = 3,
    .UseGraphics = 1,
    .Size = { .Width = 800, .Height = 600 },
    .MaxSize = { .Width = 1600, .Height = 1200 },
});

while (window.IsAlive)
{
    sc_window_update(&window);
    ScRaster* pRaster = sc_window_get_raster(&window);
    sc_raster_clear_color(pRaster, 0xFF202020);
    // ... sc_raster_* ...
    sc_window_graphics_swap_buffers(&window);
}

sc_window_destroy(&window);
```

---

## 16. UI и RasterBackend

### 16.1 Модель UI

UI — немедленный режим (immediate mode): каждый кадр виджеты создаются
заново. Состояние (hover/click) хранится между кадрами.

Порядок кадра:

```c
sc_ui_frame_begin();
// sc_ui_widget_begin / sc_ui_text / sc_ui_image ...
sc_ui_layout();
sc_ui_process_input();
sc_raster_backend_render();   // или свой backend
sc_ui_frame_end();
```

`sc_ui_frame_end` очищает список виджетов и arena строк (1 МБ).
Строки `pText` копируются в arena и живут до `frame_end`; **рендер
обязан быть до `frame_end`**.

### 16.2 Типы

```c
typedef struct { i64 Hash; char* pData; } ScSid;

typedef struct
{
    i64 ActiveId, HotId, ActivePanelId, HotPanelId;
    i8 IsLeftKeyWasPressed;
} ScUiInteractive;

typedef struct
{
    i32 ShouldUseGradient;
    v4 Idle, Hovered, Clicked;
} ScUiColor;

typedef enum { ScUiState_None = 0, ScUiState_Hovered, ScUiState_Clicked, ScUiState_Pressed } ScUiState;

typedef enum
{
    ScUiMetricType_Fit = 0,
    ScUiMetricType_Fixed,
    ScUiMetricType_Relative,
    ScUiMetricType_Grow,
} ScUiMetricType;

typedef struct { f32 Value; ScUiMetricType Type; } ScUiMetric;
```

Метрики:

```c
Fixed(v); // для Size всегда пиксели; для root Position v <= 1.0 = доля экрана
Fit(v);   // v игнорируется
Grow(v);  // v игнорируется
```

`Fit`/`Grow` считают от детей/родителя.
`ScUiMetricType_Relative` в текущей реализации не обрабатывается.

```c
typedef struct
{
    ScUiMetric Width, Height;
    f32 MinWidth, MinHeight, MaxWidth, MaxHeight;
} ScUiSizeMetrics;

typedef struct { ScUiMetric X, Y; } ScUiPositionMetrics;

typedef struct { i16 Left, Top, Right, Bot; } ScUiPad;
#define ScUiPad(l, t, r, b) ...
#define ScUiPadAll(v) ...
```

**NOTE:** макрос `ScUiPad(...)` конфликтует с именем типа `ScUiPad`.
Если нужен именно тип, используйте compound literal
`(ScUiPad){ .Left = 1, ... }` или `ScUiPadAll`.

```c
typedef struct
{
    ScUiPad Padding;
    i16 ChildGap;
    ScUiDirection Direction; // Vertical / Horizontal
} ScUiLayout;

typedef enum
{
    ScUiWidgetType_Rectangle = 0,
    ScUiWidgetType_Image,
    ScUiWidgetType_Atlas,
    ScUiWidgetType_Text,
} ScUiWidgetType;

typedef enum
{
    ScUiTextAlign_X_Left = 0,
    ScUiTextAlign_Y_Center = 0,
    ScUiTextAlign_X_Center,
    ScUiTextAlign_X_Right,
    ScUiTextAlign_Y_Top,
    ScUiTextAlign_Y_Bot,
} ScUiTextAlign;

typedef enum { ScUiPositioningMode_None = 0, ScUiPositioningMode_Wrap } ScUiPositioningMode;
```

### 16.3 Конфиг и виджет

```c
typedef struct
{
    char* pName;
    ScUiFlag Flag;          // Dead / Alive / Alive_Enabled
    ScUiWidgetType Type;

    ScUiColor Color;
    i64 AssetId;
    i16 AssetItem;

    i16 FontSize;
    char* pText;
    char* pFontPath;

    ScUiSizeMetrics Size;
    ScUiPositionMetrics Position;

    ScUiTextAlign Horizontal;
    ScUiTextAlign Vertical;
    ScUiPositioningMode PositioningMode;

    ScUiLayout Layout;
} ScUiWidgetConfig;

typedef struct
{
    ScUiWidgetConfig Config;
    ScSid Id;
    i64* aChildren;
    ScUiState State;
    f32 X, Y, Width, Height;
    i64 Parent;
} ScUiWidget;
```

API:

```c
const char* sc_ui_widget_type_to_string(ScUiWidgetType type);

ScUiState sc_ui_widget_begin(...);   // макрос с compound literal
ScUiState sc_ui_widget_begin_x(...); // то же, но сам добавляет { }
void      sc_ui_widget_end();
ScUiState sc_ui_text(...);
ScUiState sc_ui_image(...);

void sc_ui_layout();
i32  sc_ui_process_input();
void sc_ui_frame_begin();
void sc_ui_frame_end();

ScUiWidget* sc_ui_widgets_get();
ScUiWidget* sc_ui_widget_get_child_by_index(ScUiWidget* pWidget, i16 childInd);
void sc_ui_widget_print(ScUiWidget* aWidgets, i32 tab);

ScUiColor sc_ui_color_default(ScUiColor color);
```

Пример:

```c
sc_ui_frame_begin();

sc_ui_widget_begin({
    .pName = "Panel",
    .Type = ScUiWidgetType_Rectangle,
    .Flag = ScUiFlag_Alive,
    .Color = {
        .Idle = v4_rgb(30, 30, 40),
        .Hovered = v4_rgb(40, 40, 50),
    },
    .Size = { .Width = Fixed(400), .Height = Fixed(300) },
    .Position = { .X = Fixed(200), .Y = Fixed(400) },
    .Layout = {
        .Direction = ScUiDirection_Vertical,
        .Padding = ScUiPadAll(12),
        .ChildGap = 8,
    },
});

sc_ui_text({
    .pName = "Title",
    .pText = "Hello",
    .FontSize = 24,
    .Horizontal = ScUiTextAlign_X_Center,
    .Color = { .Idle = v4_rgb(255, 255, 255) },
});

sc_ui_widget_end();

sc_ui_layout();
sc_ui_process_input();
sc_raster_backend_render();
sc_ui_frame_end();
```

**NOTE (очень важно):**
- `sc_ui_widget_begin` возвращает состояние из **предыдущего** кадра
  (из `aWidgetStates`). `sc_ui_process_input` в начале своего вызова
  очищает `aWidgetStates` (`sc_list_clear`), затем пересчитывает
  состояния по текущему вводу. Виджеты уже прочитали старые значения,
  поэтому клик становится виден в следующем кадре.
- `pName` фактически обязателен: `sc_ui_csid_new` хеширует строку, а
  `NULL` приводит к падению.
- Идентификатор виджета хеширует первые `sc_utf8_length(...)` байт
  имени. `sc_utf8_length` возвращает число code point, а не байт,
  поэтому для не-ASCII имён хешируется только часть строки; возможны
  обрезание/коллизии. Используйте короткие уникальные ASCII-имена.
- UI Y-вверх: `Y` — **верхняя** граница виджета; дети раскладываются
  вниз.
- `Padding` в текущей раскладке **не учитывается при позиционировании
  детей** (влияет только на `Fit`-размер). Не рассчитывайте на отступы
  внутри панели.
- Для текста есть спецповедение: если `pText[0] == '-'`, `Y`
  сдвигается на 25; выравнивание по вертикали в основном
  игнорируется.
- `sc_ui_image` в RasterBackend ничего не рисует (см. ниже).

### 16.4 Input

```c
typedef enum { ScUiKeyState_None = 0, ScUiKeyState_Pressed, ScUiKeyState_Released } ScUiKeyState;
typedef struct { i8 IsHandled; ScUiKeyState State; } ScUiKeyData;

typedef enum
{
    ScUiKey_Undefined = 0,
    ScUiKey_Mouse_Left_Button,
    ScUiKey_Mouse_Right_Button,
    ScUiKey_Mouse_Middle_Button,
    ScUiKey_Tab, ScUiKey_Backspace,
    ScUiKey_LeftArrow, ScUiKey_RightArrow, ScUiKey_UpArrow, ScUiKey_DownArrow,
    ScUiKey_Home, ScUiKey_End, ScUiKey_Delete,
    ScUiKey_Count,
} ScUiKey;

typedef struct
{
    v2 MousePosition;
    ScUiKeyData aKeys[ScUiKey_Count];
} ScUiInput;

ScUiInput* sc_ui_backend_get_input();
```

Заполняйте `ScUiInput` из событий окна: мышь — `MousePosition` и
`ScUiKey_Mouse_*`, клавиши — `aKeys[...].State`. `IsHandled`
сбрасывайте в `0` при новом событии. `ScUiKey` не знает букв/Escape;
их обрабатывайте в пользовательском коде.

### 16.5 Бэкенд UI

```c
typedef struct
{
    void (*DrawRect)(v3 position, v2 size, v4 color);
    void (*DrawEmptyRect)(v3 position, v2 size, real thickness, v4 color);
    void (*DrawImage)(v3 position, v2 size, v4 color, i64 textureId);
    void (*DrawImageAtlasItem)(v3 position, v2 size, v4 color, i64 textureId, i32 index);
    void (*DrawText)(char* pText, i32 fontSize, v3 position, v4 glyphColor);
    void (*SetViewport)(i32 x0, i32 y0, i32 width, i32 height);
    v2 (*GetTextMetrics)(char* pText, i32 fontSize, char* pFontPath);
} ScUiBackendRender;

typedef struct { ScUiBackendRender Render; } ScUiBackendConfig;
typedef struct { v2 DisplaySize; } ScUiBackendState;

void sc_ui_backend_new(ScUiBackendConfig config);
void sc_ui_backend_update(ScUiBackendState state);
void sc_ui_backend_render();
```

### 16.6 RasterBackend

```c
void sc_raster_backend_new();
void sc_raster_backend_update(ScUiBackendState state);
void sc_raster_backend_render();
ScUiInput* sc_raster_backend_get_input();
ScRaster* sc_raster_backend_get_raster();

i64 sc_raster_backend_load_texture(char* pTextureName, void* pData,
                                   u32 width, u32 height, u8 channel);
ScRasterImage* sc_raster_backend_get_texture_by_id(i64 textureId);
void sc_raster_backend_unload_texture(i64 textureId);

i64 sc_raster_backend_load_font(char* pFontPath, i32 fontSize);
i64 sc_raster_backend_load_font_ext(char* pFontPath, i32 fontSize,
                                    i32 rangeMin, i32 rangeMax);
ScFont* sc_raster_backend_get_font_by_id(i64 fontId);
void* sc_raster_backend_load_font_by_id(i64 fontId);
void sc_raster_backend_unload_font(i64 fontId);

void sc_raster_backend_free();
```

`ScRasterImage`:

```c
typedef struct
{
    i64 Id;
    void* pData;   // принадлежит вызывающему
    u32 Width, Height;
    u8 Channels;
} ScRasterImage;
```

**NOTE:**
- `DrawImage`, `DrawImageAtlasItem`, `SetViewport` в текущей
  реализации — **no-op**; `sc_ui_image` ничего не рисует.
- `DrawText` выбирает первый загруженный шрифт подходящего размера,
  иначе первый живой. Загрузите шрифт до первого рендера:
  `sc_raster_backend_load_font(path, size)`.
- Ключ регистрации шрифта — `"path#size"`; повторная загрузка того же
  пути и размера возвращает существующий шрифт, **игнорируя новый
  range**. Если нужен другой диапазон, используйте другой размер или
  отдельный путь.
- Внутренний растер бэкенда — максимум **1920x1080**;
  `sc_raster_backend_update` обрезает размер больше этого без
  реаллокации.
- `sc_raster_backend_load_font_ext` нужен для кириллицы/других языков:
  диапазон задаётся при загрузке.
- `sc_raster_backend_load_texture` не копирует `pData`; данные должны
  жить, пока текстура используется.
- Бэкенд рисует в собственный `ScRaster`; окно нужно блитить отдельно
  (см. сэмпл UI).

Полный цикл UI+окно — в `Source/Samples/Ui/Ui.c`. Минимальный:

```c
sc_window_create(&window, (ScWindowConfig) {
    .pName = "UI", .NameLength = 2, .UseGraphics = 1,
    .Size = { .Width = 800, .Height = 600 },
    .MaxSize = { .Width = 1920, .Height = 1080 },
});
sc_raster_backend_new();
sc_raster_backend_load_font("Resources/Fonts/MartianMono-sWdRg.ttf", 18);
sc_window_set_event_call(&window, on_event);

while (window.IsAlive)
{
    sc_window_update(&window);
    sc_raster_backend_update((ScUiBackendState) {
        .DisplaySize = window.Size,
    });

    sc_ui_frame_begin();
    // ... виджеты ...
    sc_ui_layout();
    sc_ui_process_input();
    sc_raster_backend_render();
    sc_ui_frame_end();

    // копирование кадра UI в растер окна
    ScRaster* pDst = sc_window_get_raster(&window);
    ScRaster* pSrc = sc_raster_backend_get_raster();
    ScRasterBuffer src = sc_raster_get_buffer(pSrc);
    ScRasterBuffer dst = sc_raster_get_buffer(pDst);
    if (src.Width == dst.Width && src.Height == dst.Height)
        sc_copy(dst.pData, src.pData, (u64)src.Width * src.Height * 4);

    sc_window_graphics_swap_buffers(&window);
}

sc_raster_backend_free();
sc_window_destroy(&window);
```

---

## 17. WIP и исключённые модули

### 17.1 Asset (`Data/Asset.h`) — `EXCLUDED`

Формат пакета описан в комментарии заголовка. Публичные функции:

```c
typedef i64 ScAssetId;
#define ScInvalidAssetId (-1337)

void sc_asset_new();
void sc_asset_new_from_package(const char* pPath);
void sc_asset_destroy();

ScAssetId sc_asset_load_image(const char* pPath);
ScAssetId sc_asset_load_font(const char* pPath);
ScAssetId sc_asset_load_model(const char* pPath);
ScAssetId sc_asset_load_sound(const char* pPath);

void sc_asset_get_image(ScAssetId id, void* pData, i64 dataSize);
void sc_asset_get_font(ScAssetId id, void* pData, i64 dataSize);
void sc_asset_get_model(ScAssetId id, void* pData, i64 dataSize);
void sc_asset_get_sound(ScAssetId id, void* pData, i64 dataSize);
```

Не входит в `Sc.masuka`; API нестабилен, формат пакета описан
эскизно. Для загрузки ресурсов используйте файловые функции + Png/Jpg/
Qoi/Gltf/Qoa.

### 17.2 Hash / Crypt / RapidHash — `EXCLUDED`

- `Data/Hash.h` и `Data/Crypt.h` сейчас **пустые** (только include
  guard).
- `Data/Hash.c`, `Data/RapidHash.c`, `Data/Crypt.c` не входят в
  сборку; это WIP/сторонний код.
- Для хешей используйте `sc_string_hash`, `sc_i32_hash`, `sc_i64_hash`,
  `sc_u64_hash`, `alt_hash` из `Sc.h`.

### 17.3 AI/BPE (`Ai.h`) — `WIP`

```c
typedef struct { char* pText; i64 TextLength; i64 MergesCount; } ScAiBpeConfig;
typedef struct { char* pValue; } ScBpeVocabItem;
typedef struct { u32 A, B; i32 Count; } ScBpeTokenPair;
typedef struct { u32 T0, T1, Tf; } ScAiMerge;

typedef struct
{
    u32* aTokens;
    ScAiMerge* aMerges;
    ScBpeVocabItem* aVocab;
} ScAiBpe;

typedef struct { /* ... */ } ScAiBpeSaveToDiskConfig;
typedef struct { char* pText; i64 TextLength; ScAiBpe Bpe; } ScAiTokenizeConfig;

ScAiBpe sc_ai_bpe_new(ScAiBpeConfig cfg);
ScAiBpe sc_ai_bpe_new2(ScAiBpeConfig cfg);
void sc_ai_bpe_save_to_disk(ScAiBpeSaveToDiskConfig cfg);
ScAiBpe sc_ai_bpe_load_from_disk(char* pFile);
ScAiBpe sc_ai_bpe_load_from_memory(char* pData, i64 dataSize);
void sc_bpe_token_pair_print(ScBpeTokenPair pair, i32 done, i32 total);
```

`Ai.c` компилируется, но модуль экспериментальный: API токенизации не
описан в заголовке полностью (`sc_ai_tokenize` и т.п. отсутствуют в
публичном контракте). Не используйте как стабильный интерфейс.

### 17.4 Vk / Vulkan — `EXCLUDED`

`Gfx/Vk.c`, `Gfx/Vulkan.c` не входят в `Sc.masuka`: нужен Vulkan SDK,
Linux-реализация, на Windows `Vk.c` содержит
`#error "Implementation pending"`. `Vk.h` — обёртка над
сгенерированными Vulkan-биндингами (`VkInstance`, `VkDevice`,
`VkSwapchainKHR`, `ScVkImage`, `ScTexture`, `Sc2dTexture` и т.д.).
`Vulkan.h` — сгенерированные типы/функции Vulkan (тысячи строк).
Документировать их поштучно нет смысла; используйте официальный
Vulkan API и `Vk.h` как заготовку.

---

## 18. Матрица статусов и типичные ошибки

### 18.1 Статусы

| Модуль | Статус | Комментарий |
|---|---|---|
| `Sc.c` (строки, списки, словари, файлы, память) | `TEST`/`WIP` | много исторических багов, см. §3–§6 |
| `Types.c` | `READY` | базовые типы, система |
| `Math.h` | `TEST` | есть ошибки в отдельных функциях, см. §7 |
| `Ecs.c` | `TEST` | singleton, валидация неполная |
| `Reflect.c` | `TEST` | реестр типов |
| `Test.c` | `TEST` | есть баги в `v4_equal` |
| `Json.c` | `TEST` | срезы, без escape-декодирования |
| `Gltf.c` | `WIP` | эвристический парсер, утечки |
| `Png/Jpg/Gif/Qoi` | `READY`/`TEST` | нативные кодеки |
| `Qoa.c` | `READY`/`TEST` | нативный кодек |
| `TrueType.c`/`Font.c` | `TEST` | атлас, ограничения метрик |
| `Raster.c` | `TEST` | программный рендерер |
| `Window.c` | `WIP` | активно развивается |
| `Ui.c`/`RasterBackend.c` | `WIP` | layout/состояния/картинки неполные |
| `Mime.c` | `TEST` | `new_from_path` ожидает `.ext` |
| `Ai.c` | `WIP` | BPE-эксперимент |
| `Asset.c` | `EXCLUDED` | не в сборке |
| `Hash/Crypt/RapidHash` | `EXCLUDED` | пустые/сторонние |
| `Vk/Vulkan` | `EXCLUDED` | нужен Vulkan SDK |

### 18.2 Частые ошибки

1. **Считать `sc_string_get_length` длиной в символах.** Это байты.
   Символы — `sc_utf8_length`; объект — `sc_string_length`.
2. **Ждать от `sc_format` NUL-терминации.** Её нет; обнуляйте буфер.
3. **Использовать `sc_list_pop` как `pop_back`.** Он удаляет первый.
4. **Передавать в макросы списка/словаря не-lvalue.** Макрос
   переприсваивает указатель.
5. **Вызывать `sc_dict_*_get` без `contains`.** Возможен выход за
   границу.
6. **Хранить строковый ключ словаря во временном буфере.**
   Сохраняется указатель, не копия.
7. **Вызывать `sc_memory_free` внутри арены.** Это no-op.
8. **Использовать `sc_string_new_trimed`/`sc_string_replace`.** Баги.
9. **Читать `quat_*` как «правильную» математику.** См. §7.
10. **Ждать от UI состояния текущего кадра.** Состояние отстаёт на
    кадр.
11. **Рисовать UI после `sc_ui_frame_end`.** Строки уже освобождены.
12. **Забыть загрузить шрифт в RasterBackend.** Текст не рисуется.
13. **Ждать от `sc_raster_backend` картинок.** `DrawImage` — no-op.
14. **Вызывать `sc_window_graphics_swap_buffers`, рисуя в другом
    растре.** Нужно скопировать кадр в растер окна.
15. **Проверять `sc_ecs_entity_id_validate` как «жив ли entity».**
    Проверяется только диапазон.
16. **Парсить отрицательные числа через `sc_parse_int`.** Не
    поддерживается.
17. **Передавать полный путь в `sc_mime_type_new_from_path`.**
    Ожидается `.ext`.

---

## 19. Рецепты

### 19.1 Прочитать файл и разобрать JSON

```c
char* pJson = sc_file_read("data.json");
if (!pJson)
    return;

i64 tokensCapacity = 4096;
ScJsonToken* aTokens = sc_memory_allocate(sizeof(ScJsonToken) * tokensCapacity);
ScJsonConfig cfg = {
    .pText = pJson,
    .TextLength = (u64)sc_string_get_length(pJson),
    .TokensCount = tokensCapacity,
    .aTokens = aTokens,
};
sc_json_parse(&cfg);

if (cfg.ErrorType == ScJsonError_None)
{
    // ...
}

sc_memory_free(aTokens);
sc_memory_free(pJson);
```

### 19.2 Загрузить PNG и вывести размер

```c
ScImageDesc desc = {};
void* pPixels = sc_png_read("image.png", &desc, 4);
if (pPixels)
{
    printf("%dx%d, %d channels\n", desc.Width, desc.Height, desc.Channels);
    sc_memory_free(pPixels);
}
```

### 19.3 Создать шрифт и нарисовать текст в окне

```c
ScFont font = sc_font_new((ScFontConfig) {
    .pPath = "Resources/Fonts/MartianMono-sWdRg.ttf",
    .FontSize = 24,
    .RangeMin = 32,
    .RangeMax = 0x45F, // ASCII + кириллица
});

if (font.pBitmap && font.hCharTable)
{
    ScRaster* pRaster = sc_window_get_raster(&window);
    sc_raster_draw_text(pRaster, &font, 16, 40, 0xFFFFFFFF, "Привет, Sc!");
    sc_font_destroy(font);
}
```

### 19.4 ECS-система движения

```c
typedef struct { v2 Position; } Position;
typedef struct { v2 Velocity; } Velocity;

static void
movement_system(f32 dt)
{
    ScEcsEntityId* aEntities = sc_ecs_get_all_entity_ids(Position, Velocity);
    for (i64 i = 0; i < sc_list_count(aEntities); ++i)
    {
        ScEcsEntityId e = aEntities[i];
        Position* p = sc_ecs_entity_get(e, Position);
        Velocity* v = sc_ecs_entity_get(e, Velocity);
        p->Position = v2_add(p->Position, v2_mulv(v->Velocity, dt));
    }
    sc_list_free(aEntities);
}
```

### 19.5 Сохранить изображение в QOI

```c
ScQoiDesc desc = {
    .Width = width,
    .Height = height,
    .Channels = 4,
    .Colorspace = ScQoiColorspace_Srgb,
};
i64 size = 0;
void* pQoi = sc_qoi_encode(pixels, desc, &size);
if (pQoi)
{
    sc_file_write("out.qoi", pQoi, (u64)size);
    sc_memory_free(pQoi);
}
```

---

## 20. Заключение

При добавлении нового кода придерживайтесь `Convention.md`, а при
использовании существующего API — проверяйте пометки **NOTE** в этом
документе. Если поведение функции кажется «странным», сначала
посмотрите её реализацию в `Source/Sc/**`: в проекте есть исторические
решения, которые нельзя менять без тестов и анализа вызывающего кода.
