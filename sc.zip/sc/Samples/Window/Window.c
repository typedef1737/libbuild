/*
  DOCS: Сэмпл окна: создание, события, set-функции. Крест-платформенно:
  Linux - xcb, Windows - WIN32/GDI (см. Sc/Gfx/Window.h).

  Что демонстрируется:
    - sc_window_create с конфигом (Min/MaxSize, Position, UseGraphics=0);
    - цикл событий: OnEvent-коллбек печатает приходящие события;
    - aKeys/aKeyCounter для опроса нажатий (Esc - выход);
    - set_title/set_position/set_headless/set_fullscreen по ходу жизни.

  Выход: закрыть окно (крестик) или нажать Esc.
*/
#include <Sc/Gfx/Window.h>
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>

static void
window_sample_on_event(ScEvent* pEvent)
{
    switch (pEvent->Type)
    {
    case ScEventType_KeyPress:
    {
        ScKeyPressEvent* pKey = (ScKeyPressEvent*)pEvent;
        printf("[Key]    press   %s (mod %d)\n",
            sc_window_key_to_string(pKey->Key), pKey->KeyMod);
        break;
    }
    case ScEventType_KeyRelease:
    {
        ScKeyReleaseEvent* pKey = (ScKeyReleaseEvent*)pEvent;
        printf("[Key]    release %s\n", sc_window_key_to_string(pKey->Key));
        break;
    }
    case ScEventType_KeyType:
    {
        ScKeyTypeEvent* pType = (ScKeyTypeEvent*)pEvent;
        printf("[Key]    type    codepoint %u ('%c')\n",
            pType->CodePoint, (char)pType->CodePoint);
        break;
    }
    case ScEventType_MouseMove:
    {
        ScMouseMoveEvent* pMouse = (ScMouseMoveEvent*)pEvent;
        printf("[Mouse]  move    %d x %d\n", pMouse->X, pMouse->Y);
        break;
    }
    case ScEventType_MousePress:
    {
        ScMousePressEvent* pMouse = (ScMousePressEvent*)pEvent;
        printf("[Mouse]  press   %s\n", sc_mouse_key_to_string(pMouse->Key));
        break;
    }
    case ScEventType_MouseRelease:
    {
        ScMouseReleaseEvent* pMouse = (ScMouseReleaseEvent*)pEvent;
        printf("[Mouse]  release %s\n", sc_mouse_key_to_string(pMouse->Key));
        break;
    }
    case ScEventType_MouseScroll:
    {
        ScMouseScrollEvent* pScroll = (ScMouseScrollEvent*)pEvent;
        printf("[Mouse]  scroll  %d\n", pScroll->Value);
        break;
    }
    case ScEventType_WindowResized:
    {
        ScWindowResizeEvent* pResize = (ScWindowResizeEvent*)pEvent;
        printf("[Window] resize  %d x %d\n", pResize->Width, pResize->Height);
        break;
    }
    case ScEventType_WindowMoved:
    {
        ScWindowPositionEvent* pPos = (ScWindowPositionEvent*)pEvent;
        printf("[Window] moved   %d x %d\n", (i32)pPos->Position.X, (i32)pPos->Position.Y);
        break;
    }
    case ScEventType_WindowFocused:
    {
        ScWindowFocusedEvent* pFocus = (ScWindowFocusedEvent*)pEvent;
        printf("[Window] focus   %d\n", pFocus->Focused);
        break;
    }
    case ScEventType_WindowMaximized:
    {
        printf("[Window] maximize\n");
        break;
    }
    case ScEventType_WindowHidden:
    {
        printf("[Window] hide (minimize)\n");
        break;
    }
    case ScEventType_WindowClosed:
    {
        printf("[Window] close\n");
        break;
    }
    default:
        break;
    }
}

i32
main()
{
    setvbuf(stdout, NULL, _IONBF, 0);

    ScWindowConfig conf = {
        .pName = "Sc Window Sample",
        .NameLength = 17,
        .UseGraphics = 0, /* окно без растера: только события */
        .Size = { .Width = 640, .Height = 480 },
        .MinSize = { .Width = 200, .Height = 150 },
        .MaxSize = { .Width = 1280, .Height = 960 },
        .Position = { .X = 100, .Y = 100 },
    };

    ScWindow window = {};
    sc_window_create(&window, conf);
    if (!window.IsAlive)
    {
        printf("Window creation failed!\n");
        return 1;
    }

    sc_window_set_event_call(&window, window_sample_on_event);
    printf("Window created. Print events. ESC to exit.\n");

    i32 frame = 0;
    while (window.IsAlive)
    {
        sc_window_update(&window);

        /* опрос состояния клавиш (вне коллбека) */
        if (window.aKeys[ScKey_Escape] == ScAction_Press)
        {
            printf("ESC pressed - exit\n");
            window.IsAlive = 0;
            break;
        }

        /* раз в 2 секунды: пробегаемся по set-функциям */
        if (frame % 120 == 60)
            sc_window_set_title(&window, "Sc Window Sample - renamed");
        if (frame % 120 == 90)
            sc_window_set_position(&window, 200, 200);

        ++frame;
        sc_sleep_ms(1); /* консоль не заливается событиями мыши */
    }

    sc_window_destroy(&window);
    printf("Window destroyed. Bye!\n");
    return 0;
}
