/*
  DOCS: Сэмпл рендеринга в окно: software renderer (ScRaster) +
  xcb/GDI-blit через окно. Крест-платформенно (Linux: xcb,
  Windows: WIN32/GDI).

  Что демонстрируется:
    - sc_window_create с UseGraphics=1 (растер создаётся сам);
    - sc_window_get_raster -> sc_raster_* (clear/set_pixel/draw_line);
    - двойная буферизация: sc_window_graphics_swap_buffers;
    - resize окна: буферы живут на MaxSize, resize без реаллокаций;
    - FPS-счётчик.

  Сцена: сетка разноцветных прямоугольников 4x3 (заливка + белый
  контур), плавающий белый прямоугольник по круговой орбите,
  рамка по краю. Выход: закрыть окно или Esc.
*/
#include <Sc/Gfx/Raster.h>
#include <Sc/Gfx/Window.h>
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>

/*
  DOCS: Грубый табличный синус (256 точек на круг, линейная
  интерполяция): для сэмпла хватает, math.h не тащим.
*/
static f32
render_sample_sin(f32 angle)
{
    static const f32 aTable[16] = {
        0.0f, 0.38268f, 0.70711f, 0.92388f,
        1.0f, 0.92388f, 0.70711f, 0.38268f,
        0.0f, -0.38268f, -0.70711f, -0.92388f,
        -1.0f, -0.92388f, -0.70711f, -0.38268f
    };

    f32 t = angle / 6.283185f;
    t = t - (i32)t;
    if (t < 0.0f)
        t += 1.0f;

    f32 pos = t * 16.0f;
    i32 idx = (i32)pos;
    f32 frac = pos - (f32)idx;

    f32 s0 = aTable[idx & 15];
    f32 s1 = aTable[(idx + 1) & 15];
    return s0 + (s1 - s0) * frac;
}

i32
main()
{
    setvbuf(stdout, NULL, _IONBF, 0);

    ScWindowConfig conf = {
        .pName = "Sc Render Sample",
        .NameLength = 17,
        .UseGraphics = 1, /* окно + растер (software renderer) */
        .Size = { .Width = 800, .Height = 600 },
        .MinSize = { .Width = 320, .Height = 240 },
        /* MaxSize: буферы растера аллоцируются сразу на него,
           resize окна дальше не делает реаллокаций */
        .MaxSize = { .Width = 1600, .Height = 1200 },
        /* {0,0} = центр экрана */
        .Position = { .X = 0, .Y = 0 },
    };

    ScWindow window = {};
    sc_window_create(&window, conf);
    if (!window.IsAlive)
    {
        printf("Window creation failed!\n");
        return 1;
    }

    ScRaster* pRaster = sc_window_get_raster(&window);
    if (!pRaster)
    {
        printf("No raster in window!\n");
        sc_window_destroy(&window);
        return 1;
    }

    printf("Rendering. ESC to exit.\n");

    i64 frame = 0;
    i64 fpsFrames = 0;
    i64 fpsStart = sc_date_time_now_seconds();

    while (window.IsAlive)
    {
        sc_window_update(&window);

        if (window.aKeys[ScKey_Escape] == ScAction_Press)
        {
            window.IsAlive = 0;
            break;
        }

        ScRasterBuffer buf = sc_raster_get_buffer(pRaster);
        i32 width = buf.Width;
        i32 height = buf.Height;

        /* фон: чёрный */
        sc_raster_clear_color(pRaster, 0xFF000000);

        /*
          DOCS: Разноцветные прямоугольники: сетка 4x3 заливок +
          вращающиеся контуры поверх. Цвета - заметные, разные.
        */
        static const u32 aColors[12] = {
            0xFF0000FF, /* красный   */
            0xFF00FF00, /* зелёный   */
            0xFFFF0000, /* синий     */
            0xFFFFFF00, /* жёлтый    */
            0xFFFF00FF, /* маджента  */
            0xFF00FFFF, /* циан      */
            0xFF7F7F7F, /* серый     */
            0xFF8B4513, /* коричневый*/
            0xFFFF8000, /* оранжевый */
            0xFF800080, /* фиолетовый*/
            0xFF008000, /* тёмно-зелёный */
            0xFFC0C0C0, /* серебряный */
        };

        i32 cols = 4;
        i32 rows = 3;
        i32 cellW = width / cols;
        i32 cellH = height / rows;
        i32 inset = 8;

        for (i32 row = 0; row < rows; ++row)
        {
            for (i32 col = 0; col < cols; ++col)
            {
                i32 index = row * cols + col;
                i32 x = col * cellW + inset;
                i32 y = (rows - 1 - row) * cellH + inset; /* снизу вверх: Y-вверх */
                sc_raster_fill_rect(pRaster, x, y, cellW - inset * 2, cellH - inset * 2, aColors[index]);
                sc_raster_draw_rect(pRaster, x, y, cellW - inset * 2, cellH - inset * 2, 0xFFFFFFFF);
            }
        }

        /*
          DOCS: Плавающий белый прямоугольник: круговая траектория
          вокруг центра, залитый + контур.
        */
        {
            f32 orbit = (f32)(frame % 512) * 0.01227f;
            f32 sinO = render_sample_sin(orbit);
            f32 cosO = render_sample_sin(orbit + 1.570796f);

            i32 orbitRadius = ScMin(width, height) / 4;
            i32 boxSize = 90;
            i32 bx = width / 2 + (i32)(cosO * orbitRadius) - boxSize / 2;
            i32 by = height / 2 + (i32)(sinO * orbitRadius) - boxSize / 2;

            sc_raster_fill_rect(pRaster, bx, by, boxSize, boxSize, 0xE6FFFFFF);
            sc_raster_draw_rect(pRaster, bx, by, boxSize, boxSize, 0xFF000000);
        }

        /* рамка по краю */
        sc_raster_draw_rect(pRaster, 0, 0, width, height, 0xFF303030);

        /* показать кадр */
        sc_window_graphics_swap_buffers(&window);

        /* FPS раз в секунду */
        ++frame;
        ++fpsFrames;
        i64 now = sc_date_time_now_seconds();
        if (now > fpsStart)
        {
            printf("fps: %lld, size: %dx%d\n", (long long)fpsFrames, width, height);
            fpsFrames = 0;
            fpsStart = now;
        }
    }

    sc_window_destroy(&window);
    printf("Bye!\n");
    return 0;
}
