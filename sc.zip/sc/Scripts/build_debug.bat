@echo off

cd /d "%~dp0../"

masuka -b debug -p windows
