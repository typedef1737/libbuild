#!/usr/bin/env bash
set -e

cd "$(cd "$(dirname "$0")" && pwd -P)/../"

masuka -b release -p linux
