#!/usr/bin/bash

set -e

cd "$(cd "$(dirname "$0")" && pwd -P)/../"

masuka -b debug -p linux
