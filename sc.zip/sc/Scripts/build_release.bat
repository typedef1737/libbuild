@echo off
cd /d "%~dp0../"

masuka -b release -p windows
