#!/bin/bash

#cd ..
/home/tdef/Ult/OS/Apps/debugger-nnd/nnd /home/tdef/Big/programming/C/evy/Dependencies/Sc/bin/debug-linux/ui
