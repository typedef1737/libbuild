# Web / WASM порт Sc

> Статус: проектный план. Код ещё не изменён.
>
> Основной сценарий — **браузер через Emscripten + SDL2**. WASI (headless)
> рассматривается как дополнительный вариант в конце документа.

## 1. Короткий ответ

WASM для Sc сделать можно, но это отдельный платформенный порт. Ключевые
отличия от desktop:

1. Нужна отдельная платформа `SC_PLATFORM_EMSCRIPTEN`: все ветки явно
   помечаются `#if defined(SC_PLATFORM_EMSCRIPTEN)`.
2. Нужен новый бэкенд окна `SC_WINDOW_EMSCRIPTEN` на SDL2.
3. Главная переделка — **не окно, а кадровый цикл**: браузер нельзя
   блокировать `while (...) { sc_sleep_ms(1); }`. Нужен
   `emscripten_set_main_loop`.
4. Нужны WASM-ветки для потоков, файлов, random, путей и логов.
5. В masuka нужен toolchain `emcc` / `emar`, target `wasm32`, выход
   `.html`/`.js`/`.wasm` и упаковка ассетов.

Для первого порта лучше начать с **single-thread** сборки. Потоки Emscripten
можно добавить позже: они требуют `SharedArrayBuffer` и COOP/COEP-заголовков
на сервере.

---

## 2. Архитектура браузерного приложения

```text
main()
  │
  ├─ ScAppConfig: OnStart / OnFrame / OnStop
  │
  └─ sc_app_run(&cfg)
        │
        ├─ desktop:       while (IsAlive) { update; frame; swap; sleep; }
        ├─ Android:       android_main + ALooper
        └─ Emscripten:    emscripten_set_main_loop_arg
                              │
                              ├─ sc_window_update()      // SDL events
                              ├─ OnFrame(window, dt)
                              └─ sc_window_graphics_swap_buffers()
                                    // SDL_UpdateTexture + RenderCopy + Present
```

На Emscripten `main()` не должен содержать бесконечный цикл. Он настраивает
окно и передаёт управление браузеру через `emscripten_set_main_loop_arg`.

---

## 3. Карта файлов

### 3.1. Существующие файлы, которые нужно изменить

| Файл | Что сделать |
|---|---|
| `Source/Sc/Types.h` | добавить `SC_PLATFORM_EMSCRIPTEN`; `force_inline`; `ScOs_Emscripten` |
| `Source/Sc/Types.c` | `sc_os_to_string`, `sc_system_info_get`, `sc_system_cpu_count`, убрать `#error` для Emscripten |
| `Source/Sc/Sc.c` | Emscripten-ветки: заголовки, `sc_thread`, `sc_mutex`, `sc_condition`, `sc_rwlock`, `sc_job`, `sc_file`, `sc_directory`, `sc_path`, `sc_random`, `sc_profiler`, `sc_sleep_ms` |
| `Source/Sc/Sc.h` | проверить платформенные `#ifdef` (например, profiler); при необходимости добавить Emscripten-ветку |
| `Source/Sc/Gfx/Window.h` | добавить `SC_WINDOW_EMSCRIPTEN` |
| `Source/Sc/Gfx/Window.c` | вынести общий API; вынести XCB/Win32 в отдельные файлы; для Emscripten оставить только диспетчеризацию |
| `Source/Sc/Gfx/Raster.h` | уточнить комментарий про формат пикселя и совместимость с `SDL_PIXELFORMAT_ARGB8888` |
| `Source/Sc/Sc.masuka` | добавить `emscripten:` блок; вынести `Gfx/Window*` в платформенные блоки |
| `vince.masuka` | добавить платформу `emscripten` |
| `masuka/Source/Masuka.h` | расширить `MskPlatform`, добавить `MskTargetFormat` |
| `masuka/Source/Masuka.c` | парсинг `emscripten:`, `emcc`/`emar`, target format, output, `-r`/`-t` |
| `Docs/Android.md` | не менять; при желании сослаться на общий `ScAppConfig` |

### 3.2. Новые файлы

| Файл | Назначение |
|---|---|
| `Source/Sc/Gfx/WindowXcb.c` | Linux/XCB-бэкенд (выделяется из `Window.c`) |
| `Source/Sc/Gfx/WindowWin32.c` | Windows/Win32-бэкенд (выделяется из `Window.c`) |
| `Source/Sc/Gfx/WindowAndroid.c` | Android-бэкенд (если делается вместе с Android-портом) |
| `Source/Sc/Gfx/WindowEmscripten.c` | SDL2-бэкенд для браузера |
| `Source/Sc/Platform/Emscripten/ScEmscriptenMain.c` | `sc_emscripten_run`, `emscripten_set_main_loop_arg`, lifecycle |
| `Source/Sc/Platform/Emscripten/ScEmscriptenFile.c` | при необходимости: preload/IDBFS/asset-хелперы |
| `Source/Sc/Platform/Emscripten/ScEmscriptenLog.c` | при необходимости: `emscripten_log` / `console.log` |
| `Source/Sc/App.h` | `ScAppConfig` и общий API запуска (если ещё не введён для Android) |
| `Source/Sc/App.c` | desktop-реализация `sc_app_run` |
| `Source/Samples/Web/Web.c` | пример браузерного приложения |
| `Source/Samples/Web/Web.masuka` | проект примера |
| `Source/Samples/Web/shell.html` | HTML-оболочка с canvas |
| `Source/Samples/Web/Assets/` | тестовые ассеты (шрифт, изображение) |

### 3.3. Файлы, которые не должны попадать в WASM-сборку

| Файл | Причина |
|---|---|
| `Source/Sc/Gfx/Window.c` | desktop-диспетчеризация; для WASM нужен `WindowEmscripten.c` |
| `Source/Sc/Gfx/WindowXcb.c` | XCB |
| `Source/Sc/Gfx/WindowWin32.c` | Win32 |
| `Source/Sc/Gfx/WindowAndroid.c` | Android |
| `Source/Sc/Gfx/Vk.c` | Vulkan/xcb |
| `Source/Sc/Gfx/Vulkan.c` | Vulkan SDK |
| `Source/Sc/Text/Font.c` (частично) | требует решения по assets; сам файл можно оставить, но путь к шрифту должен быть preloaded |

Для WASI окно не включается вообще: проект собирает только core + CLI.

### 3.4. Генерируемые артефакты (не коммитить)

```text
bin/debug-emscripten/app.html
bin/debug-emscripten/app.js
bin/debug-emscripten/app.wasm
bin/debug-emscripten/app.data
bin/obj/debug-emscripten/app/...
```

`masuka -c -p emscripten` должен удалять всю директорию выбранной
конфигурации.

---

## 4. Что нужно сделать в слое Sc

### 4.1. Платформенные макросы

Файлы: `Source/Sc/Types.h`, `Source/Sc/Types.c`.

Добавить:

- `SC_PLATFORM_EMSCRIPTEN`;
- `ScOs_Emscripten` и строку `"Emscripten"` в `sc_os_to_string`;
- ветку `ScOs_Emscripten` в `sc_system_info_get`;
- `force_inline`:
  ```c
  #elif defined(SC_PLATFORM_LINUX) || defined(SC_PLATFORM_ANDROID) \
      || defined(SC_PLATFORM_EMSCRIPTEN)
  #define force_inline static inline __attribute((always_inline))
  ```
- убрать `#error "Not platform defined!"` для Emscripten.

WASM32 — 32-битные указатели, little-endian. `i64`/`u64` остаются
64-битными. Текущие типы Sc подходят.

### 4.2. `Sc.c`: что сломается в Emscripten

| Место | Проблема | Решение |
|---|---|---|
| `#include <bits/pthreadtypes.h>` | glibc-only | не включать в Emscripten-ветке |
| `pwd.h`, `getpwuid`, `getuid` | нет нормального `$HOME` | задавать data-dir приложением |
| `sys/random.h`, `getrandom()` | может отсутствовать | `getentropy` / `arc4random_buf` / JS `crypto.getRandomValues` |
| `DT_WHT` | может отсутствовать | безопасный размер массива + `DT_UNKNOWN` через `stat` |
| `/tmp` | MEMFS есть, но нестабилен | настраиваемый temp-dir |
| `pthread_attr_setguardsize(stackSize)` | неверная семантика | `pthread_attr_setstacksize` |
| `printf` | уходит в консоль браузера | `emscripten_log` / `console.log` |
| `sc_sleep_ms` | блокирует main thread | не использовать в кадровом цикле |

Остальное — `dirent`, `clock_gettime`, `stat`, `mkdir`, `fopen` — в
Emscripten работает через MEMFS.

Нельзя просто определить `SC_PLATFORM_LINUX`: `Window.h` включит XCB, а
`Sc.c` потянет glibc-заголовки.

### 4.3. Потоки и job system

`sc_thread`, `sc_mutex`, `sc_condition`, `sc_rwlock` и `sc_job` — главная
проблема.

#### Вариант 1: single-thread (рекомендуется для первого порта)

- `sc_thread_create` возвращает `NULL`;
- мьютексы/condition/rwlock — no-op;
- `sc_job_init` не создаёт потоки;
- `sc_job_new` выполняет job сразу inline (у `sc_job` нет `wait`, так что
  семантика сохраняется);
- `sc_job_deinit` — no-op.

Это позволяет собрать и запустить Sc без `SharedArrayBuffer`.

#### Вариант 2: Emscripten pthreads

- компилировать с `-pthread -sPTHREAD_POOL_SIZE=N`;
- сервер должен отдавать:
  ```
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Embedder-Policy: require-corp
  ```
- иначе `SharedArrayBuffer` недоступен и потоки не заработают;
- `sc_sleep_ms` на main thread всё равно нельзя; нужен
  `emscripten_set_main_loop` или `-sPROXY_TO_PTHREAD`.

Для TinyLlm и job system потоки дадут ускорение, но порт можно начать без
них.

### 4.4. Время

- `clock_gettime` в Emscripten есть.
- `nanosleep` на main thread может блокировать/ругаться. Кадровый цикл —
  только через `emscripten_set_main_loop`.
- `sc_profiler` можно оставить на `clock_gettime`; при желании —
  `emscripten_get_now`.

### 4.5. Файлы, ассеты, сохранения

- `sc_file_read` / `sc_file_write` работают с MEMFS.
- Ассеты предзагружаются:
  ```bash
  emcc ... --preload-file Assets@/assets
  ```
  После этого `assets/font.ttf` читается как обычный файл.
- Большие файлы (чекпоинты TinyLlm) лучше не тащить в `.data`, а грузить
  через `emscripten_fetch`/`fetch` и отдавать в Sc как буфер. Для этого может
  понадобиться API загрузки чекпоинта из памяти.
- MEMFS не персистентен. Для сохранений нужен IDBFS:
  - монтировать `/persist`;
  - после записи вызывать `FS.syncfs`;
  - `FS.syncfs` асинхронный, а Sc-файлы синхронные — синхронизировать по
    таймеру/`beforeunload`.

### 4.6. Random и логи

- Emscripten: `getentropy`/`arc4random_buf` или `EM_JS` →
  `crypto.getRandomValues`.
- Логи: `emscripten_log` или `printf` (консоль браузера).
- `sc_break` (null deref) в WASM даёт trap; для отладки этого достаточно.

### 4.7. Что остаётся без изменений

- `Gfx/Raster` — чистый CPU-рендерер, работает в WASM.
- `Gfx/Ui`, `UiBackends/RasterBackend` — не завязаны на окно.
- `Image/*`, `Parsers/*`, `Sound/Qoa`, `Ecs`, `Math`, `Ai/TinyLlm` — C99,
  собираются под wasm32.
- `Text/TrueType` — чистый парсер; `Text/Font` требует preload ассетов.
- `Gfx/Vk`/`Vulkan` — вне сборки.

---

## 5. Модуль `Window` для Emscripten

В `Window.h`:

```c
#if defined(SC_PLATFORM_EMSCRIPTEN)
#define SC_WINDOW_EMSCRIPTEN
#endif
```

### 5.1. SDL2-бэкенд

Проще всего через SDL2:

- `-sUSE_SDL=2` даёт SDL2 headers/libs.
- `SDL_CreateWindow`, `SDL_CreateRenderer`.
- `SDL_CreateTexture` с `SDL_PIXELFORMAT_ARGB8888` и
  `SDL_TEXTUREACCESS_STREAMING`.
- `sc_window_graphics_swap_buffers`:
  ```c
  SDL_UpdateTexture(texture, NULL, rasterBuffer.pData, width * 4);
  SDL_RenderClear(renderer);
  SDL_RenderCopy(renderer, texture, NULL, NULL);
  SDL_RenderPresent(renderer);
  ```
- `SDL_PIXELFORMAT_ARGB8888` в little-endian — это ровно `0xAARRGGBB`,
  то есть формат `ScRaster`. Swap R/B не нужен, в отличие от Android.

### 5.2. События

- `SDL_KEYDOWN` / `SDL_KEYUP` → `ScKeyPressEvent` / `ScKeyReleaseEvent`.
- `SDL_TEXTINPUT` → `ScKeyTypeEvent`.
- `SDL_MOUSEMOTION` / `SDL_MOUSEBUTTONDOWN` / `SDL_MOUSEWHEEL` → мышь.
- `SDL_WINDOWEVENT_RESIZED` → `WindowResized`.
- `SDL_WINDOWEVENT_FOCUS_GAINED` / `LOST` → `WindowFocused`.
- `SDL_QUIT` / `beforeunload` → `WindowClosed`.

### 5.3. Set-функции

- `sc_window_set_title` → `SDL_SetWindowTitle`.
- `sc_window_set_fullscreen` → `SDL_SetWindowFullscreen` /
  `emscripten_request_fullscreen`.
- `sc_window_set_cursor_visibilite` → `SDL_ShowCursor`.
- `sc_window_set_grabed_ext` → `SDL_SetRelativeMouseMode`.
- `sc_window_set_position` / `set_above` — no-op.
- `sc_window_set_headless` — скрыть canvas или no-op.

### 5.4. Кадровый цикл

Это важнее самого бэкенда. Вместо:

```c
while (window.IsAlive)
{
    sc_window_update(&window);
    ...
    sc_sleep_ms(1);
}
```

нужен runtime:

```c
typedef struct
{
    void (*OnStart)(ScWindow*);
    void (*OnFrame)(ScWindow*, f32 dt);
    void (*OnStop)(ScWindow*);
} ScAppConfig;
```

- Desktop: `sc_app_run` — обычный `while`.
- Android: `sc_android_run` — `android_main` + `ALooper`.
- Emscripten: `sc_emscripten_run` — `emscripten_set_main_loop_arg`,
  `emscripten_cancel_main_loop` в `OnStop`.

Это тот же `ScAppConfig`, который предлагался для Android. Один runtime на
все платформы — меньше различий в примерах.

---

## 6. Стартап для Emscripten

Новый файл: `Source/Sc/Platform/Emscripten/ScEmscriptenMain.c`.

Обязанности:

- `sc_emscripten_run(const ScAppConfig* pConfig)`:
  - создать `ScWindow`;
  - вызвать `OnStart`;
  - поставить `emscripten_set_main_loop_arg`;
  - в колбэке вызвать `sc_window_update`, `OnFrame`,
    `sc_window_graphics_swap_buffers`;
  - по закрытию — `emscripten_cancel_main_loop`, `OnStop`,
    `sc_window_destroy`.
- Обработать `beforeunload` / `visibilitychange` для паузы.
- Настроить canvas:
  - размер;
  - `devicePixelRatio`;
  - фокус.

Пример пользовательского кода:

```c
static void
app_frame(ScWindow* pWindow, f32 dt)
{
    ScRaster* pRaster = sc_window_get_raster(pWindow);
    sc_raster_clear_color(pRaster, 0xFF202020);
    // ...
}

int
main(void)
{
    ScAppConfig cfg = {
        .pName = "Sc Web",
        .Size = { 640, 480 },
        .UseGraphics = 1,
        .OnFrame = app_frame,
    };

    return sc_app_run(&cfg);
}
```

На Emscripten `sc_app_run` вызывает `sc_emscripten_run` и возвращает 0, не
блокируя main thread.

---

## 7. Что нужно в masuka

Проблемы те же, что с Android, плюс свои:

| Место | Что не так |
|---|---|
| `msk_language_platform_block` | только `linux:` / `windows:`; нужен `emscripten:` |
| `MskPlatform` | нет compiler/archiver/target/sysroot/format/output |
| `msk_generator_compile_argv` | жёстко `-m64`, `clang` |
| `msk_generator_archive_argv` | жёстко `ar` / `llvm-ar.exe` |
| `msk_generator_target_path` | расширение зависит от script kind; нужен `.wasm` / `.html` |
| `msk_script_kind_from_platform` | `emscripten` должен оставаться host-скриптом `.sh` / `.bat` |
| `msk_generator_link_argv` | `-Wl,-rpath` не нужен; нужны `emcc`-флаги |
| `msk_runner_run_program` | нельзя запустить `.html` / `.wasm` как host-exe |
| `msk_generator_json_create` | `compile_commands.json` должен использовать `emcc` |

### 7.1. Минимальные изменения

1. Добавить в `MskPlatform`:
   ```c
   char* pCompiler;   // emcc
   char* pArchiver;   // emar
   char* pTarget;     // wasm32
   char* pSysroot;    // для WASI; для Emscripten пусто
   char* pFormat;     // "wasm"
   char* pOutput;     // "html" / "js" / "wasm"
   i32 IsPic;
   ```

2. Добавить `MskTargetFormat_Wasm` и развести его с `MskScriptKind`.
   - `-p emscripten` на Windows → `.bat`, но выход `.html` / `.wasm`;
   - `-p emscripten` на Linux → `.sh`, тот же выход.

3. `msk_generator_compile_argv`:
   - `pCompiler` вместо `clang`;
   - без `-m64`;
   - `-std=c99 -O2` / `-g -O0`;
   - при необходимости `-pthread`, `-msimd128`.

4. `msk_generator_archive_argv`:
   - `emar` вместо `ar`;
   - выход `lib<name>.a`.

5. `msk_generator_link_argv`:
   - `emcc objects... -o <bin>/<name>.html`;
   - без `-Wl,-rpath`;
   - флаги `-s...` из `links`.

6. Новые поля проекта:
   ```text
   emscripten: {
       links: [
           "-sUSE_SDL=2",
           "-sALLOW_MEMORY_GROWTH=1",
           "-sEXIT_RUNTIME=1"
       ]
       assets: [ "Assets@/assets" ]
       shell: "shell.html"
       output: "html"
   }
   ```
   `assets` → `--preload-file`, `shell` → `--shell-file`.

7. `-r`:
   - `emrun <bin>/<name>.html` или локальный HTTP-сервер;
   - для тестов — `node <bin>/<name>.js` при `-sENVIRONMENT=node`.

### 7.2. Целевой конфиг

`vince.masuka`:

```text
workspace sc_web
{
    let EMSDK: "C:/emsdk"

    entry: "app"

    builds: [
        { name: "debug"   preprocessor: "SC_BUILD_DEBUG"   optimize: 0 }
        { name: "release" preprocessor: "SC_BUILD_RELEASE" optimize: 1 }
    ]

    platforms: [
        {
            name: "emscripten"
            preprocessor: "SC_PLATFORM_EMSCRIPTEN"
            compiler: "{EMSDK}/upstream/emscripten/emcc.bat"
            archiver: "{EMSDK}/upstream/emscripten/emar.bat"
            target: "wasm32"
            format: "wasm"
            output: "html"
        }
    ]
}
```

`app.masuka`:

```text
project app
{
    type: "Executable"

    bin: "bin/{build}-{platform}"
    objdir: "bin/obj/{build}-{platform}/{project}"

    source: [
        "Main.c"
    ]

    dependencies: [ "Sc" ]

    include: [ "Source" ]

    emscripten: {
        links: [
            "-sUSE_SDL=2",
            "-sALLOW_MEMORY_GROWTH=1",
            "-sEXIT_RUNTIME=1"
        ]
        assets: [ "Assets@/assets" ]
        shell: "shell.html"
    }
}
```

`Sc.masuka`:

```text
emscripten: {
    source: [ "Gfx/WindowEmscripten.c" ]
    links: [ "-sUSE_SDL=2" ]
}
```

При этом `Gfx/Window.c` и desktop-бэкенды не должны попадать в
Emscripten-сборку.

---

## 8. Ручная сборка

### 8.1. Emscripten

```bash
# Компиляция Sc
emcc -std=c99 -O2 -c Source/Sc/Sc.c -o obj/Sc.o
# ... остальные .c, кроме desktop Window и Vulkan

emar rcs libSc.a obj/*.o

# Приложение
emcc -std=c99 -O2 \
    -I Source \
    -DSC_PLATFORM_EMSCRIPTEN=1 \
    app/Main.c \
    Gfx/WindowEmscripten.c \
    libSc.a \
    -sUSE_SDL=2 \
    -sALLOW_MEMORY_GROWTH=1 \
    -sEXIT_RUNTIME=1 \
    --preload-file Assets@/assets \
    -o bin/app.html

emrun bin/app.html
```

С потоками:

```bash
emcc ... -pthread -sPTHREAD_POOL_SIZE=8 ...
```

Сервер должен отдавать COOP/COEP:

```
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Embedder-Policy: require-corp
```

Иначе `SharedArrayBuffer` будет недоступен.

С SIMD:

```bash
emcc ... -msimd128 -O3 ...
```

Тесты в Node:

```bash
emcc ... -sENVIRONMENT=node -o bin/test.js
node bin/test.js
```

### 8.2. HTML-оболочка

`shell.html` должен содержать canvas:

```html
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Sc Web</title>
</head>
<body>
  <canvas id="canvas" oncontextmenu="event.preventDefault()"></canvas>
  {{{ SCRIPT }}}
</body>
</html>
```

SDL2 ищет canvas через `Module.canvas`; при необходимости его можно задать
явно.

---

## 9. Ограничения и риски

1. **Блокирующий цикл.**
   Главная переделка — переход на `emscripten_set_main_loop` / `ScAppConfig`.
   Иначе браузер зависнет.

2. **Потоки.**
   Emscripten pthreads требуют COOP/COEP и `SharedArrayBuffer`. Если хостинг
   не может отдать заголовки — только single-thread.

3. **Ассеты и сохранения.**
   MEMFS эфемерен; большие модели лучше грузить асинхронно, а не через
   `--preload-file`. IDBFS требует ручной синхронизации.

4. **Производительность software blit.**
   `SDL_UpdateTexture` + `SDL_RenderCopy` нормально для 2D/UI. Для тяжёлого
   рендера — WebGL/WebGPU-бэкенд.

5. **Память.**
   WASM32 ограничен 4 GB, часто меньше. TinyLlm с большими чекпоинтами и
   датасетами может не влезть; нужны стриминг/квантование.

6. **`compile_commands.json`.**
   `emcc` и его внутренние include-пути clangd понимает не всегда; может
   понадобиться `--query-driver` или отдельный конфиг.

7. **Запуск с `file://`.**
   Браузер не загрузит `.wasm`/`.data` с `file://`; нужен HTTP-сервер.

---

## 10. Порядок работ

| Этап | Что делаем | Результат |
|---|---|---|
| 0 | `SC_PLATFORM_EMSCRIPTEN`, сборка Sc через `emcc`, тесты в Node | Core работает в WASM |
| 1 | Single-thread fallback для `sc_thread`/`sc_job`/мьютексов | Sc не падает без pthreads |
| 2 | `WindowEmscripten.c` на SDL2 | Окно, ввод, raster blit |
| 3 | `ScAppConfig` + `emscripten_set_main_loop` | Кадровый цикл без блокировки |
| 4 | masuka: `emscripten:` платформа, `emcc`, output | `masuka -p emscripten` собирает `.html` |
| 5 | Assets (`--preload-file`), IDBFS, логи | Приложение с ресурсами и сохранениями |
| 6 | Потоки/SIMD/оптимизации | Ускорение TinyLlm и raster |

По срокам:

- core + Node-тесты — несколько дней;
- SDL2-окно + кадровый цикл — 1–2 недели;
- masuka toolchain — несколько дней;
- assets/IDBFS/полировка — 1–2 недели;
- pthreads/SIMD — отдельно, по необходимости.

Минимальный браузерный порт — порядка 3–5 недель.

---

## 11. Дополнительно: WASI (headless)

Если нужен не браузер, а `.wasm` для `wasmtime`/сервера:

- отдельная платформа `SC_PLATFORM_WASI`;
- компилятор `clang --target=wasm32-wasi --sysroot=...`;
- архивер `llvm-ar`;
- выход `bin/<name>.wasm`;
- окна нет, `Gfx/Window*` не включается;
- потоки — только экспериментальный `wasi-threads`, обычно single-thread;
- файлы — preopened dirs (`wasmtime run --dir . app.wasm`);
- запуск — `wasmtime run`, тесты — тоже `wasmtime`.

WASI удобен для CLI, тестов и серверных сценариев. Для визуального
приложения нужен именно Emscripten.

---

## 12. Чек-лист

- [ ] `SC_PLATFORM_EMSCRIPTEN` добавлен в `Types.h` / `Types.c` / `Sc.c`.
- [ ] Emscripten-ветки не используют glibc-only заголовки.
- [ ] Single-thread fallback для `sc_thread`/`sc_job`/мьютексов.
- [ ] `SC_WINDOW_EMSCRIPTEN` и `WindowEmscripten.c` реализованы.
- [ ] `ScAppConfig` + `emscripten_set_main_loop`, без блокирующего `while`.
- [ ] `Samples/Web` запускается в браузере.
- [ ] `Sc.masuka` умеет `emscripten:` блок.
- [ ] masuka знает `emcc`/`emar` и target format.
- [ ] `.a` и `.html`/`.wasm` собираются.
- [ ] Ассеты предзагружаются; шрифты находятся.
- [ ] Host-сборки Linux/Windows/Android не сломаны.
