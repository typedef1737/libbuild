# AVX2 CPU-бэкенд TinyLlm

## Что сделано

Добавлен отдельный CPU-бэкенд для `TinyLlm`:

| Файл | Назначение |
|:--|:--|
| `Source/Sc/TinyLlmSimd.h` | Публичный API бэкенда: определение поддержки CPU, выбор бэкенда, ядра, self-test |
| `Source/Sc/TinyLlmSimd.c` | Скалярные ядра (эталон/fallback) + AVX2+FMA ядра + runtime dispatch |
| `Source/Sc/TinyLlm.c` | Линейные слои, LayerNorm и attention-примитивы вызывают `sc_tiny_llm_simd_*` |
| `Source/Tests/ScTinyLlm.c` | Проверка `sc_tiny_llm_simd_self_test()` в общем наборе тестов |

Один и тот же бинарник работает и на CPU с AVX2, и без него: выбор
происходит во время выполнения, а не на этапе компиляции.

## Как выбирается бэкенд

`sc_tiny_llm_simd_init()` (лениво вызывается из публичного API `TinyLlm`)
проверяет:

1. `CPUID.0` — максимальный leaf ≥ 7;
2. `CPUID.1` — OSXSAVE, AVX и FMA;
3. `XGETBV(0)` — OS сохраняет YMM-регистры (`XCR0 & 0x6 == 0x6`);
4. `CPUID.7.0:EBX[5]` — AVX2.

Если всё выполнено, выбирается `avx2+fma`, иначе `scalar`. FMA требуется
потому, что AVX2-ядра используют `_mm256_fmadd_ps`; на CPU без FMA
остаётся скалярный путь.

AVX2-функции помечены `__attribute__((target("avx2,fma")))`, поэтому
глобальный `-mavx2` для всего проекта не нужен и не ломает запуск на
старых CPU.

## Что ускорено

- `linear_forward` — GEMV/матричное умножение;
- `linear_backward_weight` — накопление градиентов весов и bias;
- `linear_backward_input` — градиент по входу (dot-произведения);
- `ln_forward` / `ln_backward_add` — LayerNorm;
- `dot` и `axpy` — оценки attention и взвешенная сумма value-векторов.

Остаются скалярными: GELU (`tanhf`), AdamW и softmax. Это следующие
кандидаты на оптимизацию, но они не дают такого же вклада, как линейные
слои.

## Диагностика

```c
#include <Sc/TinyLlm.h>

printf("cpu: %s avx2=%d fma=%d\n",
    sc_tiny_llm_cpu_backend_name(),
    sc_tiny_llm_cpu_has_avx2(),
    sc_tiny_llm_cpu_has_fma());
```

`lm_train` и `lm_chat` печатают эту строку при старте:

```text
cpu: backend=avx2+fma avx2=1 fma=1
```

Принудительный выбор и self-test (полезно для отладки и бенчмарков):

```c
#include <Sc/TinyLlmSimd.h>

sc_tiny_llm_simd_force_backend(ScTinyLlmCpu_Scalar);
sc_tiny_llm_simd_force_backend(ScTinyLlmCpu_Avx2);
i32 ok = sc_tiny_llm_simd_self_test(1e-4f);
```

`sc_tiny_llm_simd_self_test()` сравнивает скалярные и AVX2-ядра на
детерминированных данных, включая хвосты размеров, не кратных 8.

## Проверка

На машине с AVX2:

```text
avx2=1 fma=1 backend=avx2+fma
self_test=1
```

Полный набор тестов `Source/Tests` проходит, включая `ScTinyLlm.c`.

Замеры на Xeon Gold 6326 (2 vCPU), корпус 22,7 КБ, BPE 500 merges:

| Модель | Шаги | Batch | Scalar | AVX2+FMA | Ускорение |
|:--|--:|--:|--:|--:|--:|
| medium | 12 | 4 | 3,716 с (309,7 мс/шаг) | 1,701 с (141,7 мс/шаг) | **2,18×** |
| medium | 1 000 | 4 | 310,78 с (310,8 мс/шаг) | 143,90 с (143,9 мс/шаг) | **2,16×** |
| micro | 10 000 | 8 | 1107,60 с (110,8 мс/шаг) | 569,42 с (56,9 мс/шаг) | **1,95×** |
| target | 100 | 2 | 175,98 с (1759,8 мс/шаг) | 73,24 с (732,4 мс/шаг) | **2,40×** |

Loss после обучения у scalar и AVX2 совпадает до 4 знаков (у micro
0,0292 против 0,0288 — обычная разница округления FMA).

## Сборка

Никаких дополнительных флагов не требуется: AVX2-код собирается
target-атрибутами. Если нужно включить AVX2 глобально для отдельного
проекта (например, для стороннего кода), в `masuka` добавлено поле
`flags:`:

```text
project app
{
    type: "Executable"
    bin: "bin/{build}-{platform}"
    objdir: "bin/obj/{build}-{platform}/{project}"
    source: [ "main.c" ]
    flags: [ "-mavx2", "-mfma" ]
}
```

`flags` поддерживается и в платформенных блоках:

```text
windows: {
    flags: [ "-mavx2", "-mfma" ]
}
```

Флаги попадают в команду компиляции перед `-c`, поэтому изменение
`flags` автоматически пересобирает проект (stamp-файл masuka).

## Ограничения

- AVX2-путь требует x86-64, clang или GCC. Для MSVC `cl.exe` остаётся
  скалярный путь (target-атрибуты там не поддерживаются).
- Нет многопоточности и BLAS; ускорение — только за счёт SIMD.
- `sc_tiny_llm_simd_force_backend()` меняет глобальное состояние процесса:
  это диагностический инструмент, а не настройка на каждый вызов.
