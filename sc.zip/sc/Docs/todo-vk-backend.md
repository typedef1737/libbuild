# TODO: Vulkan compute backend

Цель: headless Vulkan compute backend под Radeon 6800 XT для обучения TinyLlm.
Документ описывает только Vulkan-функционал, который нужно реализовать. ML-алгоритмы
и формулы сюда не входят.

## Текущее состояние

Сейчас `Source/Sc/Gfx/Vk.c` и `Source/Sc/Gfx/Vulkan.c` — заготовка graphics renderer’а,
а не compute-бэкенд.

### Прогресс

- [x] Windows Vulkan loader (`LoadLibraryA`/`GetProcAddress`).
- [x] Platform-guard для XCB.
- [x] Win32-surface через `VK_KHR_win32_surface`.
- [x] `Vk` не зависит от `Window.h`/`Window.c` и не вызывает `win32_sc_window_*`/`xcb_sc_window_*`.
- [ ] Отдельная сборка `ScVk`/`ScGpu`.
- [ ] Headless compute-путь без surface/swapchain.

Что уже есть:

- создание instance;
- перечисление physical device;
- создание logical device;
- выбор memory type;
- создание `VkBuffer`/`VkDeviceMemory`;
- создание shader module через `glslc`;
- descriptor set layout/pool/set;
- graphics pipeline;
- command pool/buffer;
- `vkQueueSubmit`, fences, binary semaphores;
- `vkCmdPipelineBarrier`;
- `vkCmdCopyBuffer`;
- debug messenger.

Что мешает использовать это как compute backend:

- `Vk.c` на Windows уже собирается, но graphics-инициализация всё ещё требует surface/swapchain;
- `Vk.c` XCB/include закрыт platform-guard'ом, Win32-surface реализован;
- `Vulkan.c` использует `dlfcn.h`, `dlopen`, `dlsym` только на Linux;
- `Vk/Vulkan` исключены из `Source/Sc/Sc.masuka`;
- инициализация всегда требует surface/swapchain/render pass;
- нет compute pipeline, compute queue и `vkCmdDispatch`;
- нет SSBO/bindless-дескрипторов;
- нет reusable command buffer’ов и нормальной синхронизации шага.

## 1. Платформа и загрузка Vulkan

- [x] Windows-загрузчик `vulkan-1.dll` через `LoadLibraryA`/`GetProcAddress`.
- [x] Platform-guard для XCB в `Vk.c`.
- [x] Убрать `#error "Implementation pending"` с Windows-пути.
- [ ] Отдельная сборка `ScVk`/`ScGpu`.
- [ ] Линковка `vulkan-1` на Windows — не требуется при `LoadLibraryA`, нужна только `vulkan-1.dll` в системе.
- [ ] Headless-режим без `VK_KHR_win32_surface`.
- [x] Win32-surface через `VK_KHR_win32_surface`.

Для обучения окно не нужно: нужен headless compute init без surface/swapchain.

## 2. Headless-инициализация

Сейчас `sc_vk_new` всегда создаёт surface, swapchain, sync для swapchain,
graphics command buffers, final render pass, final graphics pipeline и sampler.

Нужно:

- [ ] Флаг `Headless` в `ScVkConfig` или отдельный `sc_vk_compute_new`.
- [ ] Пропуск `sc_vk_surface`.
- [ ] Пропуск `sc_vk_swap_create`.
- [ ] Пропуск `sc_vk_sync_create`.
- [ ] Пропуск `sc_vk_cmd_create`.
- [ ] Пропуск `create_final_pass`.
- [ ] Пропуск `create_final_pipe`.
- [ ] Безопасный `sc_vk_destroy` с проверками на `VK_NULL_HANDLE`.
- [ ] Отдельный `ScVkCompute`-контекст без `ScVkRenderPass`/`ScVkSwapObject`.

## 3. Physical device и очередь

Сейчас выбор physical device требует `samplerAnisotropy`, `multiDrawIndirect`,
`tessellationShader`, проверяет surface support и выбирает graphics/presentation queue.

Нужно:

- [ ] Выбор устройства по compute-возможностям, а не по graphics-фичам.
- [ ] Проверка `VK_QUEUE_COMPUTE_BIT`.
- [ ] Отдельный `ComputeQueueIndex`.
- [ ] Отдельный `VkQueue ComputeQueue`.
- [ ] Отдельный command pool для compute.
- [ ] Проверка фич через `vkGetPhysicalDeviceFeatures2`.
- [ ] Включение `descriptorIndexing`.
- [ ] Включение `shaderStorageBufferArrayNonUniformIndexing`.
- [ ] Включение `descriptorBindingPartiallyBound`.
- [ ] Включение `descriptorBindingStorageBufferUpdateAfterBind`.
- [ ] Включение `runtimeDescriptorArray`.
- [ ] Включение `bufferDeviceAddress`.
- [ ] Включение `timelineSemaphore`.
- [ ] Опционально `shaderFloat16`/`shaderInt8`.
- [ ] Опционально `VK_EXT_memory_budget`.

## 4. Compute pipeline

Сейчас `ScVkStageType` знает только Vertex/Fragment/Tessellation.
`sc_vk_stage_type_to_native` для compute возвращает `0`, а `sc_vk_pipeline_new`
всегда создаёт `VkGraphicsPipelineCreateInfo`.

Нужно:

- [ ] `ScVkStageType_Compute`.
- [ ] `ScVkComputePipelineConfig`:
  - [ ] compute shader;
  - [ ] descriptor layout;
  - [ ] push constant ranges;
  - [ ] specialization constants.
- [ ] `sc_vk_compute_pipeline_new`.
- [ ] `vkCreateComputePipelines`.
- [ ] `VkPipelineLayout` без render pass.
- [ ] `VkPipelineBindPoint` = `VK_PIPELINE_BIND_POINT_COMPUTE`.
- [ ] Отдельная структура `ScVkComputePipeline`, не наследующая graphics-поля.

## 5. Дескрипторы

Сейчас `ScVkDescriptorType_Ssbo` объявлен, но `sc_vk_stage_new` обрабатывает
только `Uniform` и `Image`, а на `Ssbo` срабатывает `sc_assert(0)`.
`sc_vk_uniform_set` пишет только uniform buffer. Descriptor set layout flags = 0,
pool `maxSets = 1`. Нет descriptor arrays, bindless, dynamic offsets и push constants.

Нужно:

- [ ] Обработка `ScVkDescriptorType_Ssbo` в `sc_vk_stage_new`.
- [ ] `VkDescriptorBufferInfo` и `VkWriteDescriptorSet` для storage buffer.
- [ ] Дескриптор массива SSBO:
  - [ ] `descriptorCount = N`;
  - [ ] `VK_DESCRIPTOR_TYPE_STORAGE_BUFFER`;
  - [ ] offsets/ranges на каждый тензор.
- [ ] Bindless-режим:
  - [ ] `VkDescriptorSetLayoutBindingFlagsCreateInfo`;
  - [ ] `VK_DESCRIPTOR_BINDING_PARTIALLY_BOUND_BIT`;
  - [ ] `VK_DESCRIPTOR_BINDING_UPDATE_AFTER_BIND_BIT`;
  - [ ] `VK_DESCRIPTOR_BINDING_VARIABLE_DESCRIPTOR_COUNT_BIT`;
  - [ ] `VK_DESCRIPTOR_SET_LAYOUT_CREATE_UPDATE_AFTER_BIND_POOL_BIT`;
  - [ ] pool с `UPDATE_AFTER_BIND`;
  - [ ] `VkDescriptorSetVariableDescriptorCountAllocateInfo`.
- [ ] Push constants:
  - [ ] `VkPushConstantRange`;
  - [ ] `vkCmdPushConstants`;
  - [ ] ranges в `VkPipelineLayoutCreateInfo`.
- [ ] Dynamic offsets, если не хочется обновлять descriptor set на каждый тензор.

Для backend понадобится дескриптор массива storage buffer’ов, а не отдельный
descriptor set на каждый тензор. Это слой для весов, градиентов, Adam-состояний
и активаций.

## 6. Буферы и память

Сейчас `sc_vk_buffer_new` создаёт отдельный `VkDeviceMemory` на каждый буфер.
Нет арены/suballocation, `VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT`,
`VkDeviceAddress`, memory allocate flags для BDA. `ScVkBuffer` не хранит
size/usage/address. `sc_vk_shared_buffer_set_data` только upload через временный
command buffer и `vkQueueWaitIdle`. Чтения GPU→CPU нет.

Нужно:

- [ ] `ScVkStorageBuffer` с `Buffer`, `Memory`, `Size`, `Usage`, `Address`.
- [ ] Арена/аллокатор для множества тензоров в одном или нескольких больших буферах.
- [ ] Выравнивание offsets по `minStorageBufferOffsetAlignment`.
- [ ] Usage:
  - [ ] `VK_BUFFER_USAGE_STORAGE_BUFFER_BIT`;
  - [ ] `VK_BUFFER_USAGE_TRANSFER_SRC_BIT`;
  - [ ] `VK_BUFFER_USAGE_TRANSFER_DST_BIT`.
- [ ] Для bindless/BDA:
  - [ ] `VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT`;
  - [ ] `VkMemoryAllocateFlagsInfo`.
- [ ] Staging upload и readback:
  - [ ] `vkCmdCopyBuffer`;
  - [ ] fence/timeline wait;
  - [ ] `vkInvalidateMappedMemoryRanges`.
- [ ] `vkCmdFillBuffer` для зануления.
- [ ] `vkCmdUpdateBuffer` для маленьких обновлений.
- [ ] Query `VK_EXT_memory_budget` для 16 ГБ VRAM.
- [ ] Обработка `VK_ERROR_OUT_OF_DEVICE_MEMORY`.

## 7. Command buffer и dispatch

Сейчас `sc_vk_cmd_begin` каждый раз аллоцирует one-time command buffer,
`sc_vk_cmd_end` сразу делает `vkQueueSubmit` и `vkQueueWaitIdle`.
Используется только `GraphicsPool`/`GraphicsQueue`. Нет `vkCmdDispatch`,
`vkCmdDispatchIndirect`, `vkCmdPushConstants`, `vkCmdFillBuffer`/`vkCmdUpdateBuffer`.
Нет reusable command buffer’ов и ring для нескольких шагов в полёте.

Нужно:

- [ ] `vkCmdDispatch`.
- [ ] `vkCmdDispatchIndirect`.
- [ ] `vkCmdPushConstants`.
- [ ] Compute command pool.
- [ ] Persistent primary command buffer на шаг/frame-in-flight.
- [ ] `vkResetCommandBuffer`/`vkResetCommandPool` без переаллокации.
- [ ] `vkCmdBindPipeline(..., VK_PIPELINE_BIND_POINT_COMPUTE, ...)`.
- [ ] `vkCmdBindDescriptorSets(..., VK_PIPELINE_BIND_POINT_COMPUTE, ...)`.
- [ ] Barriers между dispatch:
  - [ ] `VkBufferMemoryBarrier`;
  - [ ] `VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT`;
  - [ ] `VK_ACCESS_SHADER_READ_BIT`/`VK_ACCESS_SHADER_WRITE_BIT`;
  - [ ] отдельный barrier для indirect buffer.
- [ ] Один submit на шаг, а не submit+wait на каждый dispatch.

В `Vk.c` сейчас вообще нет `vkCmdDispatch`, а `Vulkan.h` не объявляет
`PFN_vkCmdDispatch`. Это нужно добавить и загрузить через `vkGetDeviceProcAddr`.

## 8. Синхронизация

Сейчас есть только binary semaphores, fences и `vkQueueWaitIdle`.

Нужно:

- [ ] Fence на command buffer/шаг.
- [ ] Желательно timeline semaphore:
  - [ ] `VkSemaphoreTypeCreateInfo`;
  - [ ] `vkWaitSemaphores`;
  - [ ] `vkSignalSemaphore`;
  - [ ] `VkTimelineSemaphoreSubmitInfo`.
- [ ] Wait без полного `vkQueueWaitIdle`.
- [ ] Синхронизация host readback только там, где реально нужно.
- [ ] Несколько шагов в полёте, если позже понадобится overlap.

Для минимальной версии достаточно fence + один шаг за раз.

## 9. Чтение результатов и профилирование

Сейчас upload есть, download/readback отсутствует. Query pool/timestamps
отсутствуют в загрузчике. GPU-профилирования нет.

Нужно:

- [ ] Staging buffer для чтения loss/метрик/небольших тензоров.
- [ ] `vkCmdCopyBuffer` device→staging.
- [ ] Fence wait.
- [ ] `vkInvalidateMappedMemoryRanges`.
- [ ] Query pool:
  - [ ] `vkCreateQueryPool`;
  - [ ] `vkCmdResetQueryPool`;
  - [ ] `vkCmdWriteTimestamp`;
  - [ ] `vkGetQueryPoolResults`.

Без этого нельзя понять, упирается ли backend в GEMM, память или dispatch overhead.

## 10. Shader-компиляция

Сейчас `sc_vk_shader_new` вызывает внешний `glslc` через `system`, не проверяет
код возврата, не проверяет, что `.spv` создан, жёстко использует
`--target-env=vulkan1.3`, не различает compute/graphics и не имеет настройки
пути к `glslc`.

Нужно:

- [ ] Вызов `glslc` для `.comp`.
- [ ] Проверка ошибок компиляции.
- [ ] Корректный путь к `glslc` на Windows.
- [ ] `--target-env=vulkan1.2` или `vulkan1.3` в зависимости от драйвера 6800 XT.
- [ ] Опционально specialization constants для размеров workgroup/тайлов.
- [ ] Без reflection — вручную связать bindings с `VkDescriptorSetLayoutBinding`.

## 11. Код, который можно пока не делать

Для compute-бэкенда не нужны:

- swapchain;
- render pass;
- graphics pipeline;
- framebuffer;
- textures/samplers;
- vertex/index buffers;
- `vkCmdDraw`.

Их надо не дорабатывать, а отделить, чтобы headless compute не тянул
graphics-инициализацию.

## Минимальный порядок реализации

1. [ ] Windows loader + headless instance/device.
2. [ ] Compute queue + compute command pool.
3. [ ] Storage buffer + staging upload/readback.
4. [ ] Compute pipeline + descriptor set + push constants.
5. [ ] `vkCmdDispatch` + barriers + fence.
6. [ ] Bindless SSBO array + indirect dispatch.
7. [ ] Timeline semaphore + query pool.
8. [ ] Сборка отдельного `ScVk`/`ScGpu` и тест «пустой compute dispatch + roundtrip буфера».

Коротко: не хватает целого compute-слоя — headless-инициализации,
compute-очереди, compute pipeline, SSBO/bindless-дескрипторов, dispatch-команд,
буферных барьеров, reusable command buffer’ов и readback. Graphics-часть
переиспользовать можно, но её нельзя тащить в backend целиком.
