# LEARN_GUIDE — обучение TinyLlm на реальном корпусе

Практическое руководство: как собрать утилиты, подготовить данные, обучить
BPE и LM, запустить генерацию, замерить AVX2 и сколько итераций давать
моделям `micro` / `medium` / `target`.

Всё проверялось на Windows (clang + masuka). Команды для Linux приведены
отдельными блоками; они используют те же исходники и те же аргументы.

---

## 1. Что вообще есть

Пайплайн MS1 состоит из трёх утилит:

| Шаг | Утилита | Что делает |
|:--|:--|:--|
| 1 | `bpe_train` | строит BPE-словарь по директории с `*.txt` / `*.text` |
| 2 | `lm_train` | обучает decoder-only transformer на BPE + корпусе, пишет чекпоинт |
| 3 | `lm_chat` | интерактивная генерация по чекпоинту |

Плюс диагностическая утилита:

| Утилита | Что делает |
|:--|:--|
| `avx2_bench` | обучает две одинаковые модели (scalar и AVX2) и печатает время/ускорение |

`lm_train` встраивает BPE в чекпоинт, поэтому `lm_chat` нужен только
файл `*.ckpt`, без отдельного `.bpe`.

---

## 2. Сборка

### Windows

```powershell
cd A:\programming\dev\sc

masuka -b release -p windows -e bpe_train  -nr
masuka -b release -p windows -e lm_train   -nr
masuka -b release -p windows -e lm_chat    -nr
masuka -b release -p windows -e avx2_bench -nr
```

`-nr` означает «собрать, но не запускать». Без `-nr` masuka попытается
запустить выбранный проект.

Готовые бинарники:

```text
bin\release-windows\bpe_train.exe
bin\release-windows\lm_train.exe
bin\release-windows\lm_chat.exe
bin\release-windows\avx2_bench.exe
```

### Linux

```bash
cd /path/to/sc

masuka -b release -p linux -e bpe_train  -nr
masuka -b release -p linux -e lm_train   -nr
masuka -b release -p linux -e lm_chat    -nr
masuka -b release -p linux -e avx2_bench -nr
```

Готовые бинарники:

```text
bin/release-linux/bpe_train
bin/release-linux/lm_train
bin/release-linux/lm_chat
bin/release-linux/avx2_bench
```

### Если `Access is denied` на Windows

Старые объекты в `bin\obj\release-windows` могут принадлежать
`BUILTIN\Administrators`. Тогда:

- запустить masuka из консоли с правами администратора, либо
- удалить/переименовать `bin\obj\release-windows` и `bin\release-windows`
  с правами администратора, либо
- собрать в чистой копии workspace.

В этом workspace уже есть готовые AVX2-бинарники:

```text
bin\avx2-windows\lm_train.exe
bin\avx2-windows\lm_chat.exe
bin\avx2-windows\bpe_train.exe
bin\avx2-windows\avx2_bench.exe
```

Их можно использовать, пока основной `bin` не пересобран.

---

## 3. Данные

`bpe_train` и `lm_train` рекурсивно собирают все `*.txt` и `*.text` из
указанной директории. Формат — UTF-8, обычный текст.

### Что проверить перед 100 МБ

- UTF-8 без «битых» байтов;
- нет дубликатов книг;
- убраны шапки Викитеки, оглавления, списки редакций, «Поиск по книге»;
- решено, что делать со старой орфографией (`ѣ`, `і`, `ѳ`, `ѵ`);
- нет файлов, где лежит только оглавление;
- train/val не пересекаются по книгам (см. ограничение ниже).

### Размер корпуса

Windows:

```powershell
$corpus = "A:\data\literature"
Get-ChildItem $corpus -Recurse -File -Include *.txt,*.text |
    Measure-Object Length -Sum
```

Linux:

```bash
CORPUS=/data/literature
find "$CORPUS" -type f \( -name '*.txt' -o -name '*.text' \) | wc -l
du -sh "$CORPUS"
```

### Деление train/val и упаковка окон

Без флагов `lm_train` делит **каждую 10-ю строку** на валидацию. Для книг это
не идеально: соседние строки одной книги попадают и в train, и в val.

Флаг `--pack` решает обе проблемы сразу:

- строки склеиваются в непрерывный поток `<BOS>строка<EOS>` и режутся на
  окна ровно `ctx + 1` токен (шаг `ctx`), поэтому окно заполнено полностью;
- train/val делятся **по файлам-книгам**: каждая 10-я книга → val
  (если файлов меньше 10 — последняя);
- val-окна перемешиваются, чтобы 32 валидационных окна покрывали разные книги.

Подробный разбор и цифры — в `Docs/PERFECT_TRAIN_DATA_EXAMPLE.md`.
Для честного эксперимента на реальных книгах используйте `--pack`.

---

## 4. BPE-словарь

### Windows

```powershell
.\bin\release-windows\bpe_train.exe "A:\data\literature" `
    -o "A:\data\literature.bpe" `
    -m 8000
```

### Linux

```bash
./bin/release-linux/bpe_train /data/literature \
    -o /data/literature.bpe \
    -m 8000
```

Параметры:

| Флаг | Значение |
|:--|:--|
| `<corpus-dir>` | директория с текстами (рекурсивно) |
| `-o <path>` | выходной `.bpe` |
| `-m <count>` | число merges |

Ориентиры по `-m`:

| Корпус | merges |
|:--|--:|
| до 10 МБ | 2 000–4 000 |
| 10–100 МБ | 8 000–16 000 |
| больше 100 МБ | 16 000–32 000 |

Больше merges — меньше токенов на текст, но больше словарь и тяжелее
эмбеддинги. Для `micro` большой словарь часто вреден: почти все параметры
уйдут в эмбеддинги.

---

## 5. Обучение LM

### Windows, micro

```powershell
.\bin\release-windows\lm_train.exe "A:\data\literature" `
    --bpe "A:\data\literature.bpe" `
    --model micro `
    --steps 30000 `
    --batch 8 `
    --lr 0.003 `
    --patience 10 `
    --pack `
    -o "A:\data\micro.ckpt" `
    --val-log "A:\data\micro-val.csv"
```

### Linux, micro

```bash
./bin/release-linux/lm_train /data/literature \
    --bpe /data/literature.bpe \
    --model micro \
    --steps 30000 \
    --batch 8 \
    --lr 0.003 \
    --patience 10 \
    --pack \
    -o /data/micro.ckpt \
    --val-log /data/micro-val.csv
```

### Параметры `lm_train`

| Флаг | По умолчанию | Смысл |
|:--|--:|:--|
| `<corpus-dir>` | — | директория с `*.txt` / `*.text` |
| `--bpe <path>` | — | обязательный BPE от `bpe_train` |
| `--model <name>` | `micro` | `micro`, `medium`, `target` |
| `--steps <n>` | 1000 | число шагов обучения |
| `--batch <n>` | 4 | размер batch |
| `--lr <f>` | 0.003 | learning rate |
| `--patience <n>` | 10 | early stopping: сколько проверок val без улучшения |
| `--pack` | выкл. | упаковка окон `ctx+1` + деление train/val по книгам |
| `-o <path>` | `lm.ckpt` | чекпоинт |
| `--val-log <path>` | `lm_val.csv` | CSV `step,val_loss,val_ppl` |

`patience` считается в проверках val, а проверка идёт каждые 50 шагов.
То есть `--patience 10` — это примерно 500 шагов без улучшения.

`lm_train` печатает:

```text
cpu: backend=avx2+fma avx2=1 fma=1
model: micro layers=2 d_model=64 heads=2 d_ff=256 ctx=128 params=...
tiny-llm: step 50/30000 loss ... lr ... grad ...
tiny-llm: val step 50 loss ... ppl ...
```

Если `backend=scalar`, AVX2 не включился: CPU без AVX2/FMA или сборка без
поддержки. На x86-64 с clang/gcc AVX2 выбирается автоматически.

---

## 6. Сколько итераций давать

### micro: параметры и capacity

`micro` — это 2 слоя, `d_model=64`, 2 головы, `d_ff=256`, `ctx=128`.
Тело трансформера — примерно **100 тыс. параметров**. Остальное — эмбеддинги
и выходной слой:

| Словарь | Всего параметров | Тело трансформера |
|--:|--:|--:|
| 4k | ~0,62 млн | ~0,10 млн |
| 8k | ~1,14 млн | ~0,10 млн |
| 16k | ~2,17 млн | ~0,10 млн |

Поэтому «2 млн параметров» у micro — это в основном таблица эмбеддингов.
Учить язык может только ~100 тыс. параметров. Данные тут не главное
ограничение; главное — capacity.

### 100 МБ в токенах

100 МБ русского UTF-8 — это примерно 50 млн символов и **12–20 млн
токенов** в зависимости от BPE.

При `batch=8`, `ctx=128` micro обрабатывает 1024 токена за шаг, значит:

| Шаги | Токенов | Эпох на 100 МБ |
|--:|--:|--:|
| 5 000 | 5,1 млн | ~0,3 |
| 10 000 | 10,2 млн | ~0,6 |
| 20 000 | 20,5 млн | ~1,2 |
| 30 000 | 30,7 млн | ~1,8 |
| 50 000 | 51,2 млн | ~3 |
| 100 000 | 102,4 млн | ~6 |

### Сколько шагов для micro

| Цель | Шаги | Комментарий |
|:--|--:|:--|
| Проверка пайплайна | 5 000–10 000 | loss падает, val не взлетает, чекпоинт грузится |
| Рабочий максимум | 20 000–40 000 | короткие фразы, стиль, пунктуация |
| Верхняя граница | 50 000 | дальше обычно плато или переобучение |
| Эксперимент | 100 000 | возможно, но ждать долго и смысла мало |

Для micro на 100 МБ я бы давал **20–40 тыс. шагов**, максимум 50 тыс.
100 тыс. шагов тоже переживёт, но это уже почти наверняка плато.

### Время micro на AVX2

Замер: ~54 мс/шаг при `batch=8`, `ctx=128`.

| Шаги | AVX2 | Scalar |
|--:|--:|--:|
| 10 000 | ~9 мин | ~18 мин |
| 20 000 | ~18 мин | ~35 мин |
| 30 000 | ~27 мин | ~53 мин |
| 50 000 | ~45 мин | ~1,5 ч |
| 100 000 | ~1,5 ч | ~3 ч |

Scalar примерно в 2 раза медленнее. 100 000 шагов отдельно гонять не
обязательно: время растёт линейно, а соотношение scalar/AVX2 уже видно
на 10 000.

### Что реально ожидать

| Обучение | Ожидаемый результат |
|:--|:--|
| micro, 5–10 тыс. шагов | мусор, но loss падает — проверка данных и BPE |
| micro, 20–40 тыс. шагов | отдельные слова, пунктуация, короткие обрывки фраз, имитация стиля |
| micro, 50–100 тыс. шагов | чуть лучше фразы, но без связного абзаца; риск переобучения |
| medium, 30–60 тыс. шагов | короткие осмысленные предложения/фрагменты, иногда связные |
| target, 20–40 тыс. шагов | заметно лучше, но всё ещё не «нормальная языковая модель» |

На 100 МБ micro **что-то выдаст**, но это будет в основном «словесный
салат» с правильными русскими окончаниями и местами знакомыми фразами.
Контекст 128 токенов — это 2–3 предложения, дальше модель ничего не держит.

Если нужен хоть сколько-то осмысленный текст — начинайте с `medium`,
а не увеличивайте число шагов у `micro`.

---

## 7. medium и target: практические команды

### medium

Windows:

```powershell
.\bin\release-windows\lm_train.exe "A:\data\literature" `
    --bpe "A:\data\literature.bpe" `
    --model medium `
    --steps 30000 `
    --batch 4 `
    --lr 0.001 `
    --patience 10 `
    --pack `
    -o "A:\data\medium.ckpt" `
    --val-log "A:\data\medium-val.csv"
```

Linux:

```bash
./bin/release-linux/lm_train /data/literature \
    --bpe /data/literature.bpe \
    --model medium \
    --steps 30000 \
    --batch 4 \
    --lr 0.001 \
    --patience 10 \
    --pack \
    -o /data/medium.ckpt \
    --val-log /data/medium-val.csv
```

`medium` — 4 слоя, `d_model=128`, 4 головы, `d_ff=512`, `ctx=256`.
Это минимальный разумный вариант, если нужен текст, а не проверка
пайплайна. На 100 МБ ориентир — 30–60 тыс. шагов.

Время с `--pack` считается по токенам, а не по шагам: окно 256 токенов,
batch 4 — это 1024 токена за шаг. На AVX2 (Xeon Gold 6326, 2 vCPU)
`medium` при `ctx=256` и `batch=2` даёт ~0,44 с/шаг, то есть `batch=4` —
~0,9 с/шаг: **30 тыс. шагов ≈ 7–8 часов, 60 тыс. ≈ 15 часов**. Без `--pack`
шаги дешевле (~0,14–0,3 с), но каждый шаг видит ~39 токенов вместо 256.

### target

Windows:

```powershell
.\bin\release-windows\lm_train.exe "A:\data\literature" `
    --bpe "A:\data\literature.bpe" `
    --model target `
    --steps 10000 `
    --batch 2 `
    --lr 0.0005 `
    --patience 10 `
    -o "A:\data\target.ckpt" `
    --val-log "A:\data\target-val.csv"
```

Linux:

```bash
./bin/release-linux/lm_train /data/literature \
    --bpe /data/literature.bpe \
    --model target \
    --steps 10000 \
    --batch 2 \
    --lr 0.0005 \
    --patience 10 \
    -o /data/target.ckpt \
    --val-log /data/target-val.csv
```

`target` — 6 слоёв, `d_model=256`, 8 голов, `d_ff=1024`, `ctx=512`.
Это дорого: один шаг на AVX2 — порядка 1,4–1,5 с при `ctx=512`, `batch=2`.
10 тыс. шагов — это несколько часов; 20–40 тыс. — уже 8–16 часов.
Для первого реального прогона лучше `medium`.

---

## 8. Генерация: lm_chat

### Windows

```powershell
.\bin\release-windows\lm_chat.exe "A:\data\micro.ckpt" `
    --temp 0.8 `
    --topk 20 `
    --max 60
```

Интерактивно:

```text
> Нярвей положила сухого хворосту в костер
>  и достала грязные чашки, деревянные и медные...
```

Выход: `exit`, `quit`, Ctrl+C или Ctrl+Z + Enter.

Подать промпт из UTF-8 файла:

```powershell
Get-Content .\prompt.txt -Raw -Encoding utf8 |
    .\bin\release-windows\lm_chat.exe .\micro.ckpt --temp 0.8 --topk 20 --max 60
```

### Linux

```bash
./bin/release-linux/lm_chat /data/micro.ckpt --temp 0.8 --topk 20 --max 60
```

Из файла:

```bash
./bin/release-linux/lm_chat /data/micro.ckpt < prompts.txt
```

Параметры:

| Флаг | По умолчанию | Смысл |
|:--|--:|:--|
| `<model.ckpt>` | — | чекпоинт от `lm_train` |
| `--temp <f>` | 0.8 | temperature; `0` = greedy |
| `--topk <n>` | 20 | top-k фильтр |
| `--max <n>` | 64 | максимум токенов |
| `--seed <u>` | 1 | seed генерации |

Чем ниже `--temp`, тем стабильнее и скучнее; чем выше — тем больше
разнообразия и мусора. Для переобученной micro `--temp 0.5–0.8` обычно
лучше, чем 1.0.

### Windows и кириллица

`lm_chat` сам переводит консоль в UTF-8 (`SetConsoleCP(65001)`).
Если всё равно видите мусор:

```powershell
chcp 65001
```

И убедитесь, что файл промпта сохранён в UTF-8 без BOM.

---

## 9. AVX2: как проверить и замерить

AVX2-бэкенд включается автоматически, если CPU поддерживает AVX2 + FMA.
`lm_train` и `lm_chat` печатают:

```text
cpu: backend=avx2+fma avx2=1 fma=1
```

Если `backend=scalar` — AVX2 не выбран. На x86-64 с clang/gcc проверьте,
что сборка свежая и в `Source/Sc/Sc.masuka` есть `TinyLlmSimd.c`.

### avx2_bench

Windows:

```powershell
.\bin\release-windows\avx2_bench.exe `
    "A:\data\sample.txt" `
    micro 10000 8 128 500
```

Linux:

```bash
./bin/release-linux/avx2_bench \
    /data/sample.txt \
    micro 10000 8 128 500
```

Аргументы:

```text
avx2_bench <corpus.txt> <micro|medium|target> <steps> <batch> [ctx] [merges]
```

Утилита строит BPE один раз, затем обучает две модели с одинаковым seed:
сначала scalar, потом AVX2. Печатает время, мс/шаг, ускорение и loss
до/после.

Пример вывода:

```text
scalar    ok=1 params=206973 ctx=128 steps=10000 batch=8 time=1107.60s ms/step=110.76 loss=6.7209->0.0292
avx2+fma  ok=1 params=206973 ctx=128 steps=10000 batch=8 time=569.42s  ms/step=56.94  loss=6.7209->0.0288
speedup: 1.95x
```

Короткие замеры на Xeon Gold 6326 (2 vCPU), корпус 22,7 КБ:

| Модель | Шаги | Batch | Scalar | AVX2 | Ускорение |
|:--|--:|--:|--:|--:|--:|
| micro | 10 | 8 | 105,7 мс/шаг | 54,1 мс/шаг | **1,95×** |
| medium | 20 | 4 | 307,8 мс/шаг | 139,8 мс/шаг | **2,20×** |
| target | 100 | 2 | 1759,8 мс/шаг | 732,4 мс/шаг | **2,40×** |

Длинные прогоны (тот же корпус, `merges=500`):

| Модель | Шаги | Batch | Scalar | AVX2 | Ускорение | Loss |
|:--|--:|--:|--:|--:|--:|:--|
| micro | 10 000 | 8 | 1107,60 с | 569,42 с | **1,95×** | 6,7209 → 0,029 |
| medium | 1 000 | 4 | 310,78 с | 143,90 с | **2,16×** | 6,8103 → 0,2797 |
| target | 100 | 2 | 175,98 с | 73,24 с | **2,40×** | 6,8907 → 5,8810 |

Loss после обучения у scalar и AVX2 совпадает до 4 знаков (у micro
разница 0,0292 против 0,0288 — это обычная разница округления FMA).
То есть AVX2 не меняет численный результат, только ускоряет.

### `flags:` в masuka

AVX2-бэкенду Sc глобальный `-mavx2` не нужен: AVX2-функции помечены
`target("avx2,fma")` и выбираются во время выполнения. Но для стороннего
кода в masuka можно задать сырые флаги:

```text
project app
{
    type: "Executable"
    bin: "bin/{build}-{platform}"
    objdir: "bin/obj/{build}-{platform}/{project}"
    source: [ "main.c" ]

    flags: [ "-mavx2", "-mfma" ]
}
```

`flags` поддерживается и в платформенных блоках:

```text
windows: {
    flags: [ "-mavx2", "-mfma" ]
}
```

---

## 10. Что смотреть во время обучения

Главный ориентир — **val loss**, а не train loss.

- train loss падает, val loss падает — всё хорошо;
- train loss < 1, val loss растёт — переобучение или утечка train/val;
- train и val стоят на месте — мало шагов, маленький lr или модель упёрлась
  в capacity;
- val loss скачет — слишком большой lr или маленький batch;
- PPL = `exp(val_loss)`. Например, loss 4,8 → PPL ≈ 121; loss 0,1 → PPL ≈ 1,1.

Для `micro` на 100 МБ train loss < 1 достигается легко и ничего не
доказывает. Смотрите на val loss и на то, что модель генерирует.

CSV валидации:

```text
step,val_loss,val_ppl
50,6.7539,857.39
...
```

Если val loss перестал падать, обучение можно останавливать: `lm_train`
сам сделает early stop по `--patience` и восстановит лучшие веса.

---

## 11. Типичные ошибки

### `cannot load BPE`

Неверный путь к `.bpe` или файл не от `bpe_train`. Проверьте, что путь
существует и начинается с корректного заголовка `# bpe v1`.

### `not enough data: train=... val=...`

Слишком маленький корпус или все строки попали в val. Нужно минимум
несколько примеров в train и хотя бы один в val.

### `error: no corpus data`

Директория пустая или в ней нет `*.txt` / `*.text`. Проверьте расширения
и рекурсивный обход.

### Мусор в генерации

- модель переобучена или недоучена;
- слишком высокая `--temp`;
- BPE обучался на грязном корпусе;
- для micro это нормальное поведение: capacity слишком мала.

### `Access is denied` при сборке

Старые `.o`/`.lib` принадлежат администратору. См. раздел 2.

### Кириллица в Windows-консоли

`chcp 65001`, UTF-8 файлы, `lm_chat` сам ставит кодовую страницу 65001.
При пайпе из PowerShell используйте `Get-Content -Raw -Encoding utf8`.

---

## 12. Краткий чек-лист

1. Собрать `bpe_train`, `lm_train`, `lm_chat` (и `avx2_bench`).
2. Почистить корпус, проверить UTF-8 и дубликаты.
3. Обучить BPE: 8k–16k merges для 100 МБ.
4. Прогнать `micro` 5–10 тыс. шагов — проверить пайплайн.
5. Для текста — `medium` 30–60 тыс. шагов, `ctx=256`, `batch=4`.
6. Смотреть val loss и PPL, а не train loss.
7. Сгенерировать `lm_chat` с `--temp 0.5–0.8`, `--topk 20`.
8. Для скорости — AVX2 (включается сам), проверить `cpu: backend=avx2+fma`.
9. Для замеров — `avx2_bench`.
10. `target` — только если готовы к 8–16 часам и чистому корпусу.
