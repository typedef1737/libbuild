# Android / NativeSDK порт Sc

> Статус: проектный план. Код ещё не изменён.
>
> Допущение: под **NativeSDK** понимается Android NDK + `NativeActivity` /
> `native_app_glue` — нативное приложение без Java/Kotlin-прослойки.
> Если нужен другой SDK или Java-оболочка, часть решений изменится.

## 1. Короткий ответ

Да, к слою Sc можно прикрутить Android. Архитектурно Sc к этому готов:

- ядро Sc — C99 + POSIX-подобные вызовы, которые есть в Bionic;
- `Gfx/Raster` — программный CPU-рендерер, ему всё равно, куда блитить кадр;
- `Gfx/Window` — тонкий платформенный слой, к XCB и Win32 добавляется третий
  бэкенд Android.

Но это отдельный платформенный порт, а не пара `#ifdef`. Нужны:

1. Отдельная платформа `SC_PLATFORM_ANDROID`: все Android-ветки явно
   помечаются `#if defined(SC_PLATFORM_ANDROID)` /
   `#elif defined(SC_PLATFORM_ANDROID)`.
2. Android-бэкенд `Window` на `ANativeWindow` + обработка lifecycle и input.
3. Специальный стартап `android_main` через `native_app_glue`.
4. В masuka — описание Android-toolchain, разделение host-скрипта и target
   формата, стадия упаковки APK.
5. Работа с assets, путями приложения, логами и подписью APK.

APK при этом можно собирать без Gradle: это zip с манифестом, `.so` и
подписью. Но для реального приложения с Java/Kotlin, IME, permissions и т.п.
Gradle всё равно будет проще.

---

## 2. Архитектура Android-приложения

```text
android_main(struct android_app*)
    │
    ├─ native_app_glue: ALooper, lifecycle, input
    │
    ├─ ScAndroidRuntime
    │      ├─ app->onAppCmd      -> INIT_WINDOW / TERM_WINDOW / FOCUS / DESTROY
    │      └─ app->onInputEvent  -> AKeyEvent / AMotionEvent
    │
    ├─ ScWindow (SC_WINDOW_ANDROID)
    │      ├─ ANativeWindow
    │      ├─ software blit ScRaster -> ANativeWindow_lock/unlockAndPost
    │      └─ очередь событий ScEvent
    │
    └─ пользовательский кадр: OnFrame(window, dt)
```

На Android окно не создаётся приложением: `NativeActivity` уже владеет
surface. Sc-бэкенд должен **привязываться** к готовому `ANativeWindow` и
переживать его потерю/пересоздание.

---

## 3. Что нужно сделать в слое Sc

В этом репозитории слой лежит в `Source/Sc`. В потребителе это обычно
`Dependencies/Sc/Source/Sc`.

### 3.1. Платформенные макросы и системная информация

Файлы:

- `Source/Sc/Types.h`
- `Source/Sc/Types.c`

Что добавить:

- `SC_PLATFORM_ANDROID` рядом с `SC_PLATFORM_LINUX` и
  `SC_PLATFORM_WINDOWS`.
- В `force_inline` для Android — тот же вариант, что у Linux:

  ```c
  #elif defined(SC_PLATFORM_LINUX) || defined(SC_PLATFORM_ANDROID)
  #define force_inline static inline __attribute((always_inline))
  ```

- `ScOs_Android` в `ScOs` и строку `"Android"` в `sc_os_to_string`.
- В `sc_system_info_get()` — ветку `ScOs_Android`.
- Убрать `#error "Not platform defined!"` для Android.
- `sc_system_cpu_count()` — Android-ветка с
  `sysconf(_SC_NPROCESSORS_ONLN)`.

Android — отдельная платформа. В местах, где Linux и Android ведут себя
одинаково, можно вынести общую реализацию в обычную статическую функцию без
платформенного макроса, но ветвление всё равно должно быть явным:

```c
#if defined(SC_PLATFORM_LINUX)
    ...
#elif defined(SC_PLATFORM_WINDOWS)
    ...
#elif defined(SC_PLATFORM_ANDROID)
    ...
#endif
```

### 3.2. `Sc.c`: что сломается на Bionic

Файл: `Source/Sc/Sc.c`.

| Место | Проблема | Что делать |
|---|---|---|
| `#include <bits/pthreadtypes.h>` | glibc-специфичный заголовок, в Bionic отсутствует | убрать из Android-ветки; `pthread.h` достаточно |
| `#include "pwd.h"`, `getpwuid`, `getuid` | на Android нет нормального `$HOME` | не использовать для домашнего каталога; подставлять `internalDataPath` приложения |
| `#include <sys/random.h>`, `getrandom()` | `getrandom` появился в API 28 | либо minSdk 28+, либо fallback на `/dev/urandom` |
| `i8 isEnabled[DT_WHT]` | `DT_WHT` может отсутствовать в Bionic | заменить на безопасный размер и обрабатывать `DT_UNKNOWN` через `stat` |
| `sc_path_get_random_temp_ext`: `"/tmp"` | на Android `/tmp` нет и он не writable | использовать кэш-каталог приложения |
| `sc_path_get_home_directory_wo_alloc` | `HOME` / `getpwuid` на Android не работают | возвращать каталог данных приложения, установленный стартапом |
| `printf` / `stdout` | stdout приложения не гарантированно попадает в logcat | Android-ветка `sc_log` через `__android_log_print` |
| `pthread_attr_setguardsize(stackSize)` | это размер guard, а не стека; на Bionic ведёт себя иначе | заменить на `pthread_attr_setstacksize` |

Остальное — `dirent`, `pthread`, `pthread_rwlock`, `clock_gettime`,
`nanosleep`, `stat`, `mkdir` — в Android есть.

Нельзя просто определить `SC_PLATFORM_LINUX` и собрать под Android:
`Window.h` сразу включит XCB, а `Sc.c` потянет glibc-заголовки и
Linux-специфичные пути.

### 3.3. Модуль `Window`

Файлы:

- `Source/Sc/Gfx/Window.h`
- `Source/Sc/Gfx/Window.c`

Сейчас в `Window.h`:

```c
#if defined(SC_PLATFORM_LINUX)
#define SC_WINDOW_XCB
#elif defined(SC_PLATFORM_WINDOWS)
#define SC_WINDOW_WIN32
#endif
```

Добавить:

```c
#elif defined(SC_PLATFORM_ANDROID)
#define SC_WINDOW_ANDROID
#endif
```

#### Вариант A (рекомендуется): разделить `Window.c` на generic + бэкенды

Сейчас `Window.c` — это общий API (`sc_window_create/update/...`) плюс оба
бэкенда в одном файле. Лучше разнести:

```text
Gfx/Window.c          — только общий API и диспетчеризация
Gfx/WindowXcb.c       — Linux/XCB
Gfx/WindowWin32.c     — Windows/Win32
Gfx/WindowAndroid.c   — Android/ANativeWindow
```

Тогда `Sc.masuka` сможет выбирать исходник по платформе:

```text
linux:   { source: [ "Gfx/WindowXcb.c" ] ... }
windows: { source: [ "Gfx/WindowWin32.c" ] ... }
android: { source: [ "Gfx/WindowAndroid.c" ] ... }
```

Android-код не будет видеть `xcb` и `windows.h`.

#### Вариант B: оставить один файл и добавить `#elif defined(SC_WINDOW_ANDROID)`

Быстрее для спайка, но файл станет ещё больше и будет включать Android-
заголовки в общий TU. Для долгой поддержки хуже.

#### Что должен делать Android-бэкенд

- `sc_window_create` на Android не создаёт surface, а только инициализирует
  состояние и запоминает `android_app*`.
- Нужен API привязки:

  ```c
  void sc_window_attach_native(ScWindow* pWindow, void* pNativeApp);
  ```

  или поле в `ScWindowConfig`:

  ```c
  void* pNativeApp; // struct android_app*
  ```

  В публичном заголовке лучше `void*`, чтобы не тащить Android-типы во все
  платформы.

- По `APP_CMD_INIT_WINDOW`:
  - сохранить `ANativeWindow*`;
  - выставить формат `WINDOW_FORMAT_RGBA_8888`;
  - взять ширину/высоту;
  - инициализировать `ScRaster`;
  - отправить `ScEventType_WindowResized`.
- По `APP_CMD_TERM_WINDOW` — освободить raster/graphics, обнулить surface.
- `sc_window_update` — разбирать очередь событий, которую наполнил
  input-колбэк.
- `sc_window_graphics_swap_buffers`:
  - `ANativeWindow_lock`;
  - построчно скопировать буфер растра в `ANativeWindow_Buffer.bits` с учётом
    `stride`;
  - `ANativeWindow_unlockAndPost`.

#### Формат пикселя

`ScRaster` хранит пиксели как `0xAARRGGBB`, то есть в little-endian память
идёт `B,G,R,A`. Android `WINDOW_FORMAT_RGBA_8888` ожидает `R,G,B,A`.
Значит, при блите нужен swap R/B, либо формат растра должен стать
настраиваемым. Для первого варианта достаточно swap в цикле копирования.

#### События

- Кнопка Back: мапить на `ScKey_Escape` или отдельное событие
  `WindowClosed`.
- Touch: первый палец — `ScMouseKey_Left`, move/down/up; multi-touch можно
  расширить позже.
- Клавиатура: `AKeyEvent_getKeyCode` → `ScKey`;
  `AKeyEvent_getUnicodeChar` → `ScEventType_KeyType` (только hardware
  keyboard).
- `ScWindowConfig.Size/Position` на Android игнорируются либо Size
  используется как request; surface всё равно решает.
- `sc_window_set_title/above/cursor_position` — no-op или частичная
  реализация.
- `sc_window_set_fullscreen` — через `ANativeActivity_setWindowFlags`.

### 3.4. Специальный стартап для Android

На Android нет обычного `main()`. Точка входа — `android_main(struct
android_app*)`, которую вызывает `android_native_app_glue`.

Добавить, например:

```text
Source/Sc/Platform/Android/ScAndroidMain.c
```

или

```text
Source/Sc/Gfx/WindowAndroidApp.c
```

Обязанности стартапа:

- реализовать `android_main`;
- повесить `app->onAppCmd` и `app->onInputEvent`;
- крутить `ALooper_pollOnce` (или `ALooper_pollAll`);
- обрабатывать lifecycle:
  - `APP_CMD_INIT_WINDOW`
  - `APP_CMD_TERM_WINDOW`
  - `APP_CMD_GAINED_FOCUS`
  - `APP_CMD_LOST_FOCUS`
  - `APP_CMD_WINDOW_RESIZED`
  - `APP_CMD_DESTROY`
- вызывать `sc_window_create`, `sc_window_update`,
  `sc_window_graphics_swap_buffers`;
- прокидывать пути приложения:
  - `android_app->activity->internalDataPath`
  - `android_app->activity->externalDataPath`
  - `android_app->activity->assetManager`
- отдавать пользователю кадровый колбэк.

Хороший API, чтобы приложение оставалось кроссплатформенным:

```c
typedef struct
{
    const char* pName;
    v2 Size;
    i32 UseGraphics;

    void (*OnStart)(ScWindow* pWindow);
    void (*OnFrame)(ScWindow* pWindow, f32 DeltaTime);
    void (*OnStop)(ScWindow* pWindow);
} ScAppConfig;

// Desktop: пользователь пишет main() и вызывает sc_app_run(&cfg);
// Android: Sc предоставляет android_main, который вызывает
//          sc_android_run(app, &cfg).
```

Тогда пользовательский код одинаковый, а платформенная разница спрятана.

Альтернатива: Sc определяет `android_main` и вызывает пользовательскую
`const ScAppConfig* sc_app_config(void)`. Но тогда нужно аккуратно с
линковкой статической библиотеки.

#### Линковка NativeActivity

- Добавить `android_native_app_glue.c` в сборку приложения (или в Sc, но
  лучше в приложение).
- Передать `-Wl,-u,ANativeActivity_onCreate` (или `-u
  ANativeActivity_onCreate`), иначе линкер может выбросить entry-символ из
  статической библиотеки.
- Линковать `-landroid -llog`.
- В манифесте указать `android.app.lib_name`.

`native_app_glue` в NDK обычно лежит в
`$NDK/sources/android/native_app_glue/`. В masuka сейчас нет нормальной
поддержки абсолютных `source`, поэтому glue лучше вендорить в репозиторий
(два небольших файла), а не ссылаться на NDK.

### 3.5. Assets, логи, рабочий каталог

#### Assets

Android-ассеты лежат внутри APK, а не в файловой системе. `sc_file_read
("assets/font.ttf")` не сработает. Нужно:

- либо читать через `AAssetManager`:

  ```c
  AAssetManager* pAssetManager = android_app->activity->assetManager;
  AAsset_openFileDescriptor / AAsset_getBuffer / AAsset_getLength
  ```

- либо при старте распаковывать нужные assets в `internalDataPath` и дальше
  работать с обычными файлами.

Сейчас `Text/Font.c` читает шрифт через `sc_file_read(pPath)`, так что для
шрифтов это придётся решить в первую очередь.

#### Логи

`printf` в Android-приложении не гарантирует вывод в logcat. Для отладки
нужен `__android_log_print(ANDROID_LOG_INFO, "Sc", ...)`. Лучше добавить
Android-ветку в `sc_log`, а не искать логи по всему коду.

#### Рабочий каталог

У Android-приложения CWD обычно `/`, а не каталог приложения. Все
относительные пути (`assets/`, `model.ckpt`, `font.ttf`) надо либо делать
абсолютными от `internalDataPath`, либо явно менять CWD при старте.

### 3.6. Ограничения NativeActivity

Если приложение — не только рендер, а UI с текстовыми полями, чистый
`NativeActivity` быстро упрётся в:

- soft keyboard / IME;
- clipboard;
- permissions UI;
- нормальный text input.

В этом случае лучше `GameActivity` (AndroidX) или своя Java/Kotlin Activity
+ JNI. Тогда APK уже требует `classes.dex`, и упаковка становится ближе к
Gradle. Это ключевое архитектурное решение, его лучше принять до начала
работ.

### 3.7. Что остаётся без изменений

- `Gfx/Raster` — остаётся программным рендерером.
- `Gfx/Ui` и `UiBackends/RasterBackend` — не завязаны на окно.
- `Image/*`, `Parsers/*`, `Sound/Qoa`, `Ecs`, `Math`, `Ai/TinyLlm` — чистый
  C99, собираются под NDK без платформенных правок, если не используют
  `sc_file_*` с путями вне sandbox.
- `Text/TrueType` — чистый парсер; `Text/Font` требует решения по assets.

---

## 4. Что нужно сделать в masuka

Сейчас masuka — компилятор C-проектов, а не Android-упаковщик. В README
прямо написано:

- поддерживаются только Linux x86_64 и Windows x86_64;
- `-m64` захардкожен;
- компилятор захардкожен (`clang` / `clang.exe`);
- `-p` выбирает «вкус скрипта», а не toolchain;
- кросс-компиляции нет;
- кастомных команд / install / package-таргетов нет;
- платформенные блоки распознаются только как `linux:` и `windows:`.

Этого недостаточно для APK.

### 4.1. Блокеры в текущем коде

| Файл / место | Что не так |
|---|---|
| `Source/Masuka.c`, `msk_language_platform_block` | распознаются только `linux:` / `windows:`; нужен `android:` |
| `MskPlatform` в `Masuka.h` | только `pName` и `pPreprocessor`; нет compiler/archiver/target/sysroot/format/pic/abi |
| `msk_generator_compile_argv` | жёстко `-m64`, `clang`, `clang.exe`; не знает target/sysroot |
| `msk_generator_archive_argv` | жёстко `ar` / `llvm-ar.exe`; не умеет NDK `llvm-ar` |
| `msk_generator_target_path` | расширение зависит от **script kind**, а не от target. На Windows `-p android` даст `.dll` / `.lib` вместо `.so` / `.a` |
| `msk_generator_link_argv` | добавляет `-Wl,-rpath,$ORIGIN` для всех non-batch; для Android это не нужно |
| `msk_generator_compile_argv` | `-fPIC` даётся только `DynamicLib`; `StaticLib` для Android тоже должен быть PIC |
| `msk_script_kind_from_platform` | Android на Windows должен генерировать `.bat`, а не `.sh` |
| `msk_runner_run_program` | `-r` запускает host-exe; для Android нужен `adb install` + `am start` |
| `msk_project_sources_resolve` | абсолютные `source` и `..` не поддерживаются; NDK glue придётся вендорить |
| `msk_generator_json_create` | в `compile_commands.json` должны попасть target/sysroot, иначе clangd не поймёт Android-код |

### 4.2. Минимальный набор изменений

#### 4.2.1. Расширить описание платформы

Добавить в `MskPlatform`:

```c
typedef struct
{
    char* pName;
    char* pPreprocessor;

    char* pCompiler;   // путь к NDK clang wrapper
    char* pArchiver;   // путь к llvm-ar
    char* pTarget;     // aarch64-linux-android24
    char* pSysroot;    // .../sysroot
    char* pFormat;     // "elf" / "pe"
    i32 IsPic;
    char* pAbi;        // arm64-v8a
    i32 ApiLevel;
} MskPlatform;
```

Парсер `vince.masuka` должен читать эти поля и прогонять через уже
существующую подстановку `{NDK}`, `{SDK}` и т.п.

#### 4.2.2. Добавить `android:` блок

В `msk_language_platform_block` и в разбор проектов добавить распознавание
`android:`. Внутри блока нужны как минимум:

- `source`
- `include`
- `links`
- `preprocessors`
- `dependencies`

Плюс, если делаем встроенную упаковку:

- `manifest`
- `package`
- `min-sdk`
- `target-sdk`
- `abi`
- `lib-name`
- `android-jar`
- `keystore` / `key-alias` / пароли

#### 4.2.3. Разделить script kind и target format

Это критично. Сейчас `msk_generator_target_path` смотрит на
`MskScriptKind`:

```c
if (isBatch) ... ".dll" ... ".lib"
else         ... ".so"  ... ".a"
```

Нужно ввести отдельно:

```c
typedef enum
{
    MskTargetFormat_Elf, // Linux/Android
    MskTargetFormat_Pe,  // Windows
} MskTargetFormat;
```

`target format` берётся из платформы, `script kind` — из хоста. Тогда:

- `-p android` на Windows генерирует `.bat`, но артефакты — `.a` и `.so`;
- `-p android` на Linux генерирует `.sh`, те же `.a` и `.so`.

#### 4.2.4. Научить compile / archive / link знанию платформы

`msk_generator_compile_argv` должен получать выбранную `MskPlatform` (или
поля, скопированные в `MskProject`):

- использовать `pCompiler` вместо `clang` / `clang.exe`;
- не добавлять `-m64`;
- добавлять `--target` / `--sysroot`, если не используется wrapper;
- добавлять `-fPIC` для всех объектных файлов Android, включая
  `StaticLib`;
- добавлять `-D__ANDROID_API__` только если не задаёт wrapper.

`msk_generator_archive_argv`:

- использовать `pArchiver`;
- для Android выдавать `.a`, а не `.lib`.

`msk_generator_link_argv`:

- для Android добавлять `-shared` (уже есть для `DynamicLib`);
- `-Wl,-soname,lib<name>.so`;
- `-Wl,-u,ANativeActivity_onCreate` для NativeActivity;
- `-Wl,-z,max-page-size=16384` для 16 KB page size (NDK r27; r28 умеет по
  умолчанию);
- не добавлять `-Wl,-rpath,$ORIGIN`;
- линковать `-landroid`, `-llog`, при необходимости `-lEGL -lGLESv3`.

#### 4.2.5. Добавить упаковку APK

##### Путь A — быстрый и прагматичный: masuka собирает `.so`, APK собирает Gradle/скрипт

Masuka делает только `libmain.so`. Дальше:

- либо маленький Gradle-проект с `jniLibs.srcDirs` /
  `externalNativeBuild`;
- либо скрипт `package_android.sh/.bat`, который вызывает `aapt2`, `zip`,
  `zipalign`, `apksigner`.

Плюсы:

- не надо превращать masuka в Android-упаковщик;
- Gradle бесплатно даёт resources, manifest merge, signing, 16 KB
  alignment, multi-ABI;
- быстрее получить первый APK.

Минусы:

- появляется зависимость от Gradle/JDK;
- две системы сборки.

Для первого рабочего прототипа — рекомендуемый путь.

##### Путь B — встроенный тип `AndroidApp`

Добавить в masuka новый тип проекта:

```text
type: "AndroidApp"
```

Он внутри ведёт себя как `DynamicLib` (собирает `lib<name>.so`), но после
линковки генерирует команды упаковки:

1. `aapt2 link` — манифест, ресурсы, `resources.arsc`.
2. Добавление `lib/<abi>/lib<name>.so` в APK.
3. `zipalign -p 4` (и `-P 16` при необходимости).
4. `apksigner sign`.

Если в приложении есть Java/Kotlin:

5. `javac` + `d8` → `classes.dex`.

Плюсы:

- одна система сборки, в духе masuka;
- полный контроль.

Минусы:

- это существенная фича: новые поля конфига, обработка путей, keystore,
  ABI, ресурсов, подписи, 16 KB;
- легко уйти в переписывание куска AGP.

Вывод: **Путь A — для старта, Путь B — долгосрочная цель**, если хочется
«masuka умеет APK» без Gradle.

### 4.3. Целевой вид конфигурации

`vince.masuka`:

```text
workspace sc_android
{
    let NDK: "C:/Android/Sdk/ndk/28.0.13004108"
    let SDK: "C:/Android/Sdk"

    entry: "main"

    builds: [
        { name: "debug"   preprocessor: "SC_BUILD_DEBUG"   optimize: 0 }
        { name: "release" preprocessor: "SC_BUILD_RELEASE" optimize: 1 }
    ]

    platforms: [
        { name: "windows" preprocessor: "SC_PLATFORM_WINDOWS" }

        {
            name: "android"
            preprocessor: "SC_PLATFORM_ANDROID"
            compiler: "{NDK}/toolchains/llvm/prebuilt/windows-x86_64/bin/aarch64-linux-android24-clang.cmd"
            archiver: "{NDK}/toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-ar.exe"
            target: "aarch64-linux-android24"
            sysroot: "{NDK}/toolchains/llvm/prebuilt/windows-x86_64/sysroot"
            format: "elf"
            pic: 1
        }
    ]
}
```

`main.masuka`:

```text
project main
{
    type: "AndroidApp"

    bin: "bin/{build}-{platform}"
    objdir: "bin/obj/{build}-{platform}/{project}"

    source: [
        "Main.c",
        "third_party/native_app_glue/android_native_app_glue.c"
    ]

    dependencies: [ "Sc" ]

    include: [
        "Source",
        "third_party/native_app_glue"
    ]

    android: {
        links: [ "android", "log", "m", "dl" ]

        manifest: "AndroidManifest.xml"
        package: "com.example.scdemo"
        min-sdk: 24
        target-sdk: 35
        abi: "arm64-v8a"
        lib-name: "main"
    }
}
```

`Sc.masuka` получает Android-блок:

```text
android: {
    links: [ "m", "dl", "android", "log" ]
}
```

а `Gfx/Window*.c` выбирается по платформе.

### 4.4. Definition of Done для masuka

- `masuka -b debug -p android` собирает `libSc.a` и `libmain.so`.
- `masuka -b debug -p android -gb` генерирует корректный `.bat`/`.sh`.
- `compile_commands.json` содержит Android target/sysroot.
- `masuka -b debug -p windows` и `-p linux` работают как раньше.
- `-c -p android` чистит только Android-артефакты.
- `-r -p android` либо ставит APK через `adb` и запускает, либо явно
  сообщает, что запуск не поддержан.

---

## 5. Как создаётся APK

APK — это zip-архив. Внутри:

```text
AndroidManifest.xml      (бинарный XML)
resources.arsc           (таблица ресурсов)
res/...                  (ресурсы, если есть)
lib/arm64-v8a/libmain.so (нативные библиотеки)
assets/...               (ассеты)
classes.dex              (если есть Java/Kotlin)
META-INF/...             (v1-подпись)
APK Signing Block        (v2/v3-подпись)
```

Инструменты:

| Шаг | Инструмент |
|---|---|
| Компиляция ресурсов | `aapt2 compile` |
| Линковка манифеста/ресурсов | `aapt2 link` |
| Java/Kotlin → dex | `javac` / `kotlinc` + `d8` |
| Выравнивание | `zipalign` |
| Подпись | `apksigner` |
| Установка | `adb install` |

Для чистого NativeActivity без Java `classes.dex` не нужен, если в
манифесте стоит `android:hasCode="false"`.

### 5.1. Минимальный манифест

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
          package="com.example.scdemo">

    <uses-sdk android:minSdkVersion="24"
              android:targetSdkVersion="35" />

    <application
        android:label="Sc Demo"
        android:hasCode="false"
        android:extractNativeLibs="false">

        <activity
            android:name="android.app.NativeActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|screenSize">

            <meta-data
                android:name="android.app.lib_name"
                android:value="main" />

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
```

`android.app.lib_name = main` означает, что система загрузит `libmain.so`
из APK и вызовет `ANativeActivity_onCreate`.

### 5.2. Ручная сборка APK

Пример для Linux (на Windows те же команды, но NDK clang — `.cmd`,
а пути `windows-x86_64`):

```bash
NDK=/path/to/ndk
SDK=/path/to/sdk
BT=$SDK/build-tools/35.0.0

CC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android24-clang
AR=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-ar

# 1) Собрать libSc.a с -fPIC
#    (все нужные .c из Source/Sc, кроме Vk/Vulkan)
$AR rcs libSc.a obj/*.o

# 2) Собрать libmain.so
$CC -std=c99 -O2 -fPIC -shared \
    -DSC_PLATFORM_ANDROID=1 -ISource \
    app/Android.c \
    third_party/native_app_glue/android_native_app_glue.c \
    -L. -lSc \
    -landroid -llog -lm -ldl \
    -Wl,-soname,libmain.so \
    -Wl,-u,ANativeActivity_onCreate \
    -Wl,-z,max-page-size=16384 \
    -o stage/lib/arm64-v8a/libmain.so

# 3) Собрать APK
$BT/aapt2 link \
    -o stage/base.apk \
    -I $SDK/platforms/android-35/android.jar \
    --manifest app/AndroidManifest.xml \
    --min-sdk-version 24 \
    --target-sdk-version 35

# 4) Добавить .so в APK.
#    -0 = без сжатия, чтобы extractNativeLibs=false и page alignment работали.
(cd stage && zip -0 -r base.apk lib)

# 5) Выровнять
$BT/zipalign -p 4 stage/base.apk stage/aligned.apk
# Если нужна поддержка 16 KB:
# $BT/zipalign -P 16 -f -v 4 stage/base.apk stage/aligned.apk

# 6) Подписать debug-ключом
$BT/apksigner sign \
    --ks debug.keystore \
    --ks-pass pass:android \
    --key-pass pass:android \
    --out app-debug.apk \
    stage/aligned.apk

# 7) Установить и запустить
adb install -r app-debug.apk
adb shell am start -n com.example.scdemo/android.app.NativeActivity
```

Если `debug.keystore` ещё нет:

```bash
keytool -genkeypair -v \
    -keystore debug.keystore \
    -storepass android -keypass android \
    -alias androiddebugkey \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US"
```

Проверить подпись:

```bash
apksigner verify --verbose app-debug.apk
```

Логи:

```bash
adb logcat -s Sc:V AndroidRuntime:E DEBUG:V
```

### 5.3. Что важно не забыть в APK

- `libmain.so` должен лежать именно в `lib/<abi>/`, иначе система его не
  найдёт.
- Имя `.so` должно совпадать с `android.app.lib_name`.
- `android:exported="true"` обязателен для launcher-activity на API 31+.
- `extractNativeLibs="false"` требует, чтобы `.so` был без сжатия и
  выровнен; иначе оставить `true`.
- Для Google Play с 2025+ нужна поддержка 16 KB page size: линковать с
  `-Wl,-z,max-page-size=16384` и выравнивать APK соответствующим
  `zipalign`.
- Для эмулятора нужен `x86_64`, для устройств — `arm64-v8a`. Можно делать
  universal APK с двумя `lib/<abi>/`.
- Debug-подпись нельзя использовать для публикации.
- `targetSdk` в 2026-м лучше держать 35/36, `minSdk` — 24 или выше (зависит
  от нужных API).

---

## 6. Предлагаемый порядок работ

| Этап | Что делаем | Результат |
|---|---|---|
| 0. Spike | `SC_PLATFORM_ANDROID`, сборка Sc через NDK, минимальный `android_main` + `ANativeWindow` clear, ручной APK | Доказательство, что цепочка работает |
| 1. Platform plumbing | `Types.h` / `Types.c` / `Sc.c`: Android-ветки, Bionic-фиксы, пути, random, logcat | Sc собирается и базово работает на устройстве |
| 2. Window backend | `WindowAndroid.c`: surface lifecycle, raster blit, input, resize, focus, back | Окно и события работают |
| 3. Startup | `ScAndroidMain.c` + `ScAppConfig`, sample `Samples/Android` | Приложение запускается без `main()` |
| 4. Masuka toolchain | platform fields, `android:` block, target format, `-fPIC`, no `-m64`, host script kind | `masuka -p android` собирает `.a` / `.so` |
| 5. Packaging | либо Gradle/скрипт, либо `AndroidApp` + aapt2/zipalign/apksigner | `masuka` (или скрипт) отдаёт `.apk` |
| 6. Polish | assets/fonts, logcat, pause/resume, multi-ABI, CI на эмуляторе | Пригодно для реальной разработки |

По срокам грубо:

- spike — несколько дней;
- полноценный Window-бэкенд — 1–2 недели;
- masuka toolchain — несколько дней;
- упаковка — от недели (скрипт) до 2+ недель (встроенный `AndroidApp`).

Суммарно без Gradle и с нуля — порядка 4–8 недель на одного человека, в
зависимости от требований к UI/IME.

---

## 7. Главные риски и решения

1. **NativeActivity vs GameActivity vs Java-прослойка.**
   Если нужен нормальный ввод текста, IME, clipboard, permissions UI —
   чистый NativeActivity не подойдёт. Тогда Java/Kotlin Activity + JNI или
   GameActivity, а значит APK с `classes.dex` и, скорее всего, Gradle.

2. **Производительность software blit.**
   `ANativeWindow_lock/unlockAndPost` на каждый кадр — простой, но не самый
   быстрый путь. Для демо и UI сойдёт; для 60 FPS рендера лучше EGL/GLES-
   бэкенд, а `Raster` оставить для оффскрина.

3. **Ассеты и шрифты.**
   `sc_file_read` не читает APK-assets. Нужен либо `AAssetManager`, либо
   распаковка при первом запуске. Иначе `Font.c` и любые ресурсы просто не
   найдутся.

4. **Пути и права.**
   Android-приложение не имеет `$HOME` и `/tmp`; все временные файлы — в
   `cacheDir`, данные — в `internalDataPath`. Это надо централизованно
   поправить в `Sc.c`, иначе Sc-модули будут падать в разных местах.

5. **Линковка.**
   Static-библиотеки для Android должны быть PIC. `-u
   ANativeActivity_onCreate` обязателен. NDK glue надо вендорить или
   научить masuka абсолютным source-путям.

6. **ABI / API / 16 KB.**
   Сначала arm64 + minSdk 24, потом x86_64 для эмулятора. Не забыть 16 KB
   alignment для современных требований.

---

## 8. Итоговый чек-лист

- [ ] `SC_PLATFORM_ANDROID` добавлен в `Types.h` / `Types.c` / `Sc.c`.
- [ ] Android-ветки в `Sc.c` не используют glibc-only заголовки.
- [ ] `SC_WINDOW_ANDROID` и `WindowAndroid.c` реализованы.
- [ ] `android_main` + `native_app_glue` + `ScAppConfig`.
- [ ] `Samples/Android` запускается на устройстве/эмуляторе.
- [ ] `Sc.masuka` умеет `android:` блок.
- [ ] masuka знает Android toolchain и target format.
- [ ] `.so` собирается с `-fPIC` и правильным SONAME.
- [ ] APK собирается, подписывается и устанавливается.
- [ ] Assets/шрифты/логи/пути работают в sandbox.
- [ ] Host-сборки Linux/Windows не сломаны.
