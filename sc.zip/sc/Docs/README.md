# Документация AI/BPE и микро-LLM

Эта папка описывает экспериментальный AI-модуль проекта Sc: byte-level BPE,
подготовку условных примеров, decoder-only transformer, обучение, генерацию,
чекпоинты и демонстрационный проект `small-llm-try`.

Документация рассчитана на разработчика, который хочет понять, что уже
реализовано, как это работает и какие данные нужны для обучения.

## Состав документации

| Файл | Содержание |
|---|---|
| [Bpe.md](Bpe.md) | Токенизатор: словарь, спецтокены, reference- и fast-тренер, формат `.bpe`, производительность. |
| [Architecture.md](Architecture.md) | Устройство transformer, forward/backward, loss, оптимизатор, генерация, чекпоинты, API. |
| [TrainingData.md](TrainingData.md) | Формат обучающих данных, объём, качество, разбиение, подготовка корпуса и оценка качества. |
| [Scaling.md](Scaling.md) | Анализ узких мест, план увеличения параметров и контекста, гибкая настройка размеров. |
| [ContextRequirements.md](ContextRequirements.md) | Что требуется для контекста 512, 1K, 2K и 512K: память, скорость, зависимости от этапов плана. |

## Кратко о реализации

- **BPE**: 256 байт + 9 спецтокенов + merges. Production-тренер
  `sc_ai_bpe_new_fast` использует хеш-таблицу частот, позиционные списки и
  max-heap. Старый `sc_ai_bpe_new` оставлен как reference-реализация.
- **Модель**: decoder-only transformer на `float32`, без BLAS, OpenMP,
  pthread и внешних ML-библиотек.
- **Задача**: по описанию персонажа и ситуации сгенерировать реплику после
  `<SEP>`.
- **Loss**: cross-entropy с маскированием prompt-части
  (`ScTinyLlmLossMask_Prompt`).
- **Обучение**: AdamW, warmup + cosine, клиппинг градиента, early stopping с
  восстановлением лучших весов (`RestoreBest`).
- **Генерация**: KV-cache, greedy / top-k / top-p / temperature.
- **Чекпоинт**: конфиг модели + веса + встроенная копия BPE.
- **Демо**: `small-llm-try` — 16 синтетических примеров, микро-модель,
  сохранение/загрузка BPE и чекпоинта.

## Быстрый старт

Сборка и запуск демо из корня репозитория:

```bash
masuka -b release -p windows -e lm_prelude_try -nr
bin\release-windows\lm_prelude_try.exe
```

Linux:

```bash
masuka -b release -p linux -e lm_prelude_try -nr
./bin/release-linux/lm_prelude_try
```

`lm_prelude_try` — демо **MS1 (LM-прелюдия)**: обучение языку на
корпусе без полей разметки (`LossMask_None`), генерация чистого
продолжения текста, чекпоинт — вход для MS2. Поддерживает реальный
корпус из `argv[1]` (UTF-8, одна фраза на строку).

Демо условной генерации (прототип MS2 на старом формате полей):

```bash
masuka -b release -p windows -e small_llm_try -nr
bin\release-windows\small_llm_try.exe
```

Подробности — в `Examples/lm-prelude-try/README.md` и
`Examples/small-llm-try/README.md`.

CLI-пайплайн MS1 для реальных прогонов (три утилиты):

```bash
masuka -b release -p windows -e bpe_train -nr
masuka -b release -p windows -e lm_train -nr
masuka -b release -p windows -e lm_chat -nr
bin\release-windows\bpe_train.exe <corpus-dir> -o corpus.bpe -m 4000
bin\release-windows\lm_train.exe <corpus-dir> --bpe corpus.bpe -o lm.ckpt
bin\release-windows\lm_chat.exe lm.ckpt
```

На Linux (или из git-bash) — скрипты «сборка + запуск» с пробросом
аргументов: `Examples/bpe-train/run_bpe_train.sh`,
`Examples/lm-train/run_lm_train.sh`, `Examples/lm-chat/run_lm_chat.sh`.

Подробности — в `Examples/bpe-train/README.md`,
`Examples/lm-train/README.md` и `Examples/lm-chat/README.md`.

## Карта кода

| Путь | Что находится |
|---|---|
| `Source/Sc/Ai.h` | Публичные типы BPE, спецтокены, legacy MLP, объявления API. |
| `Source/Sc/Ai.c` | BPE-тренеры, tokenize/decode, save/load `.bpe`, legacy MLP. |
| `Source/Sc/TinyLlm.h` | Публичный API микро-LLM, конфиги, датасет, чекпоинты. |
| `Source/Sc/TinyLlm.c` | Transformer, forward/backward, обучение, генерация, чекпоинты. |
| `Source/Tests/ScTinyLlm.c` | Тесты BPE round-trip, repeated-byte case, grad check, обучения и чекпоинта. |
| `Examples/lm-prelude-try/main.c` | Демо MS1: LM-прелюдия (LossMask_None), продолжение текста, вход MS2. |
| `Examples/bpe-train/main.c` | CLI-шаг 1: BPE-словарь по директории текстовых файлов. |
| `Examples/lm-train/main.c` | CLI-шаг 2: обучение LM-прелюдии по BPE + корпусу, чекпоинт. |
| `Examples/lm-chat/main.c` | CLI-шаг 3: интерактивная генерация `> промпт` → `> продолжение` по чекпоинту. |
| `Examples/small-llm-try/main.c` | Демо условной генерации: BPE → dataset → train → generate → reload. |
| `Examples/lm-prelude-try/README.md` | Инструкция по демо MS1 и формату корпуса. |
| `Examples/bpe-train/README.md` | Параметры bpe_train (merges, память, подвыборка). |
| `Examples/lm-train/README.md` | Параметры lm_train (пресеты, шаги, логи). |
| `Examples/lm-chat/README.md` | Параметры lm_chat (temp/topk, UTF-8 консоль Windows). |
| `Examples/small-llm-try/README.md` | Инструкция по демо условной генерации. |

## Ключевые ограничения

- BPE-кодирование `sc_ai_bpe_tokenize` применяет merges последовательно и
  имеет худшую сложность `O(merges * tokens)`. Быстрый тренер ускоряет
  обучение BPE, но не сам encode.
- Модель маленькая и учебная; на 16 примерах она переобучается.
- Нет dropout, mixed precision, beam search и repetition penalty.
- Запись чекпоинта не атомарная: при прерывании файл может быть повреждён.
- Полноценная оценка на реальном held-out корпусе в репозитории пока не
  добавлена.

## Статус по критериям ТЗ

| Критерий | Статус |
|---|---|
| 50 МБ / 10 000 merges ≤ 30 мин | Выполняется на синтетическом 50 МБ: около 17 с в release на CPU. |
| Валидационная PPL ≤ 30 | Зависит от данных и модели; на 16 синтетических примерах не показательна. |
| ≥ 50% стилистически корректных ответов | Нужен реальный held-out набор и ручная/автоматическая оценка. |
| 100 токенов ≤ 5 с на CPU | Достижимо для микро-модели; нужен замер на целевом железе. |

## Связанные файлы

- `Examples/small-llm-try/README.md` — практический запуск демо.
- `Examples/lm-prelude-try/README.md` — запуск демо MS1 и формат корпуса.
- `Examples/bpe-train/README.md`, `Examples/lm-train/README.md`,
  `Examples/lm-chat/README.md` — CLI-пайплайн MS1 (bpe → train → chat).
- `Source/Tests/ScTinyLlm.c` — пример использования API.
- `Source/Sc/TinyLlm.h` — точные сигнатуры и поля конфигов.
