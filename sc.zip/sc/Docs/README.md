# Документация AI/BPE и микро-LLM

Эта папка описывает экспериментальный AI-модуль проекта Sc: byte-level BPE,
подготовку условных примеров, decoder-only transformer, обучение, генерацию,
чекпоинты и демонстрационный проект `small-llm-try`.

Документация рассчитана на разработчика, который хочет понять, что уже
реализовано, как это работает и какие данные нужны для обучения.

## Состав документации

| Файл | Содержание |
|---|---|
| [Bpe.md](Bpe.md) | Токенизатор: словарь, спецтокены, reference- и fast-тренер, формат `.bpe`, производительность. |
| [Architecture.md](Architecture.md) | Устройство transformer, forward/backward, loss, оптимизатор, генерация, чекпоинты, API. |
| [TrainingData.md](TrainingData.md) | Формат обучающих данных, объём, качество, разбиение, подготовка корпуса и оценка качества. |

## Кратко о реализации

- **BPE**: 256 байт + 9 спецтокенов + merges. Production-тренер
  `sc_ai_bpe_new_fast` использует хеш-таблицу частот, позиционные списки и
  max-heap. Старый `sc_ai_bpe_new` оставлен как reference-реализация.
- **Модель**: decoder-only transformer на `float32`, без BLAS, OpenMP,
  pthread и внешних ML-библиотек.
- **Задача**: по описанию персонажа и ситуации сгенерировать реплику после
  `<SEP>`.
- **Loss**: cross-entropy с маскированием prompt-части
  (`ScTinyLlmLossMask_Prompt`).
- **Обучение**: AdamW, warmup + cosine, клиппинг градиента, early stopping с
  восстановлением лучших весов (`RestoreBest`).
- **Генерация**: KV-cache, greedy / top-k / top-p / temperature.
- **Чекпоинт**: конфиг модели + веса + встроенная копия BPE.
- **Демо**: `small-llm-try` — 16 синтетических примеров, микро-модель,
  сохранение/загрузка BPE и чекпоинта.

## Быстрый старт

Сборка и запуск демо из корня репозитория:

```bash
masuka -b release -p windows -nr
bin\release-windows\small_llm_try.exe
```

Linux:

```bash
masuka -b release -p linux -nr
./bin/release-linux/small_llm_try
```

Демо собирает корпус, обучает BPE fast-тренером, обучает микро-transformer,
генерирует ответы и перезагружает чекпоинт. Подробности — в
`small-llm-try/README.md`.

## Карта кода

| Путь | Что находится |
|---|---|
| `Source/Sc/Ai.h` | Публичные типы BPE, спецтокены, legacy MLP, объявления API. |
| `Source/Sc/Ai.c` | BPE-тренеры, tokenize/decode, save/load `.bpe`, legacy MLP. |
| `Source/Sc/TinyLlm.h` | Публичный API микро-LLM, конфиги, датасет, чекпоинты. |
| `Source/Sc/TinyLlm.c` | Transformer, forward/backward, обучение, генерация, чекпоинты. |
| `Source/Tests/ScTinyLlm.c` | Тесты BPE round-trip, repeated-byte case, grad check, обучения и чекпоинта. |
| `small-llm-try/main.c` | Сквозное демо: BPE → dataset → train → generate → reload. |
| `small-llm-try/README.md` | Инструкция по демо и его ограничения. |

## Ключевые ограничения

- BPE-кодирование `sc_ai_bpe_tokenize` применяет merges последовательно и
  имеет худшую сложность `O(merges * tokens)`. Быстрый тренер ускоряет
  обучение BPE, но не сам encode.
- Модель маленькая и учебная; на 16 примерах она переобучается.
- Нет dropout, mixed precision, beam search и repetition penalty.
- Запись чекпоинта не атомарная: при прерывании файл может быть повреждён.
- Полноценная оценка на реальном held-out корпусе в репозитории пока не
  добавлена.

## Статус по критериям ТЗ

| Критерий | Статус |
|---|---|
| 50 МБ / 10 000 merges ≤ 30 мин | Выполняется на синтетическом 50 МБ: около 17 с в release на CPU. |
| Валидационная PPL ≤ 30 | Зависит от данных и модели; на 16 синтетических примерах не показательна. |
| ≥ 50% стилистически корректных ответов | Нужен реальный held-out набор и ручная/автоматическая оценка. |
| 100 токенов ≤ 5 с на CPU | Достижимо для микро-модели; нужен замер на целевом железе. |

## Связанные файлы

- `small-llm-try/README.md` — практический запуск демо.
- `Source/Tests/ScTinyLlm.c` — пример использования API.
- `Source/Sc/TinyLlm.h` — точные сигнатуры и поля конфигов.
