# Архитектура и код микро-LLM

Основной код находится в `Source/Sc/TinyLlm.c`, публичный API — в
`Source/Sc/TinyLlm.h`. Токенизатор — в `Source/Sc/Ai.c` / `Source/Sc/Ai.h`.

## 1. Назначение

Модель решает условную задачу: по размеченному описанию персонажа,
эмоции и ситуации сгенерировать одну реплику после `<SEP>`.

Формат примера:

```text
<BOS><PERSONA>...<CHAR>...<EMO>...<SIT>...<SEP>ответ<EOS>
```

Это decoder-only language model: она учится предсказывать следующий токен,
но loss считается только на токенах ответа, а не на prompt-разметке.

## 2. Общая схема пайплайна

```text
сырой текст
    │
    ├─► обучение BPE (sc_ai_bpe_new_fast) ─► model.bpe
    │
    └─► подготовка условных примеров
             │
             ▼
      токенизация examples
             │
             ▼
      ScTinyLlmDataset
             │
             ▼
   sc_tiny_llm_train (+ validation, early stopping)
             │
             ▼
      checkpoint (.ckpt: config + weights + BPE)
             │
             ▼
   sc_tiny_llm_generate(prompt) ─► ответ
```

BPE и модель разделены: `ScTinyLlmModel` не хранит словарь. Токенизатор
передаётся в обучение, оценку и генерацию отдельно. Чекпоинт встраивает
копию BPE, чтобы после загрузки использовать ровно тот же словарь.

## 3. Карта кода

| Компонент | Файл | Ответственность |
|---|---|---|
| BPE | `Source/Sc/Ai.c/.h` | Обучение словаря, encode/decode, `.bpe`. |
| Transformer | `Source/Sc/TinyLlm.c/.h` | Модель, loss, backward, AdamW, генерация, чекпоинты. |
| Тесты | `Source/Tests/ScTinyLlm.c` | BPE round-trip, repeated bytes, grad check, train, checkpoint. |
| Демо | `Examples/small-llm-try/main.c` | Сквозной пример использования. |
| Legacy MLP | `Source/Sc/Ai.c` | Старая маленькая модель `ScAiModel`; не является целевой LLM. |

## 4. Пример и датасет

### 4.1. `ScTinyLlmExample`

```c
typedef struct
{
    i32* aTokens;
    i64 Count;
    i32 SepIndex;
} ScTinyLlmExample;
```

- `aTokens` — полная последовательность, включая `<BOS>`, `<SEP>`, `<EOS>`;
- `Count` — число токенов;
- `SepIndex` — индекс **последнего** `<SEP>`; `-1`, если разметки нет.

Если в строке несколько `<SEP>`, используется последний. Всё, что после
него, считается ответом.

### 4.2. Загрузка файла

`sc_tiny_llm_dataset_load_file`:

- читает файл целиком;
- пропускает UTF-8 BOM;
- делит текст по `\n`;
- удаляет завершающий `\r` (поддержка CRLF);
- пропускает пустые строки;
- пропускает строки, начинающиеся с `#` (комментарии);
- токенизирует каждую строку через переданный BPE;
- добавляет пример, если получилось хотя бы 2 токена.

Каждая строка — один независимый пример. Переводы строк внутри примера
не поддерживаются: они разделят его на два примера.

### 4.3. Память датасета

Датасет хранит все токены в памяти:

```text
O(суммарное число токенов * sizeof(i32)) + накладные расходы
```

Для очень больших корпусов это может быть заметно. При необходимости
позже можно перейти к memory-mapped токенам или потоковой загрузке.

## 5. Transformer

### 5.1. Конфигурация

```c
typedef struct
{
    i32 NumLayers;
    i32 DModel;
    i32 NumHeads;
    i32 DFf;
    i32 ContextLength;
    i32 VocabCount;
    f32 InitStd;
    u64 Seed;
} ScTinyLlmModelConfig;
```

Требование: `DModel % NumHeads == 0`. Если `VocabCount` меньше 265, он
поднимается до 265, чтобы покрыть все спецтокены. `ContextLength` — это
полная длина окна, включая prompt и ответ.

### 5.2. Слои

Модель состоит из:

1. **Token embedding**: `VocabCount × DModel`.
2. **Position embedding**: `ContextLength × DModel` (обучаемые).
3. **N блоков**:
   - pre-LayerNorm;
   - causal multi-head self-attention;
   - residual connection;
   - pre-LayerNorm;
   - FFN: `DModel → DFf → DModel`, активация GELU;
   - residual connection.
4. **Final LayerNorm**.
5. **LM head**: `DModel → VocabCount`.

Внутри attention:

```text
QKV = Linear(LN(x))          // DModel → 3 * DModel
Q, K, V = split(QKV)
scores = Q * K^T / sqrt(head_dim)
scores[t][j] = -inf, если j > t   // causal mask
probs = softmax(scores)
context = probs * V
out = Linear(context)         // DModel → DModel
```

Все веса и активации — `float32`. Есть bias-параметры у линейных слоёв и
LayerNorm. Инициализация: embedding — `InitStd`, матрицы — Xavier-подобный
предел, LayerNorm scale — 1, bias — 0.

### 5.3. Forward

`_sc_tiny_llm_forward`:

1. Складывает token embedding и position embedding.
2. Прогоняет N блоков.
3. Применяет финальный LayerNorm.
4. Считает логиты для всех позиций окна.

Если токен вне диапазона `[0, VocabCount)`, он заменяется на `<UNK>`.
Кэши активаций сохраняются для backward.

### 5.4. Параметры и память

Каждый параметр — `ScAiParam`:

```c
typedef struct
{
    f32* pData;   // веса
    f32* pGrad;   // градиент
    f32* pM;      // Adam momentum
    f32* pV;      // Adam second moment
    i64 Count;
} ScAiParam;
```

Итого около `16 байт × число параметров` на веса, градиенты и состояние
Adam, плюс активации и кэши. Точное число параметров возвращает
`sc_tiny_llm_param_count`.

## 6. Loss и маскирование

Для каждой позиции `t` модель предсказывает `label = tokens[t + 1]`.
Loss — cross-entropy по логитам.

`ScTinyLlmLossMask_Prompt`:

```text
если target_index <= SepIndex: mask = 0
иначе:                        mask = 1
```

То есть модель **видит** весь prompt, но градиент получает только за
токены ответа, включая `<EOS>`. Первый токен ответа (тот, что идёт сразу
после `<SEP>`) обучается, потому что его target_index больше `SepIndex`.

`ScTinyLlmLossMask_None` обучает все позиции, как обычную языковую модель.
Он полезен для отладки и grad check. Если `SepIndex = -1`, режим `Prompt`
не маскирует ничего: все позиции считаются обучаемыми.

Валидационный loss считается так же, как train loss, но без backward.
PPL:

```text
PPL = exp(validation_loss)
```

`sc_tiny_llm_eval` проверяет `EvalBatches` окон, стратифицированно
распределённых по всему val-датасету (`b * Count / batches`); старт окна
детерминирован от `(exampleIndex, seed)`. Один и тот же seed даёт один и тот
же val loss, но выборка покрывает корпус, а не 32 соседних примера. Если
валидных токенов нет, возвращается `NAN`; train считает это плохой
валидацией, а не «лучшим» результатом.

## 7. Backward и оптимизатор

Backward написан вручную для всех операций:

- cross-entropy + softmax;
- линейные слои;
- LayerNorm;
- causal attention;
- GELU;
- residual connections.

Порядок шага обучения:

1. Обнулить градиенты.
2. Взять очередной пример из перемешанного на эпоху списка (без возвращения).
3. Для каждого примера в батче:
   - выбрать случайное окно;
   - сделать forward;
   - добавить loss и градиенты; пустые примеры (0 валидных токенов) пропустить.
4. Нормировать градиент на число валидных токенов (`1 / stepTokens`).
5. Посчитать глобальную норму градиента.
6. Если `GradClip > 0`, масштабировать градиенты.
7. Посчитать learning rate.
8. Сделать AdamW-шаг.

AdamW:

- `beta1 = 0.9`, `beta2 = 0.999`, `eps = 1e-8`;
- weight decay применяется отдельно от адаптивного шага и только к матрицам
  (LayerNorm, bias и позиционные эмбеддинги не decay-ятся);
- bias correction по номеру шага.

Learning rate:

- линейный warmup до `WarmupSteps`;
- затем cosine decay до 10% от базового значения.

## 8. Обучение и early stopping

`sc_tiny_llm_train` принимает train и validation датасеты и конфиг.

Основные поля `ScTinyLlmTrainConfig`:

| Поле | Смысл |
|---|---|
| `Steps` | Число шагов оптимизатора. |
| `BatchSize` | Число примеров на шаг. |
| `LearningRate` | Базовый LR. |
| `WeightDecay` | Weight decay для AdamW. |
| `WarmupSteps` | Число шагов warmup. |
| `LossMask` | `Prompt` или `None`. |
| `LogEvery` | Как часто писать train loss. |
| `GradClip` | Порог глобальной нормы; `0` отключает. |
| `EvalEvery` | Как часто считать validation loss; `0` отключает. |
| `EvalBatches` | Сколько окон проверять на валидации. |
| `Patience` | Сколько проверок валидации с ухудшением терпеть; `0` отключает early stop. |
| `MinDelta` | Минимальное улучшение, чтобы считать его значимым. |
| `pCheckpointPath` | Путь чекпоинта. |
| `CheckpointEvery` | Как часто сохранять чекпоинт. |
| `pBestCheckpointPath` | Необязательный путь для best-чекпоинта; пишется сразу при улучшении. |
| `pValLogPath` | CSV-лог валидации `step,val_loss,val_ppl` (append); NULL — не писать. |
| `RestoreBest` | Восстановить лучшие веса после обучения. |
| `Seed` | Seed для перемешивания примеров и выбора окон. |

Логика early stopping:

1. При `EvalEvery > 0` и непустой валидации считается `valLoss`.
2. Если `valLoss < bestVal - MinDelta`, веса копируются в плоский буфер
   лучших параметров, `badEvals = 0`.
3. Иначе `badEvals++`; при `Patience > 0` и `badEvals >= Patience`
   обучение останавливается.
4. После цикла, если `RestoreBest = 1` и лучшие веса есть, они
   восстанавливаются.
5. Если заданы `pCheckpointPath` и `CheckpointEvery > 0`, после
   восстановления сохраняется именно best-чекпоинт.

Важно:

- `RestoreBest` работает только при `EvalEvery > 0` и непустой валидации.
- `Patience = 0` отключает раннюю остановку, но восстановление лучших
  весов в конце всё равно произойдёт, если `RestoreBest = 1`.
- Промежуточные чекпоинты сохраняют текущие веса; финальный best-чекпоинт
  перезаписывает файл после restore.
- Optimizer state при restore не восстанавливается, потому что обучение
  уже закончено.

## 9. Генерация

`sc_tiny_llm_generate`:

1. Создаёт prompt-токены.
2. Добавляет `<BOS>`, если его нет.
3. Токенизирует prompt.
4. Добавляет `<SEP>`, если последний токен — не `<SEP>` и
   `AppendSep = 1` (режим условной генерации; по умолчанию включён).
   При `AppendSep = 0` — чистое продолжение текста (LM-прелюдия).
5. Обрезает prompt так, чтобы осталось место хотя бы для одного нового
   токена (`ContextLength - 1`).
6. Прогоняет prompt через модель с KV-cache.
7. Сэмплирует новые токены до `MaxTokens` или заполнения контекста.
8. Останавливается на любом спецтокене.
9. Декодирует результат через BPE.

Sampling:

- `Temperature <= 1e-5` — greedy argmax;
- иначе softmax с температурой;
- `TopK > 0` — оставить K самых вероятных;
- `TopP` в `(0, 1)` — nucleus sampling;
- случайный выбор с seed.

`TopK = 0` отключает top-k. `TopP <= 0` или `TopP >= 1` отключает top-p.
`Seed = 0` заменяется на фиксированную константу.

Если первый же сгенерированный токен — спецтокен, результат будет пустой
строкой. Это нормальное поведение, а не ошибка.

## 10. Чекпоинт

`sc_tiny_llm_save_checkpoint` пишет:

```text
"SCTL" (4 байта)
u32 version = 1
i32 config[6] = { NumLayers, DModel, NumHeads, DFf, ContextLength, VocabCount }
для каждого параметра:
    i64 Count
    f32 data[Count]
i64 bpeLength
bytes[bpeLength]   // сериализованный .bpe
```

`sc_tiny_llm_load_checkpoint`:

- проверяет magic и version;
- восстанавливает конфиг;
- создаёт модель;
- проверяет, что `Count` каждого параметра совпадает;
- читает веса;
- читает BPE и, если передан `pOutBpe`, возвращает его.

После загрузки нужно освободить и модель, и BPE:

```c
ScAiBpe bpe = {};
ScTinyLlmModel* model = sc_tiny_llm_load_checkpoint("model.ckpt", &bpe);
// ...
sc_ai_bpe_destroy(&bpe);
sc_tiny_llm_destroy(model);
```

Запись атомарная: чекпоинт пишется в `<path>.tmp`, затем подменяет
основной файл (`MoveFileExA` на Windows, `rename` на POSIX). При падении
посреди записи основной чекпоинт остаётся прежним.

Если задан `pBestCheckpointPath`, лучшие веса пишутся туда сразу при
улучшении val loss; финальный `pCheckpointPath` сохраняется после restore.
Optimizer state в чекпоинт не входит, поэтому resume с точным состоянием
Adam пока не поддерживается.

## 11. Пример использования API

```c
#include "Sc.h"
#include "TinyLlm.h"

// 1. BPE
ScAiBpe bpe = sc_ai_bpe_new_fast((ScAiBpeConfig) {
    .pText = corpus,
    .TextLength = corpusLength,
    .MergesCount = 10000,
    .ShouldLogProgress = 0,
});

sc_ai_bpe_save_to_disk((ScAiBpeSaveToDiskConfig) {
    .Bpe = bpe,
    .pFilePath = "model.bpe",
    .TotalTextLength = corpusLength,
    .TotalTextLengthCompressed = sc_list_count(bpe.aTokens),
});

// 2. Датасет
ScTinyLlmDataset train = sc_tiny_llm_dataset_new();
ScTinyLlmDataset val = sc_tiny_llm_dataset_new();
sc_tiny_llm_dataset_load_file(&train, bpe, "train.txt");
sc_tiny_llm_dataset_load_file(&val, bpe, "val.txt");

// 3. Модель
i32 vocabCount = (i32)sc_list_count(bpe.aVocab);
ScTinyLlmModelConfig mc = sc_tiny_llm_model_config_preset(ScTinyLlmSize_Micro, vocabCount);
ScTinyLlmModel* model = sc_tiny_llm_create(&mc);

// 4. Обучение
ScTinyLlmTrainConfig tc = sc_tiny_llm_train_config_default();
tc.Steps = 2000;
tc.BatchSize = 8;
tc.EvalEvery = 50;
tc.EvalBatches = 20;
tc.Patience = 5;
tc.RestoreBest = 1;
tc.pCheckpointPath = "model.ckpt";
tc.CheckpointEvery = 200;
sc_tiny_llm_train(model, bpe, &train, &val, &tc);

// 5. Генерация
ScTinyLlmGenerateConfig gc = sc_tiny_llm_generate_config_default();
gc.MaxTokens = 100;
char* answer = sc_tiny_llm_generate(
    model, bpe,
    "<BOS><PERSONA>...<CHAR>...<EMO>...<SIT>...<SEP>",
    &gc);
sc_string_destroy(answer);

// 6. Освобождение
sc_tiny_llm_destroy(model);
sc_tiny_llm_dataset_destroy(&train);
sc_tiny_llm_dataset_destroy(&val);
sc_ai_bpe_destroy(&bpe);
```

## 12. Пресеты модели

| Пресет | Layers | DModel | Heads | DFf | Context |
|---|---:|---:|---:|---:|---:|
| `Micro` | 2 | 64 | 2 | 256 | 128 |
| `Medium` | 4 | 128 | 4 | 512 | 256 |
| `Target` | 6 | 256 | 8 | 1024 | 512 |

`sc_tiny_llm_model_config_default` возвращает micro-конфиг.
Демо `small-llm-try` использует micro, но уменьшает `DFf` до 128 и
`VocabCount` до 393 (128 merges).

## 13. Производительность и память

- Модель считается на CPU, без BLAS и многопоточности.
- Forward/backward — честные циклы на C; на больших пресетах обучение
  может быть медленным.
- Генерация использует KV-cache, поэтому не пересчитывает весь prompt на
  каждом токене.
- BPE encode всё ещё последовательный по merges; это влияет на подготовку
  данных и на генерацию prompt.
- Датасет хранится в памяти; токены копируются в массивы точного размера
  (без capacity, равной длине текста в байтах), иначе на 100 МиБ корпуса
  уходило ~450 МиБ.
- Для микро-модели 100 токенов на CPU обычно укладываются в несколько
  секунд; точный замер нужен на целевом железе.

## 14. Тесты

`Source/Tests/ScTinyLlm.c` проверяет:

- BPE reference/fast round-trip;
- повторяющиеся байты `(A, A)`;
- аналитический градиент конечными разностями;
- обучение на маленьком датасете;
- генерацию;
- сохранение/загрузку чекпоинта;
- early stopping с восстановлением лучших весов.

Grad check:

- берёт первый пример;
- использует `LossMask_None`, чтобы loss был ненулевым;
- ограничивает окно 8 токенами;
- проверяет не более `maxParams` параметров каждого тензора;
- сравнивает аналитический и численный градиент с допуском.

## 15. Ограничения

- Нет dropout и регуляризации кроме weight decay.
- Нет mixed precision.
- Нет beam search, repetition penalty и запрета повторов.
- Нет batched inference с padding.
- Нет потокобезопасности.
- Нет resume с optimizer state (m/v), step и RNG.
- Нет полноценного evaluation на реальном held-out корпусе в репозитории.
- Модель может генерировать невалидный UTF-8, потому что BPE работает с
  байтами.
- На маленьком датасете модель переобучается; early stopping и
  `RestoreBest` помогают, но не заменяют данные.

## 16. Профилирование

Замеры ядер активны только при сборке с `PROFILE`:

```sh
masuka -b profile -p windows -e lm_train -nr
```

В `TinyLlm.c` вызовы `sc_profiler_start/end` обёрнуты макросами
`SC_TINY_LLM_PROF_BEGIN/END`. Без `PROFILE` макросы раскрываются в
`((void)0)`, поля профиля в `ScTinyLlmModel` отсутствуют, а
`sc_tiny_llm_profile_*` в заголовке — пустые макросы.

`sc_tiny_llm_train` сбрасывает счётчики в начале, accumulated ns пишет в
`aProfileNanoseconds`, а в конце печатает таблицу. `forward (total)` и
`backward (total)` — вложенные таймеры; `leaf-kernel-sum` и доли считаются
без них. `sc_tiny_llm_eval` на время оценки ставит `ProfilePaused`, чтобы
валидация не попадала в train-профиль.

На Windows `sc_profiler_end` нормирует тики `QueryPerformanceCounter` в
наносекунды через `QueryPerformanceFrequency`, поэтому
`sc_profiler_get_nanoseconds` возвращает честные ns.
