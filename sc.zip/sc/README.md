# Sc

Sc is the small, explicit foundation layer of the engine: a C99 core library that provides the boring, essential things every other module needs - memory, strings, builders, lists, files, directories, paths, logging, system information, CPU/thread utilities, ui, vulkan/window abstraction layer, basic result/error handling and many more. The name can be read two ways: Simple Core as architecture, and Simple C as implementation style. Both are accurate.

## Guides

- [Docs/LEARN_GUIDE.md](Docs/LEARN_GUIDE.md) — how to train TinyLlm on a real corpus: build commands for Windows and Linux, BPE, `lm_train`, `lm_chat`, iteration guidance for `micro`/`medium`/`target`, AVX2 benchmarks and troubleshooting.
- [Docs/avx2-cpu.md](Docs/avx2-cpu.md) — AVX2+FMA CPU backend: runtime dispatch, self-test and measured speedup.
- [Docs/PERFECT_TRAIN_DATA_EXAMPLE.md](Docs/PERFECT_TRAIN_DATA_EXAMPLE.md) — why line-by-line training plateaus and how to pack lines into windows: `<BOS>`/`<EOS>` in a continuous token stream, book-level train/val split, `medium` recipe, and why `lm_chat` returns an empty continuation.
- [Docs/SysRequirements.md](Docs/SysRequirements.md) - RAM, VRAM, CPU and time requirements for `micro`, `medium` and `target`: measured peak RSS, step time, run durations and hardware recommendations.
- [Examples/GpuTinyLLM/README.md](Examples/GpuTinyLLM/README.md) - Vulkan compute backend for TinyLlm: forward/backward/AdamW on GPU, compute shaders, SCTL checkpoints, `bench`/`train`/`eval`/`gen`/`gradcheck`, and current limitations.
- [Docs/README.md](Docs/README.md) — AI/BPE and TinyLlm documentation index.
