# Sc

Sc is the small, explicit foundation layer of the engine: a C99 core library that provides the boring, essential things every other module needs — memory, strings, builders, lists, files, directories, paths, logging, system information, CPU/thread utilities, ui, vulkan/window abstraction layer, basic result/error handling and many more. The name can be read two ways: Simple Core as architecture, and Simple C as implementation style. Both are accurate.

## Documentation

- [AI/BPE and micro-LLM](Docs/README.md) — токенизатор, transformer, обучение, генерация и требования к данным.
