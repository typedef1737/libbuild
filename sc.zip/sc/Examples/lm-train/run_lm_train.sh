#!/usr/bin/env bash
# Запуск lm_train (шаг 2 пайплайна MS1): обучение LM-прелюдии.
#
# Использование (из любой папки):
#   ./run_lm_train.sh <corpus-dir> --bpe <file.bpe> [options]
#   bash Examples/lm-train/run_lm_train.sh D:/books --bpe books.bpe --model medium
#
# Скрипт: cd в корень репозитория -> сборка release -> запуск с
# пробросом всех аргументов. Все параметры утилиты — см. README.md.

set -e

# Корень репозитория (скрипт лежит в Examples/lm-train/).
cd "$(cd "$(dirname "$0")" && pwd -P)/../.."

# Платформа: linux нативно, всё остальное (git-bash/MSYS на Windows) — windows.
OS="$(uname -s)"
case "$OS" in
    Linux*) PLATFORM="linux";  EXE="" ;;
    *)      PLATFORM="windows"; EXE=".exe" ;;
esac

masuka -b release -p "$PLATFORM" -e lm_train -nr
exec "bin/release-$PLATFORM/lm_train$EXE" "$@"
