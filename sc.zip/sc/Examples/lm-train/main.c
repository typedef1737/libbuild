/*
  lm_train — CLI-утилита, шаг 2 пайплайна MS1: обучение LM-прелюдии.

  Пайплайн MS1 разбит на три CLI-инструмента (см. Docs/todo-0.md):
    1. bpe_train — словарь BPE по директории с текстовыми файлами;
    2. lm_train  — обучение LM-прелюдии по BPE + корпусу (эта утилита);
    3. lm_chat   — интерактивная генерация по чекпоинту из консоли.

  Что делает эта утилита:
    1. загружает готовый BPE-словарь (файл от bpe_train, "# bpe v1");
    2. рекурсивно собирает все *.txt/*.text из входной директории
       и склеивает в один большой буфер (на диске не склеивается);
    3. строит датасет прелюдии: каждая строка -> <BOS>строка<EOS>,
       БЕЗ полей разметки; каждая 10-я строка — валидация (held-out).
       С флагом --pack строки склеиваются в непрерывный поток токенов и
       режутся на окна ровно ctx+1 токен (шаг ctx), а train/val делятся
       по файлам-книгам, а не по строкам;
    4. обучает decoder-only transformer с LossMask_None (loss по всем
       токенам — чистое языковое моделирование) с логированием в
       консоль и CSV-лог валидации;
    5. сохраняет чекпоинт (веса + config + встроенный BPE) — это вход
       для lm_chat и для MS2 (fine-tuning).

  Запуск из корня репозитория:
    masuka -b release -p windows -e lm_train -nr
    bin\release-windows\lm_train.exe <corpus-dir> --bpe <file.bpe> [options]

  Пример:
    bin\release-windows\lm_train.exe D:\books --bpe books.bpe --model micro

  Параметры:
    <corpus-dir>    обязательная директория с текстовыми файлами (рекурсивно);
    --bpe <path>    обязательный путь к .bpe от bpe_train;
    -o <path>       выходной чекпоинт (по умолчанию "lm.ckpt" в текущей папке);
    --model <name>  пресет: micro (2/64/2/256/ctx128), medium (4/128/4/512/ctx256),
                    target (6/256/8/1024/ctx512); по умолчанию micro;
    --steps <n>     шаги обучения (по умолчанию 1000);
    --batch <n>     batch size (по умолчанию 4);
    --lr <f>        learning rate (по умолчанию 0.003);
    --patience <n>  patience early stopping (по умолчанию 10);
    --pack          упаковка окон: <BOS>строка<EOS> в непрерывный поток,
                    окна ctx+1 с шагом ctx; train/val делятся по книгам;
    --val-log <p>   CSV-лог валидации (по умолчанию "lm_val.csv").

  NOTE: это ЭТАП 1 из двухэтапной схемы (Docs/todo-0.md, глава
  «ОЧЕНЬ ВАЖНО»): модель учит ЯЗЫК на обычном тексте. Роли (поля
  разметки, LossMask_Prompt) — это MS2, отдельный fine-tuning.
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LmTrainMaxDepth 8
#define LmTrainDefaultSteps 1000
#define LmTrainDefaultBatch 4
#define LmTrainDefaultLr 0.003f
#define LmTrainDefaultPatience 10
#define LmTrainDefaultOutput "lm.ckpt"
#define LmTrainDefaultValLog "lm_val.csv"
#define LmTrainLogEvery 50
#define LmTrainEvalEvery 50
#define LmTrainCheckpointEvery 200
#define LmTrainSeed 0x5c0deULL
// DOCS: максимум ctx пресетов (target = 512) + 1 токен метки в окне.
#define LmTrainMaxContext 512
#define LmTrainPackSeed 0x9e3779b97f4a7c15ULL

// DOCS: значение флага "-name value" / "--name value" из командной
// строки; если флага нет — pDefault. Ищет пары "флаг, следующий аргумент".
static const char*
_lm_train_flag(i32 argc, char** argv, const char* pName, const char* pDefault)
{
    for (i32 i = 1; i < argc - 1; ++i)
    {
        if (strcmp(argv[i], pName) == 0)
            return argv[i + 1];
    }
    return pDefault;
}

// DOCS: булев флаг без значения (например, --pack): присутствие в argv.
static i32
_lm_train_has_flag(i32 argc, char** argv, const char* pName)
{
    for (i32 i = 1; i < argc; ++i)
    {
        if (strcmp(argv[i], pName) == 0)
            return 1;
    }
    return 0;
}

// DOCS: текстовый ли файл — по расширению (.txt/.text). Рекурсивный обход
// сам отсекает бинарные форматы по этому фильтру.
static i32
_lm_train_is_text_file(const char* pPath)
{
    i64 length = sc_string_get_length((char*)pPath);
    if (length < 4)
        return 0;

    // DOCS: сравниваем последние 4/5 символов без учёта регистра.
    const char* pTail = pPath + length - 4;
    if (pTail[0] == '.'
        && (pTail[1] == 't' || pTail[1] == 'T')
        && (pTail[2] == 'x' || pTail[2] == 'X')
        && (pTail[3] == 't' || pTail[3] == 'T'))
        return 1;

    if (length >= 5)
    {
        pTail = pPath + length - 5;
        if (pTail[0] == '.'
            && (pTail[1] == 't' || pTail[1] == 'T')
            && (pTail[2] == 'e' || pTail[2] == 'E')
            && (pTail[3] == 'x' || pTail[3] == 'X')
            && (pTail[4] == 't' || pTail[4] == 'T'))
            return 1;
    }

    return 0;
}

// DOCS: освобождение списка путей из _lm_train_collect_text_files.
// NOTE: sc_directory_get_* возвращают обычные аллокации (без
// ScString-заголовка) — освобождаем через sc_memory_free.
static void
_lm_train_free_file_list(char** aFiles, i32 FilesCount)
{
    for (i32 i = 0; i < FilesCount; ++i)
        sc_memory_free(aFiles[i]);
    sc_list_free(aFiles);
}

// DOCS: рекурсивный сбор текстовых файлов из директории (Sc):
// sc_directory_get_directories/sc_directory_get_files с абсолютными
// путями; в подпапки спускаемся до глубины maxDepth (защита от циклов
// из symlink'ов). Возвращает список путей (обычные аллокации —
// освобождать через _lm_train_free_file_list).
static char**
_lm_train_collect_text_files(const char* pDir, i32* pFilesCount, i32 maxDepth)
{
    char** aFiles = NULL;
    i32 count = 0;

    if (maxDepth <= 0)
        return NULL;

    // DOCS: файлы текущей директории (абсолютные пути).
    char** aLocalFiles = sc_directory_get_files(pDir, 1);
    for (i32 i = 0; aLocalFiles && i < (i32)sc_list_count(aLocalFiles); ++i)
    {
        if (_lm_train_is_text_file(aLocalFiles[i]))
        {
            sc_list_add(aFiles, aLocalFiles[i]);
            ++count;
        }
        else
        {
            sc_memory_free(aLocalFiles[i]);
        }
    }
    sc_list_free(aLocalFiles);

    // DOCS: подпапки — рекурсивно.
    char** aSubDirs = sc_directory_get_directories(pDir, 1);
    for (i32 i = 0; aSubDirs && i < (i32)sc_list_count(aSubDirs); ++i)
    {
        char** aSubFiles = _lm_train_collect_text_files(aSubDirs[i], NULL, maxDepth - 1);
        for (i32 s = 0; aSubFiles && s < (i32)sc_list_count(aSubFiles); ++s)
        {
            sc_list_add(aFiles, aSubFiles[s]);
            ++count;
        }
        sc_list_free(aSubFiles);
        sc_memory_free(aSubDirs[i]);
    }
    sc_list_free(aSubDirs);

    if (pFilesCount)
        *pFilesCount = count;
    return aFiles;
}

// DOCS: загрузка НЕСКОЛЬКИХ файлов корпуса (сотни рассказов — без склейки
// в один большой файл на диске): каждый файл из aFiles читается в память
// и приклеивается в общий builder с "\n" между файлами. Возвращает NULL,
// если не удалось прочитать ни один файл.
static char*
_lm_train_load_corpus_files(char** aFiles, i32 FilesCount, i64* pLength, i32* pFileCount)
{
    char* pBuilder = sc_builder_new();
    i32 loaded = 0;

    for (i32 p = 0; p < FilesCount; ++p)
    {
        i64 size = 0;
        char* pData = sc_file_read_ext_ext_r(aFiles[p], &size);
        if (!pData || size <= 0)
        {
            printf("corpus: skip %s (unreadable)\n", aFiles[p]);
            continue;
        }

        if (loaded > 0)
            sc_builder_append_string(pBuilder, "\n", 1);

        sc_builder_append_string(pBuilder, pData, size);
        // NOTE: sc_file_read_ext_ext_r возвращает обычную аллокацию
        // (не ScString) — освобождаем через sc_memory_free.
        sc_memory_free(pData);
        ++loaded;
    }

    if (loaded <= 0)
    {
        sc_builder_destroy(pBuilder);
        return NULL;
    }

    i64 length = sc_builder_count(pBuilder);
    char* pCorpus = sc_string_new_ext_ext_r(pBuilder, length, length);
    sc_builder_destroy(pBuilder);

    if (pLength)
        *pLength = length;
    if (pFileCount)
        *pFileCount = loaded;
    return pCorpus;
}

// DOCS: строка прогресса сборки датасета — в stdout через printf и в
// sc.log (тот же файл, куда пишет файловый бэкенд sc_log), чтобы прогресс
// оставался в логе после завершения утилиты.
static void
_lm_train_log_dataset_progress(i32 percent, i64 processed, i64 total, i64 lines)
{
    char buf[256] = {};
    i32 length = snprintf(buf, sizeof(buf),
        "dataset: %3d%% (%.2f/%.2f MiB, lines=%lld)\n",
        percent,
        (f64)processed / (1024.0 * 1024.0),
        (f64)total / (1024.0 * 1024.0),
        (long long)lines);
    if (length <= 0)
        return;

    if (length >= (i32)sizeof(buf))
        length = (i32)sizeof(buf) - 1;

    printf("%s", buf);
    sc_file_append_string_ext_r("sc.log", buf, (u64)length);
}

// DOCS: датасет прелюдии из буфера корпуса: каждая строка ->
// <BOS>строка<EOS>, БЕЗ полей разметки; каждая 10-я строка (added % 10
// == 9) — в валидацию (held-out). Пропускаются пустые строки, строки с
// '#' в начале и комментарии-заголовки; CRLF/BOM допустимы; уже
// размеченные <BOS>/<EOS> не задваиваются.
static void
_lm_train_build_datasets(const char* pText, i64 size, ScAiBpe bpe,
    ScTinyLlmDataset* pTrain, ScTinyLlmDataset* pVal)
{
    i64 start = 0;
    i64 i = 0;

    // DOCS: пропускаем UTF-8 BOM, если данные начинались с него.
    if (size >= 3 && (u8)pText[0] == 0xEF && (u8)pText[1] == 0xBB && (u8)pText[2] == 0xBF)
    {
        start = 3;
        i = 3;
    }

    // DOCS: прогресс сборки датасета — каждый 5% байтов корпуса в
    // printf (по ТЗ: видно, что утилита не зависла на большом корпусе).
    // progressPercent — печатаемое значение (5, 10, ... 100), progressNext —
    // соответствующий ему порог в байтах.
    i32 progressPercent = 0;
    i64 progressNext = size + 1;
    if (size >= 20)
    {
        progressPercent = 5;
        progressNext = (i64)((f64)size * 0.05);
        if (progressNext < 1)
            progressNext = 1;
    }

    i64 added = 0;
    while (i <= size)
    {
        if (i == size || pText[i] == '\n')
        {
            i64 end = i;
            if (end > start && pText[end - 1] == '\r')
                --end;

            if (end > start && pText[start] != '#')
            {
                // DOCS: если строка уже размечена <BOS>/<EOS> —
                // срезаем маркеры, чтобы не задваивать их.
                i64 lineStart = start;
                i64 lineEnd = end;
                if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineEnd - 5, "<EOS>", 5))
                    lineEnd -= 5;
                if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineStart, "<BOS>", 5))
                    lineStart += 5;

                char* pBuilder = sc_builder_new();
                sc_builder_append_string(pBuilder, "<BOS>", 5);
                sc_builder_append_string(pBuilder, pText + lineStart, lineEnd - lineStart);
                sc_builder_append_string(pBuilder, "<EOS>", 5);

                i64 lineLength = sc_builder_count(pBuilder);
                char* pLine = sc_string_new_ext_ext_r(pBuilder, lineLength, lineLength);
                sc_builder_destroy(pBuilder);

                if (added % 10 == 9)
                    sc_tiny_llm_dataset_add(pVal, bpe, pLine);
                else
                    sc_tiny_llm_dataset_add(pTrain, bpe, pLine);

                sc_string_destroy(pLine);
                ++added;
            }

            start = i + 1;
        }

        if (progressPercent > 0 && i >= progressNext)
        {
            _lm_train_log_dataset_progress(progressPercent, i, size, added);

            progressPercent += 5;
            if (progressPercent > 95)
                progressPercent = 0; // 100% — отдельной строкой после цикла
            else
                progressNext = (i64)((f64)size * (f64)progressPercent / 100.0);
        }
        ++i;
    }

    if (size > 0)
        _lm_train_log_dataset_progress(100, size, size, added);
}

// DOCS: одна строка корпуса -> <BOS>строка<EOS> -> готовые токены.
// Возвращает NULL для пустой строки, строки-комментария ('#') и ошибки
// токенизации. Уже размеченные <BOS>/<EOS> срезаются, чтобы не задваивать.
// Освобождать результат через sc_list_free.
static i32*
_lm_train_tokenize_line(ScAiBpe bpe, char* pText, i64 start, i64 end, i64* pCount)
{
    if (pCount)
        *pCount = 0;
    if (!pText || end <= start || pText[start] == '#')
        return NULL;

    if (end - start >= 5 && sc_string_compare_ext(pText + end - 5, "<EOS>", 5))
        end -= 5;
    if (end - start >= 5 && sc_string_compare_ext(pText + start, "<BOS>", 5))
        start += 5;
    if (end <= start)
        return NULL;

    char* pBuilder = sc_builder_new();
    sc_builder_append_string(pBuilder, "<BOS>", 5);
    sc_builder_append_string(pBuilder, pText + start, end - start);
    sc_builder_append_string(pBuilder, "<EOS>", 5);

    i64 lineLength = sc_builder_count(pBuilder);
    char* pLine = sc_string_new_ext_ext_r(pBuilder, lineLength, lineLength);
    sc_builder_destroy(pBuilder);

    i32* aTokens = sc_ai_bpe_tokenize((ScAiTokenizeConfig) {
        .pText = pLine,
        .TextLength = lineLength,
        .Bpe = bpe,
    });
    sc_string_destroy(pLine);

    if (!aTokens)
        return NULL;

    if (pCount)
        *pCount = sc_list_count(aTokens);
    return aTokens;
}

// DOCS: состояние упаковщика (--pack): непрерывный поток токенов режется
// на окна ровно ctx+1 токен (вход ctx + метка следующего окна), шаг ctx.
// Хвост короче ctx+1 отбрасывается — padding не нужен.
typedef struct
{
    ScTinyLlmDataset* pDataset;
    i32 Ctx;
    i32 aPending[LmTrainMaxContext + 1];
    i32 PendingCount;
    i64 Windows;
    i64 Tokens;
} LmTrainPacker;

static void
_lm_train_packer_push(LmTrainPacker* pPacker, const i32* aTokens, i64 Count)
{
    if (!pPacker || !aTokens || Count <= 0)
        return;

    for (i64 i = 0; i < Count; ++i)
    {
        pPacker->aPending[pPacker->PendingCount++] = aTokens[i];
        if (pPacker->PendingCount == pPacker->Ctx + 1)
        {
            if (sc_tiny_llm_dataset_add_tokens(pPacker->pDataset,
                    pPacker->aPending, pPacker->PendingCount))
                ++pPacker->Windows;

            // DOCS: шаг окна = ctx: последний токен окна (он же метка)
            // становится первым входным токеном следующего окна.
            pPacker->aPending[0] = pPacker->aPending[pPacker->Ctx];
            pPacker->PendingCount = 1;
        }
    }

    pPacker->Tokens += Count;
}

// DOCS: детерминированное перемешивание примеров (Fisher-Yates, xorshift64).
// Применяется к val-потоку, чтобы первые EvalBatches окон были разбросаны
// по всем валидационным книгам, а не шли подряд с начала первой книги.
static void
_lm_train_shuffle_dataset(ScTinyLlmDataset* pDataset, u64 seed)
{
    if (!pDataset || pDataset->Count < 2)
        return;

    u64 rng = seed ? seed : 1;
    for (i64 i = pDataset->Count - 1; i > 0; --i)
    {
        rng ^= rng << 13;
        rng ^= rng >> 7;
        rng ^= rng << 17;

        i64 j = (i64)(rng % (u64)(i + 1));
        ScTinyLlmExample tmp = pDataset->aExamples[i];
        pDataset->aExamples[i] = pDataset->aExamples[j];
        pDataset->aExamples[j] = tmp;
    }
}

// DOCS: --pack: корпус читается по файлам, каждый файл — «книга».
// Каждая 10-я книга уходит в val (если файлов меньше 10 — последняя).
// Внутри каждой части строки склеиваются в один поток токенов
// <BOS>строка<EOS><BOS>строка<EOS>... и режутся на окна ctx+1.
static void
_lm_train_build_packed_datasets(char** aFiles, i32 FilesCount, ScAiBpe bpe, i32 ctx,
    ScTinyLlmDataset* pTrain, ScTinyLlmDataset* pVal,
    i64* pCorpusLength, i32* pLoadedCount)
{
    if (ctx > LmTrainMaxContext)
        ctx = LmTrainMaxContext;

    LmTrainPacker train = { .pDataset = pTrain, .Ctx = ctx };
    LmTrainPacker val = { .pDataset = pVal, .Ctx = ctx };

    i64 corpusLength = 0;
    i32 loaded = 0;
    i32 trainFiles = 0;
    i32 valFiles = 0;
    i32 loggedPercent = 0;

    for (i32 f = 0; f < FilesCount; ++f)
    {
        i32 isVal = (FilesCount >= 10) ? (f % 10 == 9) : (f == FilesCount - 1);

        i64 size = 0;
        char* pData = sc_file_read_ext_ext_r(aFiles[f], &size);
        if (!pData || size <= 0)
        {
            printf("pack: skip %s (unreadable)\n", aFiles[f]);
            continue;
        }

        ++loaded;
        corpusLength += size;
        if (isVal)
            ++valFiles;
        else
            ++trainFiles;

        i64 start = 0;
        i64 i = 0;
        if (size >= 3 && (u8)pData[0] == 0xEF && (u8)pData[1] == 0xBB && (u8)pData[2] == 0xBF)
        {
            start = 3;
            i = 3;
        }

        LmTrainPacker* pPacker = isVal ? &val : &train;

        for (; i <= size; ++i)
        {
            if (i != size && pData[i] != '\n')
                continue;

            i64 end = i;
            if (end > start && pData[end - 1] == '\r')
                --end;

            i64 count = 0;
            i32* aTokens = _lm_train_tokenize_line(bpe, pData, start, end, &count);
            if (aTokens)
            {
                _lm_train_packer_push(pPacker, aTokens, count);
                sc_list_free(aTokens);
            }

            start = i + 1;
        }

        // NOTE: sc_file_read_ext_ext_r возвращает обычную аллокацию.
        sc_memory_free(pData);

        i32 percent = (i32)(((i64)(f + 1) * 100) / FilesCount);
        if (percent >= loggedPercent + 5 || f == FilesCount - 1)
        {
            loggedPercent = percent;
            printf("pack: %3d%% (%d/%d files, train windows=%lld, val windows=%lld)\n",
                percent, f + 1, FilesCount,
                (long long)train.Windows, (long long)val.Windows);
        }
    }

    _lm_train_shuffle_dataset(pVal, LmTrainPackSeed);

    if (trainFiles > 0 && valFiles > 0)
    {
        printf("pack: books train=%d val=%d, ctx=%d, window=%d, stride=%d\n",
            trainFiles, valFiles, ctx, ctx + 1, ctx);
        printf("pack: tokens train=%lld val=%lld, windows train=%lld val=%lld\n",
            (long long)train.Tokens, (long long)val.Tokens,
            (long long)train.Windows, (long long)val.Windows);
    }

    if (pCorpusLength)
        *pCorpusLength = corpusLength;
    if (pLoadedCount)
        *pLoadedCount = loaded;
}

static void
_lm_train_print_usage(void)
{
    printf("usage: lm_train <corpus-dir> --bpe <file.bpe> [options]\n");
    printf("  <corpus-dir>    directory with *.txt/*.text (recursive)\n");
    printf("  --bpe <path>    BPE file from bpe_train (required)\n");
    printf("  -o <path>       output checkpoint (default: %s)\n", LmTrainDefaultOutput);
    printf("  --model <name>  micro | medium | target (default: micro)\n");
    printf("  --steps <n>     train steps (default: %d)\n", LmTrainDefaultSteps);
    printf("  --batch <n>     batch size (default: %d)\n", LmTrainDefaultBatch);
    printf("  --lr <f>        learning rate (default: %.4f)\n", LmTrainDefaultLr);
    printf("  --patience <n>  early stopping patience (default: %d)\n", LmTrainDefaultPatience);
    printf("  --pack          pack lines into ctx+1 windows, split train/val by books\n");
    printf("  --val-log <p>   validation CSV log (default: %s)\n", LmTrainDefaultValLog);
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    sc_log_info("=== lm-train: MS1 language model prelude ===\n");

    // 1. Аргументы.
    const char* pDir = NULL;
    for (i32 i = 1; i < argc; ++i)
    {
        if (argv[i][0] != '-')
        {
            pDir = argv[i];
            break;
        }
    }
    const char* pBpePath = _lm_train_flag(argc, argv, "--bpe", NULL);

    if (!pDir || !pBpePath)
    {
        _lm_train_print_usage();
        return 1;
    }

    const char* pOutPath = _lm_train_flag(argc, argv, "-o", LmTrainDefaultOutput);
    const char* pValLogPath = _lm_train_flag(argc, argv, "--val-log", LmTrainDefaultValLog);
    const char* pModelName = _lm_train_flag(argc, argv, "--model", "micro");
    i32 steps = atoi(_lm_train_flag(argc, argv, "--steps", "1000"));
    i32 batch = atoi(_lm_train_flag(argc, argv, "--batch", "4"));
    f32 lr = (f32)atof(_lm_train_flag(argc, argv, "--lr", "0.003"));
    i32 patience = atoi(_lm_train_flag(argc, argv, "--patience", "10"));
    i32 isPack = _lm_train_has_flag(argc, argv, "--pack");
    if (steps <= 0)
        steps = LmTrainDefaultSteps;
    if (batch <= 0)
        batch = LmTrainDefaultBatch;
    if (lr <= 0.0f)
        lr = LmTrainDefaultLr;
    if (patience <= 0)
        patience = LmTrainDefaultPatience;

    ScTinyLlmSize size = ScTinyLlmSize_Micro;
    if (strcmp(pModelName, "medium") == 0)
        size = ScTinyLlmSize_Medium;
    else if (strcmp(pModelName, "target") == 0)
        size = ScTinyLlmSize_Target;
    else if (strcmp(pModelName, "micro") != 0)
    {
        printf("error: unknown model '%s' (use micro | medium | target)\n", pModelName);
        return 1;
    }

    // DOCS: терминал + файл sc.log — параметры запуска и прогресс должны
    // оставаться в логе после завершения утилиты.
    ScLogBackend aLogBackends[2] = {
        sc_log_get_terminal_backend(),
        sc_log_get_file_backend(),
    };
    sc_log_init((ScLogConfig) {
        .BackendsCount = 2,
        .aBackends = aLogBackends,
    });

    // DOCS: параметры командной строки — сразу после разбора аргументов,
    // чтобы они попали в лог даже если BPE/корпус потом не загрузятся.
    {
        char logBuf[1024] = {};

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: args: corpus=%s bpe=%s out=%s val-log=%s\n",
            pDir, pBpePath, pOutPath, pValLogPath);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: args: model=%s steps=%d batch=%d lr=%.5f patience=%d pack=%d\n",
            pModelName, steps, batch, lr, patience, isPack);
        sc_log_info("%s", logBuf);
    }

    // 2. BPE-словарь (от bpe_train).
    ScAiBpe bpe = sc_ai_bpe_load_from_disk((char*)pBpePath);
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: cannot load BPE from %s\n", pBpePath);
        sc_log_deinit();
        return 1;
    }
    printf("bpe: vocab=%d merges=%d\n",
        (i32)sc_list_count(bpe.aVocab), (i32)sc_list_count(bpe.aMerges));

    // 3. Конфиг модели: ctx нужен уже при сборке датасета (окна --pack).
    ScTinyLlmModelConfig modelConfig =
        sc_tiny_llm_model_config_preset(size, (i32)sc_list_count(bpe.aVocab));
    modelConfig.Seed = LmTrainSeed;

    // 4. Корпус.
    if (sc_path((char*)pDir) != ScPathItemType_Directory)
    {
        printf("error: corpus dir %s not found\n", pDir);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    i32 filesCount = 0;
    char** aFiles = _lm_train_collect_text_files(pDir, &filesCount, LmTrainMaxDepth);
    printf("corpus: dir %s -> %d text file(s) (recursive)\n", pDir, filesCount);

    i64 corpusLength = 0;
    i32 loadedCount = 0;
    ScTinyLlmDataset trainDataset = sc_tiny_llm_dataset_new();
    ScTinyLlmDataset valDataset = sc_tiny_llm_dataset_new();

    if (isPack)
    {
        // DOCS: --pack: поток токенов + окна ctx+1, train/val по книгам.
        if (filesCount < 2)
        {
            printf("error: --pack needs at least 2 corpus files for a book-level split\n");
            _lm_train_free_file_list(aFiles, filesCount);
            sc_tiny_llm_dataset_destroy(&valDataset);
            sc_tiny_llm_dataset_destroy(&trainDataset);
            sc_ai_bpe_destroy(&bpe);
            sc_log_deinit();
            return 1;
        }

        _lm_train_build_packed_datasets(aFiles, filesCount, bpe, modelConfig.ContextLength,
            &trainDataset, &valDataset, &corpusLength, &loadedCount);
        _lm_train_free_file_list(aFiles, filesCount);

        if (loadedCount <= 0)
        {
            printf("error: no corpus data\n");
            sc_tiny_llm_dataset_destroy(&valDataset);
            sc_tiny_llm_dataset_destroy(&trainDataset);
            sc_ai_bpe_destroy(&bpe);
            sc_log_deinit();
            return 1;
        }

        printf("corpus: %d/%d file(s), %.1f MiB total\n",
            loadedCount, filesCount, (f64)corpusLength / (1024.0 * 1024.0));
        printf("dataset: train=%d val=%d (packed: windows ctx+1, split by books)\n",
            (i32)trainDataset.Count, (i32)valDataset.Count);
    }
    else
    {
        char* pCorpus = NULL;
        if (filesCount > 0)
            pCorpus = _lm_train_load_corpus_files(aFiles, filesCount, &corpusLength, &loadedCount);
        _lm_train_free_file_list(aFiles, filesCount);

        if (!pCorpus)
        {
            printf("error: no corpus data\n");
            sc_tiny_llm_dataset_destroy(&valDataset);
            sc_tiny_llm_dataset_destroy(&trainDataset);
            sc_ai_bpe_destroy(&bpe);
            sc_log_deinit();
            return 1;
        }

        printf("corpus: %d/%d file(s), %.1f MiB total\n",
            loadedCount, filesCount, (f64)corpusLength / (1024.0 * 1024.0));

        _lm_train_build_datasets(pCorpus, corpusLength, bpe, &trainDataset, &valDataset);
        sc_string_destroy(pCorpus);

        printf("dataset: train=%d val=%d (every 10th line -> val)\n",
            (i32)trainDataset.Count, (i32)valDataset.Count);
    }

    if (trainDataset.Count < 2 || valDataset.Count < 1)
    {
        printf("error: not enough data: train=%d val=%d\n",
            (i32)trainDataset.Count, (i32)valDataset.Count);
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    // 5. Модель: пресет из ТЗ; словарь — из BPE.
    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    if (!pModel)
    {
        printf("error: failed to create model\n");
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    printf("model: %s layers=%d d_model=%d heads=%d d_ff=%d ctx=%d params=%d\n",
        pModelName, modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
        modelConfig.DFf, modelConfig.ContextLength,
        (i32)sc_tiny_llm_param_count(pModel));
    printf("cpu: backend=%s avx2=%d fma=%d\n",
        sc_tiny_llm_cpu_backend_name(), sc_tiny_llm_cpu_has_avx2(), sc_tiny_llm_cpu_has_fma());

    // 6. Обучение MS1: LossMask_None — чистое языковое моделирование.
    //    Лог: консоль (шаги + val), CSV-лог валидации, чекпоинты.
    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = steps;
    trainConfig.BatchSize = batch;
    trainConfig.LearningRate = lr;
    trainConfig.WarmupSteps = 40;
    trainConfig.LossMask = ScTinyLlmLossMask_None;
    trainConfig.LogEvery = LmTrainLogEvery;
    trainConfig.EvalEvery = LmTrainEvalEvery;
    trainConfig.EvalBatches = 32;
    trainConfig.Patience = patience;
    trainConfig.pCheckpointPath = (char*)pOutPath;
    trainConfig.CheckpointEvery = LmTrainCheckpointEvery;
    trainConfig.pValLogPath = (char*)pValLogPath;
    trainConfig.RestoreBest = 1;
    trainConfig.Seed = LmTrainSeed;

    printf("train: steps=%d batch=%d lr=%.4f patience=%d mask=none (prelude)\n",
        trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate,
        trainConfig.Patience);
    printf("train: checkpoint=%s val-log=%s\n", pOutPath, pValLogPath);

    // DOCS: полный снимок параметров запуска — в sc_log, чтобы его можно
    // было восстановить по логу (терминал, а при init_default — и sc.log).
    // NOTE: sc_log форматирует через sc_format (нет %lld/%x и точности),
    // поэтому строки собираем snprintf'ом, как в TinyLlm.c.
    {
        char logBuf[1024] = {};

        snprintf(logBuf, sizeof(logBuf), "lm-train: run: corpus-dir=%s bpe=%s\n",
            pDir, pBpePath);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: corpus: files=%d/%d bytes=%lld (%.2f MiB)\n",
            loadedCount, filesCount, (long long)corpusLength,
            (f64)corpusLength / (1024.0 * 1024.0));
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            isPack
                ? "lm-train: dataset: train=%lld val=%lld (packed windows ctx+1, split by books)\n"
                : "lm-train: dataset: train=%lld val=%lld (every 10th line -> val)\n",
            (long long)trainDataset.Count, (long long)valDataset.Count);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: model: preset=%s layers=%d d_model=%d heads=%d d_ff=%d ctx=%d vocab=%d params=%lld seed=0x%llx\n",
            pModelName, modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
            modelConfig.DFf, modelConfig.ContextLength, modelConfig.VocabCount,
            (long long)sc_tiny_llm_param_count(pModel), (unsigned long long)modelConfig.Seed);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: train: steps=%d batch=%d lr=%.5f weight-decay=%.5f warmup=%d grad-clip=%.2f mask=none\n",
            trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate,
            trainConfig.WeightDecay, trainConfig.WarmupSteps, trainConfig.GradClip);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: train: log-every=%d eval-every=%d eval-batches=%d patience=%d min-delta=%.5f restore-best=%d seed=0x%llx\n",
            trainConfig.LogEvery, trainConfig.EvalEvery, trainConfig.EvalBatches,
            trainConfig.Patience, trainConfig.MinDelta, (i32)trainConfig.RestoreBest,
            (unsigned long long)trainConfig.Seed);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: io: checkpoint=%s ckpt-every=%d val-log=%s\n",
            pOutPath, trainConfig.CheckpointEvery, pValLogPath);
        sc_log_info("%s", logBuf);
    }

    f32 before = sc_tiny_llm_eval(pModel, &valDataset, 32, ScTinyLlmLossMask_None, 1);
    sc_tiny_llm_train(pModel, bpe, &trainDataset, &valDataset, &trainConfig);
    f32 after = sc_tiny_llm_eval(pModel, &valDataset, 32, ScTinyLlmLossMask_None, 1);
    printf("train: val loss %.4f -> %.4f (ppl %.2f -> %.2f)\n",
        before, after, expf(before), expf(after));

    printf("done: checkpoint %s (weights + config + embedded BPE)\n", pOutPath);
    printf("      next: lm_chat %s\n", pOutPath);

    sc_tiny_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&valDataset);
    sc_tiny_llm_dataset_destroy(&trainDataset);
    sc_ai_bpe_destroy(&bpe);
    sc_log_deinit();

    printf("=== done ===\n");
    return 0;
}
