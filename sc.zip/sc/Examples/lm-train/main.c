/*
  lm_train — CLI-утилита, шаг 2 пайплайна MS1: обучение LM-прелюдии.

  Пайплайн MS1 разбит на три CLI-инструмента (см. Docs/todo-0.md):
    1. bpe_train — словарь BPE по директории с текстовыми файлами;
    2. lm_train  — обучение LM-прелюдии по BPE + корпусу (эта утилита);
    3. lm_chat   — интерактивная генерация по чекпоинту из консоли.

  Что делает эта утилита:
    1. загружает готовый BPE-словарь (файл от bpe_train, "# bpe v1");
    2. рекурсивно собирает все *.txt/*.text из входной директории
       и обрабатывает их по одному (без склейки всего корпуса в буфер);
    3. строит датасет прелюдии: каждая строка -> <BOS>строка<EOS>,
       БЕЗ полей разметки; при >= 10 файлах целые файлы (произведения)
       уходят в валидацию, иначе fallback — каждая 10-я строка;
    4. обучает decoder-only transformer с LossMask_None (loss по всем
       токенам — чистое языковое моделирование) с логированием в
       консоль и CSV-лог валидации;
    5. сохраняет чекпоинт (веса + config + встроенный BPE) — это вход
       для lm_chat и для MS2 (fine-tuning).

  Запуск из корня репозитория:
    masuka -b release -p windows -e lm_train -nr
    bin\release-windows\lm_train.exe <corpus-dir> --bpe <file.bpe> [options]

  Пример:
    bin\release-windows\lm_train.exe D:\books --bpe books.bpe --model micro

  Параметры:
    <corpus-dir>    обязательная директория с текстовыми файлами (рекурсивно);
    --bpe <path>    обязательный путь к .bpe от bpe_train;
    -o <path>       выходной чекпоинт (по умолчанию "lm.ckpt" в текущей папке);
    --model <name>  пресет: micro (2/64/2/256/ctx128), medium (4/128/4/512/ctx256),
                    target (6/256/8/1024/ctx512); по умолчанию micro;
    --steps <n>     шаги обучения (по умолчанию 1000);
    --batch <n>     batch size (по умолчанию 4);
    --lr <f>        learning rate (по умолчанию 0.003);
    --patience <n>  patience early stopping (по умолчанию 10);
    --val-log <p>   CSV-лог валидации (по умолчанию "lm_val.csv").

  NOTE: это ЭТАП 1 из двухэтапной схемы (Docs/todo-0.md, глава
  «ОЧЕНЬ ВАЖНО»): модель учит ЯЗЫК на обычном тексте. Роли (поля
  разметки, LossMask_Prompt) — это MS2, отдельный fine-tuning.
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LmTrainMaxDepth 8
#define LmTrainDefaultSteps 1000
#define LmTrainDefaultBatch 4
#define LmTrainDefaultLr 0.003f
#define LmTrainDefaultPatience 10
#define LmTrainDefaultOutput "lm.ckpt"
#define LmTrainDefaultValLog "lm_val.csv"
#define LmTrainLogEvery 50
#define LmTrainEvalEvery 200
#define LmTrainEvalBatches 256
#define LmTrainMinDelta 1e-3f
#define LmTrainCheckpointEvery 200
#define LmTrainWarmupMin 40
#define LmTrainWarmupMax 2000
#define LmTrainValFileMod 10
#define LmTrainSeed 0x5c0deULL

// DOCS: следующий аргумент как значение флага; NULL, если его нет.
static const char*
_lm_train_value(i32 argc, char** argv, i32* pIndex)
{
    if (*pIndex + 1 >= argc)
        return NULL;
    ++(*pIndex);
    return argv[*pIndex];
}

// DOCS: текстовый ли файл — по расширению (.txt/.text). Рекурсивный обход
// сам отсекает бинарные форматы по этому фильтру.
static i32
_lm_train_is_text_file(const char* pPath)
{
    i64 length = sc_string_get_length((char*)pPath);
    if (length < 4)
        return 0;

    // DOCS: сравниваем последние 4/5 символов без учёта регистра.
    const char* pTail = pPath + length - 4;
    if (pTail[0] == '.'
        && (pTail[1] == 't' || pTail[1] == 'T')
        && (pTail[2] == 'x' || pTail[2] == 'X')
        && (pTail[3] == 't' || pTail[3] == 'T'))
        return 1;

    if (length >= 5)
    {
        pTail = pPath + length - 5;
        if (pTail[0] == '.'
            && (pTail[1] == 't' || pTail[1] == 'T')
            && (pTail[2] == 'e' || pTail[2] == 'E')
            && (pTail[3] == 'x' || pTail[3] == 'X')
            && (pTail[4] == 't' || pTail[4] == 'T'))
            return 1;
    }

    return 0;
}

// DOCS: освобождение списка путей из _lm_train_collect_text_files.
// NOTE: sc_directory_get_* возвращают обычные аллокации (без
// ScString-заголовка) — освобождаем через sc_memory_free.
static void
_lm_train_free_file_list(char** aFiles, i32 FilesCount)
{
    for (i32 i = 0; i < FilesCount; ++i)
        sc_memory_free(aFiles[i]);
    sc_list_free(aFiles);
}

// DOCS: рекурсивный сбор текстовых файлов из директории (Sc):
// sc_directory_get_directories/sc_directory_get_files с абсолютными
// путями; в подпапки спускаемся до глубины maxDepth (защита от циклов
// из symlink'ов). Возвращает список путей (обычные аллокации —
// освобождать через _lm_train_free_file_list).
static char**
_lm_train_collect_text_files(const char* pDir, i32* pFilesCount, i32 maxDepth)
{
    char** aFiles = NULL;
    i32 count = 0;

    if (maxDepth <= 0)
        return NULL;

    // DOCS: файлы текущей директории (абсолютные пути).
    char** aLocalFiles = sc_directory_get_files(pDir, 1);
    for (i32 i = 0; aLocalFiles && i < (i32)sc_list_count(aLocalFiles); ++i)
    {
        if (_lm_train_is_text_file(aLocalFiles[i]))
        {
            sc_list_add(aFiles, aLocalFiles[i]);
            ++count;
        }
        else
        {
            sc_memory_free(aLocalFiles[i]);
        }
    }
    sc_list_free(aLocalFiles);

    // DOCS: подпапки — рекурсивно.
    char** aSubDirs = sc_directory_get_directories(pDir, 1);
    for (i32 i = 0; aSubDirs && i < (i32)sc_list_count(aSubDirs); ++i)
    {
        char** aSubFiles = _lm_train_collect_text_files(aSubDirs[i], NULL, maxDepth - 1);
        for (i32 s = 0; aSubFiles && s < (i32)sc_list_count(aSubFiles); ++s)
        {
            sc_list_add(aFiles, aSubFiles[s]);
            ++count;
        }
        sc_list_free(aSubFiles);
        sc_memory_free(aSubDirs[i]);
    }
    sc_list_free(aSubDirs);

    if (pFilesCount)
        *pFilesCount = count;
    return aFiles;
}

// DOCS: строка прогресса сборки датасета — в stdout через printf и в
// sc.log (тот же файл, куда пишет файловый бэкенд sc_log), чтобы прогресс
// оставался в логе после завершения утилиты.
static void
_lm_train_log_dataset_progress(i32 percent, i64 processed, i64 total, i64 lines)
{
    char buf[256] = {};
    i32 length = snprintf(buf, sizeof(buf),
        "dataset: %3d%% (%.2f/%.2f MiB, lines=%lld)\n",
        percent,
        (f64)processed / (1024.0 * 1024.0),
        (f64)total / (1024.0 * 1024.0),
        (long long)lines);
    if (length <= 0)
        return;

    if (length >= (i32)sizeof(buf))
        length = (i32)sizeof(buf) - 1;

    printf("%s", buf);
    sc_file_append_string_ext_r("sc.log", buf, (u64)length);
}

typedef struct
{
    ScAiBpe Bpe;
    ScTinyLlmDataset* pTrain;
    ScTinyLlmDataset* pVal;
    i32 UseFileSplit;
    i64 GlobalLine;
    i64 ProcessedBytes;
    i64 TotalBytes;
    i32 ProgressPercent;
    i64 ProgressNext;
    i64 Added;
    i64 TrainAdded;
    i64 ValAdded;
} LmTrainBuildState;

static i32
_lm_train_is_blank(const char* pText, i64 start, i64 end)
{
    for (i64 i = start; i < end; ++i)
    {
        if (pText[i] != ' ' && pText[i] != '\t')
            return 0;
    }
    return 1;
}

// DOCS: одна строка -> <BOS>...<EOS> (без промежуточной строки-обёртки).
// В file-split режиме вся файловая единица уходит в train или val; в
// fallback-режиме (мало файлов) — каждая 10-я строка.
static i32
_lm_train_add_line(LmTrainBuildState* pState, const char* pText, i64 start, i64 end,
    i32 isValFile)
{
    if (end <= start || pText[start] == '#')
        return 0;
    if (_lm_train_is_blank(pText, start, end))
        return 0;

    i64 lineStart = start;
    i64 lineEnd = end;
    if (lineEnd - lineStart >= 5 &&
        sc_string_compare_ext((char*)pText + lineEnd - 5, "<EOS>", 5))
        lineEnd -= 5;
    if (lineEnd - lineStart >= 5 &&
        sc_string_compare_ext((char*)pText + lineStart, "<BOS>", 5))
        lineStart += 5;
    if (lineEnd <= lineStart || _lm_train_is_blank(pText, lineStart, lineEnd))
        return 0;

    ScTinyLlmDataset* pTarget;
    if (pState->UseFileSplit)
        pTarget = isValFile ? pState->pVal : pState->pTrain;
    else
        pTarget = (pState->GlobalLine % 10 == 9) ? pState->pVal : pState->pTrain;
    ++pState->GlobalLine;

    if (!sc_tiny_llm_dataset_add_line(pTarget, pState->Bpe,
        pText + lineStart, lineEnd - lineStart))
        return 0;

    ++pState->Added;
    if (pTarget == pState->pVal)
        ++pState->ValAdded;
    else
        ++pState->TrainAdded;
    return 1;
}

// DOCS: читает один файл, режет на строки и добавляет в датасет. BOM
// срезается у каждого файла, а не только у первого. Пиковый размер
// памяти — один файл + датасет, без склейки всего корпуса в буфер.
static i32
_lm_train_process_file(LmTrainBuildState* pState, const char* pPath, i32 isValFile)
{
    i64 size = 0;
    char* pData = sc_file_read_ext_ext_r(pPath, &size);
    if (!pData)
    {
        printf("corpus: skip %s (unreadable)\n", pPath);
        return 0;
    }
    if (size <= 0)
    {
        sc_memory_free(pData);
        return 0;
    }

    i64 fileBase = pState->ProcessedBytes;
    i64 start = 0;
    if (size >= 3 && (u8)pData[0] == 0xEF && (u8)pData[1] == 0xBB && (u8)pData[2] == 0xBF)
        start = 3;

    for (i64 i = start; i <= size; ++i)
    {
        if (i == size || pData[i] == '\n')
        {
            i64 end = i;
            if (end > start && pData[end - 1] == '\r')
                --end;

            _lm_train_add_line(pState, pData, start, end, isValFile);
            start = i + 1;
        }

        if (pState->ProgressPercent > 0 && fileBase + i >= pState->ProgressNext)
        {
            _lm_train_log_dataset_progress(pState->ProgressPercent, fileBase + i,
                pState->TotalBytes, pState->Added);

            pState->ProgressPercent += 5;
            if (pState->ProgressPercent > 95)
                pState->ProgressPercent = 0; // 100% — отдельной строкой после цикла
            else
                pState->ProgressNext = (i64)((f64)pState->TotalBytes *
                    (f64)pState->ProgressPercent / 100.0);
        }
    }

    pState->ProcessedBytes = fileBase + size;
    sc_memory_free(pData);
    return 1;
}

static i32
_lm_train_parse_int(const char* pValue, i32* pOut)
{
    if (!pValue || !pOut)
        return 0;

    char* pEnd = NULL;
    long value = strtol(pValue, &pEnd, 10);
    if (pEnd == pValue || *pEnd != '\0')
        return 0;
    if (value < -2147483647L || value > 2147483647L)
        return 0;

    *pOut = (i32)value;
    return 1;
}

static i32
_lm_train_parse_f32(const char* pValue, f32* pOut)
{
    if (!pValue || !pOut)
        return 0;

    char* pEnd = NULL;
    double value = strtod(pValue, &pEnd);
    if (pEnd == pValue || *pEnd != '\0')
        return 0;

    *pOut = (f32)value;
    return 1;
}

static void
_lm_train_print_usage(void)
{
    printf("usage: lm_train <corpus-dir> --bpe <file.bpe> [options]\n");
    printf("  <corpus-dir>    directory with *.txt/*.text (recursive)\n");
    printf("  --bpe <path>    BPE file from bpe_train (required)\n");
    printf("  -o <path>       output checkpoint (default: %s)\n", LmTrainDefaultOutput);
    printf("  --model <name>  micro | medium | target (default: micro)\n");
    printf("  --steps <n>     train steps (default: %d)\n", LmTrainDefaultSteps);
    printf("  --batch <n>     batch size (default: %d)\n", LmTrainDefaultBatch);
    printf("  --lr <f>        learning rate (default: %.4f)\n", LmTrainDefaultLr);
    printf("  --warmup <n>    warmup steps (default: steps/50, %d..%d)\n",
        LmTrainWarmupMin, LmTrainWarmupMax);
    printf("  --patience <n>  early stopping patience (default: %d; 0 = off)\n", LmTrainDefaultPatience);
    printf("  --eval-every <n>     validation interval (default: %d)\n", LmTrainEvalEvery);
    printf("  --eval-batches <n>   validation windows (default: %d)\n", LmTrainEvalBatches);
    printf("  --min-delta <f>      min val improvement (default: %.4f)\n", LmTrainMinDelta);
    printf("  --val-log <p>   validation CSV log (default: %s)\n", LmTrainDefaultValLog);
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    sc_log_info("=== lm-train: MS1 language model prelude ===\n");

    // 1. Аргументы: строгий разбор, чтобы опечатка вроде --step не
    // превращалась в молчаливый дефолт на длинном прогоне.
    const char* pDir = NULL;
    const char* pBpePath = NULL;
    const char* pOutPath = LmTrainDefaultOutput;
    const char* pValLogPath = LmTrainDefaultValLog;
    const char* pModelName = "micro";
    i32 steps = LmTrainDefaultSteps;
    i32 batch = LmTrainDefaultBatch;
    f32 lr = LmTrainDefaultLr;
    i32 patience = LmTrainDefaultPatience;
    i32 warmup = -1;
    i32 evalEvery = LmTrainEvalEvery;
    i32 evalBatches = LmTrainEvalBatches;
    f32 minDelta = LmTrainMinDelta;

    i32 argError = 0;
    for (i32 i = 1; i < argc && !argError; ++i)
    {
        const char* pArg = argv[i];

        if (strcmp(pArg, "--help") == 0 || strcmp(pArg, "-h") == 0)
        {
            _lm_train_print_usage();
            return 0;
        }
        else if (strcmp(pArg, "--bpe") == 0)
        {
            pBpePath = _lm_train_value(argc, argv, &i);
            if (!pBpePath)
                argError = 1;
        }
        else if (strcmp(pArg, "-o") == 0)
        {
            pOutPath = _lm_train_value(argc, argv, &i);
            if (!pOutPath)
                argError = 1;
        }
        else if (strcmp(pArg, "--val-log") == 0)
        {
            pValLogPath = _lm_train_value(argc, argv, &i);
            if (!pValLogPath)
                argError = 1;
        }
        else if (strcmp(pArg, "--model") == 0)
        {
            pModelName = _lm_train_value(argc, argv, &i);
            if (!pModelName)
                argError = 1;
        }
        else if (strcmp(pArg, "--steps") == 0)
        {
            if (!_lm_train_parse_int(_lm_train_value(argc, argv, &i), &steps))
                argError = 1;
        }
        else if (strcmp(pArg, "--batch") == 0)
        {
            if (!_lm_train_parse_int(_lm_train_value(argc, argv, &i), &batch))
                argError = 1;
        }
        else if (strcmp(pArg, "--lr") == 0)
        {
            if (!_lm_train_parse_f32(_lm_train_value(argc, argv, &i), &lr))
                argError = 1;
        }
        else if (strcmp(pArg, "--patience") == 0)
        {
            if (!_lm_train_parse_int(_lm_train_value(argc, argv, &i), &patience))
                argError = 1;
        }
        else if (strcmp(pArg, "--warmup") == 0)
        {
            if (!_lm_train_parse_int(_lm_train_value(argc, argv, &i), &warmup))
                argError = 1;
        }
        else if (strcmp(pArg, "--eval-every") == 0)
        {
            if (!_lm_train_parse_int(_lm_train_value(argc, argv, &i), &evalEvery))
                argError = 1;
        }
        else if (strcmp(pArg, "--eval-batches") == 0)
        {
            if (!_lm_train_parse_int(_lm_train_value(argc, argv, &i), &evalBatches))
                argError = 1;
        }
        else if (strcmp(pArg, "--min-delta") == 0)
        {
            if (!_lm_train_parse_f32(_lm_train_value(argc, argv, &i), &minDelta))
                argError = 1;
        }
        else if (pArg[0] == '-')
        {
            printf("error: unknown option %s\n", pArg);
            argError = 2;
        }
        else if (!pDir)
        {
            pDir = pArg;
        }
        else
        {
            printf("error: unexpected argument %s\n", pArg);
            argError = 2;
        }

        if (argError == 1)
            printf("error: invalid or missing value for %s\n", pArg);
    }

    if (argError)
    {
        _lm_train_print_usage();
        return 1;
    }

    if (!pDir || !pBpePath)
    {
        _lm_train_print_usage();
        return 1;
    }

    if (steps <= 0 || batch <= 0 || patience < 0 || evalEvery <= 0 ||
        evalBatches <= 0 || lr <= 0.0f || minDelta < 0.0f || warmup < -1)
    {
        printf("error: invalid numeric option (steps/batch/eval must be > 0)\n");
        return 1;
    }

    if (warmup < 0)
    {
        warmup = steps / 50;
        if (warmup < LmTrainWarmupMin)
            warmup = LmTrainWarmupMin;
        if (warmup > LmTrainWarmupMax)
            warmup = LmTrainWarmupMax;
    }
    if (warmup > steps)
        warmup = steps;

    ScTinyLlmSize size = ScTinyLlmSize_Micro;
    if (strcmp(pModelName, "medium") == 0)
        size = ScTinyLlmSize_Medium;
    else if (strcmp(pModelName, "target") == 0)
        size = ScTinyLlmSize_Target;
    else if (strcmp(pModelName, "micro") != 0)
    {
        printf("error: unknown model '%s' (use micro | medium | target)\n", pModelName);
        return 1;
    }

    // DOCS: терминал + файл sc.log — параметры запуска и прогресс должны
    // оставаться в логе после завершения утилиты.
    ScLogBackend aLogBackends[2] = {
        sc_log_get_terminal_backend(),
        sc_log_get_file_backend(),
    };
    sc_log_init((ScLogConfig) {
        .BackendsCount = 2,
        .aBackends = aLogBackends,
    });

    // DOCS: параметры командной строки — сразу после разбора аргументов,
    // чтобы они попали в лог даже если BPE/корпус потом не загрузятся.
    {
        char logBuf[1024] = {};

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: args: corpus=%s bpe=%s out=%s val-log=%s\n",
            pDir, pBpePath, pOutPath, pValLogPath);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: args: model=%s steps=%d batch=%d lr=%.5f patience=%d\n",
            pModelName, steps, batch, lr, patience);
        sc_log_info("%s", logBuf);
    }

    // 2. BPE-словарь (от bpe_train).
    ScAiBpe bpe = sc_ai_bpe_load_from_disk((char*)pBpePath);
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: cannot load BPE from %s\n", pBpePath);
        sc_log_deinit();
        return 1;
    }
    printf("bpe: vocab=%d merges=%d\n",
        (i32)sc_list_count(bpe.aVocab), (i32)sc_list_count(bpe.aMerges));

    // 3. Корпус.
    if (sc_path((char*)pDir) != ScPathItemType_Directory)
    {
        printf("error: corpus dir %s not found\n", pDir);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    i32 filesCount = 0;
    char** aFiles = _lm_train_collect_text_files(pDir, &filesCount, LmTrainMaxDepth);
    printf("corpus: dir %s -> %d text file(s) (recursive)\n", pDir, filesCount);

    i64 totalBytes = 0;
    for (i32 i = 0; i < filesCount; ++i)
        totalBytes += (i64)sc_file_get_size((char*)aFiles[i]);

    printf("corpus: %d file(s), %.1f MiB total\n",
        filesCount, (f64)totalBytes / (1024.0 * 1024.0));

    // 4. Датасет прелюдии. При >= 10 файлах val — это целые файлы
    // (произведения), а не соседние строки из тех же текстов. Для
    // маленьких наборов остаётся fallback «каждая 10-я строка».
    ScTinyLlmDataset trainDataset = sc_tiny_llm_dataset_new();
    ScTinyLlmDataset valDataset = sc_tiny_llm_dataset_new();

    LmTrainBuildState buildState = {
        .Bpe = bpe,
        .pTrain = &trainDataset,
        .pVal = &valDataset,
        .UseFileSplit = filesCount >= LmTrainValFileMod ? 1 : 0,
        .TotalBytes = totalBytes,
    };
    if (totalBytes >= 20)
    {
        buildState.ProgressPercent = 5;
        buildState.ProgressNext = (i64)((f64)totalBytes * 0.05);
        if (buildState.ProgressNext < 1)
            buildState.ProgressNext = 1;
    }

    i32 loadedCount = 0;
    for (i32 i = 0; i < filesCount; ++i)
    {
        i32 isValFile = buildState.UseFileSplit &&
            ((i % LmTrainValFileMod) == (LmTrainValFileMod - 1));
        if (_lm_train_process_file(&buildState, aFiles[i], isValFile))
            ++loadedCount;
    }
    _lm_train_free_file_list(aFiles, filesCount);

    if (totalBytes > 0)
        _lm_train_log_dataset_progress(100, totalBytes, totalBytes, buildState.Added);

    i64 trainTokens = 0;
    i64 valTokens = 0;
    for (i64 i = 0; i < trainDataset.Count; ++i)
        trainTokens += trainDataset.aExamples[i].Count;
    for (i64 i = 0; i < valDataset.Count; ++i)
        valTokens += valDataset.aExamples[i].Count;

    printf("dataset: train=%lld val=%lld (%s split), tokens=%lld+%lld (%.1f MiB u32)\n",
        (long long)trainDataset.Count, (long long)valDataset.Count,
        buildState.UseFileSplit ? "file" : "line",
        (long long)trainTokens, (long long)valTokens,
        (f64)(trainTokens + valTokens) * 4.0 / (1024.0 * 1024.0));

    if (trainDataset.Count < 2 || valDataset.Count < 1)
    {
        printf("error: not enough data: train=%lld val=%lld (loaded %d files)\n",
            (long long)trainDataset.Count, (long long)valDataset.Count, loadedCount);
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    // 5. Модель: пресет из ТЗ; словарь — из BPE.
    ScTinyLlmModelConfig modelConfig =
        sc_tiny_llm_model_config_preset(size, (i32)sc_list_count(bpe.aVocab));
    modelConfig.Seed = LmTrainSeed;

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    if (!pModel)
    {
        printf("error: failed to create model\n");
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    printf("model: %s layers=%d d_model=%d heads=%d d_ff=%d ctx=%d params=%d\n",
        pModelName, modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
        modelConfig.DFf, modelConfig.ContextLength,
        (i32)sc_tiny_llm_param_count(pModel));

    // 6. Обучение MS1: LossMask_None — чистое языковое моделирование.
    //    Лог: консоль (шаги + val), CSV-лог валидации, чекпоинты.
    char bestPath[1024] = {};
    snprintf(bestPath, sizeof(bestPath), "%s.best", pOutPath);

    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = steps;
    trainConfig.BatchSize = batch;
    trainConfig.LearningRate = lr;
    trainConfig.WarmupSteps = warmup;
    trainConfig.LossMask = ScTinyLlmLossMask_None;
    trainConfig.LogEvery = LmTrainLogEvery;
    trainConfig.EvalEvery = evalEvery;
    trainConfig.EvalBatches = evalBatches;
    trainConfig.MinDelta = minDelta;
    trainConfig.Patience = patience;
    trainConfig.pCheckpointPath = (char*)pOutPath;
    trainConfig.CheckpointEvery = LmTrainCheckpointEvery;
    trainConfig.pBestCheckpointPath = bestPath;
    trainConfig.pValLogPath = (char*)pValLogPath;
    trainConfig.RestoreBest = 1;
    trainConfig.Seed = LmTrainSeed;

    printf("train: steps=%d batch=%d lr=%.4f warmup=%d patience=%d mask=none (prelude)\n",
        trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate,
        trainConfig.WarmupSteps, trainConfig.Patience);
    printf("train: eval every %d x %d windows; checkpoint=%s (best: %s)\n",
        trainConfig.EvalEvery, trainConfig.EvalBatches, pOutPath, bestPath);
    printf("train: val-log=%s\n", pValLogPath);

    // DOCS: полный снимок параметров запуска — в sc_log, чтобы его можно
    // было восстановить по логу (терминал, а при init_default — и sc.log).
    // NOTE: sc_log форматирует через sc_format (нет %lld/%x и точности),
    // поэтому строки собираем snprintf'ом, как в TinyLlm.c.
    {
        char logBuf[1024] = {};

        snprintf(logBuf, sizeof(logBuf), "lm-train: run: corpus-dir=%s bpe=%s\n",
            pDir, pBpePath);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: corpus: files=%d/%d bytes=%lld (%.2f MiB)\n",
            loadedCount, filesCount, (long long)totalBytes,
            (f64)totalBytes / (1024.0 * 1024.0));
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: dataset: train=%lld val=%lld (%s split) tokens=%lld+%lld (%.1f MiB u32)\n",
            (long long)trainDataset.Count, (long long)valDataset.Count,
            buildState.UseFileSplit ? "file" : "line",
            (long long)trainTokens, (long long)valTokens,
            (f64)(trainTokens + valTokens) * 4.0 / (1024.0 * 1024.0));
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: model: preset=%s layers=%d d_model=%d heads=%d d_ff=%d ctx=%d vocab=%d params=%lld seed=0x%llx\n",
            pModelName, modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
            modelConfig.DFf, modelConfig.ContextLength, modelConfig.VocabCount,
            (long long)sc_tiny_llm_param_count(pModel), (unsigned long long)modelConfig.Seed);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: train: steps=%d batch=%d lr=%.5f weight-decay=%.5f warmup=%d grad-clip=%.2f mask=none\n",
            trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate,
            trainConfig.WeightDecay, trainConfig.WarmupSteps, trainConfig.GradClip);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: train: log-every=%d eval-every=%d eval-batches=%d patience=%d min-delta=%.5f restore-best=%d seed=0x%llx\n",
            trainConfig.LogEvery, trainConfig.EvalEvery, trainConfig.EvalBatches,
            trainConfig.Patience, trainConfig.MinDelta, (i32)trainConfig.RestoreBest,
            (unsigned long long)trainConfig.Seed);
        sc_log_info("%s", logBuf);

        snprintf(logBuf, sizeof(logBuf),
            "lm-train: io: checkpoint=%s ckpt-every=%d best=%s val-log=%s\n",
            pOutPath, trainConfig.CheckpointEvery, bestPath, pValLogPath);
        sc_log_info("%s", logBuf);
    }

    f32 before = sc_tiny_llm_eval(pModel, &valDataset, trainConfig.EvalBatches,
        ScTinyLlmLossMask_None, trainConfig.Seed);
    i32 trainOk = sc_tiny_llm_train(pModel, bpe, &trainDataset, &valDataset, &trainConfig);
    f32 after = sc_tiny_llm_eval(pModel, &valDataset, trainConfig.EvalBatches,
        ScTinyLlmLossMask_None, trainConfig.Seed);

    if (isfinite((double)before) && isfinite((double)after))
    {
        printf("train: val loss %.4f -> %.4f (ppl %.2f -> %.2f)\n",
            before, after, expf(before), expf(after));
    }
    else
    {
        printf("train: val loss n/a (non-finite)\n");
    }

    u64 checkpointSize = sc_file_get_size((char*)pOutPath);
    if (!trainOk)
        printf("error: training failed (non-finite loss or no best weights)\n");
    if (checkpointSize > 0)
    {
        printf("done: checkpoint %s (%.1f MiB, weights + config + embedded BPE)\n",
            pOutPath, (f64)checkpointSize / (1024.0 * 1024.0));
        printf("      best: %s\n", bestPath);
        printf("      next: lm_chat %s\n", pOutPath);
    }
    else
    {
        printf("warning: checkpoint %s was not written\n", pOutPath);
    }

    sc_tiny_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&valDataset);
    sc_tiny_llm_dataset_destroy(&trainDataset);
    sc_ai_bpe_destroy(&bpe);
    sc_log_deinit();

    printf("=== %s ===\n", (trainOk && checkpointSize > 0) ? "done" : "failed");
    return (trainOk && checkpointSize > 0) ? 0 : 1;
}
