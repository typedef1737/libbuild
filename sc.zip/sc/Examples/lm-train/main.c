/*
  lm_train — CLI-утилита, шаг 2 пайплайна MS1: обучение LM-прелюдии.

  Пайплайн MS1 разбит на три CLI-инструмента (см. Docs/todo-0.md):
    1. bpe_train — словарь BPE по директории с текстовыми файлами;
    2. lm_train  — обучение LM-прелюдии по BPE + корпусу (эта утилита);
    3. lm_chat   — интерактивная генерация по чекпоинту из консоли.

  Что делает эта утилита:
    1. загружает готовый BPE-словарь (файл от bpe_train, "# bpe v1");
    2. рекурсивно собирает все *.txt/*.text из входной директории
       и склеивает в один большой буфер (на диске не склеивается);
    3. строит датасет прелюдии: каждая строка -> <BOS>строка<EOS>,
       БЕЗ полей разметки; каждая 10-я строка — валидация (held-out);
    4. обучает decoder-only transformer с LossMask_None (loss по всем
       токенам — чистое языковое моделирование) с логированием в
       консоль и CSV-лог валидации;
    5. сохраняет чекпоинт (веса + config + встроенный BPE) — это вход
       для lm_chat и для MS2 (fine-tuning).

  Запуск из корня репозитория:
    masuka -b release -p windows -e lm_train -nr
    bin\release-windows\lm_train.exe <corpus-dir> --bpe <file.bpe> [options]

  Пример:
    bin\release-windows\lm_train.exe D:\books --bpe books.bpe --model micro

  Параметры:
    <corpus-dir>    обязательная директория с текстовыми файлами (рекурсивно);
    --bpe <path>    обязательный путь к .bpe от bpe_train;
    -o <path>       выходной чекпоинт (по умолчанию "lm.ckpt" в текущей папке);
    --model <name>  пресет: micro (2/64/2/256/ctx128), medium (4/128/4/512/ctx256),
                    target (6/256/8/1024/ctx512); по умолчанию micro;
    --steps <n>     шаги обучения (по умолчанию 1000);
    --batch <n>     batch size (по умолчанию 4);
    --lr <f>        learning rate (по умолчанию 0.003);
    --patience <n>  patience early stopping (по умолчанию 10);
    --val-log <p>   CSV-лог валидации (по умолчанию "lm_val.csv").

  NOTE: это ЭТАП 1 из двухэтапной схемы (Docs/todo-0.md, глава
  «ОЧЕНЬ ВАЖНО»): модель учит ЯЗЫК на обычном тексте. Роли (поля
  разметки, LossMask_Prompt) — это MS2, отдельный fine-tuning.
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LmTrainMaxDepth 8
#define LmTrainDefaultSteps 1000
#define LmTrainDefaultBatch 4
#define LmTrainDefaultLr 0.003f
#define LmTrainDefaultPatience 10
#define LmTrainDefaultOutput "lm.ckpt"
#define LmTrainDefaultValLog "lm_val.csv"
#define LmTrainLogEvery 50
#define LmTrainEvalEvery 50
#define LmTrainCheckpointEvery 200
#define LmTrainSeed 0x5c0deULL

// DOCS: значение флага "-name value" / "--name value" из командной
// строки; если флага нет — pDefault. Ищет пары "флаг, следующий аргумент".
static const char*
_lm_train_flag(i32 argc, char** argv, const char* pName, const char* pDefault)
{
    for (i32 i = 1; i < argc - 1; ++i)
    {
        if (strcmp(argv[i], pName) == 0)
            return argv[i + 1];
    }
    return pDefault;
}

// DOCS: текстовый ли файл — по расширению (.txt/.text). Рекурсивный обход
// сам отсекает бинарные форматы по этому фильтру.
static i32
_lm_train_is_text_file(const char* pPath)
{
    i64 length = sc_string_get_length((char*)pPath);
    if (length < 4)
        return 0;

    // DOCS: сравниваем последние 4/5 символов без учёта регистра.
    const char* pTail = pPath + length - 4;
    if (pTail[0] == '.'
        && (pTail[1] == 't' || pTail[1] == 'T')
        && (pTail[2] == 'x' || pTail[2] == 'X')
        && (pTail[3] == 't' || pTail[3] == 'T'))
        return 1;

    if (length >= 5)
    {
        pTail = pPath + length - 5;
        if (pTail[0] == '.'
            && (pTail[1] == 't' || pTail[1] == 'T')
            && (pTail[2] == 'e' || pTail[2] == 'E')
            && (pTail[3] == 'x' || pTail[3] == 'X')
            && (pTail[4] == 't' || pTail[4] == 'T'))
            return 1;
    }

    return 0;
}

// DOCS: освобождение списка путей из _lm_train_collect_text_files.
// NOTE: sc_directory_get_* возвращают обычные аллокации (без
// ScString-заголовка) — освобождаем через sc_memory_free.
static void
_lm_train_free_file_list(char** aFiles, i32 FilesCount)
{
    for (i32 i = 0; i < FilesCount; ++i)
        sc_memory_free(aFiles[i]);
    sc_list_free(aFiles);
}

// DOCS: рекурсивный сбор текстовых файлов из директории (Sc):
// sc_directory_get_directories/sc_directory_get_files с абсолютными
// путями; в подпапки спускаемся до глубины maxDepth (защита от циклов
// из symlink'ов). Возвращает список путей (обычные аллокации —
// освобождать через _lm_train_free_file_list).
static char**
_lm_train_collect_text_files(const char* pDir, i32* pFilesCount, i32 maxDepth)
{
    char** aFiles = NULL;
    i32 count = 0;

    if (maxDepth <= 0)
        return NULL;

    // DOCS: файлы текущей директории (абсолютные пути).
    char** aLocalFiles = sc_directory_get_files(pDir, 1);
    for (i32 i = 0; aLocalFiles && i < (i32)sc_list_count(aLocalFiles); ++i)
    {
        if (_lm_train_is_text_file(aLocalFiles[i]))
        {
            sc_list_add(aFiles, aLocalFiles[i]);
            ++count;
        }
        else
        {
            sc_memory_free(aLocalFiles[i]);
        }
    }
    sc_list_free(aLocalFiles);

    // DOCS: подпапки — рекурсивно.
    char** aSubDirs = sc_directory_get_directories(pDir, 1);
    for (i32 i = 0; aSubDirs && i < (i32)sc_list_count(aSubDirs); ++i)
    {
        char** aSubFiles = _lm_train_collect_text_files(aSubDirs[i], NULL, maxDepth - 1);
        for (i32 s = 0; aSubFiles && s < (i32)sc_list_count(aSubFiles); ++s)
        {
            sc_list_add(aFiles, aSubFiles[s]);
            ++count;
        }
        sc_list_free(aSubFiles);
        sc_memory_free(aSubDirs[i]);
    }
    sc_list_free(aSubDirs);

    if (pFilesCount)
        *pFilesCount = count;
    return aFiles;
}

// DOCS: загрузка НЕСКОЛЬКИХ файлов корпуса (сотни рассказов — без склейки
// в один большой файл на диске): каждый файл из aFiles читается в память
// и приклеивается в общий builder с "\n" между файлами. Возвращает NULL,
// если не удалось прочитать ни один файл.
static char*
_lm_train_load_corpus_files(char** aFiles, i32 FilesCount, i64* pLength, i32* pFileCount)
{
    char* pBuilder = sc_builder_new();
    i32 loaded = 0;

    for (i32 p = 0; p < FilesCount; ++p)
    {
        i64 size = 0;
        char* pData = sc_file_read_ext_ext_r(aFiles[p], &size);
        if (!pData || size <= 0)
        {
            printf("corpus: skip %s (unreadable)\n", aFiles[p]);
            continue;
        }

        if (loaded > 0)
            sc_builder_append_string(pBuilder, "\n", 1);

        sc_builder_append_string(pBuilder, pData, size);
        // NOTE: sc_file_read_ext_ext_r возвращает обычную аллокацию
        // (не ScString) — освобождаем через sc_memory_free.
        sc_memory_free(pData);
        ++loaded;
    }

    if (loaded <= 0)
    {
        sc_builder_destroy(pBuilder);
        return NULL;
    }

    i64 length = sc_builder_count(pBuilder);
    char* pCorpus = sc_string_new_ext_ext_r(pBuilder, length, length);
    sc_builder_destroy(pBuilder);

    if (pLength)
        *pLength = length;
    if (pFileCount)
        *pFileCount = loaded;
    return pCorpus;
}

// DOCS: датасет прелюдии из буфера корпуса: каждая строка ->
// <BOS>строка<EOS>, БЕЗ полей разметки; каждая 10-я строка (added % 10
// == 9) — в валидацию (held-out). Пропускаются пустые строки, строки с
// '#' в начале и комментарии-заголовки; CRLF/BOM допустимы; уже
// размеченные <BOS>/<EOS> не задваиваются.
static void
_lm_train_build_datasets(const char* pText, i64 size, ScAiBpe bpe,
    ScTinyLlmDataset* pTrain, ScTinyLlmDataset* pVal)
{
    i64 start = 0;
    i64 i = 0;

    // DOCS: пропускаем UTF-8 BOM, если данные начинались с него.
    if (size >= 3 && (u8)pText[0] == 0xEF && (u8)pText[1] == 0xBB && (u8)pText[2] == 0xBF)
    {
        start = 3;
        i = 3;
    }

    i64 added = 0;
    while (i <= size)
    {
        if (i == size || pText[i] == '\n')
        {
            i64 end = i;
            if (end > start && pText[end - 1] == '\r')
                --end;

            if (end > start && pText[start] != '#')
            {
                // DOCS: если строка уже размечена <BOS>/<EOS> —
                // срезаем маркеры, чтобы не задваивать их.
                i64 lineStart = start;
                i64 lineEnd = end;
                if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineEnd - 5, "<EOS>", 5))
                    lineEnd -= 5;
                if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineStart, "<BOS>", 5))
                    lineStart += 5;

                char* pBuilder = sc_builder_new();
                sc_builder_append_string(pBuilder, "<BOS>", 5);
                sc_builder_append_string(pBuilder, pText + lineStart, lineEnd - lineStart);
                sc_builder_append_string(pBuilder, "<EOS>", 5);

                i64 lineLength = sc_builder_count(pBuilder);
                char* pLine = sc_string_new_ext_ext_r(pBuilder, lineLength, lineLength);
                sc_builder_destroy(pBuilder);

                if (added % 10 == 9)
                    sc_tiny_llm_dataset_add(pVal, bpe, pLine);
                else
                    sc_tiny_llm_dataset_add(pTrain, bpe, pLine);

                sc_string_destroy(pLine);
                ++added;
            }

            start = i + 1;
        }
        ++i;
    }
}

static void
_lm_train_print_usage(void)
{
    printf("usage: lm_train <corpus-dir> --bpe <file.bpe> [options]\n");
    printf("  <corpus-dir>    directory with *.txt/*.text (recursive)\n");
    printf("  --bpe <path>    BPE file from bpe_train (required)\n");
    printf("  -o <path>       output checkpoint (default: %s)\n", LmTrainDefaultOutput);
    printf("  --model <name>  micro | medium | target (default: micro)\n");
    printf("  --steps <n>     train steps (default: %d)\n", LmTrainDefaultSteps);
    printf("  --batch <n>     batch size (default: %d)\n", LmTrainDefaultBatch);
    printf("  --lr <f>        learning rate (default: %.4f)\n", LmTrainDefaultLr);
    printf("  --patience <n>  early stopping patience (default: %d)\n", LmTrainDefaultPatience);
    printf("  --val-log <p>   validation CSV log (default: %s)\n", LmTrainDefaultValLog);
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("=== lm-train: MS1 language model prelude ===\n");

    // 1. Аргументы.
    const char* pDir = NULL;
    for (i32 i = 1; i < argc; ++i)
    {
        if (argv[i][0] != '-')
        {
            pDir = argv[i];
            break;
        }
    }
    const char* pBpePath = _lm_train_flag(argc, argv, "--bpe", NULL);

    if (!pDir || !pBpePath)
    {
        _lm_train_print_usage();
        return 1;
    }

    const char* pOutPath = _lm_train_flag(argc, argv, "-o", LmTrainDefaultOutput);
    const char* pValLogPath = _lm_train_flag(argc, argv, "--val-log", LmTrainDefaultValLog);
    const char* pModelName = _lm_train_flag(argc, argv, "--model", "micro");
    i32 steps = atoi(_lm_train_flag(argc, argv, "--steps", "1000"));
    i32 batch = atoi(_lm_train_flag(argc, argv, "--batch", "4"));
    f32 lr = (f32)atof(_lm_train_flag(argc, argv, "--lr", "0.003"));
    i32 patience = atoi(_lm_train_flag(argc, argv, "--patience", "10"));
    if (steps <= 0)
        steps = LmTrainDefaultSteps;
    if (batch <= 0)
        batch = LmTrainDefaultBatch;
    if (lr <= 0.0f)
        lr = LmTrainDefaultLr;
    if (patience <= 0)
        patience = LmTrainDefaultPatience;

    ScTinyLlmSize size = ScTinyLlmSize_Micro;
    if (strcmp(pModelName, "medium") == 0)
        size = ScTinyLlmSize_Medium;
    else if (strcmp(pModelName, "target") == 0)
        size = ScTinyLlmSize_Target;
    else if (strcmp(pModelName, "micro") != 0)
    {
        printf("error: unknown model '%s' (use micro | medium | target)\n", pModelName);
        return 1;
    }

    ScLogBackend backend = sc_log_get_terminal_backend();
    sc_log_init((ScLogConfig) {
        .BackendsCount = 1,
        .aBackends = &backend,
    });

    // 2. BPE-словарь (от bpe_train).
    ScAiBpe bpe = sc_ai_bpe_load_from_disk((char*)pBpePath);
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: cannot load BPE from %s\n", pBpePath);
        sc_log_deinit();
        return 1;
    }
    printf("bpe: vocab=%d merges=%d\n",
        (i32)sc_list_count(bpe.aVocab), (i32)sc_list_count(bpe.aMerges));

    // 3. Корпус.
    if (sc_path((char*)pDir) != ScPathItemType_Directory)
    {
        printf("error: corpus dir %s not found\n", pDir);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    i32 filesCount = 0;
    char** aFiles = _lm_train_collect_text_files(pDir, &filesCount, LmTrainMaxDepth);
    printf("corpus: dir %s -> %d text file(s) (recursive)\n", pDir, filesCount);

    i64 corpusLength = 0;
    i32 loadedCount = 0;
    char* pCorpus = NULL;
    if (filesCount > 0)
        pCorpus = _lm_train_load_corpus_files(aFiles, filesCount, &corpusLength, &loadedCount);
    _lm_train_free_file_list(aFiles, filesCount);

    if (!pCorpus)
    {
        printf("error: no corpus data\n");
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }
    printf("corpus: %d/%d file(s), %.1f MiB total\n",
        loadedCount, filesCount, (f64)corpusLength / (1024.0 * 1024.0));

    // 4. Датасет прелюдии: <BOS>строка<EOS>, каждая 10-я строка -> val.
    ScTinyLlmDataset trainDataset = sc_tiny_llm_dataset_new();
    ScTinyLlmDataset valDataset = sc_tiny_llm_dataset_new();
    _lm_train_build_datasets(pCorpus, corpusLength, bpe, &trainDataset, &valDataset);
    sc_string_destroy(pCorpus);

    printf("dataset: train=%d val=%d (every 10th line -> val)\n",
        (i32)trainDataset.Count, (i32)valDataset.Count);

    if (trainDataset.Count < 2 || valDataset.Count < 1)
    {
        printf("error: not enough data: train=%d val=%d\n",
            (i32)trainDataset.Count, (i32)valDataset.Count);
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    // 5. Модель: пресет из ТЗ; словарь — из BPE.
    ScTinyLlmModelConfig modelConfig =
        sc_tiny_llm_model_config_preset(size, (i32)sc_list_count(bpe.aVocab));
    modelConfig.Seed = LmTrainSeed;

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    if (!pModel)
    {
        printf("error: failed to create model\n");
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&bpe);
        sc_log_deinit();
        return 1;
    }

    printf("model: %s layers=%d d_model=%d heads=%d d_ff=%d ctx=%d params=%d\n",
        pModelName, modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
        modelConfig.DFf, modelConfig.ContextLength,
        (i32)sc_tiny_llm_param_count(pModel));

    // 6. Обучение MS1: LossMask_None — чистое языковое моделирование.
    //    Лог: консоль (шаги + val), CSV-лог валидации, чекпоинты.
    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = steps;
    trainConfig.BatchSize = batch;
    trainConfig.LearningRate = lr;
    trainConfig.WarmupSteps = 40;
    trainConfig.LossMask = ScTinyLlmLossMask_None;
    trainConfig.LogEvery = LmTrainLogEvery;
    trainConfig.EvalEvery = LmTrainEvalEvery;
    trainConfig.EvalBatches = 32;
    trainConfig.Patience = patience;
    trainConfig.pCheckpointPath = (char*)pOutPath;
    trainConfig.CheckpointEvery = LmTrainCheckpointEvery;
    trainConfig.pValLogPath = (char*)pValLogPath;
    trainConfig.RestoreBest = 1;
    trainConfig.Seed = LmTrainSeed;

    printf("train: steps=%d batch=%d lr=%.4f patience=%d mask=none (prelude)\n",
        trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate,
        trainConfig.Patience);
    printf("train: checkpoint=%s val-log=%s\n", pOutPath, pValLogPath);

    f32 before = sc_tiny_llm_eval(pModel, &valDataset, 32, ScTinyLlmLossMask_None, 1);
    sc_tiny_llm_train(pModel, bpe, &trainDataset, &valDataset, &trainConfig);
    f32 after = sc_tiny_llm_eval(pModel, &valDataset, 32, ScTinyLlmLossMask_None, 1);
    printf("train: val loss %.4f -> %.4f (ppl %.2f -> %.2f)\n",
        before, after, expf(before), expf(after));

    printf("done: checkpoint %s (weights + config + embedded BPE)\n", pOutPath);
    printf("      next: lm_chat %s\n", pOutPath);

    sc_tiny_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&valDataset);
    sc_tiny_llm_dataset_destroy(&trainDataset);
    sc_ai_bpe_destroy(&bpe);
    sc_log_deinit();

    printf("=== done ===\n");
    return 0;
}
