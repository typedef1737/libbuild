# lm-train — обучение LM-прелюдии (шаг 2 пайплайна MS1)

CLI-утилита: берёт готовый BPE-словарь (от `bpe-train`) и директорию с
текстовыми файлами (рекурсивно, склейка в один буфер в памяти), строит
датасет прелюдии и обучает decoder-only transformer с `LossMask_None`
— чистое языковое моделирование, этап 1 из двухэтапной схемы
(`Docs/todo-0.md`, глава «ОЧЕНЬ ВАЖНО»).

Результат — чекпоинт (веса + config + встроенный BPE): вход для
`lm-chat` и для MS2 (fine-tuning с `LossMask_Prompt`).

Пайплайн MS1: `bpe-train` → `lm-train` → `lm-chat`.

## Запуск

```bash
masuka -b release -p windows -e lm_train -nr
bin\release-windows\lm_train.exe <corpus-dir> --bpe <file.bpe> [options]
```

На Linux (или из git-bash) — одним скриптом (сборка + запуск):

```bash
bash Examples/lm-train/run_lm_train.sh <corpus-dir> --bpe <file.bpe> [options]
```

Перед первым использованием: `chmod +x Examples/lm-train/run_lm_train.sh`.
Скрипт сам находит корень репозитория, собирает release под текущую
платформу (linux/windows) и запускает утилиту с пробросом аргументов.

Пример:

```powershell
bin\release-windows\lm_train.exe D:\books --bpe books.bpe --model medium --steps 4000
```

## Параметры

| Параметр | По умолчанию | Описание |
|---|---|---|
| `<corpus-dir>` | — (обязательный) | директория с `*.txt`/`*.text`, обход рекурсивный |
| `--bpe <path>` | — (обязательный) | файл словаря от `bpe-train` |
| `-o <path>` | `lm.ckpt` | выходной чекпоинт |
| `--model <name>` | `micro` | пресет: `micro` / `medium` / `target` |
| `--steps <n>` | `1000` | шаги обучения |
| `--batch <n>` | `4` | batch size |
| `--lr <f>` | `0.003` | learning rate |
| `--patience <n>` | `10` | early stopping patience |
| `--val-log <p>` | `lm_val.csv` | CSV-лог валидации |

## Датасет

Каждая строка корпуса → `<BOS>строка<EOS>`, без полей разметки.
Пропускаются пустые строки и строки с `#` в начале; каждая 10-я строка —
валидация (held-out). Формат файлов: UTF-8, одна фраза/реплика на строку
(прозу с прямой речью сначала прогоните через извлечение реплик —
см. `Docs/todo-0.md`, раздел MS1 «данные»).

## Логирование

- консоль: шаги каждые 50 (`step N/M loss … lr … grad …`), валидация
  каждые 50 (`val step N loss … ppl …`), события early stop / чекпоинтов;
- `lm_val.csv` (перезаписываемый append): `step,val_loss,val_ppl` —
  кривая обучения;
- чекпоинт: каждые 200 шагов + лучший по val (RestoreBest).

## Пресеты и время (CPU, 1 поток, release, V=8k)

| Модель | Конфиг (слои/d/головы/d_ff/ctx) | Данные | Время |
|---|---|---:|---:|
| micro | 2/64/2/256/128 | 5M токенов | ~0.5–1 ч (smoke-тест) |
| medium | 4/128/4/512/256 | 5–15M | 4–12 ч («за ночь») |
| target | 6/256/8/1024/512 | 10–30M | 1.5–4 сут |

Стратегия: сначала micro на всём корпусе — если val PPL не падает или
генерация каша, проблема в данных. Затем medium за ночь с RestoreBest
(лучший чекпоинт гарантирован утром).
