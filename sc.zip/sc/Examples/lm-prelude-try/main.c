/*
  lm_prelude_try — демонстрация MS1: обучение LM-прелюдии.

  Это этап 1 из двухэтапной схемы (см. Docs/todo-0.md, глава ОЧЕНЬ ВАЖНО):
    MS1: модель учится ЯЗЫКУ на обычном тексте (LossMask_None);
    MS2: модель учит РОЛИ на структурированных примерах (LossMask_Prompt).

  Пайплайн демо:
    1. корпус разговорной русской речи — ТОЛЬКО внешние текстовые файлы:
         - БЕЗ аргументов: захардкоженная директория LmPreludeCorpusDir
           ("corpus" рядом с исходником) — рекурсивный сбор всех
           *.txt/*.text через Sc (sc_directory_get_files/directories);
         - "--list files.txt": текстовый файл со списком путей;
         - file1 file2 ...: прямые пути аргументами;
         Нет данных -> демка завершается с ошибкой (return 1);
    2. byte-level BPE (sc_ai_bpe_new_fast) + сохранение # bpe v1;
    3. датасет прелюдии: каждая строка оборачивается <BOS>...<EOS>,
       разметки полей НЕТ — это чистое языковое моделирование;
    4. обучение с LossMask_None (loss по всем токенам);
    5. генерация — чистое продолжение текста (AppendSep = 0):
       модель продолжает фразу и останавливается на <EOS>;
    6. чекпоинт — это и есть вход для MS2 (fine-tuning).

  Запуск из корня репозитория:
    masuka -b release -p windows -e lm_prelude_try -nr
    bin\release-windows\lm_prelude_try.exe            # директория corpus/
    bin\release-windows\lm_prelude_try.exe --list files.txt
    bin\release-windows\lm_prelude_try.exe a.txt b.txt
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

#define LmPreludeBpeMerges 256
#define LmPreludeContextLength 128
#define LmPreludeDModel 64
#define LmPreludeHeads 2
#define LmPreludeDFf 128
#define LmPreludeLayers 2
#define LmPreludeTrainSteps 800
#define LmPreludeBatchSize 4
#define LmPreludeLearningRate 0.003f
#define LmPreludeLogEvery 50
#define LmPreludeEvalEvery 50
#define LmPreludeCheckpointEvery 200

// DOCS: захардкоженная директория корпуса для режима по умолчанию.
// Рекурсивно собираются все *.txt/*.text из этой папки и подпапок.
// Пути — с прямыми слэшами (Sc работает на обеих платформах, Windows
// их принимает).
#define LmPreludeCorpusDir "corpus"

/*
  Время обучения MS1 на CPU (1 поток, release, V=8k, ориентиры):
    Micro  (2/64/2/256):   ~0.5-1 ч    на 5M токенов   <- цель этого демо
    Medium (4/128/4/512):  ~4-12 ч     на 5-15M токенов
    Base   (6/256/8/1024): ~1.5-4 сут  на 10-30M токенов
  Стратегия: Micro на всём корпусе (smoke-тест данных) -> Medium за ночь.
*/

// DOCS: промпты для генерации после обучения: начала типовых фраз.
// Модель должна продолжить их по-русски и остановиться на <EOS>.
static const char* aLmPreludePrompts[] = {
    "Далеко за рекой",
    "Дождь начался",
    "— Подскажите, как пройти",
    "Утро выдалось ясное",
    "Ветер шумел в верхушках",
};

static const i64 cLmPreludePromptCount = (i64)(sizeof(aLmPreludePrompts) / sizeof(aLmPreludePrompts[0]));

static char*
_lm_prelude_path_near_source(const char* pName)
{
    char* pDir = sc_path_get_directory(__FILE__);
    if (!pDir)
        return sc_string_copy((char*)pName, sc_string_get_length((char*)pName));

    char* pPath = sc_path_combine(pDir, (char*)pName);
    sc_memory_free(pDir);
    return pPath;
}

// DOCS: загрузка НЕСКОЛЬКИХ файлов корпуса (сотни рассказов — без
// склейки в один большой файл на диске): каждый файл из aFiles читается
// в память и приклеивается в общий builder с "\n" между файлами.
// Возвращает NULL, если не удалось прочитать ни один файл.
static char*
_lm_prelude_load_corpus_files(char** aFiles, i32 FilesCount, i64* pLength, i32* pFileCount)
{
    char* pBuilder = sc_builder_new();
    i32 loaded = 0;

    for (i32 p = 0; p < FilesCount; ++p)
    {
        i64 size = 0;
        char* pData = sc_file_read_ext_ext_r(aFiles[p], &size);
        if (!pData || size <= 0)
        {
            printf("corpus: skip %s (unreadable)\n", aFiles[p]);
            continue;
        }

        if (loaded > 0)
            sc_builder_append_string(pBuilder, "\n", 1);

        sc_builder_append_string(pBuilder, pData, size);
        // NOTE: sc_file_read_ext_ext_r возвращает обычную аллокацию
        // (не ScString) — освобождаем через sc_memory_free.
        sc_memory_free(pData);
        ++loaded;
    }

    if (loaded <= 0)
    {
        sc_builder_destroy(pBuilder);
        return NULL;
    }

    i64 length = sc_builder_count(pBuilder);
    char* pCorpus = sc_string_new_ext_ext_r(pBuilder, length, length);
    sc_builder_destroy(pBuilder);

    if (pLength)
        *pLength = length;
    if (pFileCount)
        *pFileCount = loaded;
    return pCorpus;
}

// DOCS: чтение файла-списка путей: aFiles/FilesCount. Формат: UTF-8,
// один путь к файлу корпуса на строку; пустые строки и строки с '#' в
// начале пропускаются; CRLF/BOM допустимы. Возвращает число прочитанных
// путей (0 при ошибке); *paFiles — список строк (обычные аллокации —
// освобождать через _lm_prelude_free_file_list).
static i32
_lm_prelude_read_file_list(const char* pListPath, char*** paFiles, i32* pFilesCount)
{
    if (!pListPath || !paFiles || !pFilesCount)
        return 0;

    i64 size = 0;
    char* pData = sc_file_read_ext_ext_r((char*)pListPath, &size);
    if (!pData || size <= 0)
    {
        printf("corpus: cannot read file list %s\n", pListPath);
        return 0;
    }

    char** aFiles = NULL;
    i32 count = 0;

    i64 start = 0;
    i64 i = 0;

    // DOCS: пропускаем UTF-8 BOM.
    if (size >= 3 && (u8)pData[0] == 0xEF && (u8)pData[1] == 0xBB && (u8)pData[2] == 0xBF)
    {
        start = 3;
        i = 3;
    }

    while (i <= size)
    {
        if (i == size || pData[i] == '\n')
        {
            i64 end = i;
            if (end > start && pData[end - 1] == '\r')
                --end;

            if (end > start && pData[start] != '#')
            {
                // DOCS: срезаем пробелы по краям пути.
                while (end > start && (pData[end - 1] == ' ' || pData[end - 1] == '\t'))
                    --end;
                while (start < end && (pData[start] == ' ' || pData[start] == '\t'))
                    ++start;

                if (end > start)
                {
                    char* pPath = sc_string_copy(pData + start, end - start);
                    sc_list_add(aFiles, pPath);
                    ++count;
                }
            }

            start = i + 1;
        }
        ++i;
    }

    sc_memory_free(pData);

    *paFiles = aFiles;
    *pFilesCount = count;
    return count;
}

// DOCS: освобождение списка путей из _lm_prelude_read_file_list и
// _lm_prelude_collect_text_files.
// NOTE: sc_string_copy/sc_directory_get_* возвращают обычные аллокации
// (без ScString-заголовка) — освобождаем через sc_memory_free.
static void
_lm_prelude_free_file_list(char** aFiles, i32 FilesCount)
{
    for (i32 i = 0; i < FilesCount; ++i)
        sc_memory_free(aFiles[i]);
    sc_list_free(aFiles);
}

// DOCS: текстовый ли файл — по расширению (.txt/.text). Рекурсивный
// обход сам отсекает бинарные форматы по этому фильтру.
static i32
_lm_prelude_is_text_file(const char* pPath)
{
    i64 length = sc_string_get_length((char*)pPath);
    if (length < 4)
        return 0;

    // DOCS: сравниваем последние 4/5 символов без учёта регистра.
    const char* pTail = pPath + length - 4;
    if (pTail[0] == '.'
        && (pTail[1] == 't' || pTail[1] == 'T')
        && (pTail[2] == 'x' || pTail[2] == 'X')
        && (pTail[3] == 't' || pTail[3] == 'T'))
        return 1;

    if (length >= 5)
    {
        pTail = pPath + length - 5;
        if (pTail[0] == '.'
            && (pTail[1] == 't' || pTail[1] == 'T')
            && (pTail[2] == 'e' || pTail[2] == 'E')
            && (pTail[3] == 'x' || pTail[3] == 'X')
            && (pTail[4] == 't' || pTail[4] == 'T'))
            return 1;
    }

    return 0;
}

// DOCS: рекурсивный сбор текстовых файлов из директории (Sc):
// sc_directory_get_directories/sc_directory_get_files с абсолютными
// путями; в подпапки спускаемся до глубины maxDepth (защита от циклов
// из symlink'ов). Возвращает список путей (обычные аллокации —
// освобождать через _lm_prelude_free_file_list).
static char**
_lm_prelude_collect_text_files(const char* pDir, i32* pFilesCount, i32 maxDepth)
{
    char** aFiles = NULL;
    i32 count = 0;

    if (maxDepth <= 0)
        return NULL;

    // DOCS: файлы текущей директории (абсолютные пути).
    char** aLocalFiles = sc_directory_get_files(pDir, 1);
    for (i32 i = 0; aLocalFiles && i < (i32)sc_list_count(aLocalFiles); ++i)
    {
        if (_lm_prelude_is_text_file(aLocalFiles[i]))
        {
            sc_list_add(aFiles, aLocalFiles[i]);
            ++count;
        }
        else
        {
            sc_memory_free(aLocalFiles[i]);
        }
    }
    sc_list_free(aLocalFiles);

    // DOCS: подпапки — рекурсивно.
    char** aSubDirs = sc_directory_get_directories(pDir, 1);
    for (i32 i = 0; aSubDirs && i < (i32)sc_list_count(aSubDirs); ++i)
    {
        char** aSubFiles = _lm_prelude_collect_text_files(aSubDirs[i], NULL, maxDepth - 1);
        for (i32 s = 0; aSubFiles && s < (i32)sc_list_count(aSubFiles); ++s)
        {
            sc_list_add(aFiles, aSubFiles[s]);
            ++count;
        }
        sc_list_free(aSubFiles);
        sc_memory_free(aSubDirs[i]);
    }
    sc_list_free(aSubDirs);

    if (pFilesCount)
        *pFilesCount = count;
    return aFiles;
}

static void
_lm_prelude_print_bpe_info(ScAiBpe bpe)
{
    printf("bpe: vocab=%d merges=%d\n",
        (i32)sc_list_count(bpe.aVocab),
        (i32)sc_list_count(bpe.aMerges));
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("=== lm-prelude-try: MS1 language model prelude ===\n");

    // 1. Корпус — ТОЛЬКО внешние текстовые файлы. Режимы (по приоритету):
    //    a) без аргументов — захардкоженная директория
    //       LmPreludeCorpusDir (рекурсивный сбор *.txt/*.text через Sc);
    //    б) --list files.txt — текстовый файл со списком путей
    //       (один путь на строку; нет лимита командной строки);
    //    в) file1.txt file2.txt ... — прямые пути аргументами;
    //    Нет данных -> return 1 (без синтетического fallback).
    i64 corpusLength = 0;
    char* pCorpus = NULL;
    char** aFiles = NULL;
    i32 filesCount = 0;
    i32 filesOwned = 0;

    if (argc > 2 && strcmp(argv[1], "--list") == 0)
    {
        filesCount = _lm_prelude_read_file_list(argv[2], &aFiles, &filesCount);
        filesOwned = 1;
        printf("corpus: file list %s -> %d path(s)\n", argv[2], filesCount);
    }
    else if (argc > 1)
    {
        aFiles = argv + 1;
        filesCount = argc - 1;
    }
    else
    {
        // DOCS: режим по умолчанию — директория из кода.
        char* pCorpusDir = _lm_prelude_path_near_source(LmPreludeCorpusDir);
        if (sc_path(pCorpusDir) == ScPathItemType_Directory)
        {
            aFiles = _lm_prelude_collect_text_files(pCorpusDir, &filesCount, 8);
            filesOwned = 1;
            printf("corpus: dir %s -> %d text file(s) (recursive)\n",
                pCorpusDir, filesCount);
        }
        else
        {
            printf("error: corpus dir %s not found\n", pCorpusDir);
        }
        sc_memory_free(pCorpusDir);
    }

    if (filesCount > 0)
    {
        i32 loadedCount = 0;
        pCorpus = _lm_prelude_load_corpus_files(aFiles, filesCount, &corpusLength, &loadedCount);
        if (pCorpus)
            printf("corpus: %d/%d file(s), %d bytes total\n",
                loadedCount, filesCount, (i32)corpusLength);
    }

    if (filesOwned)
        _lm_prelude_free_file_list(aFiles, filesCount);

    if (!pCorpus)
    {
        printf("error: no corpus data\n");
        printf("  put *.txt/*.text into Examples/lm-prelude-try/%s/ (recursive),\n"
               "  or run with --list <file>, or pass files as arguments\n",
            LmPreludeCorpusDir);
        return 1;
    }

    // 2. BPE: fast-тренер.
    ScAiBpe bpe = sc_ai_bpe_new_fast((ScAiBpeConfig) {
        .pText = pCorpus,
        .TextLength = corpusLength,
        .MergesCount = LmPreludeBpeMerges,
    });
    _lm_prelude_print_bpe_info(bpe);

    // DOCS: терминальный лог включаем после шумного обучения BPE.
    ScLogBackend backend = sc_log_get_terminal_backend();
    sc_log_init((ScLogConfig) {
        .BackendsCount = 1,
        .aBackends = &backend,
    });

    char* pBpePath = _lm_prelude_path_near_source("lm_prelude.bpe");
    char* pCheckpointPath = _lm_prelude_path_near_source("lm_prelude.ckpt");
    char* pValLogPath = _lm_prelude_path_near_source("lm_prelude_val.csv");

    sc_ai_bpe_save_to_disk((ScAiBpeSaveToDiskConfig) {
        .Bpe = bpe,
        .pFilePath = pBpePath,
        .TotalTextLength = corpusLength,
        .TotalTextLengthCompressed = (i64)sc_list_count(bpe.aTokens),
        .pText = pCorpus,
        .ShouldAddText = 0,
        .ShouldAddTokens = 0,
    });
    printf("bpe: saved to %s\n", pBpePath);

    ScAiBpe loadedBpe = sc_ai_bpe_load_from_disk(pBpePath);
    _lm_prelude_print_bpe_info(loadedBpe);
    printf("bpe: round-trip -> %s\n",
        sc_list_count(loadedBpe.aVocab) == sc_list_count(bpe.aVocab) ? "ok" : "FAILED");

    // 3. Датасет прелюдии: <BOS>строка<EOS>, БЕЗ полей разметки.
    //    Корпус режем по строкам; каждая строка -> <BOS>line<EOS>.
    ScTinyLlmDataset trainDataset = sc_tiny_llm_dataset_new();
    ScTinyLlmDataset valDataset = sc_tiny_llm_dataset_new();

    {
        i64 start = 0;
        i64 i = 0;
        char* pText = pCorpus;
        i64 size = corpusLength;

        // DOCS: пропускаем UTF-8 BOM, если данные начинались с него.
        if (size >= 3 && (u8)pText[0] == 0xEF && (u8)pText[1] == 0xBB && (u8)pText[2] == 0xBF)
        {
            start = 3;
            i = 3;
        }

        i64 added = 0;
        while (i <= size)
        {
            if (i == size || pText[i] == '\n')
            {
                i64 end = i;
                if (end > start && pText[end - 1] == '\r')
                    --end;

                if (end > start && pText[start] != '#')
                {
                    // DOCS: если строка уже размечена <BOS>/<EOS> —
                    // срезаем маркеры, чтобы не задваивать их.
                    i64 lineStart = start;
                    i64 lineEnd = end;
                    if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineEnd - 5, "<EOS>", 5))
                        lineEnd -= 5;
                    if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineStart, "<BOS>", 5))
                        lineStart += 5;

                    char* pBuilder = sc_builder_new();
                    sc_builder_append_string(pBuilder, "<BOS>", 5);
                    sc_builder_append_string(pBuilder, pText + lineStart, lineEnd - lineStart);
                    sc_builder_append_string(pBuilder, "<EOS>", 5);

                    i64 lineLength = sc_builder_count(pBuilder);
                    char* pLine = sc_string_new_ext_ext_r(pBuilder, lineLength, lineLength);
                    sc_builder_destroy(pBuilder);

                    // DOCS: каждая 10-я строка — валидация (held-out).
                    if (added % 10 == 9)
                        sc_tiny_llm_dataset_add(&valDataset, bpe, pLine);
                    else
                        sc_tiny_llm_dataset_add(&trainDataset, bpe, pLine);

                    sc_string_destroy(pLine);
                    ++added;
                }

                start = i + 1;
            }
            ++i;
        }
        printf("dataset: train=%d val=%d (every 10th line -> val)\n",
            (i32)trainDataset.Count, (i32)valDataset.Count);
    }

    if (trainDataset.Count < 2 || valDataset.Count < 1)
    {
        printf("error: not enough data: train=%d val=%d\n",
            (i32)trainDataset.Count, (i32)valDataset.Count);
        sc_tiny_llm_dataset_destroy(&valDataset);
        sc_tiny_llm_dataset_destroy(&trainDataset);
        sc_ai_bpe_destroy(&loadedBpe);
        sc_ai_bpe_destroy(&bpe);
        sc_string_destroy(pCorpus);
        sc_memory_free(pBpePath);
        sc_memory_free(pCheckpointPath);
        sc_memory_free(pValLogPath);
        sc_log_deinit();
        return 1;
    }

    // 4. Модель: параметры из defines вверху файла (все применяются;
    //    значения соответствуют micro-пресету).
    ScTinyLlmModelConfig modelConfig = sc_tiny_llm_model_config_default((i32)sc_list_count(bpe.aVocab));
    modelConfig.NumLayers = LmPreludeLayers;
    modelConfig.DModel = LmPreludeDModel;
    modelConfig.NumHeads = LmPreludeHeads;
    modelConfig.DFf = LmPreludeDFf;
    modelConfig.ContextLength = LmPreludeContextLength;
    modelConfig.Seed = 0x5c0deULL;

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    if (!pModel)
    {
        printf("error: failed to create model\n");
        return 1;
    }

    printf("model: layers=%d d_model=%d heads=%d d_ff=%d ctx=%d params=%d\n",
        modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
        modelConfig.DFf, modelConfig.ContextLength,
        (i32)sc_tiny_llm_param_count(pModel));

    // 5. Обучение MS1: LossMask_None — языковое моделирование на всех
    //    позициях. Это и есть "прелюдия": модель учит язык, а не роль.
    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = LmPreludeTrainSteps;
    trainConfig.BatchSize = LmPreludeBatchSize;
    trainConfig.LearningRate = LmPreludeLearningRate;
    trainConfig.WarmupSteps = 40;
    trainConfig.LossMask = ScTinyLlmLossMask_None;
    trainConfig.LogEvery = LmPreludeLogEvery;
    trainConfig.EvalEvery = LmPreludeEvalEvery;
    trainConfig.EvalBatches = 32;
    trainConfig.Patience = 10;
    trainConfig.pCheckpointPath = pCheckpointPath;
    trainConfig.CheckpointEvery = LmPreludeCheckpointEvery;
    // DOCS: CSV-лог валидации: step,val_loss,val_ppl — кривая обучения
    // для анализа (демо пишет его рядом с исходником).
    trainConfig.pValLogPath = pValLogPath;
    trainConfig.RestoreBest = 1;
    trainConfig.Seed = 0x5c0deULL;

    printf("train: steps=%d batch=%d lr=%.4f mask=none (prelude)\n",
        trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate);

    f32 before = sc_tiny_llm_eval(pModel, &valDataset, 32, ScTinyLlmLossMask_None, 1);
    sc_tiny_llm_train(pModel, bpe, &trainDataset, &valDataset, &trainConfig);
    f32 after = sc_tiny_llm_eval(pModel, &valDataset, 32, ScTinyLlmLossMask_None, 1);
    printf("train: val loss %.4f -> %.4f (ppl %.2f -> %.2f)\n",
        before, after, expf(before), expf(after));

    // 6. Генерация: ЧИСТОЕ продолжение текста (AppendSep = 0).
    //    Модель продолжает фразу и останавливается на <EOS>.
    ScTinyLlmGenerateConfig generateConfig = sc_tiny_llm_generate_config_default();
    generateConfig.MaxTokens = 40;
    generateConfig.Temperature = 0.0f;
    generateConfig.TopK = 1;
    generateConfig.AppendSep = 0;

    printf("\n--- generation (prelude model, text continuation) ---\n");
    for (i64 i = 0; i < cLmPreludePromptCount; ++i)
    {
        char* pAnswer = sc_tiny_llm_generate(pModel, loadedBpe, aLmPreludePrompts[i], &generateConfig);
        printf("prompt: %s\n", aLmPreludePrompts[i]);
        printf("continuation: %s\n\n", pAnswer);
        sc_string_destroy(pAnswer);
    }

    // 7. Чекпоинт: reload и воспроизведение. Этот же чекпоинт — вход
    //    для MS2 (fine-tuning): load_checkpoint -> train с LossMask_Prompt.
    printf("--- checkpoint reload (this is the MS2 input) ---\n");
    ScAiBpe checkpointBpe = {};
    ScTinyLlmModel* pLoaded = sc_tiny_llm_load_checkpoint(pCheckpointPath, &checkpointBpe);
    if (pLoaded && sc_list_count(checkpointBpe.aVocab) > 0)
    {
        char* pAnswer = sc_tiny_llm_generate(pLoaded, checkpointBpe,
            aLmPreludePrompts[0], &generateConfig);
        printf("checkpoint continuation: %s\n", pAnswer);
        sc_string_destroy(pAnswer);
        sc_tiny_llm_destroy(pLoaded);
        sc_ai_bpe_destroy(&checkpointBpe);
    }
    else
    {
        printf("checkpoint reload: FAILED\n");
    }

    sc_tiny_llm_destroy(pModel);
    sc_ai_bpe_destroy(&loadedBpe);
    sc_ai_bpe_destroy(&bpe);
    sc_tiny_llm_dataset_destroy(&valDataset);
    sc_tiny_llm_dataset_destroy(&trainDataset);
    sc_string_destroy(pCorpus);
    sc_memory_free(pBpePath);
    sc_memory_free(pCheckpointPath);
    sc_memory_free(pValLogPath);
    sc_log_deinit();

    printf("=== done ===\n");
    return 0;
}
