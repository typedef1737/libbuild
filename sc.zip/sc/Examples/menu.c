/*
  DOCS: Пример главного меню на ScUi (Sc/Gfx/Ui.h) + бэкенде
  ScRasterBackend (Sc/Gfx/UiBackends/RasterBackend.h) поверх
  программного растера ScRaster. Окно (Linux: xcb, Windows: WIN32/GDI)
  блитит готовый кадр бэкенда.

  Что демонстрируется:
    - создание главного меню: "Продолжить", "Играть", "Настройки",
      "Выход";
    - виджет-кнопка = прямоугольник с текстовой подписью-ребёнком,
      hover/click-подсветка через ScUiColor;
    - выбор пункта мышью (клик ловится по ScUiState_Clicked) и
      клавиатурой (стрелки вверх/вниз, Enter, Esc);
    - все события окна приходят в callback sc_window_set_event_call,
      пользователь раскладывает их в ScUiInput через
      sc_ui_backend_get_input();
    - текст на русском: шрифт грузится с диапазоном Unicode
      ASCII + кириллица (sc_raster_backend_load_font_ext).

  Выход: пункт "Выход", Esc или закрытие окна.
*/
#include <Sc/Gfx/Ui.h>
#include <Sc/Gfx/UiBackends/RasterBackend.h>
#include <Sc/Gfx/Window.h>
#include <Sc/Math.h>
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>

/* DOCS: Индексы пунктов меню = порядок кнопок на экране. */
typedef enum
{
    MenuAction_Continue = 0,
    MenuAction_Play,
    MenuAction_Settings,
    MenuAction_Exit,
    MenuAction_Count
} MenuAction;

/*
  DOCS: Диапазон атласа шрифта: ASCII (32..126) + кириллица
  (U+0400..U+045F). Один непрерывный диапазон, потому что DrawText
  бэкенда выбирает шрифт только по размеру, без fallback по глифам.
*/
#define MenuFontRangeMin 32
#define MenuFontRangeMax 0x045F

/* DOCS: Подписи пунктов (UTF-8) и ASCII-имена для логов/виджетов. */
static const char* aMenuLabels[MenuAction_Count] = {
    "Продолжить",
    "Играть",
    "Настройки",
    "Выход",
};

static const char* aMenuWidgetNames[MenuAction_Count] = {
    "MenuButtonContinue",
    "MenuButtonPlay",
    "MenuButtonSettings",
    "MenuButtonExit",
};

/* DOCS: имена подписей-детей: уникальны, иначе хеш совпадёт с кнопкой. */
static const char* aMenuLabelNames[MenuAction_Count] = {
    "MenuLabelContinue",
    "MenuLabelPlay",
    "MenuLabelSettings",
    "MenuLabelExit",
};

static const char* aMenuLogNames[MenuAction_Count] = {
    "continue",
    "play",
    "settings",
    "exit",
};

/* DOCS: Окно нужно в callback-е, чтобы закрыть его из пункта "Выход". */
static ScWindow* g_pMenuWindow = ScNull;

/* DOCS: Выбранный клавиатурой пункт (подсвечивается) и строка статуса. */
static i32 g_MenuSelected = MenuAction_Continue;
static const char* g_pMenuStatus = "Выберите пункт меню";

static i32 g_TitleFontSize = 24;
static i32 g_ItemFontSize = 24;

/*
  DOCS: ScKey окна -> ScUiKey. ScUiKey знает только клавиши навигации и
  редактирования; остальные (Enter, Escape, буквы) остаются в
  пользовательском коде - меню обрабатывает их само.
*/
static ScUiKey
menu_ui_key_from_window_key(ScKey key)
{
    switch (key)
    {
    case ScKey_Tab:
        return ScUiKey_Tab;
    case ScKey_Backspace:
        return ScUiKey_Backspace;
    case ScKey_Left:
        return ScUiKey_LeftArrow;
    case ScKey_Right:
        return ScUiKey_RightArrow;
    case ScKey_Up:
        return ScUiKey_UpArrow;
    case ScKey_Down:
        return ScUiKey_DownArrow;
    case ScKey_Home:
        return ScUiKey_Home;
    case ScKey_End:
        return ScUiKey_End;
    case ScKey_Delete:
        return ScUiKey_Delete;
    default:
        return ScUiKey_Undefined;
    }
}

/* DOCS: ScMouseKey окна -> ScUiKey (только три основные кнопки). */
static ScUiKey
menu_ui_key_from_mouse_key(ScMouseKey key)
{
    switch (key)
    {
    case ScMouseKey_Left:
        return ScUiKey_Mouse_Left_Button;
    case ScMouseKey_Right:
        return ScUiKey_Mouse_Right_Button;
    case ScMouseKey_Middle:
        return ScUiKey_Mouse_Middle_Button;
    default:
        return ScUiKey_Undefined;
    }
}

/*
  DOCS: Кладёт состояние клавиши в ScUiInput. IsHandled сбрасываем:
  новый ввод снимает "уже обработано" с прошлого кадра.
*/
static void
menu_set_key(ScUiInput* pInput, ScUiKey key, ScUiKeyState state)
{
    if (key == ScUiKey_Undefined)
        return;

    pInput->aKeys[key].State = state;
    pInput->aKeys[key].IsHandled = 0;
}

/*
  DOCS: Отпускает зажатые клавиши: окно потеряло фокус или мышь ушла за
  его пределы, и события Release уже не придут.
*/
static void
menu_release_all_keys(ScUiInput* pInput, i32 releaseMouseOnly)
{
    for (i32 k = 0; k < ScUiKey_Count; ++k)
    {
        i32 isMouseKey = (k == ScUiKey_Mouse_Left_Button
                          || k == ScUiKey_Mouse_Right_Button
                          || k == ScUiKey_Mouse_Middle_Button);
        if (releaseMouseOnly && !isMouseKey)
            continue;

        if (pInput->aKeys[k].State == ScUiKeyState_Pressed)
        {
            pInput->aKeys[k].State = ScUiKeyState_Released;
            pInput->aKeys[k].IsHandled = 0;
        }
    }
}

/*
  DOCS: Действие выбранного пункта. "Выход" закрывает окно, остальные
  пункты для примера пишут статус в меню (здесь подключается реальная
  логика игры/настроек).
*/
static void
menu_activate(i32 action)
{
    if (action < 0 || action >= MenuAction_Count)
        return;

    if (action == MenuAction_Exit)
    {
        g_pMenuStatus = "Выход...";
        if (g_pMenuWindow != ScNull)
            g_pMenuWindow->IsAlive = 0;
    }
    else if (action == MenuAction_Continue)
    {
        g_pMenuStatus = "Продолжаем игру...";
    }
    else if (action == MenuAction_Play)
    {
        g_pMenuStatus = "Запускаем новую игру...";
    }
    else if (action == MenuAction_Settings)
    {
        g_pMenuStatus = "Настройки: раздел в разработке";
    }

    /* лог ASCII-именем: консоль Windows не всегда UTF-8 */
    printf("[menu] %s\n", aMenuLogNames[action]);
}

/*
  DOCS: Прокидывает события окна в ScUiInput (мышь/клавиши для виджетов)
  и обрабатывает клавиатуру меню. Вызывается окном из
  sc_window_set_event_call. Состояния клавиш ui снимает сам
  sc_ui_process_input (Released -> None).
*/
static void
menu_on_event(ScEvent* pEvent)
{
    ScUiInput* pInput = sc_ui_backend_get_input();
    if (pInput == ScNull)
        return;

    switch (pEvent->Type)
    {
    case ScEventType_MouseMove:
    {
        ScMouseMoveEvent* pMouse = (ScMouseMoveEvent*)pEvent;
        /* окно уже отдаёт MouseMove в Y-вверх (origin - левый низ) */
        pInput->MousePosition = v2_new((f32)pMouse->X, (f32)pMouse->Y);
        break;
    }
    case ScEventType_MousePress:
    {
        ScMousePressEvent* pMouse = (ScMousePressEvent*)pEvent;
        menu_set_key(pInput, menu_ui_key_from_mouse_key(pMouse->Key), ScUiKeyState_Pressed);
        break;
    }
    case ScEventType_MouseRelease:
    {
        ScMouseReleaseEvent* pMouse = (ScMouseReleaseEvent*)pEvent;
        menu_set_key(pInput, menu_ui_key_from_mouse_key(pMouse->Key), ScUiKeyState_Released);
        break;
    }
    case ScEventType_KeyPress:
    {
        ScKeyPressEvent* pKey = (ScKeyPressEvent*)pEvent;
        menu_set_key(pInput, menu_ui_key_from_window_key(pKey->Key), ScUiKeyState_Pressed);

        /* навигация меню: стрелки/Enter/Escape (в ScUiKey их нет) */
        switch (pKey->Key)
        {
        case ScKey_Up:
            g_MenuSelected = (g_MenuSelected + MenuAction_Count - 1) % MenuAction_Count;
            break;
        case ScKey_Down:
            g_MenuSelected = (g_MenuSelected + 1) % MenuAction_Count;
            break;
        case ScKey_Enter:
            menu_activate(g_MenuSelected);
            break;
        case ScKey_Escape:
            if (g_pMenuWindow != ScNull)
                g_pMenuWindow->IsAlive = 0;
            break;
        default:
            break;
        }
        break;
    }
    case ScEventType_KeyRelease:
    {
        ScKeyReleaseEvent* pKey = (ScKeyReleaseEvent*)pEvent;
        menu_set_key(pInput, menu_ui_key_from_window_key(pKey->Key), ScUiKeyState_Released);
        break;
    }
    case ScEventType_MouseScroll:
    {
        /* NOTE: у ScUiInput нет поля прокрутки. Колесо (ScMouseScrollEvent)
           можно использовать для смены выбранного пункта в своей логике. */
        break;
    }
    case ScEventType_KeyType:
    {
        /* NOTE: у ScUiInput нет текстового ввода: Codepoint из
           ScKeyTypeEvent.CodePoint обрабатывается в пользовательском коде. */
        break;
    }
    case ScEventType_KeyboardMapping:
        break;
    case ScEventType_WindowResized:
        /* размер ui получает в sc_raster_backend_update(DisplaySize) */
        break;
    case ScEventType_WindowEnter:
    {
        ScWindowEnterEvent* pEnter = (ScWindowEnterEvent*)pEvent;
        if (!pEnter->IsInside)
            menu_release_all_keys(pInput, 1);
        break;
    }
    case ScEventType_WindowFocused:
    {
        ScWindowFocusedEvent* pFocus = (ScWindowFocusedEvent*)pEvent;
        if (!pFocus->Focused)
            menu_release_all_keys(pInput, 0);
        break;
    }
    case ScEventType_WindowClosed:
        if (g_pMenuWindow != ScNull)
            g_pMenuWindow->IsAlive = 0;
        break;
    case ScEventType_WindowMoved:
    case ScEventType_WindowMaximized:
    case ScEventType_WindowHidden:
        break;
    case ScEventType_None:
    default:
        break;
    }
}

/*
  DOCS: Ищет первый доступный ttf (в workspace нет Resources/Fonts,
  поэтому есть системные варианты) и грузит его с диапазоном
  ASCII + кириллица. Возвращает ScInvalidId, если шрифтов нет.
*/
static i64
menu_load_font(i32 fontSize)
{
    static const char* aFontCandidates[] = {
        "Resources/Fonts/MartianMono-sWdRg.ttf",
        "C:/Windows/Fonts/consola.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/TTF/DejaVuSans.ttf",
    };

    for (i32 f = 0; f < ScArrayCount(aFontCandidates); ++f)
    {
        /* sc_font_new на отсутствующем файле уходит в sc_guard */
        if (sc_file_get_size((char*)aFontCandidates[f]) == 0)
            continue;

        i64 fontId = sc_raster_backend_load_font_ext(
            (char*)aFontCandidates[f],
            fontSize,
            MenuFontRangeMin,
            MenuFontRangeMax);
        if (fontId != ScInvalidId)
        {
            printf("Font %dpx: %s\n", fontSize, aFontCandidates[f]);
            return fontId;
        }
    }

    return ScInvalidId;
}

/* DOCS: Одна кнопка меню: прямоугольник + центрированная подпись-ребёнок. */
static void
menu_button(i32 action)
{
    /*
      DOCS: Выбранный клавиатурой пункт подсвечиваем через Idle: state
      виджета (hover/clicked) приходит только от мыши.
    */
    i32 isSelected = (action == g_MenuSelected);
    v4 idle = isSelected ? v4_rgb(56, 82, 132) : v4_rgb(44, 54, 72);

    ScUiState state = sc_ui_widget_begin({ .pName = (char*)aMenuWidgetNames[action],
        .Type = ScUiWidgetType_Rectangle,
        .Flag = ScUiFlag_Alive,
        .Color = {
            .Idle = idle,
            .Hovered = v4_rgb(62, 92, 150),
            .Clicked = v4_rgb(36, 60, 108),
        },
        .Size = { .Width = Grow(1), .Height = Fixed(56) },
        .Layout = {
            .Direction = ScUiDirection_Vertical,
        } });

    if (state == ScUiState_Clicked)
    {
        g_MenuSelected = action;
        menu_activate(action);
    }

    sc_ui_text({ .pName = (char*)aMenuLabelNames[action],
        .pText = (char*)aMenuLabels[action],
        .FontSize = (i16)g_ItemFontSize,
        .Color = { .Idle = v4_rgb(228, 233, 242) },

        .Horizontal = ScUiTextAlign_X_Right,
        .Vertical = ScUiTextAlign_Y_Bot
        });

    sc_ui_widget_end();
}

i32
main()
{
    /* I/O Not Buffered: логи сразу уходят в консоль */
    setvbuf(stdout, NULL, _IONBF, 0);

    ScWindowConfig conf = {
        .pName = "Sc Ui Menu",
        .NameLength = 10,
        .UseGraphics = 1, /* окно + растер (blit готового кадра) */
        .Size = { .Width = 800, .Height = 600 },
        .MinSize = { .Width = 320, .Height = 240 },
        /* MaxSize: буферы растера аллоцируются сразу на него */
        .MaxSize = { .Width = 1600, .Height = 1200 },
        /* {0,0} = центр экрана */
        .Position = { .X = 0, .Y = 0 },
    };

    ScWindow window = {};
    sc_window_create(&window, conf);
    if (!window.IsAlive)
    {
        printf("Window creation failed!\n");
        return 1;
    }

    /* DOCS: бэкенд ui поверх программного растера */
    sc_raster_backend_new();
    ScRaster* pUiRaster = sc_raster_backend_get_raster();
    if (pUiRaster == ScNull)
    {
        printf("Raster backend creation failed!\n");
        sc_window_destroy(&window);
        return 1;
    }

    g_pMenuWindow = &window;
    sc_window_set_event_call(&window, menu_on_event);

    /*
      DOCS: Шрифты: заголовок крупнее пунктов. Диапазон - ASCII +
      кириллица, иначе русские подписи не нарисуются.
    */
    i64 titleFontId = menu_load_font(32);
    i64 itemFontId = menu_load_font(24);

    if (itemFontId == ScInvalidId && titleFontId != ScInvalidId)
    {
        itemFontId = titleFontId;
        g_ItemFontSize = 32;
    }
    if (titleFontId == ScInvalidId && itemFontId != ScInvalidId)
    {
        titleFontId = itemFontId;
        g_TitleFontSize = 24;
    }

    if (itemFontId == ScInvalidId)
        printf("Font: not found, text disabled\n");

    printf("Main menu. Click / Up-Down / Enter, Esc to exit.\n");

    while (window.IsAlive)
    {
        sc_window_update(&window);

        /* размер окна -> ui (layout: Fit/Grow считают от DisplaySize) */
        i32 width = to_i32(window.Size.Width);
        i32 height = to_i32(window.Size.Height);
        sc_raster_backend_update((ScUiBackendState) {
            .DisplaySize = v2_new((f32)width, (f32)height),
        });

        /*
          DOCS: Кадр ui: begin -> виджеты -> layout -> input -> render
          -> frame_end. Сначала заливаем фон: бэкенд не чистит буфер.
        */
        ScRaster* pRaster = sc_raster_backend_get_raster();
        sc_raster_clear_color(pRaster, 0xFF10141A);

        sc_ui_frame_begin();
        {
            /*
              DOCS: Панель меню в центре. Ui - Y-вверх, Position.Y = ВЕРХ
              панели, поэтому top = DisplayHeight / 2 + PanelHeight / 2.
            */
            const f32 panelW = 460.0f;
            const f32 panelH = 400.0f;
            f32 panelX = (f32)width / 2 - panelW / 2;
            f32 panelY = (f32)height / 2 + panelH / 2;
            sc_ui_widget_begin({
                .pName = "MenuPanel",
                .Type = ScUiWidgetType_Rectangle,
                .Flag = ScUiFlag_Alive,
                .Color = {
                    .Idle = v4_rgb(24, 30, 40),
                    .Hovered = v4_rgb(24, 30, 40),
                    .Clicked = v4_rgb(24, 30, 40),
                },
                .Size = { .Width = Fixed(panelW), .Height = Fixed(panelH) },
                .Position = { .X = Fixed(panelX), .Y = Fixed(panelY) },
                .Layout = {
                    .Direction = ScUiDirection_Vertical,
                    .Padding = ScUiPadAll(24),
                    .ChildGap = 12,
                },
            });

            sc_ui_text({
                .pName = "MenuTitle",
                .pText = "Главное меню",
                .FontSize = (i16)g_TitleFontSize,
                .Horizontal = ScUiTextAlign_X_Center,
                .Color = { .Idle = v4_rgb(240, 242, 248) },
            });

            /* DOCS: пункты в порядке из задания */
            for (i32 action = 0; action < MenuAction_Count; ++action)
                menu_button(action);

            sc_ui_text({
                .pName = "MenuStatus",
                .pText = (char*)g_pMenuStatus,
                .FontSize = (i16)g_ItemFontSize,
                .Horizontal = ScUiTextAlign_X_Center,
                .Color = { .Idle = v4_rgb(150, 162, 180) },
            });

            /* корень закрывается последним */
            sc_ui_widget_end();
        }

        sc_ui_layout();

        /* input обрабатывается после layout-а: у виджетов уже есть позы */
        sc_ui_process_input();

        sc_raster_backend_render();

        sc_ui_frame_end();

        /* DOCS: бэкенд рисует в свой растер, окно блитит свой -
           копируем кадр ui в растер окна и показываем. */
        ScRaster* pWindowRaster = sc_window_get_raster(&window);
        if (pWindowRaster != ScNull)
        {
            ScRasterBuffer uiBuffer = sc_raster_get_buffer(pUiRaster);
            ScRasterBuffer windowBuffer = sc_raster_get_buffer(pWindowRaster);

            if (uiBuffer.pData != ScNull && windowBuffer.pData != ScNull
                && uiBuffer.Width == windowBuffer.Width
                && uiBuffer.Height == windowBuffer.Height)
            {
                sc_copy(windowBuffer.pData, uiBuffer.pData, (u64)uiBuffer.Width * uiBuffer.Height * 4);
            }
        }

        sc_window_graphics_swap_buffers(&window);
    }

    sc_raster_backend_free();
    sc_window_destroy(&window);
    printf("Bye!\n");
    return 0;
}
