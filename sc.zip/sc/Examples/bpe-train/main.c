/*
  bpe_train — CLI-утилита, шаг 1 пайплайна MS1: обучение BPE-словаря.

  Пайплайн MS1 разбит на три CLI-инструмента (см. Docs/todo-0.md):
    1. bpe_train — словарь BPE по директории с текстовыми файлами (эта утилита);
    2. lm_train  — обучение LM-прелюдии (LossMask_None) по BPE + корпусу;
    3. lm_chat   — интерактивная генерация по чекпоинту из консоли.

  Что делает эта утилита:
    1. рекурсивно собирает все *.txt/*.text из входной директории
       (sc_directory_get_files/directories, глубина 8);
    2. читает каждый файл в память и склеивает всё в один большой буфер
       (на диске ничего не склеивается);
    3. обучает byte-level BPE fast-тренером (sc_ai_bpe_new_fast);
    4. сохраняет словарь на диск (формат "# bpe v1") и проверяет round-trip.

  Запуск из корня репозитория:
    masuka -b release -p windows -e bpe_train -nr
    bin\release-windows\bpe_train.exe <corpus-dir> [-o out.bpe] [-m merges]

  Пример:
    bin\release-windows\bpe_train.exe D:\books -o books.bpe -m 4000

  Параметры:
    <corpus-dir>  обязательная директория с текстовыми файлами (рекурсивно);
    -o <path>     путь выходного .bpe (по умолчанию "bpe.bpe" в текущей папке);
    -m <count>    число merges (по умолчанию 4000; для реального корпуса
                  docs рекомендуют 4000-8000).

  NOTE: BPE-тренеру нужно много RAM (~20-30x объёма корпуса для reference,
  меньше для fast): на большом корпусе давайте директорию с подвыборкой
  200-500 МБ — словарь сходится и на ней (см. Docs/Bpe.md).
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/Types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BpeTrainMaxDepth 8
#define BpeTrainDefaultMerges 4000
#define BpeTrainDefaultOutput "bpe.bpe"

// DOCS: значение флага "-name value" из командной строки; если флага нет —
// pDefault. Ищет пары "флаг, следующий аргумент".
static const char*
_bpe_train_flag(i32 argc, char** argv, const char* pName, const char* pDefault)
{
    for (i32 i = 1; i < argc - 1; ++i)
    {
        if (strcmp(argv[i], pName) == 0)
            return argv[i + 1];
    }
    return pDefault;
}

// DOCS: текстовый ли файл — по расширению (.txt/.text). Рекурсивный обход
// сам отсекает бинарные форматы по этому фильтру.
static i32
_bpe_train_is_text_file(const char* pPath)
{
    i64 length = sc_string_get_length((char*)pPath);
    if (length < 4)
        return 0;

    // DOCS: сравниваем последние 4/5 символов без учёта регистра.
    const char* pTail = pPath + length - 4;
    if (pTail[0] == '.'
        && (pTail[1] == 't' || pTail[1] == 'T')
        && (pTail[2] == 'x' || pTail[2] == 'X')
        && (pTail[3] == 't' || pTail[3] == 'T'))
        return 1;

    if (length >= 5)
    {
        pTail = pPath + length - 5;
        if (pTail[0] == '.'
            && (pTail[1] == 't' || pTail[1] == 'T')
            && (pTail[2] == 'e' || pTail[2] == 'E')
            && (pTail[3] == 'x' || pTail[3] == 'X')
            && (pTail[4] == 't' || pTail[4] == 'T'))
            return 1;
    }

    return 0;
}

// DOCS: освобождение списка путей из _bpe_train_collect_text_files.
// NOTE: sc_directory_get_* возвращают обычные аллокации (без
// ScString-заголовка) — освобождаем через sc_memory_free.
static void
_bpe_train_free_file_list(char** aFiles, i32 FilesCount)
{
    for (i32 i = 0; i < FilesCount; ++i)
        sc_memory_free(aFiles[i]);
    sc_list_free(aFiles);
}

// DOCS: рекурсивный сбор текстовых файлов из директории (Sc):
// sc_directory_get_directories/sc_directory_get_files с абсолютными
// путями; в подпапки спускаемся до глубины maxDepth (защита от циклов
// из symlink'ов). Возвращает список путей (обычные аллокации —
// освобождать через _bpe_train_free_file_list).
static char**
_bpe_train_collect_text_files(const char* pDir, i32* pFilesCount, i32 maxDepth)
{
    char** aFiles = NULL;
    i32 count = 0;

    if (maxDepth <= 0)
        return NULL;

    // DOCS: файлы текущей директории (абсолютные пути).
    char** aLocalFiles = sc_directory_get_files(pDir, 1);
    for (i32 i = 0; aLocalFiles && i < (i32)sc_list_count(aLocalFiles); ++i)
    {
        if (_bpe_train_is_text_file(aLocalFiles[i]))
        {
            sc_list_add(aFiles, aLocalFiles[i]);
            ++count;
        }
        else
        {
            sc_memory_free(aLocalFiles[i]);
        }
    }
    sc_list_free(aLocalFiles);

    // DOCS: подпапки — рекурсивно.
    char** aSubDirs = sc_directory_get_directories(pDir, 1);
    for (i32 i = 0; aSubDirs && i < (i32)sc_list_count(aSubDirs); ++i)
    {
        char** aSubFiles = _bpe_train_collect_text_files(aSubDirs[i], NULL, maxDepth - 1);
        for (i32 s = 0; aSubFiles && s < (i32)sc_list_count(aSubFiles); ++s)
        {
            sc_list_add(aFiles, aSubFiles[s]);
            ++count;
        }
        sc_list_free(aSubFiles);
        sc_memory_free(aSubDirs[i]);
    }
    sc_list_free(aSubDirs);

    if (pFilesCount)
        *pFilesCount = count;
    return aFiles;
}

// DOCS: загрузка НЕСКОЛЬКИХ файлов корпуса (сотни рассказов — без склейки
// в один большой файл на диске): каждый файл из aFiles читается в память
// и приклеивается в общий builder с "\n" между файлами. Возвращает NULL,
// если не удалось прочитать ни один файл.
static char*
_bpe_train_load_corpus_files(char** aFiles, i32 FilesCount, i64* pLength, i32* pFileCount)
{
    char* pBuilder = sc_builder_new();
    i32 loaded = 0;

    for (i32 p = 0; p < FilesCount; ++p)
    {
        i64 size = 0;
        char* pData = sc_file_read_ext_ext_r(aFiles[p], &size);
        if (!pData || size <= 0)
        {
            printf("corpus: skip %s (unreadable)\n", aFiles[p]);
            continue;
        }

        if (loaded > 0)
            sc_builder_append_string(pBuilder, "\n", 1);

        sc_builder_append_string(pBuilder, pData, size);
        // NOTE: sc_file_read_ext_ext_r возвращает обычную аллокацию
        // (не ScString) — освобождаем через sc_memory_free.
        sc_memory_free(pData);
        ++loaded;
    }

    if (loaded <= 0)
    {
        sc_builder_destroy(pBuilder);
        return NULL;
    }

    i64 length = sc_builder_count(pBuilder);
    char* pCorpus = sc_string_new_ext_ext_r(pBuilder, length, length);
    sc_builder_destroy(pBuilder);

    if (pLength)
        *pLength = length;
    if (pFileCount)
        *pFileCount = loaded;
    return pCorpus;
}

static void
_bpe_train_print_usage(void)
{
    printf("usage: bpe_train <corpus-dir> [-o out.bpe] [-m merges]\n");
    printf("  <corpus-dir>  directory with *.txt/*.text (recursive)\n");
    printf("  -o <path>     output .bpe file (default: %s)\n", BpeTrainDefaultOutput);
    printf("  -m <count>    merges count (default: %d)\n", BpeTrainDefaultMerges);
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("=== bpe-train: BPE vocabulary from text corpus ===\n");

    // 1. Аргументы: директория + флаги.
    const char* pDir = NULL;
    for (i32 i = 1; i < argc; ++i)
    {
        if (argv[i][0] != '-')
        {
            pDir = argv[i];
            break;
        }
    }

    if (!pDir)
    {
        _bpe_train_print_usage();
        return 1;
    }

    const char* pOutPath = _bpe_train_flag(argc, argv, "-o", BpeTrainDefaultOutput);
    i32 merges = atoi(_bpe_train_flag(argc, argv, "-m", "4000"));
    if (merges <= 0)
        merges = BpeTrainDefaultMerges;

    // DOCS: терминальный лог инициализируем ДО обучения BPE, чтобы
    // прогресс merges (ShouldLogProgress) был виден в консоли.
    ScLogBackend backend = sc_log_get_terminal_backend();
    sc_log_init((ScLogConfig) {
        .BackendsCount = 1,
        .aBackends = &backend,
    });

    // 2. Сбор файлов.
    if (sc_path((char*)pDir) != ScPathItemType_Directory)
    {
        printf("error: corpus dir %s not found\n", pDir);
        sc_log_deinit();
        return 1;
    }

    i32 filesCount = 0;
    char** aFiles = _bpe_train_collect_text_files(pDir, &filesCount, BpeTrainMaxDepth);
    printf("corpus: dir %s -> %d text file(s) (recursive)\n", pDir, filesCount);
    if (filesCount <= 0)
    {
        printf("error: no *.txt/*.text files in %s\n", pDir);
        sc_log_deinit();
        return 1;
    }

    // 3. Склейка в один буфер.
    i64 corpusLength = 0;
    i32 loadedCount = 0;
    char* pCorpus = _bpe_train_load_corpus_files(aFiles, filesCount, &corpusLength, &loadedCount);
    _bpe_train_free_file_list(aFiles, filesCount);

    if (!pCorpus)
    {
        printf("error: no corpus data\n");
        sc_log_deinit();
        return 1;
    }
    printf("corpus: %d/%d file(s), %.1f MiB total\n",
        loadedCount, filesCount, (f64)corpusLength / (1024.0 * 1024.0));

    // 4. Обучение BPE fast-тренером на всём буфере.
    ScAiBpe bpe = sc_ai_bpe_new_fast((ScAiBpeConfig) {
        .pText = pCorpus,
        .TextLength = corpusLength,
        .MergesCount = merges,
        .ShouldLogProgress = 1,
    });

    i32 vocabCount = (i32)sc_list_count(bpe.aVocab);
    i64 tokenCount = sc_list_count(bpe.aTokens);
    printf("bpe: vocab=%d merges=%d\n", vocabCount, (i32)sc_list_count(bpe.aMerges));
    printf("bpe: corpus %lld bytes -> %lld tokens (%.2f bytes/token)\n",
        (long long)corpusLength, (long long)tokenCount,
        tokenCount > 0 ? (f64)corpusLength / (f64)tokenCount : 0.0);

    // 5. Сохранение на диск + round-trip проверка.
    sc_ai_bpe_save_to_disk((ScAiBpeSaveToDiskConfig) {
        .Bpe = bpe,
        .pFilePath = (char*)pOutPath,
        .TotalTextLength = corpusLength,
        .TotalTextLengthCompressed = tokenCount,
        .pText = pCorpus,
        .ShouldAddText = 0,
        .ShouldAddTokens = 0,
    });
    printf("bpe: saved to %s\n", pOutPath);

    ScAiBpe loadedBpe = sc_ai_bpe_load_from_disk((char*)pOutPath);
    printf("bpe: round-trip -> %s\n",
        sc_list_count(loadedBpe.aVocab) == sc_list_count(bpe.aVocab) ? "ok" : "FAILED");

    sc_ai_bpe_destroy(&loadedBpe);
    sc_ai_bpe_destroy(&bpe);
    sc_string_destroy(pCorpus);
    sc_log_deinit();

    printf("=== done ===\n");
    return 0;
}
