# bpe-train — обучение BPE-словаря (шаг 1 пайплайна MS1)

CLI-утилита: рекурсивно читает все `*.txt`/`*.text` из директории,
склеивает в один большой буфер в памяти и обучает byte-level BPE
fast-тренером (`sc_ai_bpe_new_fast`). Результат — файл словаря
`# bpe v1`, вход для `lm-train`.

Пайплайн MS1: `bpe-train` → `lm-train` → `lm-chat`.

## Запуск

```bash
masuka -b release -p windows -e bpe_train -nr
bin\release-windows\bpe_train.exe <corpus-dir> [-o out.bpe] [-m merges]
```

На Linux (или из git-bash) — одним скриптом (сборка + запуск):

```bash
bash Examples/bpe-train/run_bpe_train.sh <corpus-dir> [-o out.bpe] [-m merges]
```

Перед первым использованием: `chmod +x Examples/bpe-train/run_bpe_train.sh`.
Скрипт сам находит корень репозитория, собирает release под текущую
платформу (linux/windows) и запускает утилиту с пробросом аргументов.

Пример:

```powershell
bin\release-windows\bpe_train.exe D:\books -o books.bpe -m 4000
```

## Параметры

| Параметр | По умолчанию | Описание |
|---|---|---|
| `<corpus-dir>` | — (обязательный) | директория с текстовыми файлами; обход рекурсивный (глубина 8) |
| `-o <path>` | `bpe.bpe` (в текущей папке) | выходной файл словаря |
| `-m <count>` | `4000` | число merges; для реального корпуса docs рекомендуют 4000–8000 |

Формат файлов корпуса: UTF-8, любой формат строк (BPE учится на всём
буфере целиком, разметка строк не нужна); CRLF/BOM допустимы.
Несуществующие/нечитаемые файлы пропускаются с сообщением.

## Что печатает

```text
corpus: dir D:\books -> 214 text file(s) (recursive)
corpus: 214/214 file(s), 312.4 MiB total
bpe: vocab=4256 merges=4000
bpe: corpus 327530000 bytes -> 86100000 tokens (3.80 bytes/token)
bpe: saved to books.bpe
bpe: round-trip -> ok
```

Прогресс merges идёт в терминальный лог (`ShouldLogProgress = 1`).

## Память

Fast-тренер держит корпус + структуры пар в RAM: закладывайтесь на
**несколько × объёма корпуса**. На большом корпусе (гигабайты) давайте
директорию с **подвыборкой 200–500 МБ** — словарь сходится и на ней
(см. `Docs/Bpe.md`). Датасет модели (`lm-train`) при этом можно кормить
всем корпусом — он ест файлы по одному.
