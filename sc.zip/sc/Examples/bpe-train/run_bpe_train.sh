#!/usr/bin/env bash
# Запуск bpe_train (шаг 1 пайплайна MS1): обучение BPE-словаря.
#
# Использование (из любой папки):
#   ./run_bpe_train.sh <corpus-dir> [-o out.bpe] [-m merges]
#   bash Examples/bpe-train/run_bpe_train.sh D:/books -o books.bpe -m 4000
#
# Скрипт: cd в корень репозитория -> сборка release -> запуск с
# пробросом всех аргументов. Все параметры утилиты — см. README.md.

set -e

# Корень репозитория (скрипт лежит в Examples/bpe-train/).
cd "$(cd "$(dirname "$0")" && pwd -P)/../.."

# Платформа: linux нативно, всё остальное (git-bash/MSYS на Windows) — windows.
OS="$(uname -s)"
case "$OS" in
    Linux*) PLATFORM="linux";  EXE="" ;;
    *)      PLATFORM="windows"; EXE=".exe" ;;
esac

masuka -b release -p "$PLATFORM" -e bpe_train -nr
exec "bin/release-$PLATFORM/bpe_train$EXE" "$@"
