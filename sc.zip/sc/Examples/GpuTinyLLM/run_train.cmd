@echo off
rem Train TinyLlm on Vulkan (gpu_tiny_llm train) from bin\<build>-windows.
rem Examples:
rem   run_train.cmd --bpe bin\books.bpe --corpus D:\books --val D:\books-val --pack -o bin\books.ckpt
rem   run_train.cmd --checkpoint bin\books.ckpt --corpus D:\books --pack
rem All arguments are passed to "gpu_tiny_llm train" unchanged.
setlocal
for %%I in ("%~dp0..\..") do set "ROOT=%%~fI"
if "%BUILD%"=="" set "BUILD=release"
set "EXE=%ROOT%\bin\%BUILD%-windows\gpu_tiny_llm.exe"

if not exist "%EXE%" (
    echo [run_train] binary not found: %EXE%
    echo             build: masuka -b %BUILD% -p windows -e gpu_tiny_llm -nr
    exit /b 1
)

if "%~1"=="" (
    echo usage: %~nx0 --bpe ^<file.bpe^> --corpus ^<file^|dir^> [--val ^<file^|dir^>] [--pack] -o ^<ckpt^> [extra args]
    echo   example: %~nx0 --bpe bin\books.bpe --corpus D:\books --val D:\books-val --pack -o bin\books.ckpt
    echo   resume:  %~nx0 --checkpoint bin\books.ckpt --corpus D:\books --pack
    exit /b 1
)

"%EXE%" train %*
exit /b %ERRORLEVEL%
