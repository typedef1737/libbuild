#ifndef SC_GPU_TINY_LLM_VK_GPU_H
#define SC_GPU_TINY_LLM_VK_GPU_H

/*
  VkGpu - минимальный Vulkan compute-бэкенд для GpuTinyLLM.

  Это самостоятельный аналог Source/Sc/Gfx/Vk.c: без окон, swapchain и
  graphics pipeline. Нужны только instance -> physical device -> compute
  queue -> storage buffers -> compute pipelines -> dispatch.

  Vulkan загружается динамически:
    Windows - LoadLibraryA("vulkan-1.dll")
    Linux   - dlopen("libvulkan.so.1")
  Поэтому SDK при сборке не нужен, но для компиляции шейдеров во время
  запуска нужен glslc (из Vulkan SDK) в PATH или в VULKAN_SDK/Bin.

  Заголовок намеренно не тянет Vulkan.h: наружу видны только u32-хэндлы
  и ScGpuPush. Это позволяет включать его из обычного C-кода.
*/

#include "Sc/Types.h"

typedef struct ScGpu ScGpu;

typedef struct
{
    // DOCS: каталог с kernels.glsl. NULL -> "shaders".
    const char* pShaderDir;
    // DOCS: печатать имя устройства, лимиты и команды glslc.
    i32 Verbose;
} ScGpuConfig;

typedef struct
{
    u32 u[16];
    f32 f[12];
} ScGpuPush;

#define SC_GPU_INVALID_HANDLE 0xffffffffu

ScGpu* sc_gpu_create(const ScGpuConfig* pConfig);
void sc_gpu_destroy(ScGpu* pGpu);

const char* sc_gpu_device_name(ScGpu* pGpu);
u32 sc_gpu_max_storage_range(ScGpu* pGpu);
u32 sc_gpu_max_workgroup_invocations(ScGpu* pGpu);
// DOCS: максимум workgroup'ов по X (нужен для больших dispatch'ей).
u32 sc_gpu_max_workgroup_count_x(ScGpu* pGpu);
const char* sc_gpu_last_error(ScGpu* pGpu);

// DOCS: hostVisible=1 -> HOST_VISIBLE|HOST_COHERENT (mapped напрямую),
// иначе DEVICE_LOCAL. Все буферы создаются с usage
// STORAGE|TRANSFER_SRC|TRANSFER_DST.
u32 sc_gpu_buffer_new(ScGpu* pGpu, u64 size, i32 hostVisible);
void sc_gpu_buffer_destroy(ScGpu* pGpu, u32 buffer);
void* sc_gpu_buffer_map(ScGpu* pGpu, u32 buffer);
u64 sc_gpu_buffer_size(ScGpu* pGpu, u32 buffer);

// DOCS: привязать два буфера к descriptor set (binding 0 и 1).
// Вызывается один раз после создания буферов модели.
i32 sc_gpu_bind_storage(ScGpu* pGpu, u32 binding0, u32 binding1);

i32 sc_gpu_upload(ScGpu* pGpu, u32 buffer, u64 offset, const void* pData, u64 size);
i32 sc_gpu_download(ScGpu* pGpu, u32 buffer, u64 offset, void* pData, u64 size);

// DOCS: pDefine - имя без префикса K_, например "MATMUL_FWD".
u32 sc_gpu_pipeline_new(ScGpu* pGpu, const char* pDefine);
void sc_gpu_pipeline_destroy(ScGpu* pGpu, u32 pipeline);

void sc_gpu_cmd_begin(ScGpu* pGpu);
void sc_gpu_dispatch(ScGpu* pGpu, u32 pipeline, const ScGpuPush* pPush,
    u32 groupX, u32 groupY, u32 groupZ);
// DOCS: закрыть command buffer, submit и дождаться выполнения.
i32 sc_gpu_cmd_submit(ScGpu* pGpu);

#endif // SC_GPU_TINY_LLM_VK_GPU_H
