#include "VkGpu.h"

/*
  Самостоятельный Vulkan compute-бэкенд.

  Идея та же, что в Source/Sc/Gfx/Vk.c (instance/device/буферы/дескрипторы/
  пайплайны, компиляция GLSL через glslc), но:
    * без окна, surface, swapchain и graphics pipeline;
    * Vulkan грузится вручную на Windows и Linux, SDK при сборке не нужен;
    * один descriptor set (2 SSBO) и один push-constant блок;
    * command buffer пишется целиком на шаг и отправляется один раз.

  Для сборки без Vulkan SDK используется "мини-заголовок" Vulkan.h
  (MY_PROTO): он содержит нужные типы и константы, но не тянет
  vulkan/vulkan_core.h.
*/

#define MY_PROTO
#include "Sc/Gfx/Vulkan.h"
#include "Sc/Sc.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#if defined(SC_PLATFORM_WINDOWS)
#include <windows.h>
#elif defined(SC_PLATFORM_LINUX)
#include <dlfcn.h>
#else
#error "VkGpu: only Windows and Linux are supported (Android/WASM need separate backends)"
#endif

// DOCS: этих двух объявлений нет в мини-заголовке Vulkan.h.
typedef void(VKAPI_PTR* ScGpuPFN_vkCmdDispatch)(VkCommandBuffer, u32, u32, u32);
typedef void(VKAPI_PTR* ScGpuPFN_vkCmdPushConstants)(VkCommandBuffer,
    VkPipelineLayout, VkShaderStageFlags, u32, u32, const void*);

#define SC_GPU_MAX_BUFFERS 32
#define SC_GPU_MAX_PIPELINES 64
#define SC_GPU_MAX_ERROR 512

typedef struct
{
    VkBuffer Buffer;
    VkDeviceMemory Memory;
    u64 Size;
    i32 HostVisible;
    void* pMapped;
} ScGpuBufferSlot;

typedef struct
{
    VkPipeline Pipeline;
    VkShaderModule Module;
    char Name[64];
} ScGpuPipelineSlot;

typedef struct
{
    PFN_vkGetInstanceProcAddr GetInstanceProcAddr;
    PFN_vkGetDeviceProcAddr GetDeviceProcAddr;

    PFN_vkCreateInstance CreateInstance;
    PFN_vkDestroyInstance DestroyInstance;
    PFN_vkEnumeratePhysicalDevices EnumeratePhysicalDevices;
    PFN_vkGetPhysicalDeviceProperties GetPhysicalDeviceProperties;
    PFN_vkGetPhysicalDeviceMemoryProperties GetPhysicalDeviceMemoryProperties;
    PFN_vkGetPhysicalDeviceQueueFamilyProperties GetPhysicalDeviceQueueFamilyProperties;
    PFN_vkCreateDevice CreateDevice;
    PFN_vkDestroyDevice DestroyDevice;
    PFN_vkGetDeviceQueue GetDeviceQueue;
    PFN_vkDeviceWaitIdle DeviceWaitIdle;

    PFN_vkQueueSubmit QueueSubmit;
    PFN_vkQueueWaitIdle QueueWaitIdle;
    PFN_vkCreateCommandPool CreateCommandPool;
    PFN_vkDestroyCommandPool DestroyCommandPool;
    PFN_vkResetCommandPool ResetCommandPool;
    PFN_vkAllocateCommandBuffers AllocateCommandBuffers;
    PFN_vkFreeCommandBuffers FreeCommandBuffers;
    PFN_vkBeginCommandBuffer BeginCommandBuffer;
    PFN_vkEndCommandBuffer EndCommandBuffer;

    PFN_vkCreateBuffer CreateBuffer;
    PFN_vkDestroyBuffer DestroyBuffer;
    PFN_vkGetBufferMemoryRequirements GetBufferMemoryRequirements;
    PFN_vkBindBufferMemory BindBufferMemory;
    PFN_vkAllocateMemory AllocateMemory;
    PFN_vkFreeMemory FreeMemory;
    PFN_vkMapMemory MapMemory;
    PFN_vkUnmapMemory UnmapMemory;

    PFN_vkCreateShaderModule CreateShaderModule;
    PFN_vkDestroyShaderModule DestroyShaderModule;
    PFN_vkCreateDescriptorSetLayout CreateDescriptorSetLayout;
    PFN_vkDestroyDescriptorSetLayout DestroyDescriptorSetLayout;
    PFN_vkCreateDescriptorPool CreateDescriptorPool;
    PFN_vkDestroyDescriptorPool DestroyDescriptorPool;
    PFN_vkAllocateDescriptorSets AllocateDescriptorSets;
    PFN_vkUpdateDescriptorSets UpdateDescriptorSets;
    PFN_vkCreatePipelineLayout CreatePipelineLayout;
    PFN_vkDestroyPipelineLayout DestroyPipelineLayout;
    PFN_vkCreateComputePipelines CreateComputePipelines;
    PFN_vkDestroyPipeline DestroyPipeline;

    PFN_vkCmdBindPipeline CmdBindPipeline;
    PFN_vkCmdBindDescriptorSets CmdBindDescriptorSets;
    ScGpuPFN_vkCmdPushConstants CmdPushConstants;
    ScGpuPFN_vkCmdDispatch CmdDispatch;
    PFN_vkCmdPipelineBarrier CmdPipelineBarrier;
    PFN_vkCmdCopyBuffer CmdCopyBuffer;
} ScGpuApi;

struct ScGpu
{
    void* pLib;
    ScGpuApi Api;

    VkInstance Instance;
    VkPhysicalDevice PhysicalDevice;
    VkDevice Device;
    VkQueue Queue;
    u32 QueueFamily;

    VkCommandPool CommandPool;
    VkCommandBuffer Command;
    i32 IsRecording;

    // DOCS: один переиспользуемый staging-буфер для upload/download.
    VkBuffer StagingBuffer;
    VkDeviceMemory StagingMemory;
    void* pStaging;
    u64 StagingSize;

    VkDescriptorSetLayout DescriptorSetLayout;
    VkDescriptorPool DescriptorPool;
    VkDescriptorSet DescriptorSet;
    VkPipelineLayout PipelineLayout;
    i32 HasStorage;

    ScGpuBufferSlot aBuffers[SC_GPU_MAX_BUFFERS];
    u32 BufferCount;

    ScGpuPipelineSlot aPipelines[SC_GPU_MAX_PIPELINES];
    u32 PipelineCount;

    char ShaderDir[512];
    char DeviceName[256];
    char LastError[SC_GPU_MAX_ERROR];
    u32 MaxStorageRange;
    u32 MaxWorkgroupInvocations;
    u32 MaxWorkgroupCount[3];
    i32 Verbose;
};

static void _sc_gpu_staging_destroy(ScGpu* pGpu);

static i32
_sc_gpu_fail(ScGpu* pGpu, const char* pFormat, ...)
{
    if (!pGpu)
        return 0;

    va_list args;
    va_start(args, pFormat);
    vsnprintf(pGpu->LastError, SC_GPU_MAX_ERROR, pFormat, args);
    va_end(args);

    if (pGpu && pGpu->LastError[0])
        sc_log_erro("gpu: %s\n", pGpu->LastError);
    return 0;
}

static void*
_sc_gpu_lib_open(void)
{
#if defined(SC_PLATFORM_WINDOWS)
    return (void*)LoadLibraryA("vulkan-1.dll");
#else
    return dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL);
#endif
}

static void*
_sc_gpu_lib_symbol(void* pLib, const char* pName)
{
#if defined(SC_PLATFORM_WINDOWS)
    return (void*)GetProcAddress((HMODULE)pLib, pName);
#else
    return dlsym(pLib, pName);
#endif
}

static void
_sc_gpu_lib_close(void* pLib)
{
#if defined(SC_PLATFORM_WINDOWS)
    FreeLibrary((HMODULE)pLib);
#else
    dlclose(pLib);
#endif
}

#define SC_GPU_LOAD(api, field, name) \
    do { \
        (api)->field = (void*)_sc_gpu_lib_symbol(pLib, name); \
        if (!(api)->field) { \
            _sc_gpu_fail(pGpu, "vulkan: missing symbol %s", name); \
            return 0; \
        } \
    } while (0)

#define SC_GPU_LOAD_DEVICE(pGpu, field, name) \
    do { \
        (pGpu)->Api.field = (void*)(pGpu)->Api.GetDeviceProcAddr((pGpu)->Device, name); \
        if (!(pGpu)->Api.field) { \
            _sc_gpu_fail(pGpu, "vulkan: missing device symbol %s", name); \
            return 0; \
        } \
    } while (0)

static i32
_sc_gpu_load_globals(ScGpu* pGpu, void* pLib)
{
    ScGpuApi* pApi = &pGpu->Api;

    // DOCS: до создания instance грузим только глобальные команды.
    // Остальные функции (physical device, destroy instance) обязаны
    // запрашиваться через vkGetInstanceProcAddr уже с valid instance.
    SC_GPU_LOAD(pApi, GetInstanceProcAddr, "vkGetInstanceProcAddr");

    pApi->CreateInstance = (void*)pApi->GetInstanceProcAddr(NULL, "vkCreateInstance");
    if (!pApi->CreateInstance)
        return _sc_gpu_fail(pGpu, "vulkan: missing vkCreateInstance");

    (void)pLib;
    return 1;
}

static i32
_sc_gpu_load_instance(ScGpu* pGpu)
{
    ScGpuApi* pApi = &pGpu->Api;
    PFN_vkGetInstanceProcAddr pGet = pApi->GetInstanceProcAddr;

    pApi->DestroyInstance = (void*)pGet(pGpu->Instance, "vkDestroyInstance");
    pApi->EnumeratePhysicalDevices = (void*)pGet(pGpu->Instance, "vkEnumeratePhysicalDevices");
    pApi->GetPhysicalDeviceProperties = (void*)pGet(pGpu->Instance, "vkGetPhysicalDeviceProperties");
    pApi->GetPhysicalDeviceMemoryProperties = (void*)pGet(pGpu->Instance, "vkGetPhysicalDeviceMemoryProperties");
    pApi->GetPhysicalDeviceQueueFamilyProperties = (void*)pGet(pGpu->Instance, "vkGetPhysicalDeviceQueueFamilyProperties");
    pApi->CreateDevice = (void*)pGet(pGpu->Instance, "vkCreateDevice");
    pApi->GetDeviceProcAddr = (void*)pGet(pGpu->Instance, "vkGetDeviceProcAddr");

    if (!pApi->DestroyInstance || !pApi->EnumeratePhysicalDevices ||
        !pApi->GetPhysicalDeviceProperties || !pApi->GetPhysicalDeviceMemoryProperties ||
        !pApi->GetPhysicalDeviceQueueFamilyProperties || !pApi->CreateDevice ||
        !pApi->GetDeviceProcAddr)
    {
        return _sc_gpu_fail(pGpu, "vulkan: failed to load instance functions");
    }

    return 1;
}

static i32
_sc_gpu_load_device(ScGpu* pGpu)
{
    SC_GPU_LOAD_DEVICE(pGpu, DestroyDevice, "vkDestroyDevice");
    SC_GPU_LOAD_DEVICE(pGpu, GetDeviceQueue, "vkGetDeviceQueue");
    SC_GPU_LOAD_DEVICE(pGpu, DeviceWaitIdle, "vkDeviceWaitIdle");

    SC_GPU_LOAD_DEVICE(pGpu, QueueSubmit, "vkQueueSubmit");
    SC_GPU_LOAD_DEVICE(pGpu, QueueWaitIdle, "vkQueueWaitIdle");
    SC_GPU_LOAD_DEVICE(pGpu, CreateCommandPool, "vkCreateCommandPool");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyCommandPool, "vkDestroyCommandPool");
    SC_GPU_LOAD_DEVICE(pGpu, ResetCommandPool, "vkResetCommandPool");
    SC_GPU_LOAD_DEVICE(pGpu, AllocateCommandBuffers, "vkAllocateCommandBuffers");
    SC_GPU_LOAD_DEVICE(pGpu, FreeCommandBuffers, "vkFreeCommandBuffers");
    SC_GPU_LOAD_DEVICE(pGpu, BeginCommandBuffer, "vkBeginCommandBuffer");
    SC_GPU_LOAD_DEVICE(pGpu, EndCommandBuffer, "vkEndCommandBuffer");

    SC_GPU_LOAD_DEVICE(pGpu, CreateBuffer, "vkCreateBuffer");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyBuffer, "vkDestroyBuffer");
    SC_GPU_LOAD_DEVICE(pGpu, GetBufferMemoryRequirements, "vkGetBufferMemoryRequirements");
    SC_GPU_LOAD_DEVICE(pGpu, BindBufferMemory, "vkBindBufferMemory");
    SC_GPU_LOAD_DEVICE(pGpu, AllocateMemory, "vkAllocateMemory");
    SC_GPU_LOAD_DEVICE(pGpu, FreeMemory, "vkFreeMemory");
    SC_GPU_LOAD_DEVICE(pGpu, MapMemory, "vkMapMemory");
    SC_GPU_LOAD_DEVICE(pGpu, UnmapMemory, "vkUnmapMemory");

    SC_GPU_LOAD_DEVICE(pGpu, CreateShaderModule, "vkCreateShaderModule");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyShaderModule, "vkDestroyShaderModule");
    SC_GPU_LOAD_DEVICE(pGpu, CreateDescriptorSetLayout, "vkCreateDescriptorSetLayout");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyDescriptorSetLayout, "vkDestroyDescriptorSetLayout");
    SC_GPU_LOAD_DEVICE(pGpu, CreateDescriptorPool, "vkCreateDescriptorPool");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyDescriptorPool, "vkDestroyDescriptorPool");
    SC_GPU_LOAD_DEVICE(pGpu, AllocateDescriptorSets, "vkAllocateDescriptorSets");
    SC_GPU_LOAD_DEVICE(pGpu, UpdateDescriptorSets, "vkUpdateDescriptorSets");
    SC_GPU_LOAD_DEVICE(pGpu, CreatePipelineLayout, "vkCreatePipelineLayout");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyPipelineLayout, "vkDestroyPipelineLayout");
    SC_GPU_LOAD_DEVICE(pGpu, CreateComputePipelines, "vkCreateComputePipelines");
    SC_GPU_LOAD_DEVICE(pGpu, DestroyPipeline, "vkDestroyPipeline");

    SC_GPU_LOAD_DEVICE(pGpu, CmdBindPipeline, "vkCmdBindPipeline");
    SC_GPU_LOAD_DEVICE(pGpu, CmdBindDescriptorSets, "vkCmdBindDescriptorSets");
    SC_GPU_LOAD_DEVICE(pGpu, CmdPushConstants, "vkCmdPushConstants");
    SC_GPU_LOAD_DEVICE(pGpu, CmdDispatch, "vkCmdDispatch");
    SC_GPU_LOAD_DEVICE(pGpu, CmdPipelineBarrier, "vkCmdPipelineBarrier");
    SC_GPU_LOAD_DEVICE(pGpu, CmdCopyBuffer, "vkCmdCopyBuffer");

    return 1;
}

static u32
_sc_gpu_memory_type(ScGpu* pGpu, u32 typeBits, VkMemoryPropertyFlags required)
{
    VkPhysicalDeviceMemoryProperties props;
    pGpu->Api.GetPhysicalDeviceMemoryProperties(pGpu->PhysicalDevice, &props);

    // DOCS: выбираем самый большой подходящий heap: на дискретных GPU
    // первый device-local тип иногда оказывается маленьким BAR-окном.
    u32 best = SC_GPU_INVALID_HANDLE;
    u64 bestSize = 0;
    for (u32 i = 0; i < props.memoryTypeCount; ++i)
    {
        if ((typeBits & (1u << i)) == 0)
            continue;
        if ((props.memoryTypes[i].propertyFlags & required) != required)
            continue;

        u32 heapIndex = props.memoryTypes[i].heapIndex;
        u64 size = (heapIndex < props.memoryHeapCount) ? props.memoryHeaps[heapIndex].size : 0;
        if (best == SC_GPU_INVALID_HANDLE || size > bestSize)
        {
            best = i;
            bestSize = size;
        }
    }
    return best;
}

static i32
_sc_gpu_pick_device(ScGpu* pGpu)
{
    ScGpuApi* pApi = &pGpu->Api;
    u32 count = 0;
    if (pApi->EnumeratePhysicalDevices(pGpu->Instance, &count, NULL) != VK_SUCCESS || count == 0)
        return _sc_gpu_fail(pGpu, "vulkan: no physical devices");

    VkPhysicalDevice aDevices[16] = {};
    if (count > 16)
        count = 16;
    if (pApi->EnumeratePhysicalDevices(pGpu->Instance, &count, aDevices) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: failed to enumerate physical devices");

    i32 bestIndex = -1;
    i32 bestScore = -1;
    u32 bestFamily = 0;

    for (u32 i = 0; i < count; ++i)
    {
        VkPhysicalDeviceProperties props;
        pApi->GetPhysicalDeviceProperties(aDevices[i], &props);

        u32 familyCount = 0;
        pApi->GetPhysicalDeviceQueueFamilyProperties(aDevices[i], &familyCount, NULL);
        if (familyCount == 0)
            continue;

        VkQueueFamilyProperties aFamilies[32] = {};
        if (familyCount > 32)
            familyCount = 32;
        pApi->GetPhysicalDeviceQueueFamilyProperties(aDevices[i], &familyCount, aFamilies);

        i32 computeFamily = -1;
        for (u32 f = 0; f < familyCount; ++f)
        {
            if (aFamilies[f].queueFlags & VK_QUEUE_COMPUTE_BIT)
            {
                computeFamily = (i32)f;
                break;
            }
        }
        if (computeFamily < 0)
            continue;

        i32 score = 10;
        if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU)
            score += 100;
        else if (props.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU)
            score += 40;

        if (score > bestScore)
        {
            bestScore = score;
            bestIndex = (i32)i;
            bestFamily = (u32)computeFamily;
        }
    }

    if (bestIndex < 0)
        return _sc_gpu_fail(pGpu, "vulkan: no device with a compute queue");

    pGpu->PhysicalDevice = aDevices[bestIndex];
    pGpu->QueueFamily = bestFamily;

    VkPhysicalDeviceProperties props;
    pApi->GetPhysicalDeviceProperties(pGpu->PhysicalDevice, &props);
    snprintf(pGpu->DeviceName, sizeof(pGpu->DeviceName), "%s", props.deviceName);
    pGpu->MaxStorageRange = props.limits.maxStorageBufferRange;
    pGpu->MaxWorkgroupInvocations = props.limits.maxComputeWorkGroupInvocations;
    pGpu->MaxWorkgroupCount[0] = props.limits.maxComputeWorkGroupCount[0];
    pGpu->MaxWorkgroupCount[1] = props.limits.maxComputeWorkGroupCount[1];
    pGpu->MaxWorkgroupCount[2] = props.limits.maxComputeWorkGroupCount[2];

    return 1;
}

static i32
_sc_gpu_create_device(ScGpu* pGpu)
{
    ScGpuApi* pApi = &pGpu->Api;
    f32 priority = 1.0f;

    VkDeviceQueueCreateInfo queueInfo = {
        .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
        .queueFamilyIndex = pGpu->QueueFamily,
        .queueCount = 1,
        .pQueuePriorities = &priority,
    };

    VkDeviceCreateInfo deviceInfo = {
        .sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
        .queueCreateInfoCount = 1,
        .pQueueCreateInfos = &queueInfo,
    };

    if (pApi->CreateDevice(pGpu->PhysicalDevice, &deviceInfo, NULL, &pGpu->Device) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkCreateDevice failed");

    pApi->GetDeviceQueue(pGpu->Device, pGpu->QueueFamily, 0, &pGpu->Queue);

    if (!_sc_gpu_load_device(pGpu))
        return 0;

    VkCommandPoolCreateInfo poolInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
        .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
        .queueFamilyIndex = pGpu->QueueFamily,
    };

    if (pApi->CreateCommandPool(pGpu->Device, &poolInfo, NULL, &pGpu->CommandPool) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkCreateCommandPool failed");

    VkCommandBufferAllocateInfo allocInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
        .commandPool = pGpu->CommandPool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
        .commandBufferCount = 1,
    };

    if (pApi->AllocateCommandBuffers(pGpu->Device, &allocInfo, &pGpu->Command) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkAllocateCommandBuffers failed");

    return 1;
}

static i32
_sc_gpu_create_descriptors(ScGpu* pGpu)
{
    ScGpuApi* pApi = &pGpu->Api;

    VkDescriptorSetLayoutBinding aBindings[2] = {
        {
            .binding = 0,
            .descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
            .descriptorCount = 1,
            .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT,
        },
        {
            .binding = 1,
            .descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
            .descriptorCount = 1,
            .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT,
        },
    };

    VkDescriptorSetLayoutCreateInfo layoutInfo = {
        .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO,
        .bindingCount = 2,
        .pBindings = aBindings,
    };

    if (pApi->CreateDescriptorSetLayout(pGpu->Device, &layoutInfo, NULL, &pGpu->DescriptorSetLayout) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkCreateDescriptorSetLayout failed");

    VkDescriptorPoolSize poolSize = {
        .type = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
        .descriptorCount = 2,
    };

    VkDescriptorPoolCreateInfo descriptorPoolInfo = {
        .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO,
        .maxSets = 1,
        .poolSizeCount = 1,
        .pPoolSizes = &poolSize,
    };

    if (pApi->CreateDescriptorPool(pGpu->Device, &descriptorPoolInfo, NULL, &pGpu->DescriptorPool) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkCreateDescriptorPool failed");

    VkDescriptorSetAllocateInfo setInfo = {
        .sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO,
        .descriptorPool = pGpu->DescriptorPool,
        .descriptorSetCount = 1,
        .pSetLayouts = &pGpu->DescriptorSetLayout,
    };

    if (pApi->AllocateDescriptorSets(pGpu->Device, &setInfo, &pGpu->DescriptorSet) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkAllocateDescriptorSets failed");

    VkPushConstantRange range = {
        .stageFlags = VK_SHADER_STAGE_COMPUTE_BIT,
        .offset = 0,
        .size = sizeof(ScGpuPush),
    };

    VkPipelineLayoutCreateInfo pipelineLayoutInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
        .setLayoutCount = 1,
        .pSetLayouts = &pGpu->DescriptorSetLayout,
        .pushConstantRangeCount = 1,
        .pPushConstantRanges = &range,
    };

    if (pApi->CreatePipelineLayout(pGpu->Device, &pipelineLayoutInfo, NULL, &pGpu->PipelineLayout) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vulkan: vkCreatePipelineLayout failed");

    return 1;
}

ScGpu*
sc_gpu_create(const ScGpuConfig* pConfig)
{
    ScGpu* pGpu = sc_memory_allocate(sizeof(ScGpu));
    if (!pGpu)
        return NULL;
    memset(pGpu, 0, sizeof(ScGpu));

    pGpu->ShaderDir[0] = 0;
    snprintf(pGpu->ShaderDir, sizeof(pGpu->ShaderDir), "%s",
        (pConfig && pConfig->pShaderDir) ? pConfig->pShaderDir : "shaders");
    pGpu->Verbose = pConfig ? pConfig->Verbose : 0;

    pGpu->pLib = _sc_gpu_lib_open();
    if (!pGpu->pLib)
    {
        _sc_gpu_fail(pGpu, "cannot load vulkan-1.dll / libvulkan.so.1");
        fprintf(stderr, "gpu: %s\n", pGpu->LastError);
        sc_memory_free(pGpu);
        return NULL;
    }

    if (!_sc_gpu_load_globals(pGpu, pGpu->pLib))
        goto Failed;

    VkApplicationInfo appInfo = {
        .sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
        .pApplicationName = "GpuTinyLLM",
        .applicationVersion = 1,
        .pEngineName = "Sc",
        .engineVersion = 1,
        .apiVersion = VK_MAKE_VERSION(1, 0, 0),
    };

    VkInstanceCreateInfo instanceInfo = {
        .sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
        .pApplicationInfo = &appInfo,
    };

    if (pGpu->Api.CreateInstance(&instanceInfo, NULL, &pGpu->Instance) != VK_SUCCESS)
    {
        _sc_gpu_fail(pGpu, "vulkan: vkCreateInstance failed");
        goto Failed;
    }

    if (!_sc_gpu_load_instance(pGpu))
        goto Failed;

    if (!_sc_gpu_pick_device(pGpu))
        goto Failed;

    if (!_sc_gpu_create_device(pGpu))
        goto Failed;

    if (!_sc_gpu_create_descriptors(pGpu))
        goto Failed;

    if (pGpu->Verbose)
    {
        sc_log_info("gpu: device %s, maxStorageBufferRange %.1f MB, maxWorkgroupInvocations %u\n",
            pGpu->DeviceName,
            (f64)pGpu->MaxStorageRange / (1024.0 * 1024.0),
            pGpu->MaxWorkgroupInvocations);
    }

    return pGpu;

Failed:
    if (pGpu->LastError[0])
        fprintf(stderr, "gpu: %s\n", pGpu->LastError);
    sc_gpu_destroy(pGpu);
    return NULL;
}

void
sc_gpu_destroy(ScGpu* pGpu)
{
    if (!pGpu)
        return;

    if (pGpu->Device && pGpu->Api.DeviceWaitIdle)
        pGpu->Api.DeviceWaitIdle(pGpu->Device);

    for (u32 i = 0; i < pGpu->PipelineCount; ++i)
    {
        ScGpuPipelineSlot* p = &pGpu->aPipelines[i];
        if (p->Pipeline && pGpu->Api.DestroyPipeline)
            pGpu->Api.DestroyPipeline(pGpu->Device, p->Pipeline, NULL);
        if (p->Module && pGpu->Api.DestroyShaderModule)
            pGpu->Api.DestroyShaderModule(pGpu->Device, p->Module, NULL);
    }

    for (u32 i = 0; i < pGpu->BufferCount; ++i)
    {
        ScGpuBufferSlot* b = &pGpu->aBuffers[i];
        if (b->pMapped && pGpu->Api.UnmapMemory)
        {
            pGpu->Api.UnmapMemory(pGpu->Device, b->Memory);
            b->pMapped = NULL;
        }
        if (b->Buffer && pGpu->Api.DestroyBuffer)
            pGpu->Api.DestroyBuffer(pGpu->Device, b->Buffer, NULL);
        if (b->Memory && pGpu->Api.FreeMemory)
            pGpu->Api.FreeMemory(pGpu->Device, b->Memory, NULL);
    }

    if (pGpu->Device)
        _sc_gpu_staging_destroy(pGpu);

    if (pGpu->Device)
    {
        if (pGpu->CommandPool && pGpu->Api.DestroyCommandPool)
            pGpu->Api.DestroyCommandPool(pGpu->Device, pGpu->CommandPool, NULL);
        if (pGpu->DescriptorPool && pGpu->Api.DestroyDescriptorPool)
            pGpu->Api.DestroyDescriptorPool(pGpu->Device, pGpu->DescriptorPool, NULL);
        if (pGpu->PipelineLayout && pGpu->Api.DestroyPipelineLayout)
            pGpu->Api.DestroyPipelineLayout(pGpu->Device, pGpu->PipelineLayout, NULL);
        if (pGpu->DescriptorSetLayout && pGpu->Api.DestroyDescriptorSetLayout)
            pGpu->Api.DestroyDescriptorSetLayout(pGpu->Device, pGpu->DescriptorSetLayout, NULL);
        if (pGpu->Api.DestroyDevice)
            pGpu->Api.DestroyDevice(pGpu->Device, NULL);
    }

    if (pGpu->Instance && pGpu->Api.DestroyInstance)
        pGpu->Api.DestroyInstance(pGpu->Instance, NULL);

    if (pGpu->pLib)
        _sc_gpu_lib_close(pGpu->pLib);

    sc_memory_free(pGpu);
}

const char*
sc_gpu_device_name(ScGpu* pGpu)
{
    return pGpu ? pGpu->DeviceName : "";
}

u32
sc_gpu_max_storage_range(ScGpu* pGpu)
{
    return pGpu ? pGpu->MaxStorageRange : 0;
}

u32
sc_gpu_max_workgroup_invocations(ScGpu* pGpu)
{
    return pGpu ? pGpu->MaxWorkgroupInvocations : 0;
}

u32
sc_gpu_max_workgroup_count_x(ScGpu* pGpu)
{
    return pGpu ? pGpu->MaxWorkgroupCount[0] : 0;
}

const char*
sc_gpu_last_error(ScGpu* pGpu)
{
    return pGpu ? pGpu->LastError : "gpu: no device";
}

u32
sc_gpu_buffer_new(ScGpu* pGpu, u64 size, i32 hostVisible)
{
    if (!pGpu || size == 0)
        return SC_GPU_INVALID_HANDLE;

    if (pGpu->BufferCount >= SC_GPU_MAX_BUFFERS)
    {
        _sc_gpu_fail(pGpu, "too many buffers");
        return SC_GPU_INVALID_HANDLE;
    }

    VkBufferCreateInfo bufferInfo = {
        .sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
        .size = size,
        .usage = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT |
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT |
            VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
    };

    VkBuffer buffer = VK_NULL_HANDLE;
    if (pGpu->Api.CreateBuffer(pGpu->Device, &bufferInfo, NULL, &buffer) != VK_SUCCESS)
    {
        _sc_gpu_fail(pGpu, "vkCreateBuffer(%llu) failed", (unsigned long long)size);
        return SC_GPU_INVALID_HANDLE;
    }

    VkMemoryRequirements memoryRequirements;
    pGpu->Api.GetBufferMemoryRequirements(pGpu->Device, buffer, &memoryRequirements);

    VkMemoryPropertyFlags flags = hostVisible
        ? (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)
        : VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;

    u32 memoryType = _sc_gpu_memory_type(pGpu, memoryRequirements.memoryTypeBits, flags);
    if (memoryType == SC_GPU_INVALID_HANDLE)
    {
        pGpu->Api.DestroyBuffer(pGpu->Device, buffer, NULL);
        _sc_gpu_fail(pGpu, "no suitable memory type for buffer (host=%d)", hostVisible);
        return SC_GPU_INVALID_HANDLE;
    }

    VkMemoryAllocateInfo allocInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .allocationSize = memoryRequirements.size,
        .memoryTypeIndex = memoryType,
    };

    VkDeviceMemory memory = VK_NULL_HANDLE;
    if (pGpu->Api.AllocateMemory(pGpu->Device, &allocInfo, NULL, &memory) != VK_SUCCESS)
    {
        pGpu->Api.DestroyBuffer(pGpu->Device, buffer, NULL);
        _sc_gpu_fail(pGpu, "vkAllocateMemory(%llu) failed", (unsigned long long)memoryRequirements.size);
        return SC_GPU_INVALID_HANDLE;
    }

    if (pGpu->Api.BindBufferMemory(pGpu->Device, buffer, memory, 0) != VK_SUCCESS)
    {
        pGpu->Api.FreeMemory(pGpu->Device, memory, NULL);
        pGpu->Api.DestroyBuffer(pGpu->Device, buffer, NULL);
        _sc_gpu_fail(pGpu, "vkBindBufferMemory failed");
        return SC_GPU_INVALID_HANDLE;
    }

    void* pMapped = NULL;
    if (hostVisible)
    {
        if (pGpu->Api.MapMemory(pGpu->Device, memory, 0, VK_WHOLE_SIZE, 0, &pMapped) != VK_SUCCESS)
        {
            pGpu->Api.FreeMemory(pGpu->Device, memory, NULL);
            pGpu->Api.DestroyBuffer(pGpu->Device, buffer, NULL);
            _sc_gpu_fail(pGpu, "vkMapMemory failed");
            return SC_GPU_INVALID_HANDLE;
        }
    }

    u32 index = pGpu->BufferCount;
    for (u32 i = 0; i < pGpu->BufferCount; ++i)
    {
        if (pGpu->aBuffers[i].Size == 0)
        {
            index = i;
            break;
        }
    }
    if (index == pGpu->BufferCount)
        ++pGpu->BufferCount;

    ScGpuBufferSlot* slot = &pGpu->aBuffers[index];
    slot->Buffer = buffer;
    slot->Memory = memory;
    slot->Size = size;
    slot->HostVisible = hostVisible;
    slot->pMapped = pMapped;

    return index;
}

void
sc_gpu_buffer_destroy(ScGpu* pGpu, u32 buffer)
{
    if (!pGpu || buffer >= pGpu->BufferCount)
        return;

    ScGpuBufferSlot* slot = &pGpu->aBuffers[buffer];
    if (slot->pMapped)
    {
        pGpu->Api.UnmapMemory(pGpu->Device, slot->Memory);
        slot->pMapped = NULL;
    }
    if (slot->Buffer)
        pGpu->Api.DestroyBuffer(pGpu->Device, slot->Buffer, NULL);
    if (slot->Memory)
        pGpu->Api.FreeMemory(pGpu->Device, slot->Memory, NULL);
    memset(slot, 0, sizeof(*slot));
}

void*
sc_gpu_buffer_map(ScGpu* pGpu, u32 buffer)
{
    if (!pGpu || buffer >= pGpu->BufferCount)
        return NULL;
    return pGpu->aBuffers[buffer].pMapped;
}

u64
sc_gpu_buffer_size(ScGpu* pGpu, u32 buffer)
{
    if (!pGpu || buffer >= pGpu->BufferCount)
        return 0;
    return pGpu->aBuffers[buffer].Size;
}

i32
sc_gpu_bind_storage(ScGpu* pGpu, u32 binding0, u32 binding1)
{
    if (!pGpu || binding0 >= pGpu->BufferCount || binding1 >= pGpu->BufferCount)
        return _sc_gpu_fail(pGpu, "sc_gpu_bind_storage: invalid buffer handle");

    ScGpuBufferSlot* a = &pGpu->aBuffers[binding0];
    ScGpuBufferSlot* b = &pGpu->aBuffers[binding1];

    VkDescriptorBufferInfo aInfo = {
        .buffer = a->Buffer,
        .offset = 0,
        .range = VK_WHOLE_SIZE,
    };
    VkDescriptorBufferInfo bInfo = {
        .buffer = b->Buffer,
        .offset = 0,
        .range = VK_WHOLE_SIZE,
    };

    VkWriteDescriptorSet aWrite = {
        .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
        .dstSet = pGpu->DescriptorSet,
        .dstBinding = 0,
        .descriptorCount = 1,
        .descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
        .pBufferInfo = &aInfo,
    };
    VkWriteDescriptorSet bWrite = {
        .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
        .dstSet = pGpu->DescriptorSet,
        .dstBinding = 1,
        .descriptorCount = 1,
        .descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
        .pBufferInfo = &bInfo,
    };

    VkWriteDescriptorSet aWrites[2] = { aWrite, bWrite };
    pGpu->Api.UpdateDescriptorSets(pGpu->Device, 2, aWrites, 0, NULL);
    pGpu->HasStorage = 1;
    return 1;
}

static void
_sc_gpu_staging_destroy(ScGpu* pGpu)
{
    if (pGpu->pStaging && pGpu->Api.UnmapMemory)
        pGpu->Api.UnmapMemory(pGpu->Device, pGpu->StagingMemory);
    if (pGpu->StagingBuffer && pGpu->Api.DestroyBuffer)
        pGpu->Api.DestroyBuffer(pGpu->Device, pGpu->StagingBuffer, NULL);
    if (pGpu->StagingMemory && pGpu->Api.FreeMemory)
        pGpu->Api.FreeMemory(pGpu->Device, pGpu->StagingMemory, NULL);

    pGpu->StagingBuffer = VK_NULL_HANDLE;
    pGpu->StagingMemory = VK_NULL_HANDLE;
    pGpu->pStaging = NULL;
    pGpu->StagingSize = 0;
}

static i32
_sc_gpu_staging_ensure(ScGpu* pGpu, u64 size)
{
    if (pGpu->StagingSize >= size && pGpu->pStaging)
        return 1;

    _sc_gpu_staging_destroy(pGpu);

    ScGpuApi* pApi = &pGpu->Api;

    VkBufferCreateInfo bufferInfo = {
        .sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
        .size = size,
        .usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        .sharingMode = VK_SHARING_MODE_EXCLUSIVE,
    };

    if (pApi->CreateBuffer(pGpu->Device, &bufferInfo, NULL, &pGpu->StagingBuffer) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "staging: vkCreateBuffer failed");

    VkMemoryRequirements memoryRequirements;
    pApi->GetBufferMemoryRequirements(pGpu->Device, pGpu->StagingBuffer, &memoryRequirements);

    u32 memoryType = _sc_gpu_memory_type(pGpu, memoryRequirements.memoryTypeBits,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    if (memoryType == SC_GPU_INVALID_HANDLE)
        return _sc_gpu_fail(pGpu, "staging: no host-visible memory type");

    VkMemoryAllocateInfo allocInfo = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
        .allocationSize = memoryRequirements.size,
        .memoryTypeIndex = memoryType,
    };

    if (pApi->AllocateMemory(pGpu->Device, &allocInfo, NULL, &pGpu->StagingMemory) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "staging: vkAllocateMemory failed");

    if (pApi->BindBufferMemory(pGpu->Device, pGpu->StagingBuffer, pGpu->StagingMemory, 0) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "staging: vkBindBufferMemory failed");

    if (pApi->MapMemory(pGpu->Device, pGpu->StagingMemory, 0, VK_WHOLE_SIZE, 0, &pGpu->pStaging) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "staging: vkMapMemory failed");

    pGpu->StagingSize = size;
    return 1;
}

static i32
_sc_gpu_copy_and_wait(ScGpu* pGpu, VkBuffer srcBuffer, u64 srcOffset, VkBuffer dstBuffer,
    u64 dstOffset, u64 size)
{
    ScGpuApi* pApi = &pGpu->Api;

    if (!pGpu->CommandPool || pGpu->IsRecording)
        return _sc_gpu_fail(pGpu, "copy: command buffer is recording");

    if (pApi->ResetCommandPool(pGpu->Device, pGpu->CommandPool, 0) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "copy: vkResetCommandPool failed");

    VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT,
    };
    if (pApi->BeginCommandBuffer(pGpu->Command, &beginInfo) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "copy: vkBeginCommandBuffer failed");

    VkBufferCopy region = {
        .srcOffset = srcOffset,
        .dstOffset = dstOffset,
        .size = size,
    };
    pApi->CmdCopyBuffer(pGpu->Command, srcBuffer, dstBuffer, 1, &region);

    VkMemoryBarrier barrier = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER,
        .srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT,
        .dstAccessMask = VK_ACCESS_HOST_READ_BIT | VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT,
    };
    pApi->CmdPipelineBarrier(pGpu->Command,
        VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT | VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        0, 1, &barrier, 0, NULL, 0, NULL);

    if (pApi->EndCommandBuffer(pGpu->Command) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "copy: vkEndCommandBuffer failed");

    VkSubmitInfo submitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .commandBufferCount = 1,
        .pCommandBuffers = &pGpu->Command,
    };
    if (pApi->QueueSubmit(pGpu->Queue, 1, &submitInfo, VK_NULL_HANDLE) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "copy: vkQueueSubmit failed");
    if (pApi->QueueWaitIdle(pGpu->Queue) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "copy: vkQueueWaitIdle failed");

    return 1;
}

i32
sc_gpu_upload(ScGpu* pGpu, u32 buffer, u64 offset, const void* pData, u64 size)
{
    if (!pGpu || buffer >= pGpu->BufferCount || !pData || size == 0)
        return _sc_gpu_fail(pGpu, "upload: invalid arguments");
    if (offset + size > pGpu->aBuffers[buffer].Size)
        return _sc_gpu_fail(pGpu, "upload: out of range");

    if (!_sc_gpu_staging_ensure(pGpu, size))
        return 0;

    memcpy(pGpu->pStaging, pData, (size_t)size);

    return _sc_gpu_copy_and_wait(pGpu, pGpu->StagingBuffer, 0,
        pGpu->aBuffers[buffer].Buffer, offset, size);
}

i32
sc_gpu_download(ScGpu* pGpu, u32 buffer, u64 offset, void* pData, u64 size)
{
    if (!pGpu || buffer >= pGpu->BufferCount || !pData || size == 0)
        return _sc_gpu_fail(pGpu, "download: invalid arguments");
    if (offset + size > pGpu->aBuffers[buffer].Size)
        return _sc_gpu_fail(pGpu, "download: out of range");

    if (!_sc_gpu_staging_ensure(pGpu, size))
        return 0;

    if (!_sc_gpu_copy_and_wait(pGpu, pGpu->aBuffers[buffer].Buffer, offset,
        pGpu->StagingBuffer, 0, size))
        return 0;

    memcpy(pData, pGpu->pStaging, (size_t)size);
    return 1;
}

static i64
_sc_gpu_file_time(const char* pPath)
{
    struct stat info;
    if (stat(pPath, &info) != 0)
        return -1;
    return (i64)info.st_mtime;
}

static const char*
_sc_gpu_glslc_path(char* pBuffer, i32 size)
{
    const char* pSdk = getenv("VULKAN_SDK");
    if (pSdk && pSdk[0])
    {
#if defined(SC_PLATFORM_WINDOWS)
        snprintf(pBuffer, (size_t)size, "%s\\Bin\\glslc.exe", pSdk);
#else
        snprintf(pBuffer, (size_t)size, "%s/bin/glslc", pSdk);
#endif
        if (_sc_gpu_file_time(pBuffer) >= 0)
            return pBuffer;
    }

#if defined(SC_PLATFORM_WINDOWS)
    return "glslc.exe";
#else
    return "glslc";
#endif
}

static i32
_sc_gpu_compile_shader(ScGpu* pGpu, const char* pDefine, char* pSpvPath, i32 spvPathSize)
{
    char sourcePath[768];
    char binDir[768];
    char compiler[768];

    snprintf(sourcePath, sizeof(sourcePath), "%s/kernels.glsl", pGpu->ShaderDir);
    if (_sc_gpu_file_time(sourcePath) < 0)
        return _sc_gpu_fail(pGpu, "shader source not found: %s", sourcePath);

    snprintf(binDir, sizeof(binDir), "%s/.bin", pGpu->ShaderDir);
    sc_directory_create_recursive(binDir);

    snprintf(pSpvPath, (size_t)spvPathSize, "%s/%s.spv", binDir, pDefine);

    i64 sourceTime = _sc_gpu_file_time(sourcePath);
    i64 spvTime = _sc_gpu_file_time(pSpvPath);
    if (spvTime >= 0 && spvTime >= sourceTime)
        return 1;

    const char* pCompiler = _sc_gpu_glslc_path(compiler, (i32)sizeof(compiler));

    char command[2048];
    snprintf(command, sizeof(command),
        "\"%s\" \"%s\" -DK_%s -fshader-stage=compute -O --target-env=vulkan1.0 -x glsl -o \"%s\" -w",
        pCompiler, sourcePath, pDefine, pSpvPath);

    if (pGpu->Verbose)
        sc_log_info("gpu: %s\n", command);

    i32 result = system(command);
    if (result != 0 || _sc_gpu_file_time(pSpvPath) < 0)
    {
        return _sc_gpu_fail(pGpu,
            "glslc failed for %s (exit %d). Install Vulkan SDK and put glslc in PATH "
            "or set VULKAN_SDK", pDefine, result);
    }

    return 1;
}

u32
sc_gpu_pipeline_new(ScGpu* pGpu, const char* pDefine)
{
    if (!pGpu || !pDefine || !pDefine[0])
        return SC_GPU_INVALID_HANDLE;

    if (pGpu->PipelineCount >= SC_GPU_MAX_PIPELINES)
    {
        _sc_gpu_fail(pGpu, "too many pipelines");
        return SC_GPU_INVALID_HANDLE;
    }

    char spvPath[1024];
    if (!_sc_gpu_compile_shader(pGpu, pDefine, spvPath, (i32)sizeof(spvPath)))
        return SC_GPU_INVALID_HANDLE;

    i64 byteCodeSize = 0;
    char* pByteCode = sc_file_read_ext_ext_r(spvPath, &byteCodeSize);
    if (!pByteCode || byteCodeSize <= 0)
    {
        _sc_gpu_fail(pGpu, "cannot read shader binary %s", spvPath);
        if (pByteCode)
            sc_memory_free(pByteCode);
        return SC_GPU_INVALID_HANDLE;
    }

    VkShaderModuleCreateInfo moduleInfo = {
        .sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
        .codeSize = (size_t)byteCodeSize,
        .pCode = (const u32*)pByteCode,
    };

    VkShaderModule module = VK_NULL_HANDLE;
    VkResult result = pGpu->Api.CreateShaderModule(pGpu->Device, &moduleInfo, NULL, &module);
    sc_memory_free(pByteCode);

    if (result != VK_SUCCESS)
    {
        _sc_gpu_fail(pGpu, "vkCreateShaderModule(%s) failed: %d", pDefine, (i32)result);
        return SC_GPU_INVALID_HANDLE;
    }

    VkPipelineShaderStageCreateInfo stageInfo = {
        .sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
        .stage = VK_SHADER_STAGE_COMPUTE_BIT,
        .module = module,
        .pName = "main",
    };

    VkComputePipelineCreateInfo pipelineInfo = {
        .sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO,
        .stage = stageInfo,
        .layout = pGpu->PipelineLayout,
        .basePipelineHandle = VK_NULL_HANDLE,
        .basePipelineIndex = -1,
    };

    VkPipeline pipeline = VK_NULL_HANDLE;
    result = pGpu->Api.CreateComputePipelines(pGpu->Device, VK_NULL_HANDLE, 1, &pipelineInfo, NULL, &pipeline);
    if (result != VK_SUCCESS)
    {
        pGpu->Api.DestroyShaderModule(pGpu->Device, module, NULL);
        _sc_gpu_fail(pGpu, "vkCreateComputePipelines(%s) failed: %d", pDefine, (i32)result);
        return SC_GPU_INVALID_HANDLE;
    }

    u32 index = pGpu->PipelineCount;
    for (u32 i = 0; i < pGpu->PipelineCount; ++i)
    {
        if (pGpu->aPipelines[i].Name[0] == '\0')
        {
            index = i;
            break;
        }
    }
    if (index == pGpu->PipelineCount)
        ++pGpu->PipelineCount;

    ScGpuPipelineSlot* slot = &pGpu->aPipelines[index];
    slot->Pipeline = pipeline;
    slot->Module = module;
    snprintf(slot->Name, sizeof(slot->Name), "%s", pDefine);

    return index;
}

void
sc_gpu_pipeline_destroy(ScGpu* pGpu, u32 pipeline)
{
    if (!pGpu || pipeline >= pGpu->PipelineCount)
        return;

    ScGpuPipelineSlot* slot = &pGpu->aPipelines[pipeline];
    if (slot->Pipeline)
        pGpu->Api.DestroyPipeline(pGpu->Device, slot->Pipeline, NULL);
    if (slot->Module)
        pGpu->Api.DestroyShaderModule(pGpu->Device, slot->Module, NULL);
    memset(slot, 0, sizeof(*slot));
}

void
sc_gpu_cmd_begin(ScGpu* pGpu)
{
    if (!pGpu || pGpu->IsRecording)
        return;

    if (!pGpu->HasStorage)
    {
        _sc_gpu_fail(pGpu, "sc_gpu_cmd_begin: storage buffers are not bound");
        return;
    }

    pGpu->Api.ResetCommandPool(pGpu->Device, pGpu->CommandPool, 0);

    VkCommandBufferBeginInfo beginInfo = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT,
    };

    if (pGpu->Api.BeginCommandBuffer(pGpu->Command, &beginInfo) != VK_SUCCESS)
    {
        _sc_gpu_fail(pGpu, "vkBeginCommandBuffer failed");
        return;
    }

    pGpu->IsRecording = 1;

    VkMemoryBarrier barrier = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER,
        .srcAccessMask = VK_ACCESS_HOST_WRITE_BIT | VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_TRANSFER_WRITE_BIT,
        .dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT,
    };
    pGpu->Api.CmdPipelineBarrier(pGpu->Command,
        VK_PIPELINE_STAGE_ALL_COMMANDS_BIT | VK_PIPELINE_STAGE_HOST_BIT,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        0, 1, &barrier, 0, NULL, 0, NULL);

    pGpu->Api.CmdBindDescriptorSets(pGpu->Command, VK_PIPELINE_BIND_POINT_COMPUTE,
        pGpu->PipelineLayout, 0, 1, &pGpu->DescriptorSet, 0, NULL);
}

void
sc_gpu_dispatch(ScGpu* pGpu, u32 pipeline, const ScGpuPush* pPush,
    u32 groupX, u32 groupY, u32 groupZ)
{
    if (!pGpu || !pGpu->IsRecording || pipeline >= pGpu->PipelineCount)
        return;

    ScGpuPipelineSlot* slot = &pGpu->aPipelines[pipeline];

    VkMemoryBarrier barrier = {
        .sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER,
        .srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT,
        .dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT,
    };
    pGpu->Api.CmdPipelineBarrier(pGpu->Command,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        0, 1, &barrier, 0, NULL, 0, NULL);

    pGpu->Api.CmdBindPipeline(pGpu->Command, VK_PIPELINE_BIND_POINT_COMPUTE, slot->Pipeline);
    pGpu->Api.CmdPushConstants(pGpu->Command, pGpu->PipelineLayout,
        VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(ScGpuPush), pPush);
    pGpu->Api.CmdDispatch(pGpu->Command, groupX, groupY, groupZ);
}

i32
sc_gpu_cmd_submit(ScGpu* pGpu)
{
    if (!pGpu || !pGpu->IsRecording)
        return 0;

    if (pGpu->Api.EndCommandBuffer(pGpu->Command) != VK_SUCCESS)
    {
        pGpu->IsRecording = 0;
        return _sc_gpu_fail(pGpu, "vkEndCommandBuffer failed");
    }

    pGpu->IsRecording = 0;

    VkSubmitInfo submitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .commandBufferCount = 1,
        .pCommandBuffers = &pGpu->Command,
    };

    if (pGpu->Api.QueueSubmit(pGpu->Queue, 1, &submitInfo, VK_NULL_HANDLE) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vkQueueSubmit failed");

    if (pGpu->Api.QueueWaitIdle(pGpu->Queue) != VK_SUCCESS)
        return _sc_gpu_fail(pGpu, "vkQueueWaitIdle failed");

    return 1;
}
