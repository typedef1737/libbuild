#!/usr/bin/env bash
#
# Обучение TinyLlm на Vulkan (gpu_tiny_llm train) из bin/<build>-linux.
#
# Примеры:
#   ./run_train.sh --easy /data/books
#   ./run_train.sh --bpe bin/books.bpe --corpus /data/books \
#                  --val /data/books-val -o bin/books.ckpt
#   ./run_train.sh --checkpoint bin/books.ckpt --corpus /data/books
#
# Все аргументы передаются в `gpu_tiny_llm train` без изменений.
#
set -euo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd -- "$HERE/../.." && pwd)"
BUILD="${BUILD:-release}"
EXE="$ROOT/bin/$BUILD-linux/gpu_tiny_llm"

if [[ ! -x "$EXE" ]]; then
    echo "[run_train] binary not found: $EXE" >&2
    echo "            build: masuka -b $BUILD -p linux -e gpu_tiny_llm -nr" >&2
    exit 1
fi

if [[ $# -eq 0 ]]; then
    echo "usage: $0 --easy <dir> [extra args]" >&2
    echo "   or: $0 --bpe <file.bpe> --corpus <file|dir> [--val <file|dir>] -o <ckpt> [extra args]" >&2
    echo "  easy:   $0 --easy /data/books" >&2
    echo "  custom: $0 --bpe bin/books.bpe --corpus /data/books --val /data/books-val -o bin/books.ckpt" >&2
    echo "  resume: $0 --checkpoint bin/books.ckpt --corpus /data/books" >&2
    exit 1
fi

exec "$EXE" train "$@"
