#!/usr/bin/env bash
#
# Интерактивный чат/продолжение текста на GPU (gpu_tiny_llm chat).
# Генерация идёт с KV-кэшем.
#
# Примеры:
#   ./run_chat.sh --easy /data/books
#   ./run_chat.sh --checkpoint bin/books.ckpt
#   CKPT=bin/books.ckpt ./run_chat.sh
#   ./run_chat.sh --checkpoint bin/books.ckpt --temp 0.7 --max 80
#
# Команды в чате: пустая строка пропускается, 'exit'/'quit' - выход.
#
set -euo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd -- "$HERE/../.." && pwd)"
BUILD="${BUILD:-release}"
EXE="$ROOT/bin/$BUILD-linux/gpu_tiny_llm"

if [[ ! -x "$EXE" ]]; then
    echo "[run_chat] binary not found: $EXE" >&2
    echo "           build: masuka -b $BUILD -p linux -e gpu_tiny_llm -nr" >&2
    exit 1
fi

if [[ $# -eq 0 ]]; then
    if [[ -n "${EASY:-}" ]]; then
        exec "$EXE" chat --easy "$EASY"
    fi
    if [[ -n "${CKPT:-}" ]]; then
        exec "$EXE" chat --checkpoint "$CKPT"
    fi
    echo "usage: $0 --easy <dir> [--temp F] [--top-k N] [--max N] [--seed N]" >&2
    echo "   or: $0 --checkpoint <ckpt> [--temp F] [--top-k N] [--max N] [--seed N]" >&2
    echo "   or: EASY=<dir> $0" >&2
    echo "   or: CKPT=<ckpt> $0" >&2
    exit 1
fi

exec "$EXE" chat "$@"
