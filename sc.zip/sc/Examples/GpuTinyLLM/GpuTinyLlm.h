#ifndef SC_GPU_TINY_LLM_H
#define SC_GPU_TINY_LLM_H

/*
  GpuTinyLlm - TinyLlm-совместимый трансформер, полностью исполняемый на GPU
  через Vulkan compute (VkGpu).

  Совместимость с CPU-версией:
    * те же пресеты (sc_tiny_llm_model_config_preset);
    * тот же формат чекпоинта (SCTL v1, параметры в том же порядке);
    * те же формулы forward/backward/AdamW/softmax;
    * тот же порядок инициализации весов при одном seed;
    * генерация теми же top-k/top-p правилами и с KV-кэшем: промпт -
      полный forward, дальше по одному токену (decode).

  Матмулы, LayerNorm, GELU, внимание, softmax, AdamW и reduction-ы
  выполняются compute-шейдерами. На CPU остаются: выбор окон, BPE,
  сортировка токенов для scatter-градиента эмбеддингов и сэмплирование.
*/

#include "Sc/TinyLlm.h"
#include "VkGpu.h"

typedef struct ScGpuLlm ScGpuLlm;

// DOCS: Создать модель на устройстве. pConfig нормализуется так же, как в
// sc_tiny_llm_create. Веса инициализируются тем же RNG/Xavier, что на CPU.
ScGpuLlm* sc_gpu_llm_create(ScGpu* pGpu, const ScTinyLlmModelConfig* pConfig);
void sc_gpu_llm_destroy(ScGpuLlm* pModel);

ScTinyLlmModelConfig sc_gpu_llm_config(ScGpuLlm* pModel);
i64 sc_gpu_llm_param_count(ScGpuLlm* pModel);
// DOCS: сколько занимают веса+градиенты+AdamW+активации (без aux).
u64 sc_gpu_llm_memory_bytes(ScGpuLlm* pModel);
// DOCS: сколько реально выделено под оба SSBO (модель + aux).
u64 sc_gpu_llm_total_memory_bytes(ScGpuLlm* pModel);

// DOCS: Загрузить CPU-чекпоинт (SCTL v1) и создать по нему GPU-модель.
// Конфиг берётся из чекпоинта, не из пресета. BPE (если есть) возвращается
// через pOutBpe.
ScGpuLlm* sc_gpu_llm_load_checkpoint(ScGpu* pGpu, const char* pPath, ScAiBpe* pOutBpe);
i32 sc_gpu_llm_save_checkpoint(ScGpuLlm* pModel, ScAiBpe pBpe, const char* pPath);

// DOCS: Валидация. Как sc_tiny_llm_eval: batches окон, выбор start детерминирован
// seed. Возвращает средний loss по валидным токенам.
f32 sc_gpu_llm_eval(ScGpuLlm* pModel, const ScTinyLlmDataset* pDataset,
    i32 batches, ScTinyLlmLossMask lossMask, u64 seed);

// DOCS: Обучение. Повторяет sc_tiny_llm_train: warmup+cosine LR, clip по
// глобальной норме, AdamW, early stopping, RestoreBest, чекпоинты и val CSV.
i32 sc_gpu_llm_train(ScGpuLlm* pModel, ScAiBpe pBpe,
    const ScTinyLlmDataset* pTrain, const ScTinyLlmDataset* pValidation,
    const ScTinyLlmTrainConfig* pConfig);

// DOCS: Генерация с KV-кэшем. Промпт считается полным forward'ом, K/V
// переносятся в кэш, дальше каждый токен - decode с M=1.
// Возвращает ScString (освобождать sc_string_destroy).
char* sc_gpu_llm_generate(ScGpuLlm* pModel, ScAiBpe pBpe, const char* pPrompt,
    const ScTinyLlmGenerateConfig* pConfig);

/*
  Проверка/бенчмарк без CPU-модели.
*/

// DOCS: Loss (сумма по токенам, не среднее) на одном заданном окне.
f32 sc_gpu_llm_eval_window(ScGpuLlm* pModel, const i32* pTokens,
    const i32* pLabels, const i32* pMask, i32 T);

// DOCS: Численная проверка градиентов на GPU: analytic backward vs
// центральная разность по первым maxParams весам каждого параметра.
i32 sc_gpu_llm_grad_check(ScGpuLlm* pModel, const i32* pTokens,
    const i32* pLabels, const i32* pMask, i32 T,
    i32 maxParams, f32 epsilon, f32 tolerance);

#endif // SC_GPU_TINY_LLM_H
