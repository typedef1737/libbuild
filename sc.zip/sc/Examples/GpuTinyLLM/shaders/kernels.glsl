#version 450

/*
  GpuTinyLLM: все compute-ядра в одном файле.

  Каждое ядро собирается отдельно (как шейдеры в Source/Sc/Gfx/Vk.c):

    glslc kernels.glsl -DK_MATMUL_FWD -fshader-stage=compute -O \
          --target-env=vulkan1.0 -o .bin/MATMUL_FWD.spv

  VkGpu.c делает это во время инициализации, кэшируя .spv по времени
  изменения исходника.

  Раскладка буферов:
    binding 0 - device-local буфер модели: weights, grads, AdamW m/v,
                активации и логиты. Все индексы - в float (4 байта).
    binding 1 - host-visible aux: токены, метки, маска, порядок для
                scatter-градиента эмбеддингов, loss-строки, частичные суммы.

  Push constants: 16 uint + 12 float = 112 байт (минимум Vulkan - 128).
  Каждое ядро документирует, что лежит в u0..u15 / f0..f11.
*/

layout(std430, binding = 0) buffer G
{
    float g[];
};

layout(std430, binding = 1) buffer Aux
{
    float aux[];
};

layout(push_constant) uniform PC
{
    uint u0;
    uint u1;
    uint u2;
    uint u3;
    uint u4;
    uint u5;
    uint u6;
    uint u7;
    uint u8;
    uint u9;
    uint u10;
    uint u11;
    uint u12;
    uint u13;
    uint u14;
    uint u15;
    float f0;
    float f1;
    float f2;
    float f3;
    float f4;
    float f5;
    float f6;
    float f7;
    float f8;
    float f9;
    float f10;
    float f11;
} pc;

#define C_GELU_C 0.7978845608028654

/* ############################################################
   fill: g[off .. off+count) = value
   u0=off u1=count f0=value
   ############################################################ */
#ifdef K_FILL
layout(local_size_x = 256) in;
void main()
{
    uint i = gl_GlobalInvocationID.x;
    if (i >= pc.u1)
        return;
    g[pc.u0 + i] = pc.f0;
}
#endif

/* ############################################################
   add/copy: mode 0 - a=b*scale; mode 1 - a+=b*scale
   u0=aOff u1=bOff u2=count u3=mode f0=scale
   ############################################################ */
#ifdef K_ADD
layout(local_size_x = 256) in;
void main()
{
    uint i = gl_GlobalInvocationID.x;
    if (i >= pc.u2)
        return;

    float v = g[pc.u1 + i] * pc.f0;
    if (pc.u3 == 0u)
        g[pc.u0 + i] = v;
    else
        g[pc.u0 + i] += v;
}
#endif

/* ############################################################
   matmul_fwd: C[M,N] = A[M,K] * W[K,N] + bias[N]
   u0=A u1=W u2=C u3=bias u4=M u5=N u6=K u7=hasBias u8=accumulate
   ############################################################ */
#ifdef K_MATMUL_FWD
layout(local_size_x = 16, local_size_y = 16) in;
void main()
{
    uint n = gl_GlobalInvocationID.x;
    uint m = gl_GlobalInvocationID.y;
    uint M = pc.u4, N = pc.u5, K = pc.u6;
    if (m >= M || n >= N)
        return;

    float acc = pc.u7 != 0u ? g[pc.u3 + n] : 0.0;
    uint a = pc.u0 + m * K;
    uint w = pc.u1 + n;
    for (uint k = 0; k < K; ++k)
        acc += g[a + k] * g[w + k * N];

    uint c = pc.u2 + m * N + n;
    if (pc.u8 != 0u)
        g[c] += acc;
    else
        g[c] = acc;
}
#endif

/* ############################################################
   matmul_dw: dW[K,N] += A[M,K]^T * dY[M,N]; dB[N] += sum_m dY[m,n]
   u0=A u1=dY u2=dW u3=dB u4=M u5=N u6=K u7=hasBias
   ############################################################ */
#ifdef K_MATMUL_DW
layout(local_size_x = 16, local_size_y = 16) in;
void main()
{
    uint n = gl_GlobalInvocationID.x;
    uint k = gl_GlobalInvocationID.y;
    uint M = pc.u4, N = pc.u5, K = pc.u6;
    if (k >= K || n >= N)
        return;

    float acc = 0.0;
    float bacc = 0.0;
    for (uint m = 0; m < M; ++m)
    {
        float dy = g[pc.u1 + m * N + n];
        acc += g[pc.u0 + m * K + k] * dy;
        if (pc.u7 != 0u && k == 0u)
            bacc += dy;
    }

    g[pc.u2 + k * N + n] += acc;
    if (pc.u7 != 0u && k == 0u)
        g[pc.u3 + n] += bacc;
}
#endif

/* ############################################################
   matmul_din: dX[M,K] = dY[M,N] * W[K,N]^T
   u0=dY u1=W u2=dX u3=M u4=N u5=K
   ############################################################ */
#ifdef K_MATMUL_DIN
layout(local_size_x = 16, local_size_y = 16) in;
void main()
{
    uint k = gl_GlobalInvocationID.x;
    uint m = gl_GlobalInvocationID.y;
    uint M = pc.u3, N = pc.u4, K = pc.u5;
    if (m >= M || k >= K)
        return;

    float acc = 0.0;
    uint dy = pc.u0 + m * N;
    uint w = pc.u1 + k * N;
    for (uint n = 0; n < N; ++n)
        acc += g[dy + n] * g[w + n];

    g[pc.u2 + m * K + k] = acc;
}
#endif

/* ############################################################
   layernorm forward (одна строка на invocation)
   u0=x u1=y u2=xhat u3=inv u4=gamma u5=beta u6=T u7=D f0=eps
   ############################################################ */
#ifdef K_LN_FWD
layout(local_size_x = 64) in;
void main()
{
    uint t = gl_GlobalInvocationID.x;
    uint T = pc.u6, D = pc.u7;
    if (t >= T)
        return;

    uint xo = pc.u0 + t * D;
    float mean = 0.0;
    for (uint d = 0; d < D; ++d)
        mean += g[xo + d];
    mean /= float(D);

    float var = 0.0;
    for (uint d = 0; d < D; ++d)
    {
        float diff = g[xo + d] - mean;
        var += diff * diff;
    }
    var /= float(D);

    float inv = 1.0 / sqrt(var + pc.f0);
    g[pc.u3 + t] = inv;

    uint yo = pc.u1 + t * D;
    uint ho = pc.u2 + t * D;
    for (uint d = 0; d < D; ++d)
    {
        float xh = (g[xo + d] - mean) * inv;
        g[ho + d] = xh;
        g[yo + d] = xh * g[pc.u4 + d] + g[pc.u5 + d];
    }
}
#endif

/* ############################################################
   layernorm backward (accumulate into dx)
   u0=dy u1=xhat u2=inv u3=gamma u4=dx u5=T u6=D
   ############################################################ */
#ifdef K_LN_BWD
layout(local_size_x = 64) in;
void main()
{
    uint t = gl_GlobalInvocationID.x;
    uint T = pc.u5, D = pc.u6;
    if (t >= T)
        return;

    uint dy = pc.u0 + t * D;
    uint xh = pc.u1 + t * D;
    uint dx = pc.u4 + t * D;

    float meanDy = 0.0;
    float meanDyX = 0.0;
    for (uint d = 0; d < D; ++d)
    {
        float dxhat = g[dy + d] * g[pc.u3 + d];
        meanDy += dxhat;
        meanDyX += dxhat * g[xh + d];
    }
    meanDy /= float(D);
    meanDyX /= float(D);

    float inv = g[pc.u2 + t];
    for (uint d = 0; d < D; ++d)
    {
        float dxhat = g[dy + d] * g[pc.u3 + d];
        g[dx + d] += inv * (dxhat - meanDy - g[xh + d] * meanDyX);
    }
}
#endif

/* ############################################################
   layernorm gamma/beta grads
   u0=dy u1=xhat u2=dg u3=db u4=T u5=D
   ############################################################ */
#ifdef K_LN_PARAM_GRAD
layout(local_size_x = 64) in;
void main()
{
    uint d = gl_GlobalInvocationID.x;
    uint T = pc.u4, D = pc.u5;
    if (d >= D)
        return;

    float dg = 0.0;
    float db = 0.0;
    for (uint t = 0; t < T; ++t)
    {
        float dy = g[pc.u0 + t * D + d];
        dg += dy * g[pc.u1 + t * D + d];
        db += dy;
    }
    g[pc.u2 + d] += dg;
    g[pc.u3 + d] += db;
}
#endif

/* ############################################################
   gelu: mode 0 - y=gelu(x); mode 1 - y *= gelu'(x)
   u0=x u1=y u2=count u3=mode
   ############################################################ */
#ifdef K_GELU
layout(local_size_x = 256) in;
void main()
{
    uint i = gl_GlobalInvocationID.x;
    if (i >= pc.u2)
        return;

    float x = g[pc.u0 + i];
    float x2 = x * x;
    float u = C_GELU_C * (x + 0.044715 * x2 * x);
    float t = tanh(u);

    if (pc.u3 == 0u)
    {
        g[pc.u1 + i] = 0.5 * x * (1.0 + t);
        return;
    }

    float du = C_GELU_C * (1.0 + 3.0 * 0.044715 * x2);
    float d = 0.5 * (1.0 + t) + 0.5 * x * (1.0 - t * t) * du;
    g[pc.u1 + i] *= d;
}
#endif

/* ############################################################
   softmax + cross-entropy по словарю (одна строка на invocation)
   u0=logits u1=lossAux u2=labelAux u3=V u4=mode(1=train) u5=maskAux
   u6=T (обязателен: иначе лишние invocation'ы пишут за пределы слота)
   ############################################################ */
#ifdef K_SOFTMAX_CE
layout(local_size_x = 64) in;
void main()
{
    uint t = gl_GlobalInvocationID.x;
    if (t >= pc.u6)
        return;
    uint V = pc.u3;
    uint lo = pc.u0 + t * V;
    int lab = int(aux[pc.u2 + t]);
    float mask = aux[pc.u5 + t];

    if (lab < 0 || lab >= int(V) || mask < 0.5)
    {
        aux[pc.u1 + t] = 0.0;
        if (pc.u4 != 0u)
        {
            for (uint v = 0; v < V; ++v)
                g[lo + v] = 0.0;
        }
        return;
    }

    float mx = g[lo];
    for (uint v = 1; v < V; ++v)
        mx = max(mx, g[lo + v]);

    float sum = 0.0;
    for (uint v = 0; v < V; ++v)
        sum += exp(g[lo + v] - mx);

    if (sum <= 0.0)
        sum = 1.0;

    float p = exp(g[lo + uint(lab)] - mx) / sum;
    aux[pc.u1 + t] = -log(p + 1e-8);

    if (pc.u4 != 0u)
    {
        for (uint v = 0; v < V; ++v)
            g[lo + v] = exp(g[lo + v] - mx) / sum;
        g[lo + uint(lab)] -= 1.0;
    }
}
#endif

/* ############################################################
   attention scores: C[h,i,j] = scale * sum_d A[h,i,d]*B[h,j,d]
   A: u0=off u5=rowStride u6=colBase
   B: u1=off u7=rowStride u8=colBase
   C: u2=off (раскладка [H,T,T])
   u3=T u4=Dh f0=scale
   ############################################################ */
#ifdef K_ATTN_SCORES
layout(local_size_x = 16, local_size_y = 16) in;
void main()
{
    uint j = gl_GlobalInvocationID.x;
    uint i = gl_GlobalInvocationID.y;
    uint h = gl_GlobalInvocationID.z;
    uint T = pc.u3, Dh = pc.u4;
    if (i >= T || j >= T)
        return;

    uint a = pc.u0 + i * pc.u5 + pc.u6 + h * Dh;
    uint b = pc.u1 + j * pc.u7 + pc.u8 + h * Dh;
    float acc = 0.0;
    for (uint d = 0; d < Dh; ++d)
        acc += g[a + d] * g[b + d];

    g[pc.u2 + (h * T + i) * T + j] = acc * pc.f0;
}
#endif

/* ############################################################
   attention mix forward: C[row, h*Dh+o] = sum_j P[h,row,j] * B[j,...]
   u0=P (раскладка [H,T,T])
   u1=B u7=bRowStride u8=bColBase
   u2=C u9=cRowStride u10=cColBase
   u3=T u4=Dh f0=scale
   ############################################################ */
#ifdef K_ATTN_MIX
layout(local_size_x = 16, local_size_y = 16) in;
void main()
{
    uint o = gl_GlobalInvocationID.x;
    uint row = gl_GlobalInvocationID.y;
    uint h = gl_GlobalInvocationID.z;
    uint T = pc.u3, Dh = pc.u4;
    if (row >= T || o >= Dh)
        return;

    uint a = pc.u0 + (h * T + row) * T;
    uint b = pc.u1 + h * Dh + pc.u8;
    float acc = 0.0;
    for (uint j = 0; j < T; ++j)
        acc += g[a + j] * g[b + j * pc.u7 + o];

    g[pc.u2 + row * pc.u9 + pc.u10 + h * Dh + o] = acc * pc.f0;
}
#endif

/* ############################################################
   causal softmax по строкам [H,T,T]
   u0=probs u1=T u2=H
   ############################################################ */
#ifdef K_ATTN_SOFTMAX
layout(local_size_x = 64) in;
void main()
{
    uint r = gl_GlobalInvocationID.x;
    uint T = pc.u1, H = pc.u2;
    if (r >= H * T)
        return;

    uint h = r / T;
    uint t = r % T;
    uint base = pc.u0 + (h * T + t) * T;

    float mx = -1e30;
    for (uint s = 0; s <= t; ++s)
        mx = max(mx, g[base + s]);

    float sum = 0.0;
    for (uint s = 0; s <= t; ++s)
        sum += exp(g[base + s] - mx);
    if (sum <= 0.0)
        sum = 1.0;

    for (uint s = 0; s <= t; ++s)
        g[base + s] = exp(g[base + s] - mx) / sum;
    for (uint s = t + 1; s < T; ++s)
        g[base + s] = 0.0;
}
#endif

/* ############################################################
   softmax backward: dp = p * (dp - sum(p*dp))  (in-place в dp)
   u0=p u1=dp u2=T u3=H
   ############################################################ */
#ifdef K_ATTN_SOFTMAX_BWD
layout(local_size_x = 64) in;
void main()
{
    uint r = gl_GlobalInvocationID.x;
    uint T = pc.u2, H = pc.u3;
    if (r >= H * T)
        return;

    uint h = r / T;
    uint t = r % T;
    uint p = pc.u0 + (h * T + t) * T;
    uint dp = pc.u1 + (h * T + t) * T;

    float sum = 0.0;
    for (uint s = 0; s <= t; ++s)
        sum += g[p + s] * g[dp + s];

    for (uint s = 0; s <= t; ++s)
        g[dp + s] = g[p + s] * (g[dp + s] - sum);
    for (uint s = t + 1; s < T; ++s)
        g[dp + s] = 0.0;
}
#endif

/* ############################################################
   attention backward: dQ[i,h,d] = sum_{j<=i} K[j,h,d]*dS*scale
   u0=dScore u1=qkv u2=dqkv u3=T u4=Dh
   u5=qkvRowStride u6=dqkvRowStride f0=scale
   ############################################################ */
#ifdef K_ATTN_BWD_DQ
layout(local_size_x = 64) in;
void main()
{
    uint d = gl_GlobalInvocationID.x;
    uint i = gl_GlobalInvocationID.y;
    uint h = gl_GlobalInvocationID.z;
    uint T = pc.u3, Dh = pc.u4;
    if (i >= T || d >= Dh)
        return;

    uint ds = pc.u0 + (h * T + i) * T;
    // DOCS: строка QKV = [Q(D) | K(D) | V(D)], заголовок K начинается с D.
    uint D = pc.u5 / 3u;
    uint kBase = pc.u1 + D + h * Dh;
    float acc = 0.0;
    for (uint j = 0; j <= i; ++j)
        acc += g[kBase + j * pc.u5 + d] * g[ds + j];

    g[pc.u2 + i * pc.u6 + h * Dh + d] = acc * pc.f0;
}
#endif

/* ############################################################
   attention backward: dK[j] = sum_{i>=j} Q[i]*dS*scale
                       dV[j] = sum_{i>=j} dCtx[i]*P
   u0=dScore u1=P u2=dqkv u3=T u4=Dh
   u5=qkvOff u6=dctxOff u7=ctxRowStride
   u8=qkvRowStride u9=dqkvRowStride f0=scale
   ############################################################ */
#ifdef K_ATTN_BWD_DKV
layout(local_size_x = 64) in;
void main()
{
    uint d = gl_GlobalInvocationID.x;
    uint j = gl_GlobalInvocationID.y;
    uint h = gl_GlobalInvocationID.z;
    uint T = pc.u3, Dh = pc.u4;
    if (j >= T || d >= Dh)
        return;

    uint dsRow = pc.u0 + h * T * T;
    uint pRow = pc.u1 + h * T * T;
    uint qBase = pc.u5 + h * Dh;
    uint cBase = pc.u6 + h * Dh;

    float dk = 0.0;
    float dv = 0.0;
    for (uint i = j; i < T; ++i)
    {
        float ds = g[dsRow + i * T + j];
        dk += g[qBase + i * pc.u8 + d] * ds;
        dv += g[cBase + i * pc.u7 + d] * g[pRow + i * T + j];
    }

    // DOCS: QKV-раскладка строки: [Q(D) | K(D) | V(D)]. u7 = D.
    uint D = pc.u7;
    g[pc.u2 + j * pc.u9 + D + h * Dh + d] = dk * pc.f0;
    g[pc.u2 + j * pc.u9 + 2u * D + h * Dh + d] = dv;
}
#endif

/* ############################################################
   embedding gather: x[t] = TokEmb[tok] + PosEmb[posOffset + t]
   u0=tokAux u1=tokEmb u2=posEmb u3=x u4=T u5=D u6=V u7=unk u8=posOffset
   ############################################################ */
#ifdef K_EMB_GATHER
layout(local_size_x = 256) in;
void main()
{
    uint idx = gl_GlobalInvocationID.x;
    uint T = pc.u4, D = pc.u5, V = pc.u6;
    if (idx >= T * D)
        return;

    uint t = idx / D;
    uint d = idx % D;
    int tok = int(aux[pc.u0 + t]);
    if (tok < 0 || tok >= int(V))
        tok = int(pc.u7);

    g[pc.u3 + t * D + d] = g[pc.u1 + uint(tok) * D + d] +
        g[pc.u2 + (pc.u8 + t) * D + d];
}
#endif

/* ############################################################
   token embedding grad (без гонок: одинаковые токены сгруппированы
   на хосте)
   u0=orderAux u1=goffAux u2=U u3=dx u4=D u5=gtokAux u6=dtokGrad
   ############################################################ */
#ifdef K_EMB_TOKEN_GRAD
layout(local_size_x = 256) in;
void main()
{
    uint idx = gl_GlobalInvocationID.x;
    uint U = pc.u2, D = pc.u4;
    if (idx >= U * D)
        return;

    uint gi = idx / D;
    uint d = idx % D;
    uint tok = uint(aux[pc.u5 + gi]);

    uint start = uint(aux[pc.u1 + gi]);
    uint end = uint(aux[pc.u1 + gi + 1]);

    float acc = 0.0;
    for (uint i = start; i < end; ++i)
    {
        uint r = uint(aux[pc.u0 + i]);
        acc += g[pc.u3 + r * D + d];
    }
    g[pc.u6 + tok * D + d] += acc;
}
#endif

/* ############################################################
   positional embedding grad
   u1=dx u2=dpos u3=T u4=D
   ############################################################ */
#ifdef K_EMB_POS_GRAD
layout(local_size_x = 256) in;
void main()
{
    uint idx = gl_GlobalInvocationID.x;
    uint T = pc.u3, D = pc.u4;
    if (idx >= T * D)
        return;

    g[pc.u2 + idx] += g[pc.u1 + idx];
}
#endif

/* ############################################################
   partial sum: каждая workgroup суммирует свою долю диапазона
   u0=src off u1=count u2=dstAuxBase u3=groupCount
   u4=mode(0=sum,1=sum of squares) u5=source(0=g,1=aux)
   ############################################################ */
#ifdef K_PARTIAL_SUM
layout(local_size_x = 256) in;
shared float sdata[256];
void main()
{
    uint tid = gl_LocalInvocationID.x;
    uint group = gl_WorkGroupID.x;
    float s = 0.0;

    for (uint i = group * 256u + tid; i < pc.u1; i += pc.u3 * 256u)
    {
        float v = pc.u5 == 0u ? g[pc.u0 + i] : aux[pc.u0 + i];
        if (pc.u4 == 0u)
            s += v;
        else
            s += v * v;
    }

    sdata[tid] = s;
    barrier();
    for (uint stride = 128u; stride > 0u; stride >>= 1u)
    {
        if (tid < stride)
            sdata[tid] += sdata[tid + stride];
        barrier();
    }
    if (tid == 0u)
        aux[pc.u2 + group] = sdata[0];
}
#endif

/* ############################################################
   reduce partials (один workgroup)
   u0=srcAux off u1=count u2=dstAux u3=mode(0=sum,1=sumsq)
   ############################################################ */
#ifdef K_REDUCE_SUM
layout(local_size_x = 256) in;
shared float sdata[256];
void main()
{
    uint tid = gl_LocalInvocationID.x;
    float s = 0.0;
    for (uint i = tid; i < pc.u1; i += 256u)
    {
        float v = aux[pc.u0 + i];
        if (pc.u3 == 0u)
            s += v;
        else
            s += v * v;
    }

    sdata[tid] = s;
    barrier();
    for (uint stride = 128u; stride > 0u; stride >>= 1u)
    {
        if (tid < stride)
            sdata[tid] += sdata[tid + stride];
        barrier();
    }
    if (tid == 0u)
        aux[pc.u2] = sdata[0];
}
#endif

/* ############################################################
   finalize norm: aux[dst] = sqrt(aux[src])
   u0=srcAux u1=dstAux
   ############################################################ */
#ifdef K_FINALIZE_NORM
layout(local_size_x = 1) in;
void main()
{
    aux[pc.u1] = sqrt(aux[pc.u0]);
}
#endif

/* ############################################################
   grad scale: aux[out] = clip>0 && norm>clip ? clip/(norm+eps) : 1
   u0=normAux u1=outAux f0=clip
   ############################################################ */
#ifdef K_GRAD_SCALE
layout(local_size_x = 1) in;
void main()
{
    float n = aux[pc.u0];
    float s = 1.0;
    if (pc.f0 > 0.0 && n > pc.f0)
        s = pc.f0 / n;
    aux[pc.u1] = s;
}
#endif

/* ############################################################
   AdamW (индексы data/grad/m/v параллельны)
   u0=data u1=grad u2=m u3=v u4=count u5=scaleAux
   f0=lr f1=wd f2=b1 f3=b2 f4=bc1 f5=bc2 f6=eps f7=invBatch
   ############################################################ */
#ifdef K_ADAMW
layout(local_size_x = 256) in;
void main()
{
    uint i = gl_GlobalInvocationID.x;
    if (i >= pc.u4)
        return;

    float grad = g[pc.u1 + i] * aux[pc.u5] * pc.f7;
    float m = pc.f2 * g[pc.u2 + i] + (1.0 - pc.f2) * grad;
    float v = pc.f3 * g[pc.u3 + i] + (1.0 - pc.f3) * grad * grad;
    g[pc.u2 + i] = m;
    g[pc.u3 + i] = v;

    float update = (m / pc.f4) / (sqrt(v / pc.f5) + pc.f6) + pc.f1 * g[pc.u0 + i];
    g[pc.u0 + i] -= pc.f0 * update;
    g[pc.u1 + i] = 0.0;
}
#endif

/* ############################################################
   argmax последней строки логитов (для greedy-генерации).
   u0=logits u1=V u2=row u3=outAux
   ############################################################ */
#ifdef K_ARGMAX_ROW
layout(local_size_x = 256) in;
shared float sBest[256];
shared uint sIndex[256];
void main()
{
    uint tid = gl_LocalInvocationID.x;
    uint base = pc.u0 + pc.u2 * pc.u1;

    float best = -1e30;
    uint bestIndex = 0;
    for (uint v = tid; v < pc.u1; v += 256u)
    {
        float x = g[base + v];
        if (x > best)
        {
            best = x;
            bestIndex = v;
        }
    }

    sBest[tid] = best;
    sIndex[tid] = bestIndex;
    barrier();

    for (uint stride = 128u; stride > 0u; stride >>= 1u)
    {
        if (tid < stride)
        {
            if (sBest[tid + stride] > sBest[tid])
            {
                sBest[tid] = sBest[tid + stride];
                sIndex[tid] = sIndex[tid + stride];
            }
        }
        barrier();
    }

    if (tid == 0u)
        aux[pc.u3] = float(sIndex[0]);
}
#endif

/* ============================================================
   KV-кэш (генерация)

   Раскладка кэша на слой: KCache[pos*D + h*Dh + d], VCache так же.
   Позиции 0..pos уже посчитаны; строка QKV = [Q(D)|K(D)|V(D)].
   ============================================================ */

/* ############################################################
   kv_append: скопировать K/V одной строки QKV в кэш
   u0=qkv u1=srcRow u2=srcRowStride u3=D u4=kCache u5=vCache u6=dstPos
   ############################################################ */
#ifdef K_KV_APPEND
layout(local_size_x = 256) in;
void main()
{
    uint idx = gl_GlobalInvocationID.x;
    if (idx >= pc.u3)
        return;

    uint q = pc.u0 + pc.u1 * pc.u2;
    g[pc.u4 + pc.u6 * pc.u3 + idx] = g[q + pc.u3 + idx];
    g[pc.u5 + pc.u6 * pc.u3 + idx] = g[q + 2u * pc.u3 + idx];
}
#endif

/* ############################################################
   kv_fill: скопировать K/V всех T позиций префилла в кэш
   u0=qkv u1=kCache u2=vCache u3=T u4=D u5=qkvRowStride
   ############################################################ */
#ifdef K_KV_FILL
layout(local_size_x = 256) in;
void main()
{
    uint idx = gl_GlobalInvocationID.x;
    if (idx >= pc.u3 * pc.u4)
        return;

    uint t = idx / pc.u4;
    uint d = idx % pc.u4;
    uint q = pc.u0 + t * pc.u5;

    g[pc.u1 + idx] = g[q + pc.u4 + d];
    g[pc.u2 + idx] = g[q + 2u * pc.u4 + d];
}
#endif

/* ############################################################
   attention scores для одной строки Q по KV-кэшу
   u0=qkv u1=probs u2=Tctx u3=D u4=Dh u5=qRow u6=qStride
   u7=posMax u8=kCache f0=scale
   ############################################################ */
#ifdef K_ATTN_SCORES1
layout(local_size_x = 64) in;
void main()
{
    uint j = gl_GlobalInvocationID.x;
    uint h = gl_GlobalInvocationID.y;
    if (j > pc.u7)
        return;

    uint q = pc.u0 + pc.u5 * pc.u6 + h * pc.u4;
    uint k = pc.u8 + j * pc.u3 + h * pc.u4;

    float acc = 0.0;
    for (uint d = 0; d < pc.u4; ++d)
        acc += g[q + d] * g[k + d];

    g[pc.u1 + h * pc.u2 * pc.u2 + j] = acc * pc.f0;
}
#endif

/* ############################################################
   softmax по одной строке KV-кэша (0..posMax)
   u0=probs u1=Tctx u2=posMax
   ############################################################ */
#ifdef K_ATTN_SOFTMAX1
layout(local_size_x = 1) in;
void main()
{
    uint h = gl_GlobalInvocationID.x;
    uint base = pc.u0 + h * pc.u1 * pc.u1;

    float mx = -1e30;
    for (uint j = 0; j <= pc.u2; ++j)
        mx = max(mx, g[base + j]);

    float sum = 0.0;
    for (uint j = 0; j <= pc.u2; ++j)
        sum += exp(g[base + j] - mx);
    if (sum <= 0.0)
        sum = 1.0;

    for (uint j = 0; j <= pc.u2; ++j)
        g[base + j] = exp(g[base + j] - mx) / sum;
}
#endif

/* ############################################################
   mix для одной строки Q: ctx[h*Dh+o] = sum_j P[h,j]*V[j]
   u0=probs u1=vCache u2=ctx u3=Tctx u4=Dh u5=D u6=posMax
   ############################################################ */
#ifdef K_ATTN_MIX1
layout(local_size_x = 64) in;
void main()
{
    uint o = gl_GlobalInvocationID.x;
    uint h = gl_GlobalInvocationID.y;
    if (o >= pc.u4)
        return;

    uint p = pc.u0 + h * pc.u3 * pc.u3;
    uint v = pc.u1 + h * pc.u4 + o;

    float acc = 0.0;
    for (uint j = 0; j <= pc.u6; ++j)
        acc += g[p + j] * g[v + j * pc.u5];

    g[pc.u2 + h * pc.u4 + o] = acc;
}
#endif
