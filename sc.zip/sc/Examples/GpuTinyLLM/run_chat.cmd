@echo off
rem Interactive chat / text continuation on GPU (gpu_tiny_llm chat).
rem Generation uses the KV cache.
rem Examples:
rem   run_chat.cmd --checkpoint bin\books.ckpt
rem   set CKPT=bin\books.ckpt ^& run_chat.cmd
rem   run_chat.cmd --checkpoint bin\books.ckpt --temp 0.7 --max 80
rem Commands: empty line is skipped, 'exit'/'quit' quits.
setlocal
for %%I in ("%~dp0..\..") do set "ROOT=%%~fI"
if "%BUILD%"=="" set "BUILD=release"
set "EXE=%ROOT%\bin\%BUILD%-windows\gpu_tiny_llm.exe"

if not exist "%EXE%" (
    echo [run_chat] binary not found: %EXE%
    echo            build: masuka -b %BUILD% -p windows -e gpu_tiny_llm -nr
    exit /b 1
)

if not "%~1"=="" goto :run_args
if not "%CKPT%"=="" goto :run_ckpt

echo usage: %~nx0 --checkpoint ^<ckpt^> [--temp F] [--top-k N] [--max N] [--seed N]
echo   or:  set CKPT=^<ckpt^> ^& %~nx0
exit /b 1

:run_ckpt
"%EXE%" chat --checkpoint "%CKPT%"
exit /b %ERRORLEVEL%

:run_args
"%EXE%" chat %*
exit /b %ERRORLEVEL%
