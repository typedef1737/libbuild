@echo off
rem Train BPE vocabulary (bpe_train) from bin\<build>-windows.
rem Example: run_bpe.cmd D:\books -o D:\books\books.bpe -m 8192
setlocal
for %%I in ("%~dp0..\..") do set "ROOT=%%~fI"
if "%BUILD%"=="" set "BUILD=release"
set "EXE=%ROOT%\bin\%BUILD%-windows\bpe_train.exe"

if not exist "%EXE%" (
    echo [run_bpe] binary not found: %EXE%
    echo           build: masuka -b %BUILD% -p windows -e bpe_train -nr
    exit /b 1
)

if "%~1"=="" (
    echo usage: %~nx0 ^<corpus-dir^> [-o out.bpe] [-m merges] [extra args]
    echo   example: %~nx0 D:\books -o D:\books\books.bpe -m 8192
    exit /b 1
)

"%EXE%" %*
exit /b %ERRORLEVEL%
