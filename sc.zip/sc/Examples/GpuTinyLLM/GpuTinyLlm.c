#include "GpuTinyLlm.h"

#include "Sc/Sc.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
  GpuTinyLlm: все вычислительные шаги TinyLlm на Vulkan compute.

  Раскладка большого SSBO (индексы в float):

    [ Data | Grad | AdamM | AdamV | Activations ]

  Data/Grad/M/V - параллельные блоки: у параметра p один и тот же Index
  во всех четырёх блоках. Это позволяет считать норму градиента и делать
  AdamW одним dispatch'ем по всему блоку.

  Aux SSBO (host-visible) разбит на слоты по batch. В слоте лежат токены,
  метки, маска, порядок для scatter-градиента эмбеддингов, loss-строки.
  Это нужно, чтобы записать весь batch в один command buffer и отправить
  его одним submit'ом.
*/

#define SC_GPU_LLM_MAX_LAYERS 32
#define SC_GPU_LLM_MAX_PARAMS (6 + 12 * SC_GPU_LLM_MAX_LAYERS)
#define SC_GPU_LLM_MAX_BATCH 64
#define SC_GPU_LLM_LOSS_GROUPS 8
#define SC_GPU_LLM_NORM_GROUPS 64
#define SC_GPU_LLM_LN_EPS 1e-5f
#define SC_GPU_LLM_GELU_C 0.7978845608028654f

typedef enum
{
    ScGpuPipe_Fill = 0,
    ScGpuPipe_Add,
    ScGpuPipe_MatmulFwd,
    ScGpuPipe_MatmulDw,
    ScGpuPipe_MatmulDin,
    ScGpuPipe_LnFwd,
    ScGpuPipe_LnBwd,
    ScGpuPipe_LnParamGrad,
    ScGpuPipe_Gelu,
    ScGpuPipe_SoftmaxCe,
    ScGpuPipe_AttnScores,
    ScGpuPipe_AttnMix,
    ScGpuPipe_AttnSoftmax,
    ScGpuPipe_AttnSoftmaxBwd,
    ScGpuPipe_AttnBwdDq,
    ScGpuPipe_AttnBwdDkv,
    ScGpuPipe_EmbGather,
    ScGpuPipe_EmbTokenGrad,
    ScGpuPipe_EmbPosGrad,
    ScGpuPipe_PartialSum,
    ScGpuPipe_ReduceSum,
    ScGpuPipe_FinalizeNorm,
    ScGpuPipe_GradScale,
    ScGpuPipe_AdamW,
    ScGpuPipe_ArgmaxRow,
    // KV-кэш для генерации.
    ScGpuPipe_KvAppend,
    ScGpuPipe_KvFill,
    ScGpuPipe_AttnScores1,
    ScGpuPipe_AttnSoftmax1,
    ScGpuPipe_AttnMix1,
    ScGpuPipe_Count
} ScGpuPipe;

static const char* c_sc_gpu_llm_pipeline_names[ScGpuPipe_Count] = {
    "FILL",
    "ADD",
    "MATMUL_FWD",
    "MATMUL_DW",
    "MATMUL_DIN",
    "LN_FWD",
    "LN_BWD",
    "LN_PARAM_GRAD",
    "GELU",
    "SOFTMAX_CE",
    "ATTN_SCORES",
    "ATTN_MIX",
    "ATTN_SOFTMAX",
    "ATTN_SOFTMAX_BWD",
    "ATTN_BWD_DQ",
    "ATTN_BWD_DKV",
    "EMB_GATHER",
    "EMB_TOKEN_GRAD",
    "EMB_POS_GRAD",
    "PARTIAL_SUM",
    "REDUCE_SUM",
    "FINALIZE_NORM",
    "GRAD_SCALE",
    "ADAMW",
    "ARGMAX_ROW",
    "KV_APPEND",
    "KV_FILL",
    "ATTN_SCORES1",
    "ATTN_SOFTMAX1",
    "ATTN_MIX1",
};

typedef struct
{
    u32 Index;
    i64 Count;
    f32 InitLimit;
    i32 IsGamma;
    char Name[32];
} ScGpuLlmParam;

typedef struct
{
    u32 Ln1Y;
    u32 Ln1Xhat;
    u32 Ln1InvStd;
    u32 Qkv;
    u32 Probs;
    u32 AttnCtx;
    u32 Ln2Y;
    u32 Ln2Xhat;
    u32 Ln2InvStd;
    u32 Fc1Pre;
    u32 Fc1Act;
} ScGpuLlmLayer;

struct ScGpuLlm
{
    ScGpu* pGpu;
    ScTinyLlmModelConfig Cfg;

    i32 L;
    i32 D;
    i32 V;
    i32 F;
    i32 T;
    i32 H;
    i32 Dh;

    i32 NumParams;
    i64 TotalParams;
    ScGpuLlmParam aParams[SC_GPU_LLM_MAX_PARAMS];

    u32 DataOff;
    u32 GradOff;
    u32 MOff;
    u32 VOff;
    u64 TotalFloats;

    ScGpuLlmLayer aLayers[SC_GPU_LLM_MAX_LAYERS];

    u32 X;
    u32 Tmp;
    u32 FinalY;
    u32 FinalXhat;
    u32 FinalInvStd;
    u32 Logits;
    u32 DProb;
    u32 DX;
    u32 DCur;
    u32 DNorm;
    u32 DAttnCtx;
    u32 DQkv;
    u32 DFc1;

    // DOCS: KV-кэш генерации: по L*T*D float на K и на V.
    u32 KCache;
    u32 VCache;

    u32 GBuffer;
    u32 AuxBuffer;
    u32 SlotStride;
    u32 TokOff;
    u32 LabOff;
    u32 MaskOff;
    u32 OrderOff;
    u32 GOffOff;
    u32 GTokOff;
    u32 LossOff;
    u32 AuxLossPartials;
    u32 AuxNormPartials;
    u32 AuxNormSq;
    u32 AuxNorm;
    u32 AuxScale;
    u32 AuxLossSum;
    u32 AuxFloats;
    f32* pAux;

    u32 aPipes[ScGpuPipe_Count];

    i32* aTokens;
    i32* aLabels;
    i32* aMask;
    i32* aOrder;
    i32* aGOff;
    i32* aGTok;
};

typedef struct
{
    f32 Prob;
    i32 Index;
} ScGpuLlmCandidate;

static u64
_sc_gpu_llm_rng_next(u64* pState)
{
    u64 x = *pState;
    if (x == 0)
        x = 0x9e3779b97f4a7c15ULL;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *pState = x;
    return x;
}

static f32
_sc_gpu_llm_rng_f32(u64* pState)
{
    u64 value = _sc_gpu_llm_rng_next(pState) >> 40;
    return (f32)value / 16777216.0f;
}

static f32
_sc_gpu_llm_xavier_limit(i32 fanIn, i32 fanOut)
{
    if (fanIn <= 0 || fanOut <= 0)
        return 0.02f;
    return sqrtf(6.0f / (f32)(fanIn + fanOut));
}

static ScGpuPush
_sc_gpu_llm_push_zero(void)
{
    ScGpuPush p;
    memset(&p, 0, sizeof(p));
    return p;
}

static u32
_sc_gpu_llm_grid256(i64 count)
{
    if (count <= 0)
        return 1;
    return (u32)((count + 255) / 256);
}

static u32
_sc_gpu_llm_grid64(i64 count)
{
    if (count <= 0)
        return 1;
    return (u32)((count + 63) / 64);
}

static u32
_sc_gpu_llm_grid16(i64 count)
{
    if (count <= 0)
        return 1;
    return (u32)((count + 15) / 16);
}

static void
_sc_gpu_llm_add_param(ScGpuLlm* pModel, i64 count, f32 initLimit, i32 isGamma,
    const char* pName)
{
    sc_assert(pModel->NumParams < SC_GPU_LLM_MAX_PARAMS);
    ScGpuLlmParam* p = &pModel->aParams[pModel->NumParams++];
    p->Index = (u32)pModel->TotalParams;
    p->Count = count;
    p->InitLimit = initLimit;
    p->IsGamma = isGamma;
    snprintf(p->Name, sizeof(p->Name), "%s", pName);
    pModel->TotalParams += count;
}

static u32
_sc_gpu_llm_param_data(ScGpuLlm* pModel, i32 index)
{
    return pModel->DataOff + pModel->aParams[index].Index;
}

static u32
_sc_gpu_llm_param_grad(ScGpuLlm* pModel, i32 index)
{
    return pModel->GradOff + pModel->aParams[index].Index;
}

static void
_sc_gpu_llm_free_host(ScGpuLlm* pModel)
{
    if (!pModel)
        return;

    sc_memory_free(pModel->aTokens);
    sc_memory_free(pModel->aLabels);
    sc_memory_free(pModel->aMask);
    sc_memory_free(pModel->aOrder);
    sc_memory_free(pModel->aGOff);
    sc_memory_free(pModel->aGTok);
}

static ScGpuLlm*
_sc_gpu_llm_create_ext(ScGpu* pGpu, const ScTinyLlmModelConfig* pConfig, i32 initWeights)
{
    if (!pGpu || !pConfig)
        return NULL;

    ScTinyLlmModelConfig cfg = *pConfig;
    if (cfg.NumLayers <= 0)
        cfg.NumLayers = 2;
    if (cfg.DModel <= 0)
        cfg.DModel = 64;
    if (cfg.NumHeads <= 0)
        cfg.NumHeads = 2;
    if (cfg.DFf <= 0)
        cfg.DFf = cfg.DModel * 4;
    if (cfg.ContextLength <= 0)
        cfg.ContextLength = 128;
    if (cfg.VocabCount < (i32)ScAiSpecialToken_Sit + 1)
        cfg.VocabCount = (i32)ScAiSpecialToken_Sit + 1;
    if (cfg.InitStd <= 0.0f)
        cfg.InitStd = 0.02f;
    if (cfg.Seed == 0)
        cfg.Seed = 0x9e3779b97f4a7c15ULL;

    if (cfg.DModel % cfg.NumHeads != 0)
    {
        sc_log_erro("gpu-llm: DModel (%d) must be divisible by NumHeads (%d)\n",
            cfg.DModel, cfg.NumHeads);
        return NULL;
    }

    if (cfg.NumLayers > SC_GPU_LLM_MAX_LAYERS)
    {
        sc_log_erro("gpu-llm: too many layers (%d > %d)\n", cfg.NumLayers, SC_GPU_LLM_MAX_LAYERS);
        return NULL;
    }

    if (sc_gpu_max_workgroup_invocations(pGpu) < 256)
    {
        sc_log_erro("gpu-llm: device supports only %u invocations per workgroup, need 256\n",
            sc_gpu_max_workgroup_invocations(pGpu));
        return NULL;
    }

    ScGpuLlm* pModel = sc_memory_allocate(sizeof(ScGpuLlm));
    if (!pModel)
        return NULL;
    memset(pModel, 0, sizeof(ScGpuLlm));
    pModel->pGpu = pGpu;
    pModel->Cfg = cfg;
    pModel->GBuffer = SC_GPU_INVALID_HANDLE;
    pModel->AuxBuffer = SC_GPU_INVALID_HANDLE;
    for (i32 i = 0; i < ScGpuPipe_Count; ++i)
        pModel->aPipes[i] = SC_GPU_INVALID_HANDLE;

    pModel->L = cfg.NumLayers;
    pModel->D = cfg.DModel;
    pModel->V = cfg.VocabCount;
    pModel->F = cfg.DFf;
    pModel->T = cfg.ContextLength;
    pModel->H = cfg.NumHeads;
    pModel->Dh = cfg.DModel / cfg.NumHeads;

    i32 L = pModel->L;
    i32 D = pModel->D;
    i32 V = pModel->V;
    i32 F = pModel->F;
    i32 T = pModel->T;

    u64 seed = cfg.Seed;
    f32 embLimit = cfg.InitStd;
    f32 qkvLimit = _sc_gpu_llm_xavier_limit(D, 3 * D);
    f32 projLimit = _sc_gpu_llm_xavier_limit(D, D);
    f32 fc1Limit = _sc_gpu_llm_xavier_limit(D, F);
    f32 fc2Limit = _sc_gpu_llm_xavier_limit(F, D);
    f32 lmLimit = _sc_gpu_llm_xavier_limit(D, V);

    // DOCS: порядок параметров повторяет sc_tiny_llm_create - от него зависит
    // формат чекпоинта и точное совпадение RNG-инициализации.
    _sc_gpu_llm_add_param(pModel, (i64)V * D, embLimit, 0, "TokEmb");
    _sc_gpu_llm_add_param(pModel, (i64)T * D, embLimit, 0, "PosEmb");
    _sc_gpu_llm_add_param(pModel, D, 0.0f, 1, "FinalLnG");
    _sc_gpu_llm_add_param(pModel, D, 0.0f, 0, "FinalLnB");
    _sc_gpu_llm_add_param(pModel, (i64)D * V, lmLimit, 0, "LmHeadW");
    _sc_gpu_llm_add_param(pModel, V, 0.0f, 0, "LmHeadB");

    for (i32 l = 0; l < L; ++l)
    {
        char name[32];
        snprintf(name, sizeof(name), "L%d.Ln1G", l);  _sc_gpu_llm_add_param(pModel, D, 0.0f, 1, name);
        snprintf(name, sizeof(name), "L%d.Ln1B", l);  _sc_gpu_llm_add_param(pModel, D, 0.0f, 0, name);
        snprintf(name, sizeof(name), "L%d.QkvW", l);  _sc_gpu_llm_add_param(pModel, (i64)D * 3 * D, qkvLimit, 0, name);
        snprintf(name, sizeof(name), "L%d.QkvB", l);  _sc_gpu_llm_add_param(pModel, 3 * D, 0.0f, 0, name);
        snprintf(name, sizeof(name), "L%d.ProjW", l); _sc_gpu_llm_add_param(pModel, (i64)D * D, projLimit, 0, name);
        snprintf(name, sizeof(name), "L%d.ProjB", l); _sc_gpu_llm_add_param(pModel, D, 0.0f, 0, name);
        snprintf(name, sizeof(name), "L%d.Ln2G", l);  _sc_gpu_llm_add_param(pModel, D, 0.0f, 1, name);
        snprintf(name, sizeof(name), "L%d.Ln2B", l);  _sc_gpu_llm_add_param(pModel, D, 0.0f, 0, name);
        snprintf(name, sizeof(name), "L%d.Fc1W", l);  _sc_gpu_llm_add_param(pModel, (i64)D * F, fc1Limit, 0, name);
        snprintf(name, sizeof(name), "L%d.Fc1B", l);  _sc_gpu_llm_add_param(pModel, F, 0.0f, 0, name);
        snprintf(name, sizeof(name), "L%d.Fc2W", l);  _sc_gpu_llm_add_param(pModel, (i64)F * D, fc2Limit, 0, name);
        snprintf(name, sizeof(name), "L%d.Fc2B", l);  _sc_gpu_llm_add_param(pModel, D, 0.0f, 0, name);
    }

    // DOCS: проверяем размер до 32-битных смещений (шейдеры индексируют
    // float-массив через uint).
    if (pModel->TotalParams > 0x3fffffffLL)
    {
        sc_log_erro("gpu-llm: model is too large for 32-bit float offsets\n");
        sc_memory_free(pModel);
        return NULL;
    }

    // DOCS: активации лежат ПОСЛЕ четырёх блоков параметров
    // [Data | Grad | M | V]. actCursor считаем в u64, чтобы поймать
    // переполнение 32-битных индексов до создания буфера.
    u64 actCursor = 4 * (u64)pModel->TotalParams;
#define SC_GPU_LLM_ALLOC(field, count) \
    do { (field) = (u32)actCursor; actCursor += (u64)(count); } while (0)

    SC_GPU_LLM_ALLOC(pModel->X, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->Tmp, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->FinalY, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->FinalXhat, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->FinalInvStd, T);
    SC_GPU_LLM_ALLOC(pModel->Logits, (i64)T * V);
    SC_GPU_LLM_ALLOC(pModel->DProb, (i64)pModel->H * T * T);
    SC_GPU_LLM_ALLOC(pModel->DX, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->DCur, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->DNorm, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->DAttnCtx, (i64)T * D);
    SC_GPU_LLM_ALLOC(pModel->DQkv, (i64)T * 3 * D);
    SC_GPU_LLM_ALLOC(pModel->DFc1, (i64)T * F);
    SC_GPU_LLM_ALLOC(pModel->KCache, (i64)L * T * D);
    SC_GPU_LLM_ALLOC(pModel->VCache, (i64)L * T * D);

    for (i32 l = 0; l < L; ++l)
    {
        ScGpuLlmLayer* pLayer = &pModel->aLayers[l];
        SC_GPU_LLM_ALLOC(pLayer->Ln1Y, (i64)T * D);
        SC_GPU_LLM_ALLOC(pLayer->Ln1Xhat, (i64)T * D);
        SC_GPU_LLM_ALLOC(pLayer->Ln1InvStd, T);
        SC_GPU_LLM_ALLOC(pLayer->Qkv, (i64)T * 3 * D);
        SC_GPU_LLM_ALLOC(pLayer->Probs, (i64)pModel->H * T * T);
        SC_GPU_LLM_ALLOC(pLayer->AttnCtx, (i64)T * D);
        SC_GPU_LLM_ALLOC(pLayer->Ln2Y, (i64)T * D);
        SC_GPU_LLM_ALLOC(pLayer->Ln2Xhat, (i64)T * D);
        SC_GPU_LLM_ALLOC(pLayer->Ln2InvStd, T);
        SC_GPU_LLM_ALLOC(pLayer->Fc1Pre, (i64)T * F);
        SC_GPU_LLM_ALLOC(pLayer->Fc1Act, (i64)T * F);
    }
#undef SC_GPU_LLM_ALLOC

    if (actCursor > 0xffffffffULL)
    {
        sc_log_erro("gpu-llm: activations exceed 32-bit float offsets\n");
        sc_memory_free(pModel);
        return NULL;
    }

    pModel->DataOff = 0;
    pModel->GradOff = (u32)pModel->TotalParams;
    pModel->MOff = (u32)(2 * pModel->TotalParams);
    pModel->VOff = (u32)(3 * pModel->TotalParams);
    // DOCS: actCursor уже включает 4 * TotalParams (см. выше).
    pModel->TotalFloats = (u64)actCursor;

    // DOCS: самый большой gridX дают fill/adamw по блоку параметров
    // (ceil(TotalParams / 256)); остальные dispatch'и меньше. Проверяем
    // лимит устройства (минимум по спеке - 65535).
    u32 maxGroupsX = sc_gpu_max_workgroup_count_x(pGpu);
    u64 neededGroupsX = (pModel->TotalParams + 255) / 256;
    if (maxGroupsX > 0 && neededGroupsX > maxGroupsX)
    {
        sc_log_erro("gpu-llm: dispatch needs %llu workgroups in X, device allows %u\n",
            (unsigned long long)neededGroupsX, maxGroupsX);
        sc_memory_free(pModel);
        return NULL;
    }

    u64 totalBytes = pModel->TotalFloats * sizeof(f32);
    u32 maxRange = sc_gpu_max_storage_range(pGpu);
    if (maxRange > 0 && totalBytes > (u64)maxRange)
    {
        sc_log_erro("gpu-llm: model needs %.1f MB, but maxStorageBufferRange is %.1f MB\n",
            (f64)totalBytes / (1024.0 * 1024.0), (f64)maxRange / (1024.0 * 1024.0));
        sc_memory_free(pModel);
        return NULL;
    }

    // DOCS: host-visible aux: по слоту на каждый sample в batch.
    pModel->SlotStride = 8 * (u32)T + 8;
    pModel->TokOff = 0;
    pModel->LabOff = (u32)T;
    pModel->MaskOff = 2 * (u32)T;
    pModel->OrderOff = 3 * (u32)T;
    pModel->GOffOff = 4 * (u32)T;
    pModel->GTokOff = 5 * (u32)T + 1;
    pModel->LossOff = 6 * (u32)T + 1;
    pModel->AuxLossPartials = SC_GPU_LLM_MAX_BATCH * pModel->SlotStride;
    pModel->AuxNormPartials = pModel->AuxLossPartials + SC_GPU_LLM_MAX_BATCH * SC_GPU_LLM_LOSS_GROUPS;
    pModel->AuxNormSq = pModel->AuxNormPartials + SC_GPU_LLM_NORM_GROUPS;
    pModel->AuxNorm = pModel->AuxNormSq + 1;
    pModel->AuxScale = pModel->AuxNorm + 1;
    pModel->AuxLossSum = pModel->AuxScale + 1;
    pModel->AuxFloats = pModel->AuxLossSum + 8;

    pModel->GBuffer = sc_gpu_buffer_new(pGpu, totalBytes, 0);
    pModel->AuxBuffer = sc_gpu_buffer_new(pGpu, (u64)pModel->AuxFloats * sizeof(f32), 1);
    if (pModel->GBuffer == SC_GPU_INVALID_HANDLE || pModel->AuxBuffer == SC_GPU_INVALID_HANDLE)
        goto Failed;

    if (!sc_gpu_bind_storage(pGpu, pModel->GBuffer, pModel->AuxBuffer))
        goto Failed;

    pModel->pAux = (f32*)sc_gpu_buffer_map(pGpu, pModel->AuxBuffer);
    if (!pModel->pAux)
        goto Failed;
    memset(pModel->pAux, 0, (size_t)pModel->AuxFloats * sizeof(f32));

    if (initWeights)
    {
        f32* pHost = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
        if (!pHost)
            goto Failed;

        i64 cursor = 0;
        for (i32 p = 0; p < pModel->NumParams; ++p)
        {
            ScGpuLlmParam* param = &pModel->aParams[p];
            for (i64 i = 0; i < param->Count; ++i)
                pHost[cursor + i] = (_sc_gpu_llm_rng_f32(&seed) * 2.0f - 1.0f) * param->InitLimit;
            if (param->IsGamma)
            {
                for (i64 i = 0; i < param->Count; ++i)
                    pHost[cursor + i] = 1.0f;
            }
            cursor += param->Count;
        }

        if (!sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->DataOff * sizeof(f32),
            pHost, (u64)pModel->TotalParams * sizeof(f32)))
        {
            sc_memory_free(pHost);
            goto Failed;
        }
        memset(pHost, 0, (size_t)pModel->TotalParams * sizeof(f32));

        if (!sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->GradOff * sizeof(f32),
                pHost, (u64)pModel->TotalParams * sizeof(f32)) ||
            !sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->MOff * sizeof(f32),
                pHost, (u64)pModel->TotalParams * sizeof(f32)) ||
            !sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->VOff * sizeof(f32),
                pHost, (u64)pModel->TotalParams * sizeof(f32)))
        {
            sc_memory_free(pHost);
            goto Failed;
        }

        sc_memory_free(pHost);
    }

    for (i32 i = 0; i < ScGpuPipe_Count; ++i)
    {
        pModel->aPipes[i] = sc_gpu_pipeline_new(pGpu, c_sc_gpu_llm_pipeline_names[i]);
        if (pModel->aPipes[i] == SC_GPU_INVALID_HANDLE)
            goto Failed;
    }

    pModel->aTokens = sc_memory_allocate(sizeof(i32) * (size_t)T);
    pModel->aLabels = sc_memory_allocate(sizeof(i32) * (size_t)T);
    pModel->aMask = sc_memory_allocate(sizeof(i32) * (size_t)T);
    pModel->aOrder = sc_memory_allocate(sizeof(i32) * (size_t)T);
    pModel->aGOff = sc_memory_allocate(sizeof(i32) * (size_t)(T + 1));
    pModel->aGTok = sc_memory_allocate(sizeof(i32) * (size_t)T);

    if (!pModel->aTokens || !pModel->aLabels || !pModel->aMask ||
        !pModel->aOrder || !pModel->aGOff || !pModel->aGTok)
        goto Failed;

    return pModel;

Failed:
    sc_gpu_llm_destroy(pModel);
    return NULL;
}

ScGpuLlm*
sc_gpu_llm_create(ScGpu* pGpu, const ScTinyLlmModelConfig* pConfig)
{
    return _sc_gpu_llm_create_ext(pGpu, pConfig, 1);
}

void
sc_gpu_llm_destroy(ScGpuLlm* pModel)
{
    if (!pModel)
        return;

    for (i32 i = 0; i < ScGpuPipe_Count; ++i)
    {
        if (pModel->aPipes[i] != SC_GPU_INVALID_HANDLE)
            sc_gpu_pipeline_destroy(pModel->pGpu, pModel->aPipes[i]);
    }

    if (pModel->GBuffer != SC_GPU_INVALID_HANDLE)
        sc_gpu_buffer_destroy(pModel->pGpu, pModel->GBuffer);
    if (pModel->AuxBuffer != SC_GPU_INVALID_HANDLE)
        sc_gpu_buffer_destroy(pModel->pGpu, pModel->AuxBuffer);

    _sc_gpu_llm_free_host(pModel);
    sc_memory_free(pModel);
}

ScTinyLlmModelConfig
sc_gpu_llm_config(ScGpuLlm* pModel)
{
    return pModel ? pModel->Cfg : (ScTinyLlmModelConfig) {};
}

i64
sc_gpu_llm_param_count(ScGpuLlm* pModel)
{
    return pModel ? pModel->TotalParams : 0;
}

u64
sc_gpu_llm_memory_bytes(ScGpuLlm* pModel)
{
    return pModel ? pModel->TotalFloats * sizeof(f32) : 0;
}

u64
sc_gpu_llm_total_memory_bytes(ScGpuLlm* pModel)
{
    if (!pModel)
        return 0;
    return pModel->TotalFloats * sizeof(f32) + (u64)pModel->AuxFloats * sizeof(f32);
}

/*
  ###################################
  окна и aux
  ###################################
*/

static i32
_sc_gpu_llm_fill_window(ScGpuLlm* pModel, const ScTinyLlmExample* pExample, i32 start,
    ScTinyLlmLossMask lossMask, i32* pT, i32* pValid)
{
    i32 ctx = pModel->T;
    i32 T = (i32)(pExample->Count - 1 - start);
    if (T > ctx)
        T = ctx;
    if (T <= 0)
    {
        *pT = 0;
        *pValid = 0;
        return 0;
    }

    i32 valid = 0;
    for (i32 t = 0; t < T; ++t)
    {
        i64 globalTarget = (i64)start + t + 1;

        // DOCS: как CPU forward/backward: токен вне словаря заменяется на
        // <UNK>. Это же значение увидит и scatter-градиент эмбеддингов.
        i32 token = pExample->aTokens[start + t];
        if (token < 0 || token >= pModel->V)
            token = (i32)ScAiSpecialToken_Unk;
        pModel->aTokens[t] = token;

        // NOTE: метки не клампим: невалидная метка маскируется в loss,
        // как в _sc_tiny_llm_loss_and_dlogits.
        pModel->aLabels[t] = pExample->aTokens[globalTarget];

        i32 mask = 1;
        if (lossMask == ScTinyLlmLossMask_Prompt && pExample->SepIndex >= 0 &&
            globalTarget <= (i64)pExample->SepIndex)
            mask = 0;

        pModel->aMask[t] = mask;
        valid += mask;
    }

    *pT = T;
    *pValid = valid;
    return 1;
}

// DOCS: Группировка одинаковых токенов для scatter-градиента эмбеддингов.
// Без атомарных float-операций: каждая уникальная строка считается одним
// invocation'ом. O(T^2) сортировка вставками на хосте, T <= ctx (512).
static i32
_sc_gpu_llm_build_token_groups(ScGpuLlm* pModel, i32 T)
{
    // DOCS: aOrder - перестановка индексов t, отсортированная по токену.
    for (i32 i = 0; i < T; ++i)
        pModel->aOrder[i] = i;

    for (i32 i = 1; i < T; ++i)
    {
        i32 index = pModel->aOrder[i];
        i32 token = pModel->aTokens[index];
        i32 j = i - 1;
        while (j >= 0 && pModel->aTokens[pModel->aOrder[j]] > token)
        {
            pModel->aOrder[j + 1] = pModel->aOrder[j];
            --j;
        }
        pModel->aOrder[j + 1] = index;
    }

    // DOCS: инвариант для шейдера: aGOff[g] .. aGOff[g+1] - диапазон строк
    // в aOrder с одинаковым токеном aGTok[g]. aGOff[u] = T - конец.
    i32 u = 0;
    pModel->aGOff[0] = 0;
    pModel->aGTok[0] = pModel->aTokens[pModel->aOrder[0]];

    for (i32 i = 1; i < T; ++i)
    {
        i32 token = pModel->aTokens[pModel->aOrder[i]];
        i32 prevToken = pModel->aTokens[pModel->aOrder[i - 1]];
        if (token != prevToken)
        {
            ++u;
            pModel->aGOff[u] = i;
            pModel->aGTok[u] = token;
        }
    }
    pModel->aGOff[u + 1] = T;

    return u + 1;
}

static i32
_sc_gpu_llm_write_aux(ScGpuLlm* pModel, i32 batchIndex, i32 T, i32 buildGroups)
{
    u32 base = (u32)batchIndex * pModel->SlotStride;
    f32* pAux = pModel->pAux;

    for (i32 t = 0; t < T; ++t)
    {
        pAux[base + pModel->TokOff + (u32)t] = (f32)pModel->aTokens[t];
        pAux[base + pModel->LabOff + (u32)t] = (f32)pModel->aLabels[t];
        pAux[base + pModel->MaskOff + (u32)t] = (f32)pModel->aMask[t];
    }

    if (!buildGroups)
        return 0;

    i32 u = _sc_gpu_llm_build_token_groups(pModel, T);
    for (i32 i = 0; i < T; ++i)
        pAux[base + pModel->OrderOff + (u32)i] = (f32)pModel->aOrder[i];
    for (i32 i = 0; i <= u; ++i)
        pAux[base + pModel->GOffOff + (u32)i] = (f32)pModel->aGOff[i];
    for (i32 i = 0; i < u; ++i)
        pAux[base + pModel->GTokOff + (u32)i] = (f32)pModel->aGTok[i];

    return u;
}

static void
_sc_gpu_llm_zero_loss_partials(ScGpuLlm* pModel, i32 batchIndex)
{
    u32 partialBase = pModel->AuxLossPartials + (u32)batchIndex * SC_GPU_LLM_LOSS_GROUPS;
    for (i32 i = 0; i < SC_GPU_LLM_LOSS_GROUPS; ++i)
        pModel->pAux[partialBase + (u32)i] = 0.0f;
}

/*
  ###################################
  запись dispatches
  ###################################
*/

static void
_sc_gpu_llm_record_forward(ScGpuLlm* pModel, u32 base, i32 T)
{
    ScGpu* pGpu = pModel->pGpu;
    i32 D = pModel->D;
    i32 V = pModel->V;
    i32 F = pModel->F;
    i32 H = pModel->H;
    i32 Dh = pModel->Dh;
    i32 L = pModel->L;
    f32 scale = 1.0f / sqrtf((f32)Dh);

    ScGpuPush p = _sc_gpu_llm_push_zero();
    p.u[0] = base + pModel->TokOff;
    p.u[1] = _sc_gpu_llm_param_data(pModel, 0);
    p.u[2] = _sc_gpu_llm_param_data(pModel, 1);
    p.u[3] = pModel->X;
    p.u[4] = (u32)T;
    p.u[5] = (u32)D;
    p.u[6] = (u32)V;
    p.u[7] = (u32)ScAiSpecialToken_Unk;
    p.u[8] = 0; // позиции начинаются с 0 (полный префилл)
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_EmbGather], &p,
        _sc_gpu_llm_grid256((i64)T * D), 1, 1);

    for (i32 l = 0; l < L; ++l)
    {
        ScGpuLlmLayer* pLayer = &pModel->aLayers[l];
        i32 pLn1G = 6 + l * 12 + 0;
        i32 pQkvW = 6 + l * 12 + 2;
        i32 pQkvB = 6 + l * 12 + 3;
        i32 pProjW = 6 + l * 12 + 4;
        i32 pProjB = 6 + l * 12 + 5;
        i32 pLn2G = 6 + l * 12 + 6;
        i32 pLn2B = 6 + l * 12 + 7;
        i32 pFc1W = 6 + l * 12 + 8;
        i32 pFc1B = 6 + l * 12 + 9;
        i32 pFc2W = 6 + l * 12 + 10;
        i32 pFc2B = 6 + l * 12 + 11;

        // LN1
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pLayer->Ln1Y;
        p.u[2] = pLayer->Ln1Xhat;
        p.u[3] = pLayer->Ln1InvStd;
        p.u[4] = _sc_gpu_llm_param_data(pModel, pLn1G);
        p.u[5] = _sc_gpu_llm_param_data(pModel, pLn1G + 1);
        p.u[6] = (u32)T;
        p.u[7] = (u32)D;
        p.f[0] = SC_GPU_LLM_LN_EPS;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnFwd], &p, _sc_gpu_llm_grid64(T), 1, 1);

        // QKV
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Ln1Y;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pQkvW);
        p.u[2] = pLayer->Qkv;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pQkvB);
        p.u[4] = (u32)T;
        p.u[5] = (u32)(3 * D);
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(3 * D), _sc_gpu_llm_grid16(T), 1);

        // scores
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Qkv;
        p.u[1] = pLayer->Qkv;
        p.u[2] = pLayer->Probs;
        p.u[3] = (u32)T;
        p.u[4] = (u32)Dh;
        p.u[5] = (u32)(3 * D);
        p.u[6] = 0;
        p.u[7] = (u32)(3 * D);
        p.u[8] = (u32)D;
        p.f[0] = scale;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnScores], &p,
            _sc_gpu_llm_grid16(T), _sc_gpu_llm_grid16(T), (u32)H);

        // causal softmax
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Probs;
        p.u[1] = (u32)T;
        p.u[2] = (u32)H;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnSoftmax], &p,
            _sc_gpu_llm_grid64((i64)H * T), 1, 1);

        // P * V
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Probs;
        p.u[1] = pLayer->Qkv;
        p.u[2] = pLayer->AttnCtx;
        p.u[3] = (u32)T;
        p.u[4] = (u32)Dh;
        p.u[7] = (u32)(3 * D);
        p.u[8] = (u32)(2 * D);
        p.u[9] = (u32)D;
        p.u[10] = 0;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnMix], &p,
            _sc_gpu_llm_grid16(Dh), _sc_gpu_llm_grid16(T), (u32)H);

        // projection
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->AttnCtx;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pProjW);
        p.u[2] = pModel->Tmp;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pProjB);
        p.u[4] = (u32)T;
        p.u[5] = (u32)D;
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(T), 1);

        // residual
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pModel->Tmp;
        p.u[2] = (u32)((i64)T * D);
        p.u[3] = 1;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Add], &p,
            _sc_gpu_llm_grid256((i64)T * D), 1, 1);

        // LN2
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pLayer->Ln2Y;
        p.u[2] = pLayer->Ln2Xhat;
        p.u[3] = pLayer->Ln2InvStd;
        p.u[4] = _sc_gpu_llm_param_data(pModel, pLn2G);
        p.u[5] = _sc_gpu_llm_param_data(pModel, pLn2B);
        p.u[6] = (u32)T;
        p.u[7] = (u32)D;
        p.f[0] = SC_GPU_LLM_LN_EPS;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnFwd], &p, _sc_gpu_llm_grid64(T), 1, 1);

        // FC1
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Ln2Y;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pFc1W);
        p.u[2] = pLayer->Fc1Pre;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pFc1B);
        p.u[4] = (u32)T;
        p.u[5] = (u32)F;
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(F), _sc_gpu_llm_grid16(T), 1);

        // GELU
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Fc1Pre;
        p.u[1] = pLayer->Fc1Act;
        p.u[2] = (u32)((i64)T * F);
        p.u[3] = 0;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Gelu], &p,
            _sc_gpu_llm_grid256((i64)T * F), 1, 1);

        // FC2
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Fc1Act;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pFc2W);
        p.u[2] = pModel->Tmp;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pFc2B);
        p.u[4] = (u32)T;
        p.u[5] = (u32)D;
        p.u[6] = (u32)F;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(T), 1);

        // residual
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pModel->Tmp;
        p.u[2] = (u32)((i64)T * D);
        p.u[3] = 1;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Add], &p,
            _sc_gpu_llm_grid256((i64)T * D), 1, 1);
    }

    // final LN
    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->X;
    p.u[1] = pModel->FinalY;
    p.u[2] = pModel->FinalXhat;
    p.u[3] = pModel->FinalInvStd;
    p.u[4] = _sc_gpu_llm_param_data(pModel, 2);
    p.u[5] = _sc_gpu_llm_param_data(pModel, 3);
    p.u[6] = (u32)T;
    p.u[7] = (u32)D;
    p.f[0] = SC_GPU_LLM_LN_EPS;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnFwd], &p, _sc_gpu_llm_grid64(T), 1, 1);

    // LM head
    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->FinalY;
    p.u[1] = _sc_gpu_llm_param_data(pModel, 4);
    p.u[2] = pModel->Logits;
    p.u[3] = _sc_gpu_llm_param_data(pModel, 5);
    p.u[4] = (u32)T;
    p.u[5] = (u32)V;
    p.u[6] = (u32)D;
    p.u[7] = 1;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
        _sc_gpu_llm_grid16(V), _sc_gpu_llm_grid16(T), 1);
}

// DOCS: после полного префилла переносим K/V всех T позиций из aQkv
// каждого слоя в KV-кэш. Дальше генерация идёт по одному токену.
static void
_sc_gpu_llm_record_kv_fill(ScGpuLlm* pModel, i32 T)
{
    ScGpu* pGpu = pModel->pGpu;
    i32 D = pModel->D;
    i32 Tctx = pModel->T;

    for (i32 l = 0; l < pModel->L; ++l)
    {
        ScGpuLlmLayer* pLayer = &pModel->aLayers[l];

        ScGpuPush p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Qkv;
        p.u[1] = pModel->KCache + (u32)l * (u32)Tctx * (u32)D;
        p.u[2] = pModel->VCache + (u32)l * (u32)Tctx * (u32)D;
        p.u[3] = (u32)T;
        p.u[4] = (u32)D;
        p.u[5] = (u32)(3 * D);
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_KvFill], &p,
            _sc_gpu_llm_grid256((i64)T * D), 1, 1);
    }
}

/*
  DOCS: decode одного токена на позиции pos с KV-кэшем.

  Считает ровно те же величины, что и полный forward для строки pos,
  но M=1: эмбеддинг, LN1, QKV, добавление K/V в кэш, внимание по
  позициям 0..pos, projection, residual, LN2, FFN, residual, финальный
  LN и LM head. Результат - строка 0 Logits.
*/
static void
_sc_gpu_llm_record_decode(ScGpuLlm* pModel, u32 base, i32 pos)
{
    ScGpu* pGpu = pModel->pGpu;
    i32 D = pModel->D;
    i32 V = pModel->V;
    i32 F = pModel->F;
    i32 H = pModel->H;
    i32 Dh = pModel->Dh;
    i32 L = pModel->L;
    i32 Tctx = pModel->T;
    f32 scale = 1.0f / sqrtf((f32)Dh);

    ScGpuPush p = _sc_gpu_llm_push_zero();
    p.u[0] = base + pModel->TokOff;
    p.u[1] = _sc_gpu_llm_param_data(pModel, 0);
    p.u[2] = _sc_gpu_llm_param_data(pModel, 1);
    p.u[3] = pModel->X;
    p.u[4] = 1;
    p.u[5] = (u32)D;
    p.u[6] = (u32)V;
    p.u[7] = (u32)ScAiSpecialToken_Unk;
    p.u[8] = (u32)pos;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_EmbGather], &p,
        _sc_gpu_llm_grid256(D), 1, 1);

    for (i32 l = 0; l < L; ++l)
    {
        ScGpuLlmLayer* pLayer = &pModel->aLayers[l];
        i32 pLn1G = 6 + l * 12 + 0;
        i32 pQkvW = 6 + l * 12 + 2;
        i32 pQkvB = 6 + l * 12 + 3;
        i32 pProjW = 6 + l * 12 + 4;
        i32 pProjB = 6 + l * 12 + 5;
        i32 pLn2G = 6 + l * 12 + 6;
        i32 pLn2B = 6 + l * 12 + 7;
        i32 pFc1W = 6 + l * 12 + 8;
        i32 pFc1B = 6 + l * 12 + 9;
        i32 pFc2W = 6 + l * 12 + 10;
        i32 pFc2B = 6 + l * 12 + 11;

        u32 kCache = pModel->KCache + (u32)l * (u32)Tctx * (u32)D;
        u32 vCache = pModel->VCache + (u32)l * (u32)Tctx * (u32)D;

        // LN1 (одна строка)
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pLayer->Ln1Y;
        p.u[2] = pLayer->Ln1Xhat;
        p.u[3] = pLayer->Ln1InvStd;
        p.u[4] = _sc_gpu_llm_param_data(pModel, pLn1G);
        p.u[5] = _sc_gpu_llm_param_data(pModel, pLn1G + 1);
        p.u[6] = 1;
        p.u[7] = (u32)D;
        p.f[0] = SC_GPU_LLM_LN_EPS;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnFwd], &p, 1, 1, 1);

        // QKV: M=1
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Ln1Y;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pQkvW);
        p.u[2] = pLayer->Qkv;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pQkvB);
        p.u[4] = 1;
        p.u[5] = (u32)(3 * D);
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(3 * D), 1, 1);

        // K/V -> кэш
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Qkv;
        p.u[1] = 0;
        p.u[2] = (u32)(3 * D);
        p.u[3] = (u32)D;
        p.u[4] = kCache;
        p.u[5] = vCache;
        p.u[6] = (u32)pos;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_KvAppend], &p,
            _sc_gpu_llm_grid256(D), 1, 1);

        // Q * K^T по 0..pos
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Qkv;
        p.u[1] = pLayer->Probs;
        p.u[2] = (u32)Tctx;
        p.u[3] = (u32)D;
        p.u[4] = (u32)Dh;
        p.u[5] = 0;
        p.u[6] = (u32)(3 * D);
        p.u[7] = (u32)pos;
        p.u[8] = kCache;
        p.f[0] = scale;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnScores1], &p,
            _sc_gpu_llm_grid64((i64)pos + 1), (u32)H, 1);

        // softmax по 0..pos
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Probs;
        p.u[1] = (u32)Tctx;
        p.u[2] = (u32)pos;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnSoftmax1], &p,
            (u32)H, 1, 1);

        // P * V
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Probs;
        p.u[1] = vCache;
        p.u[2] = pLayer->AttnCtx;
        p.u[3] = (u32)Tctx;
        p.u[4] = (u32)Dh;
        p.u[5] = (u32)D;
        p.u[6] = (u32)pos;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnMix1], &p,
            _sc_gpu_llm_grid64(Dh), (u32)H, 1);

        // projection: M=1
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->AttnCtx;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pProjW);
        p.u[2] = pModel->Tmp;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pProjB);
        p.u[4] = 1;
        p.u[5] = (u32)D;
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(D), 1, 1);

        // residual
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pModel->Tmp;
        p.u[2] = (u32)D;
        p.u[3] = 1;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Add], &p,
            _sc_gpu_llm_grid256(D), 1, 1);

        // LN2
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pLayer->Ln2Y;
        p.u[2] = pLayer->Ln2Xhat;
        p.u[3] = pLayer->Ln2InvStd;
        p.u[4] = _sc_gpu_llm_param_data(pModel, pLn2G);
        p.u[5] = _sc_gpu_llm_param_data(pModel, pLn2B);
        p.u[6] = 1;
        p.u[7] = (u32)D;
        p.f[0] = SC_GPU_LLM_LN_EPS;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnFwd], &p, 1, 1, 1);

        // FC1
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Ln2Y;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pFc1W);
        p.u[2] = pLayer->Fc1Pre;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pFc1B);
        p.u[4] = 1;
        p.u[5] = (u32)F;
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(F), 1, 1);

        // GELU
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Fc1Pre;
        p.u[1] = pLayer->Fc1Act;
        p.u[2] = (u32)F;
        p.u[3] = 0;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Gelu], &p,
            _sc_gpu_llm_grid256(F), 1, 1);

        // FC2
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Fc1Act;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pFc2W);
        p.u[2] = pModel->Tmp;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pFc2B);
        p.u[4] = 1;
        p.u[5] = (u32)D;
        p.u[6] = (u32)F;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
            _sc_gpu_llm_grid16(D), 1, 1);

        // residual
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->X;
        p.u[1] = pModel->Tmp;
        p.u[2] = (u32)D;
        p.u[3] = 1;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Add], &p,
            _sc_gpu_llm_grid256(D), 1, 1);
    }

    // финальный LN
    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->X;
    p.u[1] = pModel->FinalY;
    p.u[2] = pModel->FinalXhat;
    p.u[3] = pModel->FinalInvStd;
    p.u[4] = _sc_gpu_llm_param_data(pModel, 2);
    p.u[5] = _sc_gpu_llm_param_data(pModel, 3);
    p.u[6] = 1;
    p.u[7] = (u32)D;
    p.f[0] = SC_GPU_LLM_LN_EPS;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnFwd], &p, 1, 1, 1);

    // LM head: M=1
    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->FinalY;
    p.u[1] = _sc_gpu_llm_param_data(pModel, 4);
    p.u[2] = pModel->Logits;
    p.u[3] = _sc_gpu_llm_param_data(pModel, 5);
    p.u[4] = 1;
    p.u[5] = (u32)V;
    p.u[6] = (u32)D;
    p.u[7] = 1;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulFwd], &p,
        _sc_gpu_llm_grid16(V), 1, 1);
}

static void
_sc_gpu_llm_record_loss(ScGpuLlm* pModel, u32 base, i32 batchIndex, i32 T, i32 train)
{
    ScGpu* pGpu = pModel->pGpu;

    ScGpuPush p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->Logits;
    p.u[1] = base + pModel->LossOff;
    p.u[2] = base + pModel->LabOff;
    p.u[3] = (u32)pModel->V;
    p.u[4] = (u32)train;
    p.u[5] = base + pModel->MaskOff;
    p.u[6] = (u32)T;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_SoftmaxCe], &p, _sc_gpu_llm_grid64(T), 1, 1);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = base + pModel->LossOff;
    p.u[1] = (u32)T;
    p.u[2] = pModel->AuxLossPartials + (u32)batchIndex * SC_GPU_LLM_LOSS_GROUPS;
    p.u[3] = SC_GPU_LLM_LOSS_GROUPS;
    p.u[4] = 0;
    p.u[5] = 1;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_PartialSum], &p,
        SC_GPU_LLM_LOSS_GROUPS, 1, 1);
}

static void
_sc_gpu_llm_record_reduce_loss(ScGpuLlm* pModel, i32 count)
{
    ScGpuPush p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->AuxLossPartials;
    p.u[1] = (u32)(count * SC_GPU_LLM_LOSS_GROUPS);
    p.u[2] = pModel->AuxLossSum;
    p.u[3] = 0;
    sc_gpu_dispatch(pModel->pGpu, pModel->aPipes[ScGpuPipe_ReduceSum], &p, 1, 1, 1);
}

static void
_sc_gpu_llm_record_backward(ScGpuLlm* pModel, u32 base, i32 T, i32 uniqueTokens)
{
    ScGpu* pGpu = pModel->pGpu;
    i32 D = pModel->D;
    i32 V = pModel->V;
    i32 F = pModel->F;
    i32 H = pModel->H;
    i32 Dh = pModel->Dh;
    i32 L = pModel->L;
    f32 scale = 1.0f / sqrtf((f32)Dh);

    ScGpuPush p = _sc_gpu_llm_push_zero();

    // LM head
    p.u[0] = pModel->FinalY;
    p.u[1] = pModel->Logits;
    p.u[2] = _sc_gpu_llm_param_grad(pModel, 4);
    p.u[3] = _sc_gpu_llm_param_grad(pModel, 5);
    p.u[4] = (u32)T;
    p.u[5] = (u32)V;
    p.u[6] = (u32)D;
    p.u[7] = 1;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDw], &p,
        _sc_gpu_llm_grid16(V), _sc_gpu_llm_grid16(D), 1);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->Logits;
    p.u[1] = _sc_gpu_llm_param_data(pModel, 4);
    p.u[2] = pModel->DNorm;
    p.u[3] = (u32)T;
    p.u[4] = (u32)V;
    p.u[5] = (u32)D;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDin], &p,
        _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(T), 1);

    // dX = 0
    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->DX;
    p.u[1] = (u32)((i64)T * D);
    p.f[0] = 0.0f;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Fill], &p,
        _sc_gpu_llm_grid256((i64)T * D), 1, 1);

    // final LN
    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->DNorm;
    p.u[1] = pModel->FinalXhat;
    p.u[2] = pModel->FinalInvStd;
    p.u[3] = _sc_gpu_llm_param_data(pModel, 2);
    p.u[4] = pModel->DX;
    p.u[5] = (u32)T;
    p.u[6] = (u32)D;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnBwd], &p, _sc_gpu_llm_grid64(T), 1, 1);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->DNorm;
    p.u[1] = pModel->FinalXhat;
    p.u[2] = _sc_gpu_llm_param_grad(pModel, 2);
    p.u[3] = _sc_gpu_llm_param_grad(pModel, 3);
    p.u[4] = (u32)T;
    p.u[5] = (u32)D;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnParamGrad], &p, _sc_gpu_llm_grid64(D), 1, 1);

    for (i32 l = L - 1; l >= 0; --l)
    {
        ScGpuLlmLayer* pLayer = &pModel->aLayers[l];
        i32 pLn1G = 6 + l * 12 + 0;
        i32 pQkvW = 6 + l * 12 + 2;
        i32 pQkvB = 6 + l * 12 + 3;
        i32 pProjW = 6 + l * 12 + 4;
        i32 pProjB = 6 + l * 12 + 5;
        i32 pLn2G = 6 + l * 12 + 6;
        i32 pLn2B = 6 + l * 12 + 7;
        i32 pFc1W = 6 + l * 12 + 8;
        i32 pFc1B = 6 + l * 12 + 9;
        i32 pFc2W = 6 + l * 12 + 10;
        i32 pFc2B = 6 + l * 12 + 11;

        // dCur = dX
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DCur;
        p.u[1] = pModel->DX;
        p.u[2] = (u32)((i64)T * D);
        p.u[3] = 0;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Add], &p,
            _sc_gpu_llm_grid256((i64)T * D), 1, 1);

        // FC2
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Fc1Act;
        p.u[1] = pModel->DCur;
        p.u[2] = _sc_gpu_llm_param_grad(pModel, pFc2W);
        p.u[3] = _sc_gpu_llm_param_grad(pModel, pFc2B);
        p.u[4] = (u32)T;
        p.u[5] = (u32)D;
        p.u[6] = (u32)F;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDw], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(F), 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DCur;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pFc2W);
        p.u[2] = pModel->DFc1;
        p.u[3] = (u32)T;
        p.u[4] = (u32)D;
        p.u[5] = (u32)F;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDin], &p,
            _sc_gpu_llm_grid16(F), _sc_gpu_llm_grid16(T), 1);

        // GELU backward in place
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Fc1Pre;
        p.u[1] = pModel->DFc1;
        p.u[2] = (u32)((i64)T * F);
        p.u[3] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Gelu], &p,
            _sc_gpu_llm_grid256((i64)T * F), 1, 1);

        // FC1
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Ln2Y;
        p.u[1] = pModel->DFc1;
        p.u[2] = _sc_gpu_llm_param_grad(pModel, pFc1W);
        p.u[3] = _sc_gpu_llm_param_grad(pModel, pFc1B);
        p.u[4] = (u32)T;
        p.u[5] = (u32)F;
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDw], &p,
            _sc_gpu_llm_grid16(F), _sc_gpu_llm_grid16(D), 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DFc1;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pFc1W);
        p.u[2] = pModel->DNorm;
        p.u[3] = (u32)T;
        p.u[4] = (u32)F;
        p.u[5] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDin], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(T), 1);

        // LN2 backward
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DNorm;
        p.u[1] = pLayer->Ln2Xhat;
        p.u[2] = pLayer->Ln2InvStd;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pLn2G);
        p.u[4] = pModel->DCur;
        p.u[5] = (u32)T;
        p.u[6] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnBwd], &p, _sc_gpu_llm_grid64(T), 1, 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DNorm;
        p.u[1] = pLayer->Ln2Xhat;
        p.u[2] = _sc_gpu_llm_param_grad(pModel, pLn2G);
        p.u[3] = _sc_gpu_llm_param_grad(pModel, pLn2B);
        p.u[4] = (u32)T;
        p.u[5] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnParamGrad], &p, _sc_gpu_llm_grid64(D), 1, 1);

        // projection
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->AttnCtx;
        p.u[1] = pModel->DCur;
        p.u[2] = _sc_gpu_llm_param_grad(pModel, pProjW);
        p.u[3] = _sc_gpu_llm_param_grad(pModel, pProjB);
        p.u[4] = (u32)T;
        p.u[5] = (u32)D;
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDw], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(D), 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DCur;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pProjW);
        p.u[2] = pModel->DAttnCtx;
        p.u[3] = (u32)T;
        p.u[4] = (u32)D;
        p.u[5] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDin], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(T), 1);

        // attention backward
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DAttnCtx;
        p.u[1] = pLayer->Qkv;
        p.u[2] = pModel->DProb;
        p.u[3] = (u32)T;
        p.u[4] = (u32)Dh;
        p.u[5] = (u32)D;
        p.u[6] = 0;
        p.u[7] = (u32)(3 * D);
        p.u[8] = (u32)(2 * D);
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnScores], &p,
            _sc_gpu_llm_grid16(T), _sc_gpu_llm_grid16(T), (u32)H);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Probs;
        p.u[1] = pModel->DProb;
        p.u[2] = (u32)T;
        p.u[3] = (u32)H;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnSoftmaxBwd], &p,
            _sc_gpu_llm_grid64((i64)H * T), 1, 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DProb;
        p.u[1] = pLayer->Qkv;
        p.u[2] = pModel->DQkv;
        p.u[3] = (u32)T;
        p.u[4] = (u32)Dh;
        p.u[5] = (u32)(3 * D);
        p.u[6] = (u32)(3 * D);
        p.f[0] = scale;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnBwdDq], &p,
            _sc_gpu_llm_grid64(Dh), (u32)T, (u32)H);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DProb;
        p.u[1] = pLayer->Probs;
        p.u[2] = pModel->DQkv;
        p.u[3] = (u32)T;
        p.u[4] = (u32)Dh;
        p.u[5] = pLayer->Qkv;
        p.u[6] = pModel->DAttnCtx;
        p.u[7] = (u32)D;
        p.u[8] = (u32)(3 * D);
        p.u[9] = (u32)(3 * D);
        p.f[0] = scale;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AttnBwdDkv], &p,
            _sc_gpu_llm_grid64(Dh), (u32)T, (u32)H);

        // QKV linear
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pLayer->Ln1Y;
        p.u[1] = pModel->DQkv;
        p.u[2] = _sc_gpu_llm_param_grad(pModel, pQkvW);
        p.u[3] = _sc_gpu_llm_param_grad(pModel, pQkvB);
        p.u[4] = (u32)T;
        p.u[5] = (u32)(3 * D);
        p.u[6] = (u32)D;
        p.u[7] = 1;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDw], &p,
            _sc_gpu_llm_grid16(3 * D), _sc_gpu_llm_grid16(D), 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DQkv;
        p.u[1] = _sc_gpu_llm_param_data(pModel, pQkvW);
        p.u[2] = pModel->DNorm;
        p.u[3] = (u32)T;
        p.u[4] = (u32)(3 * D);
        p.u[5] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_MatmulDin], &p,
            _sc_gpu_llm_grid16(D), _sc_gpu_llm_grid16(T), 1);

        // LN1 backward
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DNorm;
        p.u[1] = pLayer->Ln1Xhat;
        p.u[2] = pLayer->Ln1InvStd;
        p.u[3] = _sc_gpu_llm_param_data(pModel, pLn1G);
        p.u[4] = pModel->DCur;
        p.u[5] = (u32)T;
        p.u[6] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnBwd], &p, _sc_gpu_llm_grid64(T), 1, 1);

        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DNorm;
        p.u[1] = pLayer->Ln1Xhat;
        p.u[2] = _sc_gpu_llm_param_grad(pModel, pLn1G);
        p.u[3] = _sc_gpu_llm_param_grad(pModel, pLn1G + 1);
        p.u[4] = (u32)T;
        p.u[5] = (u32)D;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_LnParamGrad], &p, _sc_gpu_llm_grid64(D), 1, 1);

        // dX = dCur
        p = _sc_gpu_llm_push_zero();
        p.u[0] = pModel->DX;
        p.u[1] = pModel->DCur;
        p.u[2] = (u32)((i64)T * D);
        p.u[3] = 0;
        p.f[0] = 1.0f;
        sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_Add], &p,
            _sc_gpu_llm_grid256((i64)T * D), 1, 1);
    }

    // embedding gradients
    i32 u = uniqueTokens;

    p = _sc_gpu_llm_push_zero();
    p.u[0] = base + pModel->OrderOff;
    p.u[1] = base + pModel->GOffOff;
    p.u[2] = (u32)u;
    p.u[3] = pModel->DX;
    p.u[4] = (u32)D;
    p.u[5] = base + pModel->GTokOff;
    p.u[6] = _sc_gpu_llm_param_grad(pModel, 0);
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_EmbTokenGrad], &p,
        _sc_gpu_llm_grid256((i64)u * D), 1, 1);

    p = _sc_gpu_llm_push_zero();
    p.u[1] = pModel->DX;
    p.u[2] = _sc_gpu_llm_param_grad(pModel, 1);
    p.u[3] = (u32)T;
    p.u[4] = (u32)D;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_EmbPosGrad], &p,
        _sc_gpu_llm_grid256((i64)T * D), 1, 1);
}

static void
_sc_gpu_llm_record_zero_grads(ScGpuLlm* pModel)
{
    ScGpuPush p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->GradOff;
    p.u[1] = (u32)pModel->TotalParams;
    p.f[0] = 0.0f;
    sc_gpu_dispatch(pModel->pGpu, pModel->aPipes[ScGpuPipe_Fill], &p,
        _sc_gpu_llm_grid256(pModel->TotalParams), 1, 1);
}

static void
_sc_gpu_llm_record_adamw(ScGpuLlm* pModel, f32 lr, i32 step, f32 invBatch, f32 weightDecay,
    f32 gradClip)
{
    ScGpu* pGpu = pModel->pGpu;

    ScGpuPush p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->GradOff;
    p.u[1] = (u32)pModel->TotalParams;
    p.u[2] = pModel->AuxNormPartials;
    p.u[3] = SC_GPU_LLM_NORM_GROUPS;
    p.u[4] = 1;
    p.u[5] = 0;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_PartialSum], &p,
        SC_GPU_LLM_NORM_GROUPS, 1, 1);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->AuxNormPartials;
    p.u[1] = SC_GPU_LLM_NORM_GROUPS;
    p.u[2] = pModel->AuxNormSq;
    p.u[3] = 0;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_ReduceSum], &p, 1, 1, 1);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->AuxNormSq;
    p.u[1] = pModel->AuxNorm;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_FinalizeNorm], &p, 1, 1, 1);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->AuxNorm;
    p.u[1] = pModel->AuxScale;
    p.f[0] = gradClip;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_GradScale], &p, 1, 1, 1);

    const f32 beta1 = 0.9f;
    const f32 beta2 = 0.999f;
    f32 beta1Pow = 1.0f - powf(beta1, (f32)step);
    f32 beta2Pow = 1.0f - powf(beta2, (f32)step);

    p = _sc_gpu_llm_push_zero();
    p.u[0] = pModel->DataOff;
    p.u[1] = pModel->GradOff;
    p.u[2] = pModel->MOff;
    p.u[3] = pModel->VOff;
    p.u[4] = (u32)pModel->TotalParams;
    p.u[5] = pModel->AuxScale;
    p.f[0] = lr;
    p.f[1] = weightDecay;
    p.f[2] = beta1;
    p.f[3] = beta2;
    p.f[4] = beta1Pow;
    p.f[5] = beta2Pow;
    p.f[6] = 1e-8f;
    p.f[7] = invBatch;
    sc_gpu_dispatch(pGpu, pModel->aPipes[ScGpuPipe_AdamW], &p,
        _sc_gpu_llm_grid256(pModel->TotalParams), 1, 1);
}

/*
  ###################################
  чекпоинты
  ###################################
*/

static const char c_sc_gpu_llm_magic[4] = { 'S', 'C', 'T', 'L' };
static const u32 c_sc_gpu_llm_version = 1;

i32
sc_gpu_llm_save_checkpoint(ScGpuLlm* pModel, ScAiBpe pBpe, const char* pPath)
{
    if (!pModel || !pPath)
        return 0;

    f32* pHost = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
    if (!pHost)
        return 0;

    if (!sc_gpu_download(pModel->pGpu, pModel->GBuffer,
        (u64)pModel->DataOff * sizeof(f32), pHost,
        (u64)pModel->TotalParams * sizeof(f32)))
    {
        sc_memory_free(pHost);
        return 0;
    }

    // DOCS: пишем во временный файл и подменяем им чекпоинт только после
    // успешной записи. Иначе обрыв/ошибка посреди fwrite уничтожала бы
    // последний рабочий чекпоинт (а он теперь пишется раз в 1000 шагов).
    i64 pathLength = sc_string_get_length((char*)pPath);
    char* pTmpPath = sc_memory_allocate((size_t)pathLength + 5);
    if (!pTmpPath)
    {
        sc_memory_free(pHost);
        return 0;
    }
    snprintf(pTmpPath, (size_t)pathLength + 5, "%s.tmp", pPath);

    FILE* pFile = fopen(pTmpPath, "wb");
    if (!pFile)
    {
        sc_log_erro("gpu-llm: cannot open checkpoint %s for writing\n", pTmpPath);
        sc_memory_free(pTmpPath);
        sc_memory_free(pHost);
        return 0;
    }

    i32 config[6] = {
        pModel->Cfg.NumLayers,
        pModel->Cfg.DModel,
        pModel->Cfg.NumHeads,
        pModel->Cfg.DFf,
        pModel->Cfg.ContextLength,
        pModel->Cfg.VocabCount,
    };

    i32 isOk = 1;
    isOk = isOk && fwrite(c_sc_gpu_llm_magic, 1, 4, pFile) == 4;
    isOk = isOk && fwrite(&c_sc_gpu_llm_version, sizeof(u32), 1, pFile) == 1;
    isOk = isOk && fwrite(config, sizeof(i32), 6, pFile) == 6;

    i64 cursor = 0;
    for (i32 p = 0; p < pModel->NumParams && isOk; ++p)
    {
        ScGpuLlmParam* param = &pModel->aParams[p];
        isOk = fwrite(&param->Count, sizeof(i64), 1, pFile) == 1;
        isOk = isOk && fwrite(pHost + cursor, sizeof(f32), (size_t)param->Count, pFile) == (size_t)param->Count;
        cursor += param->Count;
    }

    i64 bpeLength = 0;
    char* pBpeData = pBpe.aVocab ? sc_ai_bpe_save_to_memory(pBpe, &bpeLength) : NULL;
    if (pBpeData)
    {
        isOk = isOk && fwrite(&bpeLength, sizeof(i64), 1, pFile) == 1;
        isOk = isOk && fwrite(pBpeData, 1, (size_t)bpeLength, pFile) == (size_t)bpeLength;
        sc_string_destroy(pBpeData);
    }
    else
    {
        // NOTE: CPU-версия требует BPE и падает без него; GPU-версия
        // пишет 0, чтобы чекпоинт весов можно было сохранить и без
        // токенизатора (например, из gradcheck/bench).
        i64 zero = 0;
        isOk = isOk && fwrite(&zero, sizeof(i64), 1, pFile) == 1;
        if (isOk)
            sc_log_warn("gpu-llm: checkpoint %s saved without embedded BPE\n", pPath);
    }

    if (isOk)
        isOk = fflush(pFile) == 0;
    if (fclose(pFile) != 0)
        isOk = 0;
    sc_memory_free(pHost);

    if (!isOk)
    {
        sc_log_erro("gpu-llm: failed to write checkpoint %s\n", pTmpPath);
        remove(pTmpPath);
        sc_memory_free(pTmpPath);
        return 0;
    }

    // DOCS: rename поверх существующего файла на Windows не работает,
    // поэтому старый чекпоинт удаляем. Битая запись уже отсеяна выше,
    // а до этого места старый файл остаётся нетронутым.
    remove(pPath);
    if (rename(pTmpPath, pPath) != 0)
    {
        sc_log_erro("gpu-llm: cannot replace checkpoint %s (new data in %s)\n",
            pPath, pTmpPath);
        sc_memory_free(pTmpPath);
        return 0;
    }

    sc_memory_free(pTmpPath);
    return 1;
}

ScGpuLlm*
sc_gpu_llm_load_checkpoint(ScGpu* pGpu, const char* pPath, ScAiBpe* pOutBpe)
{
    if (!pGpu || !pPath)
        return NULL;

    FILE* pFile = fopen(pPath, "rb");
    if (!pFile)
    {
        sc_log_erro("gpu-llm: cannot open checkpoint %s\n", pPath);
        return NULL;
    }

    char magic[4] = {};
    u32 version = 0;
    i32 config[6] = {};
    i32 isOk = 1;

    isOk = isOk && fread(magic, 1, 4, pFile) == 4;
    isOk = isOk && fread(&version, sizeof(u32), 1, pFile) == 1;
    isOk = isOk && fread(config, sizeof(i32), 6, pFile) == 6;
    isOk = isOk && memcmp(magic, c_sc_gpu_llm_magic, 4) == 0;
    isOk = isOk && version == c_sc_gpu_llm_version;

    if (!isOk)
    {
        sc_log_erro("gpu-llm: invalid checkpoint header %s\n", pPath);
        fclose(pFile);
        return NULL;
    }

    ScTinyLlmModelConfig cfg = sc_tiny_llm_model_config_default(config[5]);
    cfg.NumLayers = config[0];
    cfg.DModel = config[1];
    cfg.NumHeads = config[2];
    cfg.DFf = config[3];
    cfg.ContextLength = config[4];

    ScGpuLlm* pModel = _sc_gpu_llm_create_ext(pGpu, &cfg, 0);
    if (!pModel)
    {
        fclose(pFile);
        return NULL;
    }

    f32* pHost = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
    if (!pHost)
    {
        fclose(pFile);
        sc_gpu_llm_destroy(pModel);
        return NULL;
    }

    i64 cursor = 0;
    for (i32 p = 0; p < pModel->NumParams && isOk; ++p)
    {
        ScGpuLlmParam* param = &pModel->aParams[p];
        i64 count = 0;
        isOk = fread(&count, sizeof(i64), 1, pFile) == 1;
        isOk = isOk && count == param->Count;
        if (isOk)
            isOk = fread(pHost + cursor, sizeof(f32), (size_t)param->Count, pFile) == (size_t)param->Count;
        cursor += param->Count;
    }

    i64 bpeLength = 0;
    if (isOk)
        isOk = fread(&bpeLength, sizeof(i64), 1, pFile) == 1;

    char* pBpeData = NULL;
    if (isOk && bpeLength > 0)
    {
        pBpeData = sc_memory_allocate((u64)bpeLength + 1);
        if (!pBpeData)
            isOk = 0;
        else
        {
            isOk = fread(pBpeData, 1, (size_t)bpeLength, pFile) == (size_t)bpeLength;
            pBpeData[bpeLength] = '\0';
        }
    }

    fclose(pFile);

    if (isOk)
    {
        isOk = sc_gpu_upload(pGpu, pModel->GBuffer,
            (u64)pModel->DataOff * sizeof(f32), pHost,
            (u64)pModel->TotalParams * sizeof(f32));
    }

    if (isOk)
    {
        f32* pZero = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
        if (!pZero)
            isOk = 0;
        else
        {
            memset(pZero, 0, sizeof(f32) * (size_t)pModel->TotalParams);
            isOk = sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->GradOff * sizeof(f32),
                    pZero, (u64)pModel->TotalParams * sizeof(f32)) &&
                sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->MOff * sizeof(f32),
                    pZero, (u64)pModel->TotalParams * sizeof(f32)) &&
                sc_gpu_upload(pGpu, pModel->GBuffer, (u64)pModel->VOff * sizeof(f32),
                    pZero, (u64)pModel->TotalParams * sizeof(f32));
            sc_memory_free(pZero);
        }
    }

    sc_memory_free(pHost);

    if (isOk && pBpeData && pOutBpe)
        *pOutBpe = sc_ai_bpe_load_from_memory(pBpeData, bpeLength);

    if (pBpeData)
        sc_memory_free(pBpeData);

    if (!isOk)
    {
        sc_gpu_llm_destroy(pModel);
        return NULL;
    }

    return pModel;
}

/*
  ###################################
  eval / train
  ###################################
*/

// DOCS: Записывает forward+loss для одного окна и возвращает loss (сумму).
static f32
_sc_gpu_llm_forward_loss_slot(ScGpuLlm* pModel, i32 T)
{
    sc_gpu_cmd_begin(pModel->pGpu);
    _sc_gpu_llm_record_forward(pModel, 0, T);
    _sc_gpu_llm_record_loss(pModel, 0, 0, T, 0);
    _sc_gpu_llm_record_reduce_loss(pModel, 1);
    if (!sc_gpu_cmd_submit(pModel->pGpu))
        return 0.0f;
    return pModel->pAux[pModel->AuxLossSum];
}

f32
sc_gpu_llm_eval_window(ScGpuLlm* pModel, const i32* pTokens, const i32* pLabels,
    const i32* pMask, i32 T)
{
    if (!pModel || !pTokens || !pLabels || !pMask || T <= 0)
        return 0.0f;
    if (T > pModel->T)
        T = pModel->T;

    for (i32 t = 0; t < T; ++t)
    {
        pModel->aTokens[t] = pTokens[t];
        pModel->aLabels[t] = pLabels[t];
        pModel->aMask[t] = pMask[t];
    }
    _sc_gpu_llm_write_aux(pModel, 0, T, 0);
    return _sc_gpu_llm_forward_loss_slot(pModel, T);
}

f32
sc_gpu_llm_eval(ScGpuLlm* pModel, const ScTinyLlmDataset* pDataset,
    i32 batches, ScTinyLlmLossMask lossMask, u64 seed)
{
    if (!pModel || !pDataset || pDataset->Count <= 0 || batches <= 0)
        return 0.0f;

    f64 lossSum = 0.0;
    i64 tokenCount = 0;
    i32 ctx = pModel->T;
    i32 remaining = batches;

    while (remaining > 0)
    {
        i32 chunk = remaining > SC_GPU_LLM_MAX_BATCH ? SC_GPU_LLM_MAX_BATCH : remaining;
        i32 validCount = 0;
        i32 recorded = 0;

        // DOCS: сначала раскладываем окна по aux-слотам (host), потом
        // записываем один command buffer на весь chunk.
        for (i32 b = 0; b < chunk; ++b)
        {
            i32 globalB = batches - remaining + b;
            i64 exampleIndex = ((i64)globalB + (i64)(seed & 0x7fffffff)) % pDataset->Count;
            const ScTinyLlmExample* example = pDataset->aExamples + exampleIndex;
            i32 maxStart = (i32)(example->Count - 1 - ctx);
            if (maxStart < 0)
                maxStart = 0;
            i32 start = maxStart > 0 ? (i32)(((i64)globalB * ctx) % (maxStart + 1)) : 0;

            i32 T = 0;
            i32 valid = 0;
            if (!_sc_gpu_llm_fill_window(pModel, example, start, lossMask, &T, &valid) || valid <= 0)
            {
                _sc_gpu_llm_zero_loss_partials(pModel, b);
                continue;
            }

            _sc_gpu_llm_write_aux(pModel, b, T, 0);
            ++recorded;
            validCount += valid;
        }

        if (recorded <= 0)
        {
            remaining -= chunk;
            continue;
        }

        sc_gpu_cmd_begin(pModel->pGpu);

        for (i32 b = 0; b < chunk; ++b)
        {
            // NOTE: валидные слоты помечены тем, что их loss-частицы уже
            // могли быть записаны; проще повторить выбор окна.
            i32 globalB = batches - remaining + b;
            i64 exampleIndex = ((i64)globalB + (i64)(seed & 0x7fffffff)) % pDataset->Count;
            const ScTinyLlmExample* example = pDataset->aExamples + exampleIndex;
            i32 maxStart = (i32)(example->Count - 1 - ctx);
            if (maxStart < 0)
                maxStart = 0;
            i32 start = maxStart > 0 ? (i32)(((i64)globalB * ctx) % (maxStart + 1)) : 0;

            i32 T = 0;
            i32 valid = 0;
            if (!_sc_gpu_llm_fill_window(pModel, example, start, lossMask, &T, &valid) || valid <= 0)
                continue;

            _sc_gpu_llm_record_forward(pModel, (u32)b * pModel->SlotStride, T);
            _sc_gpu_llm_record_loss(pModel, (u32)b * pModel->SlotStride, b, T, 0);
        }

        _sc_gpu_llm_record_reduce_loss(pModel, chunk);
        if (!sc_gpu_cmd_submit(pModel->pGpu))
            break;

        lossSum += pModel->pAux[pModel->AuxLossSum];
        tokenCount += validCount;
        remaining -= chunk;
    }

    return tokenCount > 0 ? (f32)(lossSum / (f64)tokenCount) : 0.0f;
}

static f32
_sc_gpu_llm_lr_at(i32 step, const ScTinyLlmTrainConfig* pCfg)
{
    f32 base = pCfg->LearningRate;
    if (pCfg->WarmupSteps > 0 && step < pCfg->WarmupSteps)
        return base * ((f32)(step + 1) / (f32)pCfg->WarmupSteps);

    i32 total = pCfg->Steps > pCfg->WarmupSteps ? pCfg->Steps - pCfg->WarmupSteps : 1;
    i32 done = step - pCfg->WarmupSteps;
    if (done < 0)
        done = 0;
    if (done > total)
        done = total;

    f32 progress = (f32)done / (f32)total;
    f32 cosine = 0.5f * (1.0f + cosf(3.14159265358979323846f * progress));
    return base * (0.1f + 0.9f * cosine);
}

static void
_sc_gpu_llm_val_log_append(const char* pPath, i32 step, f32 valLoss)
{
    if (!pPath)
        return;

    i32 isFirstLine = 0;
    FILE* pProbe = fopen(pPath, "r");
    if (!pProbe)
        isFirstLine = 1;
    else
        fclose(pProbe);

    FILE* pFile = fopen(pPath, "a");
    if (!pFile)
        return;

    if (isFirstLine)
        fprintf(pFile, "step,val_loss,val_ppl\n");
    fprintf(pFile, "%d,%.6f,%.4f\n", step, valLoss, expf(valLoss));
    fclose(pFile);
}

i32
sc_gpu_llm_train(ScGpuLlm* pModel, ScAiBpe pBpe,
    const ScTinyLlmDataset* pTrain, const ScTinyLlmDataset* pValidation,
    const ScTinyLlmTrainConfig* pConfig)
{
    if (!pModel || !pTrain || pTrain->Count <= 0 || !pConfig || pConfig->Steps <= 0)
        return 0;

    ScTinyLlmTrainConfig cfg = *pConfig;
    if (cfg.BatchSize <= 0)
        cfg.BatchSize = 1;
    if (cfg.BatchSize > SC_GPU_LLM_MAX_BATCH)
        cfg.BatchSize = SC_GPU_LLM_MAX_BATCH;
    if (cfg.LearningRate <= 0.0f)
        cfg.LearningRate = 1e-3f;
    if (cfg.Seed == 0)
        cfg.Seed = 0x9e3779b97f4a7c15ULL;

    u64 rng = cfg.Seed;
    i32 ctx = pModel->T;
    i32 adamStep = 0;
    i32 lastStep = 0;
    i32 lastSavedStep = -1;

    f32 bestVal = 1e30f;
    i32 badEvals = 0;
    i32 shouldStop = 0;
    i32 failed = 0;

    f32* pBest = NULL;
    if (cfg.RestoreBest && cfg.EvalEvery > 0 && pValidation && pValidation->Count > 0)
    {
        pBest = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
        if (!pBest)
            sc_log_warn("gpu-llm: cannot allocate best-weights buffer\n");
    }

    f64 lossSum = 0.0;
    i64 lossTokens = 0;

    for (i32 step = 0; step < cfg.Steps && !shouldStop; ++step)
    {
        lastStep = step + 1;

        i32 aT[SC_GPU_LLM_MAX_BATCH] = {};
        i32 aValid[SC_GPU_LLM_MAX_BATCH] = {};
        i32 aU[SC_GPU_LLM_MAX_BATCH] = {};
        i32 actualBatch = 0;

        // DOCS: раскладываем весь batch в aux-слоты до submit'а.
        for (i32 b = 0; b < cfg.BatchSize; ++b)
        {
            i64 exampleIndex = (i64)(_sc_gpu_llm_rng_next(&rng) % (u64)pTrain->Count);
            const ScTinyLlmExample* example = pTrain->aExamples + exampleIndex;
            i32 maxStart = (i32)(example->Count - 1 - ctx);
            if (maxStart < 0)
                maxStart = 0;
            i32 start = maxStart > 0 ? (i32)(_sc_gpu_llm_rng_next(&rng) % (u64)(maxStart + 1)) : 0;

            i32 T = 0;
            i32 valid = 0;
            if (!_sc_gpu_llm_fill_window(pModel, example, start, cfg.LossMask, &T, &valid) || T <= 0)
            {
                _sc_gpu_llm_zero_loss_partials(pModel, b);
                continue;
            }

            aU[b] = _sc_gpu_llm_write_aux(pModel, b, T, 1);
            aT[b] = T;
            aValid[b] = valid;
            ++actualBatch;
        }

        if (actualBatch <= 0)
            continue;

        sc_gpu_cmd_begin(pModel->pGpu);
        _sc_gpu_llm_record_zero_grads(pModel);

        i64 stepTokens = 0;
        for (i32 b = 0; b < cfg.BatchSize; ++b)
        {
            if (aT[b] <= 0)
                continue;
            u32 base = (u32)b * pModel->SlotStride;
            _sc_gpu_llm_record_forward(pModel, base, aT[b]);
            _sc_gpu_llm_record_loss(pModel, base, b, aT[b], 1);
            _sc_gpu_llm_record_backward(pModel, base, aT[b], aU[b]);
            stepTokens += aValid[b];
        }

        _sc_gpu_llm_record_reduce_loss(pModel, cfg.BatchSize);

        f32 lr = _sc_gpu_llm_lr_at(step, &cfg);
        ++adamStep;
        _sc_gpu_llm_record_adamw(pModel, lr, adamStep, 1.0f / (f32)actualBatch,
            cfg.WeightDecay, cfg.GradClip);

        if (!sc_gpu_cmd_submit(pModel->pGpu))
        {
            failed = 1;
            break;
        }

        lossSum += pModel->pAux[pModel->AuxLossSum];
        lossTokens += stepTokens;

        if (cfg.LogEvery > 0 && (step + 1) % cfg.LogEvery == 0)
        {
            f32 avgLoss = lossTokens > 0 ? (f32)(lossSum / (f64)lossTokens) : 0.0f;
            f32 gradNorm = pModel->pAux[pModel->AuxNorm];
            printf("gpu-llm: step %d/%d loss %.4f lr %.6f grad %.3f\n",
                step + 1, cfg.Steps, avgLoss, lr, gradNorm);
            fflush(stdout);
            lossSum = 0.0;
            lossTokens = 0;
        }

        if (cfg.EvalEvery > 0 && pValidation && pValidation->Count > 0 &&
            (step + 1) % cfg.EvalEvery == 0)
        {
            f32 valLoss = sc_gpu_llm_eval(pModel, pValidation,
                cfg.EvalBatches > 0 ? cfg.EvalBatches : 1, cfg.LossMask, cfg.Seed);
            printf("gpu-llm: val step %d loss %.4f ppl %.2f\n",
                step + 1, valLoss, expf(valLoss));
            fflush(stdout);

            _sc_gpu_llm_val_log_append(cfg.pValLogPath, step + 1, valLoss);

            if (valLoss < bestVal - cfg.MinDelta)
            {
                bestVal = valLoss;
                badEvals = 0;
                if (pBest)
                {
                    sc_gpu_download(pModel->pGpu, pModel->GBuffer,
                        (u64)pModel->DataOff * sizeof(f32), pBest,
                        (u64)pModel->TotalParams * sizeof(f32));
                }
            }
            else
            {
                ++badEvals;
                if (cfg.Patience > 0 && badEvals >= cfg.Patience)
                {
                    printf("gpu-llm: early stop at step %d (best val %.4f)\n",
                        step + 1, bestVal);
                    shouldStop = 1;
                }
            }
        }

        if (cfg.pCheckpointPath && cfg.CheckpointEvery > 0 &&
            (step + 1) % cfg.CheckpointEvery == 0)
        {
            if (sc_gpu_llm_save_checkpoint(pModel, pBpe, cfg.pCheckpointPath))
            {
                printf("gpu-llm: checkpoint saved to %s\n", cfg.pCheckpointPath);
                lastSavedStep = step + 1;
            }
            else
            {
                sc_log_erro("gpu-llm: checkpoint save failed at step %d\n", step + 1);
            }
        }
    }

    if (pBest && bestVal < 1e29f)
    {
        sc_gpu_upload(pModel->pGpu, pModel->GBuffer,
            (u64)pModel->DataOff * sizeof(f32), pBest,
            (u64)pModel->TotalParams * sizeof(f32));
        printf("gpu-llm: restored best weights (val %.4f)\n", bestVal);

        if (cfg.pCheckpointPath && cfg.CheckpointEvery > 0 &&
            sc_gpu_llm_save_checkpoint(pModel, pBpe, cfg.pCheckpointPath))
        {
            printf("gpu-llm: checkpoint saved to %s\n", cfg.pCheckpointPath);
            lastSavedStep = lastStep;
        }
    }

    // DOCS: финальный чекпоинт. Нужен, если Steps не кратен CheckpointEvery,
    // обучение остановилось раньше или валидации нет вовсе (тогда выше
    // блок RestoreBest не выполняется). Без него последние шаги терялись.
    if (cfg.pCheckpointPath && cfg.CheckpointEvery > 0 &&
        lastStep > 0 && lastSavedStep != lastStep)
    {
        if (sc_gpu_llm_save_checkpoint(pModel, pBpe, cfg.pCheckpointPath))
            printf("gpu-llm: final checkpoint saved to %s (step %d)\n",
                cfg.pCheckpointPath, lastStep);
        else
            sc_log_erro("gpu-llm: final checkpoint save failed\n");
    }

    sc_memory_free(pBest);

    if (failed)
    {
        sc_log_erro("gpu-llm: training aborted: GPU command submission failed\n");
        return 0;
    }

    return 1;
}

/*
  ###################################
  generation
  ###################################
*/

static u32
_sc_gpu_llm_argmax(const f32* pLogits, i32 V)
{
    u32 best = 0;
    for (i32 v = 1; v < V; ++v)
    {
        if (pLogits[v] > pLogits[best])
            best = (u32)v;
    }
    return best;
}

static int
_sc_gpu_llm_candidate_compare(const void* pA, const void* pB)
{
    const ScGpuLlmCandidate* a = (const ScGpuLlmCandidate*)pA;
    const ScGpuLlmCandidate* b = (const ScGpuLlmCandidate*)pB;
    if (a->Prob < b->Prob)
        return 1;
    if (a->Prob > b->Prob)
        return -1;
    return 0;
}

static u32
_sc_gpu_llm_sample(const f32* pLogits, i32 V, const ScTinyLlmGenerateConfig* pCfg,
    ScGpuLlmCandidate* aCandidates, u64* pRng)
{
    if (pCfg->Temperature <= 1e-5f)
        return _sc_gpu_llm_argmax(pLogits, V);

    f32 maxLogit = pLogits[0];
    for (i32 v = 1; v < V; ++v)
    {
        if (pLogits[v] > maxLogit)
            maxLogit = pLogits[v];
    }

    f32 sum = 0.0f;
    for (i32 v = 0; v < V; ++v)
    {
        f32 value = expf((pLogits[v] - maxLogit) / pCfg->Temperature);
        aCandidates[v].Prob = value;
        aCandidates[v].Index = v;
        sum += value;
    }

    if (sum <= 0.0f)
        return _sc_gpu_llm_argmax(pLogits, V);

    for (i32 v = 0; v < V; ++v)
        aCandidates[v].Prob /= sum;

    qsort(aCandidates, (size_t)V, sizeof(ScGpuLlmCandidate), _sc_gpu_llm_candidate_compare);

    i32 selected = V;
    if (pCfg->TopK > 0 && pCfg->TopK < selected)
        selected = pCfg->TopK;

    f32 topP = pCfg->TopP;
    if (topP > 0.0f && topP < 1.0f)
    {
        f32 cumulative = 0.0f;
        i32 pCut = selected;
        for (i32 i = 0; i < selected; ++i)
        {
            cumulative += aCandidates[i].Prob;
            if (cumulative >= topP)
            {
                pCut = i + 1;
                break;
            }
        }
        if (pCut < selected)
            selected = pCut;
    }

    if (selected <= 0)
        selected = 1;

    f32 selectedSum = 0.0f;
    for (i32 i = 0; i < selected; ++i)
        selectedSum += aCandidates[i].Prob;

    if (selectedSum <= 0.0f)
        return (u32)aCandidates[0].Index;

    f32 r = _sc_gpu_llm_rng_f32(pRng) * selectedSum;
    f32 accumulated = 0.0f;
    for (i32 i = 0; i < selected; ++i)
    {
        accumulated += aCandidates[i].Prob;
        if (r <= accumulated)
            return (u32)aCandidates[i].Index;
    }

    return (u32)aCandidates[selected - 1].Index;
}

char*
sc_gpu_llm_generate(ScGpuLlm* pModel, ScAiBpe pBpe, const char* pPrompt,
    const ScTinyLlmGenerateConfig* pConfig)
{
    if (!pModel || !pPrompt)
        return sc_string_new_ext_ext_r("", 0, 0);

    ScTinyLlmGenerateConfig cfg = pConfig ? *pConfig : sc_tiny_llm_generate_config_default();
    if (cfg.MaxTokens <= 0)
        cfg.MaxTokens = 100;
    if (cfg.Seed == 0)
        cfg.Seed = 0x9e3779b97f4a7c15ULL;

    i32 ctx = pModel->T;
    i32 V = pModel->V;

    i32* aPrompt = NULL;
    sc_list_add(aPrompt, (i32)ScAiSpecialToken_Bos);

    i64 promptLength = sc_string_get_length((char*)pPrompt);
    if (promptLength > 0)
    {
        i32* aPromptTokens = sc_ai_bpe_tokenize((ScAiTokenizeConfig) {
            .pText = (char*)pPrompt,
            .TextLength = promptLength,
            .Bpe = pBpe,
        });

        if (aPromptTokens)
        {
            for (i64 i = 0; i < sc_list_count(aPromptTokens); ++i)
            {
                i32 token = aPromptTokens[i];
                if (token == ScAiSpecialToken_Bos && sc_list_count(aPrompt) == 1)
                    continue;
                sc_list_add(aPrompt, token);
            }
            sc_list_free(aPromptTokens);
        }
    }

    if (cfg.AppendSep &&
        (sc_list_count(aPrompt) == 0 || aPrompt[sc_list_count(aPrompt) - 1] != ScAiSpecialToken_Sep))
        sc_list_add(aPrompt, (i32)ScAiSpecialToken_Sep);

    i64 totalPrompt = sc_list_count(aPrompt);
    i64 maxPrompt = ctx > 1 ? ctx - 1 : 1;
    i64 first = totalPrompt > maxPrompt ? totalPrompt - maxPrompt : 0;

    // DOCS: промпт кладём сразу в aTokens (размер ровно ctx), а не в
    // стековый массив - ContextLength из чекпоинта не ограничен 1024.
    i32 pos = 0;
    for (i64 i = first; i < totalPrompt && pos < ctx; ++i, ++pos)
        pModel->aTokens[pos] = aPrompt[i];

    if (pos <= 0)
    {
        sc_list_free(aPrompt);
        return sc_string_new_ext_ext_r("", 0, 0);
    }

    f32* aLogits = sc_memory_allocate(sizeof(f32) * (size_t)V);
    ScGpuLlmCandidate* aCandidates = sc_memory_allocate(sizeof(ScGpuLlmCandidate) * (size_t)V);
    if (!aLogits || !aCandidates)
    {
        sc_memory_free(aLogits);
        sc_memory_free(aCandidates);
        sc_list_free(aPrompt);
        return sc_string_new_ext_ext_r("", 0, 0);
    }

    i32* aResult = NULL;
    u64 rng = cfg.Seed;

    // DOCS: префилл всего промпта одним полным forward'ом, затем
    // переносим K/V в кэш. Дальше на каждый токен - decode (M=1).
    for (i32 t = 0; t < pos; ++t)
    {
        pModel->aLabels[t] = (t + 1 < pos) ? pModel->aTokens[t + 1] : 0;
        pModel->aMask[t] = 1;
    }
    _sc_gpu_llm_write_aux(pModel, 0, pos, 0);

    sc_gpu_cmd_begin(pModel->pGpu);
    _sc_gpu_llm_record_forward(pModel, 0, pos);
    _sc_gpu_llm_record_kv_fill(pModel, pos);
    if (!sc_gpu_cmd_submit(pModel->pGpu) ||
        !sc_gpu_download(pModel->pGpu, pModel->GBuffer,
            (u64)(pModel->Logits + (u32)(pos - 1) * (u32)V) * sizeof(f32),
            aLogits, (u64)V * sizeof(f32)))
    {
        sc_list_free(aPrompt);
        sc_memory_free(aLogits);
        sc_memory_free(aCandidates);
        return sc_string_new_ext_ext_r("", 0, 0);
    }

    // DOCS: как в CPU-версии: пока есть место в окне и не исчерпан лимит.
    for (i32 i = 0; i < cfg.MaxTokens && pos < ctx; ++i)
    {
        u32 token = _sc_gpu_llm_sample(aLogits, V, &cfg, aCandidates, &rng);

        if (token == (u32)ScAiSpecialToken_Eos ||
            token == (u32)ScAiSpecialToken_Pad ||
            token == (u32)ScAiSpecialToken_Bos ||
            token == (u32)ScAiSpecialToken_Sep ||
            token == (u32)ScAiSpecialToken_Unk ||
            token == (u32)ScAiSpecialToken_Persona ||
            token == (u32)ScAiSpecialToken_Char ||
            token == (u32)ScAiSpecialToken_Emo ||
            token == (u32)ScAiSpecialToken_Sit)
            break;

        sc_list_add(aResult, (i32)token);

        // DOCS: следующий токен (индекс pos+1) существует только при
        // pos+1 < ctx; иначе forward не нужен.
        if (pos + 1 >= ctx || i + 1 >= cfg.MaxTokens)
            break;

        // DOCS: скормить только что выбранный токен на позиции pos;
        // K/V добавятся в кэш, Logits[0] даст распределение для pos+1.
        pModel->pAux[pModel->TokOff] = (f32)token;

        sc_gpu_cmd_begin(pModel->pGpu);
        _sc_gpu_llm_record_decode(pModel, 0, pos);
        if (!sc_gpu_cmd_submit(pModel->pGpu))
            break;

        ++pos;

        if (!sc_gpu_download(pModel->pGpu, pModel->GBuffer,
            (u64)pModel->Logits * sizeof(f32), aLogits, (u64)V * sizeof(f32)))
            break;
    }

    char* pText = sc_ai_bpe_decode(pBpe, aResult);

    sc_list_free(aResult);
    sc_list_free(aPrompt);
    sc_memory_free(aLogits);
    sc_memory_free(aCandidates);

    return pText;
}

/*
  ###################################
  gradient check
  ###################################
*/

i32
sc_gpu_llm_grad_check(ScGpuLlm* pModel, const i32* pTokens, const i32* pLabels,
    const i32* pMask, i32 T, i32 maxParams, f32 epsilon, f32 tolerance)
{
    if (!pModel || !pTokens || !pLabels || !pMask || T <= 0)
        return 0;
    if (T > pModel->T)
        T = pModel->T;
    if (maxParams <= 0)
        maxParams = 1;
    if (epsilon <= 0.0f)
        epsilon = 1e-3f;
    if (tolerance <= 0.0f)
        tolerance = 1e-2f;

    for (i32 t = 0; t < T; ++t)
    {
        pModel->aTokens[t] = pTokens[t];
        pModel->aLabels[t] = pLabels[t];
        pModel->aMask[t] = pMask[t];
    }
    i32 uniqueTokens = _sc_gpu_llm_write_aux(pModel, 0, T, 1);

    f32* pGradHost = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
    f32* pDataHost = sc_memory_allocate(sizeof(f32) * (size_t)pModel->TotalParams);
    if (!pGradHost || !pDataHost)
    {
        sc_memory_free(pGradHost);
        sc_memory_free(pDataHost);
        return 0;
    }

    sc_gpu_cmd_begin(pModel->pGpu);
    _sc_gpu_llm_record_zero_grads(pModel);
    _sc_gpu_llm_record_forward(pModel, 0, T);
    _sc_gpu_llm_record_loss(pModel, 0, 0, T, 1);
    _sc_gpu_llm_record_backward(pModel, 0, T, uniqueTokens);
    if (!sc_gpu_cmd_submit(pModel->pGpu))
    {
        sc_memory_free(pGradHost);
        sc_memory_free(pDataHost);
        return 0;
    }

    if (!sc_gpu_download(pModel->pGpu, pModel->GBuffer,
            (u64)pModel->GradOff * sizeof(f32), pGradHost,
            (u64)pModel->TotalParams * sizeof(f32)) ||
        !sc_gpu_download(pModel->pGpu, pModel->GBuffer,
            (u64)pModel->DataOff * sizeof(f32), pDataHost,
            (u64)pModel->TotalParams * sizeof(f32)))
    {
        sc_memory_free(pGradHost);
        sc_memory_free(pDataHost);
        return 0;
    }

    i32 checked = 0;
    i32 failed = 0;

    for (i32 p = 0; p < pModel->NumParams && failed < 5; ++p)
    {
        ScGpuLlmParam* param = &pModel->aParams[p];
        i32 limit = (i32)(param->Count < maxParams ? param->Count : maxParams);

        for (i32 i = 0; i < limit; ++i)
        {
            i64 localIndex = (i64)param->Index + i;
            f32 original = pDataHost[localIndex];
            f32 analytic = pGradHost[localIndex];

            f32 plus = original + epsilon;
            f32 minus = original - epsilon;
            u64 uploadOffset = (u64)(pModel->DataOff + param->Index + (u32)i) * sizeof(f32);

            if (!sc_gpu_upload(pModel->pGpu, pModel->GBuffer, uploadOffset, &plus, sizeof(f32)))
                break;
            f32 lossPlus = _sc_gpu_llm_forward_loss_slot(pModel, T);

            if (!sc_gpu_upload(pModel->pGpu, pModel->GBuffer, uploadOffset, &minus, sizeof(f32)))
                break;
            f32 lossMinus = _sc_gpu_llm_forward_loss_slot(pModel, T);

            sc_gpu_upload(pModel->pGpu, pModel->GBuffer, uploadOffset, &original, sizeof(f32));

            f32 numeric = (lossPlus - lossMinus) / (2.0f * epsilon);
            f32 absDiff = fabsf(numeric - analytic);
            f32 denom = fabsf(numeric) + fabsf(analytic);
            if (denom < 1.0f)
                denom = 1.0f;
            f32 relative = absDiff / denom;
            ++checked;

            if (absDiff > tolerance && relative > tolerance)
            {
                printf("gpu-llm grad check: %s[%d] numeric %g analytic %g abs %g rel %g\n",
                    param->Name, i, numeric, analytic, absDiff, relative);
                ++failed;
                if (failed >= 5)
                    break;
            }
        }
    }

    sc_gpu_cmd_begin(pModel->pGpu);
    _sc_gpu_llm_record_zero_grads(pModel);
    sc_gpu_cmd_submit(pModel->pGpu);

    sc_memory_free(pGradHost);
    sc_memory_free(pDataHost);

    printf("gpu-llm grad check: checked %d, failed %d\n", checked, failed);
    return checked > 0 && failed == 0;
}
