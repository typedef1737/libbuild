/*
  GpuTinyLLM - обучение TinyLlm на Vulkan compute.

  Запуск из корня репозитория:
    masuka -b release -p windows -e gpu_tiny_llm -nr
    bin\release-windows\gpu_tiny_llm.exe bench
    bin\release-windows\gpu_tiny_llm.exe train --easy D:\books
    bin\release-windows\gpu_tiny_llm.exe chat --easy D:\books
    bin\release-windows\gpu_tiny_llm.exe gen --checkpoint lm.ckpt --prompt "Once upon a time"

  Требования:
    * GPU с Vulkan 1.0 compute (Windows: vulkan-1.dll, Linux: libvulkan.so.1);
    * glslc из Vulkan SDK в PATH или VULKAN_SDK - шейдеры компилируются
      при первом запуске в shaders/.bin (по одному .spv на ядро).

  Команды:
    bench      - синтетические данные, замер шага (по умолчанию);
    train      - обучение на текстовом корпусе (--pack включён по умолчанию);
    eval       - loss на корпусе по чекпоинту;
    compare    - GPU vs CPU loss по одному чекпоинту и одним окнам;
    chat       - интерактивное продолжение текста (KV-кэш);
    gen        - генерация по чекпоинту (KV-кэш);
    gradcheck  - численная проверка градиентов на GPU.

  Общие флаги:
    --shaders <dir>   каталог с kernels.glsl;
    --model <name>    micro|medium|target (для bench/train без чекпоинта);
    --vocab <n>       словарь для bench без BPE (по умолчанию 8265);
    --checkpoint <p>  загрузить SCTL-чекпоинт (и BPE из него);
    --easy <dir>      всё из одного каталога: *.bpe + ldata/train + val + model.ckpt;
    --bpe <p>         BPE-словарь для train/gradcheck;
    --corpus <p>      файл или каталог с текстовыми файлами (txt/text);
    --val <p>         отдельный файл/каталог для валидации;
    --seed <n>        seed (десятичный или 0x...);

  train:
    --steps <n> --batch <n> --lr <f> --wd <f> --warmup <n> --clip <f>
    --log-every <n> --eval-every <n> --eval-batches <n> --patience <n>
    -o <path> --ckpt-every <n> (default 1000) --val-log <path>
    --pack включён по умолчанию (склейка <BOS>строка<EOS> в окна ctx+1);
    --no-pack - построчная загрузка (как lm_train без --pack)

  gen:
    --prompt <text> --tokens <n> --temp <f> --top-k <n> --top-p <f>

  gradcheck:
    --check-params <n> --eps <f> --tol <f>
*/

#if !defined(_WIN32) && !defined(_POSIX_C_SOURCE)
#define _POSIX_C_SOURCE 199309L
#endif

#include "GpuTinyLlm.h"

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#if defined(SC_PLATFORM_WINDOWS)
#include <windows.h>
#endif

static f64
_now_seconds(void)
{
#if defined(SC_PLATFORM_WINDOWS)
    LARGE_INTEGER frequency;
    LARGE_INTEGER counter;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&counter);
    return (f64)counter.QuadPart / (f64)frequency.QuadPart;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (f64)ts.tv_sec + (f64)ts.tv_nsec * 1e-9;
#endif
}

#define GpuDefaultVocab 8265
#define GpuDefaultSeed 0x5c0deULL
#define GpuDefaultValLog "gpu_val.csv"

static const char*
_flag(i32 argc, char** argv, const char* pName, const char* pDefault)
{
    i64 nameLength = sc_string_get_length((char*)pName);

    for (i32 i = 1; i < argc; ++i)
    {
        if (sc_string_compare(argv[i], (char*)pName))
            return (i + 1 < argc) ? argv[i + 1] : pDefault;

        // DOCS: поддержка формы --name=value (раньше молча игнорировалась).
        if (nameLength > 0 &&
            sc_string_get_length(argv[i]) > nameLength &&
            argv[i][nameLength] == '=' &&
            sc_string_compare_ext(argv[i], (char*)pName, nameLength))
            return argv[i] + nameLength + 1;
    }
    return pDefault;
}

static i32
_has_flag(i32 argc, char** argv, const char* pName)
{
    for (i32 i = 1; i < argc; ++i)
    {
        if (sc_string_compare(argv[i], (char*)pName))
            return 1;
    }
    return 0;
}

static const char* c_gpu_commands[] = {
    "bench", "train", "eval", "compare", "chat", "gen", "gradcheck",
};

static i32
_is_command(const char* pArgument)
{
    for (i32 c = 0; c < (i32)(sizeof(c_gpu_commands) / sizeof(c_gpu_commands[0])); ++c)
    {
        if (sc_string_compare((char*)pArgument, (char*)c_gpu_commands[c]))
            return 1;
    }
    return 0;
}

static i32
_flag_takes_value(const char* pArgument)
{
    if (!pArgument || pArgument[0] != '-')
        return 0;

    // DOCS: только известные флаги съедают следующий аргумент. Неизвестный
    // флаг команду не проглатывает (--verbose2 train -> команда train).
    static const char* aValueFlags[] = {
        "--shaders", "--model", "--vocab", "--checkpoint", "--easy", "--bpe",
        "--corpus", "--val", "--seed", "--steps", "--batch", "--lr", "--wd",
        "--warmup", "--clip", "--log-every", "--eval-every", "--eval-batches",
        "--patience", "--min-delta", "-o", "--ckpt-every", "--val-log",
        "--prompt", "--tokens", "--temp", "--top-k", "--topk", "--top-p",
        "--max", "--check-params", "--eps", "--tol",
    };

    i64 argumentLength = sc_string_get_length((char*)pArgument);
    for (i32 i = 0; i < (i32)(sizeof(aValueFlags) / sizeof(aValueFlags[0])); ++i)
    {
        const char* pName = aValueFlags[i];
        i64 nameLength = sc_string_get_length((char*)pName);

        if (argumentLength == nameLength &&
            sc_string_compare_ext((char*)pArgument, (char*)pName, nameLength))
            return 1;

        // DOCS: --name=value уже содержит значение.
        if (argumentLength > nameLength && pArgument[nameLength] == '=' &&
            sc_string_compare_ext((char*)pArgument, (char*)pName, nameLength))
            return 0;
    }
    return 0;
}

static const char*
_command(i32 argc, char** argv)
{
    // DOCS: команда ищется среди позиционных аргументов, но значения флагов
    // пропускаются. Раньше, например, --prompt "train" выбирал команду train.
    for (i32 i = 1; i < argc; ++i)
    {
        if (_is_command(argv[i]))
            return argv[i];
        if (_flag_takes_value(argv[i]))
            ++i;
    }
    return "bench";
}

static u64
_parse_seed(const char* pText, u64 pDefault)
{
    if (!pText)
        return pDefault;
    if (pText[0] == '0' && (pText[1] == 'x' || pText[1] == 'X'))
        return (u64)strtoull(pText, NULL, 16);
    return (u64)strtoull(pText, NULL, 10);
}

static ScTinyLlmSize
_parse_size(const char* pName)
{
    if (pName && sc_string_compare((char*)pName, "medium"))
        return ScTinyLlmSize_Medium;
    if (pName && sc_string_compare((char*)pName, "target"))
        return ScTinyLlmSize_Target;
    return ScTinyLlmSize_Micro;
}

static const char*
_detect_shader_dir(const char* pRequested)
{
    if (pRequested)
        return pRequested;

    const char* aCandidates[] = {
        "shaders",
        "Examples/GpuTinyLLM/shaders",
        "../shaders",
        "../../Examples/GpuTinyLLM/shaders",
    };

    for (i32 i = 0; i < (i32)(sizeof(aCandidates) / sizeof(aCandidates[0])); ++i)
    {
        char path[512];
        snprintf(path, sizeof(path), "%s/kernels.glsl", aCandidates[i]);
        // DOCS: проверка существования без fopen (иначе MSVC/clang ругаются
        // на deprecated fopen). API Sc переносимый.
        if (sc_path(path) == ScPathItemType_File)
            return aCandidates[i];
    }

    return "shaders";
}

static i32
_is_text_file(const char* pPath)
{
    i64 length = sc_string_get_length((char*)pPath);
    if (length >= 4)
    {
        const char* p = pPath + length - 4;
        if (p[0] == '.' && (p[1] == 't' || p[1] == 'T') &&
            (p[2] == 'x' || p[2] == 'X') && (p[3] == 't' || p[3] == 'T'))
            return 1;
    }
    if (length >= 5)
    {
        const char* p = pPath + length - 5;
        if (p[0] == '.' && (p[1] == 't' || p[1] == 'T') &&
            (p[2] == 'e' || p[2] == 'E') && (p[3] == 'x' || p[3] == 'X') &&
            (p[4] == 't' || p[4] == 'T'))
            return 1;
    }
    return 0;
}

static char
_ascii_lower(char c)
{
    return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c;
}

static i32
_str_eq_ci(const char* pA, const char* pB)
{
    if (!pA || !pB)
        return 0;

    while (*pA && *pB)
    {
        if (_ascii_lower(*pA) != _ascii_lower(*pB))
            return 0;
        ++pA;
        ++pB;
    }
    return *pA == '\0' && *pB == '\0';
}

static i32
_str_ends_ci(const char* pString, const char* pSuffix)
{
    if (!pString || !pSuffix)
        return 0;

    i64 stringLength = sc_string_get_length((char*)pString);
    i64 suffixLength = sc_string_get_length((char*)pSuffix);
    if (suffixLength <= 0 || suffixLength > stringLength)
        return 0;

    return _str_eq_ci(pString + stringLength - suffixLength, pSuffix);
}

/*
  DOCS: рекурсивный сбор *.txt и *.text. Работает и на Windows, и на Linux,
  потому что используется только переносимый API Sc. pExcludeDir позволяет
  не брать val-каталог, если train задан корнем --easy.
*/
static void
_collect_text_files(const char* pPath, const char* pExcludeDir,
    char*** ppFiles, i32 depth)
{
    if (!pPath || !ppFiles || depth > 32)
        return;

    if (pExcludeDir && pExcludeDir[0] && _str_eq_ci(pPath, pExcludeDir))
        return;

    ScPathItemType type = sc_path(pPath);
    if (type == ScPathItemType_File)
    {
        if (_is_text_file(pPath))
        {
            char* pCopy = sc_string_copy((char*)pPath, sc_string_get_length((char*)pPath));
            if (pCopy)
                sc_list_add(*ppFiles, pCopy);
        }
        return;
    }
    if (type != ScPathItemType_Directory)
        return;

    char** aDirs = sc_directory_get_directories(pPath, 1);
    for (i32 i = 0; aDirs && i < (i32)sc_list_count(aDirs); ++i)
    {
        _collect_text_files(aDirs[i], pExcludeDir, ppFiles, depth + 1);
        sc_memory_free(aDirs[i]);
    }
    sc_list_free(aDirs);

    char** aFiles = sc_directory_get_files(pPath, 1);
    for (i32 i = 0; aFiles && i < (i32)sc_list_count(aFiles); ++i)
    {
        // DOCS: val может быть отдельным файлом (val.txt); его нельзя
        // добавлять в train, иначе validation loss = train loss.
        if (pExcludeDir && pExcludeDir[0] && _str_eq_ci(aFiles[i], pExcludeDir))
        {
            sc_memory_free(aFiles[i]);
            continue;
        }

        if (_is_text_file(aFiles[i]))
        {
            char* pCopy = sc_string_copy((char*)aFiles[i], sc_string_get_length((char*)aFiles[i]));
            if (pCopy)
                sc_list_add(*ppFiles, pCopy);
        }
        sc_memory_free(aFiles[i]);
    }
    sc_list_free(aFiles);
}

static void
_free_string_list(char** aStrings)
{
    for (i32 i = 0; aStrings && i < (i32)sc_list_count(aStrings); ++i)
        sc_memory_free(aStrings[i]);
    sc_list_free(aStrings);
}

static char*
_dup_string(const char* pString)
{
    if (!pString)
        return NULL;
    return sc_string_copy((char*)pString, sc_string_get_length((char*)pString));
}

static char*
_join_path(const char* pDir, const char* pName)
{
    if (!pDir || !pName)
        return NULL;
    return sc_path_combine((char*)pDir, (char*)pName);
}

/*
  DOCS: первый файл с нужным суффиксом. Сначала смотрим каталог, потом
  подкаталоги (depth ограничивает вложенность). Только переносимый API Sc.
*/
static char*
_find_first_suffix(const char* pPath, const char* pSuffix, i32 depth)
{
    if (!pPath || !pSuffix)
        return NULL;

    ScPathItemType type = sc_path(pPath);
    if (type == ScPathItemType_File)
        return _str_ends_ci(pPath, pSuffix) ? _dup_string(pPath) : NULL;
    if (type != ScPathItemType_Directory || depth < 0)
        return NULL;

    char* pFound = NULL;

    char** aFiles = sc_directory_get_files(pPath, 1);
    for (i32 i = 0; aFiles && i < (i32)sc_list_count(aFiles); ++i)
    {
        if (!pFound && _str_ends_ci(aFiles[i], pSuffix))
            pFound = _dup_string(aFiles[i]);
        sc_memory_free(aFiles[i]);
    }
    sc_list_free(aFiles);

    if (pFound)
        return pFound;

    char** aDirs = sc_directory_get_directories(pPath, 1);
    for (i32 i = 0; aDirs && i < (i32)sc_list_count(aDirs); ++i)
    {
        if (!pFound)
            pFound = _find_first_suffix(aDirs[i], pSuffix, depth - 1);
        sc_memory_free(aDirs[i]);
    }
    sc_list_free(aDirs);

    return pFound;
}

static char*
_first_existing(const char* pDir, const char* const* apNames, i32 count,
    ScPathItemType wanted)
{
    for (i32 i = 0; i < count; ++i)
    {
        char* pPath = _join_path(pDir, apNames[i]);
        if (pPath && sc_path(pPath) == wanted)
            return pPath;
        if (pPath)
            sc_memory_free(pPath);
    }
    return NULL;
}

static char*
_easy_bpe_path(const char* pDir)
{
    static const char* aNames[] = {
        "bpe.bpe", "tokenizer.bpe", "vocab.bpe", "merges.bpe", "books.bpe",
    };
    char* pPath = _first_existing(pDir, aNames,
        (i32)(sizeof(aNames) / sizeof(aNames[0])), ScPathItemType_File);
    if (pPath)
        return pPath;
    return _find_first_suffix(pDir, ".bpe", 1);
}

static char*
_easy_train_path(const char* pDir)
{
    static const char* aNames[] = {
        "ldata", "train", "learn", "data", "corpus", "text", "texts", "txt",
    };
    char* pPath = _first_existing(pDir, aNames,
        (i32)(sizeof(aNames) / sizeof(aNames[0])), ScPathItemType_Directory);
    if (pPath)
        return pPath;

    // DOCS: нет отдельного каталога — берём сам --easy и обходим рекурсивно.
    return _dup_string(pDir);
}

static char*
_easy_val_path(const char* pDir)
{
    static const char* aDirs[] = {
        "val", "valid", "validation", "eval", "test",
    };
    static const char* aFiles[] = {
        "val.txt", "valid.txt", "validation.txt", "test.txt",
    };

    char* pPath = _first_existing(pDir, aDirs,
        (i32)(sizeof(aDirs) / sizeof(aDirs[0])), ScPathItemType_Directory);
    if (pPath)
        return pPath;
    return _first_existing(pDir, aFiles,
        (i32)(sizeof(aFiles) / sizeof(aFiles[0])), ScPathItemType_File);
}

static char*
_easy_ckpt_path(const char* pDir)
{
    char* pPath = _join_path(pDir, "model.ckpt");
    if (pPath && sc_path(pPath) == ScPathItemType_File)
        return pPath;
    if (pPath)
        sc_memory_free(pPath);

    // DOCS: если в --easy уже лежит чекпоинт с другим именем, пишем в него.
    char* pFound = _find_first_suffix(pDir, ".ckpt", 0);
    if (pFound)
        return pFound;

    return _join_path(pDir, "model.ckpt");
}

#define GpuMaxPath 4096

typedef struct GpuEasyPaths
{
    char Bpe[GpuMaxPath];
    char Train[GpuMaxPath];
    char Val[GpuMaxPath];
    char Ckpt[GpuMaxPath];
    char ValLog[GpuMaxPath];
    i32 HasBpe;
    i32 HasTrain;
    i32 HasVal;
    i32 HasCkpt;
} GpuEasyPaths;

static i32
_store_path(char* pDst, char* pHeap)
{
    pDst[0] = '\0';
    if (!pHeap)
        return 1;

    i32 written = snprintf(pDst, GpuMaxPath, "%s", pHeap);
    sc_memory_free(pHeap);

    if (written < 0 || written >= GpuMaxPath)
    {
        printf("error: --easy path is too long (%d chars, max %d)\n",
            written, GpuMaxPath - 1);
        pDst[0] = '\0';
        return 0;
    }
    return 1;
}

static i32
_resolve_easy(const char* pEasyDir, GpuEasyPaths* pEasy)
{
    if (!pEasyDir)
        return 0;

    if (sc_path(pEasyDir) != ScPathItemType_Directory)
    {
        printf("error: --easy expects a directory, got '%s'\n", pEasyDir);
        return -1;
    }

    i32 storeOk = 1;
    if (!_store_path(pEasy->Bpe, _easy_bpe_path(pEasyDir)))
        storeOk = 0;
    if (!_store_path(pEasy->Train, _easy_train_path(pEasyDir)))
        storeOk = 0;
    if (!_store_path(pEasy->Val, _easy_val_path(pEasyDir)))
        storeOk = 0;
    if (!_store_path(pEasy->Ckpt, _easy_ckpt_path(pEasyDir)))
        storeOk = 0;
    if (!_store_path(pEasy->ValLog, _join_path(pEasyDir, "val.csv")))
        storeOk = 0;
    if (!storeOk)
        return -1;

    pEasy->HasBpe = pEasy->Bpe[0] != '\0';
    pEasy->HasTrain = pEasy->Train[0] != '\0';
    pEasy->HasVal = pEasy->Val[0] != '\0';
    pEasy->HasCkpt = pEasy->Ckpt[0] != '\0' &&
        sc_path(pEasy->Ckpt) == ScPathItemType_File;

    printf("easy: dir=%s\n", pEasyDir);
    printf("easy: bpe=%s\n", pEasy->HasBpe ? pEasy->Bpe : "(not found, pass --bpe)");
    printf("easy: train=%s\n", pEasy->HasTrain ? pEasy->Train : "(not found)");
    printf("easy: val=%s\n", pEasy->HasVal ? pEasy->Val : "(none, eval/early-stop off)");
    printf("easy: checkpoint=%s%s\n", pEasy->Ckpt[0] ? pEasy->Ckpt : "(default)",
        pEasy->HasCkpt ? "" : " (not found)");
    printf("easy: val-log=%s\n", pEasy->ValLog[0] ? pEasy->ValLog : GpuDefaultValLog);
    fflush(stdout);

    return 1;
}

static i32
_load_corpus_path(const char* pPath, ScAiBpe bpe, ScTinyLlmDataset* pDataset,
    const char* pExcludeDir)
{
    ScPathItemType type = sc_path(pPath);

    if (type == ScPathItemType_Directory)
    {
        char** aFiles = NULL;
        _collect_text_files(pPath, pExcludeDir, &aFiles, 0);

        i32 total = aFiles ? (i32)sc_list_count(aFiles) : 0;
        i32 loaded = 0;
        for (i32 i = 0; i < total; ++i)
        {
            printf("load: %d/%d %s\n", i + 1, total, aFiles[i]);
            fflush(stdout);

            if (sc_tiny_llm_dataset_load_file(pDataset, bpe, aFiles[i]))
                ++loaded;
        }

        _free_string_list(aFiles);
        return loaded;
    }

    if (type == ScPathItemType_File)
    {
        printf("load: %s\n", pPath);
        fflush(stdout);
        return sc_tiny_llm_dataset_load_file(pDataset, bpe, pPath) ? 1 : 0;
    }

    printf("error: no such file or directory: %s\n", pPath);
    return 0;
}

/*
  ###################################
  --pack: <BOS>строка<EOS> в непрерывный поток,
  окна ctx+1 с шагом ctx (как lm_train --pack)
  ###################################
*/

typedef struct
{
    ScTinyLlmDataset* pDataset;
    i32 Ctx;
    i32* aPending;
    i32 PendingCount;
    i64 Windows;
} GpuPacker;

static i32*
_tokenize_packed_line(ScAiBpe bpe, char* pText, i64 start, i64 end, i32* pCount)
{
    i64 lineStart = start;
    i64 lineEnd = end;

    if (lineEnd > lineStart && pText[lineEnd - 1] == '\r')
        --lineEnd;

    if (lineEnd <= lineStart || pText[lineStart] == '#')
        return NULL;

    if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineEnd - 5, "<EOS>", 5))
        lineEnd -= 5;
    if (lineEnd - lineStart >= 5 && sc_string_compare_ext(pText + lineStart, "<BOS>", 5))
        lineStart += 5;

    if (lineEnd <= lineStart)
        return NULL;

    char* pBuilder = sc_builder_new();
    sc_builder_append_string(pBuilder, "<BOS>", 5);
    sc_builder_append_string(pBuilder, pText + lineStart, lineEnd - lineStart);
    sc_builder_append_string(pBuilder, "<EOS>", 5);

    i64 lineLength = sc_builder_count(pBuilder);
    char* pLine = sc_string_new_ext_ext_r(pBuilder, lineLength, lineLength);
    sc_builder_destroy(pBuilder);

    i32* aTokens = sc_ai_bpe_tokenize((ScAiTokenizeConfig) {
        .pText = pLine,
        .TextLength = lineLength,
        .Bpe = bpe,
    });
    sc_string_destroy(pLine);

    if (!aTokens)
        return NULL;
    *pCount = (i32)sc_list_count(aTokens);
    return aTokens;
}

/*
  DOCS: локальная версия sc_tiny_llm_dataset_add_tokens.
  Нужна, чтобы пример собирался и со старыми Sc, где этой функции ещё нет.
  Копия строится через sc_list - так же, как внутри Sc, поэтому
  sc_tiny_llm_dataset_destroy освобождает её тем же sc_list_free.
*/
static i32
_gpu_dataset_add_tokens(ScTinyLlmDataset* pDataset, const i32* aTokens, i64 Count)
{
    if (!pDataset || !aTokens || Count < 2)
        return 0;

    i32 sepIndex = -1;
    for (i64 i = 0; i < Count; ++i)
    {
        if (aTokens[i] == ScAiSpecialToken_Sep)
            sepIndex = (i32)i;
    }

    i32* aCopy = NULL;
    for (i64 i = 0; i < Count; ++i)
        sc_list_add(aCopy, aTokens[i]);

    ScTinyLlmExample example = {
        .aTokens = aCopy,
        .Count = Count,
        .SepIndex = sepIndex,
    };

    sc_list_add(pDataset->aExamples, example);
    ++pDataset->Count;
    return 1;
}

static void
_packer_push(GpuPacker* pPacker, const i32* aTokens, i32 Count)
{
    if (!pPacker || !aTokens || Count <= 0)
        return;

    for (i32 i = 0; i < Count; ++i)
    {
        pPacker->aPending[pPacker->PendingCount++] = aTokens[i];
        if (pPacker->PendingCount == pPacker->Ctx + 1)
        {
            if (_gpu_dataset_add_tokens(pPacker->pDataset,
                    pPacker->aPending, pPacker->PendingCount))
                ++pPacker->Windows;

            pPacker->aPending[0] = pPacker->aPending[pPacker->Ctx];
            pPacker->PendingCount = 1;
        }
    }
}

static i32
_pack_file(const char* pPath, ScAiBpe bpe, GpuPacker* pPacker)
{
    i64 size = 0;
    char* pData = sc_file_read_ext_ext_r(pPath, &size);
    if (!pData || size <= 0)
    {
        if (pData)
            sc_memory_free(pData);
        return 0;
    }

    i64 start = 0;
    i64 i = 0;
    if (size >= 3 && (u8)pData[0] == 0xEF && (u8)pData[1] == 0xBB && (u8)pData[2] == 0xBF)
    {
        start = 3;
        i = 3;
    }

    i32 lines = 0;
    i64 nextLog = 1 * 1024 * 1024;
    for (; i <= size; ++i)
    {
        // DOCS: для одного большого файла иначе не видно прогресса минутами.
        if (i >= nextLog)
        {
            printf("pack:   %s: %.0f%% (%.0f/%.0f MB)\n", pPath,
                100.0 * (f64)i / (f64)size,
                (f64)i / 1048576.0, (f64)size / 1048576.0);
            fflush(stdout);
            nextLog += 1 * 1024 * 1024;
        }

        if (i != size && pData[i] != '\n')
            continue;

        i32 count = 0;
        i32* aTokens = _tokenize_packed_line(bpe, pData, start, i, &count);
        if (aTokens)
        {
            _packer_push(pPacker, aTokens, count);
            sc_list_free(aTokens);
            ++lines;
        }
        start = i + 1;
    }

    sc_memory_free(pData);
    return lines > 0;
}

static i32
_pack_corpus_path(const char* pPath, ScAiBpe bpe, i32 ctx,
    ScTinyLlmDataset* pDataset, const char* pExcludeDir)
{
    if (ctx > 512)
        ctx = 512;

    GpuPacker packer = {
        .pDataset = pDataset,
        .Ctx = ctx,
        .aPending = sc_memory_allocate(sizeof(i32) * (size_t)(ctx + 1)),
    };
    if (!packer.aPending)
        return 0;

    ScPathItemType type = sc_path(pPath);
    i32 files = 0;

    if (type != ScPathItemType_Directory && type != ScPathItemType_File)
    {
        printf("error: corpus path not found: %s\n", pPath);
        sc_memory_free(packer.aPending);
        return 0;
    }

    char** aFiles = NULL;
    _collect_text_files(pPath, pExcludeDir, &aFiles, 0);

    i32 totalFiles = aFiles ? (i32)sc_list_count(aFiles) : 0;
    if (totalFiles <= 0)
    {
        printf("pack: no *.txt/*.text files in %s\n", pPath);
        _free_string_list(aFiles);
        sc_memory_free(packer.aPending);
        return 0;
    }

    for (i32 i = 0; i < totalFiles; ++i)
    {
        // DOCS: токенизация файла может занять секунды-минуты,
        // поэтому показываем прогресс, а не молчим до конца.
        printf("pack: %d/%d %s\n", i + 1, totalFiles, aFiles[i]);
        fflush(stdout);

        if (_pack_file(aFiles[i], bpe, &packer))
            ++files;
    }
    _free_string_list(aFiles);

    printf("pack: %s: files=%d windows=%lld tokens_in_windows=%lld\n",
        pPath, files, (long long)packer.Windows, (long long)(packer.Windows * (ctx + 1)));

    sc_memory_free(packer.aPending);
    return packer.Windows > 0;
}

static void
_make_synthetic_dataset(ScTinyLlmDataset* pDataset, i32 vocabCount, i32 ctx, i32 examples, u64 seed)
{
    i32 length = ctx * 3;
    if (length < 32)
        length = 32;

    i32* aTokens = sc_memory_allocate(sizeof(i32) * (size_t)length);
    if (!aTokens)
        return;

    u64 rng = seed ? seed : GpuDefaultSeed;
    i32 firstTextToken = (i32)ScAiSpecialToken_Sit + 1;
    if (firstTextToken >= vocabCount)
        firstTextToken = 0;

    for (i32 e = 0; e < examples; ++e)
    {
        for (i32 i = 0; i < length; ++i)
        {
            rng ^= rng << 13;
            rng ^= rng >> 7;
            rng ^= rng << 17;
            aTokens[i] = firstTextToken + (i32)(rng % (u64)(vocabCount - firstTextToken));
        }
        _gpu_dataset_add_tokens(pDataset, aTokens, length);
    }

    sc_memory_free(aTokens);
}

static void
_print_model_info2(ScGpuLlm* pModel, ScGpu* pGpu)
{
    if (!pModel)
        return;

    ScTinyLlmModelConfig cfg = sc_gpu_llm_config(pModel);
    printf("model: layers=%d d_model=%d heads=%d d_ff=%d ctx=%d vocab=%d params=%lld\n",
        cfg.NumLayers, cfg.DModel, cfg.NumHeads, cfg.DFf, cfg.ContextLength,
        cfg.VocabCount, (long long)sc_gpu_llm_param_count(pModel));
    printf("gpu: device=%s model_mem=%.1f MB total_mem=%.1f MB\n",
        sc_gpu_device_name(pGpu),
        (f64)sc_gpu_llm_memory_bytes(pModel) / (1024.0 * 1024.0),
        (f64)sc_gpu_llm_total_memory_bytes(pModel) / (1024.0 * 1024.0));
    fflush(stdout);
}

static ScGpuLlm*
_create_or_load_model(ScGpu* pGpu, const char* pCheckpoint, ScAiBpe bpe,
    i32 hasBpe, const char* pModelName, i32 vocabOverride, ScAiBpe* pOutBpe)
{
    if (pCheckpoint)
    {
        printf("model: loading checkpoint %s...\n", pCheckpoint);
        fflush(stdout);

        ScGpuLlm* pModel = sc_gpu_llm_load_checkpoint(pGpu, pCheckpoint, pOutBpe);
        if (!pModel)
        {
            printf("error: cannot load checkpoint %s\n", pCheckpoint);
            printf("  gpu: %s\n", sc_gpu_last_error(pGpu));
        }
        else
        {
            printf("model: ready\n");
            fflush(stdout);
        }
        return pModel;
    }

    i32 vocabCount = hasBpe ? (i32)sc_list_count(bpe.aVocab) : vocabOverride;
    if (vocabCount <= (i32)ScAiSpecialToken_Sit + 1)
        vocabCount = GpuDefaultVocab;

    ScTinyLlmModelConfig cfg =
        sc_tiny_llm_model_config_preset(_parse_size(pModelName), vocabCount);
    cfg.Seed = GpuDefaultSeed;

    printf("model: creating %s (compiling shaders on first run)...\n", pModelName);
    fflush(stdout);

    ScGpuLlm* pModel = sc_gpu_llm_create(pGpu, &cfg);
    if (!pModel)
    {
        printf("error: cannot create GPU model (shaders/glslc/VRAM)\n");
        printf("  gpu: %s\n", sc_gpu_last_error(pGpu));
    }
    else
    {
        printf("model: ready\n");
        fflush(stdout);
    }
    return pModel;
}

static i32
_cmd_bench(i32 argc, char** argv, ScGpu* pGpu)
{
    const char* pCheckpoint = _flag(argc, argv, "--checkpoint", NULL);
    const char* pBpePath = _flag(argc, argv, "--bpe", NULL);
    i32 vocabOverride = atoi(_flag(argc, argv, "--vocab", "8265"));
    i32 steps = atoi(_flag(argc, argv, "--steps", "20"));
    i32 batch = atoi(_flag(argc, argv, "--batch", "8"));

    ScAiBpe bpe = {};
    i32 hasBpe = 0;
    if (pBpePath)
    {
        bpe = sc_ai_bpe_load_from_disk((char*)pBpePath);
        hasBpe = sc_list_count(bpe.aVocab) > 0;
    }

    ScAiBpe loadedBpe = {};
    ScGpuLlm* pModel = _create_or_load_model(pGpu, pCheckpoint, bpe, hasBpe,
        _flag(argc, argv, "--model", "micro"), vocabOverride, &loadedBpe);
    if (!pModel)
        return 1;

    ScTinyLlmModelConfig cfg = sc_gpu_llm_config(pModel);
    ScTinyLlmDataset dataset = sc_tiny_llm_dataset_new();
    _make_synthetic_dataset(&dataset, cfg.VocabCount, cfg.ContextLength, 16, GpuDefaultSeed);
    if (dataset.Count <= 0)
    {
        printf("error: cannot build synthetic dataset\n");
        sc_gpu_llm_destroy(pModel);
        return 1;
    }

    _print_model_info2(pModel, pGpu);

    ScTinyLlmTrainConfig trainCfg = sc_tiny_llm_train_config_default();
    trainCfg.Steps = steps > 0 ? steps : 20;
    trainCfg.BatchSize = batch > 0 ? batch : 8;
    trainCfg.LearningRate = 1e-3f;
    trainCfg.WeightDecay = 0.01f;
    trainCfg.WarmupSteps = 0;
    trainCfg.GradClip = 1.0f;
    trainCfg.LossMask = ScTinyLlmLossMask_None;
    trainCfg.LogEvery = 0;
    trainCfg.EvalEvery = 0;
    trainCfg.CheckpointEvery = 0;
    trainCfg.RestoreBest = 0;
    trainCfg.Seed = GpuDefaultSeed;

    i64 tokens = (i64)trainCfg.Steps * trainCfg.BatchSize * cfg.ContextLength;
    printf("bench: steps=%d batch=%d ctx=%d (~%lld tokens)\n",
        trainCfg.Steps, trainCfg.BatchSize, cfg.ContextLength, (long long)tokens);
    fflush(stdout);

    f64 start = _now_seconds();
    i32 ok = sc_gpu_llm_train(pModel, bpe, &dataset, NULL, &trainCfg);
    f64 end = _now_seconds();

    if (!ok)
    {
        printf("error: training step failed\n");
        sc_gpu_llm_destroy(pModel);
        sc_tiny_llm_dataset_destroy(&dataset);
        return 1;
    }

    f64 seconds = end - start;
    if (seconds <= 0.0)
        seconds = 1e-9;
    printf("bench: %.3f s total, %.2f ms/step, %.2f ms/token, %.0f tokens/s\n",
        seconds, seconds * 1000.0 / (f64)trainCfg.Steps,
        seconds * 1000.0 / (f64)tokens, (f64)tokens / seconds);

    sc_gpu_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&dataset);
    if (bpe.aVocab)
        sc_ai_bpe_destroy(&bpe);
    if (loadedBpe.aVocab)
        sc_ai_bpe_destroy(&loadedBpe);
    return 0;
}

static i32
_cmd_train(i32 argc, char** argv, ScGpu* pGpu)
{
    /*
      DOCS: --easy <dir> — один каталог со всем нужным:
        <dir>/<name>.bpe            BPE-словарь (или вложенный, ищется рекурсивно);
        <dir>/ldata|train|...       обучающий корпус (иначе весь <dir>);
        <dir>/val|valid|...         валидация (если есть);
        <dir>/model.ckpt            чекпоинт (или первый найденный .ckpt).
      Явные флаги --bpe/--corpus/--val/-o/--val-log всегда переопределяют.
    */
    const char* pEasyDir = _flag(argc, argv, "--easy", NULL);
    GpuEasyPaths easy = {};
    const char* pEasyValLog = GpuDefaultValLog;

    i32 easyResult = _resolve_easy(pEasyDir, &easy);
    if (easyResult < 0)
        return 1;
    if (easy.ValLog[0])
        pEasyValLog = easy.ValLog;

    const char* pBpePath = _flag(argc, argv, "--bpe", easy.HasBpe ? easy.Bpe : NULL);
    const char* pCorpus = _flag(argc, argv, "--corpus", easy.HasTrain ? easy.Train : NULL);
    const char* pValPath = _flag(argc, argv, "--val", easy.HasVal ? easy.Val : NULL);
    const char* pCheckpoint = _flag(argc, argv, "--checkpoint", NULL);
    const char* pOutPath = _flag(argc, argv, "-o",
        easy.Ckpt[0] ? easy.Ckpt : "gpu_lm.ckpt");
    const char* pValLog = _flag(argc, argv, "--val-log", pEasyValLog);
    const char* pModelName = _flag(argc, argv, "--model", "medium");

    if (!pCorpus)
    {
        printf("error: train requires --corpus <file|dir> or --easy <dir>\n");
        return 1;
    }

    if (!pCheckpoint && easy.HasCkpt)
    {
        printf("easy: existing checkpoint found; pass --checkpoint %s to resume\n",
            easy.Ckpt);
        fflush(stdout);
    }

    // DOCS: если train и val — один и тот же путь, не исключаем его из train,
    // иначе обучающих окон не останется.
    const char* pExcludeVal = pValPath;
    if (pValPath && pCorpus && _str_eq_ci(pValPath, pCorpus))
    {
        printf("warn: --val equals --corpus; training without validation split\n");
        pExcludeVal = NULL;
        pValPath = NULL;
    }

    ScAiBpe bpe = {};
    if (pBpePath)
    {
        bpe = sc_ai_bpe_load_from_disk((char*)pBpePath);
        if (sc_list_count(bpe.aVocab) <= 0)
        {
            printf("error: cannot load BPE %s\n", pBpePath);
            return 1;
        }
        printf("bpe: %s vocab=%lld\n", pBpePath, (long long)sc_list_count(bpe.aVocab));
        fflush(stdout);
    }
    else if (!pCheckpoint)
    {
        printf("error: no BPE found; pass --bpe <file.bpe> or put *.bpe into --easy dir\n");
        return 1;
    }

    if (!pCheckpoint)
    {
        printf("model: preset=%s\n", pModelName);
        fflush(stdout);
    }

    ScAiBpe loadedBpe = {};
    ScGpuLlm* pModel = _create_or_load_model(pGpu, pCheckpoint, bpe,
        sc_list_count(bpe.aVocab) > 0, pModelName,
        GpuDefaultVocab, &loadedBpe);
    if (!pModel)
        return 1;

    if (pCheckpoint && sc_list_count(loadedBpe.aVocab) > 0)
    {
        if (bpe.aVocab)
            sc_ai_bpe_destroy(&bpe);
        bpe = loadedBpe;
    }

    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: no BPE available (checkpoint has none; pass --bpe <file.bpe>)\n");
        sc_gpu_llm_destroy(pModel);
        return 1;
    }

    printf("data: tokenizing %s (BPE merges; first time can take minutes)...\n", pCorpus);
    fflush(stdout);

    ScTinyLlmDataset trainDataset = sc_tiny_llm_dataset_new();
    ScTinyLlmDataset valDataset = sc_tiny_llm_dataset_new();

    // DOCS: по умолчанию train использует упакованные окна (--pack).
    // --no-pack оставляет построчную загрузку (как lm_train без --pack).
    i32 isPack = !_has_flag(argc, argv, "--no-pack");
    printf("data: mode=%s\n", isPack ? "packed (ctx+1 windows)" : "lines");
    fflush(stdout);

    ScTinyLlmModelConfig modelCfg = sc_gpu_llm_config(pModel);

    i32 trainCount = 0;
    i32 valCount = 0;

    if (isPack)
    {
        trainCount = _pack_corpus_path(pCorpus, bpe, modelCfg.ContextLength,
            &trainDataset, pExcludeVal) ? 1 : 0;
        if (pValPath)
        {
            printf("data: tokenizing val %s...\n", pValPath);
            fflush(stdout);
            valCount = _pack_corpus_path(pValPath, bpe, modelCfg.ContextLength,
                &valDataset, NULL) ? 1 : 0;
        }
    }
    else
    {
        trainCount = _load_corpus_path(pCorpus, bpe, &trainDataset, pExcludeVal);
        if (pValPath)
        {
            printf("data: tokenizing val %s...\n", pValPath);
            fflush(stdout);
            valCount = _load_corpus_path(pValPath, bpe, &valDataset, NULL);
        }
    }

    if (trainCount <= 0)
    {
        printf("error: no training examples in %s\n", pCorpus);
        sc_gpu_llm_destroy(pModel);
        return 1;
    }

    ScTinyLlmTrainConfig trainCfg = sc_tiny_llm_train_config_default();
    /*
      DOCS: дефолты подобраны под типовой прогон на RX 6800 XT:
      medium, ~30k шагов, batch 4, lr 1e-3. Любой флаг переопределяется.
    */
    trainCfg.Steps = atoi(_flag(argc, argv, "--steps", "30000"));
    trainCfg.BatchSize = atoi(_flag(argc, argv, "--batch", "4"));
    trainCfg.LearningRate = (f32)atof(_flag(argc, argv, "--lr", "0.001"));
    trainCfg.WeightDecay = (f32)atof(_flag(argc, argv, "--wd", "0.01"));
    trainCfg.WarmupSteps = atoi(_flag(argc, argv, "--warmup", "300"));
    trainCfg.GradClip = (f32)atof(_flag(argc, argv, "--clip", "1.0"));
    trainCfg.LogEvery = atoi(_flag(argc, argv, "--log-every", "100"));
    trainCfg.EvalEvery = valCount > 0 ? atoi(_flag(argc, argv, "--eval-every", "500")) : 0;
    trainCfg.EvalBatches = atoi(_flag(argc, argv, "--eval-batches", "8"));
    trainCfg.Patience = atoi(_flag(argc, argv, "--patience", "5"));
    trainCfg.MinDelta = (f32)atof(_flag(argc, argv, "--min-delta", "0.0001"));
    trainCfg.LossMask = ScTinyLlmLossMask_None;
    trainCfg.pCheckpointPath = (char*)pOutPath;
    // DOCS: чекпоинт пишется редко: запись большого файла на GPU-обучении
    // заметно дороже, чем шаг. Можно переопределить через --ckpt-every.
    trainCfg.CheckpointEvery = atoi(_flag(argc, argv, "--ckpt-every", "1000"));
    trainCfg.pValLogPath = (char*)pValLog;
    trainCfg.RestoreBest = 1;
    trainCfg.Seed = _parse_seed(_flag(argc, argv, "--seed", NULL), GpuDefaultSeed);

    _print_model_info2(pModel, pGpu);
    printf("data: train=%lld examples val=%lld examples\n",
        (long long)trainDataset.Count, (long long)valDataset.Count);

    // DOCS: пользователь должен видеть пути до старта долгого прогона.
    printf("io: checkpoint=%s every=%d\n", pOutPath, trainCfg.CheckpointEvery);
    if (trainCfg.EvalEvery > 0)
        printf("io: val-log=%s every=%d\n", pValLog, trainCfg.EvalEvery);
    printf("train: steps=%d batch=%d lr=%.5f wd=%.5f warmup=%d clip=%.2f\n",
        trainCfg.Steps, trainCfg.BatchSize, trainCfg.LearningRate,
        trainCfg.WeightDecay, trainCfg.WarmupSteps, trainCfg.GradClip);
    fflush(stdout);

    f32 before = valCount > 0
        ? sc_gpu_llm_eval(pModel, &valDataset, 20, ScTinyLlmLossMask_None, trainCfg.Seed)
        : 0.0f;

    i32 ok = sc_gpu_llm_train(pModel, bpe, &trainDataset,
        valCount > 0 ? &valDataset : NULL, &trainCfg);

    if (!ok)
        printf("error: training failed\n");

    if (valCount > 0)
    {
        f32 after = sc_gpu_llm_eval(pModel, &valDataset, 20, ScTinyLlmLossMask_None, trainCfg.Seed);
        printf("train: val loss %.4f -> %.4f (ppl %.2f -> %.2f)\n",
            before, after, expf(before), expf(after));
    }

    if (ok)
        printf("done: checkpoint %s (weights + config + embedded BPE)\n", pOutPath);

    sc_gpu_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&trainDataset);
    sc_tiny_llm_dataset_destroy(&valDataset);
    if (bpe.aVocab)
        sc_ai_bpe_destroy(&bpe);
    return ok ? 0 : 1;
}

static i32
_cmd_eval(i32 argc, char** argv, ScGpu* pGpu)
{
    GpuEasyPaths easy = {};
    if (_resolve_easy(_flag(argc, argv, "--easy", NULL), &easy) < 0)
        return 1;

    const char* pCheckpoint = _flag(argc, argv, "--checkpoint",
        easy.HasCkpt ? easy.Ckpt : NULL);
    // DOCS: для eval/compare логично брать held-out val, если он есть в --easy.
    const char* pCorpus = _flag(argc, argv, "--corpus",
        easy.HasVal ? easy.Val : (easy.HasTrain ? easy.Train : NULL));
    if (!pCheckpoint || !pCorpus)
    {
        printf("error: eval requires --checkpoint <ckpt> and --corpus <file|dir>\n");
        printf("       or --easy <dir> containing a checkpoint and train data\n");
        return 1;
    }

    ScAiBpe bpe = {};
    ScGpuLlm* pModel = sc_gpu_llm_load_checkpoint(pGpu, pCheckpoint, &bpe);
    if (!pModel)
        return 1;
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: checkpoint has no embedded BPE\n");
        sc_gpu_llm_destroy(pModel);
        return 1;
    }

    ScTinyLlmDataset dataset = sc_tiny_llm_dataset_new();
    i32 count = _load_corpus_path(pCorpus, bpe, &dataset, NULL);
    if (count <= 0)
    {
        printf("error: no examples in %s\n", pCorpus);
        sc_gpu_llm_destroy(pModel);
        sc_ai_bpe_destroy(&bpe);
        return 1;
    }

    i32 batches = atoi(_flag(argc, argv, "--eval-batches", "32"));
    // DOCS: seed выбирает окна так же, как lm_train (LmTrainSeed=0x5c0de),
    // поэтому loss можно сравнивать с CPU-логом валидации.
    u64 seed = _parse_seed(_flag(argc, argv, "--seed", NULL), GpuDefaultSeed);

    _print_model_info2(pModel, pGpu);
    printf("eval: %lld examples, %d windows, seed=0x%llx\n",
        (long long)dataset.Count, batches, (unsigned long long)seed);

    f32 loss = sc_gpu_llm_eval(pModel, &dataset, batches, ScTinyLlmLossMask_None, seed);
    printf("eval: loss %.4f ppl %.2f\n", loss, expf(loss));

    sc_gpu_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&dataset);
    sc_ai_bpe_destroy(&bpe);
    return 0;
}

/*
  compare: загружает один и тот же SCTL-чекпоинт в GPU- и CPU-модель и
  считает loss на одних и тех же окнах (seed детерминирован). Это самый
  прямой тест численной совместимости forward на реальном железе.
*/
static i32
_cmd_compare(i32 argc, char** argv, ScGpu* pGpu)
{
    GpuEasyPaths easy = {};
    if (_resolve_easy(_flag(argc, argv, "--easy", NULL), &easy) < 0)
        return 1;

    const char* pCheckpoint = _flag(argc, argv, "--checkpoint",
        easy.HasCkpt ? easy.Ckpt : NULL);
    const char* pCorpus = _flag(argc, argv, "--corpus",
        easy.HasVal ? easy.Val : (easy.HasTrain ? easy.Train : NULL));
    if (!pCheckpoint || !pCorpus)
    {
        printf("error: compare requires --checkpoint <ckpt> and --corpus <file|dir>\n");
        printf("       or --easy <dir> containing a checkpoint and train data\n");
        return 1;
    }

    ScAiBpe gpuBpe = {};
    ScGpuLlm* pGpuModel = sc_gpu_llm_load_checkpoint(pGpu, pCheckpoint, &gpuBpe);
    if (!pGpuModel)
        return 1;

    ScAiBpe cpuBpe = {};
    ScTinyLlmModel* pCpuModel = sc_tiny_llm_load_checkpoint(pCheckpoint, &cpuBpe);
    if (!pCpuModel)
    {
        sc_gpu_llm_destroy(pGpuModel);
        if (gpuBpe.aVocab)
            sc_ai_bpe_destroy(&gpuBpe);
        return 1;
    }

    // DOCS: BPE берём из GPU-модели, иначе из CPU-модели (они одинаковы,
    // если чекпоинт один и тот же).
    ScAiBpe bpe = sc_list_count(gpuBpe.aVocab) > 0 ? gpuBpe : cpuBpe;
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: checkpoint has no embedded BPE\n");
        sc_gpu_llm_destroy(pGpuModel);
        sc_tiny_llm_destroy(pCpuModel);
        if (cpuBpe.aVocab)
            sc_ai_bpe_destroy(&cpuBpe);
        if (gpuBpe.aVocab)
            sc_ai_bpe_destroy(&gpuBpe);
        return 1;
    }

    ScTinyLlmDataset dataset = sc_tiny_llm_dataset_new();
    if (_load_corpus_path(pCorpus, bpe, &dataset, NULL) <= 0)
    {
        printf("error: no examples in %s\n", pCorpus);
        sc_gpu_llm_destroy(pGpuModel);
        sc_tiny_llm_destroy(pCpuModel);
        sc_tiny_llm_dataset_destroy(&dataset);
        if (cpuBpe.aVocab)
            sc_ai_bpe_destroy(&cpuBpe);
        if (gpuBpe.aVocab)
            sc_ai_bpe_destroy(&gpuBpe);
        return 1;
    }

    i32 batches = atoi(_flag(argc, argv, "--eval-batches", "8"));
    u64 seed = _parse_seed(_flag(argc, argv, "--seed", NULL), GpuDefaultSeed);
    f32 tolerance = (f32)atof(_flag(argc, argv, "--tol", "0.01"));

    _print_model_info2(pGpuModel, pGpu);
    printf("compare: %lld examples, %d windows, seed=0x%llx\n",
        (long long)dataset.Count, batches, (unsigned long long)seed);

    f32 gpuLoss = sc_gpu_llm_eval(pGpuModel, &dataset, batches, ScTinyLlmLossMask_None, seed);
    f32 cpuLoss = sc_tiny_llm_eval(pCpuModel, &dataset, batches, ScTinyLlmLossMask_None, seed);
    f32 diff = fabsf(gpuLoss - cpuLoss);

    printf("compare: cpu loss %.6f | gpu loss %.6f | diff %.6f (tol %.6f)\n",
        cpuLoss, gpuLoss, diff, tolerance);
    printf("compare: %s\n", diff <= tolerance ? "PASS" : "FAIL");

    sc_gpu_llm_destroy(pGpuModel);
    sc_tiny_llm_destroy(pCpuModel);
    sc_tiny_llm_dataset_destroy(&dataset);
    if (cpuBpe.aVocab)
        sc_ai_bpe_destroy(&cpuBpe);
    if (gpuBpe.aVocab)
        sc_ai_bpe_destroy(&gpuBpe);

    return diff <= tolerance ? 0 : 1;
}

/*
  chat: интерактивное продолжение текста на GPU (как lm_chat).
  Каждая строка - независимый промпт; генерация использует KV-кэш.
*/
static i32
_cmd_chat(i32 argc, char** argv, ScGpu* pGpu)
{
    GpuEasyPaths easy = {};
    if (_resolve_easy(_flag(argc, argv, "--easy", NULL), &easy) < 0)
        return 1;

    const char* pCheckpoint = _flag(argc, argv, "--checkpoint", NULL);
    if (!pCheckpoint)
    {
        // DOCS: позиционно чекпоинт можно передать как `chat <ckpt>`;
        // берём только аргумент сразу после команды, иначе значения
        // других флагов (--temp 0.7) ошибочно считались чекпоинтом.
        for (i32 i = 1; i < argc; ++i)
        {
            if (!sc_string_compare(argv[i], "chat"))
                continue;
            if (i + 1 < argc && argv[i + 1][0] != '-')
                pCheckpoint = argv[i + 1];
            break;
        }
    }
    if (!pCheckpoint && easy.HasCkpt)
        pCheckpoint = easy.Ckpt;
    if (!pCheckpoint)
    {
        printf("error: chat requires --checkpoint <ckpt> or --easy <dir>\n");
        return 1;
    }

    ScAiBpe bpe = {};
    ScGpuLlm* pModel = sc_gpu_llm_load_checkpoint(pGpu, pCheckpoint, &bpe);
    if (!pModel)
        return 1;
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: checkpoint has no embedded BPE\n");
        sc_gpu_llm_destroy(pModel);
        return 1;
    }

    const char* pMax = _flag(argc, argv, "--max", NULL);
    if (!pMax)
        pMax = _flag(argc, argv, "--tokens", "64");

    ScTinyLlmGenerateConfig cfg = sc_tiny_llm_generate_config_default();
    cfg.MaxTokens = atoi(pMax);
    cfg.Temperature = (f32)atof(_flag(argc, argv, "--temp", "0.8"));
    cfg.TopK = atoi(_flag(argc, argv, "--top-k", _flag(argc, argv, "--topk", "40")));
    cfg.TopP = (f32)atof(_flag(argc, argv, "--top-p", "0.95"));
    cfg.Seed = _parse_seed(_flag(argc, argv, "--seed", NULL), GpuDefaultSeed);
    // DOCS: чистое продолжение текста (LM-прелюдия): без <SEP>.
    cfg.AppendSep = 0;

#ifdef SC_PLATFORM_WINDOWS
    SetConsoleCP(65001);
    SetConsoleOutputCP(65001);
#endif

    _print_model_info2(pModel, pGpu);
    printf("chat: temp=%.2f top-k=%d max=%d seed=0x%llx (generation uses KV cache)\n",
        cfg.Temperature, cfg.TopK, cfg.MaxTokens, (unsigned long long)cfg.Seed);
    printf("type a prompt, or 'exit' to quit\n\n");

    char buf[2048] = {};
    while (1)
    {
        printf("> ");
        fflush(stdout);

        if (!fgets(buf, (i32)sizeof(buf), stdin))
            break;

        i64 length = (i64)strlen(buf);
        while (length > 0 && (buf[length - 1] == '\n' || buf[length - 1] == '\r'))
            --length;
        buf[length] = 0;

        if (length == 0)
            continue;
        if (sc_string_compare(buf, "exit") || sc_string_compare(buf, "quit"))
            break;

        char* pAnswer = sc_gpu_llm_generate(pModel, bpe, buf, &cfg);
        printf("> %s\n\n", pAnswer ? pAnswer : "(generation failed)");
        if (pAnswer)
            sc_string_destroy(pAnswer);
    }

    printf("\nbye\n");
    sc_gpu_llm_destroy(pModel);
    sc_ai_bpe_destroy(&bpe);
    return 0;
}

static i32
_cmd_gen(i32 argc, char** argv, ScGpu* pGpu)
{
    GpuEasyPaths easy = {};
    if (_resolve_easy(_flag(argc, argv, "--easy", NULL), &easy) < 0)
        return 1;

    const char* pCheckpoint = _flag(argc, argv, "--checkpoint",
        easy.HasCkpt ? easy.Ckpt : NULL);
    const char* pPrompt = _flag(argc, argv, "--prompt", "");
    if (!pCheckpoint)
    {
        printf("error: gen requires --checkpoint <ckpt> or --easy <dir>\n");
        return 1;
    }

    ScAiBpe bpe = {};
    ScGpuLlm* pModel = sc_gpu_llm_load_checkpoint(pGpu, pCheckpoint, &bpe);
    if (!pModel)
        return 1;
    if (sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: checkpoint has no embedded BPE\n");
        sc_gpu_llm_destroy(pModel);
        return 1;
    }

    ScTinyLlmGenerateConfig cfg = sc_tiny_llm_generate_config_default();
    cfg.MaxTokens = atoi(_flag(argc, argv, "--tokens", "80"));
    cfg.Temperature = (f32)atof(_flag(argc, argv, "--temp", "0.8"));
    cfg.TopK = atoi(_flag(argc, argv, "--top-k", "40"));
    cfg.TopP = (f32)atof(_flag(argc, argv, "--top-p", "0.95"));
    cfg.Seed = _parse_seed(_flag(argc, argv, "--seed", NULL), GpuDefaultSeed);
    cfg.AppendSep = 0;

    _print_model_info2(pModel, pGpu);
    printf("prompt: %s\n", pPrompt);
    fflush(stdout);

    char* pText = sc_gpu_llm_generate(pModel, bpe, pPrompt, &cfg);
    printf("answer: %s\n", pText ? pText : "");
    if (pText)
        sc_string_destroy(pText);

    sc_gpu_llm_destroy(pModel);
    sc_ai_bpe_destroy(&bpe);
    return 0;
}

static i32
_cmd_gradcheck(i32 argc, char** argv, ScGpu* pGpu)
{
    ScAiBpe bpe = {};
    const char* pCheckpoint = _flag(argc, argv, "--checkpoint", NULL);
    ScAiBpe loadedBpe = {};
    ScGpuLlm* pModel = _create_or_load_model(pGpu, pCheckpoint, bpe, 0,
        _flag(argc, argv, "--model", "micro"),
        atoi(_flag(argc, argv, "--vocab", "8265")), &loadedBpe);
    if (!pModel)
        return 1;

    ScTinyLlmModelConfig cfg = sc_gpu_llm_config(pModel);
    i32 T = 8;
    if (T > cfg.ContextLength - 1)
        T = cfg.ContextLength - 1;

    i32 aTokens[64] = {};
    i32 aLabels[64] = {};
    i32 aMask[64] = {};
    i32 firstTextToken = (i32)ScAiSpecialToken_Sit + 1;
    if (firstTextToken >= cfg.VocabCount)
        firstTextToken = 0;

    for (i32 t = 0; t < T + 1; ++t)
        aTokens[t] = firstTextToken + (t * 17) % (cfg.VocabCount - firstTextToken);
    for (i32 t = 0; t < T; ++t)
    {
        aLabels[t] = aTokens[t + 1];
        aMask[t] = 1;
    }

    i32 maxParams = atoi(_flag(argc, argv, "--check-params", "1"));
    f32 epsilon = (f32)atof(_flag(argc, argv, "--eps", "0.001"));
    f32 tolerance = (f32)atof(_flag(argc, argv, "--tol", "0.01"));

    _print_model_info2(pModel, pGpu);
    printf("gradcheck: T=%d maxParams=%d eps=%g tol=%g\n", T, maxParams, epsilon, tolerance);
    fflush(stdout);

    i32 ok = sc_gpu_llm_grad_check(pModel, aTokens, aLabels, aMask, T,
        maxParams, epsilon, tolerance);

    printf("gradcheck: %s\n", ok ? "PASS" : "FAIL");

    sc_gpu_llm_destroy(pModel);
    if (bpe.aVocab)
        sc_ai_bpe_destroy(&bpe);
    if (loadedBpe.aVocab)
        sc_ai_bpe_destroy(&loadedBpe);
    return ok ? 0 : 1;
}

static void
_print_usage(void)
{
    printf("usage: gpu_tiny_llm <command> [options]\n\n");
    printf("commands:\n");
    printf("  bench      synthetic training steps, throughput (default)\n");
    printf("  train      train on --corpus and write a checkpoint\n");
    printf("  eval       loss on a corpus for an existing checkpoint\n");
    printf("  compare    GPU vs CPU loss on the same checkpoint/windows\n");
    printf("  chat       interactive text continuation (KV cache)\n");
    printf("  gen        one-shot generation from a prompt\n");
    printf("  gradcheck  finite-difference gradient check\n\n");
    printf("easy mode (recommended):\n");
    printf("  --easy <dir>   auto-discover everything from one directory:\n");
    printf("                   *.bpe          BPE vocabulary (searched recursively)\n");
    printf("                   ldata/ train/  training corpus (else <dir> itself)\n");
    printf("                   val/ valid/    validation corpus (optional)\n");
    printf("                   model.ckpt     checkpoint (or first *.ckpt)\n");
    printf("                 explicit --bpe/--corpus/--val/-o/--val-log win.\n\n");
    printf("model (bench/train/gradcheck only):\n");
    printf("  --model micro|medium|target   (train default: medium)\n");
    printf("  eval/compare/chat/gen take the model from --checkpoint;\n");
    printf("  a checkpoint can only be used with the preset it was trained with.\n\n");
    printf("train defaults: --steps 30000 --batch 4 --lr 0.001 --wd 0.01\n");
    printf("  --warmup 300 --clip 1.0 --log-every 100 --ckpt-every 1000\n");
    printf("  --eval-every 500 --eval-batches 8 --patience 5 --pack\n");
    printf("  --no-pack disables packed windows; --min-delta <f> for early stop.\n\n");
    printf("common: --shaders <dir> --seed <n> --checkpoint <ckpt> --vocab <n>\n\n");
    printf("examples:\n");
    printf("  gpu_tiny_llm bench --model medium --steps 100 --batch 4\n");
    printf("  gpu_tiny_llm train --easy D:\\books\n");
    printf("  gpu_tiny_llm train --bpe books.bpe --corpus D:\\books --val D:\\books-val\n");
    printf("  gpu_tiny_llm chat --easy D:\\books\n");
    printf("  gpu_tiny_llm chat --checkpoint medium.ckpt\n");
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    if (_has_flag(argc, argv, "--help") || _has_flag(argc, argv, "-h"))
    {
        _print_usage();
        return 0;
    }

    if (argc == 1)
    {
        _print_usage();
        return 0;
    }

    // DOCS: раньше неизвестное слово молча игнорировалось и запускался bench
    // с micro. Теперь это явная ошибка с подсказкой.
    if (argv[1][0] != '-' && !_is_command(argv[1]))
    {
        printf("error: unknown command '%s'\n\n", argv[1]);
        _print_usage();
        return 2;
    }

    const char* pCommand = _command(argc, argv);
    const char* pShaderDir = _detect_shader_dir(_flag(argc, argv, "--shaders", NULL));

    // DOCS: включаем терминальный лог Sc (sc_log_info из VkGpu.c иначе молчит).
    // Файловый backend не подключаем, чтобы не плодить лог-файлы.
    ScLogBackend aLogBackends[] = { sc_log_get_terminal_backend() };
    sc_log_init((ScLogConfig) {
        .BackendsCount = 1,
        .aBackends = aLogBackends,
    });

    printf("=== GpuTinyLLM (%s) ===\n", pCommand);
    printf("args:");
    for (i32 i = 1; i < argc; ++i)
        printf(" %s", argv[i]);
    printf("\n");
    printf("shaders: %s\n", pShaderDir);
    fflush(stdout);

    ScGpuConfig gpuCfg = {
        .pShaderDir = pShaderDir,
        .Verbose = 1,
    };

    ScGpu* pGpu = sc_gpu_create(&gpuCfg);
    if (!pGpu)
    {
        printf("error: cannot create Vulkan compute device.\n");
        printf("  Windows: vulkan-1.dll from the GPU driver.\n");
        printf("  Linux:   libvulkan.so.1 (mesa-vulkan-drivers or vendor driver).\n");
        printf("  shaders: glslc from Vulkan SDK must be in PATH or VULKAN_SDK.\n");
        return 1;
    }

    printf("gpu: %s\n", sc_gpu_device_name(pGpu));
    fflush(stdout);

    i32 result = 0;
    if (sc_string_compare((char*)pCommand, "train"))
        result = _cmd_train(argc, argv, pGpu);
    else if (sc_string_compare((char*)pCommand, "eval"))
        result = _cmd_eval(argc, argv, pGpu);
    else if (sc_string_compare((char*)pCommand, "compare"))
        result = _cmd_compare(argc, argv, pGpu);
    else if (sc_string_compare((char*)pCommand, "chat"))
        result = _cmd_chat(argc, argv, pGpu);
    else if (sc_string_compare((char*)pCommand, "gen"))
        result = _cmd_gen(argc, argv, pGpu);
    else if (sc_string_compare((char*)pCommand, "gradcheck"))
        result = _cmd_gradcheck(argc, argv, pGpu);
    else
        result = _cmd_bench(argc, argv, pGpu);

    sc_gpu_destroy(pGpu);
    sc_log_deinit();
    printf("=== done ===\n");
    return result;
}
