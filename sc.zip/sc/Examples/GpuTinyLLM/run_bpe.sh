#!/usr/bin/env bash
#
# Обучение BPE-словаря (bpe_train) бинарником из bin/<build>-linux.
#
# Пример:
#   ./run_bpe.sh /data/books -o bin/books.bpe -m 8192
#
set -euo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd -- "$HERE/../.." && pwd)"
BUILD="${BUILD:-release}"
EXE="$ROOT/bin/$BUILD-linux/bpe_train"

if [[ ! -x "$EXE" ]]; then
    echo "[run_bpe] binary not found: $EXE" >&2
    echo "          build: masuka -b $BUILD -p linux -e bpe_train -nr" >&2
    exit 1
fi

if [[ $# -eq 0 ]]; then
    echo "usage: $0 <corpus-dir> [-o out.bpe] [-m merges] [extra args]" >&2
    echo "  example: $0 /data/books -o bin/books.bpe -m 8192" >&2
    exit 1
fi

exec "$EXE" "$@"
