# GpuTinyLLM

TinyLlm на Vulkan compute: тот же трансформер, что в `Source/Sc/TinyLlm.c`,
но forward, backward, softmax, LayerNorm, GELU, внимание и AdamW считаются
compute-шейдерами на GPU.

Это не замена `lm_train`: цель примера - быстрый GPU-бэкенд и проверка
алгоритмов. Загрузка корпуса, BPE и выбор окон остаются на CPU.

## Быстрый старт

`gpu_tiny_llm` - консольная программа, окна у неё нет. Запускай её из
`cmd`/PowerShell в корне репозитория (двойной клик по `.exe` просто
откроет и сразу закроет консоль).

```bat
rem сборка без запуска
masuka -b release -e gpu_tiny_llm -nr

rem справка и проверка, что GPU виден
bin\release-windows\gpu_tiny_llm.exe --help
bin\release-windows\gpu_tiny_llm.exe bench --model micro --steps 2 --batch 2

rem бенчмарк выбранного пресета
bin\release-windows\gpu_tiny_llm.exe bench --model medium --steps 100 --batch 4
bin\release-windows\gpu_tiny_llm.exe bench --model target --steps 20 --batch 2
```

Модель задаётся только при создании: `--model micro|medium|target` у
`bench`, `train`, `gradcheck`. Команды `eval`, `compare`, `gen`, `chat`
берут пресет из `--checkpoint` - чекпоинт нельзя «переключить» на другой
пресет, его нужно обучать заново.

```bat
bin\release-windows\gpu_tiny_llm.exe train ^
  --bpe bin\books-8k.bpe --corpus D:\books --val D:\books-val --pack ^
  --model medium --steps 30000 --batch 4 --lr 0.001 --warmup 300 ^
  --eval-every 500 --eval-batches 16 --patience 5 --ckpt-every 1000 ^
  -o bin\medium-gpu.ckpt --val-log bin\medium-gpu-val.csv

bin\release-windows\gpu_tiny_llm.exe chat --checkpoint bin\medium-gpu.ckpt
```

### Easy mode: всё из одного каталога

Если BPE, корпус и валидация лежат в одном месте, достаточно:

```bat
bin\release-windows\gpu_tiny_llm.exe train --easy D:\books
bin\release-windows\gpu_tiny_llm.exe chat  --easy D:\books
```

`--easy <dir>` ищет:

- `*.bpe`: сначала `bpe.bpe`, `tokenizer.bpe`, `vocab.bpe`, `books.bpe`,
  потом любой `.bpe` в каталоге и на один уровень вглубь;
- train: `ldata`, `train`, `learn`, `data`, `corpus`, `text`, `texts`, `txt`
  (если ни одного нет - обходится весь `<dir>` рекурсивно);
- val: `val`, `valid`, `validation`, `eval`, `test` (каталог или
  `val.txt`/`valid.txt`/...); если нет - eval и early stop выключены;
- чекпоинт: `<dir>/model.ckpt`, а если в каталоге уже есть другой `.ckpt` -
  используется он; val-лог пишется в `<dir>/val.csv`.

Дефолты train уже настроены под типовой прогон medium: `--steps 30000
--batch 4 --lr 0.001 --warmup 300 --log-every 100 --ckpt-every 1000
--eval-every 500 --eval-batches 8 --patience 5`, упаковка окон включена.
Любой флаг переопределяет дефолт; `--no-pack` выключает упаковку.

`eval`, `compare`, `gen`, `chat` тоже понимают `--easy`: чекпоинт и
корпус подставляются из каталога, а явные флаги имеют приоритет.

## Что уже есть

| Часть | Где | Статус |
|:--|:--|:--|
| Vulkan instance/device/queue без окна | `VkGpu.c` | готово |
| SSBO, staging upload/download, compute pipelines | `VkGpu.c` | готово |
| Компиляция `kernels.glsl` через `glslc` | `VkGpu.c` | готово, кэш в `.bin` |
| Forward (эмбеддинги, LN, QKV, attention, FFN, LM head) | `GpuTinyLlm.c` + шейдеры | готово |
| Backward (все слои, attention, эмбеддинги) | `GpuTinyLlm.c` + шейдеры | готово |
| AdamW + clip по глобальной норме | шейдеры `PARTIAL_SUM`/`ADAMW` | готово |
| Eval, early stopping, RestoreBest, val CSV | `GpuTinyLlm.c` | готово |
| Чекпоинты SCTL v1 (совместимы с CPU) | `GpuTinyLlm.c` | готово |
| Генерация top-k/top-p с KV-кэшем | `GpuTinyLlm.c` + `K_*1` | готово |
| Интерактивный чат на GPU | `chat` | готово |
| Численная проверка градиентов на GPU | `--gradcheck` | готово |
| Сверка forward GPU vs CPU на одном чекпоинте | `compare` | готово |
| Скрипты bpe/train/chat для Linux и Windows | `run_*.sh`, `run_*.cmd` | готово |

## Требования

- GPU с Vulkan 1.0 compute. На Windows - обычный драйвер AMD/NVIDIA/Intel,
  на Linux - `mesa-vulkan-drivers` или проприетарный драйвер.
- `glslc` из Vulkan SDK в `PATH` или в `%VULKAN_SDK%/Bin/glslc.exe`
  (`$VULKAN_SDK/bin/glslc` на Linux). SDK нужен **только во время запуска**
  для компиляции шейдеров; при сборке Vulkan-заголовки не требуются.
- Sc собирается как обычно. Пример линкует `Sc` и грузит Vulkan динамически.

## Сборка

Из корня репозитория:

```sh
masuka -b release -p windows -e gpu_tiny_llm -nr
# Linux:
masuka -b release -p linux -e gpu_tiny_llm -nr
```

Бинарник: `bin/release-windows/gpu_tiny_llm.exe` (или `bin/release-linux/`).

## Запуск

`--shaders` можно не указывать: программа ищет `shaders`, затем
`Examples/GpuTinyLLM/shaders`. При первом запуске шейдеры компилируются в
`shaders/.bin/*.spv` (несколько секунд).

### Bench

Синтетические данные, замер шага:

```sh
bin/release-windows/gpu_tiny_llm.exe bench --model micro --steps 50 --batch 8
```

Печатает мс/шаг, мс/токен и токенов/с. Первый запуск включает компиляцию
шейдеров; для чистого замера запусти команду второй раз.

### Train

```sh
bin/release-windows/gpu_tiny_llm.exe train ^
  --bpe bin/micro-100mb/micro-100mb-8k.bpe ^
  --corpus A:/books ^
  --val A:/books-val ^
  --pack ^
  --model micro --steps 30000 --batch 8 --lr 0.003 ^
  -o bin/micro-gpu.ckpt --val-log bin/micro-gpu-val.csv
```

Особенности:

- `--corpus` и `--val` - файл или каталог с `*.txt`/`*.text`; каталоги
  обходятся рекурсивно (Windows и Linux).
- `--pack` включён по умолчанию: строки склеиваются в непрерывный поток
  `<BOS>строка<EOS><BOS>строка<EOS>...` и режутся на окна `ctx+1`
  с шагом `ctx` (как `lm_train --pack`). `--no-pack` оставляет
  построчную загрузку (как `lm_train` без `--pack`). В отличие от
  `lm_train`, split train/val не по каждой 10-й книге: `--val` нужно
  указать явно или положить в `val/` рядом с `--easy`.
- Loss mask - `None` (чистое языковое моделирование).
- Чекпоинт пишется каждые `--ckpt-every` шагов (по умолчанию 1000) и
  ещё раз в конце обучения, даже если число шагов не кратно интервалу.
  Запись идёт во временный файл `*.tmp`, рабочий чекпоинт подменяется
  только после успешного завершения записи.
- Пути чекпоинта и val-лога печатаются до старта обучения.

Продолжить с чекпоинта (BPE берётся из него):

```sh
gpu_tiny_llm.exe train --checkpoint bin/micro-gpu.ckpt --corpus A:/books ...
```

### Eval

```sh
gpu_tiny_llm.exe eval --checkpoint bin/micro-gpu.ckpt --corpus A:/books-val --eval-batches 32
```

### Compare (GPU vs CPU)

```sh
gpu_tiny_llm.exe compare --checkpoint bin/micro-100mb/micro-100mb.ckpt --corpus A:/books-val --eval-batches 8 --tol 0.01
```

Загружает **один и тот же** SCTL-чекпоинт в GPU- и CPU-модель, строит
датасет тем же BPE и считает loss на одних и тех же окнах (seed
`0x5c0de`). Печатает оба loss и `PASS`/`FAIL` по допуску `--tol`.

Это самый быстрый способ проверить, что forward на GPU совпадает с
`TinyLlm.c`: если `compare` проходит, а `gradcheck` проходит, то и
обучение должно идти как на CPU (различия только в порядке суммирования
float32).

### Gen

```sh
gpu_tiny_llm.exe gen --checkpoint bin/micro-gpu.ckpt --prompt "Once upon a time" --tokens 80
```

Промпт считается одним полным forward'ом, K/V всех слоёв переносятся в
KV-кэш, дальше каждый токен считается decode-ядрами с `M=1`. Стоимость
токена больше не растёт с длиной окна (только внимание по уже
посчитанным K/V), поэтому генерация близка к CPU-версии с кэшем.

### Chat

```sh
gpu_tiny_llm.exe chat --checkpoint bin/micro-gpu.ckpt --temp 0.8 --top-k 40 --max 64
```

Интерактивное продолжение текста (как `lm_chat`): каждая строка -
независимый промпт, `exit`/`quit` - выход. Использует тот же KV-кэш.

### Gradcheck

```sh
gpu_tiny_llm.exe gradcheck --model micro --check-params 2 --eps 0.001 --tol 0.01
```

Сравнивает аналитические градиенты с центральной разностью на GPU.
Для float32 и T=8 шум конечных разностей заметен; если проверка падает
на нескольких элементах, попробуй `--eps 0.01 --tol 0.05`.

## Скрипты (bin/)

В каталоге примера лежат тонкие обёртки над бинарниками из `bin/`.
Они ищут корень репозитория от своего расположения, поэтому их можно
запускать из любого каталога. `BUILD` выбирает сборку (`release` по
умолчанию, можно `debug`).

Linux (bash):

```sh
chmod +x run_*.sh   # один раз

./run_bpe.sh   /data/books -o bin/books.bpe -m 8192
./run_train.sh --bpe bin/books.bpe --corpus /data/books \
               --val /data/books-val --pack -o bin/books.ckpt
./run_chat.sh  --checkpoint bin/books.ckpt
```

Windows (cmd):

```bat
run_bpe.cmd   D:\books -o bin\books.bpe -m 8192
run_train.cmd --bpe bin\books.bpe --corpus D:\books ^
              --val D:\books-val --pack -o bin\books.ckpt
run_chat.cmd  --checkpoint bin\books.ckpt
```

Перед запуском соберите нужные утилиты:

```sh
masuka -b release -p linux   -e bpe_train     -nr
masuka -b release -p linux   -e gpu_tiny_llm  -nr
# Windows: -p windows
```

Скрипты ничего не делают с путями: все аргументы уходят в бинарник как
есть. Для `run_chat` можно задать `CKPT=<ckpt>` и вызвать без аргументов
(Windows: `set CKPT=bin\books.ckpt` затем `run_chat.cmd`).

## Память и производительность

- Веса, градиенты, AdamW `m/v` и активации лежат в одном device-local SSBO.
- В aux SSBO (host-visible) на каждый sample в batch есть слот с токенами,
  метками, маской и порядком для scatter-градиента эмбеддингов.
- Весь batch пишется в один command buffer и отправляется одним submit'ом
  за шаг; между dispatch'ами стоят memory barriers.
- KV-кэш генерации (`KCache`/`VCache` в том же SSBO) занимает
  `2 * NumLayers * ContextLength * DModel` float: ~6 МБ для `target`.
- Матмулы - простые 16x16 тайлы без shared memory. Это корректно, но далеко
  от пиковой производительности; следующий шаг - tiled/shared-memory матмул
  (ускорит и обучение, и decode).

Оценка памяти (float32, словарь 8265):

| Пресет | Веса+грады+AdamW+активации | SSBO модели | + aux |
|:--|--:|--:|--:|
| micro | ~30 МБ | ~30 МБ | ~0.1 МБ |
| medium | ~84 МБ | ~84 МБ | ~0.3 МБ |
| target | ~316 МБ | ~316 МБ | ~1 МБ |

`maxStorageBufferRange` проверяется при создании модели. На дискретных GPU
он обычно 4 ГБ; на старых интегрированных может быть 128 МБ - тогда
`target` не поместится в один SSBO.

## Ограничения

1. **Одна модель на устройство.** Descriptor set общий; повторный
   `sc_gpu_bind_storage` перезапишет привязку.
2. **`--pack` есть, но split train/val проще, чем в `lm_train`.** Нужно
   явно передать `--val` с held-out книгами; автоматического деления
   по каждой 10-й книге нет.
3. **Нет shared-memory тайлинга в матмулах.** Производительность ниже
   оптимизированных ядер, но алгоритм полностью на GPU.
4. **Численная проверка градиентов** использует float32-лосс; допуски
   конечных разностей подбираются под конкретную модель.
5. **Префилл генерации не батчится с decode.** Промпт считается одним
   полным forward'ом, затем токены идут по одному (так же, как в
   `lm_chat`); спекулятивного/батчевого decode нет.

## Файлы

| Файл | Назначение |
|:--|:--|
| `VkGpu.h/.c` | Vulkan compute-бэкенд: device, буферы, pipelines, dispatch |
| `GpuTinyLlm.h/.c` | модель, forward/backward/AdamW, eval, чекпоинты, генерация |
| `shaders/kernels.glsl` | все compute-ядра (один файл, сборка по `-DK_*`) |
| `main.c` | CLI: bench/train/eval/compare/chat/gen/gradcheck |
| `gpu_tiny_llm.masuka` | сборка masuka |
| `run_bpe.sh/.cmd` | запуск `bin/.../bpe_train` |
| `run_train.sh/.cmd` | запуск `bin/.../gpu_tiny_llm train` |
| `run_chat.sh/.cmd` | запуск `bin/.../gpu_tiny_llm chat` |

## Как это соотносится с CPU-версией

- Формат чекпоинта тот же: `SCTL` v1, параметры в том же порядке.
  `gpu_tiny_llm gen --checkpoint bin/micro-100mb/micro-100mb.ckpt` читает
  существующий CPU-чекпоинт.
- Инициализация весов при одном seed совпадает с CPU (тот же RNG и Xavier).
- Формулы forward/backward/LayerNorm/GELU/softmax/AdamW повторяют
  `TinyLlm.c` и `TinyLlmSimd.c`.
- Отличия: порядок суммирования float на GPU другой, поэтому loss и
  градиенты совпадают не бит-в-бит, а с точностью до ошибки float32.
