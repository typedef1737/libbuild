# small-llm-try

Учебно-практический проект микро-LLM на C99: byte-level BPE, условный
датасет с разметкой персоны и decoder-only transformer, который учится
продолжать реплику после `<SEP>`.

Проект не использует BLAS, MKL, OpenMP, pthread или внешние ML-библиотеки.
Только `Sc.h`/`Types.h`, стандартная библиотека C и собственный код.

## Что реализовано

### 1. Токенизатор

- byte-level BPE: 256 байт + 9 спецтокенов + слияния;
- спецтокены: `<UNK>`, `<PAD>`, `<BOS>`, `<EOS>`, `<SEP>`,
  `<PERSONA>`, `<CHAR>`, `<EMO>`, `<SIT>`;
- формат файла: `# bpe v1`, escaped-словарь `# vocab-esc`, строгая
  проверка ID мерджей и спецтокенов;
- encode/decode без потери UTF-8, включая кириллицу;
- production-тренер `sc_ai_bpe_new_fast`: хеш-таблица частот пар,
  позиционные списки и max-heap с ленивым удалением; `sc_ai_bpe_new`
  оставлен как reference-реализация.

### 2. Модель

`Source/Sc/TinyLlm.c` — decoder-only transformer, float32:

- LayerNorm → causal multi-head self-attention → residual;
- LayerNorm → FFN (GELU) → residual;
- forward/backward для всех слоёв;
- cross-entropy с маскированием prompt-позиций;
- AdamW, warmup + cosine, клиппинг по глобальной норме градиента;
- KV-cache при генерации;
- greedy / top-k / top-p / temperature;
- чекпоинт: magic + version + config + weights + встроенная копия BPE;
- early stopping по валидационному loss с восстановлением лучших весов
  (`ScTinyLlmTrainConfig.RestoreBest`);
- отладочная проверка аналитического градиента конечными разностями.

Публичный API — `Source/Sc/TinyLlm.h`:

```c
ScTinyLlmModel* sc_tiny_llm_create(const ScTinyLlmModelConfig* cfg);
i32 sc_tiny_llm_train(ScTinyLlmModel* model, ScAiBpe bpe,
    const ScTinyLlmDataset* train, const ScTinyLlmDataset* val,
    const ScTinyLlmTrainConfig* cfg);
char* sc_tiny_llm_generate(ScTinyLlmModel* model, ScAiBpe bpe,
    const char* prompt, const ScTinyLlmGenerateConfig* cfg);
```

`sc_tiny_llm_generate` возвращает `ScString`, который нужно освободить
через `sc_string_destroy`.

### 3. Датасет

Один пример — одна строка вида:

```text
<BOS><PERSONA>мужчина 30 крестьянин<CHAR>грубоватый добрый<EMO>раздражён<SIT>повозка сломалась<SEP>— Млорд, здесь проезд закрыт!<EOS>
```

При `ScTinyLlmLossMask_Prompt` loss считается только по токенам после
последнего `<SEP>`, поэтому модель не тратит ёмкость на предсказание
описания персоны.

## Сборка и запуск

Из корня репозитория:

```bash
masuka -b release -p windows -e small_llm_try -nr
bin\release-windows\small_llm_try.exe
```

Linux:

```bash
masuka -b release -p linux -e small_llm_try -nr
./bin/release-linux/small_llm_try
```

Debug-сборка полезна для отладки, но обучение в ней в несколько раз
медленнее:

```bash
masuka -b debug -p windows -e small_llm_try -nr
bin\debug-windows\small_llm_try.exe
```

## Что делает демо

1. Собирает корпус из 16 синтетических условных реплик.
2. Учит BPE fast-тренером на 128 слияний и сохраняет
   `small-llm-try/tiny_llm.bpe`.
3. Загружает BPE обратно и проверяет словарь.
4. Делит данные на train/val.
5. Создаёт transformer: 2 слоя, `d_model=64`, 2 головы, `d_ff=128`,
   контекст 128.
6. Обучает 300 шагов с маскированием prompt.
7. Генерирует ответы на 5 промптов.
8. Загружает чекпоинт `small-llm-try/tiny_llm.ckpt` со встроенным BPE и
   генерирует ещё один ответ.

Ожидаемый вывод (release, ориентировочно 2–5 секунд; точные строки
зависят от платформы и версии компилятора):

```text
bpe: vocab=393 merges=128
dataset: train=12 val=4
model: layers=2 d_model=64 heads=2 d_ff=128 ctx=128 params=...
train: steps=300 batch=4 lr=0.0030 mask=prompt
tiny-llm: step 20/300 loss ...
tiny-llm: val step 50 loss 5.3131 ppl 202.98
...
tiny-llm: early stop at step 250 (best val 5.3131)
tiny-llm: restored best weights (val 5.3131)
train: val 6.1978 -> 5.3131
...
--- generation (trained model) ---
...
--- checkpoint reload ---
checkpoint answer: ...
```

На 16 примерах модель переобучается: val loss после первых шагов растёт,
поэтому early stopping возвращает веса с лучшим val loss. Часть ответов
при этом остаётся недоученной — для обобщения нужны тысячи примеров.
Без `RestoreBest` демо показывало бы почти дословное запоминание train,
но гораздо худший val loss.

## Параметры

Основные константы — в начале `main.c`:

- `SmallLlmBpeMerges` — число BPE-слияний;
- `SmallLlmLayers`, `SmallLlmDModel`, `SmallLlmHeads`, `SmallLlmDFf`,
  `SmallLlmContextLength` — размер модели;
- `SmallLlmTrainSteps`, `SmallLlmBatchSize`, `SmallLlmLearningRate` —
  обучение;
- `SmallLlmEvalEvery`, `SmallLlmCheckpointEvery` — валидация и чекпоинты.

Конфиги по умолчанию можно получить через:

```c
ScTinyLlmModelConfig modelCfg = sc_tiny_llm_model_config_default(vocabCount);
ScTinyLlmTrainConfig trainCfg = sc_tiny_llm_train_config_default();
ScTinyLlmGenerateConfig genCfg = sc_tiny_llm_generate_config_default();

// Пресеты из ТЗ: Micro / Medium / Target.
ScTinyLlmModelConfig micro = sc_tiny_llm_model_config_preset(ScTinyLlmSize_Micro, vocabCount);
```

## Ограничения и что дальше

- **Reference-BPE медленный.** `sc_ai_bpe_new` по-прежнему пересчитывает
  пары после каждого слияния и оставлен для сравнения/тестов. Для больших
  корпусов используйте `sc_ai_bpe_new_fast`; на синтетическом корпусе
  50 МБ / 10 000 merges release-сборка укладывается примерно в 17 секунд.
- **Модель маленькая.** 2 слоя / 64 dim — это микро-конфиг для проверки
  пайплайна, а не качественный ассистент.
- **Нет dropout и mixed precision.** Для CPU-демо это осознанно.
- **Чекпоинт не атомарный.** Запись идёт напрямую в файл; для production
  нужен temp + rename.
- **Оценка качества условная.** На синтетике из 16 примеров метрика
  «≥ 50% стилистически корректных ответов» не показательна; нужен
  held-out набор из сотен примеров.

## Связь с ТЗ

| Этап ТЗ | Статус |
|---|---|
| BPE production, формат `# bpe v1` | готово: `sc_ai_bpe_new_fast`, строгая валидация |
| Float transformer, forward/backward | готово, есть численная проверка градиента |
| Conditional-задача + маскирование loss | готово |
| Инференс: KV-cache, top-p, публичный API | готово |
| Чекпоинты, early stopping, логирование | готово, лучшие веса восстанавливаются |
| 50 МБ / 10k merges ≤ 30 мин | готово: ~17 с на синтетическом 50 МБ, release CPU |
| Валидационная перплексия ≤ 30 | зависит от данных; на 16 примерах не проверяется |
