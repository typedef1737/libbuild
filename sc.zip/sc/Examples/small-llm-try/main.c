/*
  small_llm_try — демонстрационный проект микро-LLM на Sc/TinyLlm.

  Пайплайн:
    1. синтетический корпус условных реплик
       <BOS><PERSONA>...<CHAR>...<EMO>...<SIT>...<SEP>ответ<EOS>;
    2. byte-level BPE (Sc/Ai.c) + сохранение в формате # bpe v1;
    3. датасет с маскированием prompt;
    4. обучение decoder-only transformer (Sc/TinyLlm.c);
    5. генерация с KV-cache / greedy;
    6. загрузка чекпоинта со встроенным BPE.

  Запуск из корня репозитория:
    masuka -b release -p windows -e small_llm_try -nr
    bin\release-windows\small_llm_try.exe
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <stdio.h>

#define SmallLlmBpeMerges 128
#define SmallLlmContextLength 128
#define SmallLlmDModel 64
#define SmallLlmHeads 2
#define SmallLlmDFf 128
#define SmallLlmLayers 2
#define SmallLlmTrainSteps 300
#define SmallLlmBatchSize 4
#define SmallLlmLearningRate 0.003f
#define SmallLlmLogEvery 20
#define SmallLlmEvalEvery 50
#define SmallLlmCheckpointEvery 100

/*
  Условные примеры. Формат фиксирован: персона -> черты -> эмоция ->
  ситуация -> ответ. Модель учится продолжать последовательность после
  <SEP>, loss на prompt-токенах маскируется.
*/
static const char* aSmallLlmSamples[] = {
    "<BOS><PERSONA>мужчина 30 крестьянин<CHAR>грубоватый добрый<EMO>раздражён<SIT>повозка сломалась<SEP>— Млорд, здесь проезд закрыт! Поскочите в другую сторону!<EOS>",
    "<BOS><PERSONA>женщина 25 торговка<CHAR>весёлая хитрая<EMO>радостно<SIT>ярмарка<SEP>— Покупайте яблоки, самые сладкие!<EOS>",
    "<BOS><PERSONA>мужчина 40 стражник<CHAR>суровый честный<EMO>спокойно<SIT>городские ворота<SEP>— Проходите, только не задерживайтесь.<EOS>",
    "<BOS><PERSONA>женщина 35 знахарка<CHAR>тихая добрая<EMO>устало<SIT>больной ребёнок<SEP>— Дайте мне травы и тёплой воды.<EOS>",
    "<BOS><PERSONA>мужчина 22 пастух<CHAR>робкий мечтательный<EMO>испуганно<SIT>волки у стада<SEP>— Помогите! Волки идут к овцам!<EOS>",
    "<BOS><PERSONA>женщина 50 хозяйка<CHAR>строгая заботливая<EMO>сердито<SIT>пропала курица<SEP>— Кто видел мою курицу? Сознавайтесь!<EOS>",
    "<BOS><PERSONA>мужчина 60 старейшина<CHAR>мудрый спокойный<EMO>задумчиво<SIT>спор в деревне<SEP>— Не кричите, решим всё по совести.<EOS>",
    "<BOS><PERSONA>женщина 18 девушка<CHAR>весёлая болтливая<EMO>смущённо<SIT>встреча у колодца<SEP>— Ой, я вас не заметила!<EOS>",
    "<BOS><PERSONA>мужчина 35 кузнец<CHAR>сильный угрюмый<EMO>устало<SIT>сломался молот<SEP>— Придётся чинить, иначе работа стоит.<EOS>",
    "<BOS><PERSONA>женщина 30 учительница<CHAR>добрая терпеливая<EMO>мягко<SIT>дети не слушаются<SEP>— Тише, дети, давайте начнём урок.<EOS>",
    "<BOS><PERSONA>мужчина 45 охотник<CHAR>молчаливый смелый<EMO>настороженно<SIT>следы в лесу<SEP>— Здесь кто-то прошёл совсем недавно.<EOS>",
    "<BOS><PERSONA>женщина 40 пекарша<CHAR>хлопотливая добрая<EMO>весело<SIT>утро на кухне<SEP>— Свежий хлеб готов, угощайтесь!<EOS>",
    "<BOS><PERSONA>мужчина 28 рыбак<CHAR>ленивый добродушный<EMO>довольно<SIT>хороший улов<SEP>— Сегодня рыба сама идёт в руки.<EOS>",
    "<BOS><PERSONA>женщина 55 вдовa<CHAR>печальная тихая<EMO>скорбно<SIT>старое кладбище<SEP>— Он всегда возвращался домой вовремя.<EOS>",
    "<BOS><PERSONA>мужчина 19 ученик<CHAR>любопытный неуклюжий<EMO>растерянно<SIT>первый день работы<SEP>— А куда это нужно ставить?<EOS>",
    "<BOS><PERSONA>женщина 33 травница<CHAR>спокойная загадочная<EMO>таинственно<SIT>ночной лес<SEP>— Не всякая трава лечит, иная и губит.<EOS>",
};

static const i64 cSmallLlmSampleCount = (i64)(sizeof(aSmallLlmSamples) / sizeof(aSmallLlmSamples[0]));

static const char* aSmallLlmPrompts[] = {
    "<BOS><PERSONA>мужчина 30 крестьянин<CHAR>грубоватый добрый<EMO>раздражён<SIT>повозка сломалась<SEP>",
    "<BOS><PERSONA>женщина 25 торговка<CHAR>весёлая хитрая<EMO>радостно<SIT>ярмарка<SEP>",
    "<BOS><PERSONA>мужчина 40 стражник<CHAR>суровый честный<EMO>спокойно<SIT>городские ворота<SEP>",
    "<BOS><PERSONA>женщина 35 знахарка<CHAR>тихая добрая<EMO>устало<SIT>больной ребёнок<SEP>",
    "<BOS><PERSONA>мужчина 50 мельник<CHAR>добродушный шумный<EMO>весело<SIT>новая мельница<SEP>",
};

static const i64 cSmallLlmPromptCount = (i64)(sizeof(aSmallLlmPrompts) / sizeof(aSmallLlmPrompts[0]));

static char*
_small_llm_path_near_source(const char* pName)
{
    char* pDir = sc_path_get_directory(__FILE__);
    if (!pDir)
        return sc_string_copy((char*)pName, sc_string_get_length((char*)pName));

    char* pPath = sc_path_combine(pDir, (char*)pName);
    sc_memory_free(pDir);
    return pPath;
}

static char*
_small_llm_build_corpus(i64* pLength)
{
    char* pBuilder = sc_builder_new();

    for (i64 i = 0; i < cSmallLlmSampleCount; ++i)
    {
        const char* pSample = aSmallLlmSamples[i];
        sc_builder_append_string(pBuilder, (char*)pSample, sc_string_get_length((char*)pSample));
        sc_builder_append_string(pBuilder, "\n", 1);
    }

    i64 length = sc_builder_count(pBuilder);
    char* pCorpus = sc_string_new_ext_ext_r(pBuilder, length, length);
    sc_builder_destroy(pBuilder);

    if (pLength)
        *pLength = length;
    return pCorpus;
}

static void
_small_llm_print_bpe_info(ScAiBpe bpe)
{
    printf("bpe: vocab=%d merges=%d\n",
        (i32)sc_list_count(bpe.aVocab),
        (i32)sc_list_count(bpe.aMerges));
}

i32
main()
{
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("=== small-llm-try: tiny transformer ===\n");
    printf("samples: %d\n", (i32)cSmallLlmSampleCount);

    i64 corpusLength = 0;
    char* pCorpus = _small_llm_build_corpus(&corpusLength);
    printf("corpus: %d bytes\n", (i32)corpusLength);

    // DOCS: fast-тренер: хеш-таблица частот + позиционные списки + heap.
    // Старый sc_ai_bpe_new оставлен как reference-реализация.
    ScAiBpe bpe = sc_ai_bpe_new_fast((ScAiBpeConfig) {
        .pText = pCorpus,
        .TextLength = corpusLength,
        .MergesCount = SmallLlmBpeMerges,
    });
    _small_llm_print_bpe_info(bpe);

    // DOCS: терминальный лог включаем после шумного обучения BPE, чтобы
    // в выводе остались только шаги обучения и валидации модели.
    ScLogBackend backend = sc_log_get_terminal_backend();
    sc_log_init((ScLogConfig) {
        .BackendsCount = 1,
        .aBackends = &backend,
    });

    char* pBpePath = _small_llm_path_near_source("tiny_llm.bpe");
    char* pCheckpointPath = _small_llm_path_near_source("tiny_llm.ckpt");

    sc_ai_bpe_save_to_disk((ScAiBpeSaveToDiskConfig) {
        .Bpe = bpe,
        .pFilePath = pBpePath,
        .TotalTextLength = corpusLength,
        .TotalTextLengthCompressed = (i64)sc_list_count(bpe.aTokens),
        .pText = pCorpus,
        .ShouldAddText = 0,
        .ShouldAddTokens = 0,
    });
    printf("bpe: saved to %s\n", pBpePath);

    ScAiBpe loadedBpe = sc_ai_bpe_load_from_disk(pBpePath);
    _small_llm_print_bpe_info(loadedBpe);
    printf("bpe: round-trip -> %s\n",
        sc_list_count(loadedBpe.aVocab) == sc_list_count(bpe.aVocab) ? "ok" : "FAILED");

    ScTinyLlmDataset trainDataset = sc_tiny_llm_dataset_new();
    ScTinyLlmDataset valDataset = sc_tiny_llm_dataset_new();

    for (i64 i = 0; i < cSmallLlmSampleCount; ++i)
    {
        if (i < cSmallLlmSampleCount - 4)
            sc_tiny_llm_dataset_add(&trainDataset, bpe, aSmallLlmSamples[i]);
        else
            sc_tiny_llm_dataset_add(&valDataset, bpe, aSmallLlmSamples[i]);
    }

    printf("dataset: train=%d val=%d\n", (i32)trainDataset.Count, (i32)valDataset.Count);

    // Micro-пресет из ТЗ; d_ff уменьшен для скорости демо.
    ScTinyLlmModelConfig modelConfig =
        sc_tiny_llm_model_config_preset(ScTinyLlmSize_Micro, (i32)sc_list_count(bpe.aVocab));
    modelConfig.DFf = SmallLlmDFf;
    modelConfig.Seed = 0x5c0deULL;

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    if (!pModel)
    {
        printf("error: failed to create model\n");
        return 1;
    }

    printf("model: layers=%d d_model=%d heads=%d d_ff=%d ctx=%d params=%d\n",
        modelConfig.NumLayers, modelConfig.DModel, modelConfig.NumHeads,
        modelConfig.DFf, modelConfig.ContextLength,
        (i32)sc_tiny_llm_param_count(pModel));

    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = SmallLlmTrainSteps;
    trainConfig.BatchSize = SmallLlmBatchSize;
    trainConfig.LearningRate = SmallLlmLearningRate;
    trainConfig.WarmupSteps = 30;
    trainConfig.LogEvery = SmallLlmLogEvery;
    trainConfig.EvalEvery = SmallLlmEvalEvery;
    trainConfig.EvalBatches = 4;
    trainConfig.Patience = 4;
    trainConfig.pCheckpointPath = pCheckpointPath;
    trainConfig.CheckpointEvery = SmallLlmCheckpointEvery;
    // DOCS: early stopping вернёт веса с лучшим val loss, а не последний шаг.
    trainConfig.RestoreBest = 1;
    trainConfig.Seed = 0x5c0deULL;

    printf("train: steps=%d batch=%d lr=%.4f mask=prompt\n",
        trainConfig.Steps, trainConfig.BatchSize, trainConfig.LearningRate);

    f32 before = sc_tiny_llm_eval(pModel, &valDataset, 4, ScTinyLlmLossMask_Prompt, 1);
    sc_tiny_llm_train(pModel, bpe, &trainDataset, &valDataset, &trainConfig);
    f32 after = sc_tiny_llm_eval(pModel, &valDataset, 4, ScTinyLlmLossMask_Prompt, 1);
    printf("train: val %.4f -> %.4f\n", before, after);

    ScTinyLlmGenerateConfig generateConfig = sc_tiny_llm_generate_config_default();
    generateConfig.MaxTokens = 32;
    generateConfig.Temperature = 0.0f;
    generateConfig.TopK = 1;

    printf("\n--- generation (trained model) ---\n");
    for (i64 i = 0; i < cSmallLlmPromptCount; ++i)
    {
        char* pAnswer = sc_tiny_llm_generate(pModel, loadedBpe, aSmallLlmPrompts[i], &generateConfig);
        printf("prompt: %s\n", aSmallLlmPrompts[i]);
        printf("answer: %s\n\n", pAnswer);
        sc_string_destroy(pAnswer);
    }

    printf("--- checkpoint reload ---\n");
    ScAiBpe checkpointBpe = {};
    ScTinyLlmModel* pLoaded = sc_tiny_llm_load_checkpoint(pCheckpointPath, &checkpointBpe);
    if (pLoaded && sc_list_count(checkpointBpe.aVocab) > 0)
    {
        char* pAnswer = sc_tiny_llm_generate(pLoaded, checkpointBpe,
            aSmallLlmPrompts[0], &generateConfig);
        printf("checkpoint answer: %s\n", pAnswer);
        sc_string_destroy(pAnswer);
        sc_tiny_llm_destroy(pLoaded);
        sc_ai_bpe_destroy(&checkpointBpe);
    }
    else
    {
        printf("checkpoint reload: FAILED\n");
    }

    sc_tiny_llm_destroy(pModel);
    sc_ai_bpe_destroy(&loadedBpe);
    sc_ai_bpe_destroy(&bpe);
    sc_tiny_llm_dataset_destroy(&valDataset);
    sc_tiny_llm_dataset_destroy(&trainDataset);
    sc_string_destroy(pCorpus);
    sc_memory_free(pBpePath);
    sc_memory_free(pCheckpointPath);
    sc_log_deinit();

    printf("=== done ===\n");
    return 0;
}
