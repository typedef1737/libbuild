/*
  avx2_bench - scalar vs AVX2 training benchmark for TinyLlm.

  Usage:
    avx2_bench <corpus.txt> <micro|medium|target> <steps> <batch> [ctx] [merges]

  Builds the BPE vocabulary once, then trains two fresh models with the same
  seed: first with the scalar backend, then with avx2+fma. Prints wall time,
  ms/step, speedup and eval loss before/after training.

  Examples:
    avx2_bench corpus.txt micro 10000 8 128 500
    avx2_bench corpus.txt medium 1000 4 128 500
    avx2_bench corpus.txt target 100 2 256 500
*/

#include <Sc/TinyLlm.h>
#include <Sc/TinyLlmSimd.h>
#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static double
_now_sec(void)
{
    return (double)clock() / (double)CLOCKS_PER_SEC;
}

static char*
_read_file(const char* pPath, i64* pLength)
{
    FILE* pFile = fopen(pPath, "rb");
    if (!pFile)
        return NULL;

    fseek(pFile, 0, SEEK_END);
    long size = ftell(pFile);
    fseek(pFile, 0, SEEK_SET);
    if (size < 0)
    {
        fclose(pFile);
        return NULL;
    }

    char* pData = (char*)malloc((size_t)size + 1);
    if (!pData)
    {
        fclose(pFile);
        return NULL;
    }

    size_t read = fread(pData, 1, (size_t)size, pFile);
    fclose(pFile);
    pData[read] = '\0';
    *pLength = (i64)read;
    return pData;
}

static ScTinyLlmSize
_preset_from_name(const char* pName)
{
    if (strcmp(pName, "micro") == 0)
        return ScTinyLlmSize_Micro;
    if (strcmp(pName, "target") == 0)
        return ScTinyLlmSize_Target;
    return ScTinyLlmSize_Medium;
}

static double
_run_backend(ScTinyLlmCpuBackend backend, ScAiBpe bpe, const char* pText,
    ScTinyLlmSize size, i32 steps, i32 batch, i32 ctx)
{
    sc_tiny_llm_simd_force_backend(backend);

    ScTinyLlmDataset dataset = sc_tiny_llm_dataset_new();
    if (sc_tiny_llm_dataset_add(&dataset, bpe, pText) != 1)
    {
        printf("dataset add failed\n");
        return -1.0;
    }

    ScTinyLlmModelConfig modelConfig =
        sc_tiny_llm_model_config_preset(size, (i32)sc_list_count(bpe.aVocab));
    if (ctx > 0)
        modelConfig.ContextLength = ctx;
    modelConfig.Seed = 42;

    ScTinyLlmModel* pModel = sc_tiny_llm_create(&modelConfig);
    if (!pModel)
    {
        printf("model create failed\n");
        sc_tiny_llm_dataset_destroy(&dataset);
        return -1.0;
    }

    f32 lossBefore = sc_tiny_llm_eval(pModel, &dataset, 8, ScTinyLlmLossMask_None, 1);

    ScTinyLlmTrainConfig trainConfig = sc_tiny_llm_train_config_default();
    trainConfig.Steps = steps;
    trainConfig.BatchSize = batch;
    trainConfig.LearningRate = 0.001f;
    trainConfig.WarmupSteps = 0;
    trainConfig.LogEvery = 0;
    trainConfig.GradClip = 1.0f;
    trainConfig.EvalEvery = 0;
    trainConfig.Patience = 0;
    trainConfig.RestoreBest = 0;
    trainConfig.Seed = 42;

    double t0 = _now_sec();
    i32 ok = sc_tiny_llm_train(pModel, bpe, &dataset, &dataset, &trainConfig);
    double t1 = _now_sec();

    f32 lossAfter = sc_tiny_llm_eval(pModel, &dataset, 8, ScTinyLlmLossMask_None, 1);

    printf("%-9s ok=%d params=%lld ctx=%d steps=%d batch=%d time=%8.2fs ms/step=%7.2f loss=%.4f->%.4f\n",
        sc_tiny_llm_simd_backend_name(),
        ok,
        (long long)sc_tiny_llm_param_count(pModel),
        modelConfig.ContextLength,
        steps,
        batch,
        t1 - t0,
        (t1 - t0) * 1000.0 / (double)steps,
        (double)lossBefore,
        (double)lossAfter);

    sc_tiny_llm_destroy(pModel);
    sc_tiny_llm_dataset_destroy(&dataset);

    return t1 - t0;
}

int
main(int argc, char** argv)
{
    if (argc < 5)
    {
        printf("usage: %s <corpus.txt> <micro|medium|target> <steps> <batch> [ctx] [merges]\n", argv[0]);
        return 1;
    }

    const char* pPath = argv[1];
    const char* pPreset = argv[2];
    i32 steps = atoi(argv[3]);
    i32 batch = atoi(argv[4]);
    i32 ctx = argc > 5 ? atoi(argv[5]) : 0;
    i32 merges = argc > 6 ? atoi(argv[6]) : 500;

    if (steps <= 0 || batch <= 0)
    {
        printf("steps and batch must be positive\n");
        return 1;
    }

    i64 length = 0;
    char* pText = _read_file(pPath, &length);
    if (!pText)
    {
        printf("cannot read %s\n", pPath);
        return 1;
    }

    printf("file=%s bytes=%lld preset=%s steps=%d batch=%d ctx=%d merges=%d\n",
        pPath, (long long)length, pPreset, steps, batch, ctx, merges);

    ScAiBpe bpe = sc_ai_bpe_new_fast((ScAiBpeConfig) {
        .pText = pText,
        .TextLength = length,
        .MergesCount = merges,
        .ShouldLogProgress = 0,
    });

    printf("bpe: vocab=%d merges=%d\n",
        (i32)sc_list_count(bpe.aVocab), (i32)sc_list_count(bpe.aMerges));
    printf("cpu: avx2=%d fma=%d\n", sc_tiny_llm_simd_has_avx2(), sc_tiny_llm_simd_has_fma());

    ScTinyLlmSize size = _preset_from_name(pPreset);

    double scalarTime = _run_backend(ScTinyLlmCpu_Scalar, bpe, pText, size, steps, batch, ctx);
    double avx2Time = -1.0;

    if (sc_tiny_llm_simd_has_avx2())
        avx2Time = _run_backend(ScTinyLlmCpu_Avx2, bpe, pText, size, steps, batch, ctx);
    else
        printf("avx2 is not available on this CPU\n");

    if (scalarTime > 0.0 && avx2Time > 0.0)
        printf("speedup: %.2fx\n", scalarTime / avx2Time);

    sc_ai_bpe_destroy(&bpe);
    free(pText);
    return 0;
}
