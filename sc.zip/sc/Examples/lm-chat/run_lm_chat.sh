#!/usr/bin/env bash
# Запуск lm_chat (шаг 3 пайплайна MS1): интерактивная генерация по чекпоинту.
#
# Использование (из любой папки):
#   ./run_lm_chat.sh <model.ckpt> [--temp F] [--topk N] [--max N] [--seed U]
#   bash Examples/lm-chat/run_lm_chat.sh lm.ckpt --temp 0.8
#
# Скрипт: cd в корень репозитория -> сборка release -> запуск с
# пробросом всех аргументов. Все параметры утилиты — см. README.md.

set -e

# Корень репозитория (скрипт лежит в Examples/lm-chat/).
cd "$(cd "$(dirname "$0")" && pwd -P)/../.."

# Платформа: linux нативно, всё остальное (git-bash/MSYS на Windows) — windows.
OS="$(uname -s)"
case "$OS" in
    Linux*) PLATFORM="linux";  EXE="" ;;
    *)      PLATFORM="windows"; EXE=".exe" ;;
esac

masuka -b release -p "$PLATFORM" -e lm_chat -nr
exec "bin/release-$PLATFORM/lm_chat$EXE" "$@"
