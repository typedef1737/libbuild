# lm-chat — генерация по чекпоинту (шаг 3 пайплайна MS1)

CLI-утилита: загружает чекпоинт от `lm-train` (веса + config + встроенный
BPE) и в цикле читает промпт из консоли, печатая продолжение модели.
Чистое продолжение текста (`AppendSep = 0`): модель ведёт фразу дальше
и останавливается на `<EOS>`.

Пайплайн MS1: `bpe-train` → `lm-train` → `lm-chat`.

## Запуск

```bash
masuka -b release -p windows -e lm_chat -nr
bin\release-windows\lm_chat.exe <model.ckpt> [--temp F] [--topk N] [--max N]
```

На Linux (или из git-bash) — одним скриптом (сборка + запуск):

```bash
bash Examples/lm-chat/run_lm_chat.sh <model.ckpt> [--temp F] [--topk N]
```

Перед первым использованием: `chmod +x Examples/lm-chat/run_lm_chat.sh`.
Скрипт сам находит корень репозитория, собирает release под текущую
платформу (linux/windows) и запускает утилиту с пробросом аргументов.

Пример:

```powershell
bin\release-windows\lm_chat.exe lm.ckpt --temp 0.8 --topk 20
```

## Параметры

| Параметр | По умолчанию | Описание |
|---|---|---|
| `<model.ckpt>` | — (обязательный) | чекпоинт от `lm-train` |
| `--temp <f>` | `0.8` | temperature сэмплирования; `0` = greedy (детерминированно) |
| `--topk <n>` | `20` | top-k фильтр сэмплирования |
| `--max <n>` | `64` | лимит токенов ответа |
| `--seed <u>` | `1` | seed генерации (одинаковый промпт + настройки → тот же ответ) |

## Сессия

```text
=== lm-chat: interactive generation from checkpoint ===
model: lm.ckpt params=142473 vocab=521
gen: temp=0.80 topk=20 max=64 seed=1 (prelude continuation)
type a prompt, or 'exit' to quit

> Далеко за рекой
>  темнел лес, и дорога шла прямо туда.

> Дождь начался
>  ещё утром и не прекращался до самого вечера.

> exit
bye
```

Выход: `exit` / `quit` / Ctrl+C / конец ввода (Ctrl+Z, Enter).
Пустая строка игнорируется.

## Windows и кириллица

На старте консоль переводится в UTF-8 (`SetConsoleCP(65001)` /
`SetConsoleOutputCP(65001)`) — иначе `fgets` получил бы байты в CP866,
и BPE закодировал бы мусор. Если кириллица в ответах отображается
криво, выполните `chcp 65001` перед запуском или запустите утилиту из
Windows Terminal.
