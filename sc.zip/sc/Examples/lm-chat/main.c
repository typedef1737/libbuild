/*
  lm_chat — CLI-утилита, шаг 3 пайплайна MS1: генерация по чекпоинту.

  Пайплайн MS1 разбит на три CLI-инструмента (см. Docs/todo-0.md):
    1. bpe_train — словарь BPE по директории с текстовыми файлами;
    2. lm_train  — обучение LM-прелюдии по BPE + корпусу;
    3. lm_chat   — интерактивная генерация по чекпоинту (эта утилита).

  Что делает эта утилита:
    1. загружает чекпоинт от lm_train (веса + config + встроенный BPE);
    2. в цикле читает промпт из консоли и печатает продолжение модели
       (чистое продолжение текста, AppendSep = 0 — модель ведёт фразу
       дальше и останавливается на <EOS>):

         > Далеко за рекой
         >  темнел лес, и дорога шла прямо туда.

       Выход: "exit" / "quit" / Ctrl+C / конец ввода (Ctrl+Z, Enter).

  Запуск из корня репозитория:
    masuka -b release -p windows -e lm_chat -nr
    bin\release-windows\lm_chat.exe <model.ckpt> [--temp F] [--topk N] [--max N]

  Пример:
    bin\release-windows\lm_chat.exe lm.ckpt --temp 0.8 --topk 20

  Параметры:
    <model.ckpt>  обязательный путь к чекпоинту от lm_train;
    --temp <f>    temperature сэмплирования (по умолчанию 0.8; 0 = greedy);
    --topk <n>    top-k фильтр (по умолчанию 20);
    --max <n>     лимит токенов ответа (по умолчанию 64);
    --seed <u>    seed генерации (по умолчанию 1; детерминизм при
                  одинаковых prompt/настройках).

  NOTE (Windows): для ввода/вывода кириллицы консоль переводится в
  UTF-8 (SetConsoleCP/SetConsoleOutputCP) — иначе fgets получил бы
  байты в CP866, и BPE закодировал бы мусор.
*/

#include <Sc/Ai.h>
#include <Sc/Sc.h>
#include <Sc/TinyLlm.h>
#include <Sc/Types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef SC_PLATFORM_WINDOWS
#include <windows.h>
#endif

#define LmChatDefaultTemp 0.8f
#define LmChatDefaultTopK 20
#define LmChatDefaultMaxTokens 64
#define LmChatInputBufferSize 8192

// DOCS: значение флага "-name value" / "--name value" из командной
// строки; если флага нет — pDefault. Ищет пары "флаг, следующий аргумент".
static const char*
_lm_chat_flag(i32 argc, char** argv, const char* pName, const char* pDefault)
{
    for (i32 i = 1; i < argc - 1; ++i)
    {
        if (strcmp(argv[i], pName) == 0)
            return argv[i + 1];
    }
    return pDefault;
}

static void
_lm_chat_print_usage(void)
{
    printf("usage: lm_chat <model.ckpt> [--temp F] [--topk N] [--max N] [--seed U]\n");
    printf("  <model.ckpt>  checkpoint from lm_train (required)\n");
    printf("  --temp <f>    sampling temperature (default: %.2f; 0 = greedy)\n", LmChatDefaultTemp);
    printf("  --topk <n>    top-k filter (default: %d)\n", LmChatDefaultTopK);
    printf("  --max <n>     max answer tokens (default: %d)\n", LmChatDefaultMaxTokens);
    printf("  --seed <u>    generation seed (default: 1)\n");
}

i32
main(i32 argc, char** argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("=== lm-chat: interactive generation from checkpoint ===\n");

    // 1. Аргументы: чекпоинт + настройки генерации.
    const char* pCkptPath = NULL;
    for (i32 i = 1; i < argc; ++i)
    {
        if (argv[i][0] != '-')
        {
            pCkptPath = argv[i];
            break;
        }
    }

    if (!pCkptPath)
    {
        _lm_chat_print_usage();
        return 1;
    }

    f32 temp = (f32)atof(_lm_chat_flag(argc, argv, "--temp", "0.8"));
    i32 topk = atoi(_lm_chat_flag(argc, argv, "--topk", "20"));
    i32 maxTokens = atoi(_lm_chat_flag(argc, argv, "--max", "64"));
    u64 seed = (u64)strtoull(_lm_chat_flag(argc, argv, "--seed", "1"), NULL, 10);
    if (topk <= 0)
        topk = LmChatDefaultTopK;
    if (maxTokens <= 0)
        maxTokens = LmChatDefaultMaxTokens;

    // 2. Консоль Windows -> UTF-8 (и ввод, и вывод кириллицы).
#ifdef SC_PLATFORM_WINDOWS
    SetConsoleCP(65001);
    SetConsoleOutputCP(65001);
#endif

    // 3. Чекпоинт: веса + config + встроенный BPE.
    ScAiBpe bpe = {};
    ScTinyLlmModel* pModel = sc_tiny_llm_load_checkpoint((char*)pCkptPath, &bpe);
    if (!pModel || sc_list_count(bpe.aVocab) <= 0)
    {
        printf("error: cannot load checkpoint %s\n", pCkptPath);
        if (pModel)
            sc_tiny_llm_destroy(pModel);
        return 1;
    }

    printf("model: %s params=%d vocab=%d\n",
        pCkptPath, (i32)sc_tiny_llm_param_count(pModel),
        (i32)sc_list_count(bpe.aVocab));
    printf("gen: temp=%.2f topk=%d max=%d seed=%llu (prelude continuation)\n",
        temp, topk, maxTokens, (unsigned long long)seed);
    printf("type a prompt, or 'exit' to quit\n\n");

    // 4. Интерактивный цикл: > промпт, > ответ модели.
    ScTinyLlmGenerateConfig generateConfig = sc_tiny_llm_generate_config_default();
    generateConfig.MaxTokens = maxTokens;
    generateConfig.Temperature = temp;
    generateConfig.TopK = topk;
    // DOCS: чистое продолжение текста (LM-прелюдия): без <SEP>.
    generateConfig.AppendSep = 0;
    generateConfig.Seed = seed;

    char buf[LmChatInputBufferSize] = {};
    while (1)
    {
        printf("> ");
        fflush(stdout);

        if (!fgets(buf, (i32)sizeof(buf), stdin))
            break;

        // DOCS: срезаем перевод строки (LF и CRLF).
        i64 length = (i64)strlen(buf);
        while (length > 0 && (buf[length - 1] == '\n' || buf[length - 1] == '\r'))
            --length;
        buf[length] = 0;

        if (length == 0)
            continue;
        if (strcmp(buf, "exit") == 0 || strcmp(buf, "quit") == 0)
            break;

        // NOTE: sc_tiny_llm_generate возвращает ScString — освобождать
        // через sc_string_destroy (не sc_memory_free).
        char* pAnswer = sc_tiny_llm_generate(pModel, bpe, buf, &generateConfig);
        printf("> %s\n\n", pAnswer ? pAnswer : "(generation failed)");
        sc_string_destroy(pAnswer);
    }

    printf("\nbye\n");
    sc_tiny_llm_destroy(pModel);
    sc_ai_bpe_destroy(&bpe);
    return 0;
}
