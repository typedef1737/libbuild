![masuka ascii](md-content/masuka-ascii.png)

# masuka

Masuka is a custom build system written in C99 that, like its namesake from the Miami Metro forensics department, combines an eccentric exterior with absolute professionalism in its work.

# Introduction

to build masuka through cli:

On Linux run:
```sh
./vince_build.sh
```

On Windows run:
```bat
./vince_build.bat
```
