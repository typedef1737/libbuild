<div align="center">

<img src="md-content/masuka-ascii.png" alt="Masuka ASCII art" width="760">

# Masuka

**A small, declarative build system written in C99.**
No CMake, no Make, no magic — just `vince.masuka`, `*.masuka` files and generated shell/batch scripts.

[![Language](https://img.shields.io/badge/language-C99-00599C?style=for-the-badge&logo=c&logoColor=white)](https://en.wikipedia.org/wiki/C99)
[![Platforms](https://img.shields.io/badge/platforms-Linux%20%7C%20Windows-4EAA25?style=for-the-badge&logo=linux&logoColor=white)](#supported-platforms)
[![Arch](https://img.shields.io/badge/arch-x86__64-6A0DAD?style=for-the-badge)](#supported-platforms)
[![Compiler](https://img.shields.io/badge/compiler-clang-1E90FF?style=for-the-badge&logo=llvm&logoColor=white)](#requirements)
[![Dependencies](https://img.shields.io/badge/dependencies-zero-FF2D95?style=for-the-badge)](#requirements)
[![Config](https://img.shields.io/badge/config-vince.masuka-FFA500?style=for-the-badge)](#configuration-syntax)

[Quick start](#quick-start) · [CLI](#cli-reference) · [Syntax](#configuration-syntax) · [How it works](#how-it-works) · [Platforms](#supported-platforms) · [Recipes](#recipes) · [Troubleshooting](#troubleshooting)

</div>

> [!NOTE]
> Masuka is the build system. <br/> 
> Like its namesake from the Miami Metro forensics department, <br/> 
> it combines an eccentric exterior with absolute professionalism in its work. <br/> 
> It parses a tiny declarative language, resolves a project graph and emits readable build scripts that call `clang`.

## At a glance

| Property | Value |
|:--|:--|
| Language | C99 |
| Configuration | one `vince.masuka` (workspace) + any `*.masuka` (project) |
| Platforms | 🟢 Linux x86_64 · 🟢 Windows x86_64 |
| Project types | `Executable`, `StaticLib`, `DynamicLib` |
| Build steps | 🟢 compile · 🟢 link / archive · 🟢 run / test · 🟢 generate sh / bat / `compile_commands.json` |
| Parallelism | 🟢 POSIX: background shell jobs · Windows: masuka-driven thread pool |
| External tools | `clang` + `ar` (`clang.exe` + `llvm-ar.exe` on Windows) |
| Outputs | `.a` / `.so` / `.lib` / `.dll` |

---

## Quick start

### Requirements

| Tool | Linux | Windows | Notes |
|:--|:--|:--|:--|
| C compiler | `clang` | `clang.exe` | hard-coded by the generator, must be on `PATH` |
| Archiver | `ar` | `llvm-ar.exe` | used for `StaticLib` projects |
| Shell | `bash` | `cmd.exe` | generated scripts are `.sh` / `.bat` |
| Architecture | x86_64 | x86_64 | generated commands always pass `-m64` |

> [!IMPORTANT]
> Masuka does not detect or choose a compiler. <br/>
> It always uses `clang` 

### Build Masuka from source

```sh
# Linux
./vince_build.sh
./bin/release-linux/masuka --help
```

```bat
:: Windows
vince_build.bat
bin\release-windows\masuka.exe --help
```

Or use prebuilt Masuka. Binaries live in [`Packages/`](Packages/) (but they may lag behind the source).

### Create your first workspace

```text
my-project/
├── vince.masuka     ← workspace: builds, platforms, entry project
├── hello.masuka     ← project description
└── src/
    └── main.c
```

**`vince.masuka`**

```text
// Workspace: a tiny demo.

workspace demo
{
    entry: "hello"

    builds: [
        { name: "debug"   preprocessor: "DEMO_DEBUG"   optimize: 0 }
        { name: "release" preprocessor: "DEMO_RELEASE" optimize: 1 }
    ]

    platforms: [
        { name: "linux"   preprocessor: "DEMO_LINUX" }
        { name: "windows" preprocessor: "DEMO_WINDOWS" }
    ]
}
```

**`hello.masuka`**

```text
project hello
{
    type: "Executable"

    bin: "bin/{build}-{platform}"
    objdir: "obj/{project}/{build}-{platform}"

    source: [ "src/**.c" ]
}
```

**`src/main.c`**

```c
#include <stdio.h>

int main(void)
{
    printf("Hello from Masuka!\n");
    return 0;
}
```

Now build and run it (assuming `masuka` is on your `PATH`):

```sh
masuka -b debug -p linux -j 8
./bin/debug-linux/hello
# Hello from Masuka!

# or build and run the entry project in one command:
masuka -r -b debug -p linux
```

> [!TIP]
> Running plain `masuka` builds the default configuration. <br/>
> The default build/platform is the host-matching entry declared in `vince.masuka`. <br/>
> Use `-b` and `-p` to be explicit.

---

## CLI reference

```text
masuka [flags]
```

| Flag | Value | Description | Default |
|:--|:--|:--|:--|
| `-b` | `<build>` | Build name declared in `vince.masuka` (`debug`, `release`, …) | host-matching / first |
| `-p` | `<platform>` | Platform name declared in `vince.masuka`; also chooses `.sh` or `.bat` script flavor | host-matching / first |
| `-d` | `<directory>` | Workspace directory; Masuka `cd`s there before reading `vince.masuka` | current directory |
| `-j` | `<count>` | Parallel jobs, `0 < count <= 2 × CPU cores` | `1` |
| `-c` | — | Remove build artifacts of the selected configuration | off |
| `-gb` | — | Write generated scripts to disk (`vince_build.*` and `build_<Project>.*`) | off |
| `-rb` | — | Clean + generate + build (`-c` + `-gb` + compile) | off |
| `-gccj` | — | Write `compile_commands.json` at the workspace root | off |
| `-nc` | — | Do not compile; useful with `-gb`, `-gccj`, `-c` | off |
| `-r` | — | Run the entry project after building | off |
| `-e` | `<project>` | Run the given project; implies `-r` | — |
| `-a` | `<arguments>` | Program arguments for `-r` / `-e` (max 1023 bytes) | — |
| `-a{N}` | `<arguments>` | Same as `-a`, with an explicitly declared length `N` | — |
| `-t` | — | Run every `Executable` project of the workspace | off |
| `-l` | — | List all projects of the workspace with their types | off |
| `-lc` | — | Compile info of the entry project: dependencies in compile order + sources that will be recompiled (changed files in red) | off |
| `-pt`, `--perf-test` | — | Profile the build: per-file compile times, per-project build times (dependency tree), compiler warnings/errors summary, target sizes | off |
| `-v`, `--version` | — | Print the Masuka version and build, exit | — |
| `-h`, `--help` | — | Print help and exit | — |

### Exit codes

| Code | Meaning |
|:--:|:--|
| `0` | 🟢 Success |
| `1` | 🔴 Build, link or run failed |
| `2` | 🔴 Invalid CLI configuration / `vince.masuka` / project graph |

### Argument quoting for `-a`

The `-a` string is split into program arguments using simple shell-like rules:

| Syntax | Meaning |
|:--|:--|
| spaces / tabs | separate words |
| `"..."` | one word; supports `\"` and `\\` escapes |
| `'...'` | one literal word (no escapes inside) |
| unquoted text | literal characters; backslash has no special meaning outside quotes |

```sh
masuka -e app -a '--input "my file.txt" --verbose'
```

---

## Configuration syntax

Masuka reads **one** `vince.masuka` workspace file and discovers **all** `*.masuka` files recursively in the workspace. Every file containing a `project <Name> { ... }` block becomes a project. The `vince.masuka` file is also scanned but skipped as a project — this produces the harmless warning `no 'project' declaration, skipped`.

> [!WARNING]
> The parser is intentionally small and line-oriented. Keep `workspace` / `project` declarations on their own lines, quote all values, use bare names for `workspace` and `project`, and keep **one `project` block per file**. Commas between entries are optional. Comments with `//` are supported, but in `vince.masuka` leave a blank line after a comment before the next declaration, and in project files never write `field:` inside a comment.

### Workspace file: `vince.masuka`

| Field | Form | Required | Meaning |
|:--|:--|:--:|:--|
| `workspace` | `workspace <Name>` | ✅ | Workspace name, a bare word without quotes |
| `entry` | `entry: "<Project>"` | — | Default project for `-r`; `-e` overrides it |
| `let` | `let <KEY>: "<value>"` | — | Custom variable, usable as `{KEY}` |
| `builds` | `builds: [ { ... } ]` | ✅ | At least one build; names must be unique |
| `platforms` | `platforms: [ { ... } ]` | ✅ | At least one platform; names must be unique |

**Build object**

| Key | Type | Meaning |
|:--|:--|:--|
| `name` | string | Build name used by `-b` and `{build}` |
| `preprocessor` | string | Added to every project as `-D<value>` |
| `optimize` | `0` / `1` | `1` → `-O2`; otherwise `-g -O0` |

**Platform object**

| Key | Type | Meaning |
|:--|:--|:--|
| `name` | string | Platform name used by `-p` and `{platform}`; `linux` / `windows` also enable matching blocks in project files |
| `preprocessor` | string | Added to every project as `-D<value>` |

> [!TIP]
> Build and platform names are free-form, but keeping `debug` / `release` and `linux` / `windows` makes the defaults and platform-specific blocks behave predictably.
> ll change in the future!

### Project file: `*.masuka`

| Field | Form | Required | Path base | Meaning |
|:--|:--|:--:|:--|:--|
| `project` | `project <Name>` | ✅ | — | Project name: letters, digits and `_` |
| `type` | `"Executable"` · `"StaticLib"` · `"DynamicLib"` | ✅ | — | Output kind and link mode |
| `bin` | `"<path>"` | ✅ | workspace | Output directory template |
| `objdir` | `"<path>"` | ✅ | workspace | Object directory template |
| `source` | `[ "<path>" ... ]` | ✅ | project | Source files or globs; must not be empty |
| `include` | `[ "<path>" ... ]` | — | workspace | Extra `-I` directories |
| `provide-include` | `[ "<path>" ... ]` | — | project | Include directories exported to dependents (transitively) |
| `dependencies` | `[ "<Project>" ... ]` | — | — | Other projects; controls build order, linking and include propagation |
| `links` | `[ "<link>" ... ]` | — | — | Library names (`m` → `-lm`) or raw linker flags (`-pthread`) |
| `preprocessors` | `[ "<value>" ... ]` | — | — | Added as `-D<value>`; `LEVEL=2` becomes `-DLEVEL=2` |

Missing `type`, `bin`, `objdir` or `source` is a configuration error. Unknown fields are ignored.

### Variables and placeholders

| Placeholder | Value |
|:--|:--|
| `{build}` | Selected build name |
| `{platform}` | Selected platform name |
| `{project}` | Current project name (available inside project files) |
| `{KEY}` | Value declared with `let KEY: "..."` in `vince.masuka` |

Substitution is applied to `bin`, `objdir`, `source`, `include`, `provide-include`, `dependencies`, `links`, `preprocessors` and platform blocks.

```text
workspace demo
{
    let OUT: "artifacts"

    builds: [
        { name: "debug" optimize: 0 }
        { name: "release" optimize: 1 }
    ]

    platforms: [
        { name: "linux" }
        { name: "windows" }
    ]
}
```

```text
project app
{
    type: "Executable"
    bin: "{OUT}/{build}-{platform}"
    objdir: "obj/{project}/{build}-{platform}"
    source: [ "src/**.c" ]
}
```

> [!NOTE]
> Substitution is single-pass: a `let` value is inserted as-is and is not expanded again. Unknown placeholders are reported in the log and replaced with nothing. Environment variables (`$VAR`) and `..` path concatenation are **not** implemented — write literal paths or `let` variables.

### Paths and globs

| Example | Result |
|:--|:--|
| `source: [ "src/main.c" ]` | exactly one file, relative to the project directory |
| `source: [ "src/**.c" ]` | every `.c` file under `src/` recursively |
| `source: [ "src/*.c" ]` | same as above; `**` and `*` are equivalent masks |
| `source: [ "src/front/*.c" ]` | every `.c` under `src/front/` recursively |
| `include: [ "third_party/include" ]` | `-Ithird_party/include`, relative to the workspace root |

`*` is the only wildcard. Everything before the first `*` is the starting directory; the rest becomes a file-name mask. An unmatched pattern is reported as an error.

### Platform blocks

A project can extend its fields for a concrete platform:

```text
project app
{
    type: "Executable"
    bin: "bin/{build}-{platform}"
    objdir: "obj/{project}/{build}-{platform}"
    source: [ "src/**.c" ]

    links: [ "m" ]

    linux: {
        links: [ "pthread", "dl" ]
    }

    windows: {
        links: [ "pathcch", "shell32", "bcrypt" ]
    }
}
```

The block whose key matches the selected platform name is **appended** to the base fields (arrays are merged, not replaced). Only `linux` and `windows` blocks are recognized by the parser. Supported keys inside a block: `source`, `include`, `provide-include`, `dependencies`, `links`, `preprocessors`.

### Projects, dependencies and linking

`dependencies` is a graph, not a list of flags:

- projects are topologically sorted; dependencies build first;
- a dependency is linked automatically as `-l<name>` when an executable or shared library is linked, and its `bin` directory becomes `-L<dir>`;
- `provide-include` directories of a dependency (and its dependencies) are added to the dependent project's `-I` list;
- unknown dependencies, self-dependencies, duplicate project names and cycles are configuration errors;
- independent projects can build in parallel waves when `-j > 1` (POSIX scripts, Windows thread pool).

**`util.masuka`**

```text
project util
{
    type: "StaticLib"
    bin: "bin/{build}-{platform}"
    objdir: "obj/{project}/{build}-{platform}"
    source: [ "util/**.c" ]
    provide-include: [ "util" ]
}
```

**`app.masuka`**

```text
project app
{
    type: "Executable"
    bin: "bin/{build}-{platform}"
    objdir: "obj/{project}/{build}-{platform}"
    source: [ "src/**.c" ]
    dependencies: [ "util" ]
    links: [ "m" ]
}
```

---

## How it works

```mermaid
%%{init: {'theme':'base','themeVariables':{'primaryColor':'#ffe3f1','primaryTextColor':'#4a0a2a','primaryBorderColor':'#d63384','lineColor':'#6f42c1','fontFamily':'ui-sans-serif'}}}%%
flowchart TD
    A["masuka [flags]..."] --> B["vince.masuka..."]
    B --> C["scan workspace"]
    C --> D["parse AST"]
    D --> E["substitute vars"]
    E --> F["merge platform block"]
    F --> G["resolve graph<br/>globs · deps · cycles"]
    G --> H["generate scripts<br/>.bat/.sh"]
    H --> I["compile via<br/>clang"]
    I --> J["link"]
    J --> K["run exe"]

    classDef cli fill:#ffe3f1,stroke:#d63384,stroke-width:2px,color:#4a0a2a
    classDef cfg fill:#f3e8ff,stroke:#8b5cf6,stroke-width:2px,color:#2e1065
    classDef gen fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#082f49
    classDef out fill:#dcfce7,stroke:#16a34a,stroke-width:2px,color:#052e16
    class A cli
    class B,C,D,E,F,G cfg
    class H,I,J gen
    class K out
```

### Pipeline

1. **CLI parsing.** Flags are parsed, system defaults fill in `-b`, `-p` and `-d`, and everything is validated early where possible.
2. **Workspace and project discovery.** `vince.masuka` is read; then every directory in the workspace is scanned for `*.masuka`, including the root.
3. **Parsing and validation.** Each project becomes a small AST; required fields, project type, names and arrays are validated with file/field diagnostics.
4. **Preprocessing.** `{build}`, `{platform}`, `{project}` and `let` variables are substituted in every relevant string.
5. **Platform merge.** The selected `linux:` / `windows:` block is appended to the project.
6. **Graph resolution.** Source globs are expanded, duplicate names and dependency cycles are rejected, projects are topologically sorted, and `provide-include` closures are propagated.
7. **Script generation.** Masuka emits a main script plus one script per project. Scripts `cd` into the absolute workspace root, create output directories and contain explicit compiler, archiver and linker commands.
8. **Execution.** The generated script is run with `bash` or `cmd /c`; compiler output goes straight to the terminal.
9. **Optional actions.** `-gccj` writes `compile_commands.json`; after the build, `-r` / `-e` run a program and `-t` runs tests.

### Generated scripts

| Artifact | Written by | Location |
|:--|:--|:--|
| Main script | `-gb` / `-rb` | `<workspace>/vince_build.sh` or `vince_build.bat` |
| Project script | `-gb` / `-rb` | next to the project's `*.masuka` as `build_<Project>.sh` / `.bat` |
| Temporary scripts | plain `masuka` (no `-gb`) | `bin/.masuka-tmp/`, removed after the build |
| Compilation database | `-gccj` | `<workspace>/compile_commands.json` |
| Build stamp | POSIX incremental builds | `<objdir>/.masuka_flags` |

> [!IMPORTANT]
> Generated scripts are build artifacts. Do not edit them: `masuka -gb` rewrites them. Change `*.masuka` files instead.

### Incremental builds

| Situation | Recompile? |
|:--|:--:|
| Object file is missing | ✅ |
| Source file is newer than the object | ✅ |
| Compile flags changed (`-D`, `-I`, `-O2`, build/platform selection) | ✅ all translation units of the project |
| A header included by the source changed | ❌ not tracked |
| Windows `.bat` build | ✅ always rebuilds (portable mtime checks are not used in `cmd`) |

Link and archive steps always run after compilation. Because headers are not tracked, use `masuka -rb` (clean rebuild) after changing headers that do not correspond to a changed `.c` file.

### Output layout

| Project type | Linux | Windows |
|:--|:--|:--|
| `Executable` | `<bin>/<project>` | `<bin>\<project>.exe` |
| `StaticLib` | `<bin>/lib<project>.a` | `<bin>\<project>.lib` |
| `DynamicLib` | `<bin>/lib<project>.so` | `<bin>\<project>.dll` |

Object files mirror the source path inside `objdir`:

```text
obj/hello/debug-linux/src/main.o
obj/util/debug-linux/util/string.o
```

When a dynamic library is among the dependencies, Linux links add `-Wl,-rpath,$ORIGIN`, so shared libraries are found next to the executable.

### Compiler flags

| Flag | When |
|:--|:--|
| `-std=c99 -m64` | always |
| `-O2` | selected build has `optimize: 1` |
| `-g -O0` | selected build has `optimize: 0` or omits it |
| `-fPIC` | project type is `DynamicLib` |
| `-D<value>` | every entry in `preprocessors` + build/platform preprocessors |
| `-I<path>` | every entry in `include` + provided includes from dependencies |
| `-shared` | linking a `DynamicLib` |
| `-L<path>` / `-l<name>` | dependency binary directories and libraries |
| `-Wl,-rpath,$ORIGIN` | a dynamic dependency is linked on Linux |

---

## Supported platforms

| Platform | Status | Scripts | Toolchain | Executable | Static lib | Shared lib |
|:--|:--:|:--|:--|:--|:--|:--|
| **Linux x86_64** | 🟢 Supported | `.sh` (`bash`) | `clang`, `ar` | ELF | `.a` | `.so` |
| **Windows x86_64** | 🟢 Supported | `.bat` (`cmd`) | `clang.exe`, `llvm-ar.exe` | `.exe` | `.lib` | `.dll` |
| macOS | 🔴 Not supported | — | — | — | — | — |
| Linux ARM / AArch64 | 🔴 Not supported | — | — | — | — | — |
| Windows ARM64 | 🔴 Not supported | — | — | — | — | — |
| Cross-compilation | 🔴 Not supported | — | — | — | — | — |

Why the limits:

- the source contains `#error "Not platform defined!"` unless `SC_PLATFORM_LINUX` or `SC_PLATFORM_WINDOWS` is defined;
- generated commands always use `-m64` (x86_64 / amd64);
- the compiler name is hard-coded (`clang` on Linux, `clang.exe` on Windows);
- `-p windows` selects the Windows script flavor and Windows library naming, but does not switch the compiler or toolchain — cross-building is not wired up;
- POSIX parallel builds use background `bash` jobs; on Windows with `-j > 1` masuka itself runs the build through a thread pool (`sc_thread`/`sc_mutex` from Sc) — the commands are split into per-thread `.bat` chunks, each executed by one `cmd.exe`, with per-chunk logs merged in order afterwards; `cmd.exe` has no background jobs, so a plain `.bat` script can't parallelize itself;
- the Windows thread-pool path applies to the default build-from-memory invocation (`masuka -j N`); `-gb` scripts written to disk stay sequential — run them through `masuka -j N` for parallelism.

---

## Recipes

| I want to… | Command |
|:--|:--|
| Build the default configuration | `masuka` |
| Build a specific configuration | `masuka -b release -p linux` |
| Build with parallel jobs | `masuka -j 8` |
| Generate scripts without compiling | `masuka -gb -nc` |
| Clean, regenerate and compile | `masuka -rb` |
| Clean the selected configuration | `masuka -c` |
| Build and run the entry project | `masuka -r` |
| Run a specific project with arguments | `masuka -e app -a '--verbose "input.txt"'` |
| Run every executable as a test | `masuka -t` |
| Run the Masuka test suite | `masuka -e masuka-test` |
| Generate `compile_commands.json` for clangd | `masuka -gccj -nc` |
| Build another workspace | `masuka -d ../other-project` |
| Show all flags | `masuka -h` |

---

## Repository layout

| Path | Role |
|:--|:--|
| [`vince.masuka`](vince.masuka) | Workspace description of Masuka itself (`msk`): builds and platforms |
| [`masuka.masuka`](masuka.masuka) | Project description of the Masuka executable (workspace root) |
| [`masuka-test.masuka`](masuka-test.masuka) | Project description of the Masuka test executable |
| [`Source/`](Source/) | All sources, flat: `EntryPoint.c`, `Masuka.c` / `Masuka.h`, `MasukaTests.c` / `MasukaTests.h`, the `Sc` utility library |
| [`Source/EntryPoint.c`](Source/EntryPoint.c) | `main()` of masuka; delegates to `msk_cli_start` |
| [`Source/Masuka.c`](Source/Masuka.c) | CLI, language parser, preprocessor, project resolver, generator, compiler, runner |
| [`Source/Masuka.h`](Source/Masuka.h) | Data structures and the public API of every stage |
| [`Source/MasukaTests.c`](Source/MasukaTests.c) / [`.h`](Source/MasukaTests.h) | Unit test suite with its own `main` (built as `masuka-test`) |
| `Source/Sc*.c`, `Source/Json*.c`, `Source/Test*.c`, `Source/Types*.c` | Small cross-platform C utility library: strings, lists, dicts, files, threads, jobs, logging, tests |
| [`vince_build.sh`](vince_build.sh) / [`vince_build.bat`](vince_build.bat) | Generated main build scripts (bootstrap) |
| `build_masuka.sh` / `build_masuka.bat` | Generated per-project build scripts (bootstrap, workspace root) |
| [`Packages/`](Packages/) | Prebuilt `masuka` / `masuka.exe` binaries |
| [`md-content/`](md-content/) | README artwork |

### Build pipeline of Masuka itself

```text
vince.masuka (msk)
  ├── masuka.masuka (project masuka, Executable)
  │       └── Source/EntryPoint.c + Source/Masuka.c + Source/Sc*.c ...
  │             ↓
  │       bin/release-linux/masuka   (or bin\release-windows\masuka.exe)
  └── masuka-test.masuka (project masuka-test, Executable)
        └── Source/MasukaTests.c + Source/Masuka.c + Source/Sc*.c ...
              ↓
        bin/release-linux/masuka-test
```

The checked-in bootstrap scripts were generated by a previous Masuka build and are committed so the project can be built from a clean checkout. Once a working binary exists, `masuka -gb` can regenerate them; do not edit generated scripts by hand.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|:--|:--|:--|
| `No vince.masuka file existed!` | wrong working directory | run from the workspace or pass `-d <dir>` |
| `vince.masuka: missing 'workspace <Name>' declaration` | a `//` comment directly above `workspace` | add a blank line after the comment; keep the workspace name unquoted |
| `-b: build '…' not found` | name is not declared in `builds` | add it to `builds` or use an existing name |
| `-p: platform '…' not found` | name is not declared in `platforms` | add it to `platforms` or use an existing name |
| `source pattern '…' doesn't match any file` | wrong glob or empty directory | check the path relative to the project file |
| `Project '…' depends on unknown project '…'` | dependency name typo | use the exact `project <Name>` |
| `Dependency cycle detected` | circular `dependencies` | break the cycle |
| `Duplicate project name` | two project blocks with the same name | rename one project |
| `clang: command not found` | compiler not installed / not on `PATH` | install clang or fix `PATH` |
| Headers changed, nothing rebuilds | header dependencies are not tracked | `masuka -rb` |
| `-gb` rewrote my scripts | this is expected | never edit generated scripts; edit `*.masuka` |
| `vince.masuka: no 'project' declaration, skipped` | workspace file is also scanned as a project | harmless warning; ignore it |

> [!CAUTION]
> `masuka -c` removes the generated `vince_build.*`, `build_<Project>.*` scripts and the **entire** `bin` / `objdir` directories of the selected configuration. If you point `bin` or `objdir` at a shared directory, make sure that deleting it is safe.

---

## Current limitations

- **No header dependency tracking.** Touching an included header does not recompile its users; use `-rb`.
- **Windows `.bat` builds always rebuild.** Scripts for Windows do not use mtime checks; every translation unit is recompiled on every invocation.
- **No cross-compilation.** `-p` chooses a script flavor and naming scheme, not a toolchain.
- **x86_64 only.** `-m64` is hard-coded; ARM is not supported.
- **No custom commands, install targets, package targets or per-file flags.** The language describes compilation units, libraries and links only.
- **No environment-variable expansion** and no `..` path concatenation; use literal paths or `let`.
- **The parser is minimal.** One project block per file is strongly recommended; comments and unusual whitespace can confuse it.
- **`links` are global to a project.** There are no per-source or per-configuration link lists beyond platform blocks.

---

## Development

### Testing

The unit tests live in their own translation unit and binary: a build system
must not test itself. The test project is described by
[`masuka-test.masuka`](masuka-test.masuka) and built as `masuka-test`:

```sh
# build and run the whole suite through masuka itself
masuka -e masuka-test

# or run the already built binary directly
./bin/release-linux/masuka-test
```

The suite covers:

- CLI parsing and validation;
- parsers for `vince.masuka` and project files;
- variable preprocessing;
- platform blocks;
- project graph construction;
- script generation;
- JSON generation;
- the compiler wrapper.

For each test function, the runner prints an `ok` or `fail` status. After all tests are finished, it prints the totals.

### Code conventions

The code follows conventions inherited from the `Sc` library:

| Convention | Meaning |
|:--|:--|
| `i32`, `u64`, `f32`, `real` | Lowercase basic types |
| `ScString`, `ScTimer`, `MskProject` | PascalCase compound types |
| `sc_*`, `msk_*` | Library / build-system prefixes |
| `*_wo_alloc` | The result is not heap-allocated |
| `*_init` / `*_new` | Initialize in place / construct and return |

<div align="center">

🌴 **Declarative configs. Explicit scripts. Zero magic.** 🔬

<sub>Masuka — Miami Metro's finest build system.</sub>

</div>
