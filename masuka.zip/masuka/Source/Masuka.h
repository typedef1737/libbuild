#ifndef MSK_H
#define MSK_H

#include "Types.h"

// DOCS: Masuka version, printed by -v / --version.
#define MSK_MAJOR_VERSION 1
#define MSK_MINOR_VERSION 0
#define MSK_PATCH_VERSION 0

// DOCS: String form of the version: "%d.%d.%d" of the macros above.
#define MSK_STRINGIFY_IMPL(x) #x
#define MSK_STRINGIFY(x) MSK_STRINGIFY_IMPL(x)
#define MSK_VERSION MSK_STRINGIFY(MSK_MAJOR_VERSION) "." MSK_STRINGIFY(MSK_MINOR_VERSION) "." MSK_STRINGIFY(MSK_PATCH_VERSION)

// DOCS: Build configuration the masuka binary was compiled with (-v output).
#if defined(SC_BUILD_DEBUG)
#define MSK_VERSION_BUILD "debug"
#elif defined(SC_BUILD_RELEASE)
#define MSK_VERSION_BUILD "release"
#elif defined(SC_BUILD_DISTRIBUTE)
#define MSK_VERSION_BUILD "distribute"
#else
#define MSK_VERSION_BUILD "unknown"
#endif

// DOCS: Max length of the string passed through -a (without '\0').
#define MSK_CLI_PROGRAM_ARGUMENTS_MAX_LENGTH 1024

// DOCS: Temporary scripts of a build from memory (removed after the build, also by -c).
#define MSK_COMPILER_TEMPORARY_DIRECTORY "bin/.masuka-tmp"

/*
   DOCS: Masuka structs
*/

typedef struct
{
    // DOCS: Flags that change build process flow.
    i8 IsSetup;
    i8 IsClean;                   // -c
    i8 IsRebuild;                 // -rb (clean + generate + build)
    i8 IsCompile;                 // enabled by default, disabled by -nc
    i8 IsExecute;                 // -r (also enabled by -e)
    i8 IsRunTests;                // -t
    i8 IsGenerateCompileCmdsJson; // -gccj
    i8 IsGenerateBuildFiles;      // -gb
    i8 IsHelp;                    // -h / --help
    i8 IsVersion;                 // -v / --version
    i8 IsList;                    // -l (list all projects)
    i8 IsListCompile;             // -lc (entry compile info)
    i8 IsPerfTest;                // -pt / --perf-test (build profiling)
    i8 IsNoRun;                   // -nr (build only, do not run the entry even with -r/-e)

    // DOCS: Set when flag was passed through cli.
    // DOCS: Used to validate user input strictly (defaults are allowed to fallback).
    i8 IsBuildExplicit;
    i8 IsPlatformExplicit;
    i8 IsJobsExplicit;
    i8 IsDirectoryExplicit;
    i8 IsDirectoryApplied; // DOCS: working directory was already changed
    i8 IsEntryExplicit;
    i8 IsArgumentsExplicit;
    i8 IsArgumentsLengthExplicit;
    i8 IsLogLevelExplicit;

    i16 JobsCount;
    i16 BuildIndex;
    i16 PlatformIndex;
    i16 EntryIndex;
    i16 LogLevel;       // -ll: 0 errors only, 1 + warnings, 2 + info (default 2)

    char* pDirectory;        // -d or system default
    char* pBuild;            // -b or system default
    char* pPlatform;         // -p or system default
    char* pJobs;             // raw -j value (validated in msk_cli_validate_args)
    char* pLogLevel;         // raw -ll value (validated in msk_cli_validate_args)
    char* pEntryName;        // -e
    char* pProgramArguments; // -a
    char* pArgumentsLength;  // raw -a{number} value (validated in msk_cli_validate_args)
    i64 ProgramArgumentsLength;
    char* pUnknownArgument;  // first unknown flag
    char* pMissingValueFlag; // first flag without required value
    char* pExePath;          // argv[0]
} MskCliConfig;

// DOCS: Global variables block of vince.masuka: key -> value, used by the preprocessor.
typedef struct
{
    char* pKey;
    char* pValue;
} MskVariable;

typedef struct
{
    char* pName;
} MskString;

typedef struct
{
    char* pName;
    char* pPreprocessor;
    i32 IsOptimize;
} MskBuild;

typedef struct
{
    char* pName;
    char* pPreprocessor;
} MskPlatform;

typedef enum
{
    MskProjectType_Executable = 0,
    MskProjectType_StaticLib,
    MskProjectType_DynamicLib,
} MskProjectType;

typedef struct
{
    char* pName;
    char* pEntryName;
    MskVariable* aVariables;
    MskBuild* aBuilds;
    MskPlatform* aPlatforms;
} MskVince;

typedef struct
{
    char* pName;
    MskString* aSources;
    MskString* aDependencies;
    MskString* aLinks;
    MskString* aIncludes;
    MskString* aProvideIncludes;
    MskString* aPreprocessors;
} MskFilePlatform;

typedef struct
{
    // DOCS: Source *.masuka file and raw `type` value (for validation messages).
    char* pFilePath;
    char* pTypeName;

    char* pProjectName;
    char* pProjectLocation;
    char* pBin;
    char* pObjDir;
    MskProjectType ProjectType;
    MskString* aSources;
    MskString* aDependencies;
    MskString* aLinks;
    MskString* aIncludes;
    MskString* aProvideIncludes;
    MskString* aPreprocessors;

    MskFilePlatform* aPlatforms;
} MskFile;

typedef struct
{
    char* pName;
    // DOCS: Source *.masuka file (for duplicate/validation diagnostics).
    char* pFilePath;
    MskProjectType Type;
    MskString* aSources;
    MskString* aProvided;
    MskString* aDependencies;
    MskString* aLinks;
    MskString* aIncludes;
    MskString* aPreprocessors;
    char* pProjectLocation;
    char* pBin;
    char* pObjDir;
    // DOCS: Selected build is optimized (`optimize: 1` in vince.masuka) => -O2, otherwise -g -O0.
    i8 IsOptimize;
} MskProject;

typedef struct
{
    char** aArguments;
    i64 ArgumentsCount;
} MskConfig;

typedef struct
{
    // DOCS: Part of configuration through cli.
    i8 IsRebuild;
    i8 IsExecute;
    i8 IsGenerate;
    i16 JobsCount;
    i16 BuildIndex;
    i16 PlatformIndex;
    char* pDirectory;

    // DOCS: Part of configuration through vince.masuka file.
    i16 EntryIndex;
    char* pName;
    MskBuild* aBuilds;
    MskPlatform* aPlatforms;
    MskProject* aProjects;
    MskVariable* aVariables;
} MskWorkspace;

typedef struct
{
    i32 ArgumentsCount;
    char** aArguments;
    MskProject Project;
} MskCompileConfig;

typedef struct
{
    char* pCompilationCommands;
} MskCompileResult;

typedef struct
{
    i8 IsOptimize;
    // DOCS: %s/%s.o
    MskString Object;
    MskString SourceFile;
} MskBatch;

typedef struct MskBatchProject
{
    i8 IsCompiled;
    char* pName;
    MskProjectType Type;
    char* pBin;
    char* pObjDir;
    // DOCS: Shared across all batches of this project
    MskString* aIncludes;
    MskString* aLibraries;
    MskString* aPreprocessors;
    MskBatch* aBatches;
    // DOCS: Dependency project names (for linking)
    MskString* aDependencies;
    // DOCS: Project directory location (for writing scripts)
    char* pProjectLocation;
} MskBatchProject;

typedef struct
{
    MskProject* aProjects;
    i32 ProjectsCount;
    // DOCS: Absolute workspace directory: generated commands don't depend on the caller's cwd.
    char* pRootDirectory;
} MskGeneratorJsonConfig;

// DOCS: Build scripts are generated for the host: .sh on Linux, .bat on Windows.
// DOCS: Processes are started from these scripts only (see Documentation/Masuka/audit-and-plan.md, section 7).
typedef enum
{
    MskScriptKind_Shell = 0,
    MskScriptKind_Batch,
} MskScriptKind;

typedef struct
{
    MskProject* aProjects;
    i32 ProjectsCount;
    // DOCS: Parallel compilation inside a project (`-j`); 1 means sequential.
    i16 JobsCount;
    MskScriptKind Kind;
    // DOCS: Absolute workspace directory (`cd` at the beginning of every script).
    char* pRootDirectory;
    // DOCS: Selected configuration, written into the script header.
    char* pBuild;
    char* pPlatform;
    // DOCS: Index of the project generated by msk_generator_build_create_single().
    i32 ProjectIndex;
    // DOCS: When set, per-project scripts are generated into this directory instead of
    // the project directories (build from memory: temporary scripts, M4-1).
    char* pScriptsDirectory;
} MskGeneratorBuildConfig;

typedef struct
{
    char* pSb;
    char* pProjectName;
    // DOCS: <project location>/build_<project>.sh|.bat
    char* pScriptPath;
} MskGeneratorSingleBuildResult;

typedef struct
{
    char* pSb;
    MskGeneratorSingleBuildResult* aResults;
    MskScriptKind Kind;
} MskGeneratorBuildResult;

typedef struct
{
    MskProject* aProjects;
    i32 ProjectsCount;
    // DOCS: -j: parallel translation units and independent projects.
    i16 JobsCount;
    MskScriptKind Kind;
    // DOCS: Absolute workspace directory: scripts are `cd`-ed into it.
    char* pRootDirectory;
    char* pBuild;
    char* pPlatform;
} MskCompilerConfig;

typedef struct
{
    MskScriptKind Kind;
    // DOCS: Absolute workspace directory: <root>/vince_build.sh|.bat is executed.
    char* pRootDirectory;
    // DOCS: Resolved projects (for the build summary: target sizes, -pt tree).
    MskProject* aProjects;
    i32 ProjectsCount;
} MskCompilerScriptsConfig;

typedef struct
{
    // DOCS: Entry project to run: -e <name> or entry from vince.masuka.
    MskProject* pProject;
    // DOCS: Absolute workspace directory: the program is started from it (cwd).
    char* pRootDirectory;
    // DOCS: Parsed -a words (msk_cli_parse_program_arguments); every word is quoted.
    char** aProgramArguments;
    // DOCS: Host script kind: .exe suffix and quoting on Windows.
    MskScriptKind Kind;
} MskRunnerConfig;

typedef struct
{
    MskProject* aProjects;
    i32 ProjectsCount;
    char* pRootDirectory;
    MskScriptKind Kind;
} MskTestRunnerConfig;

/*
   DOCS: Masuka CLI - command line interface of Masuka.
   Contains:
   - the main pipeline function (parse -> vince.masuka -> projects -> build -> run)
   - filling values that were not passed through cli with system defaults
   - validation of the input arguments
*/

i32 msk_cli_start(i32 argumentsCount, char** aArguments);
MskCliConfig msk_cli_parse_args(i32 argumentsCount, char** aArguments);
// DOCS: Fill values that were not passed through cli with system defaults.
void msk_cli_apply_system_defaults(MskCliConfig* pConfig, char* pExePath);
// DOCS: Validate parsed flags against filesystem and vince.masuka.
ScResult msk_cli_validate_args(MskCliConfig* pConfig, MskVince* pVince, MskFile* aFiles, i32 filesCount);
/* DOCS:
    Parse the -a string into argv words (M5-2): whitespace separators,
    "..." with \" and \\ escapes, '...' literal, \x escape outside quotes.
    Words are raw allocated strings: sc_memory_free each, then sc_list_free.
*/
char** msk_cli_parse_program_arguments(char* pString, i64 length);

/*
   DOCS: Masuka Language - the *.masuka configuration language.
   Contains:
   - parse functions of vince.masuka and project files
   - validation of the parsed configuration
*/

MskVince msk_language_vince_new(char* pFileContent);
i32 msk_language_vince_is_valid(MskVince mskVince);
// DOCS: Validate vince.masuka with a precise error (builds/platforms/entry).
ScResult msk_language_vince_validate(MskVince mskVince);
// DOCS: Override {build}/{platform} variables with selected values.
void msk_language_vince_set_selection(MskVince* pVince, char* pBuild, char* pPlatform);
MskFile msk_language_file_new(MskVince* pVince, char* pFilePath);
// DOCS: Parse a *.masuka file from memory (tests, callers that already read the file).
MskFile msk_language_file_new_from_memory(MskVince* pVince, char* pFilePath, char* pFileContent);
i32 msk_language_file_is_valid(MskFile mf);
// DOCS: Validate a parsed *.masuka file; logs the file and the field that is invalid.
ScResult msk_language_file_validate(MskFile mskFile);

/*
   DOCS: Masuka Preprocessor
*/

MskFile msk_preprocessor_file(MskVince* pVince, MskFile mskFile);
// DOCS: Merge the selected platform block (linux:/windows:) into the project.
void msk_file_apply_platform(MskFile* pFile, char* pPlatformName);

/*
   DOCS: Masuka Project - resolved projects (paths, globs, platform, build).
   One data model: MskFile (AST) -> MskProject (resolved) -> generator.
*/

MskProject msk_project_from_file(MskFile mskFile, MskVince mskVince, char* pBuild, char* pPlatform);
MskProject* msk_projects_from_files(MskFile* aFiles, i32 filesCount, MskVince mskVince, char* pBuild, char* pPlatform);
// DOCS: Check dependency names, detect cycles, sort by dependencies, merge
// DOCS: transitive provide-include paths into includes.
ScResult msk_projects_resolve(MskProject* aProjects, i32 projectsCount);

/*
   DOCS: Masuka generator
   Build scripts: the main vince_build.sh (topological order) in the workspace root +
   build_{Project}.sh next to each project, and compile_commands.json for clangd.
*/

// DOCS: -gccj: write compile_commands.json into the workspace root (absolute paths).
i32 msk_generator_json_create(MskGeneratorJsonConfig cfg);
// DOCS: Main script text + per-project script texts (in memory, nothing is written).
MskGeneratorBuildResult msk_generator_build_create(MskGeneratorBuildConfig cfg);
MskGeneratorSingleBuildResult msk_generator_build_create_single(MskGeneratorBuildConfig cfg);
// DOCS: Write generated scripts to disk and make the main script executable.
i32 msk_generator_build_write(MskGeneratorBuildResult* pResult, char* pRootDirectory);
// DOCS: <project location>/build_<project>.sh|.bat (sc_memory_free).
char* msk_generator_project_script_path(MskProject* pProject, MskScriptKind kind);
// DOCS: <root>/vince_build.sh|.bat (sc_memory_free).
char* msk_generator_main_script_path(char* pRootDirectory, MskScriptKind kind);
// DOCS: Host script kind: .sh on Linux, .bat on Windows.
MskScriptKind msk_script_kind_host(void);
// DOCS: Script kind of the selected platform: -p windows => .bat, -p linux => .sh;
// DOCS: unknown platform falls back to the host kind.
MskScriptKind msk_script_kind_from_platform(char* pPlatform);
// DOCS: Object file of a source: mirrors the source path inside objdir (sc_memory_free).
char* msk_project_object_path(MskProject* pProject, char* pSource);
// DOCS: Quote a single script word (sc_memory_free), used by tests and the generator.
char* msk_script_quote_word(char* pWord, MskScriptKind kind);

/*
   DOCS: Masuka compiler
*/

i32 msk_compiler_compile(MskCompilerConfig cfg);
i32 msk_compiler_compile_from_scripts(MskCompilerScriptsConfig cfg);
// DOCS: Remove build artifacts of current build/platform (used by -c and -rb).
void msk_compiler_clean(MskProject* aProjects, i32 projectsCount, char* pRootDirectory);

/*
   DOCS: Masuka runner
*/

i32 msk_runner_run_program(MskRunnerConfig cfg);
i32 msk_runner_run_tests(MskTestRunnerConfig cfg);

/*
   DOCS: Masuka utils
*/

static const char*
msk_project_type_to_string(MskProjectType type)
{
    switch (type)
    {
    case MskProjectType_Executable:
        return "exe";
    case MskProjectType_StaticLib:
        return "static";
    case MskProjectType_DynamicLib:
        return "dynamic";
    }
}

char* msk_parse_next_single_value(char** ppRead, char* pC);
char* msk_parse_next_single_path(MskVariable* aVariables, char** ppRead, char* pC);
char* msk_parse_next_id(char** ppRead, char* pC);
MskString* msk_parse_next_array(char** ppRead, char* pC);

char* msk_preprocess_string(MskVariable* aVariables, i64 variablesCount, char* pString, i64 stringLength);

// DOCS: Path utils (used by the workspace scan and by source glob expansion).
i32 msk_file_regex_match(char* pInput, char* pPattern);
char** msk_get_all_files_from_directory(char* pDirectory, char* pPattern);

// DOCS: Character class of project names: letters, digits and '_'.
i32 msk_language_name_char(char c);
// DOCS: Platform block starts with "linux:" / "windows:" (not a quoted name).
i32 msk_language_platform_block(char* pRead, char* pName);
// DOCS: Is the string in the list (MskString array)?
i8 msk_project_strings_contains(MskString* aStrings, char* pString);

#endif // MSK_H
