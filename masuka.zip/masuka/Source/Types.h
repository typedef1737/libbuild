#ifndef SC_TYPES_H
#define SC_TYPES_H

/*
CONTENT:
    [sc_color] - color struct for storing r,g,b,a values.


OPTIONS:

Inside build tool set preprocessor:
* SC_BUILD_DEBUG  - debug build
* SC_BUILD_RELEASE  - otherwise

// to make 64 bit floating point work
#define SC_FLOAT_64_BIT
*/

/*
  ############################################
  DOCS: Declare our own types as typedef;s
  ############################################
*/

typedef char i8;
typedef short i16;
typedef int i32;
typedef long long int i64;
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef float f32;
typedef double f64;

/*
  ############################################
  DOCS: Convert values
  ############################################
*/

#define to_i8(x) ((i8)(x))
#define to_i16(x) ((i16)(x))
#define to_i32(x) ((i32)(x))
#define to_i64(x) ((i64)(x))
#define to_u8(x) ((u8)(x))

#define to_u16(x) ((u16)(x))
#define to_u32(x) ((u32)(x))
#define to_u64(x) ((u64)(x))

#define to_f32(x) ((f32)(x))
#define to_f64(x) ((f64)(x))

#define f32_to_byte(f) real_to_byte(f)
#define real_to_byte(r) ((u8)(r * 255))

#define SC_I8_MAX 127
#define SC_I16_MAX 32767
#define SC_I32_MAX 2147483647
#define SC_I32_MAX_HALF 1123241323
/* 9 223 372 036 854 775 807 = 9e+18 */
#define SC_I64_MAX (9223372036854775807LL)
#define SC_I64_MIN (i64)(-9223372036854775807LL - 1)

#define SC_U8_MAX 255
#define SC_U16_MAX 65535
#define SC_U32_MAX 4294967295U
/* 18 446 744 073 709 551 615 = 1.8*e+19 */
#define SC_U64_MAX (18446744073709551615ULL)

#define SC_F32_MAX (3.4028234663852886e38f)
#define SC_F64_MAX (1.7976931348623157e+308)
#define SC_F32_MIN (-SC_F32_MAX)
#define SC_F64_MIN (-SC_F64_MAX)

#if !defined(SC_F32_EPSILON)
#define SC_F32_EPSILON 0.0001
#endif // SC_F32_EPSILON

#if !defined(ScNull)
#define ScNull (void*)0
#endif // ScNull

#if !defined(NULL)
#define NULL (void*)0
#endif // NULL

/*
  ############################################
  DOCS: Platform definition
  ############################################
*/

#if defined(SC_PLATFORM_WINDOWS)
#define force_inline static
#elif defined(SC_PLATFORM_LINUX)
#define force_inline static inline __attribute((always_inline))
#else
#error "Platform not supported"
#endif

/*
  ############################################
  DOCS: REAL precision, by default 32 bit
  #define REAL_64_BIT for better accuracy
  ############################################
*/

#if !defined(SC_REAL_64_BIT)
#define SC_REAL_32_BIT
#endif

/*
  ############################################
  DOCS: System byte order
  ############################################
*/

#if !defined(SC_SYSTEM_BIG) && !defined(SC_SYSTEM_LIT)
/*🐨
  1 in endian system:
    16                0
  BigEndian   : 1000 0000 0000 0000
    0                16
  LittleEndian: 0000 0000 0000 0001

  general order: 123 => little: 0000 0123
        big   : 0123 0000
*/

#define SC_SYSTEM_LIT (*((u8*)&(u32) { 1 }))
#define SC_SYSTEM_BIG (!(SC_SYSTEM_LIT))

#endif

/*
  ############################################
  DOCS: sc
  ############################################
*/

typedef enum
{
    ScBuild_Debug = 0,
    ScBuild_Release,
    ScBuild_Distribution,
} ScBuild;

typedef enum
{
    ScOs_Linux = 0,
    ScOs_Windows,
} ScOs;

typedef enum
{
    ScReal_32Bit = 0,
    ScReal_64Bit,
} ScReal;

typedef enum
{
    ScEndian_Little = 0,
    ScEndian_Big,
} ScEndian;

const char* sc_build_to_string(ScBuild build);
const char* sc_os_to_string(ScOs os);
const char* sc_real_to_string(ScReal scReal);
const char* sc_endian_to_string(ScEndian scEndian);

typedef struct
{
    ScBuild Build;
    ScOs Os;
    ScReal Real;
    ScEndian Endian;
} ScSystemInfo;

ScSystemInfo sc_system_info_get();
void sc_system_info_print();
// DOCS: Physical (logical) CPU count. Always >= 1.
i32 sc_system_cpu_count();

/*

  ###################################
  ###################################
  sc_color
  ###################################
  ###################################

*/

typedef struct
{ // ((r << 24) | (g << 16) | (b << 8) | (a))
    u8 R;
    u8 G;
    u8 B;
    u8 A;
} ScColor;

#define ScColor_R(r) ((u32)(((ScColor*)(r))->R))
#define ScColor_G(g) ((u32)(((ScColor*)(g))->G))
#define ScColor_B(b) ((u32)(((ScColor*)(b))->B))
#define ScColor_A(a) ((u32)(((ScColor*)(a))->A))
#define ScColor_RGBA(r, g, b, a) ((a << 24) | (b << 16) | (g << 8) | (r))
#define ScColor_ARGB(a, r, g, b) (((a) << 24) | ((r) << 16) | ((g) << 8) | (b))

/*
  ############################################
  DOCS: Sc Terminal Color;s
  ############################################
*/

#define ScTerminalMagneta(x) "\x1B[35m" x "\033[0m"
#define ScTerminalRed(x) "\x1B[31m" x "\033[0m"
#define ScTerminalYellow(x) "\x1B[93m" x "\033[0m"
#define ScTerminalGreen(x) "\x1B[32m" x "\033[0m"
#define ScTerminalOrange(x) "\x1B[33m" x "\033[0m"
#define ScTerminalBlue(x) "\x1B[33m" x "\033[0m"
#define ScTerminalWhite(x) "\x1B[37m" x "\033[0m"
#define ScTerminalRedActive(x) "\033[5;1;31m" x "\033[0m"

/*
  #############################################
  DOCS: Constant;s
  #############################################
*/

#define ScInvalidId -1337

/*
  #############################################
  DOCS: Helper methods abs, elvis, swap, minmax
  #############################################
*/

void sc_copy(void* pvWrite, void* pvRead, u64 size);
i32 sc_i32_sign(i32 v);
i32 sc_i32_abs(i32 v);
i32 sc_f32_sign(f32 v);
f32 sc_f32_abs(f32 v);

// DOCS: Count bits for any type that can be sizeof;ed
#define sc_bits_count(structOrAny) ((i32)(sizeof(structOrAny) * 8))

// DOCS: True on N run
#define sc_helper_tonr(n)         \
    ({                            \
        static i32 isFlag = n;    \
        i32 returnValue = isFlag; \
        if (isFlag)               \
            --isFlag;             \
        returnValue;              \
    })

// DOCS: True on first run
#define sc_helper_tofr() sc_helper_tonr(1)

// DOCS: False on first run
#define sc_helper_fofr()   \
    ({                     \
        static i32 is = 0; \
        i32 rv = is;       \
        if (!is)           \
            is = 1;        \
        rv;                \
    })

#define sc_if_null(o, v) ({ \
    __typeof__(o) ov = o;   \
    if (!ov)                \
        ov = v;             \
    ov;                     \
})

#define ScSwap(x, y)            \
    ({                          \
        __typeof__(x) temp = x; \
        x = y;                  \
        y = temp;               \
    })

#define ScMax(x, y)          \
    ({                       \
        __typeof__(x) l = x; \
        __typeof__(y) r = y; \
        (l > r) ? l : r;     \
    })
#define ScMin(x, y)          \
    ({                       \
        __typeof__(x) l = x; \
        __typeof__(y) r = y; \
        (l > r) ? r : l;     \
    })

#define ScMinMax(x, min, max)                \
    ({                                       \
        __typeof__(x) l = x;                 \
        __typeof__(min) mn = min;            \
        __typeof__(max) mx = max;            \
        ((l > mx) ? mx : (l < mn ? mn : l)); \
    })
#define ScMinMaxV2(x, v2v) ScMinMax(x, v2v.Min, v2v.Max)

#define ScKb(x) ((i64)1024 * (i64)x)
#define ScMb(x) ((i64)1024 * ScKb(x))
#define ScGb(x) ((i64)1024 * ScMb(x))
#define ScToKb(x) (((f64)x) / 1024)
#define ScToMb(x) (((f64)ScToKb(x)) / 1024)
#define ScToGb(x) (((f64)ScToMb(x)) / 1024)

#define ScOffsetOf(Type, Field) ((u64)(&(((Type*)0)->Field)))

#define ScAlign(byte) __attribute__((aligned(byte)))
#define ScAlignOf(Type)  \
    ((u64) & (((struct { \
        char c;          \
        Type i;          \
    }*)0)                \
             ->i))
#define ScArrayCount(x) (sizeof(x) / sizeof(x[0]))

#define ScBitAnd(flag, bit) (((flag) & (bit)))
#define ScBitNotAnd(flag, bit) (ScBitAnd(flag, bit) == 0)

#define sc_char_array_set(charArr, pString) \
    ({ sc_char_array_set_ext(charArr, sizeof(charArr), pString, sc_string_get_length(pString)); })
void sc_char_array_set_ext(char aArr[], u64 arrSize, char* pString, i64 stringLength);

/*
  ############################################
  DOCS: Structure types
  ############################################
*/

typedef struct
{
    i32 Length;
    i32 Size;
    char* pData;
} ScString;

typedef struct
{
    i32 Length;
    i32 Size;
    char* pData;
} ScStringView;

typedef struct
{
    i64 Length;
    void* pData;
} ScData;

typedef enum
{
    ScResult_Error = 0,
    ScResult_Success = 1,
    ScResult_Warning = 2
} ScResult;

#if defined(SC_REAL_32_BIT)
typedef f32 real;
#else
typedef f64 real;
#endif

typedef real v3a[3];
typedef real v4a[4];
typedef v3a m3a[3];
typedef v4a m4a[4];

typedef struct
{
    union
    {
        struct
        {
            real X, Y;
        };
        struct
        {
            real Width, Height;
        };
        struct
        {
            real Min, Max;
        };
        real V[2];
    };
} v2;

typedef struct
{
    union
    {
        struct
        {
            i32 X, Y;
        };
        struct
        {
            i32 Width, Height;
        };
        struct
        {
            i32 Min, Max;
        };
        i32 V[2];
    };
} v2i;

typedef struct
{
    i8 IsSet;
    v2 Value;
} v2o;

typedef struct
{
    union
    {
        struct
        {
            real X, Y, Z;
        };
        struct
        {
            real R, G, B;
        };
        struct
        {
            real Hue, Saturation, Value;
        };
        struct
        {
            real Pitch, Yaw, Roll;
        };
        struct
        {
            v2 XY;
            real T3;
        };
        struct
        {
            real T0;
            v2 YZ;
        };
        real V[3];
    };
} v3;

typedef struct
{
    union
    {
        struct
        {
            i32 X, Y, Z;
        };
        i32 V[3];
    };
} v3i;

typedef struct
{
    i8 IsSet;
    v3 Value;
} v3o;

typedef struct
{
    union
    {
        struct
        {
            real X, Y, Z, W;
        };
        struct
        {
            real R, G, B, A;
        };
        struct
        {
            v2 Min;
            v2 Max;
        };

        struct
        {
            v3 RGB;
            f32 A4;
        };
        real V[4];
    };
} v4;

typedef struct
{
    union
    {
        struct
        {
            i32 X, Y, Z, W;
        };
        struct
        {
            i32 R, G, B, A;
        };
        i32 V[4];
    };
} v4i;

typedef struct
{
    i8 IsSet;
    v4 Value;
} v4o;

typedef struct
{
    union
    {
        struct
        {
            real M00, M01, M02;
            real M10, M11, M12;
            real M20, M21, M22;
        };
        struct
        {
            real R0[3];
            real R1[3];
            real R2[3];
        };
        m3a M;
    };
} m3;

/* DOCS: Row-Major */
typedef struct
{
    union
    {
        struct
        {
            real M00, M01, M02, M03,
                M10, M11, M12, M13,
                M20, M21, M22, M23,
                M30, M31, M32, M33;
        };
        struct
        {
            real R0[4];
            real R1[4];
            real R2[4];
            real R3[4];
        };
        v4 V[4];
        m4a M;
    };
} m4;

typedef struct
{
    union
    {
        struct
        {
            real X, Y, Z, W;
        };
        v3 XYZ;

        struct
        {
            real X0;
            v3 YZW;
        };

        v4 V4;
        real V[4];
    };
} quat;

#define v2_new(x, y) ({ (v2) { x, y }; })
#define v2_0() v2_new(0, 0)
#define v2_v3(v) v2_new(v.X, v.Y)
#define v2_array(aVals) ({ (v2) { aVals[0], aVals[1] }; })
#define v2i_new(v) ({ (v2i) { x, y }; })

#define v3_new(x, y, z) ({ (v3) { x, y, z }; })
#define v3_v2(v) v3_new(v.X, v.Y, 0.0f)
#define v3_v2v(v, s) v3_new(v.X, v.Y, s)
#define v3_array(aVals) ({ (v3) { aVals[0], aVals[1], aVals[2] }; })
#define v3_v4(v) ({ v3_new(v.X, v.Y, v.Z); })
#define v3_rgb(r, g, b) ({ f32 ratio = 1/255.0f; v3_new(r*ratio, g*ratio, b*ratio); })

#define v4_new(x, y, z, w) ({ (v4) { x, y, z, w }; })
#define v4_v3(v) ({ (v4) { v.X, v.Y, v.Z, 0.0f }; })
#define v4_v3v(v, s) ({ (v4) { v.X, v.Y, v.Z, s }; })
#define v4_array(aVals) ({ v4_new(aVals[0], aVals[1], aVals[2], aVals[3]; })
#define v4_array_w(aVals, s) ({ v4_new(aVals[0], aVals[1], aVals[2], s; })
#define v4_to_argb(color)                         \
    ({                                            \
        u8 a = f32_to_byte(color.A);              \
        u8 r = f32_to_byte(color.R);              \
        u8 g = f32_to_byte(color.G);              \
        u8 b = f32_to_byte(color.B);              \
        u32 colorArgb = ScColor_ARGB(a, r, g, b); \
        colorArgb;                                \
    })

i32 f32_equal(f32 f0, f32 f1);
i32 v2_equal(v2 v0, v2 v1);
i32 v3_equal(v3 v0, v3 v1);
i32 v4_equal(v4 v0, v4 v1);
i32 quat_equal(quat q0, quat q1);

typedef struct
{
    v3 Min;
    v3 Max;
} ScAabb;

typedef struct
{
    f32 _CountSeconds;
    f32 WaitSeconds;
} ScSimpleTimer;

/*
  ############################################
  DOCS: Conditional break, assert, guard
  ############################################
*/

void sc_break(const char* msg, const char* file, int line, const char* condition);

#if defined(SC_BUILD_DEBUG)

#define sc_assert(a)                                                   \
    ({                                                                 \
        const char* pMsg = "[ASSERT] %s:%d condition: %s is false!\n"; \
        if (!(a))                                                      \
            sc_break(pMsg, __FILE__, __LINE__, #a);                    \
    })
#define sc_assert_not_null(ptr) sc_assert(ptr != ScNull)
#define sc_assert_null(ptr) sc_assert((ptr == ScNull))
#define sc_assert_break() sc_assert(0 && "We shouldn't get here!!!")

#else // SC_BUILD_DEBUG

#define sc_assert(a) ((void)0)
#define sc_assert_not_null(ptr) ((void)0)
#define sc_assert_null(ptr) ((void)0)
#define sc_assert_break() ((void)0)
#define sc_assert_null_offset(ptr) ((void)0)

#endif // SC_BUILD_RELEASE

/*
  DOCS(typedef): Guard functionality
*/
#define sc_guard(ptr)                                                 \
    ({                                                                \
        const char* pMsg = "[GUARD] %s:%d condition: %s is false!\n"; \
        if (!(ptr))                                                   \
            sc_break(pMsg, __FILE__, __LINE__, #ptr);                 \
    })
#define sc_guard_not_null(ptr) ({ sc_guard(ptr != NULL && #ptr); })
#define sc_guard_null(ptr) ({ sc_guard(ptr == NULL); })
#define sc_guard_legacy(func) ({ sc_guard(0 && #func " - legacy function!"); })
#define sc_guard_not_impl() ({ sc_guard(0 && "not implementsd!"); })
#define sc_guard_not_used() ({ sc_guard(0 && "not used anymore!"); })
#define sc_guard_call_once() \
    if (sc_helper_fofr())    \
        vguard(0 && "Called more then one time!");

// TODO: Put into asset manager
/*
  #############################################
  DOCS: Asset/Resource path
  #############################################
*/

// todo: move to asset manager
// like am_load_texture("TexturePack1337/Texture.png")
// "TexturePack1337/Texture.png" -> auto translated to
// "Assets/Textures/TexturePack1337/Texture.png"

// note: not sure we will need this
#define BASE_ASSET_PATH "assets/"
#define asset(path) BASE_ASSET_PATH path
#define asset_shader(shader) asset("shaders/") shader
#define asset_texture(texture) asset("textures/") texture
#define asset_cubemap(cubemap) asset("cubemaps/") cubemap
#define asset_font(font) asset("fonts/") font
#define asset_model(model) asset("models/") model
#define asset_sound(sound) asset("sounds/") sound
#define asset_scene(scene) asset("scenes/") scene
#define asset_db(db) asset("databases/") db
#define asset_localization(local) asset("localization/") local

#define BASE_RESOURCE_PATH "Resources/"
#define resource(path) BASE_RESOURCE_PATH path
#define resource_shader(path) resource("Shaders/") path
#define resource_font(path) resource("Fonts/") path
#define resource_texture(path) resource("Textures/") path
#define resource_model(path) resource("Models/") path

#endif // SC_TYPES_H
