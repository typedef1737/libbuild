#if defined(SC_PLATFORM_LINUX)
// DOCS: POSIX declarations (dup2/fileno) for the quiet negative-build test.
#define _POSIX_C_SOURCE 200809L
#endif // SC_PLATFORM_LINUX

#include "Masuka.h"
#include "Sc.h"
#include "Test.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(SC_PLATFORM_LINUX)
#include <unistd.h>
#endif // SC_PLATFORM_LINUX

#define MSK_DEBUG_LOG 0
#if MSK_DEBUG_LOG == 1
#define logf(format, ...) printf(format, __VA_ARGS__)
#else
#define logf(format, ...)
#endif

/*
  Content:

  WIP - not complete, need more code to be complete.
  TEST - need more auto test's in auto test sample project.
  READY - tested or validated.

  Sections (in file order):

READY:
  [msk_cli] - command line interface: flags, defaults, validation, -h/-v output.
  - msk_cli_start - the main pipeline: parse args -> vince.masuka -> projects -> build/run.
  - msk_cli_parse_args - split argv into flags and values.
  - msk_cli_apply_system_defaults - missing -b/-p/-j/-d are taken from the system.
  - msk_cli_validate_args - precise validation of everything (-d, -j, -a, -b, -p, -e).
  - msk_cli_print_help / msk_cli_print_usage_hint / msk_cli_print_version - CLI output.
  - msk_cli_source_needs_recompile - incremental check: no object yet or source is newer.
  - msk_cli_print_project_tree - dependency tree of -l (-e or vince.masuka entry).
  - msk_cli_print_compile_info - -lc: sources + dependencies, recompile candidates in red.

TEST:
  [msk_language & WIP] - the *.masuka configuration language parser.
  - msk_language_vince_new - parse vince.masuka: builds, platforms, entry.
  - msk_language_file_new / _from_memory - parse one *.masuka project file.
  - msk_language_*_is_valid / _validate - precise error messages per field.
  - msk_language_is_identifier / _name_char / _path_char - lexer character classes.
  - msk_language_platform_block - merge linux:/windows: block of a project.

READY:
  [msk_preprocess] - variable substitution in string fields ({{name}} -> value).
  - msk_preprocessor_file - expand variables of every string field of a file.

READY:
  [msk_project] - resolved projects (globs expanded, dependencies linked).
  - msk_project_from_file - one project from one parsed file (MskFile -> MskProject).
  - msk_projects_resolve - validate the graph, sort dependencies-first,
    propagate provide-include of dependencies into dependents.
  - msk_project_object_path - object mirrors the source path inside objdir.
  - msk_project_link_collect - libraries to link: direct dependencies first.
  - msk_projects_levels - dependency level of every project (for parallel waves).

TEST:
  [msk_script] - shell/batch script primitives: quoting, words, commands.
  - msk_script_quote_word - one word ("a b" -> "'a b'" / \"a b\").
  - msk_script_append_word / _command / _mkdir - append quoted script parts.
  - msk_script_kind_host / _from_platform / _extension / _is_batch - script flavor.

READY:
  [msk_generator] - build script generation (sh / bat / compile_commands.json).
  - msk_generator_build_create - per-project + main script of the whole workspace.
  - msk_generator_compile_argv / _archive_argv / _link_argv - argv of one command.
  - msk_generator_json_create - compile_commands.json for clangd and IDEs.
  - msk_generator_flags_text / _stamp_path - flags stamp: rebuild all on flags change.

READY:
  [msk_perf] - -pt profiling and the build summary.
  - msk_perf_report - always printed: success/warnings/errors + target sizes.
  - msk_perf_* - timings of -pt: per source (compile) and per project (build).
  - msk_perf_parse_diagnostics - count "warning:"/"error:" in the captured log.

READY:
  [msk_compiler] - build executors (three paths).
  - msk_compiler_compile - build from memory: temporary scripts, executed and removed.
  - msk_compiler_compile_parallel - Windows + -j: thread pool of sc_thread,
    commands split into per-thread .bat chunks (cmd.exe has no background jobs).
  - msk_compiler_compile_measured - -pt: masuka runs every command itself,
    measured with sc_profiler.
  - msk_compiler_compile_from_scripts - -gb: run the scripts already on disk.
  - msk_compiler_clean - remove generated scripts, objects and targets.

READY:
  [msk_runner] - run/test the built entry point (-r / -e / -t).
  - msk_runner_run_program - run the executable from the workspace root.
  - msk_runner_run_tests - run every test program of the workspace.

READY:
  [msk_utils] - shared parse helpers used by the language parser.
  - msk_parse_next_single_value / _single_path / _id / _array - field readers.
  - msk_file_regex_match - one file name against one star mask.
  - msk_get_all_files_from_directory - recursive glob (star / star-star).

  Convention:

  msk_cli_*      - command line interface.
  msk_language_* - *.masuka parsing.
  msk_preprocess_* - variable expansion.
  msk_project_*  - resolved project helpers.
  msk_script_*   - script quoting/primitives.
  msk_generator_* - script and json generation.
  msk_perf_*     - profiling and build summary.
  msk_compiler_* - build execution.
  msk_runner_*   - run and test.
  msk_parse_*    - low-level parse helpers.

  static functions are internal to Masuka.c; the public API lives in Masuka.h
  (msk_* without a section or exported helpers like msk_language_name_char).

  TODO:
  * cache resolved projects between runs (compile-only invocation)
*/

static const char*
msk_cli_build_name_from_system(ScBuild build)
{
    switch (build)
    {
    case ScBuild_Debug:
        return "debug";
    case ScBuild_Release:
        return "release";
    case ScBuild_Distribution:
        return "distribute";
    }

    return "debug";
}

static const char*
msk_cli_platform_name_from_system(ScOs os)
{
    switch (os)
    {
    case ScOs_Linux:
        return "linux";
    case ScOs_Windows:
        return "windows";
    }

    return "linux";
}

// DOCS: Full flag list (-h/--help).
static void
msk_cli_print_help(void)
{
    printf("masuka - build system of the Miracle engine\n");
    printf("\n");
    printf("Usage:\n");
    printf("  masuka [flags]\n");
    printf("\n");
    printf("Configuration:\n");
    printf("  -b <build>        build name from vince.masuka (default: system build)\n");
    printf("  -p <platform>     platform name from vince.masuka (default: system platform);\n");
    printf("                    -p windows generates .bat (clang.exe), -p linux - .sh (clang)\n");
    printf("  -d <directory>    working directory (default: current working directory)\n");
    printf("  -j <count>        parallel jobs, 0 < count <= %d (default: 1)\n", 2 * sc_system_cpu_count());
    printf("\n");
    printf("Actions:\n");
    printf("  -c                remove build artifacts of the selected configuration\n");
    printf("  -gb               write build scripts to disk (vince_build.sh / vince_build.bat\n");
    printf("                    in the root + build_<Project> in project directories);\n");
    printf("                    without -gb scripts are built in memory (temporary directory)\n");
    printf("  -rb               clean + generate + build\n");
    printf("  -rb <build>       short form: -rb release == -rb -b release\n");
    printf("  -gccj             generate compile_commands.json\n");
    printf("  -nc               do not compile\n");
    printf("  -r                run the entry project of the workspace\n");
    printf("  -nr               do not run the entry after the build (overrides -r/-e run)\n");
    printf("  -e <project>      run the given project\n");
    printf("  -a <arguments>    program arguments for the run (max %d bytes)\n", MSK_CLI_PROGRAM_ARGUMENTS_MAX_LENGTH - 1);
    printf("  -a{N} <arguments> same as -a with an explicitly declared length N\n");
    printf("  -t                run test projects of the workspace\n");
    printf("  -l                list all projects of the workspace with their types\n");
    printf("  -lc               print compile info of the entry (-e or vince.masuka entry):\n");
    printf("                    dependencies in compile order and sources to recompile;\n");
    printf("                    with -rb/-pt the build still happens after the info\n");
    printf("  -pt               profile test: per-file compile times and per-project\n");
    printf("                    build times in a dependency tree; also captures the build log\n");
    printf("                    and prints a success/warnings/errors summary\n");
    printf("\n");
    printf("Other:\n");
    printf("  -ll <0|1|2>       log level: 0 - errors only, 1 - also warnings,\n");
    printf("                    2 - also info (default: 2)\n");
    printf("  -v, --version     show Masuka version and exit\n");
    printf("  -h, --help        show this help and exit\n");
    printf("\n");
    printf("Exit codes: 0 - success, 1 - build/run failed, 2 - invalid configuration.\n");
}

// DOCS: Short hint printed after a configuration error (-h is always one flag away).
static void
msk_cli_print_usage_hint(void)
{
    printf("Run 'masuka -h' for usage.\n");
}

// DOCS: -v/--version: version of Masuka and the build this binary was compiled with.
static void
msk_cli_print_version(void)
{
    printf("masuka %s (%s build)\n", MSK_VERSION, MSK_VERSION_BUILD);
}

// DOCS: Index of a project in a resolved (sorted) project list.
static i32 msk_project_index_of(MskProject* aProjects, i32 projectsCount, char* pName);

// DOCS: Is the string a non-negative decimal number (used by -j/-ll/-a{N} validation)?
static i8 msk_cli_is_number(char* pValue);

// DOCS: -lc: compile info of the entry project (see the implementation above).
static i32 msk_cli_print_compile_info(MskProject* aProjects, i32 projectsCount, i32 entryIndex);

// DOCS: Timing of one measured unit: a source file (compile) or a project (build).
typedef struct
{
    char* pName;   // "project" for projects, source path for files
    i64 Milliseconds;
} MskPerfEntry;

typedef struct
{
    MskPerfEntry* aCompile;   // per-file compile times
    MskPerfEntry* aProject;   // per-project build times (compile + link/archive)
    MskPerfEntry* aLink;      // per-project link/archive times
    i32 WarningsCount;
    i32 ErrorsCount;
} MskPerfLog;

// DOCS: Build summary + optional -pt timings (see the perf section below).
static void msk_perf_report(MskProject* aProjects, i32 projectsCount, MskPerfLog* pLog, i8 isSuccess);
static void msk_perf_free(MskPerfLog* pLog);
static MskPerfLog msk_perf_parse_log(char* pLogPath);
// DOCS: -pt build: masuka runs every command itself, measured with sc_profiler.
static i32 msk_compiler_compile_measured(MskCompilerConfig cfg);
// DOCS: Windows parallel build: masuka runs the commands through a thread pool.
static i32 msk_compiler_compile_parallel(MskCompilerConfig cfg);

/* DOCS:
    Tree connectors of the -lc output (ASCII, portable across console code pages):
    |-- branch, `-- last branch, |   vertical continuation,     space continuation.
*/
#define MSK_CLI_TREE_BRANCH "|-- "
#define MSK_CLI_TREE_LAST "`-- "
#define MSK_CLI_TREE_VERTICAL "|   "
#define MSK_CLI_TREE_SPACE "    "

/* DOCS:
    A source will be recompiled when its object doesn't exist yet or the source
    is newer than the object: the same rule the generated scripts use (M4-5).
*/
static i8
msk_cli_source_needs_recompile(MskProject* pProject, char* pSource)
{
    char* pObject = msk_project_object_path(pProject, pSource);
    if (!pObject)
        return 1;

    i8 isNeeded = 1;

    if (sc_path(pObject) == ScPathItemType_File)
    {
        ScFileTime sourceTime = sc_file_get_time(pSource);
        ScFileTime objectTime = sc_file_get_time(pObject);
        isNeeded = sourceTime.LastModificationTime > objectTime.LastModificationTime;
    }

    sc_memory_free(pObject);
    return isNeeded;
}

/* DOCS:
    Print one project as a tree node of the -lc output:
    the node header (name + type), then its dependencies (recursively,
    dependencies compile first), then its sources as leaf nodes.
    isRoot controls the connector: the entry project is the tree root.
    pPrefix is the indentation inherited from the parent level.
*/
static void
msk_cli_print_project_tree(MskProject* aProjects, i32 projectsCount, i32 index, i8* aPrinted, char* pPrefix, i8 isLast, i8 isRoot)
{
    MskProject* pProject = &aProjects[index];

    if (isRoot)
        printf("%s (%s)\n", pProject->pName, msk_project_type_to_string(pProject->Type));
    else
        printf("%s%s%s (%s)\n", pPrefix, isLast ? MSK_CLI_TREE_LAST : MSK_CLI_TREE_BRANCH, pProject->pName, msk_project_type_to_string(pProject->Type));

    /* DOCS:
        A dependency already expanded higher in the tree is only named, not
        repeated (the graph resolver rejects cycles, so the tree is finite).
    */
    if (aPrinted[index])
    {
        printf("%s%s(see above)\n", pPrefix, isRoot ? "" : (isLast ? MSK_CLI_TREE_SPACE : MSK_CLI_TREE_VERTICAL));
        return;
    }

    aPrinted[index] = 1;

    /* DOCS:
        Children are indented one level deeper than this node.
        UTF-8 connectors are byte-concatenated: sc_format %s counts characters
        (sc_utf8_length) but copies that many bytes, breaking multibyte '|'.
    */
    char* pChildPrefixSb = NULL;
    sc_builder_append_string(pChildPrefixSb, pPrefix, sc_string_get_length(pPrefix));
    {
        char* pConnector = isRoot ? "" : (isLast ? MSK_CLI_TREE_SPACE : MSK_CLI_TREE_VERTICAL);
        sc_builder_append_string(pChildPrefixSb, pConnector, sc_string_get_length(pConnector));
    }
    char aChildPrefix[256] = {};
    if (pChildPrefixSb && sc_builder_count(pChildPrefixSb) > 0)
        memcpy(aChildPrefix, pChildPrefixSb, sc_builder_count(pChildPrefixSb));
    sc_list_free(pChildPrefixSb);

    /* DOCS:
        Count only the children that are actually printed (dependencies that
        resolve + non-NULL sources): the last one gets the └── connector.
    */
    i64 childrenCount = 0;

    for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
    {
        char* pDependency = pProject->aDependencies[d].pName;
        if (!pDependency)
            continue;

        if (msk_project_index_of(aProjects, projectsCount, pDependency) < 0)
            continue;

        ++childrenCount;
    }

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        if (pProject->aSources[s].pName)
            ++childrenCount;
    }

    i64 childIndex = 0;

    // DOCS: Dependencies come first: this is the compile order of the tree.
    for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
    {
        char* pDependency = pProject->aDependencies[d].pName;
        if (!pDependency)
            continue;

        i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, pDependency);
        if (dependencyIndex < 0)
            continue;

        ++childIndex;
        msk_cli_print_project_tree(aProjects, projectsCount, dependencyIndex, aPrinted, aChildPrefix, childIndex == childrenCount, 0);
    }

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        char* pSource = pProject->aSources[s].pName;
        if (!pSource)
            continue;

        ++childIndex;
        printf("%s%s", aChildPrefix, childIndex == childrenCount ? MSK_CLI_TREE_LAST : MSK_CLI_TREE_BRANCH);

        if (msk_cli_source_needs_recompile(pProject, pSource))
            printf("%s%s\033[0m\n", sc_log_level_to_color(ScLogLevel_Error), pSource);
        else
            printf("%s\n", pSource);
    }
}

/* DOCS:
    -lc: compile info of the entry project (-e or vince.masuka entry):
    a dependency tree in compile order; sources that will be recompiled
    (object missing or source newer) are printed in red (sc_log_level_to_color).
*/
static i32
msk_cli_print_compile_info(MskProject* aProjects, i32 projectsCount, i32 entryIndex)
{
    if (!aProjects || entryIndex < 0 || entryIndex >= projectsCount)
    {
        sc_log_erro("-lc: no entry project: pass -e <project> or set entry in vince.masuka\n");
        return 1;
    }

    i8* aPrinted = sc_memory_allocate(projectsCount);
    memset(aPrinted, 0, projectsCount);

    printf("Compile order (dependencies first):\n");
    msk_cli_print_project_tree(aProjects, projectsCount, entryIndex, aPrinted, "", 1, 1);

    sc_memory_free(aPrinted);

    return 0;
}

i32
msk_cli_start(i32 argumentsCount, char** aArguments)
{
    MskCliConfig cliConfig = msk_cli_parse_args(argumentsCount, aArguments);

    // DOCS: -h/--help prints usage and exits without touching the workspace.
    if (cliConfig.IsHelp)
    {
        msk_cli_print_help();
        return 0;
    }

    // DOCS: -v/--version prints the version and the build of this masuka binary.
    if (cliConfig.IsVersion)
    {
        msk_cli_print_version();
        return 0;
    }

    /* DOCS:
        -ll 0/1/2 sets the sc_log level: 0 - errors only, 1 - also warnings,
        2 - also info (default). Raw value is parsed here so the very first
        "Parsing cli config" line already respects the level; a wrong value
        is reported by msk_cli_validate_args (with the default level on).
    */
    if (cliConfig.IsLogLevelExplicit && cliConfig.pLogLevel
        && msk_cli_is_number(cliConfig.pLogLevel))
    {
        i64 level = sc_parse_int(cliConfig.pLogLevel, sc_string_get_length(cliConfig.pLogLevel));

        if (level >= 0 && level <= 2)
        {
            // DOCS: 0 -> Error only, 1 -> also Warn, 2 -> everything.
            ScLogLevel minLevel = ScLogLevel_Count;
            switch (level)
            {
            case 0: minLevel = ScLogLevel_Error; break;
            case 1: minLevel = ScLogLevel_Warn; break;
            case 2: minLevel = ScLogLevel_Info; break;
            }

            sc_log_set_level(minLevel);
        }
    }

    ScLogBackend terminalBack = sc_log_get_terminal_backend();
    ScLogBackend* aBacks = NULL;
    sc_list_add(aBacks, terminalBack);
    ScLogConfig scLogCfg = {
        .BackendsCount = 1,
        .aBackends = aBacks
    };
    sc_log_init(scLogCfg);

    sc_log_info("Parsing cli config\n");

    // DOCS: If -b/-p/-j/-d are not passed, take values from the system.
    msk_cli_apply_system_defaults(&cliConfig, argumentsCount > 0 ? aArguments[0] : NULL);

    // DOCS: Early validation of flags that don't depend on vince.masuka (-d, -j, -a).
    if (msk_cli_validate_args(&cliConfig, NULL, NULL, 0) != ScResult_Success)
    {
        sc_log_erro("Cli config is not valid. See errors above.\n");
        msk_cli_print_usage_hint();
        return 2;
    }

    /* DOCS:
        -d (or the current working directory by default) is a working directory.
        All relative project paths (bin, objdir, source, include) are resolved from it.
    */
    if (cliConfig.pDirectory)
    {
        sc_log_info("Working directory: %s\n", cliConfig.pDirectory);

        if (sc_directory_set_current(cliConfig.pDirectory) != ScResult_Success)
        {
            sc_log_erro("Can't change working directory to '%s'\n", cliConfig.pDirectory);
            return 2;
        }

        cliConfig.IsDirectoryApplied = 1;
        cliConfig.pDirectory = NULL;
    }

    // DOCS: read vince.masuka file
    char* pRootDirectory = cliConfig.pDirectory;
    char* pPath = NULL;
    i8 isPathAllocated = 0;
    if (pRootDirectory == NULL)
    {
        pPath = "vince.masuka";
        pRootDirectory = ".";
    }
    else
    {
        pPath = sc_path_combine(pRootDirectory, "vince.masuka");
        isPathAllocated = 1;
    }

    i64 fileLength = 0;
    char* pFileContent = sc_file_read_ext(pPath, &fileLength);
    if (isPathAllocated)
        sc_memory_free(pPath);

    if (!pFileContent)
    {
        sc_log_erro("No vince.masuka file existed!\n");
        return 2;
    }

    sc_log_info("Parsing MskVince\n");
    MskVince mskVince = msk_language_vince_new(pFileContent);

    // DOCS: Validate vince.masuka with precise messages (builds/platforms/names).
    if (msk_language_vince_validate(mskVince) != ScResult_Success)
    {
        sc_log_erro("vince.masuka is not valid. See errors above.\n");
        return 2;
    }

    // DOCS: Get all masuka files recursively
    ScDirectoryGetConfig cfg = {
        .IsAbsolutePath = cliConfig.pDirectory != NULL,
        .Type = ScDirectoryItemType_Directory
    };
    ScDirectoryItem* aItems = sc_directory_get_items(pRootDirectory, cfg);
    char** aMskDirectories = NULL;
    i64 itemsCount = sc_list_count(aItems);
    for (i64 i = 0; i < itemsCount; ++i)
    {
        ScDirectoryItem item = aItems[i];
        if (item.Type == ScDirectoryItemType_Directory)
        {
            char** aFiles = msk_get_all_files_from_directory(item.pPath, "*.masuka");
            if (aFiles != NULL)
            {
                logf("Path: %s\n", item.pPath);
                sc_list_for_each(aFiles, pFile)
                {
                    logf("- File: %s\n", *pFile);
                    sc_list_add(aMskDirectories, *pFile);
                }

                sc_list_free(aFiles);
            }
        }
    }
    sc_list_free(aItems);

    /* DOCS:
        *.masuka files in the workspace root are projects too (M1-10).
        Files without a 'project' block (vince.masuka, stray files) are skipped below.
    */
    ScDirectoryGetConfig rootCfg = {
        .IsAbsolutePath = 0,
        .Type = ScDirectoryItemType_File
    };
    ScDirectoryItem* aRootItems = sc_directory_get_items(pRootDirectory, rootCfg);
    for (i32 i = 0; i < sc_list_count(aRootItems); ++i)
    {
        if (!msk_file_regex_match(aRootItems[i].pPath, "*.masuka"))
            continue;

        char* pRootFile = sc_path_combine(pRootDirectory, aRootItems[i].pPath);
        sc_list_add(aMskDirectories, pRootFile);
    }
    sc_list_free(aRootItems);

    sc_log_info("Parsing other masuka files..\n");
    MskFile* aMskFiles = NULL;
    for (i32 m = 0; m < sc_list_count(aMskDirectories); ++m)
    {
        char* pMskFile = aMskDirectories[m];

        MskFile mskFile = msk_language_file_new(&mskVince, pMskFile);

        // DOCS: A *.masuka without a 'project' block is not a project.
        if (!mskFile.pProjectName)
        {
            sc_log_warn("%s: no 'project' declaration, skipped\n", pMskFile);
            continue;
        }

        sc_list_add(aMskFiles, mskFile);
    }

    // DOCS: Validate required fields of every project (M1-7).
    for (i32 f = 0; f < sc_list_count(aMskFiles); ++f)
    {
        if (msk_language_file_validate(aMskFiles[f]) != ScResult_Success)
        {
            sc_log_erro("Project file is not valid. See errors above.\n");
            return 2;
        }
    }

    // DOCS: Validate cli config. All projects are already parsed, so -e can be checked.
    sc_log_info("Validate cli config..\n");
    if (msk_cli_validate_args(&cliConfig, &mskVince, aMskFiles, (i32)sc_list_count(aMskFiles)) != ScResult_Success)
    {
        sc_log_erro("Cli config is not valid. See errors above.\n");
        msk_cli_print_usage_hint();
        return 2;
    }

    // DOCS: {build} and {platform} must contain selected values, not system ones.
    msk_language_vince_set_selection(&mskVince, cliConfig.pBuild, cliConfig.pPlatform);

    sc_log_info("Config: build=%s platform=%s dir=%s jobs=%d\n",
        cliConfig.pBuild,
        cliConfig.pPlatform,
        pRootDirectory ? pRootDirectory : ".",
        cliConfig.JobsCount);

    // DOCS: Preprocess strings with variables
    sc_log_info("Preprocess..\n");
    for (i32 f = 0; f < sc_list_count(aMskFiles); ++f)
    {
        aMskFiles[f] = msk_preprocessor_file(&mskVince, aMskFiles[f]);
    }

    // DOCS: Merge the selected platform block (linux:/windows:) into each project.
    for (i32 f = 0; f < sc_list_count(aMskFiles); ++f)
    {
        msk_file_apply_platform(&aMskFiles[f], cliConfig.pPlatform);
    }

    /* DOCS:
        Resolve projects: expand globs, resolve provide-include paths and add
        -D build/platform (M1-6); then validate the graph and sort by dependencies (M1-8).
    */
    sc_log_info("Resolve projects..\n");
    MskProject* aProjects = msk_projects_from_files(aMskFiles, (i32)sc_list_count(aMskFiles), mskVince, cliConfig.pBuild, cliConfig.pPlatform);
    i32 projectsCount = (i32)sc_list_count(aProjects);

    /* DOCS:
        EntryIndex points into the file list, but msk_projects_resolve sorts projects
        by dependencies. Remember the entry name and resolve its index again after sorting.
    */
    char* pEntryProjectName = NULL;
    if (cliConfig.EntryIndex >= 0 && cliConfig.EntryIndex < projectsCount)
        pEntryProjectName = aProjects[cliConfig.EntryIndex].pName;

    if (msk_projects_resolve(aProjects, projectsCount) != ScResult_Success)
    {
        sc_log_erro("Projects are not valid. See errors above.\n");
        return 2;
    }

    // DOCS: The project order changed: -e / vince.masuka entry must point at the same project.
    if (pEntryProjectName)
        cliConfig.EntryIndex = (i16)msk_project_index_of(aProjects, projectsCount, pEntryProjectName);

    sc_log_info("Build order:\n");
    for (i32 p = 0; p < projectsCount; ++p)
        sc_log_info("  %s (%s)\n", aProjects[p].pName, msk_project_type_to_string(aProjects[p].Type));

    // DOCS: -l: print all projects of the workspace with their types.
    if (cliConfig.IsList)
    {
        printf("Total masuka projects in workspace - %d.\n", projectsCount);
        for (i32 p = 0; p < projectsCount; ++p)
            printf("  %s - %s\n", aProjects[p].pName, msk_project_type_to_string(aProjects[p].Type));
    }

    /* DOCS:
        -lc: compile info of the entry project (-e or vince.masuka entry):
        dependencies in compile order + sources that will be recompiled.
    */
    if (cliConfig.IsListCompile)
    {
        msk_cli_print_compile_info(aProjects, projectsCount, cliConfig.EntryIndex);
    }

    i32 result = 0;

    // DOCS: -c / -rb: clean build artifacts of selected build/platform.
    if (cliConfig.IsClean)
    {
        sc_log_info("Clean build artifacts..\n");
        msk_compiler_clean(aProjects, projectsCount, pRootDirectory);
    }

    // DOCS: Absolute workspace directory: generated scripts and json don't depend on cwd.
    char* pAbsoluteRoot = sc_directory_get_current();
    // DOCS: Script kind follows the selected platform (M6-4): -p windows => .bat.
    MskScriptKind scriptKind = msk_script_kind_from_platform(cliConfig.pPlatform);

    // DOCS: -gccj: generate compile_commands.json (M3-5).
    if (cliConfig.IsGenerateCompileCmdsJson)
    {
        sc_log_info("Generate compile_commands.json file..\n");
        MskGeneratorJsonConfig jsonCfg = {
            .aProjects = aProjects,
            .ProjectsCount = projectsCount,
            .pRootDirectory = pAbsoluteRoot,
        };

        if (msk_generator_json_create(jsonCfg) != 0)
        {
            sc_log_erro("Can't generate compile_commands.json file!\n");
            result = 1;
        }
    }

    /* DOCS:
        -gb / -rb: write build scripts to disk (M3-1..M3-3): per-project
        build_<Project>.sh|.bat in project directories (next to *.masuka) and
        the main vince_build.sh|.bat in the workspace root. Without -gb nothing
        is written: the compiler generates scripts into a temporary directory (M4-1).
    */
    if (cliConfig.IsGenerateBuildFiles)
    {
        sc_log_info("Generate build files..\n");

        MskGeneratorBuildConfig buildCfg = {
            .aProjects = aProjects,
            .ProjectsCount = projectsCount,
            .JobsCount = cliConfig.JobsCount,
            .Kind = scriptKind,
            .pRootDirectory = pAbsoluteRoot,
            .pBuild = cliConfig.pBuild,
            .pPlatform = cliConfig.pPlatform,
            };

        MskGeneratorBuildResult mskBuildResult = msk_generator_build_create(buildCfg);

        if (msk_generator_build_write(&mskBuildResult, pRootDirectory) != 0)
        {
            sc_log_erro("Can't generate build file!\n");
            result = 1;
        }

        sc_list_for_each(mskBuildResult.aResults, pSingleResult)
        {
            sc_list_free(pSingleResult->pSb);
            sc_memory_free(pSingleResult->pScriptPath);
        }
        sc_list_free(mskBuildResult.aResults);
        sc_list_free(mskBuildResult.pSb);
    }

    // DOCS: Build (compile and link) by running generated scripts (M4-1).
    if (cliConfig.IsCompile)
    {
        sc_log_info("Building projects..\n");
        i32 compileResult = 0;

        // DOCS: Wall time of the whole build (compile + link), printed in the summary.
        ScProfiler buildProfiler = {};
        sc_profiler_start(&buildProfiler);

        if (cliConfig.IsPerfTest)
        {
            /* DOCS:
                -pt: masuka runs every command itself and measures each one
                with sc_profiler (no generated scripts, no parallel jobs).
            */
            MskCompilerConfig compileCfg = {
                .aProjects = aProjects,
                .ProjectsCount = projectsCount,
                .JobsCount = cliConfig.JobsCount,
                .Kind = scriptKind,
                .pRootDirectory = pAbsoluteRoot,
                .pBuild = cliConfig.pBuild,
                .pPlatform = cliConfig.pPlatform,
            };

            compileResult = msk_compiler_compile_measured(compileCfg);
        }
        else if (cliConfig.IsGenerateBuildFiles)
        {
            // DOCS: Scripts are already on disk: run the generated main script.
            MskCompilerScriptsConfig scriptsCfg = {
                .Kind = scriptKind,
                .pRootDirectory = pAbsoluteRoot,
                .aProjects = aProjects,
                .ProjectsCount = projectsCount,
            };

            compileResult = msk_compiler_compile_from_scripts(scriptsCfg);
        }
        else if (scriptKind == MskScriptKind_Batch && cliConfig.JobsCount > 1)
        {
            /* DOCS:
                Windows + -j: cmd.exe has no background jobs, so masuka runs the
                commands itself through a thread pool (sc_thread/sc_mutex).
            */
            MskCompilerConfig compileCfg = {
                .aProjects = aProjects,
                .ProjectsCount = projectsCount,
                .JobsCount = cliConfig.JobsCount,
                .Kind = scriptKind,
                .pRootDirectory = pAbsoluteRoot,
                .pBuild = cliConfig.pBuild,
                .pPlatform = cliConfig.pPlatform,
            };

            compileResult = msk_compiler_compile_parallel(compileCfg);
        }
        else
        {
            // DOCS: Build from memory: temporary scripts in bin/.masuka-tmp, executed
            // and removed, so nothing appears next to the sources.
            MskCompilerConfig compileCfg = {
                .aProjects = aProjects,
                .ProjectsCount = projectsCount,
                .JobsCount = cliConfig.JobsCount,
                .Kind = scriptKind,
                .pRootDirectory = pAbsoluteRoot,
                .pBuild = cliConfig.pBuild,
                .pPlatform = cliConfig.pPlatform,
            };

            compileResult = msk_compiler_compile(compileCfg);
        }

        if (compileResult != 0)
        {
            sc_log_erro("Build failed!\n");
            result = 1;
        }

        sc_profiler_end(&buildProfiler);
        // DOCS: Presentation output (not a log): printf, like the build summary.
        printf("Build time: %d ms\n", (i32)sc_profiler_get_milliseconds(&buildProfiler));
    }

    /* DOCS:
        -r / -e: run selected entry point (M5-1).
        EntryIndex is resolved by msk_cli_validate_args (-e > vince.masuka entry).
        -nr disables the run: build only (useful when -e is only an entry selector).
    */
    if (cliConfig.IsExecute && !cliConfig.IsNoRun)
    {
        sc_log_info("Executing program.\n");

        if (cliConfig.EntryIndex < 0 || cliConfig.EntryIndex >= projectsCount)
        {
            sc_log_erro("No entry point to run: pass -e <project> or set entry in vince.masuka\n");
            result = 1;
        }
        else
        {
            // DOCS: -a words are parsed once (M5-2) and quoted per word.
            char** aProgramArguments = msk_cli_parse_program_arguments(
                cliConfig.pProgramArguments,
                cliConfig.ProgramArgumentsLength > 0 ? cliConfig.ProgramArgumentsLength : sc_string_get_length(cliConfig.pProgramArguments));

            MskRunnerConfig runnerCfg = {
                .pProject = &aProjects[cliConfig.EntryIndex],
                .pRootDirectory = pAbsoluteRoot,
                .aProgramArguments = aProgramArguments,
                .Kind = scriptKind,
            };

            if (msk_runner_run_program(runnerCfg) != 0)
            {
                sc_log_erro("Run failed!\n");
                result = 1;
            }

            // DOCS: Words are copied into the command: the list can be released.
            sc_list_for_each(aProgramArguments, ppWord)
                sc_memory_free(*ppWord);
            sc_list_free(aProgramArguments);
        }
    }

    // DOCS: -t: run tests (M5-3): every Executable project of the workspace.
    if (cliConfig.IsRunTests)
    {
        sc_log_info("Run tests.\n");

        MskTestRunnerConfig testsCfg = {
            .aProjects = aProjects,
            .ProjectsCount = projectsCount,
            .pRootDirectory = pAbsoluteRoot,
            .Kind = scriptKind,
        };

        if (msk_runner_run_tests(testsCfg) != 0)
        {
            sc_log_erro("Tests failed!\n");
            result = 1;
        }
    }

    sc_memory_free(pAbsoluteRoot);

    return result;
}

MskCliConfig
msk_cli_parse_args(i32 argumentsCount, char** aArguments)
{
    MskCliConfig cfg = {
        .JobsCount = 1,
        .LogLevel = 2,
        .BuildIndex = -1,
        .PlatformIndex = -1,
        .EntryIndex = -1,
    };

    if (argumentsCount <= 0 || aArguments == NULL)
        return cfg;

    // DOCS: argv[0] is the executable path.
    cfg.pExePath = aArguments[0];

    i8 isNoCompile = 0;

    for (i32 a = 1; a < argumentsCount; ++a)
    {
        char* pArg = aArguments[a];

        if (!pArg || pArg[0] != '-' || pArg[1] == '\0')
            continue;

        cfg.IsSetup = 1;

        if (sc_string_compare(pArg, "-b"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pBuild = aArguments[++a];
            cfg.IsBuildExplicit = 1;
        }
        else if (sc_string_compare(pArg, "-c"))
        {
            cfg.IsClean = 1;
        }
        else if (sc_string_compare(pArg, "-gb"))
        {
            cfg.IsGenerateBuildFiles = 1;
        }
        else if (sc_string_compare(pArg, "-rb"))
        {
            cfg.IsRebuild = 1;

            /* DOCS:
                Short form: a bare word right after -rb is the build name
                (-rb release == -rb -b release). Only when -b was not passed
                explicitly and the next argument is not a flag itself.
            */
            if (a + 1 < argumentsCount && !cfg.IsBuildExplicit)
            {
                char* pNext = aArguments[a + 1];

                if (pNext && pNext[0] != '-' && pNext[0] != '\0')
                {
                    cfg.pBuild = aArguments[++a];
                    cfg.IsBuildExplicit = 1;
                }
            }
        }
        else if (sc_string_compare(pArg, "-gccj"))
        {
            cfg.IsGenerateCompileCmdsJson = 1;
        }
        else if (sc_string_compare(pArg, "-d"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pDirectory = aArguments[++a];
            cfg.IsDirectoryExplicit = 1;
        }
        else if (sc_string_compare(pArg, "-p"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pPlatform = aArguments[++a];
            cfg.IsPlatformExplicit = 1;
        }
        else if (sc_string_compare(pArg, "-j"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pJobs = aArguments[++a];
            cfg.IsJobsExplicit = 1;
        }
        else if (sc_string_compare(pArg, "-nc"))
        {
            isNoCompile = 1;
        }
        else if (sc_string_compare(pArg, "-r"))
        {
            cfg.IsExecute = 1;
        }
        else if (sc_string_compare(pArg, "-nr"))
        {
            cfg.IsNoRun = 1;
        }
        else if (sc_string_compare(pArg, "-ll") || sc_string_compare(pArg, "--log-level"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pLogLevel = aArguments[++a];
            cfg.IsLogLevelExplicit = 1;
        }
        else if (sc_string_compare(pArg, "-e"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pEntryName = aArguments[++a];
            cfg.IsEntryExplicit = 1;
            // DOCS: -e "test" runs the test project (see the task spec).
            cfg.IsExecute = 1;
        }
        else if (sc_string_compare(pArg, "-t"))
        {
            cfg.IsRunTests = 1;
        }
        else if (sc_string_compare(pArg, "-h") || sc_string_compare(pArg, "--help"))
        {
            cfg.IsHelp = 1;
        }
        else if (sc_string_compare(pArg, "-v") || sc_string_compare(pArg, "--version"))
        {
            cfg.IsVersion = 1;
        }
        else if (sc_string_compare(pArg, "-l"))
        {
            cfg.IsList = 1;
        }
        else if (sc_string_compare(pArg, "-lc"))
        {
            cfg.IsListCompile = 1;
        }
        else if (sc_string_compare(pArg, "-pt") || sc_string_compare(pArg, "--perf-test"))
        {
            cfg.IsPerfTest = 1;
        }
        else if (sc_string_compare(pArg, "-a"))
        {
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pProgramArguments = aArguments[++a];
            cfg.IsArgumentsExplicit = 1;
        }
        else if (pArg[1] == 'a' && pArg[2] != '\0')
        {
            // DOCS: -a{number}: arguments string with explicitly declared length.
            if (a + 1 >= argumentsCount)
            {
                cfg.pMissingValueFlag = pArg;
                continue;
            }

            cfg.pArgumentsLength = pArg + 2;
            cfg.pProgramArguments = aArguments[++a];
            cfg.IsArgumentsExplicit = 1;
            cfg.IsArgumentsLengthExplicit = 1;
        }
        else if (!cfg.pUnknownArgument)
        {
            cfg.pUnknownArgument = pArg;
        }
    }

    // DOCS: -rb means clean + generate + build.
    if (cfg.IsRebuild)
    {
        cfg.IsClean = 1;
        cfg.IsGenerateBuildFiles = 1;
    }

    /* DOCS:
        The project is always compiled (M2-2): every run of masuka builds.
        -nc is the only way to disable the compilation.
    */
    cfg.IsCompile = 1;

    if (isNoCompile)
        cfg.IsCompile = 0;

    // DOCS: -l / -lc are info commands: they only print, nothing is built.
    /* DOCS:
        -l / -lc are info commands: they only print, nothing is built.
        Exception: -rb (clean + generate + build) and -pt (profile the build)
        are explicit build commands - with them -lc prints its tree and the
        build still happens (so the summary, timings and sizes are printed).
    */
    if ((cfg.IsList || cfg.IsListCompile) && !cfg.IsRebuild && !cfg.IsPerfTest)
    {
        cfg.IsCompile = 0;
        // DOCS: With -lc the -e flag only selects the entry project: no execution.
        cfg.IsExecute = 0;
    }

    return cfg;
}

void
msk_cli_apply_system_defaults(MskCliConfig* pConfig, char* pExePath)
{
    if (!pConfig)
        return;

    ScSystemInfo sysInfo = sc_system_info_get();

    if (!pConfig->pExePath)
        pConfig->pExePath = pExePath;

    if (!pConfig->pBuild)
        pConfig->pBuild = (char*)msk_cli_build_name_from_system(sysInfo.Build);

    if (!pConfig->pPlatform)
        pConfig->pPlatform = (char*)msk_cli_platform_name_from_system(sysInfo.Os);

    if (!pConfig->pJobs)
        pConfig->JobsCount = 1;

    /* DOCS:
        The workspace is the directory the executable was started from; -d overrides it.
        Never derive it from the executable location: bin/... is not a workspace.
    */
    (void)pExePath;
    if (!pConfig->pDirectory)
        pConfig->pDirectory = ".";
}

static i8
msk_cli_is_number(char* pValue)
{
    if (!pValue || pValue[0] == '\0')
        return 0;

    for (char* pC = pValue; *pC != '\0'; ++pC)
    {
        if (!sc_char_is_integer(*pC))
            return 0;
    }

    return 1;
}

// DOCS: Resolve project index by name (-e or vince.masuka entry).
static i32
msk_cli_find_project_index(MskFile* aFiles, i32 filesCount, char* pProjectName)
{
    for (i32 f = 0; f < filesCount; ++f)
    {
        if (!aFiles[f].pProjectName)
            continue;

        if (sc_string_compare(aFiles[f].pProjectName, pProjectName))
            return f;
    }

    return -1;
}

static void
msk_cli_validate_jobs(MskCliConfig* pConfig, ScResult* pResult)
{
    if (!pConfig->IsJobsExplicit)
        return;

    i32 maxJobs = 2 * sc_system_cpu_count();

    if (!msk_cli_is_number(pConfig->pJobs))
    {
        sc_log_erro("-j: '%s' is not a number\n", pConfig->pJobs ? pConfig->pJobs : "");
        *pResult = ScResult_Error;
        return;
    }

    i64 jobs = sc_parse_int(pConfig->pJobs, sc_string_get_length(pConfig->pJobs));

    if (jobs <= 0 || jobs > maxJobs)
    {
        // note: sc_log formatter doesn't support %lld, use %d.
        sc_log_erro("-j: %d is outside of range (0, %d]\n", (i32)jobs, maxJobs);
        *pResult = ScResult_Error;
        return;
    }

    pConfig->JobsCount = (i16)jobs;
}

static void
msk_cli_validate_log_level(MskCliConfig* pConfig, ScResult* pResult)
{
    if (!pConfig->IsLogLevelExplicit)
        return;

    if (!msk_cli_is_number(pConfig->pLogLevel))
    {
        sc_log_erro("-ll: '%s' is not a number\n", pConfig->pLogLevel ? pConfig->pLogLevel : "");
        *pResult = ScResult_Error;
        return;
    }

    i64 level = sc_parse_int(pConfig->pLogLevel, sc_string_get_length(pConfig->pLogLevel));

    if (level < 0 || level > 2)
    {
        sc_log_erro("-ll: %d is outside of range [0, 2]\n", (i32)level);
        *pResult = ScResult_Error;
        return;
    }

    pConfig->LogLevel = (i16)level;
}

static void
msk_cli_validate_build(MskCliConfig* pConfig, MskVince* pVince, ScResult* pResult)
{
    // DOCS: vince.masuka is not parsed yet (early validation).
    if (!pVince)
        return;

    if (sc_list_count(pVince->aBuilds) <= 0)
    {
        sc_log_erro("vince.masuka doesn't contain any build\n");
        *pResult = ScResult_Error;
        return;
    }

    if (!pConfig->pBuild)
    {
        pConfig->BuildIndex = 0;
        pConfig->pBuild = pVince->aBuilds[0].pName;
        return;
    }

    i64 buildIndex = sc_list_index_of(pVince->aBuilds, sc_string_compare(item.pName, pConfig->pBuild));

    if (buildIndex == -1)
    {
        if (pConfig->IsBuildExplicit)
        {
            sc_log_erro("-b: build '%s' not found in vince.masuka\n", pConfig->pBuild);
            *pResult = ScResult_Error;
            return;
        }

        sc_log_warn("Build '%s' not found in vince.masuka, using '%s'\n", pConfig->pBuild, pVince->aBuilds[0].pName);
        buildIndex = 0;
    }

    pConfig->BuildIndex = (i16)buildIndex;
    pConfig->pBuild = pVince->aBuilds[buildIndex].pName;
}

static void
msk_cli_validate_platform(MskCliConfig* pConfig, MskVince* pVince, ScResult* pResult)
{
    // DOCS: vince.masuka is not parsed yet (early validation).
    if (!pVince)
        return;

    if (sc_list_count(pVince->aPlatforms) <= 0)
    {
        sc_log_erro("vince.masuka doesn't contain any platform\n");
        *pResult = ScResult_Error;
        return;
    }

    if (!pConfig->pPlatform)
    {
        pConfig->PlatformIndex = 0;
        pConfig->pPlatform = pVince->aPlatforms[0].pName;
        return;
    }

    i64 platformIndex = sc_list_index_of(pVince->aPlatforms, sc_string_compare(item.pName, pConfig->pPlatform));

    if (platformIndex == -1)
    {
        if (pConfig->IsPlatformExplicit)
        {
            sc_log_erro("-p: platform '%s' not found in vince.masuka\n", pConfig->pPlatform);
            *pResult = ScResult_Error;
            return;
        }

        sc_log_warn("Platform '%s' not found in vince.masuka, using '%s'\n", pConfig->pPlatform, pVince->aPlatforms[0].pName);
        platformIndex = 0;
    }

    pConfig->PlatformIndex = (i16)platformIndex;
    pConfig->pPlatform = pVince->aPlatforms[platformIndex].pName;
}

static void
msk_cli_validate_entry(MskCliConfig* pConfig, MskVince* pVince, MskFile* aFiles, i32 filesCount, ScResult* pResult)
{
    // DOCS: Projects are not parsed yet (early validation).
    if (!aFiles)
        return;

    if (pConfig->IsEntryExplicit)
    {
        i32 entryIndex = msk_cli_find_project_index(aFiles, filesCount, pConfig->pEntryName);

        if (entryIndex == -1)
        {
            sc_log_erro("-e: project '%s' not found\n", pConfig->pEntryName);
            *pResult = ScResult_Error;
            return;
        }

        pConfig->EntryIndex = (i16)entryIndex;
        return;
    }

    if (pVince && pVince->pEntryName)
    {
        i32 entryIndex = msk_cli_find_project_index(aFiles, filesCount, pVince->pEntryName);

        if (entryIndex == -1)
        {
            sc_log_warn("vince.masuka entry '%s' not found in projects\n", pVince->pEntryName);
            return;
        }

        pConfig->EntryIndex = (i16)entryIndex;
    }
}

static void
msk_cli_validate_arguments(MskCliConfig* pConfig, ScResult* pResult)
{
    if (!pConfig->IsArgumentsExplicit)
        return;

    if (!pConfig->pProgramArguments)
    {
        sc_log_erro("-a: no arguments string\n");
        *pResult = ScResult_Error;
        return;
    }

    i64 actualLength = sc_string_get_length(pConfig->pProgramArguments);

    if (actualLength >= MSK_CLI_PROGRAM_ARGUMENTS_MAX_LENGTH)
    {
        sc_log_erro("-a: arguments string length is %d, max is %d\n", (i32)actualLength, MSK_CLI_PROGRAM_ARGUMENTS_MAX_LENGTH - 1);
        *pResult = ScResult_Error;
        return;
    }

    if (!pConfig->IsArgumentsLengthExplicit)
    {
        pConfig->ProgramArgumentsLength = actualLength;
        return;
    }

    if (!msk_cli_is_number(pConfig->pArgumentsLength))
    {
        sc_log_erro("-a{N}: '%s' is not a number\n", pConfig->pArgumentsLength ? pConfig->pArgumentsLength : "");
        *pResult = ScResult_Error;
        return;
    }

    i64 declaredLength = sc_parse_int(pConfig->pArgumentsLength, sc_string_get_length(pConfig->pArgumentsLength));

    if (declaredLength <= 0)
    {
        sc_log_erro("-a{N}: length must be greater than 0\n");
        *pResult = ScResult_Error;
        return;
    }

    if (declaredLength >= MSK_CLI_PROGRAM_ARGUMENTS_MAX_LENGTH)
    {
        sc_log_erro("-a{N}: length %d is greater than max %d\n", (i32)declaredLength, MSK_CLI_PROGRAM_ARGUMENTS_MAX_LENGTH - 1);
        *pResult = ScResult_Error;
        return;
    }

    if (declaredLength > actualLength)
    {
        sc_log_warn("-a{N}: declared length %d is greater than actual %d, using actual\n", (i32)declaredLength, (i32)actualLength);
        declaredLength = actualLength;
    }

    pConfig->ProgramArgumentsLength = declaredLength;
}

ScResult
msk_cli_validate_args(MskCliConfig* pConfig, MskVince* pVince, MskFile* aFiles, i32 filesCount)
{
    if (!pConfig)
        return ScResult_Error;

    ScResult result = ScResult_Success;

    if (pConfig->pUnknownArgument)
    {
        sc_log_erro("Unknown cli argument '%s'\n", pConfig->pUnknownArgument);
        result = ScResult_Error;
    }

    if (pConfig->pMissingValueFlag)
    {
        sc_log_erro("No value after flag '%s'\n", pConfig->pMissingValueFlag);
        result = ScResult_Error;
    }

    // DOCS: -d must be an existing directory (skip after working directory is applied).
    if (pConfig->IsDirectoryExplicit && !pConfig->IsDirectoryApplied)
    {
        if (!pConfig->pDirectory || sc_path(pConfig->pDirectory) != ScPathItemType_Directory)
        {
            sc_log_erro("-d: '%s' is not an existing directory\n", pConfig->pDirectory ? pConfig->pDirectory : "");
            result = ScResult_Error;
        }
    }

    msk_cli_validate_jobs(pConfig, &result);
    msk_cli_validate_log_level(pConfig, &result);
    msk_cli_validate_build(pConfig, pVince, &result);
    msk_cli_validate_platform(pConfig, pVince, &result);
    msk_cli_validate_entry(pConfig, pVince, aFiles, filesCount, &result);
    msk_cli_validate_arguments(pConfig, &result);

    // DOCS: Run requires a resolved entry point (checked after projects are parsed).
    if (aFiles && pConfig->IsExecute && !pConfig->IsEntryExplicit && pConfig->EntryIndex < 0)
    {
        sc_log_erro("No entry point to run: pass -e <project> or set entry in vince.masuka\n");
        result = ScResult_Error;
    }

    return result;
}

/*
   DOCS: Masuka -a parser (M5-2)
    Parse the -a string into argv words: arg0="0" arg1='1' arg2=2.
    - whitespace/tab - word separators;
    - "..." - quoted word with \" and \\ escapes;
    - '...' - literal word (no escape sequences);
    - \ before a special character - just that character;
    - empty quotes "" - empty word (not skipped).
    Words are raw allocated strings: sc_memory_free each, then sc_list_free.
*/

char**
msk_cli_parse_program_arguments(char* pString, i64 length)
{
    char** aWords = NULL;

    if (!pString || length <= 0)
        return aWords;

    char* pSb = NULL;

    i32 isWordStarted = 0; // DOCS: Non-space characters have been seen.
    i32 isWordInSb = 0;    // DOCS: The current word is already (partially) in pSb.

    for (i64 i = 0; i < length; ++i)
    {
        char c = pString[i];

        if (c == ' ' || c == '\t')
        {
            // DOCS: A word ends only after it started: multiple spaces are skipped.
            if (isWordStarted && isWordInSb)
            {
                sc_list_add(aWords, sc_string_copy(pSb, sc_builder_count(pSb)));
                sc_list_free(pSb);
                pSb = NULL;
                isWordInSb = 0;
            }

            isWordStarted = 0;
            continue;
        }

        if (!isWordStarted)
        {
            isWordStarted = 1;
            isWordInSb = 0;
        }

        if (c == '"')
        {
            // DOCS: Double quotes: \" and \\ are unescaped, everything else is literal.
            for (++i; i < length; ++i)
            {
                char qc = pString[i];

                if (qc == '\\' && i + 1 < length && (pString[i + 1] == '"' || pString[i + 1] == '\\'))
                {
                    sc_builder_append_char(pSb, pString[i + 1]);
                    ++i;
                    isWordInSb = 1;
                    continue;
                }

                if (qc == '"')
                    break;

                sc_builder_append_char(pSb, qc);
                isWordInSb = 1;
            }

            /* DOCS:
                An unterminated quote is a parse error: the rest of the string is
                kept as is, so nothing is silently lost.
            */
            if (i >= length)
                sc_log_warn("-a: unterminated double quote in arguments\n");

            continue;
        }

        if (c == '\'')
        {
            // DOCS: Single quotes: literal, no escape sequences inside.
            for (++i; i < length; ++i)
            {
                if (pString[i] == '\'')
                    break;

                sc_builder_append_char(pSb, pString[i]);
                isWordInSb = 1;
            }

            if (i >= length)
                sc_log_warn("-a: unterminated single quote in arguments\n");

            continue;
        }

        // DOCS: A word without quotes: separators and quotes lose their meaning.
        sc_builder_append_char(pSb, c);
        isWordInSb = 1;
    }

    // DOCS: The last word (a string without a trailing space ends right here).
    if (isWordStarted && isWordInSb)
    {
        sc_list_add(aWords, sc_string_copy(pSb, sc_builder_count(pSb)));
    }

    sc_list_free(pSb);

    return aWords;
}

/*
    DOCS: Masuka Language - the *.masuka configuration language.
    Contains:
    - parse functions
    - language objects
*/

MskVince
msk_language_vince_new(char* pFileContent)
{
    MskVince mskVince = {};

    /* DOCS:
        Put base variables. Values are filled after parsing: {build} and {platform}
        must be names declared in vince.masuka, not system names ("Debug"/"Linux").
    */
    MskVariable buildVar = {
        sc_string_new("build"),
        ScNull
    };
    MskVariable platformVar = {
        sc_string_new("platform"),
        ScNull
    };

    sc_list_add(mskVince.aVariables, buildVar);
    sc_list_add(mskVince.aVariables, platformVar);

    char c = *pFileContent;
    while (c != '\0')
    {
        switch (c)
        {
        case 'w':
        {
            if (!sc_string_compare_ext(pFileContent, "workspace", 9))
            {
                break;
            }

            sc_ptr_next_n(pFileContent, c, 9);

            while (!sc_char_is_letter(c))
                sc_ptr_next(pFileContent, c);

            char* pWordStart = pFileContent;
            sc_ptr_skip_until_two(pFileContent, c, '\n', '\0');

            i64 wordLength = sc_ptr_diff(pWordStart, pFileContent) - 1;
            mskVince.pName = sc_string_new_ext(pWordStart, wordLength, wordLength);
            break;
        }

        case 'e':
        {
            if (!sc_string_compare_ext(pFileContent, "entry", 5))
            {
                break;
            }

            sc_ptr_skip_until(pFileContent, c, ':');

            while (!sc_char_is_letter(c))
                sc_ptr_next(pFileContent, c);

            char* pStart = pFileContent;
            sc_ptr_skip_until(pFileContent, c, '"');
            char* pEnd = pFileContent;

            i64 entryLen = sc_ptr_diff(pStart, pEnd) - 1;
            mskVince.pEntryName = sc_string_new_ext(pStart, entryLen, entryLen);

            break;
        }

        case 'l':
        {
            if (!sc_string_compare_ext(pFileContent, "let", 3))
            {
                break;
            }

            sc_ptr_skip_until(pFileContent, c, ' ');

            while (!sc_char_is_letter(c))
                sc_ptr_next(pFileContent, c);

            char* pVarKeyStart = pFileContent;
            sc_ptr_skip_until(pFileContent, c, ':');
            char* pVarKeyEnd = pFileContent;
            i64 var_key_len = pVarKeyEnd - pVarKeyStart;
            char* pVarKey = sc_string_new_ext(pVarKeyStart, var_key_len, var_key_len);

            sc_ptr_skip_until(pFileContent, c, '"');
            sc_ptr_next(pFileContent, c);
            char* pVarValueStart = pFileContent;
            sc_ptr_next(pFileContent, c);
            sc_ptr_skip_until(pFileContent, c, '"');
            char* pVarValueEnd = pFileContent;
            i64 var_value_len = pVarValueEnd - pVarValueStart;
            char* pVarValue = sc_string_new_ext(pVarValueStart, var_value_len, var_value_len);

            MskVariable mskVariable = {
                .pKey = pVarKey,
                .pValue = pVarValue
            };
            sc_list_add(mskVince.aVariables, mskVariable);

            break;
        }

        case 'b':
        {
            if (sc_string_compare_ext(pFileContent, "builds", 6))
            {
                // parse builds
                sc_ptr_skip_until(pFileContent, c, ':');
                sc_ptr_skip_until_two(pFileContent, c, '[', '{');

                if (c == '[')
                {
                    // logf("Builds is array of objects!\n");
                    sc_ptr_skip_until_two(pFileContent, c, '{', ']');
                    if (c == ']')
                    {
                        // logf("builds is empty!\n");
                    }
                    else if (c == '{')
                    {
                        // logf("first object!\n");
                        /*
                        builds: [
                            {
                              name: "debug"
                              preprocessor: "SC_BUILD_DEBUG",
                              optimize: 0
                            },
                            {
                              name: "release"
                              preprocessor: "SC_BUILD_RELEASE",
                              optimize: 1
                            },
                            {
                              name: "distribute"
                              preprocessor: "SC_BUILD_DISTRIBUTE",
                              optimize: 1
                            },
                        ],
                        */

                        while (!sc_char_is_letter(c))
                            sc_ptr_next(pFileContent, c);

                        MskBuild mskBuild = {};
                        while (1)
                        {
                            while (sc_char_is_whitespace(c))
                                sc_ptr_next(pFileContent, c);

                            switch (c)
                            {
                            case 'n':
                            {
                                if (sc_string_compare_ext(pFileContent, "name", 4))
                                {
                                    char* pNameValue = msk_parse_next_single_value(&pFileContent, &c);
                                    logf("%s\n", pNameValue);
                                    sc_ptr_next(pFileContent, c);
                                    mskBuild.pName = pNameValue;
                                }
                                break;
                            }

                            case 'p':
                            {
                                if (sc_string_compare_ext(pFileContent, "preprocessor", 12))
                                {
                                    char* pPreprocValue = msk_parse_next_single_value(&pFileContent, &c);
                                    logf("%s\n", pPreprocValue);
                                    mskBuild.pPreprocessor = pPreprocValue;
                                }
                                break;
                            }

                            case 'o':
                            {
                                if (sc_string_compare_ext(pFileContent, "optimize", 8))
                                {
                                    char* pOptimizeValue = msk_parse_next_single_value(&pFileContent, &c);
                                    logf("%s\n", pOptimizeValue);
                                    mskBuild.IsOptimize = (*pOptimizeValue == '1');
                                }
                                break;
                            }

                            case '}':
                            {
                                if (*pFileContent == '}')
                                {
                                    sc_list_add(mskVince.aBuilds, mskBuild);
                                }
                                break;
                            }
                            }

                            if (c == ']')
                                break;

                            sc_ptr_next(pFileContent, c);
                        }
                    }
                    else
                    {
                        logf("Fatal ERROR!\n");
                    }
                }
                else if (c == '{')
                {
                    logf("Builds is object!\n");
                }
                else
                {
                    logf("FATAL ERROR!\n");
                }
            }
            break;
        }

        case 'p':
        {
            if (sc_string_compare_ext(pFileContent, "platforms", 9))
            {
                // parse builds
                sc_ptr_skip_until(pFileContent, c, ':');
                sc_ptr_skip_until_two(pFileContent, c, '[', '{');

                if (c == '[')
                {
                    logf("Platforms is array of objects!\n");
                    sc_ptr_skip_until_two(pFileContent, c, '{', ']');
                    if (c == ']')
                    {
                        logf("builds is empty!\n");
                    }
                    else if (c == '{')
                    {
                        logf("first object!\n");
                        /*
                        platforms: [
                                {
                                    name: "linux",
                                    preprocessor: "SC_PLATFORM_LINUX"
                                },
                                {
                                    name: "windows",
                                    preprocessor: "SC_PLATFORM_WINDOWS"
                                }
                            ]
                        */

                        while (!sc_char_is_letter(c))
                            sc_ptr_next(pFileContent, c);

                        MskPlatform mskPlatform = {};
                        do
                        {
                            if (sc_string_compare_ext(pFileContent, "name", 4))
                            {
                                char* pNameValue = msk_parse_next_single_value(&pFileContent, &c);
                                logf("%s\n", pNameValue);
                                mskPlatform.pName = pNameValue;
                            }
                            else if (sc_string_compare_ext(pFileContent, "preprocessor", 12))
                            {
                                char* pPreprocValue = msk_parse_next_single_value(&pFileContent, &c);
                                logf("%s\n", pPreprocValue);
                                mskPlatform.pPreprocessor = pPreprocValue;
                            }
                            else if (*pFileContent == '}')
                            {
                                sc_list_add(mskVince.aPlatforms, mskPlatform);
                            }
                            sc_ptr_next(pFileContent, c);
                        }
                        while (c != ']');
                    }
                    else
                    {
                        logf("Fatal ERROR!\n");
                    }
                }
                else if (c == '{')
                {
                    logf("Builds is object!\n");
                }
                else
                {
                    logf("FATAL ERROR!\n");
                }
            }
            break;
        }

        case '/':
        {
            sc_ptr_skip_until(pFileContent, c, '\n');
            sc_ptr_next(pFileContent, c);
            break;
        }
        }

        /*
        c == 'w' -> workspace (scope-keyword)
        { -> begin scope_keyword (add to scope-keyword collection)
        } -> end of current scope_keyword

        b -> builds

        c == 'd' -> dependencies
        c == 'p' -> project
        */

        if (c == '\0')
            break;

        ++pFileContent;
        c = *pFileContent;
    }

    /* DOCS:
        Default values of {build} and {platform} are the first names declared
        in vince.masuka. System values are a fallback only for an empty workspace.
    */
    ScSystemInfo sysInfo = sc_system_info_get();
    char* pDefaultBuild = sc_list_count(mskVince.aBuilds) > 0 ? mskVince.aBuilds[0].pName : (char*)msk_cli_build_name_from_system(sysInfo.Build);
    char* pDefaultPlatform = sc_list_count(mskVince.aPlatforms) > 0 ? mskVince.aPlatforms[0].pName : (char*)msk_cli_platform_name_from_system(sysInfo.Os);

    msk_language_vince_set_selection(&mskVince, pDefaultBuild, pDefaultPlatform);

    return mskVince;
}

void
msk_language_vince_set_selection(MskVince* pVince, char* pBuild, char* pPlatform)
{
    if (!pVince)
        return;

    /* DOCS:
        Values are names declared in vince.masuka, so pointers stay valid
        for the whole lifetime of MskVince. NULL means "keep current value".
    */
    for (i32 v = 0; v < sc_list_count(pVince->aVariables); ++v)
    {
        MskVariable* pVariable = &pVince->aVariables[v];

        if (pBuild && sc_string_compare(pVariable->pKey, "build"))
        {
            pVariable->pValue = pBuild;
        }
        else if (pPlatform && sc_string_compare(pVariable->pKey, "platform"))
        {
            pVariable->pValue = pPlatform;
        }
    }
}

i32
msk_language_vince_is_valid(MskVince mskVince)
{
    if (!mskVince.pName)
        return 0;

    if (sc_list_count(mskVince.aBuilds) <= 0)
        return 0;

    if (sc_list_count(mskVince.aPlatforms) <= 0)
        return 0;

    return 1;
}

// DOCS: Validate vince.masuka with a precise message: what is missing or duplicated.
ScResult
msk_language_vince_validate(MskVince mskVince)
{
    ScResult result = ScResult_Success;

    if (!mskVince.pName)
    {
        sc_log_erro("vince.masuka: missing 'workspace <Name>' declaration\n");
        result = ScResult_Error;
    }

    if (sc_list_count(mskVince.aBuilds) <= 0)
    {
        sc_log_erro("vince.masuka: 'builds' array is missing or empty\n");
        result = ScResult_Error;
    }

    for (i32 b = 0; b < sc_list_count(mskVince.aBuilds); ++b)
    {
        if (!mskVince.aBuilds[b].pName || mskVince.aBuilds[b].pName[0] == '\0')
        {
            sc_log_erro("vince.masuka: build #%d has no 'name'\n", b + 1);
            result = ScResult_Error;
            continue;
        }

        for (i32 p = 0; p < b; ++p)
        {
            if (mskVince.aBuilds[p].pName && sc_string_compare(mskVince.aBuilds[p].pName, mskVince.aBuilds[b].pName))
            {
                sc_log_erro("vince.masuka: duplicate build name '%s'\n", mskVince.aBuilds[b].pName);
                result = ScResult_Error;
            }
        }
    }

    if (sc_list_count(mskVince.aPlatforms) <= 0)
    {
        sc_log_erro("vince.masuka: 'platforms' array is missing or empty\n");
        result = ScResult_Error;
    }

    for (i32 p = 0; p < sc_list_count(mskVince.aPlatforms); ++p)
    {
        if (!mskVince.aPlatforms[p].pName || mskVince.aPlatforms[p].pName[0] == '\0')
        {
            sc_log_erro("vince.masuka: platform #%d has no 'name'\n", p + 1);
            result = ScResult_Error;
            continue;
        }

        for (i32 q = 0; q < p; ++q)
        {
            if (mskVince.aPlatforms[q].pName && sc_string_compare(mskVince.aPlatforms[q].pName, mskVince.aPlatforms[p].pName))
            {
                sc_log_erro("vince.masuka: duplicate platform name '%s'\n", mskVince.aPlatforms[p].pName);
                result = ScResult_Error;
            }
        }
    }

    return result;
}

MskFilePlatform
msk_file_platform_parse(char* pName, char** ppRead, char* pC)
{
    MskFilePlatform mskFilePlatform = {
        .pName = sc_string_new(pName)
    };

    char* pRead = *ppRead;
    char c = *pC;

    while (c != '\0' && *pRead != '{')
    {
        ++pRead;
        c = *pRead;
    }

    while (c != '\0' && *pRead != '}')
    {
        c = *pRead;

        switch (c)
        {
        case 's':
        {
            if (sc_string_compare_ext(pRead, "source:", 7))
            {
                mskFilePlatform.aSources = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'd':
        {
            if (sc_string_compare_ext(pRead, "dependencies:", 13))
            {
                mskFilePlatform.aDependencies = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'l':
        {
            if (sc_string_compare_ext(pRead, "links:", 6))
            {
                mskFilePlatform.aLinks = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'i':
        {
            if (sc_string_compare_ext(pRead, "include:", 8))
            {
                mskFilePlatform.aIncludes = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'p':
        {
            if (sc_string_compare_ext(pRead, "provide-include:", 16))
            {
                mskFilePlatform.aProvideIncludes = msk_parse_next_array(&pRead, &c);
            }
            else if (sc_string_compare_ext(pRead, "preprocessors:", 14))
            {
                mskFilePlatform.aPreprocessors = msk_parse_next_array(&pRead, &c);
            }
            break;
        }
        }

        ++pRead;
    }

    *ppRead = pRead;
    *pC = c;

    return mskFilePlatform;
}

force_inline i32
msk_language_is_identifier(char c)
{
    if (c == '\0' || sc_char_is_whitespace(c))
        return 0;

    char hCharIsId[256] = {
        // DOCS: sc_char_is_letter (a-z)
        ['a'] = 1,
        ['b'] = 1,
        ['c'] = 1,
        ['d'] = 1,
        ['e'] = 1,
        ['f'] = 1,
        ['g'] = 1,
        ['h'] = 1,
        ['i'] = 1,
        ['j'] = 1,
        ['k'] = 1,
        ['l'] = 1,
        ['m'] = 1,
        ['n'] = 1,
        ['o'] = 1,
        ['p'] = 1,
        ['q'] = 1,
        ['r'] = 1,
        ['s'] = 1,
        ['t'] = 1,
        ['u'] = 1,
        ['v'] = 1,
        ['w'] = 1,
        ['x'] = 1,
        ['y'] = 1,
        ['z'] = 1,
        // DOCS: sc_char_is_letter (A-Z)
        ['A'] = 1,
        ['B'] = 1,
        ['C'] = 1,
        ['D'] = 1,
        ['E'] = 1,
        ['F'] = 1,
        ['G'] = 1,
        ['H'] = 1,
        ['I'] = 1,
        ['J'] = 1,
        ['K'] = 1,
        ['L'] = 1,
        ['M'] = 1,
        ['N'] = 1,
        ['O'] = 1,
        ['P'] = 1,
        ['Q'] = 1,
        ['R'] = 1,
        ['S'] = 1,
        ['T'] = 1,
        ['U'] = 1,
        ['V'] = 1,
        ['W'] = 1,
        ['X'] = 1,
        ['Y'] = 1,
        ['Z'] = 1,
        // DOCS: sc_char_is_integer (0-9)
        ['0'] = 1,
        ['1'] = 1,
        ['2'] = 1,
        ['3'] = 1,
        ['4'] = 1,
        ['5'] = 1,
        ['6'] = 1,
        ['7'] = 1,
        ['8'] = 1,
        ['9'] = 1,
        // DOCS: Additional identifier characters
        ['_'] = 1,
        ['-'] = 1,
        ['{'] = 1,
        ['}'] = 1,
    };

    return hCharIsId[(u8)c];
}

// DOCS: Project names: letters, digits, '_' and '-' (MiniAudio, ScVkSample, masuka-test).
i32
msk_language_name_char(char c)
{
    return sc_char_is_letter(c) || sc_char_is_integer(c) || c == '_' || c == '-';
}

/* DOCS:
    Platform block starts with "linux:" / "windows:", not with a quoted name
    like platforms: [ { name: "linux", ... } ].
*/
i32
msk_language_platform_block(char* pRead, char* pName)
{
    i64 nameLength = sc_string_get_length(pName);
    if (!sc_string_compare_ext(pRead, pName, nameLength))
        return 0;

    char nextChar = pRead[nameLength];
    return nextChar == ':' || sc_char_is_whitespace(nextChar);
}

force_inline i32
msk_language_path_char(char c)
{
    return '.';
}

MskFile
msk_language_file_new(MskVince* pVince, char* pFilePath)
{
    i64 mskFileLength = 0;
    char* pFileContent = sc_file_read_ext(pFilePath, &mskFileLength);

    if (!pFileContent)
    {
        sc_log_warn("Failed to read file %s\n", pFilePath);
        return (MskFile) {};
    }

    MskFile mskFile = msk_language_file_new_from_memory(pVince, pFilePath, pFileContent);
    sc_memory_free(pFileContent);

    return mskFile;
}

// DOCS: The content is owned by the caller (not freed here); paths are taken from pFilePath.
MskFile
msk_language_file_new_from_memory(MskVince* pVince, char* pFilePath, char* pFileContent)
{
    MskFile mskFile = {};

    mskFile.pFilePath = sc_string_new(pFilePath);
    /* DOCS:
        A project file in the workspace root has no separator in its path:
        sc_path_get_directory returns NULL, but the project location is "." (root).
    */
    mskFile.pProjectLocation = sc_path_get_directory(pFilePath);
    if (!mskFile.pProjectLocation)
        mskFile.pProjectLocation = sc_string_copy(".", 1);

    /* DOCS:
        File parsing doesn't need vince.masuka: variables are substituted later,
        during preprocessing (msk_preprocessor_file), including {project}.
    */
    (void)pVince;

    if (!pFileContent)
        return mskFile;

    char* pRead = pFileContent;
    char c = *pRead;

    while (c != '\0' && !msk_language_is_identifier(c))
    {
        ++pRead;
        c = *pRead;
    }

    while (c != '\0')
    {
        switch (c)
        {

        case 't':
        {
            if (sc_string_compare_ext(pRead, "type:", 5))
            {
                /* DOCS:
                    The raw value is kept for validation messages: an unknown type
                    must be reported, not silently turned into an executable.
                */
                mskFile.pTypeName = msk_parse_next_single_value(&pRead, &c);

                if (sc_string_compare(mskFile.pTypeName, "StaticLib"))
                    mskFile.ProjectType = MskProjectType_StaticLib;
                else if (sc_string_compare(mskFile.pTypeName, "DynamicLib"))
                    mskFile.ProjectType = MskProjectType_DynamicLib;
                else if (sc_string_compare(mskFile.pTypeName, "Executable"))
                    mskFile.ProjectType = MskProjectType_Executable;
            }
            break;
        }

        case 'b':
        {
            if (sc_string_compare_ext(pRead, "bin:", 4))
            {
                mskFile.pBin = msk_parse_next_single_value(&pRead, &c);
            }
            break;
        }

        case 'o':
        {
            if (sc_string_compare_ext(pRead, "objdir:", 7))
            {
                mskFile.pObjDir = msk_parse_next_single_value(&pRead, &c);
            }
            break;
        }

        case 's':
        {
            if (sc_string_compare_ext(pRead, "source:", 7))
            {
                mskFile.aSources = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'd':
        {
            if (sc_string_compare_ext(pRead, "dependencies:", 13))
            {
                mskFile.aDependencies = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'l':
        {
            if (sc_string_compare_ext(pRead, "links:", 6))
            {
                mskFile.aLinks = msk_parse_next_array(&pRead, &c);
            }
            else if (msk_language_platform_block(pRead, "linux"))
            {
                MskFilePlatform mskFilePlatform = msk_file_platform_parse("linux", &pRead, &c);
                sc_list_add(mskFile.aPlatforms, mskFilePlatform);
            }
            break;
        }

        case 'w':
        {
            if (msk_language_platform_block(pRead, "windows"))
            {
                MskFilePlatform mskFilePlatform = msk_file_platform_parse("windows", &pRead, &c);
                sc_list_add(mskFile.aPlatforms, mskFilePlatform);
            }
            break;
        }

        case 'i':
        {
            if (sc_string_compare_ext(pRead, "include:", 8))
            {
                mskFile.aIncludes = msk_parse_next_array(&pRead, &c);
            }
            break;
        }

        case 'p':
        {
            if (sc_string_compare_ext(pRead, "preprocessors:", 14))
            {
                mskFile.aPreprocessors = msk_parse_next_array(&pRead, &c);
            }
            else if (sc_string_compare_ext(pRead, "project ", 8))
            {
                pRead = pRead + 8;
                while (!sc_char_is_letter(*pRead))
                    sc_ptr_next(pRead, c);

                char* pStart = pRead;
                while (msk_language_name_char(*pRead))
                    sc_ptr_next(pRead, c);

                i64 length = sc_ptr_diff(pStart, pRead) - 1;
                mskFile.pProjectName = sc_string_new_ext(pStart, length, length);
            }
            else if (sc_string_compare_ext(pRead, "provide-include:", 16))
            {
                mskFile.aProvideIncludes = msk_parse_next_array(&pRead, &c);
            }
            break;
        }
        }

        if (c == '\0')
            break;

        ++pRead;
        c = *pRead;
    }

    return mskFile;
}

i32
msk_language_file_is_valid(MskFile mf)
{
    return mf.pProjectName && mf.pProjectLocation && mf.pBin && mf.pObjDir && sc_list_count(mf.aSources) > 0;
}

// DOCS: Validate a parsed *.masuka file with a precise error: file and field.
ScResult
msk_language_file_validate(MskFile mskFile)
{
    ScResult result = ScResult_Success;
    char* pPath = mskFile.pFilePath ? mskFile.pFilePath : "<masuka file>";

    if (!mskFile.pProjectName || mskFile.pProjectName[0] == '\0')
    {
        sc_log_erro("%s: missing 'project <Name>' declaration\n", pPath);
        result = ScResult_Error;
    }

    if (!mskFile.pTypeName)
    {
        sc_log_erro("%s: missing 'type' field (expected \"Executable\", \"StaticLib\" or \"DynamicLib\")\n", pPath);
        result = ScResult_Error;
    }
    else if (!sc_string_compare(mskFile.pTypeName, "Executable") && !sc_string_compare(mskFile.pTypeName, "StaticLib") && !sc_string_compare(mskFile.pTypeName, "DynamicLib"))
    {
        sc_log_erro("%s: unknown project type '%s' (expected \"Executable\", \"StaticLib\" or \"DynamicLib\")\n",
            pPath,
            mskFile.pTypeName);
        result = ScResult_Error;
    }

    if (!mskFile.pBin || mskFile.pBin[0] == '\0')
    {
        sc_log_erro("%s: missing or empty 'bin' field\n", pPath);
        result = ScResult_Error;
    }

    if (!mskFile.pObjDir || mskFile.pObjDir[0] == '\0')
    {
        sc_log_erro("%s: missing or empty 'objdir' field\n", pPath);
        result = ScResult_Error;
    }

    if (sc_list_count(mskFile.aSources) <= 0)
    {
        sc_log_erro("%s: missing or empty 'source' array\n", pPath);
        result = ScResult_Error;
    }

    return result;
}

/*
   DOCS: Masuka Preprocessor
*/

/* DOCS:
    Preprocess a string field in place: the new value is written back and the old one
    is released. Nothing is lost and nothing leaks.
*/
static void
msk_preprocess_string_field(MskVariable* aVariables, i64 variablesCount, char** ppString)
{
    if (!ppString || !*ppString)
        return;

    char* pOld = *ppString;
    char* pNew = msk_preprocess_string(aVariables, variablesCount, pOld, sc_string_length(pOld));

    // DOCS: Same pointer means that there is nothing to substitute (no variables inside).
    if (!pNew || pNew == pOld)
        return;

    *ppString = pNew;
    sc_string_destroy(pOld);
}

// DOCS: Preprocess an array of strings (source:, include:, links:, ...) in place.
static void
msk_preprocess_string_array(MskVariable* aVariables, i64 variablesCount, MskString* aStrings)
{
    for (i32 s = 0; s < sc_list_count(aStrings); ++s)
        msk_preprocess_string_field(aVariables, variablesCount, &aStrings[s].pName);
}

MskFile
msk_preprocessor_file(MskVince* pVince, MskFile mskFile)
{
    MskVariable* aVariables = NULL;
    i64 variablesCount = 0;
    i8 isProjectVariableAdded = 0;

    /* DOCS:
        {project} is a variable of a concrete project, not of the whole workspace.
        It is registered for this file only and removed after preprocessing.
    */
    if (pVince && mskFile.pProjectName)
    {
        MskVariable projectVariable = {
            .pKey = "project",
            .pValue = mskFile.pProjectName
        };

        sc_list_add(pVince->aVariables, projectVariable);
        isProjectVariableAdded = 1;
    }

    if (pVince)
    {
        aVariables = pVince->aVariables;
        variablesCount = sc_list_count(pVince->aVariables);
    }

    // DOCS: Project fields
    msk_preprocess_string_field(aVariables, variablesCount, &mskFile.pBin);
    msk_preprocess_string_field(aVariables, variablesCount, &mskFile.pObjDir);

    msk_preprocess_string_array(aVariables, variablesCount, mskFile.aSources);
    msk_preprocess_string_array(aVariables, variablesCount, mskFile.aDependencies);
    msk_preprocess_string_array(aVariables, variablesCount, mskFile.aLinks);
    msk_preprocess_string_array(aVariables, variablesCount, mskFile.aIncludes);
    msk_preprocess_string_array(aVariables, variablesCount, mskFile.aProvideIncludes);
    msk_preprocess_string_array(aVariables, variablesCount, mskFile.aPreprocessors);

    // DOCS: Preprocess platform-specific fields (linux:/windows: blocks).
    for (i32 p = 0; p < sc_list_count(mskFile.aPlatforms); ++p)
    {
        MskFilePlatform* pPlatform = &mskFile.aPlatforms[p];

        msk_preprocess_string_field(aVariables, variablesCount, &pPlatform->pName);
        msk_preprocess_string_array(aVariables, variablesCount, pPlatform->aSources);
        msk_preprocess_string_array(aVariables, variablesCount, pPlatform->aDependencies);
        msk_preprocess_string_array(aVariables, variablesCount, pPlatform->aLinks);
        msk_preprocess_string_array(aVariables, variablesCount, pPlatform->aIncludes);
        msk_preprocess_string_array(aVariables, variablesCount, pPlatform->aProvideIncludes);
        msk_preprocess_string_array(aVariables, variablesCount, pPlatform->aPreprocessors);
    }

    // DOCS: Remove the temporary {project} variable, so the next project gets its own.
    if (isProjectVariableAdded)
    {
        pVince->aVariables = sc_list_remove_index(pVince->aVariables, (i32)sc_list_count(pVince->aVariables) - 1);
    }

    return mskFile;
}

// DOCS: Append every entry of aStrings to *ppTarget (entries are not copied, only shared).
static void
msk_strings_append(MskString** ppTarget, MskString* aStrings)
{
    for (i32 s = 0; s < sc_list_count(aStrings); ++s)
        sc_list_add(*ppTarget, aStrings[s]);
}

/*
   DOCS: Merge the selected platform block (linux:/windows:) into the project.
   DOCS: Called once per file, after preprocessing: platform entries are already resolved.
*/
void
msk_file_apply_platform(MskFile* pFile, char* pPlatformName)
{
    if (!pFile || !pPlatformName)
        return;

    for (i32 p = 0; p < sc_list_count(pFile->aPlatforms); ++p)
    {
        MskFilePlatform* pPlatform = &pFile->aPlatforms[p];

        if (!pPlatform->pName || !sc_string_compare(pPlatform->pName, pPlatformName))
            continue;

        msk_strings_append(&pFile->aSources, pPlatform->aSources);
        msk_strings_append(&pFile->aDependencies, pPlatform->aDependencies);
        msk_strings_append(&pFile->aLinks, pPlatform->aLinks);
        msk_strings_append(&pFile->aIncludes, pPlatform->aIncludes);
        msk_strings_append(&pFile->aProvideIncludes, pPlatform->aProvideIncludes);
        msk_strings_append(&pFile->aPreprocessors, pPlatform->aPreprocessors);

        return;
    }
}

/*
   DOCS: Masuka Project - resolved projects.
   MskFile (parsed AST) -> MskProject (paths, globs, build/platform preprocessors,
   dependencies resolved, includes propagated).
*/

static MskString
msk_project_string(char* pString)
{
    MskString result = {};

    if (pString && pString[0] != '\0')
        result.pName = sc_string_new(pString);

    return result;
}

/* DOCS:
    Combine a project-relative path with the project location.
    Returns raw allocated memory (sc_memory_free), like sc_path_combine.
*/
static char*
msk_project_path_combine(char* pProjectLocation, char* pPath)
{
    if (!pProjectLocation || pProjectLocation[0] == '\0')
        return sc_string_copy(pPath, sc_string_get_length(pPath));

    return sc_path_combine(pProjectLocation, pPath);
}

static void
msk_project_strings_append_copy(MskString** ppTarget, MskString* aStrings)
{
    for (i32 s = 0; s < sc_list_count(aStrings); ++s)
    {
        MskString item = msk_project_string(aStrings[s].pName);
        if (item.pName)
            sc_list_add(*ppTarget, item);
    }
}

i8
msk_project_strings_contains(MskString* aStrings, char* pString)
{
    for (i32 s = 0; s < sc_list_count(aStrings); ++s)
    {
        if (aStrings[s].pName && sc_string_compare(aStrings[s].pName, pString))
            return 1;
    }

    return 0;
}

// DOCS: Append entries of aStrings that are not in *ppTarget yet (entries are shared).
static void
msk_project_strings_append_unique(MskString** ppTarget, MskString* aStrings)
{
    for (i32 s = 0; s < sc_list_count(aStrings); ++s)
    {
        if (!aStrings[s].pName || msk_project_strings_contains(*ppTarget, aStrings[s].pName))
            continue;

        MskString item = { .pName = aStrings[s].pName };
        sc_list_add(*ppTarget, item);
    }
}

/* DOCS:
    Expand source patterns (star-star and star masks) relative to the project directory.
    Non-pattern entries are only prefixed with the project directory.
*/
static MskString*
msk_project_sources_resolve(MskString* aSources, char* pProjectLocation)
{
    MskString* aResult = NULL;

    for (i32 s = 0; s < sc_list_count(aSources); ++s)
    {
        char* pSource = aSources[s].pName;

        if (!pSource || pSource[0] == '\0')
            continue;

        i64 wildcardIndex = sc_string_index_of(pSource, '*');

        if (wildcardIndex < 0)
        {
            char* pCombined = msk_project_path_combine(pProjectLocation, pSource);
            MskString source = { .pName = sc_string_new(pCombined) };
            sc_list_add(aResult, source);
            sc_memory_free(pCombined);
            continue;
        }

        char* pCombined = msk_project_path_combine(pProjectLocation, pSource);
        char* pDirectory = sc_path_get_directory(pCombined);
        char* pMask = pSource + wildcardIndex;

        if (!pDirectory)
            pDirectory = sc_string_copy(".", 1);

        char** aFiles = msk_get_all_files_from_directory(pDirectory, pMask);
        if (sc_list_count(aFiles) <= 0)
        {
            sc_log_erro("%s: source pattern '%s' doesn't match any file\n", pProjectLocation ? pProjectLocation : ".", pSource);
        }

        sc_list_for_each(aFiles, ppFile)
        {
            MskString source = { .pName = sc_string_new(*ppFile) };
            sc_list_add(aResult, source);
            sc_memory_free(*ppFile);
        }

        sc_list_free(aFiles);
        sc_memory_free(pDirectory);
        sc_memory_free(pCombined);
    }

    return aResult;
}

/* DOCS:
    Build a resolved project: expand globs, resolve provide-include from the
    project directory, add build/platform preprocessors.
*/
MskProject
msk_project_from_file(MskFile mskFile, MskVince mskVince, char* pBuild, char* pPlatform)
{
    MskProject project = {};

    if (!mskFile.pProjectName || !mskFile.pProjectLocation)
        return project;

    project.pName = sc_string_new(mskFile.pProjectName);
    project.pProjectLocation = sc_string_new(mskFile.pProjectLocation);
    project.pFilePath = mskFile.pFilePath ? sc_string_new(mskFile.pFilePath) : NULL;
    project.Type = mskFile.ProjectType;

    if (mskFile.pBin)
        project.pBin = sc_string_new(mskFile.pBin);

    if (mskFile.pObjDir)
        project.pObjDir = sc_string_new(mskFile.pObjDir);

    char* pLocation = mskFile.pProjectLocation;

    // DOCS: source: project-relative, patterns are expanded into a file list.
    project.aSources = msk_project_sources_resolve(mskFile.aSources, pLocation);

    // DOCS: include: workspace-relative, as written in *.masuka.
    msk_project_strings_append_copy(&project.aIncludes, mskFile.aIncludes);

    // DOCS: provide-include: project-relative directories exposed to dependents.
    for (i32 p = 0; p < sc_list_count(mskFile.aProvideIncludes); ++p)
    {
        char* pProvideInclude = mskFile.aProvideIncludes[p].pName;
        if (!pProvideInclude || pProvideInclude[0] == '\0')
            continue;

        char* pCombined = msk_project_path_combine(pLocation, pProvideInclude);
        MskString provided = { .pName = sc_string_new(pCombined) };
        sc_list_add(project.aProvided, provided);
        sc_memory_free(pCombined);
    }

    // DOCS: dependencies are project names; they are resolved by msk_projects_resolve.
    msk_project_strings_append_copy(&project.aDependencies, mskFile.aDependencies);
    msk_project_strings_append_copy(&project.aLinks, mskFile.aLinks);

    // DOCS: preprocessors: project-level + selected build + selected platform.
    msk_project_strings_append_copy(&project.aPreprocessors, mskFile.aPreprocessors);

    MskString aSelectionPreprocessors[2] = {};
    i64 buildIndex = pBuild ? sc_list_index_of(mskVince.aBuilds, sc_string_compare(item.pName, pBuild)) : -1;
    i64 platformIndex = pPlatform ? sc_list_index_of(mskVince.aPlatforms, sc_string_compare(item.pName, pPlatform)) : -1;

    if (buildIndex >= 0 && mskVince.aBuilds[buildIndex].pPreprocessor)
        aSelectionPreprocessors[0] = msk_project_string(mskVince.aBuilds[buildIndex].pPreprocessor);

    // DOCS: Flags of the compiler depend on the selected build (M3-1): -O2 or -g -O0.
    if (buildIndex >= 0)
        project.IsOptimize = mskVince.aBuilds[buildIndex].IsOptimize ? 1 : 0;

    if (platformIndex >= 0 && mskVince.aPlatforms[platformIndex].pPreprocessor)
        aSelectionPreprocessors[1] = msk_project_string(mskVince.aPlatforms[platformIndex].pPreprocessor);

    for (i32 p = 0; p < (i32)ScArrayCount(aSelectionPreprocessors); ++p)
    {
        if (aSelectionPreprocessors[p].pName && !msk_project_strings_contains(project.aPreprocessors, aSelectionPreprocessors[p].pName))
            sc_list_add(project.aPreprocessors, aSelectionPreprocessors[p]);
    }

    return project;
}

MskProject*
msk_projects_from_files(MskFile* aFiles, i32 filesCount, MskVince mskVince, char* pBuild, char* pPlatform)
{
    MskProject* aProjects = NULL;

    for (i32 f = 0; f < filesCount; ++f)
    {
        MskProject project = msk_project_from_file(aFiles[f], mskVince, pBuild, pPlatform);

        if (!project.pName)
            continue;

        sc_list_add(aProjects, project);
    }

    return aProjects;
}

static i32
msk_project_index_of(MskProject* aProjects, i32 projectsCount, char* pName)
{
    if (!pName)
        return -1;

    for (i32 p = 0; p < projectsCount; ++p)
    {
        if (aProjects[p].pName && sc_string_compare(aProjects[p].pName, pName))
            return p;
    }

    return -1;
}

// DOCS: Depth-first dependency visit: post-order gives dependencies-first order.
static i32
msk_project_visit(MskProject* aProjects, i32 projectsCount, i32 index, i32* aColor, i32* aStack, i32* pStackCount, i32* aOrder, i32* pOrderCount)
{
    if (aColor[index] == 1)
    {
        sc_log_erro("Dependency cycle detected: ");
        for (i32 s = 0; s < *pStackCount; ++s)
            sc_log_erro("%s -> ", aProjects[aStack[s]].pName);
        sc_log_erro("%s\n", aProjects[index].pName);
        return 0;
    }

    if (aColor[index] == 2)
        return 1;

    aColor[index] = 1;
    aStack[(*pStackCount)++] = index;

    MskProject* pProject = &aProjects[index];
    for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
    {
        i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, pProject->aDependencies[d].pName);
        if (dependencyIndex < 0)
            continue;

        if (!msk_project_visit(aProjects, projectsCount, dependencyIndex, aColor, aStack, pStackCount, aOrder, pOrderCount))
            return 0;
    }

    --(*pStackCount);
    aColor[index] = 2;
    aOrder[(*pOrderCount)++] = index;

    return 1;
}

/* DOCS:
    A dependent project compiles with the directories provided by its
    dependencies (transitively): Dependencies/stb/src, MiracleEngine/Source, ...
*/
static void
msk_projects_apply_provided_includes(MskProject* aProjects, i32 projectsCount)
{
    MskString** aClosures = sc_memory_allocate(sizeof(MskString*) * projectsCount);
    memset(aClosures, 0, sizeof(MskString*) * projectsCount);

    /* DOCS:
        Projects are already sorted by dependencies: a closure of every dependency
        is computed before the dependent project uses it.
    */
    for (i32 index = 0; index < projectsCount; ++index)
    {
        MskProject* pProject = &aProjects[index];

        MskString* aClosure = NULL;
        msk_project_strings_append_unique(&aClosure, pProject->aProvided);

        for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
        {
            i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, pProject->aDependencies[d].pName);
            if (dependencyIndex < 0)
                continue;

            msk_project_strings_append_unique(&aClosure, aClosures[dependencyIndex]);
        }

        aClosures[index] = aClosure;

        for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
        {
            i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, pProject->aDependencies[d].pName);
            if (dependencyIndex < 0)
                continue;

            msk_project_strings_append_unique(&pProject->aIncludes, aClosures[dependencyIndex]);
        }
    }

    for (i32 p = 0; p < projectsCount; ++p)
        sc_list_free(aClosures[p]);

    sc_memory_free(aClosures);
}

/* DOCS:
    Validate the project graph, sort projects by dependencies and propagate
    provide-include paths. Called after all projects are resolved.
*/
ScResult
msk_projects_resolve(MskProject* aProjects, i32 projectsCount)
{
    if (!aProjects || projectsCount <= 0)
        return ScResult_Success;

    ScResult result = ScResult_Success;

    for (i32 p = 0; p < projectsCount; ++p)
    {
        for (i32 q = 0; q < p; ++q)
        {
            if (aProjects[p].pName && aProjects[q].pName && sc_string_compare(aProjects[p].pName, aProjects[q].pName))
            {
                sc_log_erro("Duplicate project name '%s': %s and %s\n",
                    aProjects[p].pName,
                    aProjects[q].pFilePath ? aProjects[q].pFilePath : "<unknown>",
                    aProjects[p].pFilePath ? aProjects[p].pFilePath : "<unknown>");
                result = ScResult_Error;
            }
        }

        for (i32 d = 0; d < sc_list_count(aProjects[p].aDependencies); ++d)
        {
            char* pDependency = aProjects[p].aDependencies[d].pName;
            if (!pDependency)
                continue;

            i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, pDependency);
            if (dependencyIndex == p)
            {
                sc_log_erro("Project '%s' depends on itself\n", aProjects[p].pName);
                result = ScResult_Error;
            }
            else if (dependencyIndex < 0)
            {
                sc_log_erro("Project '%s' depends on unknown project '%s'\n", aProjects[p].pName, pDependency);
                result = ScResult_Error;
            }
        }
    }

    if (result != ScResult_Success)
        return result;

    i32* aColor = sc_memory_allocate(sizeof(i32) * projectsCount);
    i32* aStack = sc_memory_allocate(sizeof(i32) * projectsCount);
    i32* aOrder = sc_memory_allocate(sizeof(i32) * projectsCount);
    memset(aColor, 0, sizeof(i32) * projectsCount);

    i32 stackCount = 0;
    i32 orderCount = 0;
    for (i32 p = 0; p < projectsCount; ++p)
    {
        if (aColor[p] != 0)
            continue;

        if (!msk_project_visit(aProjects, projectsCount, p, aColor, aStack, &stackCount, aOrder, &orderCount))
        {
            result = ScResult_Error;
            break;
        }
    }

    if (result == ScResult_Success && orderCount == projectsCount)
    {
        MskProject* aSorted = NULL;
        for (i32 o = 0; o < orderCount; ++o)
            sc_list_add(aSorted, aProjects[aOrder[o]]);

        memcpy(aProjects, aSorted, sizeof(MskProject) * orderCount);
        sc_list_free(aSorted);

        msk_projects_apply_provided_includes(aProjects, projectsCount);
    }

    sc_memory_free(aColor);
    sc_memory_free(aStack);
    sc_memory_free(aOrder);

    return result;
}

/*
   DOCS: Masuka generator
    Build scripts:
    - vince_build.sh/vince_build.bat in the workspace root: projects in dependency order;
    - build_{Project}.sh/build_{Project}.bat in the project directory (next to its .masuka):
      compiles its own TU list, then ar (StaticLib) or the linker (Executable/DynamicLib);
    - compile_commands.json for clangd (-gccj).
    Scripts are written relative to the workspace root (the paths are the same as in
    commands), json - absolute.
*/

// DOCS: Command line of one compiler/tool invocation.
typedef struct
{
    // DOCS: Allocated words; freed by msk_argv_free.
    char** aWords;
} MskArgv;

/* DOCS:
    Script kind of the selected platform (§7): -p windows => .bat (clang.exe),
    -p linux => .sh. Host kind is only the fallback for an unknown platform.
*/
MskScriptKind
msk_script_kind_host(void)
{
#if defined(SC_PLATFORM_WINDOWS)
    return MskScriptKind_Batch;
#else  // defined(SC_PLATFORM_LINUX)
    return MskScriptKind_Shell;
#endif // SC_PLATFORM_LINUX
}

/* DOCS:
    -p windows generates .bat for Windows (clang.exe, llvm-ar.exe, \ paths),
    -p linux generates .sh. This is a target choice, not cross-compilation:
    scripts are executed by the host shell (bash / cmd).
*/
MskScriptKind
msk_script_kind_from_platform(char* pPlatform)
{
    if (pPlatform && sc_string_compare(pPlatform, "windows"))
        return MskScriptKind_Batch;

    if (pPlatform && sc_string_compare(pPlatform, "linux"))
        return MskScriptKind_Shell;

    return msk_script_kind_host();
}

static const char*
msk_script_kind_extension(MskScriptKind kind)
{
    return kind == MskScriptKind_Batch ? ".bat" : ".sh";
}

static i8
msk_script_kind_is_batch(MskScriptKind kind)
{
    return kind == MskScriptKind_Batch ? 1 : 0;
}

// DOCS: Path is already absolute ("/..." or "C:...").
static i8
msk_path_is_absolute(char* pPath)
{
    if (!pPath || pPath[0] == '\0')
        return 0;

#if defined(SC_PLATFORM_WINDOWS)
    if (pPath[1] == ':' && ((pPath[0] >= 'a' && pPath[0] <= 'z') || (pPath[0] >= 'A' && pPath[0] <= 'Z')))
        return 1;
#endif // SC_PLATFORM_WINDOWS

    return pPath[0] == '/' || pPath[0] == '\\';
}

/* DOCS:
    Absolute workspace directory: relative input is combined with cwd.
    Returns raw allocated memory (sc_memory_free).
*/
static char*
msk_generator_root_absolute(char* pRootDirectory)
{
    char* pCurrent = sc_directory_get_current();

    if (!pRootDirectory || pRootDirectory[0] == '\0' || sc_string_compare(pRootDirectory, "."))
        return pCurrent;

    if (msk_path_is_absolute(pRootDirectory) || !pCurrent)
    {
        char* pRoot = sc_string_copy(pRootDirectory, sc_string_get_length(pRootDirectory));
        sc_memory_free(pCurrent);
        return pRoot;
    }

    char* pRoot = sc_path_combine(pCurrent, pRootDirectory);
    sc_memory_free(pCurrent);
    return pRoot;
}

/* DOCS:
    Path for generated scripts/json: optionally absolute; batch scripts use '\'.
    Returns raw allocated memory (sc_memory_free).
*/
static char*
msk_generator_path_create(char* pRootDirectory, char* pPath, i8 isAbsolute, MskScriptKind kind)
{
    if (!pPath || pPath[0] == '\0')
        return NULL;

    char* pResult = NULL;

    if (isAbsolute && pRootDirectory && !msk_path_is_absolute(pPath))
        pResult = sc_path_combine(pRootDirectory, pPath);
    else
        pResult = sc_string_copy(pPath, sc_string_get_length(pPath));

    if (pResult && msk_script_kind_is_batch(kind))
    {
        for (char* p = pResult; p[0] != '\0'; ++p)
        {
            if (p[0] == '/')
                p[0] = '\\';
        }
    }

    return pResult;
}

// DOCS: A word that the shell takes literally: no quoting needed.
static i8
msk_script_word_is_safe(char* pWord)
{
    if (!pWord || pWord[0] == '\0')
        return 0;

    for (char* p = pWord; p[0] != '\0'; ++p)
    {
        char c = p[0];
        i8 isSafe = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
        isSafe = isSafe || c == '_' || c == '.' || c == '/' || c == '-' || c == ':' || c == '@' || c == '%' || c == '+' || c == '=' || c == ',';

        if (!isSafe)
            return 0;
    }

    return 1;
}

/* DOCS:
    Quote a single script word ("plain/path" stays as is, "a b" -> "'a b'").
    Returns raw allocated memory (sc_memory_free).
*/
char*
msk_script_quote_word(char* pWord, MskScriptKind kind)
{
    if (!pWord)
        return NULL;

    char* pSb = NULL;

    if (msk_script_word_is_safe(pWord))
    {
        sc_builder_append_string(pSb, pWord, sc_string_get_length(pWord));
    }
    else if (msk_script_kind_is_batch(kind))
    {
        sc_builder_append_char(pSb, '"');

        for (char* p = pWord; p[0] != '\0'; ++p)
        {
            // DOCS: cmd escapes a quote by doubling it.
            if (p[0] == '"')
                sc_builder_append_char(pSb, '"');

            sc_builder_append_char(pSb, p[0]);
        }

        sc_builder_append_char(pSb, '"');
    }
    else
    {
        sc_builder_append_char(pSb, '\'');

        for (char* p = pWord; p[0] != '\0'; ++p)
        {
            // DOCS: it's -> 'it'\''s'
            if (p[0] == '\'')
            {
                sc_builder_append_string(pSb, "'\\''", 4);
                continue;
            }

            sc_builder_append_char(pSb, p[0]);
        }

        sc_builder_append_char(pSb, '\'');
    }

    char* pResult = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pResult;
}

static void
msk_script_append_literal(char** ppSb, char* pText)
{
    sc_builder_append_string(*ppSb, pText, sc_string_get_length(pText));
}

// DOCS: Comment line: "# ..." for shell, "rem ..." for batch.
static void
msk_script_append_comment(char** ppSb, MskScriptKind kind, char* pFormat, ...)
{
    char aBuffer[1024] = {};

    va_list aArguments;
    va_start(aArguments, pFormat);
    sc_format_ext(aBuffer, sizeof(aBuffer), pFormat, aArguments);
    va_end(aArguments);

    msk_script_append_literal(ppSb, msk_script_kind_is_batch(kind) ? "rem " : "# ");
    msk_script_append_literal(ppSb, aBuffer);
    msk_script_append_literal(ppSb, "\n");
}

// DOCS: Append a quoted word as is, without any separator.
static void
msk_script_append_word_raw(char** ppSb, char* pWord, MskScriptKind kind)
{
    if (!pWord || pWord[0] == '\0')
        return;

    char* pQuoted = msk_script_quote_word(pWord, kind);
    if (!pQuoted)
        return;

    sc_builder_append_string(*ppSb, pQuoted, sc_string_get_length(pQuoted));
    sc_memory_free(pQuoted);
}

// DOCS: Append a word separated by a space from the previous content.
static void
msk_script_append_word(char** ppSb, char* pWord, MskScriptKind kind)
{
    if (!pWord || pWord[0] == '\0')
        return;

    sc_builder_append_char(*ppSb, ' ');
    msk_script_append_word_raw(ppSb, pWord, kind);
}

static void
msk_script_append_command(char** ppSb, MskArgv* pArgv, MskScriptKind kind, char* pSuffix)
{
    for (i32 w = 0; w < sc_list_count(pArgv->aWords); ++w)
    {
        if (w > 0)
            sc_builder_append_char(*ppSb, ' ');

        msk_script_append_word_raw(ppSb, pArgv->aWords[w], kind);
    }

    msk_script_append_literal(ppSb, pSuffix);
}

static void
msk_argv_add_copy(MskArgv* pArgv, char* pWord)
{
    if (!pWord || pWord[0] == '\0')
        return;

    sc_list_add(pArgv->aWords, sc_string_copy(pWord, sc_string_get_length(pWord)));
}

// DOCS: Takes ownership of a raw allocated string (sc_memory_free).
static void
msk_argv_add_owned(MskArgv* pArgv, char* pWord)
{
    if (!pWord)
        return;

    sc_list_add(pArgv->aWords, pWord);
}

static void
msk_argv_add_prefixed(MskArgv* pArgv, char* pPrefix, char* pValue)
{
    if (!pValue || pValue[0] == '\0')
        return;

    char* pSb = NULL;
    sc_builder_append_string(pSb, pPrefix, sc_string_get_length(pPrefix));
    sc_builder_append_string(pSb, pValue, sc_string_get_length(pValue));

    char* pWord = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    sc_list_add(pArgv->aWords, pWord);
}

static void
msk_argv_free(MskArgv* pArgv)
{
    for (i32 w = 0; w < sc_list_count(pArgv->aWords); ++w)
        sc_memory_free(pArgv->aWords[w]);

    sc_list_free(pArgv->aWords);
    pArgv->aWords = NULL;
}

// DOCS: <project location>/build_<project>.sh|.bat
char*
msk_generator_project_script_path(MskProject* pProject, MskScriptKind kind)
{
    if (!pProject || !pProject->pName)
        return NULL;

    char* pLocation = (pProject->pProjectLocation && pProject->pProjectLocation[0] != '\0') ? pProject->pProjectLocation : ".";

    char* pSb = NULL;
    sc_builder_append_format(pSb, "%s/build_%s%s", pLocation, pProject->pName, msk_script_kind_extension(kind));

    char* pPath = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pPath;
}

// DOCS: <root>/vince_build.sh|.bat (sc_memory_free).
char*
msk_generator_main_script_path(char* pRootDirectory, MskScriptKind kind)
{
    char* pSb = NULL;
    sc_builder_append_format(pSb, "%s/vince_build%s", (pRootDirectory && pRootDirectory[0] != '\0') ? pRootDirectory : ".", msk_script_kind_extension(kind));

    char* pPath = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pPath;
}

/* DOCS:
    Script path of a project: next to its sources, or in the temporary directory
    of a build from memory (M4-1). Returns raw allocated memory (sc_memory_free).
*/
static char*
msk_generator_script_path(MskGeneratorBuildConfig* pConfig, MskProject* pProject)
{
    if (!pConfig->pScriptsDirectory || pConfig->pScriptsDirectory[0] == '\0')
        return msk_generator_project_script_path(pProject, pConfig->Kind);

    if (!pProject || !pProject->pName)
        return NULL;

    char* pSb = NULL;
    sc_builder_append_format(pSb, "%s/build_%s%s", pConfig->pScriptsDirectory, pProject->pName, msk_script_kind_extension(pConfig->Kind));

    char* pPath = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pPath;
}

// DOCS: Compile flags of a project: argv words before `-c` (M4-5: flags change => rebuild).
static char*
msk_generator_flags_text(MskArgv* pArgv)
{
    char* pSb = NULL;

    for (i32 w = 0; w < sc_list_count(pArgv->aWords); ++w)
    {
        char* pWord = pArgv->aWords[w];
        if (!pWord || sc_string_compare(pWord, "-c"))
            break;

        if (pSb && sc_builder_count(pSb) > 0)
            sc_builder_append_char(pSb, ' ');

        sc_builder_append_string(pSb, pWord, sc_string_get_length(pWord));
    }

    if (!pSb || sc_builder_count(pSb) == 0)
    {
        sc_list_free(pSb);
        return NULL;
    }

    char* pText = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pText;
}

// DOCS: Stamp file with the compile flags of the last build of a project (M4-5).
static char*
msk_generator_flags_stamp_path(MskProject* pProject)
{
    if (!pProject || !pProject->pObjDir || pProject->pObjDir[0] == '\0')
        return NULL;

    char* pSb = NULL;
    sc_builder_append_format(pSb, "%s/.masuka_flags", pProject->pObjDir);

    char* pPath = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pPath;
}

// DOCS: A source path relative to the project directory (borrowed pointer).
static char*
msk_project_source_relative(MskProject* pProject, char* pSource)
{
    if (!pProject || !pProject->pProjectLocation || !pSource)
        return pSource;

    i64 locationLength = sc_string_get_length(pProject->pProjectLocation);
    if (locationLength <= 0 || !sc_string_compare_ext(pSource, pProject->pProjectLocation, locationLength))
        return pSource;

    char* pRelative = pSource + locationLength;
    if (pRelative[0] != '/' && pRelative[0] != '\\')
        return pSource;

    while (pRelative[0] == '/' || pRelative[0] == '\\')
        ++pRelative;

    return pRelative;
}

/* DOCS:
    Object file mirrors the source path inside objdir
    (objdir/Source/Sc/Sc.o for <project>/Source/Sc/Sc.c), so names never collide.
*/
char*
msk_project_object_path(MskProject* pProject, char* pSource)
{
    if (!pProject || !pSource || !pProject->pObjDir || pProject->pObjDir[0] == '\0')
        return NULL;

    char* pRelative = msk_project_source_relative(pProject, pSource);

    char* pSb = NULL;
    sc_builder_append_format(pSb, "%s/%s", pProject->pObjDir, pRelative);

    char* pObject = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);

    // DOCS: The last dot after the last separator is the extension: replace it with ".o".
    i64 length = sc_string_get_length(pObject);
    i64 dotIndex = -1;

    for (i64 i = length - 1; i >= 0; --i)
    {
        if (pObject[i] == '/' || pObject[i] == '\\')
            break;

        if (pObject[i] == '.')
        {
            dotIndex = i;
            break;
        }
    }

    if (dotIndex >= 0 && dotIndex + 1 < length)
    {
        pObject[dotIndex] = '.';
        pObject[dotIndex + 1] = 'o';
        pObject[dotIndex + 2] = '\0';
    }
    else
    {
        char* pWithExtension = NULL;
        sc_builder_append_format(pWithExtension, "%s.o", pObject);
        sc_memory_free(pObject);
        pObject = sc_string_copy(pWithExtension, sc_builder_count(pWithExtension));
        sc_list_free(pWithExtension);
    }

    return pObject;
}

/* DOCS:
    Output of the project:
    <bin>/<name>[.exe], <bin>/lib<name>.a|.so (Linux) or <bin>/<name>.lib|.dll (Windows).
*/
static char*
msk_generator_target_path(MskProject* pProject, char* pRootDirectory, i8 isAbsolute, MskScriptKind kind)
{
    if (!pProject || !pProject->pName || !pProject->pBin)
        return NULL;

    char* pBin = msk_generator_path_create(pRootDirectory, pProject->pBin, isAbsolute, kind);
    if (!pBin)
        return NULL;

    i8 isBatch = msk_script_kind_is_batch(kind);
    char* pSeparator = isBatch ? "\\" : "/";
    char* pSb = NULL;

    switch (pProject->Type)
    {
    case MskProjectType_Executable:
        sc_builder_append_format(pSb, "%s%s%s%s", pBin, pSeparator, pProject->pName, isBatch ? ".exe" : "");
        break;

    case MskProjectType_StaticLib:
        if (isBatch)
            sc_builder_append_format(pSb, "%s%s%s.lib", pBin, pSeparator, pProject->pName);
        else
            sc_builder_append_format(pSb, "%s%slib%s.a", pBin, pSeparator, pProject->pName);
        break;

    case MskProjectType_DynamicLib:
        if (isBatch)
            sc_builder_append_format(pSb, "%s%s%s.dll", pBin, pSeparator, pProject->pName);
        else
            sc_builder_append_format(pSb, "%s%slib%s.so", pBin, pSeparator, pProject->pName);
        break;
    }

    sc_memory_free(pBin);

    char* pResult = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pResult;
}

/* DOCS:
    Libraries to link: direct dependencies first, then theirs (deps-first order),
    plus the binary directories they live in. Duplicates are skipped.
*/
static void
msk_project_link_collect(MskProject* aProjects, i32 projectsCount, MskProject* pProject, MskString** ppLibraries, MskString** ppBinDirectories, i8* pIsDynamic)
{
    for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
    {
        char* pName = pProject->aDependencies[d].pName;
        if (!pName || msk_project_strings_contains(*ppLibraries, pName))
            continue;

        i32 index = msk_project_index_of(aProjects, projectsCount, pName);
        if (index < 0)
            continue;

        sc_list_add(*ppLibraries, (MskString) { .pName = pName });

        if (aProjects[index].pBin && !msk_project_strings_contains(*ppBinDirectories, aProjects[index].pBin))
            sc_list_add(*ppBinDirectories, (MskString) { .pName = aProjects[index].pBin });

        if (aProjects[index].Type == MskProjectType_DynamicLib)
            *pIsDynamic = 1;

        msk_project_link_collect(aProjects, projectsCount, &aProjects[index], ppLibraries, ppBinDirectories, pIsDynamic);
    }
}

// DOCS: Compiler executable for the script kind: clang.exe in .bat, clang in .sh.
static char*
msk_generator_compiler_name(MskScriptKind kind)
{
    return msk_script_kind_is_batch(kind) ? "clang.exe" : "clang";
}

// DOCS: Compile command of one translation unit (M3-1).
static MskArgv
msk_generator_compile_argv(MskProject* pProject, char* pSource, char* pRootDirectory, i8 isAbsolute, MskScriptKind kind)
{
    MskArgv argv = {};

    msk_argv_add_copy(&argv, msk_generator_compiler_name(kind));
    msk_argv_add_copy(&argv, "-std=c99");
    msk_argv_add_copy(&argv, "-m64");

    if (pProject->IsOptimize)
    {
        msk_argv_add_copy(&argv, "-O2");
    }
    else
    {
        msk_argv_add_copy(&argv, "-g");
        msk_argv_add_copy(&argv, "-O0");
    }

    if (pProject->Type == MskProjectType_DynamicLib)
        msk_argv_add_copy(&argv, "-fPIC");

    for (i32 p = 0; p < sc_list_count(pProject->aPreprocessors); ++p)
        msk_argv_add_prefixed(&argv, "-D", pProject->aPreprocessors[p].pName);

    for (i32 i = 0; i < sc_list_count(pProject->aIncludes); ++i)
    {
        char* pInclude = msk_generator_path_create(pRootDirectory, pProject->aIncludes[i].pName, isAbsolute, kind);
        if (pInclude)
        {
            msk_argv_add_prefixed(&argv, "-I", pInclude);
            sc_memory_free(pInclude);
        }
    }

    msk_argv_add_copy(&argv, "-c");
    msk_argv_add_owned(&argv, msk_generator_path_create(pRootDirectory, pSource, isAbsolute, kind));
    msk_argv_add_copy(&argv, "-o");

    char* pObject = msk_project_object_path(pProject, pSource);
    if (pObject)
    {
        msk_argv_add_owned(&argv, msk_generator_path_create(pRootDirectory, pObject, isAbsolute, kind));
        sc_memory_free(pObject);
    }

    return argv;
}

// DOCS: Archive command of a StaticLib: explicit object list (no shell glob, no stale objects).
static MskArgv
msk_generator_archive_argv(MskProject* pProject, char* pRootDirectory, i8 isAbsolute, MskScriptKind kind)
{
    MskArgv argv = {};

    msk_argv_add_copy(&argv, msk_script_kind_is_batch(kind) ? "llvm-ar.exe" : "ar");
    msk_argv_add_copy(&argv, "rcs");
    msk_argv_add_owned(&argv, msk_generator_target_path(pProject, pRootDirectory, isAbsolute, kind));

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
        if (!pObject)
            continue;

        msk_argv_add_owned(&argv, msk_generator_path_create(pRootDirectory, pObject, isAbsolute, kind));
        sc_memory_free(pObject);
    }

    return argv;
}

/* DOCS:
    Link command of an Executable/DynamicLib: objects by explicit list, own and
    dependencies' binary dirs, -l for workspace projects, raw `links` at the end.
*/
static MskArgv
msk_generator_link_argv(MskProject* aProjects, i32 projectsCount, MskProject* pProject, char* pRootDirectory, i8 isAbsolute, MskScriptKind kind)
{
    MskArgv argv = {};

    msk_argv_add_copy(&argv, msk_generator_compiler_name(kind));

    if (pProject->Type == MskProjectType_DynamicLib)
        msk_argv_add_copy(&argv, "-shared");

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
        if (!pObject)
            continue;

        msk_argv_add_owned(&argv, msk_generator_path_create(pRootDirectory, pObject, isAbsolute, kind));
        sc_memory_free(pObject);
    }

    MskString* aLibraries = NULL;
    MskString* aBinDirectories = NULL;
    i8 isDynamic = 0;

    msk_project_link_collect(aProjects, projectsCount, pProject, &aLibraries, &aBinDirectories, &isDynamic);

    // DOCS: The project's own library directory is used first.
    if (pProject->pBin && !msk_project_strings_contains(aBinDirectories, pProject->pBin))
        sc_list_add(aBinDirectories, (MskString) { .pName = pProject->pBin });

    for (i32 b = 0; b < sc_list_count(aBinDirectories); ++b)
    {
        char* pBinDirectory = msk_generator_path_create(pRootDirectory, aBinDirectories[b].pName, isAbsolute, kind);
        if (pBinDirectory)
        {
            msk_argv_add_prefixed(&argv, "-L", pBinDirectory);
            sc_memory_free(pBinDirectory);
        }
    }

    for (i32 l = 0; l < sc_list_count(aLibraries); ++l)
        msk_argv_add_prefixed(&argv, "-l", aLibraries[l].pName);

    // DOCS: links: raw linker flags ("-pthread") or library names ("vulkan" -> -lvulkan).
    for (i32 l = 0; l < sc_list_count(pProject->aLinks); ++l)
    {
        char* pLink = pProject->aLinks[l].pName;
        if (!pLink)
            continue;

        if (pLink[0] == '-')
            msk_argv_add_copy(&argv, pLink);
        else
            msk_argv_add_prefixed(&argv, "-l", pLink);
    }

    // DOCS: Shared libraries are searched next to the executable.
    if (isDynamic && !msk_script_kind_is_batch(kind))
        msk_argv_add_copy(&argv, "-Wl,-rpath,$ORIGIN");

    msk_argv_add_copy(&argv, "-o");
    msk_argv_add_owned(&argv, msk_generator_target_path(pProject, pRootDirectory, isAbsolute, kind));

    sc_list_free(aLibraries);
    sc_list_free(aBinDirectories);

    return argv;
}

// DOCS: Wait for the background compile jobs of the previous batch (-j fan-out).
static void
msk_generator_append_wait(char** ppSb)
{
    msk_script_append_literal(ppSb, "for pid in \"${pids[@]}\"; do wait \"$pid\"; done\n");
}

static void
msk_script_append_mkdir(char** ppSb, char* pDirectory, MskScriptKind kind)
{
    char* pPath = msk_generator_path_create(NULL, pDirectory, 0, kind);
    if (!pPath)
        return;

    if (msk_script_kind_is_batch(kind))
    {
        msk_script_append_literal(ppSb, "if not exist");
        msk_script_append_word(ppSb, pPath, kind);
        msk_script_append_literal(ppSb, " mkdir");
        msk_script_append_word(ppSb, pPath, kind);
        msk_script_append_literal(ppSb, "\n");
    }
    else
    {
        msk_script_append_literal(ppSb, "mkdir -p");
        msk_script_append_word(ppSb, pPath, kind);
        msk_script_append_literal(ppSb, "\n");
    }

    sc_memory_free(pPath);
}

// DOCS: JSON string literal with escaped quotes, backslashes and control characters.
static void
msk_generator_append_json_string(char** ppSb, char* pString)
{
    sc_builder_append_char(*ppSb, '"');

    for (char* p = pString; p && p[0] != '\0'; ++p)
    {
        switch (p[0])
        {
        case '"':
            msk_script_append_literal(ppSb, "\\\"");
            break;

        case '\\':
            msk_script_append_literal(ppSb, "\\\\");
            break;

        case '\n':
            msk_script_append_literal(ppSb, "\\n");
            break;

        case '\r':
            msk_script_append_literal(ppSb, "\\r");
            break;

        case '\t':
            msk_script_append_literal(ppSb, "\\t");
            break;

        default:
            sc_builder_append_char(*ppSb, p[0]);
            break;
        }
    }

    sc_builder_append_char(*ppSb, '"');
}

MskGeneratorSingleBuildResult
msk_generator_build_create_single(MskGeneratorBuildConfig cfg)
{
    MskGeneratorSingleBuildResult result = {};

    if (cfg.ProjectsCount <= 0 || cfg.aProjects == ScNull)
        return result;

    if (cfg.ProjectIndex < 0 || cfg.ProjectIndex >= cfg.ProjectsCount)
        return result;

    MskProject* pProject = &cfg.aProjects[cfg.ProjectIndex];
    i8 isBatch = msk_script_kind_is_batch(cfg.Kind);
    char* pRootDirectory = cfg.pRootDirectory;

    result.pProjectName = pProject->pName;
    result.pScriptPath = msk_generator_script_path(&cfg, pProject);

    // DOCS: Header: the script is self-contained, it always starts in the workspace root.
    msk_script_append_literal(&result.pSb, isBatch ? "@echo off\n" : "#!/bin/bash\n");
    msk_script_append_comment(&result.pSb, cfg.Kind, "Generated by Masuka. Do not edit: `masuka -gb` rewrites this file.");
    msk_script_append_comment(&result.pSb, cfg.Kind, "Project: %s (%s), build=%s, platform=%s.", pProject->pName, msk_project_type_to_string(pProject->Type), cfg.pBuild ? cfg.pBuild : "?", cfg.pPlatform ? cfg.pPlatform : "?");

    if (!isBatch)
        msk_script_append_literal(&result.pSb, "set -e\n");

    if (pRootDirectory)
    {
        msk_script_append_literal(&result.pSb, isBatch ? "cd /d" : "cd");
        msk_script_append_word(&result.pSb, pRootDirectory, cfg.Kind);
        msk_script_append_literal(&result.pSb, "\n");

        if (isBatch)
            msk_script_append_literal(&result.pSb, "if errorlevel 1 exit /b 1\n");
    }


    // DOCS: Object directories mirror the source tree: created once per project (M3-1).
    char** aObjectDirectories = NULL;

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
        char* pObjectDirectory = pObject ? sc_path_get_directory(pObject) : NULL;
        sc_memory_free(pObject);

        if (!pObjectDirectory)
            continue;

        i8 isDuplicate = 0;
        for (i32 d = 0; d < sc_list_count(aObjectDirectories); ++d)
        {
            if (sc_string_compare(aObjectDirectories[d], pObjectDirectory))
            {
                isDuplicate = 1;
                break;
            }
        }

        if (isDuplicate)
        {
            sc_memory_free(pObjectDirectory);
            continue;
        }

        sc_list_add(aObjectDirectories, pObjectDirectory);
    }

    for (i32 d = 0; d < sc_list_count(aObjectDirectories); ++d)
    {
        msk_script_append_mkdir(&result.pSb, aObjectDirectories[d], cfg.Kind);
        sc_memory_free(aObjectDirectories[d]);
    }

    sc_list_free(aObjectDirectories);

    if (pProject->pBin)
        msk_script_append_mkdir(&result.pSb, pProject->pBin, cfg.Kind);

    /* DOCS:
        Incremental build (M4-5): a TU is recompiled when its object is missing,
        the source is newer, or the compile flags changed (stamp file in objdir).
        Batch scripts always rebuild: mtime comparison is not portable in cmd (M6).
    */
    i8 isIncremental = !isBatch && sc_list_count(pProject->aSources) > 0;
    char* pFlagsText = NULL;
    char* pStampPath = NULL;

    if (isIncremental)
    {
        MskArgv probe = msk_generator_compile_argv(pProject, pProject->aSources[0].pName, pRootDirectory, 0, cfg.Kind);
        pFlagsText = msk_generator_flags_text(&probe);
        msk_argv_free(&probe);

        pStampPath = msk_generator_flags_stamp_path(pProject);
        isIncremental = pFlagsText != NULL && pStampPath != NULL;

        if (isIncremental)
        {
            msk_script_append_literal(&result.pSb, "MSK_FLAGS=");
            msk_script_append_word_raw(&result.pSb, pFlagsText, cfg.Kind);
            msk_script_append_literal(&result.pSb, "\nMSK_STAMP=");
            msk_script_append_word_raw(&result.pSb, pStampPath, cfg.Kind);
            msk_script_append_literal(&result.pSb, "\n");
        }
    }

    // DOCS: Compile every TU; -j fan-out inside the project (M3-3).
    i32 jobs = cfg.JobsCount > 0 ? cfg.JobsCount : 1;
    i8 isParallel = !isBatch && jobs > 1 && sc_list_count(pProject->aSources) > 1;
    i32 runningJobs = 0;

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        MskArgv argv = msk_generator_compile_argv(pProject, pProject->aSources[s].pName, pRootDirectory, 0, cfg.Kind);

        if (sc_list_count(argv.aWords) <= 0)
        {
            msk_argv_free(&argv);
            continue;
        }

        if (isParallel && runningJobs == 0)
            msk_script_append_literal(&result.pSb, "pids=()\n");

        if (isIncremental)
        {
            char* pSourcePath = msk_generator_path_create(pRootDirectory, pProject->aSources[s].pName, 0, cfg.Kind);
            char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
            char* pObjectPath = pObject ? msk_generator_path_create(pRootDirectory, pObject, 0, cfg.Kind) : NULL;

            msk_script_append_literal(&result.pSb, "if [ ! -f ");
            msk_script_append_word_raw(&result.pSb, pObjectPath, cfg.Kind);
            msk_script_append_literal(&result.pSb, " ] || [ ");
            msk_script_append_word_raw(&result.pSb, pSourcePath, cfg.Kind);
            msk_script_append_literal(&result.pSb, " -nt ");
            msk_script_append_word_raw(&result.pSb, pObjectPath, cfg.Kind);
            msk_script_append_literal(&result.pSb, " ] || [ \"$MSK_FLAGS\" != \"$(cat \"$MSK_STAMP\" 2>/dev/null)\" ]; then\n");

            sc_memory_free(pSourcePath);
            sc_memory_free(pObject);
            sc_memory_free(pObjectPath);
        }


        msk_script_append_command(&result.pSb, &argv, cfg.Kind, "\n");


        if (isIncremental)
            msk_script_append_literal(&result.pSb, isParallel ? "fi &\n" : "fi\n");

        if (isParallel)
        {
            if (!isIncremental)
                msk_script_append_literal(&result.pSb, " &\n");

            msk_script_append_literal(&result.pSb, "pids+=(\"$!\")\n");
            ++runningJobs;

            if (runningJobs >= jobs)
            {
                msk_generator_append_wait(&result.pSb);
                runningJobs = 0;
            }
        }

        msk_argv_free(&argv);
    }

    if (runningJobs > 0)
        msk_generator_append_wait(&result.pSb);

    // DOCS: Archive/link step (M3-2): remove the old output, then build it from explicit lists.
    char* pTarget = msk_generator_target_path(pProject, pRootDirectory, 0, cfg.Kind);

    if (pTarget)
    {
        if (isBatch)
        {
            msk_script_append_literal(&result.pSb, "if exist");
            msk_script_append_word(&result.pSb, pTarget, cfg.Kind);
            msk_script_append_literal(&result.pSb, " del /q");
            msk_script_append_word(&result.pSb, pTarget, cfg.Kind);
            msk_script_append_literal(&result.pSb, "\n");
        }
        else
        {
            msk_script_append_literal(&result.pSb, "rm -f");
            msk_script_append_word(&result.pSb, pTarget, cfg.Kind);
            msk_script_append_literal(&result.pSb, "\n");
        }
    }

    MskArgv command = {};

    if (pProject->Type == MskProjectType_StaticLib)
        command = msk_generator_archive_argv(pProject, pRootDirectory, 0, cfg.Kind);
    else
        command = msk_generator_link_argv(cfg.aProjects, cfg.ProjectsCount, pProject, pRootDirectory, 0, cfg.Kind);


    if (sc_list_count(command.aWords) > 0)
        msk_script_append_command(&result.pSb, &command, cfg.Kind, "\n");


    msk_argv_free(&command);
    sc_memory_free(pTarget);

    // DOCS: Remember the flags of this build: a change recompiles every TU (M4-5).
    if (isIncremental)
        msk_script_append_literal(&result.pSb, "printf '%s' \"$MSK_FLAGS\" > \"$MSK_STAMP\"\n");


    sc_memory_free(pFlagsText);
    sc_memory_free(pStampPath);

    return result;
}

/* DOCS:
    Dependency level of every project: 1 + the deepest dependency level (M4-2).
    Projects of one level are independent and can be built in parallel.
*/
static void
msk_projects_levels(MskProject* aProjects, i32 projectsCount, i32* aLevels)
{
    for (i32 p = 0; p < projectsCount; ++p)
        aLevels[p] = 0;

    /* DOCS:
        Projects are sorted deps-first, but a few passes make the result independent
        of the input order.
    */
    for (i32 pass = 0; pass <= projectsCount; ++pass)
    {
        i8 isChanged = 0;

        for (i32 p = 0; p < projectsCount; ++p)
        {
            i32 level = 0;

            for (i32 d = 0; d < sc_list_count(aProjects[p].aDependencies); ++d)
            {
                i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, aProjects[p].aDependencies[d].pName);
                if (dependencyIndex < 0)
                    continue;

                i32 uppedDepLvl = aLevels[dependencyIndex] + 1;
                if (uppedDepLvl > level)
                    level = uppedDepLvl;
            }

            if (aLevels[p] != level)
            {
                aLevels[p] = level;
                isChanged = 1;
            }
        }

        if (!isChanged)
            break;
    }
}

MskGeneratorBuildResult
msk_generator_build_create(MskGeneratorBuildConfig cfg)
{
    MskGeneratorBuildResult result = {};
    result.Kind = cfg.Kind;

    i8 isBatch = msk_script_kind_is_batch(cfg.Kind);

    // DOCS: Header of the workspace build script.
    msk_script_append_literal(&result.pSb, isBatch ? "@echo off\n" : "#!/bin/bash\n");
    msk_script_append_comment(&result.pSb, cfg.Kind, "Generated by Masuka. Do not edit: `masuka -gb` rewrites this file.");
    msk_script_append_comment(&result.pSb, cfg.Kind, "build=%s, platform=%s, jobs=%d, projects=%d.", cfg.pBuild ? cfg.pBuild : "?", cfg.pPlatform ? cfg.pPlatform : "?", (i32)cfg.JobsCount, cfg.ProjectsCount);

    if (!isBatch)
        msk_script_append_literal(&result.pSb, "set -e\n");

    if (cfg.pRootDirectory)
    {
        msk_script_append_literal(&result.pSb, isBatch ? "cd /d" : "cd");
        msk_script_append_word(&result.pSb, cfg.pRootDirectory, cfg.Kind);
        msk_script_append_literal(&result.pSb, "\n");

        if (isBatch)
            msk_script_append_literal(&result.pSb, "if errorlevel 1 exit /b 1\n");
    }

    /* DOCS:
        Projects are already sorted by dependencies (msk_projects_resolve).
        Projects of one dependency level are independent: they may build in parallel (M4-2).
    */
    i32 jobs = cfg.JobsCount > 0 ? cfg.JobsCount : 1;
    i32* aLevels = NULL;
    i32 levelsCount = 0;

    if (cfg.ProjectsCount > 0)
    {
        aLevels = sc_memory_allocate(sizeof(i32) * cfg.ProjectsCount);
        msk_projects_levels(cfg.aProjects, cfg.ProjectsCount, aLevels);

        for (i32 p = 0; p < cfg.ProjectsCount; ++p)
        {
            if (aLevels[p] + 1 > levelsCount)
                levelsCount = aLevels[p] + 1;
        }
    }

    i32 builtCount = 0;

    for (i32 level = 0; level < levelsCount; ++level)
    {
        i32 waveCount = 0;

        for (i32 p = 0; p < cfg.ProjectsCount; ++p)
        {
            if (aLevels[p] == level)
                ++waveCount;
        }

        if (waveCount <= 0)
            continue;

        // DOCS: -j is shared between parallel projects: 2 projects and 4 jobs -> 2 jobs each.
        i32 chunkSize = (jobs > 1 && waveCount > 1) ? (waveCount < jobs ? waveCount : jobs) : 1;
        i32 projectJobs = jobs / chunkSize;

        if (projectJobs < 1)
            projectJobs = 1;

        i8 isParallelWave = !isBatch && chunkSize > 1;

        if (isParallelWave)
            msk_script_append_comment(&result.pSb, cfg.Kind, "Level %d: %d project(s) in parallel", level + 1, waveCount);

        i32 chunkIndex = 0;

        for (i32 p = 0; p < cfg.ProjectsCount; ++p)
        {
            if (aLevels[p] != level)
                continue;

            MskGeneratorBuildConfig singleCfg = cfg;
            singleCfg.ProjectIndex = p;
            singleCfg.JobsCount = (i16)projectJobs;

            MskGeneratorSingleBuildResult singleResult = msk_generator_build_create_single(singleCfg);
            sc_list_add(result.aResults, singleResult);
            ++builtCount;

            if (!singleResult.pSb || !singleResult.pScriptPath)
                continue;

            msk_script_append_comment(&result.pSb, cfg.Kind, "[%d/%d] %s (%s)", builtCount, cfg.ProjectsCount, cfg.aProjects[p].pName, msk_project_type_to_string(cfg.aProjects[p].Type));

            if (isParallelWave && chunkIndex == 0)
                msk_script_append_literal(&result.pSb, "pids=()\n");

            msk_script_append_literal(&result.pSb, isBatch ? "call" : "bash");

            // DOCS: Batch scripts get '\' separators, shell scripts keep '/' as is.
            char* pInvocation = msk_generator_path_create(NULL, singleResult.pScriptPath, 0, cfg.Kind);
            msk_script_append_word(&result.pSb, pInvocation, cfg.Kind);
            sc_memory_free(pInvocation);

            if (isParallelWave)
            {
                msk_script_append_literal(&result.pSb, " &\n");
                msk_script_append_literal(&result.pSb, "pids+=(\"$!\")\n");

                if (++chunkIndex >= chunkSize)
                {
                    msk_generator_append_wait(&result.pSb);
                    chunkIndex = 0;
                }
            }
            else
            {
                msk_script_append_literal(&result.pSb, "\n");

                if (isBatch)
                    msk_script_append_literal(&result.pSb, "if errorlevel 1 exit /b 1\n");
            }
        }

        if (chunkIndex > 0)
            msk_generator_append_wait(&result.pSb);
    }

    sc_memory_free(aLevels);

    msk_script_append_literal(&result.pSb, isBatch ? "echo Done.\n" : "echo 'Build finished.'\n");

    return result;
}

// DOCS: Generated scripts are executable, like hand-written build scripts.
static void
msk_script_make_executable(char* pPath)
{
    char* pQuoted = msk_script_quote_word(pPath, MskScriptKind_Shell);
    if (!pQuoted)
        return;

    char aCommand[1024] = {};
    sc_format(aCommand, sizeof(aCommand), "chmod +x %s", pQuoted);
    system(aCommand);
    sc_memory_free(pQuoted);
}

// DOCS: Write script text to a file, creating its directory (temporary scripts of M4-1).
static void
msk_script_write_file(char* pPath, char* pSb)
{
    if (!pPath || !pSb)
        return;

    char* pDirectory = sc_path_get_directory(pPath);

    if (pDirectory)
    {
        sc_directory_create_recursive(pDirectory);
        sc_memory_free(pDirectory);
    }

    if (sc_path(pPath) == ScPathItemType_File)
        sc_file_delete(pPath);

    sc_file_write(pPath, pSb, sc_list_count(pSb));
}

i32
msk_generator_build_write(MskGeneratorBuildResult* pResult, char* pRootDirectory)
{
    if (!pResult || !pResult->pSb)
        return 1;

    i8 isBatch = msk_script_kind_is_batch(pResult->Kind);

    // DOCS: Per-project scripts live in the project directory (M3-2).
    for (i32 r = 0; r < sc_list_count(pResult->aResults); ++r)
    {
        MskGeneratorSingleBuildResult* pSingle = &pResult->aResults[r];

        if (!pSingle->pSb || !pSingle->pScriptPath)
            continue;

        msk_script_write_file(pSingle->pScriptPath, pSingle->pSb);
        sc_log_info("Generated %s\n", pSingle->pScriptPath);

        if (!isBatch)
            msk_script_make_executable(pSingle->pScriptPath);
    }

    // DOCS: Main script in the workspace root (M3-3).
    char* pMainPath = msk_generator_main_script_path(pRootDirectory ? pRootDirectory : ".", pResult->Kind);
    if (!pMainPath)
        return 1;

    msk_script_write_file(pMainPath, pResult->pSb);
    sc_log_info("Generated %s\n", pMainPath);

    if (!isBatch)
        msk_script_make_executable(pMainPath);

    sc_memory_free(pMainPath);
    return 0;
}

i32
msk_generator_json_create(MskGeneratorJsonConfig cfg)
{
    if (cfg.ProjectsCount <= 0 || cfg.aProjects == ScNull)
        return 1;

    char* pRootDirectory = msk_generator_root_absolute(cfg.pRootDirectory);
    if (!pRootDirectory)
        return 1;

    char* pSb = NULL;
    i32 entriesCount = 0;

    msk_script_append_literal(&pSb, "[\n");

    for (i32 p = 0; p < cfg.ProjectsCount; ++p)
    {
        MskProject* pProject = &cfg.aProjects[p];

        if (!pProject->pName)
            continue;

        char* pDirectory = msk_generator_path_create(pRootDirectory,
            (pProject->pProjectLocation && pProject->pProjectLocation[0] != '\0') ? pProject->pProjectLocation : ".",
            1,
            MskScriptKind_Shell);

        for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
        {
            char* pFile = msk_generator_path_create(pRootDirectory, pProject->aSources[s].pName, 1, MskScriptKind_Shell);
            char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
            char* pOutput = pObject ? msk_generator_path_create(pRootDirectory, pObject, 1, MskScriptKind_Shell) : NULL;
            sc_memory_free(pObject);

            MskArgv argv = msk_generator_compile_argv(pProject, pProject->aSources[s].pName, pRootDirectory, 1, MskScriptKind_Shell);

            if (pFile && pOutput && sc_list_count(argv.aWords) > 0)
            {
                msk_script_append_literal(&pSb, entriesCount > 0 ? ",\n  {\n" : "  {\n");

                msk_script_append_literal(&pSb, "    \"directory\": ");
                msk_generator_append_json_string(&pSb, pDirectory ? pDirectory : "");

                msk_script_append_literal(&pSb, ",\n    \"file\": ");
                msk_generator_append_json_string(&pSb, pFile);

                msk_script_append_literal(&pSb, ",\n    \"output\": ");
                msk_generator_append_json_string(&pSb, pOutput);

                msk_script_append_literal(&pSb, ",\n    \"arguments\": [");

                for (i32 w = 0; w < sc_list_count(argv.aWords); ++w)
                {
                    if (w > 0)
                        msk_script_append_literal(&pSb, ", ");

                    msk_generator_append_json_string(&pSb, argv.aWords[w]);
                }

                msk_script_append_literal(&pSb, "]\n  }");

                ++entriesCount;
            }

            msk_argv_free(&argv);
            sc_memory_free(pFile);
            sc_memory_free(pOutput);
        }

        sc_memory_free(pDirectory);
    }

    msk_script_append_literal(&pSb, entriesCount > 0 ? "\n]\n" : "]\n");

    i32 result = 0;
    char* pPath = sc_path_combine(pRootDirectory, "compile_commands.json");

    if (!pPath)
    {
        result = 1;
    }
    else
    {
        if (sc_path(pPath) == ScPathItemType_File)
            sc_file_delete(pPath);

        sc_file_write(pPath, pSb, sc_list_count(pSb));
        sc_log_info("Generated %s (%d translation units)\n", pPath, entriesCount);
        sc_memory_free(pPath);
    }

    sc_list_free(pSb);
    sc_memory_free(pRootDirectory);

    return result;
}

/*
   DOCS: Masuka perf (-pt)
    Build profiling through sc_profiler: masuka itself runs every compile/link
    command and measures its time. Timings are collected into MskPerfLog
    (in-process, without log parsing), then printed as a dependency tree.
*/

// DOCS: Find an entry by name ("project" for projects, source path for files).
static MskPerfEntry*
msk_perf_find(MskPerfEntry* aEntries, char* pName)
{
    for (i32 e = 0; e < sc_list_count(aEntries); ++e)
    {
        if (sc_string_compare(aEntries[e].pName, pName))
            return &aEntries[e];
    }

    return NULL;
}

// DOCS: Add or update a timing entry (ms) of a measured unit.
static void
msk_perf_add(MskPerfEntry** ppEntries, char* pName, i64 milliseconds)
{
    MskPerfEntry* pEntry = msk_perf_find(*ppEntries, pName);

    if (!pEntry)
    {
        MskPerfEntry entry = {
            .pName = sc_string_new(pName),
            .Milliseconds = milliseconds
        };
        sc_list_add(*ppEntries, entry);
        return;
    }

    pEntry->Milliseconds = milliseconds;
}

// DOCS: Time of an entry by name; 0 when the unit was not measured.
static i64
msk_perf_time_of(MskPerfEntry* aEntries, char* pName)
{
    MskPerfEntry* pEntry = msk_perf_find(aEntries, pName);
    return pEntry ? pEntry->Milliseconds : 0;
}

// DOCS: Human-readable size: B, KiB, MiB (sc_int_to_string/sc_float_to_string).
static void
msk_perf_format_size(u64 bytes, char* pBuffer, i64 bufferSize)
{
    if (bytes >= 1024 * 1024)
    {
        char aNumber[48] = {};
        sc_float_to_string_ext(aNumber, sizeof(aNumber), (f64)bytes / (1024.0 * 1024.0), 0.05);
        sc_format(pBuffer, bufferSize, "%s MiB", aNumber);
    }
    else if (bytes >= 1024)
    {
        char aNumber[48] = {};
        sc_float_to_string_ext(aNumber, sizeof(aNumber), (f64)bytes / 1024.0, 0.05);
        sc_format(pBuffer, bufferSize, "%s KiB", aNumber);
    }
    else
    {
        sc_format(pBuffer, bufferSize, "%d B", (i32)bytes);
    }
}

// DOCS: Count compiler diagnostics of one command output (sc_string_index_of_string).
static i32
msk_perf_count_occurrences(char* pText, char* pSubstring)
{
    i32 count = 0;

    for (char* p = pText; ; )
    {
        i64 index = sc_string_index_of_string(p, pSubstring);
        if (index < 0)
            break;

        ++count;
        p += index + 1;

        if (*p == '\0')
            break;
    }

    return count;
}
// DOCS: Release the parsed log entries.
static void
msk_perf_free(MskPerfLog* pLog)
{
    {
        sc_list_for_each(pLog->aCompile, pEntry)
            sc_string_destroy(pEntry->pName);
        sc_list_free(pLog->aCompile);
        pLog->aCompile = NULL;
    }

    {
        sc_list_for_each(pLog->aProject, pEntry)
            sc_string_destroy(pEntry->pName);
        sc_list_free(pLog->aProject);
        pLog->aProject = NULL;
    }

    {
        sc_list_for_each(pLog->aLink, pEntry)
            sc_string_destroy(pEntry->pName);
        sc_list_free(pLog->aLink);
        pLog->aLink = NULL;
    }
}

// DOCS: -pt: per-project tree node with timings (the same tree as -lc).
static void
msk_perf_print_project_tree(MskProject* aProjects, i32 projectsCount, MskPerfLog* pLog, i32 index, i8* aPrinted, char* pPrefix, i8 isLast, i8 isRoot)
{
    MskProject* pProject = &aProjects[index];
    i64 projectTime = msk_perf_time_of(pLog->aProject, pProject->pName);
    i64 linkTime = msk_perf_time_of(pLog->aLink, pProject->pName);

    if (isRoot)
        printf("%s (%s) - %lld ms\n", pProject->pName, msk_project_type_to_string(pProject->Type), projectTime);
    else
        printf("%s%s%s (%s) - %lld ms\n", pPrefix, isLast ? MSK_CLI_TREE_LAST : MSK_CLI_TREE_BRANCH, pProject->pName, msk_project_type_to_string(pProject->Type), projectTime);

    if (aPrinted[index])
    {
        printf("%s%s(see above)\n", pPrefix, isRoot ? "" : (isLast ? MSK_CLI_TREE_SPACE : MSK_CLI_TREE_VERTICAL));
        return;
    }

    aPrinted[index] = 1;

    /* DOCS:
        UTF-8 connectors are byte-concatenated: sc_format %s counts characters
        (sc_utf8_length) but copies that many bytes, breaking multibyte '|'.
    */
    char* pChildPrefixSb = NULL;
    sc_builder_append_string(pChildPrefixSb, pPrefix, sc_string_get_length(pPrefix));
    {
        char* pConnector = isRoot ? "" : (isLast ? MSK_CLI_TREE_SPACE : MSK_CLI_TREE_VERTICAL);
        sc_builder_append_string(pChildPrefixSb, pConnector, sc_string_get_length(pConnector));
    }
    char aChildPrefix[256] = {};
    if (pChildPrefixSb && sc_builder_count(pChildPrefixSb) > 0)
        memcpy(aChildPrefix, pChildPrefixSb, sc_builder_count(pChildPrefixSb));
    sc_list_free(pChildPrefixSb);

    i64 childrenCount = 0;

    for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
    {
        char* pDependency = pProject->aDependencies[d].pName;
        if (!pDependency)
            continue;

        if (msk_project_index_of(aProjects, projectsCount, pDependency) < 0)
            continue;

        ++childrenCount;
    }

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        if (pProject->aSources[s].pName)
            ++childrenCount;
    }

    ++childrenCount; // DOCS: the link/archive line is always the last node of a project

    i64 childIndex = 0;

    for (i32 d = 0; d < sc_list_count(pProject->aDependencies); ++d)
    {
        char* pDependency = pProject->aDependencies[d].pName;
        if (!pDependency)
            continue;

        i32 dependencyIndex = msk_project_index_of(aProjects, projectsCount, pDependency);
        if (dependencyIndex < 0)
            continue;

        ++childIndex;
        msk_perf_print_project_tree(aProjects, projectsCount, pLog, dependencyIndex, aPrinted, aChildPrefix, childIndex == childrenCount, 0);
    }

    for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
    {
        char* pSource = pProject->aSources[s].pName;
        if (!pSource)
            continue;

        ++childIndex;

        i64 compileTime = msk_perf_time_of(pLog->aCompile, pSource);

        printf("%s%s%s - %lld ms\n", aChildPrefix, childIndex == childrenCount ? MSK_CLI_TREE_LAST : MSK_CLI_TREE_BRANCH, pSource, compileTime);
    }

    ++childIndex;
    printf("%s%s[link] - %lld ms\n", aChildPrefix, childIndex == childrenCount ? MSK_CLI_TREE_LAST : MSK_CLI_TREE_BRANCH, linkTime);
}

/* DOCS:
    Build summary (always): success/warnings/errors + target sizes;
    -pt also prints the dependency tree with compile/build timings.
*/
static void
msk_perf_report(MskProject* aProjects, i32 projectsCount, MskPerfLog* pLog, i8 isSuccess)
{
    // DOCS: Summary line: colored success/warnings/errors (terminal colors from Sc).
    printf("\n");
    printf("%sBuild %s\033[0m: %d warning(s), %d error(s)\n",
        isSuccess ? "\x1B[92m" : "\x1B[31m",
        isSuccess ? "succeeded" : "failed",
        pLog->WarningsCount,
        pLog->ErrorsCount);

    // DOCS: Target sizes: every project output that exists on disk.
    if (aProjects)
    {
        for (i32 p = 0; p < projectsCount; ++p)
        {
            MskProject* pProject = &aProjects[p];

            MskScriptKind kind = msk_script_kind_host();
            char* pTarget = msk_generator_target_path(pProject, NULL, 0, kind);

            if (pTarget && sc_path(pTarget) == ScPathItemType_File)
            {
                u64 size = sc_file_get_size(pTarget);
                char aSize[64] = {};
                msk_perf_format_size(size, aSize, sizeof(aSize));
                printf("  %s (%s): %s\n", pProject->pName, msk_project_type_to_string(pProject->Type), aSize);
            }

            sc_memory_free(pTarget);
        }
    }

    // DOCS: -pt: timings of every file and project in the dependency tree form.
    if (sc_list_count(pLog->aCompile) > 0 && aProjects && projectsCount > 0)
    {
        i8* aPrinted = sc_memory_allocate(projectsCount);
        memset(aPrinted, 0, projectsCount);

        printf("\nBuild timings (dependencies first):\n");
        msk_perf_print_project_tree(aProjects, projectsCount, pLog, projectsCount - 1, aPrinted, "", 1, 1);

        sc_memory_free(aPrinted);
    }
}

// DOCS: Count warnings/errors of the captured build log (sc_string_index_of_string).
static void
msk_perf_parse_diagnostics(MskPerfLog* pLog, char* pLogContent)
{
    if (!pLogContent)
        return;

    pLog->WarningsCount = msk_perf_count_occurrences(pLogContent, "warning:");
    pLog->ErrorsCount = msk_perf_count_occurrences(pLogContent, "error:");
}

/* DOCS:
    Parse the captured build log into a MskPerfLog (diagnostics only:
    timings are measured in-process with sc_profiler, not parsed).
*/
static MskPerfLog
msk_perf_parse_log(char* pLogPath)
{
    MskPerfLog log = {};

    i64 logLength = 0;
    char* pLogContent = sc_file_read_ext(pLogPath, &logLength);

    msk_perf_parse_diagnostics(&log, pLogContent);
    sc_memory_free(pLogContent);

    return log;
}
/*
   DOCS: Masuka compiler
    The build runs generated scripts through system() (see section 7):
    - with -gb the already written vince_build.sh/vince_build.bat in the root;
    - without -gb scripts go to the temporary directory bin/.masuka-tmp, are executed
      and deleted, so nothing is left next to the sources.
*/

// DOCS: Temporary scripts of a build from memory (removed after the build, also by -c).
#define MSK_COMPILER_TEMPORARY_DIRECTORY "bin/.masuka-tmp"

static void
msk_compiler_clean_directory(char* pPath)
{
    if (!pPath || pPath[0] == '\0')
        return;

    if (sc_path(pPath) != ScPathItemType_Directory)
        return;

    if (sc_directory_delete_recursive(pPath) != ScResult_Success)
    {
        sc_log_erro("Can't remove directory %s\n", pPath);
        return;
    }

    sc_log_info("Removed %s\n", pPath);
}

/* DOCS:
    Path of the captured build log: <root>/bin/.masuka-tmp/build.log.
    sc_path_get_random_temp is Linux-only, so the log lives next to the
    temporary build scripts (the directory is removed after the build).
*/
static char*
msk_compiler_log_path(char* pRootDirectory)
{
    char* pBase = sc_path_combine(pRootDirectory ? pRootDirectory : ".", MSK_COMPILER_TEMPORARY_DIRECTORY);
    if (!pBase)
        return NULL;

    char* pLog = sc_path_combine(pBase, "build.log");
    sc_memory_free(pBase);
    return pLog;
}
/* DOCS:
    Run a generated script; its output goes straight to the terminal (M4-1).
    -pt / summary: the output is also captured into a temporary log file, so masuka
    can parse [msk] timing markers and count warnings/errors of the compiler.
    Linux: live output through tee; Windows: cmd has no tee, the log is printed
    right after the script finishes (the exit code stays the script's one).
*/
static i32
msk_compiler_run_script_ext(char* pScriptPath, MskScriptKind kind, char* pRootDirectory, char** ppLogFile)
{
    if (!pScriptPath)
        return 1;

    char* pQuoted = msk_script_quote_word(pScriptPath, kind);
    if (!pQuoted)
        return 1;

    char* pLogPath = NULL;
    char aCommand[4096] = {};

    if (ppLogFile)
        pLogPath = msk_compiler_log_path(pRootDirectory);

    if (pLogPath)
    {
        char* pDirectory = sc_path_get_directory(pLogPath);
        if (pDirectory && sc_path(pDirectory) == ScPathItemType_Undefined)
            sc_directory_create_recursive(pDirectory);
        sc_memory_free(pDirectory);

        *ppLogFile = pLogPath;
    }

    if (pLogPath)
    {
        char* pLogQuoted = msk_script_quote_word(pLogPath, kind);

        if (msk_script_kind_is_batch(kind))
            sc_format(aCommand, sizeof(aCommand), "cmd /c %s > %s 2>&1", pQuoted, pLogQuoted);
        else
            sc_format(aCommand, sizeof(aCommand), "bash %s 2>&1 | tee %s", pQuoted, pLogQuoted);

        sc_memory_free(pLogQuoted);
    }
    else
    {
        if (msk_script_kind_is_batch(kind))
            sc_format(aCommand, sizeof(aCommand), "cmd /c %s", pQuoted);
        else
            sc_format(aCommand, sizeof(aCommand), "bash %s", pQuoted);
    }

    sc_memory_free(pQuoted);

    sc_log_info("Run: %s\n", aCommand);

    i32 status = system(aCommand);

    // DOCS: Windows: the log is printed after the script (cmd has no tee).
    if (pLogPath && msk_script_kind_is_batch(kind))
    {
        i64 logLength = 0;
        char* pLogContent = sc_file_read_ext(pLogPath, &logLength);

        if (pLogContent)
        {
            printf("%s", pLogContent);
            sc_memory_free(pLogContent);
        }
    }

    if (status != 0)
    {
        sc_log_erro("Command failed (status %d): %s\n", status, aCommand);
        return 1;
    }

    return 0;
}

static i32
msk_compiler_run_script(char* pScriptPath, MskScriptKind kind)
{
    return msk_compiler_run_script_ext(pScriptPath, kind, NULL, NULL);
}

// DOCS: Write all generated scripts into the temporary directory (build from memory).
static i32
msk_compiler_write_scripts(MskGeneratorBuildResult* pResult, char* pScriptsDirectory)
{
    if (!pResult || !pResult->pSb || !pScriptsDirectory)
        return 1;

    for (i32 r = 0; r < sc_list_count(pResult->aResults); ++r)
    {
        MskGeneratorSingleBuildResult* pSingle = &pResult->aResults[r];

        if (!pSingle->pSb || !pSingle->pScriptPath)
            continue;

        msk_script_write_file(pSingle->pScriptPath, pSingle->pSb);
    }

    char* pMainPath = msk_generator_main_script_path(pScriptsDirectory, pResult->Kind);
    if (!pMainPath)
        return 1;

    msk_script_write_file(pMainPath, pResult->pSb);
    sc_memory_free(pMainPath);

    return 0;
}

void
msk_compiler_clean(MskProject* aProjects, i32 projectsCount, char* pRootDirectory)
{
    if (!aProjects)
        return;

/* DOCS:
        Remove scripts of both kinds: the platform selection is not passed here,
        and a leftover script of the other platform must be cleaned too.
    */
    MskScriptKind aKinds[2] = {
        msk_script_kind_host(),
        msk_script_kind_host() == MskScriptKind_Batch ? MskScriptKind_Shell : MskScriptKind_Batch,
    };

    /* DOCS:
        Remove generated per-project scripts and the main script of both kinds
        (.sh and .bat: a leftover script of the other platform is removed too).
    */
    for (i32 k = 0; k < (i32)ScArrayCount(aKinds); ++k)
    {
        for (i32 p = 0; p < projectsCount; ++p)
        {
            char* pScriptPath = msk_generator_project_script_path(&aProjects[p], aKinds[k]);
            if (!pScriptPath)
                continue;

            if (sc_path(pScriptPath) == ScPathItemType_File)
            {
                sc_file_delete(pScriptPath);
                sc_log_info("Removed %s\n", pScriptPath);
            }

            sc_memory_free(pScriptPath);
        }

        char* pMainScriptPath = msk_generator_main_script_path(pRootDirectory ? pRootDirectory : ".", aKinds[k]);

        if (pMainScriptPath && sc_path(pMainScriptPath) == ScPathItemType_File)
        {
            sc_file_delete(pMainScriptPath);
            sc_log_info("Removed %s\n", pMainScriptPath);
        }

        sc_memory_free(pMainScriptPath);
    }

    // DOCS: Temporary scripts of a build from memory.
    char* pTemporaryDirectory = sc_path_combine(pRootDirectory ? pRootDirectory : ".", MSK_COMPILER_TEMPORARY_DIRECTORY);

    if (pTemporaryDirectory)
    {
        msk_compiler_clean_directory(pTemporaryDirectory);
        sc_memory_free(pTemporaryDirectory);
    }

    // DOCS: Remove object directories of every project.
    for (i32 p = 0; p < projectsCount; ++p)
        msk_compiler_clean_directory(aProjects[p].pObjDir);

    // DOCS: Remove binary directories (same directory can be shared by projects).
    for (i32 p = 0; p < projectsCount; ++p)
    {
        if (!aProjects[p].pBin)
            continue;

        i8 isDuplicate = 0;
        for (i32 q = 0; q < p; ++q)
        {
            if (aProjects[q].pBin && sc_string_compare(aProjects[q].pBin, aProjects[p].pBin))
            {
                isDuplicate = 1;
                break;
            }
        }

        if (!isDuplicate)
            msk_compiler_clean_directory(aProjects[p].pBin);
    }
}

/* DOCS:
    Run several argv commands sequentially inside one cmd.exe process:
    every command is written into a single .bat script (with the output
    redirected into the shared log), so tiny archives/links don't pay a
    cmd spawn each. Returns 0 when every command succeeded.
*/
static i32
msk_compiler_run_batched(MskArgv* aArgv, i32 argvCount, MskScriptKind kind, char* pLogPath)
{
    if (!aArgv || argvCount <= 0 || !pLogPath)
        return 1;

    char* pTmpDirectory = sc_path_get_directory(pLogPath);

    char aScriptPath[1024] = {};
    sc_format(aScriptPath, sizeof(aScriptPath), "%s/batched.bat", pTmpDirectory ? pTmpDirectory : ".");
    sc_memory_free(pTmpDirectory);

    char* pSb = NULL;
    sc_builder_append_string(pSb, "@echo off\r\n", 11);

    for (i32 i = 0; i < argvCount; ++i)
    {
        for (i32 w = 0; w < sc_list_count(aArgv[i].aWords); ++w)
        {
            char* pQuoted = msk_script_quote_word(aArgv[i].aWords[w], kind);
            if (pQuoted)
            {
                sc_builder_append_string(pSb, pQuoted, sc_string_get_length(pQuoted));
                sc_memory_free(pQuoted);
            }

            sc_builder_append_char(pSb, ' ');
        }

        sc_builder_append_string(pSb, "\r\n", 2);
    }

    msk_script_write_file(aScriptPath, pSb);
    sc_list_free(pSb);

    char aCommand[2048] = {};
    sc_format(aCommand, sizeof(aCommand), "cmd /c %s >> %s 2>&1", aScriptPath, pLogPath);

    i32 status = system(aCommand);

    if (status != 0)
        sc_log_erro("Batched command failed (status %d)\n", status);

    sc_file_delete(aScriptPath);

    return status != 0;
}
/* DOCS:
    Execute one argv command of the -pt build and measure it with sc_profiler.
    The output is redirected into the shared command log (printed after),
    so warnings/errors can be counted; the command line is echoed to it too.
    pWhat: "compile", "link" or "archive" (only for the log header).
*/
static i32
msk_compiler_run_measured(MskArgv* pArgv, MskScriptKind kind, char* pLogPath)
{
    if (!pArgv || sc_list_count(pArgv->aWords) <= 0 || !pLogPath)
        return 1;

    // DOCS: Command line: every word quoted, output appended to the shared log.
    char* pSb = NULL;

    for (i32 w = 0; w < sc_list_count(pArgv->aWords); ++w)
    {
        if (w > 0)
            sc_builder_append_char(pSb, ' ');

        char* pQuoted = msk_script_quote_word(pArgv->aWords[w], kind);
        if (pQuoted)
        {
            sc_builder_append_string(pSb, pQuoted, sc_string_get_length(pQuoted));
            sc_memory_free(pQuoted);
        }
    }

    char aCommand[4096] = {};
    sc_format(aCommand, sizeof(aCommand), "%s", pSb ? pSb : "");
    sc_list_free(pSb);

    char aRedirect[4200] = {};

    if (msk_script_kind_is_batch(kind))
        sc_format(aRedirect, sizeof(aRedirect), "cmd /c %s >> %s 2>&1", aCommand, pLogPath);
    else
        sc_format(aRedirect, sizeof(aRedirect), "(%s) >> %s 2>&1", aCommand, pLogPath);

    sc_log_info("Run: %s\n", aCommand);

    ScProfiler profiler = {};
    sc_profiler_start(&profiler);

    i32 status = system(aRedirect);

    sc_profiler_end(&profiler);

    if (status != 0)
    {
        sc_log_erro("Command failed (status %d): %s\n", status, aCommand);
        return 1;
    }

    return 0;
}

/* DOCS:
    Parallel Windows build: cmd.exe has no '&' background jobs, so masuka runs
    the commands itself through threads (sc_thread from Sc).
    The commands are split into chunks (one per thread); every chunk is written
    to its own .bat file and executed by one cmd.exe process - exactly the
    pids/wait pattern of the POSIX scripts, but driven from masuka itself.
    Every chunk writes into its own log file (several cmd.exe processes can't
    append to one file at once: Windows locks it), merged in order after the join.
*/

typedef struct
{
    char* pScriptPath;  // chunk script: <tmp>/parallel.<thread>.bat
    char* pLogPath;     // chunk log: <tmp>/parallel.<thread>.log
    i32 Status;
} MskParallelChunk;

// DOCS: Worker thread body: run one chunk script, remember its exit code.
static void*
msk_parallel_worker(void* pData)
{
    MskParallelChunk* pChunk = (MskParallelChunk*)pData;

    char aCommand[2048] = {};
    sc_format(aCommand, sizeof(aCommand), "cmd /c %s > %s 2>&1", pChunk->pScriptPath, pChunk->pLogPath);
    pChunk->Status = system(aCommand);

    return NULL;
}

/* DOCS:
    Run the argv words of several compile commands in parallel:
    split into <jobsCount> chunks, write each chunk to a .bat file and start
    one worker thread per chunk. Returns 0 when every command succeeded.
*/
static i32
msk_compiler_run_parallel(MskArgv* aArgv, i32 argvCount, MskScriptKind kind, char* pLogPath, i32 jobsCount)
{
    if (!aArgv || argvCount <= 0 || !pLogPath)
        return 1;

    if (jobsCount <= 1 || argvCount <= 1)
    {
        // DOCS: Sequential fallback: one by one, the same contract.
        for (i32 i = 0; i < argvCount; ++i)
        {
            if (msk_compiler_run_measured(&aArgv[i], kind, pLogPath) != 0)
                return 1;
        }

        return 0;
    }

    i32 chunksCount = jobsCount < argvCount ? jobsCount : argvCount;
    char* pTmpDirectory = sc_path_get_directory(pLogPath);

    MskParallelChunk* aChunks = sc_memory_allocate(sizeof(MskParallelChunk) * chunksCount);
    memset(aChunks, 0, sizeof(MskParallelChunk) * chunksCount);

    // DOCS: Build the chunk scripts: command i goes to chunk i % chunksCount.
    for (i32 i = 0; i < chunksCount; ++i)
    {
        char aScriptPath[1024] = {};
        char aChunkLogPath[1024] = {};
        sc_format(aScriptPath, sizeof(aScriptPath), "%s/parallel.%d.bat", pTmpDirectory ? pTmpDirectory : ".", i);
        sc_format(aChunkLogPath, sizeof(aChunkLogPath), "%s/parallel.%d.log", pTmpDirectory ? pTmpDirectory : ".", i);

        i64 scriptLength = sc_string_get_length(aScriptPath);
        aChunks[i].pScriptPath = sc_memory_allocate(scriptLength + 1);
        memcpy(aChunks[i].pScriptPath, aScriptPath, scriptLength + 1);

        i64 logLength = sc_string_get_length(aChunkLogPath);
        aChunks[i].pLogPath = sc_memory_allocate(logLength + 1);
        memcpy(aChunks[i].pLogPath, aChunkLogPath, logLength + 1);

        aChunks[i].Status = 0;
    }

    for (i32 i = 0; i < chunksCount; ++i)
    {
        char* pSb = NULL;
        sc_builder_append_string(pSb, "@echo off\r\n", 11);

        for (i32 j = i; j < argvCount; j += chunksCount)
        {
            for (i32 w = 0; w < sc_list_count(aArgv[j].aWords); ++w)
            {
                char* pQuoted = msk_script_quote_word(aArgv[j].aWords[w], kind);
                if (pQuoted)
                {
                    sc_builder_append_string(pSb, pQuoted, sc_string_get_length(pQuoted));
                    sc_memory_free(pQuoted);
                }

                sc_builder_append_char(pSb, ' ');
            }

            sc_builder_append_string(pSb, "\r\n", 2);
        }

        msk_script_write_file(aChunks[i].pScriptPath, pSb);
        sc_list_free(pSb);
    }

    sc_memory_free(pTmpDirectory);

    // DOCS: One worker thread per chunk, then join them all.
    ScThread* aThreads = sc_memory_allocate(sizeof(ScThread) * chunksCount);

    for (i32 t = 0; t < chunksCount; ++t)
        aThreads[t] = sc_thread_create(msk_parallel_worker, 0, &aChunks[t]);

    for (i32 t = 0; t < chunksCount; ++t)
        sc_thread_attach(aThreads[t]);

    i32 result = 0;

    /* DOCS:
        Merge the chunk logs into the shared log in the original order:
        the build summary reads warnings/errors from the shared log.
    */
    for (i32 i = 0; i < chunksCount; ++i)
    {
        if (aChunks[i].Status != 0)
        {
            sc_log_erro("Parallel chunk %d failed (status %d)\n", i, aChunks[i].Status);
            result = 1;
        }

        i64 chunkLogLength = 0;
        char* pChunkLog = sc_file_read_ext(aChunks[i].pLogPath, &chunkLogLength);

        if (pChunkLog)
        {
            sc_file_append_string(pLogPath, pChunkLog, chunkLogLength);
            sc_memory_free(pChunkLog);
        }

        sc_file_delete(aChunks[i].pLogPath);
        sc_memory_free(aChunks[i].pLogPath);
        sc_file_delete(aChunks[i].pScriptPath);
        sc_memory_free(aChunks[i].pScriptPath);
    }

    sc_memory_free(aThreads);
    sc_memory_free(aChunks);

    return result;
}


/* DOCS:
    -pt build: masuka itself runs every compile/archive/link command (no scripts),
    measures each one with sc_profiler and prints the perf report at the end.
    Projects are already sorted dependencies-first: a plain loop is the build order.
*/
static i32
msk_compiler_compile_measured(MskCompilerConfig cfg)
{
    if (cfg.ProjectsCount <= 0 || cfg.aProjects == ScNull)
    {
        sc_log_info("Nothing to build: workspace has no projects\n");
        return 0;
    }

    if (!cfg.pRootDirectory)
    {
        sc_log_erro("Can't build: workspace directory is unknown\n");
        return 1;
    }

    /* DOCS:
        Shared command log of the measured build: output of every command
        is appended here, echoed at the end and parsed for diagnostics.
    */
    char* pLogPath = msk_compiler_log_path(cfg.pRootDirectory);

    if (!pLogPath)
        return 1;

    char* pLogDirectory = sc_path_get_directory(pLogPath);
    if (pLogDirectory && sc_path(pLogDirectory) == ScPathItemType_Undefined)
        sc_directory_create_recursive(pLogDirectory);
    sc_memory_free(pLogDirectory);

    if (sc_path(pLogPath) == ScPathItemType_File)
        sc_file_delete(pLogPath);

    MskPerfLog perfLog = {};
    i32 result = 0;

    for (i32 p = 0; p < cfg.ProjectsCount && result == 0; ++p)
    {
        MskProject* pProject = &cfg.aProjects[p];

        // DOCS: Object and bin directories of the project (the scripts' mkdir steps).
        char** aObjectDirectories = NULL;

        for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
        {
            char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
            char* pObjectDirectory = pObject ? sc_path_get_directory(pObject) : NULL;
            sc_memory_free(pObject);

            if (!pObjectDirectory)
                continue;

            i8 isDuplicate = 0;
            for (i32 d = 0; d < sc_list_count(aObjectDirectories); ++d)
            {
                if (sc_string_compare(aObjectDirectories[d], pObjectDirectory))
                {
                    isDuplicate = 1;
                    break;
                }
            }

            if (isDuplicate)
            {
                sc_memory_free(pObjectDirectory);
                continue;
            }

            sc_list_add(aObjectDirectories, pObjectDirectory);
        }

        for (i32 d = 0; d < sc_list_count(aObjectDirectories); ++d)
        {
            sc_directory_create_recursive(aObjectDirectories[d]);
            sc_memory_free(aObjectDirectories[d]);
        }
        sc_list_free(aObjectDirectories);

        if (pProject->pBin)
            sc_directory_create_recursive(pProject->pBin);

        ScProfiler projectProfiler = {};
        sc_profiler_start(&projectProfiler);

        /* DOCS:
            Compile every TU, measured with sc_profiler (incremental check:
            a TU is skipped when its object exists and is newer).
        */
        for (i32 s = 0; s < sc_list_count(pProject->aSources) && result == 0; ++s)
        {
            char* pSource = pProject->aSources[s].pName;
            if (!pSource)
                continue;

            if (!msk_cli_source_needs_recompile(pProject, pSource))
                continue;

            MskArgv argv = msk_generator_compile_argv(pProject, pSource, cfg.pRootDirectory, 0, cfg.Kind);

            ScProfiler profiler = {};
            sc_profiler_start(&profiler);

            i32 commandResult = msk_compiler_run_measured(&argv, cfg.Kind, pLogPath);

            sc_profiler_end(&profiler);
            msk_argv_free(&argv);

            if (commandResult != 0)
            {
                result = 1;
                break;
            }

            msk_perf_add(&perfLog.aCompile, pSource, sc_profiler_get_milliseconds(&profiler));
        }

        // DOCS: Archive/link step, measured the same way.
        if (result == 0)
        {
            MskArgv command = {};

            if (pProject->Type == MskProjectType_StaticLib)
                command = msk_generator_archive_argv(pProject, cfg.pRootDirectory, 0, cfg.Kind);
            else
                command = msk_generator_link_argv(cfg.aProjects, cfg.ProjectsCount, pProject, cfg.pRootDirectory, 0, cfg.Kind);

            // DOCS: Remove the old output first (the scripts' rm/del step).
            char* pTarget = msk_generator_target_path(pProject, cfg.pRootDirectory, 0, cfg.Kind);
            if (pTarget)
            {
                if (sc_path(pTarget) == ScPathItemType_File)
                    sc_file_delete(pTarget);
                sc_memory_free(pTarget);
            }

            ScProfiler profiler = {};
            sc_profiler_start(&profiler);

            i32 commandResult = msk_compiler_run_measured(&command, cfg.Kind, pLogPath);

            sc_profiler_end(&profiler);
            msk_argv_free(&command);

            if (commandResult != 0)
            {
                result = 1;
            }
            else
            {
                msk_perf_add(&perfLog.aLink, pProject->pName, sc_profiler_get_milliseconds(&profiler));
            }
        }

        sc_profiler_end(&projectProfiler);
        msk_perf_add(&perfLog.aProject, pProject->pName, sc_profiler_get_milliseconds(&projectProfiler));
    }

    // DOCS: Print the captured output of every command (it was hidden by redirect).
    {
        i64 logLength = 0;
        char* pLogContent = sc_file_read_ext(pLogPath, &logLength);

        if (pLogContent)
        {
            printf("%s", pLogContent);
            msk_perf_parse_diagnostics(&perfLog, pLogContent);
            sc_memory_free(pLogContent);
        }
    }

    // DOCS: Full report: summary, target sizes and the timings tree.
    msk_perf_report(cfg.aProjects, cfg.ProjectsCount, &perfLog, result == 0);
    msk_perf_free(&perfLog);

    sc_file_delete(pLogPath);
    sc_memory_free(pLogPath);

    return result;
}
/* DOCS:
    Parallel build (Windows: batch scripts have no background jobs, so masuka
    runs the commands itself; Linux host uses the shell scripts instead).
    The same two parallelism levels as the POSIX scripts (M4-2):
    - projects of one dependency level (wave) build in parallel;
    - translation units of one project compile in parallel (jobs / chunk).
    Incremental checks are the same as in the scripts (M4-5).
*/
static i32
msk_compiler_compile_parallel(MskCompilerConfig cfg)
{
    if (cfg.ProjectsCount <= 0 || cfg.aProjects == ScNull)
    {
        sc_log_info("Nothing to build: workspace has no projects\n");
        return 0;
    }

    if (!cfg.pRootDirectory)
    {
        sc_log_erro("Can't build: workspace directory is unknown\n");
        return 1;
    }

    char* pLogPath = msk_compiler_log_path(cfg.pRootDirectory);

    if (!pLogPath)
        return 1;

    char* pLogDirectory = sc_path_get_directory(pLogPath);
    if (pLogDirectory && sc_path(pLogDirectory) == ScPathItemType_Undefined)
        sc_directory_create_recursive(pLogDirectory);
    sc_memory_free(pLogDirectory);

    if (sc_path(pLogPath) == ScPathItemType_File)
        sc_file_delete(pLogPath);

    i32 jobs = cfg.JobsCount > 0 ? cfg.JobsCount : 1;

    /* DOCS:
        Dependency levels of every project (msk_projects_levels): projects of
        one level are independent and may be built in parallel (M4-2).
    */
    i32* aLevels = sc_memory_allocate(sizeof(i32) * cfg.ProjectsCount);
    msk_projects_levels(cfg.aProjects, cfg.ProjectsCount, aLevels);

    i32 levelsCount = 0;
    for (i32 p = 0; p < cfg.ProjectsCount; ++p)
    {
        if (aLevels[p] + 1 > levelsCount)
            levelsCount = aLevels[p] + 1;
    }

    MskPerfLog perfLog = {};
    i32 result = 0;

    for (i32 level = 0; level < levelsCount && result == 0; ++level)
    {
        i32 waveCount = 0;

        for (i32 p = 0; p < cfg.ProjectsCount; ++p)
        {
            if (aLevels[p] == level)
                ++waveCount;
        }

        if (waveCount <= 0)
            continue;

        if (waveCount > 1)
            sc_log_info("Level %d: %d project(s) in parallel\n", level + 1, waveCount);

        /* DOCS:
            Phase 1: collect the compile commands of every project of the wave
            into one shared pool - all translation units of the whole wave
            compete for the same -j threads, exactly like the POSIX scripts.
        */
        MskArgv* aWaveArgv = NULL;
        i32 waveCommandsCount = 0;

        for (i32 p = 0; p < cfg.ProjectsCount && result == 0; ++p)
        {
            if (aLevels[p] != level)
                continue;

            MskProject* pProject = &cfg.aProjects[p];

            /* DOCS:
                Object and bin directories of the project (the scripts' mkdir steps).
            */
            char** aObjectDirectories = NULL;

            for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
            {
                char* pObject = msk_project_object_path(pProject, pProject->aSources[s].pName);
                char* pObjectDirectory = pObject ? sc_path_get_directory(pObject) : NULL;
                sc_memory_free(pObject);

                if (!pObjectDirectory)
                    continue;

                i8 isDuplicate = 0;
                for (i32 d = 0; d < sc_list_count(aObjectDirectories); ++d)
                {
                    if (sc_string_compare(aObjectDirectories[d], pObjectDirectory))
                    {
                        isDuplicate = 1;
                        break;
                    }
                }

                if (isDuplicate)
                {
                    sc_memory_free(pObjectDirectory);
                    continue;
                }

                sc_list_add(aObjectDirectories, pObjectDirectory);
            }

            for (i32 d = 0; d < sc_list_count(aObjectDirectories); ++d)
            {
                sc_directory_create_recursive(aObjectDirectories[d]);
                sc_memory_free(aObjectDirectories[d]);
            }
            sc_list_free(aObjectDirectories);

            if (pProject->pBin)
                sc_directory_create_recursive(pProject->pBin);

            /* DOCS:
                Compile every TU that needs it (incremental, M4-5): the argv of
                every command is built up front and queued into the wave pool.
            */
            i32 projectCommandsCount = 0;

            for (i32 s = 0; s < sc_list_count(pProject->aSources); ++s)
            {
                char* pSource = pProject->aSources[s].pName;
                if (!pSource)
                    continue;

                if (!msk_cli_source_needs_recompile(pProject, pSource))
                    continue;

                MskArgv argv = msk_generator_compile_argv(pProject, pSource, cfg.pRootDirectory, 0, cfg.Kind);
                sc_list_add(aWaveArgv, argv);
                ++projectCommandsCount;
                ++waveCommandsCount;
            }

            if (projectCommandsCount > 0)
                sc_log_info("[%s] compiling %d translation unit(s)\n", pProject->pName, projectCommandsCount);
        }

        if (waveCommandsCount > 0)
        {
            if (msk_compiler_run_parallel(aWaveArgv, waveCommandsCount, cfg.Kind, pLogPath, jobs) != 0)
                result = 1;
        }

        for (i32 i = 0; i < waveCommandsCount; ++i)
            msk_argv_free(&aWaveArgv[i]);
        sc_list_free(aWaveArgv);

        /* DOCS:
            Phase 2: archive/link step of every project of the wave (all links
            of the wave in one chunk script: it needs every object of its
            project, and every compile of the wave has finished by now).
        */
        MskArgv* aLinkArgv = NULL;
        i32 linkCommandsCount = 0;

        for (i32 p = 0; p < cfg.ProjectsCount && result == 0; ++p)
        {
            if (aLevels[p] != level)
                continue;

            MskProject* pProject = &cfg.aProjects[p];

            MskArgv command = {};

            if (pProject->Type == MskProjectType_StaticLib)
                command = msk_generator_archive_argv(pProject, cfg.pRootDirectory, 0, cfg.Kind);
            else
                command = msk_generator_link_argv(cfg.aProjects, cfg.ProjectsCount, pProject, cfg.pRootDirectory, 0, cfg.Kind);

            char* pTarget = msk_generator_target_path(pProject, cfg.pRootDirectory, 0, cfg.Kind);
            if (pTarget)
            {
                if (sc_path(pTarget) == ScPathItemType_File)
                    sc_file_delete(pTarget);
                sc_memory_free(pTarget);
            }

            sc_list_add(aLinkArgv, command);
            ++linkCommandsCount;
        }

        if (linkCommandsCount > 0)
        {
            if (msk_compiler_run_batched(aLinkArgv, linkCommandsCount, cfg.Kind, pLogPath) != 0)
                result = 1;

            for (i32 i = 0; i < linkCommandsCount; ++i)
                msk_argv_free(&aLinkArgv[i]);
        }

        sc_list_free(aLinkArgv);
    }

    sc_memory_free(aLevels);

    /* DOCS:
        Print the captured output of every command (it was hidden by redirect).
    */
    {
        i64 logLength = 0;
        char* pLogContent = sc_file_read_ext(pLogPath, &logLength);

        if (pLogContent)
        {
            printf("%s", pLogContent);
            msk_perf_parse_diagnostics(&perfLog, pLogContent);
            sc_memory_free(pLogContent);
        }
    }

    /* DOCS:
        Build summary: success/warnings/errors + target sizes (M5).
    */
    msk_perf_report(cfg.aProjects, cfg.ProjectsCount, &perfLog, result == 0);
    msk_perf_free(&perfLog);

    sc_file_delete(pLogPath);
    sc_memory_free(pLogPath);

    return result;
}

i32
msk_compiler_compile(MskCompilerConfig cfg)
{
    if (cfg.ProjectsCount <= 0 || cfg.aProjects == ScNull)
    {
        sc_log_info("Nothing to build: workspace has no projects\n");
        return 0;
    }

    if (!cfg.pRootDirectory)
    {
        sc_log_erro("Can't build: workspace directory is unknown\n");
        return 1;
    }

    /* DOCS:
         Build from memory (section 7): scripts go to a temporary directory, are executed
        and removed afterwards, so nothing appears next to the sources.
    */
    char* pScriptsDirectory = sc_path_combine(cfg.pRootDirectory, MSK_COMPILER_TEMPORARY_DIRECTORY);

    if (!pScriptsDirectory)
        return 1;

    MskGeneratorBuildConfig buildCfg = {
        .aProjects = cfg.aProjects,
        .ProjectsCount = cfg.ProjectsCount,
        .JobsCount = cfg.JobsCount,
        .Kind = cfg.Kind,
        .pRootDirectory = cfg.pRootDirectory,
        .pBuild = cfg.pBuild,
        .pPlatform = cfg.pPlatform,
        .pScriptsDirectory = pScriptsDirectory,
    };

    MskGeneratorBuildResult buildResult = msk_generator_build_create(buildCfg);
    i32 result = 0;
    char* pLogFile = NULL;

    if (!buildResult.pSb)
    {
        sc_log_erro("Can't generate build scripts!\n");
        result = 1;
    }
    else if (msk_compiler_write_scripts(&buildResult, pScriptsDirectory) != 0)
    {
        sc_log_erro("Can't write temporary build scripts!\n");
        result = 1;
    }
    else
    {
        char* pMainScript = msk_generator_main_script_path(pScriptsDirectory, cfg.Kind);
        result = msk_compiler_run_script_ext(pMainScript, cfg.Kind, cfg.pRootDirectory, &pLogFile);
        sc_memory_free(pMainScript);
    }

    // DOCS: Build summary: success/warnings/errors + target size; -pt adds timings.
    if (pLogFile)
    {
        MskPerfLog perfLog = msk_perf_parse_log(pLogFile);
        msk_perf_report(cfg.aProjects, cfg.ProjectsCount, &perfLog, result == 0);
        msk_perf_free(&perfLog);
        sc_file_delete(pLogFile);
        sc_memory_free(pLogFile);
    }

    // DOCS: Temporary scripts are removed even when the build failed.
    sc_directory_delete_recursive(pScriptsDirectory);

    for (i32 r = 0; r < sc_list_count(buildResult.aResults); ++r)
    {
        sc_list_free(buildResult.aResults[r].pSb);
        sc_memory_free(buildResult.aResults[r].pScriptPath);
    }

    sc_list_free(buildResult.aResults);
    sc_list_free(buildResult.pSb);
    sc_memory_free(pScriptsDirectory);

    return result;
}

i32
msk_compiler_compile_from_scripts(MskCompilerScriptsConfig cfg)
{
    if (!cfg.pRootDirectory)
    {
        sc_log_erro("Can't build: workspace directory is unknown\n");
        return 1;
    }

    char* pMainScript = msk_generator_main_script_path(cfg.pRootDirectory, cfg.Kind);

    if (!pMainScript)
        return 1;

    if (sc_path(pMainScript) != ScPathItemType_File)
    {
        sc_log_erro("Build script '%s' doesn't exist. Run `masuka -gb` to generate it.\n", pMainScript);
        sc_memory_free(pMainScript);
        return 1;
    }

    char* pLogFile = NULL;
    i32 result = msk_compiler_run_script_ext(pMainScript, cfg.Kind, cfg.pRootDirectory, &pLogFile);
    sc_memory_free(pMainScript);

    // DOCS: Build summary: success/warnings/errors + target size.
    if (pLogFile)
    {
        MskPerfLog perfLog = msk_perf_parse_log(pLogFile);
        msk_perf_report(cfg.aProjects, cfg.ProjectsCount, &perfLog, result == 0);
        msk_perf_free(&perfLog);
        sc_file_delete(pLogFile);
        sc_memory_free(pLogFile);
    }

    return result;
}
/*
   DOCS: Masuka runner
    Run the built projects through system() (see section 7): the
    bin/{build}-{platform}/{project}[.exe] path is built by msk_generator_target_path,
    cwd - the workspace root, so the program sees relative paths.
*/

// DOCS: Path of the built executable of a project: <bin>/<name>[.exe] (sc_memory_free).
static char*
msk_runner_program_path(MskProject* pProject, MskScriptKind Kind)
{
    return msk_generator_target_path(pProject, NULL, 0, Kind);
}

/* DOCS:
    Build the run command: cd into the workspace root, quoted program path,
    then the raw -a string as is (M5-2 parses it into argv).
    Returns raw allocated memory (sc_memory_free).
*/
static char*
msk_runner_command_create(MskRunnerConfig cfg, char* pProgramPath)
{
    char* pSb = NULL;

    // DOCS: Start from the workspace root: relative paths of the program still work.
    if (cfg.pRootDirectory && cfg.pRootDirectory[0] != '\0')
    {
        if (cfg.Kind == MskScriptKind_Batch)
            msk_script_append_literal(&pSb, "cd /d");
        else
            msk_script_append_literal(&pSb, "cd");

        msk_script_append_word(&pSb, cfg.pRootDirectory, cfg.Kind);
        msk_script_append_literal(&pSb, " && ");
    }

    msk_script_append_word(&pSb, pProgramPath, cfg.Kind);

    /* DOCS:
        -a words are already parsed (msk_cli_parse_program_arguments):
        every word is quoted as a single argv element.
    */
    for (i32 w = 0; w < sc_list_count(cfg.aProgramArguments); ++w)
        msk_script_append_word(&pSb, cfg.aProgramArguments[w], cfg.Kind);

    char* pResult = sc_string_copy(pSb, sc_builder_count(pSb));
    sc_list_free(pSb);
    return pResult;
}

i32
msk_runner_run_program(MskRunnerConfig cfg)
{
    if (!cfg.pProject || !cfg.pProject->pName)
    {
        sc_log_erro("No project to run\n");
        return 1;
    }

    if (cfg.pProject->Type != MskProjectType_Executable)
    {
        sc_log_erro("Project '%s' is %s, not an executable\n",
            cfg.pProject->pName,
            msk_project_type_to_string(cfg.pProject->Type));
        return 1;
    }

    char* pProgramPath = msk_runner_program_path(cfg.pProject, cfg.Kind);
    if (!pProgramPath)
    {
        sc_log_erro("Project '%s' has no 'bin' path to run from\n", cfg.pProject->pName);
        return 1;
    }

    if (sc_path(pProgramPath) != ScPathItemType_File)
    {
        sc_log_erro("Program '%s' doesn't exist. Build it first (masuka or masuka -rb).\n", pProgramPath);
        sc_memory_free(pProgramPath);
        return 1;
    }

    char* pCommand = msk_runner_command_create(cfg, pProgramPath);
    sc_memory_free(pProgramPath);

    if (!pCommand)
    {
        sc_log_erro("Can't build a run command for project '%s'\n", cfg.pProject->pName);
        return 1;
    }

    sc_log_info("Run: %s\n", pCommand);

    i32 status = system(pCommand);
    sc_memory_free(pCommand);

    // DOCS: Exit code of the process goes to the outside (spec): success is 0 only.
    if (status != 0)
    {
        sc_log_erro("Program '%s' failed (status %d)\n", cfg.pProject->pName, status);
        return 1;
    }

    return 0;
}

// DOCS: Run all Executable projects of the workspace: -t (extension outside the spec).
i32
msk_runner_run_tests(MskTestRunnerConfig cfg)
{
    if (!cfg.aProjects || cfg.ProjectsCount <= 0)
    {
        sc_log_info("No projects to test\n");
        return 0;
    }

    if (!cfg.pRootDirectory)
    {
        sc_log_erro("Can't run tests: workspace directory is unknown\n");
        return 1;
    }

    i32 result = 0;

    for (i32 p = 0; p < cfg.ProjectsCount; ++p)
    {
        MskProject* pProject = &cfg.aProjects[p];

        // DOCS: Test projects are executables (spec: -e "test" runs the test project).
        if (!pProject->pName || pProject->Type != MskProjectType_Executable)
            continue;

        MskRunnerConfig runCfg = {
            .pProject = pProject,
            .pRootDirectory = cfg.pRootDirectory,
            .Kind = cfg.Kind,
        };

        sc_log_info("Test: %s\n", pProject->pName);

        if (msk_runner_run_program(runCfg) != 0)
        {
            sc_log_erro("Test '%s' failed\n", pProject->pName);
            result = 1;
        }
    }

    if (result == 0)
        sc_log_info("All tests passed\n");

    return result;
}

/*
   DOCS: Masuka utils
*/

char*
msk_parse_next_single_value(char** ppRead, char* pC)
{
    char* pRead = *ppRead;
    char c = *pRead;
    sc_ptr_skip_until(pRead, c, ':');
    while (c != '\0' && !msk_language_is_identifier(c))
    {
        sc_ptr_next(pRead, c);
    }
    char* pWordStart = pRead;
    while (c != '\0' && c != '"' && c != ':' && !sc_char_is_whitespace(c))
    {
        sc_ptr_next(pRead, c);
    }
    i64 wordLength = sc_ptr_diff(pWordStart, pRead) - 1;
    *ppRead = pRead;
    *pC = c;
    return sc_string_new_ext(pWordStart, wordLength, wordLength);
}

char*
msk_parse_next_single_path(MskVariable* aVariables, char** ppRead, char* pC)
{
    sc_guard_not_used();

    char* pRead = *ppRead;
    char c = *pRead;
    sc_ptr_skip_until(pRead, c, ':');
    while (c != '\0' && c != '"')
        sc_ptr_next(pRead, c);
    ++pRead;
    c = *pRead;
    char* pWordStart = pRead;
    while (c != '\0' && c != '"')
        sc_ptr_next(pRead, c);
    char* pWordEnd = pRead;
    i64 wordLength = sc_ptr_diff(pWordStart, pRead) - 1;
    *ppRead = pRead;
    *pC = c;
    return NULL; // msk_preprocess_string(aVariables, pWordStart, wordLength);
}

char*
msk_parse_next_id(char** ppRead, char* pC)
{
    char* pRead = *ppRead;
    char c = *pRead;

    while (c != '\0' && !msk_language_is_identifier(c))
        sc_ptr_next(pRead, c);
    char* pWordStart = pRead;
    while (c != '\0' && msk_language_is_identifier(c))
        sc_ptr_next(pRead, c);
    char* pWordEnd = pRead;
    i64 wordLength = sc_ptr_diff(pWordStart, pRead) - 1;

    *ppRead = pRead;
    *pC = c;

    char* pId = sc_string_new_ext(pWordStart, wordLength, wordLength);
    return pId;
}

MskString*
msk_parse_next_array(char** ppRead, char* pC)
{
    MskString* aFiles = NULL;

    char* pRead = *ppRead;
    char c = *pRead;

    while (c != '\0' && c != '[')
        sc_ptr_next(pRead, c);

    while (c != '\0' && c != ']')
    {
        if (c == '"')
        {
            ++pRead;
            char* pWordStart = pRead;
            while (*pRead != '\0' && *pRead != '"')
            {
                ++pRead;
            }
            char* pWordEnd = pRead;
            i64 wordLength = sc_ptr_diff(pWordStart, pRead) - 1;

            char* pStr = sc_string_new_ext(pWordStart, wordLength, wordLength);

            MskString mskFile = {
                .pName = pStr
            };
            sc_list_add(aFiles, mskFile);
        }

        ++pRead;
        c = *pRead;
    }

    *ppRead = pRead;
    *pC = c;

    return aFiles;
}

char*
msk_preprocess_string(MskVariable* aVariables, i64 variablesCount, char* pString, i64 stringLength)
{
    // note: this string is already sc_string_new()-allocated.
    if (!pString || stringLength <= 0)
        return pString;

    if (!aVariables || variablesCount <= 0)
        return pString;

    // DOCS: Most strings don't contain variables at all: return them as is, without allocation.
    if (!memchr(pString, '{', stringLength))
        return pString;

    char* sb = NULL;

    for (i64 i = 0; i < stringLength; ++i)
    {
        char c = pString[i];

        switch (c)
        {
        case '{':
        {
            char* pVarStart = pString + i + 1;
            i64 endRelativeInd = sc_string_index_of(pVarStart, '}');

            // DOCS: Unclosed '{' is not a variable: keep it as a plain character.
            if (endRelativeInd < 0)
            {
                sc_builder_append_char(sb, c);
                break;
            }

            i8 isFindVariable = 0;
            i64 varLength = endRelativeInd;

            // get variable name
            for (i64 v = 0; v < variablesCount; ++v)
            {
                MskVariable var = aVariables[v];

                if (!var.pKey || !var.pValue)
                    continue;

                if (varLength != sc_string_get_length(var.pKey))
                    continue;

                if (!sc_string_compare_ext(var.pKey, pVarStart, varLength))
                    continue;

                // put variable value into sb
                sc_builder_append_format(sb, "%s", var.pValue);
                isFindVariable = 1;
                break;
            }

            if (!isFindVariable)
            {
                // note: sc_format doesn't support %.*s, so copy the name into a buffer.
                char aNameBuffer[128] = {};
                i64 nameLength = varLength < (i64)sizeof(aNameBuffer) - 1 ? varLength : (i64)sizeof(aNameBuffer) - 1;
                memcpy(aNameBuffer, pVarStart, nameLength);

                sc_log_erro("No variable declared with name %s\n", aNameBuffer);

                sc_list_for_each(aVariables, pVar)
                {
                    sc_log_warn("%s = %s\n",
                        pVar->pKey ? pVar->pKey : "<null>",
                        pVar->pValue ? pVar->pValue : "<null>");
                }
            }

            i = i + 1 + endRelativeInd;

            break;
        }

        case '}':
            break;

        default:
        {
            sc_builder_append_char(sb, c);
            break;
        }
        }
    }

    // DOCS: Empty result must stay a valid (empty) string, not NULL.
    char* pPreprocessedString = sb ? sc_string_new(sb) : sc_string_new("");
    sc_builder_destroy(sb);

    return pPreprocessedString;
}

/*
   DOCS: Path utils: match a file name against a simple mask (*.c) and collect
   DOCS: files recursively from a directory.
*/

i32
msk_file_regex_match(char* pInput, char* pPattern)
{
    i64 patternLength = sc_string_get_length(pPattern);
    i64 inputLength = sc_string_get_length(pInput);
    char* pPatternEnd = pPattern + patternLength;
    char* pInputEnd = pInput + inputLength;

    i32 isLengthEqual = inputLength == patternLength;

    while (patternLength >= 0)
    {
        char patternC = *pPatternEnd;
        char inputC = *pInputEnd;

        if (patternC == '*')
        {
            return 1;
        }
        else if (patternC != inputC)
        {
            return 0;
        }

        --patternLength;
        --pPatternEnd;
        --pInputEnd;
    }

    return isLengthEqual;
}

char**
msk_get_all_files_from_directory(char* pDirectory, char* pPattern)
{
    char** aFiles = NULL;

    char* pRoot = pDirectory;

    char** aSearchDirectories = NULL;
    sc_list_add(aSearchDirectories, sc_string_copy(pDirectory, sc_string_get_length(pDirectory)));

    while (sc_list_count(aSearchDirectories) > 0)
    {
        i32 dirInd = sc_list_count(aSearchDirectories) - 1;
        char* pSelectedDirectory = aSearchDirectories[dirInd];
        sc_list_header(aSearchDirectories)->Count -= 1;

        ScDirectoryGetConfig cfg = {
            .IsAbsolutePath = 0,
            .Type = ScDirectoryItemType_None
        };
        ScDirectoryItem* aItems = sc_directory_get_items(pSelectedDirectory, cfg);

        for (i32 i = 0; i < sc_list_count(aItems); ++i)
        {
            ScDirectoryItem item = aItems[i];
            char* pAbsolute = sc_path_combine(pSelectedDirectory, item.pPath);
            switch (item.Type)
            {
            case ScDirectoryItemType_File:
                if (msk_file_regex_match(item.pPath, pPattern))
                    sc_list_add(aFiles, pAbsolute);
                break;
            case ScDirectoryItemType_Directory:
            {
                sc_list_add(aSearchDirectories, pAbsolute);
                break;
            }
            default:
                break;
            }
        }

        sc_memory_free(pSelectedDirectory);
        sc_list_free(aItems);
    }

    return aFiles;
}
