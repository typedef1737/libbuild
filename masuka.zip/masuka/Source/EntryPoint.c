#include "Sc/Sc.h"
#include "Tools/Masuka.h"
#include <stdio.h>
#include <stdlib.h>

i32
main(i32 argumentsCount, char** aArguments)
{
    return msk_cli_start(argumentsCount, aArguments);
}
