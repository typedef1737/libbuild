#include "Sc.h"
#include "Masuka.h"
#include <stdio.h>
#include <stdlib.h>

i32
main(i32 argumentsCount, char** aArguments)
{
    // DOCS: Unbuffered stdout: when the process crashes, the log written so far
    // is not lost inside the stdio buffer (important for build diagnostics).
    setvbuf(stdout, NULL, _IONBF, 0);

    return msk_cli_start(argumentsCount, aArguments);
}
