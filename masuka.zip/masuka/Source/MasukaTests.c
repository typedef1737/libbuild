/*
   DOCS: MasukaTests - unit tests of the Masuka build system.
   Standalone test executable (masuka-test): CLI parsing, language parsers,
   preprocessor, project graph, script generator, compiler wrapper.

   DOCS: The original --self-test flag was removed: a build system must not
   DOCS: test itself. Tests live in their own translation unit and binary.
*/

#if defined(SC_PLATFORM_LINUX)
// DOCS: POSIX declarations (dup2/fileno) for the quiet negative-build test.
#define _POSIX_C_SOURCE 200809L
#endif // SC_PLATFORM_LINUX

#include "MasukaTests.h"
#include "Masuka.h"
#include "Sc.h"
#include "Test.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(SC_PLATFORM_LINUX)
#include <unistd.h>
#endif // SC_PLATFORM_LINUX

#define MSK_TESTS_TEMPORARY_DIRECTORY ".tmp-masuka-tests"

static void
msk_tests_cleanup(void)
{
    if (sc_path(MSK_TESTS_TEMPORARY_DIRECTORY) == ScPathItemType_Directory)
        sc_directory_delete_recursive(MSK_TESTS_TEMPORARY_DIRECTORY);
}

static void
msk_tests_write_file(char* pPath, char* pContent)
{
    char* pDirectory = sc_path_get_directory(pPath);
    if (pDirectory)
    {
        sc_directory_create_recursive(pDirectory);
        sc_memory_free(pDirectory);
    }

    sc_file_write(pPath, pContent, sc_string_get_length(pContent));
}

static char*
msk_tests_variable_value(MskVariable* aVariables, char* pKey)
{
    for (i32 v = 0; v < sc_list_count(aVariables); ++v)
    {
        if (aVariables[v].pKey && sc_string_compare(aVariables[v].pKey, pKey))
            return aVariables[v].pValue;
    }

    return NULL;
}

static void
msk_tests_cli_parse_args(void)
{
    char* aArguments[] = {
        "masuka",
        "-b",
        "release",
        "-p",
        "windows",
        "-j",
        "4",
        "-nc",
        "-gb",
        "-d",
        "some/dir",
        "-e",
        "proj",
        "-a",
        "arg0=\"0\" arg1='1'",
    };

    MskCliConfig cfg = msk_cli_parse_args((i32)ScArrayCount(aArguments), aArguments);

    sc_test_i32_equal(cfg.IsBuildExplicit, 1);
    sc_test_string_equals(cfg.pBuild, "release");
    sc_test_i32_equal(cfg.IsPlatformExplicit, 1);
    sc_test_string_equals(cfg.pPlatform, "windows");
    sc_test_i32_equal(cfg.IsJobsExplicit, 1);
    sc_test_string_equals(cfg.pJobs, "4");
    sc_test_i32_equal(cfg.IsCompile, 0);
    sc_test_i32_equal(cfg.IsGenerateBuildFiles, 1);
    sc_test_i32_equal(cfg.IsDirectoryExplicit, 1);
    sc_test_string_equals(cfg.pDirectory, "some/dir");
    sc_test_i32_equal(cfg.IsEntryExplicit, 1);
    sc_test_string_equals(cfg.pEntryName, "proj");
    sc_test_i32_equal(cfg.IsExecute, 1);
    sc_test_i32_equal(cfg.IsArgumentsExplicit, 1);
    sc_test_string_equals(cfg.pProgramArguments, "arg0=\"0\" arg1='1'");
    sc_test_i32_equal(cfg.IsArgumentsLengthExplicit, 0);
}

static void
msk_tests_cli_parse_args_special(void)
{
    char* aHelp[] = { "masuka", "--help" };
    MskCliConfig helpConfig = msk_cli_parse_args(2, aHelp);
    sc_test_i32_equal(helpConfig.IsHelp, 1);

    char* aShortHelp[] = { "masuka", "-h" };
    MskCliConfig shortHelpConfig = msk_cli_parse_args(2, aShortHelp);
    sc_test_i32_equal(shortHelpConfig.IsHelp, 1);

    char* aUnknown[] = { "masuka", "--wat" };
    MskCliConfig unknownConfig = msk_cli_parse_args(2, aUnknown);
    sc_test_string_equals(unknownConfig.pUnknownArgument, "--wat");

    // DOCS: A value that looks like a flag is still a value of the previous flag.
    char* aDashValue[] = { "masuka", "-e", "-x" };
    MskCliConfig dashValueConfig = msk_cli_parse_args(3, aDashValue);
    sc_test_string_equals(dashValueConfig.pEntryName, "-x");
}

static void
msk_tests_cli_validate_arguments(void)
{
    // DOCS: -a{N}: declared length is greater than actual -> actual is used.
    char* aShort[] = { "masuka", "-a5", "abc" };
    MskCliConfig shortConfig = msk_cli_parse_args(3, aShort);
    ScResult shortResult = msk_cli_validate_args(&shortConfig, NULL, NULL, 0);
    sc_test_i32_equal(shortResult, ScResult_Success);
    sc_test_i32_equal((i32)shortConfig.ProgramArgumentsLength, 3);

    char* aZero[] = { "masuka", "-a0", "abc" };
    MskCliConfig zeroConfig = msk_cli_parse_args(3, aZero);
    ScResult zeroResult = msk_cli_validate_args(&zeroConfig, NULL, NULL, 0);
    sc_test_condition(zeroResult != ScResult_Success);

    char* aNoValue[] = { "masuka", "-a" };
    MskCliConfig noValueConfig = msk_cli_parse_args(2, aNoValue);
    ScResult noValueResult = msk_cli_validate_args(&noValueConfig, NULL, NULL, 0);
    sc_test_condition(noValueResult != ScResult_Success);
}

static void
msk_tests_cli_validate_jobs(void)
{
    char* aGood[] = { "masuka", "-j", "1" };
    MskCliConfig goodConfig = msk_cli_parse_args(3, aGood);
    sc_test_i32_equal(msk_cli_validate_args(&goodConfig, NULL, NULL, 0), ScResult_Success);
    sc_test_i32_equal(goodConfig.JobsCount, 1);

    char* aZero[] = { "masuka", "-j", "0" };
    MskCliConfig zeroConfig = msk_cli_parse_args(3, aZero);
    sc_test_condition(msk_cli_validate_args(&zeroConfig, NULL, NULL, 0) != ScResult_Success);

    char* aTooMany[] = { "masuka", "-j", "999999" };
    MskCliConfig tooManyConfig = msk_cli_parse_args(3, aTooMany);
    sc_test_condition(msk_cli_validate_args(&tooManyConfig, NULL, NULL, 0) != ScResult_Success);

    char* aNotNumber[] = { "masuka", "-j", "abc" };
    MskCliConfig notNumberConfig = msk_cli_parse_args(3, aNotNumber);
    sc_test_condition(msk_cli_validate_args(&notNumberConfig, NULL, NULL, 0) != ScResult_Success);
}

// DOCS: Count words and check one word of a parsed -a string (M5-2).
static void
msk_tests_arguments_check(char** aWords, i32 expectedCount, i32 index, char* pExpected)
{
    sc_test_i32_equal((i32)sc_list_count(aWords), expectedCount);

    if (index >= 0 && index < (i32)sc_list_count(aWords))
        sc_test_string_equals(aWords[index], pExpected);
}

static void
msk_tests_arguments_free(char** aWords)
{
    sc_list_for_each(aWords, ppWord)
        sc_memory_free(*ppWord);
    sc_list_free(aWords);
}

static void
msk_tests_cli_parse_program_arguments(void)
{
    // DOCS: Format from the ТЗ: quotes are quoting, not a part of the word.
    char* pSpec = "arg0=\"0\" arg1='1' arg2=2";
    char** aSpec = msk_cli_parse_program_arguments(pSpec, sc_string_get_length(pSpec));
    msk_tests_arguments_check(aSpec, 3, 0, "arg0=0");
    msk_tests_arguments_check(aSpec, 3, 1, "arg1=1");
    msk_tests_arguments_check(aSpec, 3, 2, "arg2=2");
    msk_tests_arguments_free(aSpec);

    // DOCS: Spaces inside quotes don't split the word; multiple spaces are skipped.
    char* pSpaces = "a  \"b c\"   d";
    char** aSpaces = msk_cli_parse_program_arguments(pSpaces, sc_string_get_length(pSpaces));
    msk_tests_arguments_check(aSpaces, 3, 1, "b c");
    msk_tests_arguments_free(aSpaces);

    // DOCS: Double quotes: \" and \\ are unescaped.
    char* pEscapes = "\"x\\\"y\" \"a\\\\b\"";
    char** aEscapes = msk_cli_parse_program_arguments(pEscapes, sc_string_get_length(pEscapes));
    msk_tests_arguments_check(aEscapes, 2, 0, "x\"y");
    msk_tests_arguments_check(aEscapes, 2, 1, "a\\b");
    msk_tests_arguments_free(aEscapes);

    // DOCS: Single quotes are literal: no escape sequences inside.
    char* pSingle = "'it\\'s' 'x\"y'";
    char** aSingle = msk_cli_parse_program_arguments(pSingle, sc_string_get_length(pSingle));
    msk_tests_arguments_check(aSingle, 2, 0, "it\\'s");
    msk_tests_arguments_check(aSingle, 2, 1, "x\"y");
    msk_tests_arguments_free(aSingle);

    // DOCS: Empty quotes give an empty word; it is not skipped.
    char* pEmpty = "\"\" x";
    char** aEmpty = msk_cli_parse_program_arguments(pEmpty, sc_string_get_length(pEmpty));
    msk_tests_arguments_check(aEmpty, 2, 0, "");
    msk_tests_arguments_check(aEmpty, 2, 1, "x");
    msk_tests_arguments_free(aEmpty);

    // DOCS: A word without trailing spaces ends at the end of the string.
    char* pTail = "one two";
    char** aTail = msk_cli_parse_program_arguments(pTail, sc_string_get_length(pTail));
    msk_tests_arguments_check(aTail, 2, 1, "two");
    msk_tests_arguments_free(aTail);

    // DOCS: -a{N}: only the declared length is parsed.
    char* pLength = "abc def ghi";
    char** aLength = msk_cli_parse_program_arguments(pLength, 7); // "abc def"
    msk_tests_arguments_check(aLength, 2, 1, "def");
    msk_tests_arguments_free(aLength);

    // DOCS: NULL/empty input gives an empty list, not a crash.
    sc_test_i32_equal((i32)sc_list_count(msk_cli_parse_program_arguments(NULL, 0)), 0);

    // DOCS: Unterminated quotes keep the rest of the string (with a WARN).
    char* pUnterminated = "\"abc";
    char** aUnterminated = msk_cli_parse_program_arguments(pUnterminated, sc_string_get_length(pUnterminated));
    msk_tests_arguments_check(aUnterminated, 1, 0, "abc");
    msk_tests_arguments_free(aUnterminated);
}

static void
msk_tests_language_vince(void)
{
    char* pVinceContent = "workspace miracle\n"
                          "{\n"
                          "    entry: \"masuka\",\n"
                          "    builds: [\n"
                          "        { name: \"debug\" preprocessor: \"SC_BUILD_DEBUG\", optimize: 0 },\n"
                          "        { name: \"release\" preprocessor: \"SC_BUILD_RELEASE\", optimize: 1 }\n"
                          "    ],\n"
                          "    platforms: [\n"
                          "        { name: \"linux\" preprocessor: \"SC_PLATFORM_LINUX\" }\n"
                          "    ]\n"
                          "}\n";

    MskVince vince = msk_language_vince_new(pVinceContent);

    sc_test_string_equals(vince.pName, "miracle");
    sc_test_string_equals(vince.pEntryName, "masuka");
    sc_test_i32_equal((i32)sc_list_count(vince.aBuilds), 2);
    sc_test_i32_equal((i32)sc_list_count(vince.aPlatforms), 1);
    sc_test_condition(msk_language_vince_validate(vince) == ScResult_Success);

    // DOCS: Default {build}/{platform} are the first declared names, not system ones.
    sc_test_string_equals(msk_tests_variable_value(vince.aVariables, "build"), "debug");
    sc_test_string_equals(msk_tests_variable_value(vince.aVariables, "platform"), "linux");

    // DOCS: Explicit selection replaces the values (NULL keeps the current one).
    msk_language_vince_set_selection(&vince, "release", NULL);
    sc_test_string_equals(msk_tests_variable_value(vince.aVariables, "build"), "release");
    sc_test_string_equals(msk_tests_variable_value(vince.aVariables, "platform"), "linux");

    MskVince emptyVince = msk_language_vince_new("workspace empty { }");
    sc_test_condition(msk_language_vince_validate(emptyVince) != ScResult_Success);
}

static void
msk_tests_language_file(void)
{
    char* pContent = "project p1\n"
                     "{\n"
                     "    type: \"StaticLib\",\n"
                     "    bin: \"bin/{build}-{platform}\",\n"
                     "    objdir: \"bin/obj/{build}-{platform}/{project}\",\n"
                     "    source: [\"src/*.c\"],\n"
                     "    dependencies: [\"dep1\"],\n"
                     "    include: [\"inc\"],\n"
                     "    provide-include: [\"src\"],\n"
                     "    preprocessors: [\"COMMON\"],\n"
                     "    linux: { preprocessors: [\"LIN_ONLY\"] }\n"
                     "}\n";

    MskFile mskFile = msk_language_file_new_from_memory(NULL, "tests/proj.masuka", pContent);

    sc_test_string_equals(mskFile.pProjectName, "p1");
    sc_test_i32_equal(mskFile.ProjectType, MskProjectType_StaticLib);
    sc_test_string_equals(mskFile.pBin, "bin/{build}-{platform}");
    sc_test_string_equals(mskFile.pObjDir, "bin/obj/{build}-{platform}/{project}");
    sc_test_i32_equal((i32)sc_list_count(mskFile.aSources), 1);
    sc_test_string_equals(mskFile.aSources[0].pName, "src/*.c");
    sc_test_i32_equal((i32)sc_list_count(mskFile.aDependencies), 1);
    sc_test_string_equals(mskFile.aDependencies[0].pName, "dep1");
    sc_test_i32_equal((i32)sc_list_count(mskFile.aProvideIncludes), 1);
    sc_test_string_equals(mskFile.aProvideIncludes[0].pName, "src");
    sc_test_i32_equal((i32)sc_list_count(mskFile.aPreprocessors), 1);
    sc_test_string_equals(mskFile.aPreprocessors[0].pName, "COMMON");
    sc_test_i32_equal((i32)sc_list_count(mskFile.aPlatforms), 1);
    sc_test_string_equals(mskFile.pFilePath, "tests/proj.masuka");
    sc_test_string_equals(mskFile.pProjectLocation, "tests");
    sc_test_i32_equal(msk_language_file_is_valid(mskFile), 1);
    sc_test_condition(msk_language_file_validate(mskFile) == ScResult_Success);

    // DOCS: Unknown type and missing fields are reported (details go to the log).
    char* pBrokenContent = "project broken { type: \"Wrong\", objdir: \"o\" }";
    MskFile brokenFile = msk_language_file_new_from_memory(NULL, "tests/broken.masuka", pBrokenContent);
    sc_test_condition(msk_language_file_validate(brokenFile) != ScResult_Success);
    sc_test_i32_equal(msk_language_file_is_valid(brokenFile), 0);
}

static void
msk_tests_preprocess_string(void)
{
    MskVariable aVariables[2] = {
        { "build", "debug" },
        { "project", "p1" },
    };

    char* pInput = "bin/{build}-{project}";
    char* pResult = msk_preprocess_string(aVariables, 2, pInput, sc_string_get_length(pInput));
    sc_test_string_equals(pResult, "bin/debug-p1");
    sc_string_destroy(pResult);

    // DOCS: A string without variables is returned as is (no allocation).
    char* pPlain = "plain/path";
    sc_test_condition(msk_preprocess_string(aVariables, 2, pPlain, sc_string_get_length(pPlain)) == pPlain);

    // DOCS: An unclosed brace stays literal instead of eating the rest.
    char* pUnclosed = "a{b";
    char* pUnclosedResult = msk_preprocess_string(aVariables, 2, pUnclosed, sc_string_get_length(pUnclosed));
    sc_test_string_equals(pUnclosedResult, "a{b");
    sc_string_destroy(pUnclosedResult);

    // DOCS: Without variables nothing is substituted.
    char* pWithVar = "x{project}";
    sc_test_condition(msk_preprocess_string(NULL, 0, pWithVar, sc_string_get_length(pWithVar)) == pWithVar);
}

static void
msk_tests_language_platform_block(void)
{
    sc_test_i32_equal(msk_language_platform_block("linux: {", "linux"), 1);
    sc_test_i32_equal(msk_language_platform_block("windows: {", "windows"), 1);
    sc_test_i32_equal(msk_language_platform_block("linux\"", "linux"), 0);
    sc_test_i32_equal(msk_language_platform_block("linuxX", "linux"), 0);
    sc_test_i32_equal(msk_language_platform_block("platforms", "linux"), 0);

    sc_test_i32_equal(msk_language_name_char('a'), 1);
    sc_test_i32_equal(msk_language_name_char('1'), 1);
    sc_test_i32_equal(msk_language_name_char('_'), 1);
    sc_test_i32_equal(msk_language_name_char('-'), 1);
    sc_test_i32_equal(msk_language_name_char(' '), 0);
}

static void
msk_tests_project_from_file(void)
{
    msk_tests_write_file(MSK_TESTS_TEMPORARY_DIRECTORY "/proj/src/a.c", "int a;\n");
    msk_tests_write_file(MSK_TESTS_TEMPORARY_DIRECTORY "/proj/src/b.c", "int b;\n");

    char* pVinceContent = "workspace tests\n"
                          "{\n"
                          "    builds: [ { name: \"debug\" preprocessor: \"SC_BUILD_DEBUG\", optimize: 0 } ],\n"
                          "    platforms: [ { name: \"linux\" preprocessor: \"SC_PLATFORM_LINUX\" } ]\n"
                          "}\n";

    char* pProjectContent = "project p1\n"
                            "{\n"
                            "    type: \"StaticLib\",\n"
                            "    bin: \"bin/{build}-{platform}\",\n"
                            "    objdir: \"bin/obj/{build}-{platform}/{project}\",\n"
                            "    source: [\"src/*.c\"],\n"
                            "    provide-include: [\"src\"],\n"
                            "    preprocessors: [\"COMMON\"],\n"
                            "    linux: { preprocessors: [\"LIN_ONLY\"] }\n"
                            "}\n";

    MskVince vince = msk_language_vince_new(pVinceContent);
    MskFile mskFile = msk_language_file_new_from_memory(&vince, MSK_TESTS_TEMPORARY_DIRECTORY "/proj/proj.masuka", pProjectContent);

    mskFile = msk_preprocessor_file(&vince, mskFile);
    msk_file_apply_platform(&mskFile, "linux");

    MskProject project = msk_project_from_file(mskFile, vince, "debug", "linux");

    sc_test_string_equals(project.pName, "p1");
    sc_test_i32_equal(project.Type, MskProjectType_StaticLib);
    sc_test_string_equals(project.pBin, "bin/debug-linux");
    sc_test_string_equals(project.pObjDir, "bin/obj/debug-linux/p1");

    // DOCS: The glob is expanded relative to the project directory.
    sc_test_i32_equal((i32)sc_list_count(project.aSources), 2);
    sc_test_condition(msk_project_strings_contains(project.aSources, MSK_TESTS_TEMPORARY_DIRECTORY "/proj/src/a.c"));
    sc_test_condition(msk_project_strings_contains(project.aSources, MSK_TESTS_TEMPORARY_DIRECTORY "/proj/src/b.c"));

    // DOCS: provide-include is a project-relative directory for dependents.
    sc_test_i32_equal((i32)sc_list_count(project.aProvided), 1);
    sc_test_string_equals(project.aProvided[0].pName, MSK_TESTS_TEMPORARY_DIRECTORY "/proj/src");

    // DOCS: project + build + platform preprocessors are all present.
    sc_test_condition(msk_project_strings_contains(project.aPreprocessors, "COMMON"));
    sc_test_condition(msk_project_strings_contains(project.aPreprocessors, "LIN_ONLY"));
    sc_test_condition(msk_project_strings_contains(project.aPreprocessors, "SC_BUILD_DEBUG"));
    sc_test_condition(msk_project_strings_contains(project.aPreprocessors, "SC_PLATFORM_LINUX"));
}

static void
msk_tests_projects_resolve(void)
{
    MskProject* aProjects = NULL;

    MskProject projectA = {};
    projectA.pName = sc_string_new("a");
    sc_list_add(projectA.aDependencies, (MskString) { .pName = sc_string_new("b") });

    MskProject projectB = {};
    projectB.pName = sc_string_new("b");
    sc_list_add(projectB.aProvided, (MskString) { .pName = sc_string_new("prov-b") });

    // DOCS: The dependent project comes first: the topological sort must reorder them.
    sc_list_add(aProjects, projectA);
    sc_list_add(aProjects, projectB);

    sc_test_condition(msk_projects_resolve(aProjects, 2) == ScResult_Success);
    sc_test_string_equals(aProjects[0].pName, "b");
    sc_test_string_equals(aProjects[1].pName, "a");
    sc_test_condition(msk_project_strings_contains(aProjects[1].aIncludes, "prov-b"));

    // DOCS: Unknown dependency is an error, not a silent skip.
    MskProject* aUnknown = NULL;
    MskProject unknown = { .pName = sc_string_new("u") };
    sc_list_add(unknown.aDependencies, (MskString) { .pName = sc_string_new("nope") });
    sc_list_add(aUnknown, unknown);
    sc_test_condition(msk_projects_resolve(aUnknown, 1) != ScResult_Success);

    // DOCS: A dependency cycle is detected and reported.
    MskProject* aCycle = NULL;
    MskProject cycleX = { .pName = sc_string_new("x") };
    MskProject cycleY = { .pName = sc_string_new("y") };
    sc_list_add(cycleX.aDependencies, (MskString) { .pName = sc_string_new("y") });
    sc_list_add(cycleY.aDependencies, (MskString) { .pName = sc_string_new("x") });
    sc_list_add(aCycle, cycleX);
    sc_list_add(aCycle, cycleY);
    sc_test_condition(msk_projects_resolve(aCycle, 2) != ScResult_Success);
}

static i32
msk_tests_contains(char* pText, char* pSubstring)
{
    return (pText && pSubstring) ? (sc_string_index_of_string(pText, pSubstring) >= 0) : 0;
}

static i32
msk_tests_count(char* pText, char* pSubstring)
{
    if (!pText || !pSubstring || pSubstring[0] == '\0')
        return 0;

    i32 count = 0;
    i64 length = sc_string_get_length(pSubstring);

    for (char* p = pText; ; )
    {
        i64 index = sc_string_index_of_string(p, pSubstring);
        if (index < 0)
            break;

        ++count;
        p += index + length;

        if (*p == '\0')
            break;
    }

    return count;
}

static MskProject
msk_tests_project_create(char* pName, MskProjectType type, char* pLocation, char* pObjDir, char* pBin)
{
    MskProject project = {};

    project.pName = sc_string_new(pName);
    project.Type = type;
    project.pProjectLocation = sc_string_new(pLocation);
    project.pObjDir = sc_string_new(pObjDir);
    project.pBin = sc_string_new(pBin);

    return project;
}

static void
msk_tests_project_add_string(MskString** ppList, char* pString)
{
    sc_list_add(*ppList, (MskString) { .pName = sc_string_new(pString) });
}

// DOCS: math (static) <- util (dynamic) <- app (exe) with a space in a project path.
static MskProject*
msk_tests_generator_projects(void)
{
    MskProject* aProjects = NULL;

    MskProject mathProject = msk_tests_project_create("math", MskProjectType_StaticLib, "libs/math lib", "bin/obj/debug-linux/math", "bin/debug-linux");
    msk_tests_project_add_string(&mathProject.aSources, "libs/math lib/src/a.c");
    msk_tests_project_add_string(&mathProject.aSources, "libs/math lib/src/sub/b.c");
    msk_tests_project_add_string(&mathProject.aIncludes, "libs/math lib/src");
    msk_tests_project_add_string(&mathProject.aPreprocessors, "MATH_COMMON");
    msk_tests_project_add_string(&mathProject.aPreprocessors, "SC_BUILD_DEBUG");
    sc_list_add(aProjects, mathProject);

    MskProject utilProject = msk_tests_project_create("util", MskProjectType_DynamicLib, "libs/util", "bin/obj/debug-linux/util", "bin/debug-linux");
    msk_tests_project_add_string(&utilProject.aSources, "libs/util/src/util.c");
    msk_tests_project_add_string(&utilProject.aDependencies, "math");
    msk_tests_project_add_string(&utilProject.aLinks, "m");
    sc_list_add(aProjects, utilProject);

    MskProject appProject = msk_tests_project_create("app", MskProjectType_Executable, "apps/app", "bin/obj/debug-linux/app", "bin/debug-linux");
    msk_tests_project_add_string(&appProject.aSources, "apps/app/src/main.c");
    msk_tests_project_add_string(&appProject.aDependencies, "util");
    msk_tests_project_add_string(&appProject.aDependencies, "math");
    msk_tests_project_add_string(&appProject.aLinks, "m");
    msk_tests_project_add_string(&appProject.aLinks, "-pthread");
    sc_list_add(aProjects, appProject);

    return aProjects;
}

static void
msk_tests_generator_free(MskGeneratorBuildResult* pResult)
{
    for (i32 r = 0; r < sc_list_count(pResult->aResults); ++r)
    {
        sc_list_free(pResult->aResults[r].pSb);
        sc_memory_free(pResult->aResults[r].pScriptPath);
    }

    sc_list_free(pResult->aResults);
    sc_list_free(pResult->pSb);
    pResult->aResults = NULL;
    pResult->pSb = NULL;
}

static void
msk_tests_generator_object_path(void)
{
    MskProject project = msk_tests_project_create("math", MskProjectType_StaticLib, "libs/math lib", "bin/obj/math", "bin/debug-linux");

    // DOCS: The object path mirrors the source path inside objdir (no name collisions).
    char* pObject = msk_project_object_path(&project, "libs/math lib/src/a.c");
    sc_test_string_equals(pObject, "bin/obj/math/src/a.o");
    sc_memory_free(pObject);

    pObject = msk_project_object_path(&project, "libs/math lib/src/sub/b.c");
    sc_test_string_equals(pObject, "bin/obj/math/src/sub/b.o");
    sc_memory_free(pObject);

    // DOCS: Two sources with the same name in different directories stay apart.
    char* pOtherObject = msk_project_object_path(&project, "libs/math lib/src/other/a.c");
    sc_test_string_equals(pOtherObject, "bin/obj/math/src/other/a.o");
    sc_memory_free(pOtherObject);

    // DOCS: A source outside the project directory keeps its path.
    pObject = msk_project_object_path(&project, "shared/math.c");
    sc_test_string_equals(pObject, "bin/obj/math/shared/math.o");
    sc_memory_free(pObject);
}

static void
msk_tests_generator_script_shell(void)
{
    MskProject* aProjects = msk_tests_generator_projects();

    MskGeneratorBuildConfig cfg = {
        .aProjects = aProjects,
        .ProjectsCount = 3,
        .JobsCount = 2,
        .Kind = MskScriptKind_Shell,
        .pRootDirectory = "/tmp/masuka-root",
        .pBuild = "debug",
        .pPlatform = "linux",
    };

    MskGeneratorBuildResult build = msk_generator_build_create(cfg);

    // DOCS: Main script: shebang, fail on error, absolute cwd, projects in build order.
    sc_test_condition(msk_tests_contains(build.pSb, "#!/bin/bash"));
    sc_test_condition(msk_tests_contains(build.pSb, "set -e"));
    sc_test_condition(msk_tests_contains(build.pSb, "cd /tmp/masuka-root"));
    sc_test_condition(msk_tests_contains(build.pSb, "bash 'libs/math lib/build_math.sh'"));
    sc_test_condition(msk_tests_contains(build.pSb, "bash libs/util/build_util.sh"));
    sc_test_condition(msk_tests_contains(build.pSb, "bash apps/app/build_app.sh"));

    // DOCS: Indexes prove the build order: mathlib before util before app.
    i64 mathCallIndex = sc_string_index_of_string(build.pSb, "build_math.sh");
    i64 utilCallIndex = sc_string_index_of_string(build.pSb, "build_util.sh");
    i64 appCallIndex = sc_string_index_of_string(build.pSb, "build_app.sh");
    sc_test_condition(mathCallIndex >= 0 && utilCallIndex >= 0 && appCallIndex >= 0 && mathCallIndex < utilCallIndex && utilCallIndex < appCallIndex);

    sc_test_i32_equal((i32)sc_list_count(build.aResults), 3);

    // DOCS: StaticLib: explicit object list, no shell glob, fresh archive.
    char* pMathScript = build.aResults[0].pSb;
    sc_test_string_equals(build.aResults[0].pScriptPath, "libs/math lib/build_math.sh");
    sc_test_condition(msk_tests_contains(pMathScript, "ar rcs"));
    sc_test_condition(msk_tests_contains(pMathScript, "rm -f bin/debug-linux/libmath.a"));
    sc_test_condition(msk_tests_contains(pMathScript, "libmath.a bin/obj/debug-linux/math/src/a.o bin/obj/debug-linux/math/src/sub/b.o"));
    sc_test_condition(!msk_tests_contains(pMathScript, "*.o"));
    sc_test_condition(msk_tests_contains(pMathScript, "-std=c99 -m64 -g -O0"));
    sc_test_condition(msk_tests_contains(pMathScript, "-DMATH_COMMON -DSC_BUILD_DEBUG"));
    sc_test_condition(msk_tests_contains(pMathScript, "'-Ilibs/math lib/src'"));
    sc_test_condition(msk_tests_contains(pMathScript, "mkdir -p bin/obj/debug-linux/math/src/sub"));
    sc_test_condition(msk_tests_contains(pMathScript, "mkdir -p bin/debug-linux"));
    sc_test_condition(msk_tests_contains(pMathScript, "pids=()"));
    sc_test_condition(msk_tests_contains(pMathScript, "for pid in \"${pids[@]}\"; do wait \"$pid\"; done"));

    // DOCS: Incremental build (M4-5): flags stamp + per-TU mtime/flags check.
    sc_test_condition(msk_tests_contains(pMathScript, "MSK_FLAGS='clang -std=c99 -m64 -g -O0"));
    sc_test_condition(msk_tests_contains(pMathScript, "MSK_STAMP=bin/obj/debug-linux/math/.masuka_flags"));
    sc_test_condition(msk_tests_contains(pMathScript, "if [ ! -f bin/obj/debug-linux/math/src/a.o ] || [ 'libs/math lib/src/a.c' -nt bin/obj/debug-linux/math/src/a.o ]"));
    sc_test_condition(msk_tests_contains(pMathScript, "] || [ \"$MSK_FLAGS\" != \"$(cat \"$MSK_STAMP\" 2>/dev/null)\" ]; then"));
    sc_test_condition(msk_tests_contains(pMathScript, "printf '%s' \"$MSK_FLAGS\" > \"$MSK_STAMP\""));

    // DOCS: DynamicLib: -fPIC, -shared, .so, dependencies are linked as -l.
    char* pUtilScript = build.aResults[1].pSb;
    sc_test_condition(msk_tests_contains(pUtilScript, "-fPIC"));
    sc_test_condition(msk_tests_contains(pUtilScript, "-shared"));
    sc_test_condition(msk_tests_contains(pUtilScript, "-lmath"));
    sc_test_condition(msk_tests_contains(pUtilScript, "-lm"));
    sc_test_condition(msk_tests_contains(pUtilScript, "libutil.so"));

    // DOCS: Executable: direct + transitive libraries, raw links, rpath, target path.
    char* pAppScript = build.aResults[2].pSb;
    sc_test_condition(msk_tests_contains(pAppScript, "-lutil -lmath"));
    sc_test_condition(msk_tests_contains(pAppScript, "-lm -pthread"));
    sc_test_condition(msk_tests_contains(pAppScript, "'-Wl,-rpath,$ORIGIN'"));
    sc_test_condition(msk_tests_contains(pAppScript, "-o bin/debug-linux/app"));

    // DOCS: An optimized build uses -O2 instead of -g -O0.
    aProjects[0].IsOptimize = 1;
    MskGeneratorBuildResult releaseBuild = msk_generator_build_create(cfg);
    sc_test_condition(msk_tests_contains(releaseBuild.aResults[0].pSb, "-O2"));
    sc_test_condition(!msk_tests_contains(releaseBuild.aResults[0].pSb, "-O0"));
    msk_tests_generator_free(&releaseBuild);

    msk_tests_generator_free(&build);
}

static void
msk_tests_generator_script_batch(void)
{
    MskProject* aProjects = msk_tests_generator_projects();

    MskGeneratorBuildConfig cfg = {
        .aProjects = aProjects,
        .ProjectsCount = 3,
        .JobsCount = 4,
        .Kind = MskScriptKind_Batch,
        .pRootDirectory = "C:\\ws",
        .pBuild = "debug",
        .pPlatform = "windows",
    };

    MskGeneratorBuildResult build = msk_generator_build_create(cfg);

    // DOCS: Main script: batch syntax, calls of per-project scripts, fail on error.
    sc_test_condition(msk_tests_contains(build.pSb, "@echo off"));
    sc_test_condition(msk_tests_contains(build.pSb, "cd /d \"C:\\ws\""));
    sc_test_condition(msk_tests_contains(build.pSb, "call \"libs\\math lib\\build_math.bat\""));
    sc_test_condition(msk_tests_contains(build.pSb, "if errorlevel 1 exit /b 1"));
    sc_test_condition(!msk_tests_contains(build.pSb, "#!/bin/bash"));
    sc_test_condition(!msk_tests_contains(build.pSb, "set -e"));

    char* pMathScript = build.aResults[0].pSb;
    sc_test_string_equals(build.aResults[0].pScriptPath, "libs/math lib/build_math.bat");
    sc_test_condition(msk_tests_contains(pMathScript, "llvm-ar.exe rcs"));
    sc_test_condition(msk_tests_contains(pMathScript, "clang.exe -std=c99"));
    sc_test_condition(msk_tests_contains(pMathScript, "bin\\debug-linux\\math.lib"));
    sc_test_condition(msk_tests_contains(pMathScript, "if not exist"));
    sc_test_condition(msk_tests_contains(pMathScript, "mkdir"));
    sc_test_condition(!msk_tests_contains(pMathScript, "pids=()"));

    char* pAppScript = build.aResults[2].pSb;
    sc_test_condition(msk_tests_contains(pAppScript, "bin\\debug-linux\\app.exe"));
    sc_test_condition(msk_tests_contains(pAppScript, "del /q"));
    sc_test_condition(!msk_tests_contains(pAppScript, "rpath"));

    msk_tests_generator_free(&build);
}

static void
msk_tests_generator_json(void)
{
    MskProject* aProjects = msk_tests_generator_projects();

    char* pRoot = MSK_TESTS_TEMPORARY_DIRECTORY "/ws";
    sc_directory_create_recursive(pRoot);

    MskGeneratorJsonConfig cfg = {
        .aProjects = aProjects,
        .ProjectsCount = 3,
        .pRootDirectory = pRoot,
    };

    sc_test_i32_equal(msk_generator_json_create(cfg), 0);

    i64 length = 0;
    char* pJson = sc_file_read_ext(MSK_TESTS_TEMPORARY_DIRECTORY "/ws/compile_commands.json", &length);
    sc_test_condition(pJson != NULL);

    if (pJson)
    {
        // DOCS: One entry per translation unit with the fields clangd expects.
        sc_test_i32_equal(msk_tests_count(pJson, "\"directory\": "), 4);
        sc_test_i32_equal(msk_tests_count(pJson, "\"file\": "), 4);
        sc_test_i32_equal(msk_tests_count(pJson, "\"output\": "), 4);
        sc_test_i32_equal(msk_tests_count(pJson, "\"arguments\": ["), 4);

        // DOCS: Absolute paths and the same flags as the generated script.
        sc_test_condition(msk_tests_contains(pJson, "/.tmp-masuka-tests/ws/libs/math lib/src/a.c"));
        sc_test_condition(msk_tests_contains(pJson, "/.tmp-masuka-tests/ws/bin/obj/debug-linux/math/src/a.o"));
        sc_test_condition(msk_tests_contains(pJson, "\"clang\""));
        sc_test_condition(msk_tests_contains(pJson, "\"-std=c99\""));
        sc_test_condition(msk_tests_contains(pJson, "\"-DMATH_COMMON\""));
        sc_test_condition(msk_tests_contains(pJson, "\"-c\""));

        sc_memory_free(pJson);
    }
}

static void
msk_tests_generator_quoting(void)
{
    char* pPlain = msk_script_quote_word("plain/path", MskScriptKind_Shell);
    sc_test_string_equals(pPlain, "plain/path");
    sc_memory_free(pPlain);

    char* pSpaced = msk_script_quote_word("a b", MskScriptKind_Shell);
    sc_test_string_equals(pSpaced, "'a b'");
    sc_memory_free(pSpaced);

    char* pQuoted = msk_script_quote_word("it's", MskScriptKind_Shell);
    sc_test_string_equals(pQuoted, "'it'\\''s'");
    sc_memory_free(pQuoted);

    char* pBatchSpaced = msk_script_quote_word("a b", MskScriptKind_Batch);
    sc_test_string_equals(pBatchSpaced, "\"a b\"");
    sc_memory_free(pBatchSpaced);

    char* pBatchPath = msk_script_quote_word("bin\\debug-linux", MskScriptKind_Batch);
    sc_test_string_equals(pBatchPath, "\"bin\\debug-linux\"");
    sc_memory_free(pBatchPath);

    char* pMainScript = msk_generator_main_script_path(".", MskScriptKind_Shell);
    sc_test_string_equals(pMainScript, "./vince_build.sh");
    sc_memory_free(pMainScript);

    char* pMainBatchScript = msk_generator_main_script_path(".", MskScriptKind_Batch);
    sc_test_string_equals(pMainBatchScript, "./vince_build.bat");
    sc_memory_free(pMainBatchScript);

#if defined(SC_PLATFORM_LINUX)
    sc_test_i32_equal(msk_script_kind_host(), MskScriptKind_Shell);
#elif defined(SC_PLATFORM_WINDOWS)
    sc_test_i32_equal(msk_script_kind_host(), MskScriptKind_Batch);
#endif
}

/* DOCS:
    Run a compiler call of a negative test with stdout/stderr silenced:
    the expected failure output must not pollute the self-test report.
*/
static i32
msk_tests_compile_quietly(MskCompilerConfig cfg)
{
#if defined(SC_PLATFORM_LINUX)
    fflush(stdout);
    fflush(stderr);

    i32 savedStdout = dup(1);
    i32 savedStderr = dup(2);
    FILE* pDevNull = fopen("/dev/null", "w");

    if (pDevNull)
    {
        dup2(fileno(pDevNull), 1);
        dup2(fileno(pDevNull), 2);
    }

    i32 result = msk_compiler_compile(cfg);

    fflush(stdout);
    fflush(stderr);

    if (pDevNull)
    {
        dup2(savedStdout, 1);
        dup2(savedStderr, 2);
        fclose(pDevNull);
    }

    close(savedStdout);
    close(savedStderr);

    return result;
#else
    return msk_compiler_compile(cfg);
#endif // SC_PLATFORM_LINUX
}

// DOCS: Run a built program and report its exit code (smoke test of M4).
static i32
msk_tests_run_program(char* pPath)
{
    char* pQuoted = msk_script_quote_word(pPath, MskScriptKind_Shell);
    if (!pQuoted)
        return 1;

    char aCommand[1024] = {};
    sc_format(aCommand, sizeof(aCommand), "%s", pQuoted);
    sc_memory_free(pQuoted);

    return system(aCommand) == 0 ? 0 : 1;
}

static void
msk_tests_generator_parallel_waves(void)
{
    MskProject* aProjects = NULL;

    MskProject alpha = msk_tests_project_create("alpha", MskProjectType_StaticLib, "alpha", "bin/obj/alpha", "bin");
    msk_tests_project_add_string(&alpha.aSources, "alpha/a.c");
    msk_tests_project_add_string(&alpha.aSources, "alpha/b.c");
    sc_list_add(aProjects, alpha);

    MskProject beta = msk_tests_project_create("beta", MskProjectType_StaticLib, "beta", "bin/obj/beta", "bin");
    msk_tests_project_add_string(&beta.aSources, "beta/c.c");
    sc_list_add(aProjects, beta);

    MskGeneratorBuildConfig cfg = {
        .aProjects = aProjects,
        .ProjectsCount = 2,
        .JobsCount = 2,
        .Kind = MskScriptKind_Shell,
        .pRootDirectory = "/tmp/ws",
        .pBuild = "debug",
        .pPlatform = "linux",
    };

    // DOCS: Projects of one dependency level are independent: they build in parallel (M4-2).
    MskGeneratorBuildResult parallelBuild = msk_generator_build_create(cfg);
    sc_test_condition(msk_tests_contains(parallelBuild.pSb, "Level 1: 2 project(s) in parallel"));
    sc_test_condition(msk_tests_contains(parallelBuild.pSb, "pids=()"));
    sc_test_condition(msk_tests_contains(parallelBuild.pSb, "build_alpha.sh &"));
    sc_test_condition(msk_tests_contains(parallelBuild.pSb, "build_beta.sh &"));
    sc_test_condition(msk_tests_contains(parallelBuild.pSb, "for pid in \"${pids[@]}\"; do wait \"$pid\"; done"));

    // DOCS: -j is shared: 2 projects and 2 jobs -> one job per project.
    sc_test_condition(!msk_tests_contains(parallelBuild.aResults[0].pSb, "pids=()"));

    msk_tests_generator_free(&parallelBuild);

    // DOCS: -j 1 runs everything sequentially.
    cfg.JobsCount = 1;
    MskGeneratorBuildResult serialBuild = msk_generator_build_create(cfg);
    sc_test_condition(!msk_tests_contains(serialBuild.pSb, "pids=()"));
    sc_test_condition(!msk_tests_contains(serialBuild.pSb, " &"));
    msk_tests_generator_free(&serialBuild);
}

static void
msk_tests_compiler_compile(void)
{
    char* pRootRelative = MSK_TESTS_TEMPORARY_DIRECTORY "/compile";
    msk_tests_write_file(MSK_TESTS_TEMPORARY_DIRECTORY "/compile/lib.c", "int lib_value(void) { return 7; }\n");
    msk_tests_write_file(MSK_TESTS_TEMPORARY_DIRECTORY "/compile/main.c", "int lib_value(void);\n\nint main(void)\n{\n    return lib_value() == 7 ? 0 : 1;\n}\n");

    char* pCurrent = sc_directory_get_current();
    char* pRoot = sc_path_combine(pCurrent, pRootRelative);
    sc_memory_free(pCurrent);

    MskProject* aProjects = NULL;

    MskProject libProject = msk_tests_project_create("lib", MskProjectType_StaticLib, ".", "bin/obj/lib", "bin");
    msk_tests_project_add_string(&libProject.aSources, "lib.c");
    sc_list_add(aProjects, libProject);

    MskProject appProject = msk_tests_project_create("app", MskProjectType_Executable, ".", "bin/obj/app", "bin");
    msk_tests_project_add_string(&appProject.aSources, "main.c");
    msk_tests_project_add_string(&appProject.aDependencies, "lib");
    sc_list_add(aProjects, appProject);

    MskCompilerConfig cfg = {
        .aProjects = aProjects,
        .ProjectsCount = 2,
        .JobsCount = 2,
        .Kind = msk_script_kind_host(),
        .pRootDirectory = pRoot,
        .pBuild = "debug",
        .pPlatform = "linux",
    };

    // DOCS: Full cycle (M4): scripts in memory -> compile -> ar -> link.
    sc_test_i32_equal(msk_compiler_compile(cfg), 0);

#if defined(SC_PLATFORM_WINDOWS)
    char* pBinary = sc_path_combine(pRoot, "bin/app.exe");
#else
    char* pBinary = sc_path_combine(pRoot, "bin/app");
#endif

    sc_test_i32_equal(sc_path(pBinary), ScPathItemType_File);

    // DOCS: Temporary scripts are removed after the build.
    char* pScriptsDirectory = sc_path_combine(pRoot, MSK_COMPILER_TEMPORARY_DIRECTORY);
    sc_test_i32_equal(sc_path(pScriptsDirectory), ScPathItemType_Undefined);

    // DOCS: The linked program runs and returns success.
    sc_test_i32_equal(msk_tests_run_program(pBinary), 0);

    // DOCS: A second build reuses the objects (incremental, M4-5) and still succeeds.
    sc_test_i32_equal(msk_compiler_compile(cfg), 0);

    /* DOCS:
        A broken source makes the build fail instead of passing silently.
        The expected clang error is silenced, the self-test report stays readable.
    */
    msk_tests_write_file(MSK_TESTS_TEMPORARY_DIRECTORY "/compile/lib.c", "int lib_value(void) { return }\n");
    sc_test_condition(msk_tests_compile_quietly(cfg) != 0);

    sc_memory_free(pBinary);
    sc_memory_free(pScriptsDirectory);
    sc_memory_free(pRoot);
}

static void
msk_tests_silent_backend(ScLogItem item, ScLogFormat* aFormats, u32 formatsCount)
{
    (void)item;
    (void)aFormats;
    (void)formatsCount;
}

i32
msk_tests_run(void)
{
    msk_tests_cleanup();

    // DOCS: Negative tests check that errors are reported; keep that output out of the way.
    ScLogBackend silentBackend = {
        .Action = msk_tests_silent_backend,
        .FormatsCount = 1,
        .aFormats = { ScLogFormat_Message },
    };
    ScLogBackend* aBackends = NULL;
    sc_list_add(aBackends, silentBackend);
    sc_log_init((ScLogConfig) { .BackendsCount = 1, .aBackends = aBackends });

    sc_test_file();

    sc_test_func(msk_tests_cli_parse_args());
    sc_test_func(msk_tests_cli_parse_args_special());
    sc_test_func(msk_tests_cli_validate_arguments());
    sc_test_func(msk_tests_cli_validate_jobs());
    sc_test_func(msk_tests_cli_parse_program_arguments());
    sc_test_func(msk_tests_language_vince());
    sc_test_func(msk_tests_language_file());
    sc_test_func(msk_tests_preprocess_string());
    sc_test_func(msk_tests_language_platform_block());
    sc_test_func(msk_tests_project_from_file());
    sc_test_func(msk_tests_projects_resolve());
    sc_test_func(msk_tests_generator_object_path());
    sc_test_func(msk_tests_generator_script_shell());
    sc_test_func(msk_tests_generator_script_batch());
    sc_test_func(msk_tests_generator_json());
    sc_test_func(msk_tests_generator_quoting());
    sc_test_func(msk_tests_generator_parallel_waves());
    sc_test_func(msk_tests_compiler_compile());

    ScTestFile* aFiles = sc_test_get();

    i32 functionsCount = 0;
    i32 checksCount = 0;
    i32 failedFunctions = 0;

    printf("Masuka self-test\n");

    sc_list_for_each(aFiles, pFile)
    {
        sc_list_for_each(pFile->aFuncs, pFunc)
        {
            i32 isFailed = 0;
            checksCount += (i32)sc_list_count(pFunc->aRecords);

            for (i32 r = 0; r < sc_list_count(pFunc->aRecords); ++r)
            {
                if (!pFunc->aRecords[r].Code)
                    isFailed = 1;
            }

            ++functionsCount;
            failedFunctions += isFailed;

            printf("  [%s] %s\n", isFailed ? "fail" : " ok ", pFunc->pName);

            if (isFailed)
            {
                for (i32 r = 0; r < sc_list_count(pFunc->aRecords); ++r)
                {
                    if (!pFunc->aRecords[r].Code)
                        printf("         failed: %s\n", pFunc->aRecords[r].pMessage);
                }
            }
        }
    }

    if (failedFunctions == 0)
        printf("\nAll %d checks in %d functions passed.\n", checksCount, functionsCount);
    else
        printf("\n%d of %d functions failed (%d checks total).\n", failedFunctions, functionsCount, checksCount);

    msk_tests_cleanup();

    return failedFunctions > 0 ? 1 : 0;
}

i32
main(i32 argumentsCount, char** aArguments)
{
    // DOCS: The test binary takes no flags: it just runs the whole suite.
    (void)argumentsCount;
    (void)aArguments;

    return msk_tests_run();
}