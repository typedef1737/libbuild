#include "Test.h"

#include "Sc.h"
#include <stdio.h>

static struct
{
    ScTestFile* aFiles;

    i32 CurrentFile;
    i32 CurrentFunction;
} g = {};

void
sc_test_set_file(const char* pFilePath)
{
    char* pFileName = sc_path_get_name_wo_alloc((char*)pFilePath);

    i32 ind = -1;
    sc_list_for_each(g.aFiles, pFile)
    {
        if (sc_string_compare(pFile->pFileName, pFileName))
        {
            ind = index;
        }
    }

    if (ind == -1)
    {
        ScTestFile file = {
            .pFileName = pFileName
        };
        sc_list_add(g.aFiles, file);
        ind = sc_list_count(g.aFiles) - 1;
    }

    g.CurrentFile = ind;
}

ScTestFile*
sc_test_file_get()
{
    ScTestFile* pFile = &g.aFiles[g.CurrentFile];
    return pFile;
}

void
sc_test_set_func(const char* pFuncName)
{
    i32 ind = -1;

    ScTestFile* pFile = sc_test_file_get();
    sc_list_for_each(pFile->aFuncs, pFunc)
    {
        if (sc_string_compare(pFunc->pName, (char*)pFuncName))
        {
            ind = index;
        }
    }

    if (ind == -1)
    {
        ScTestFunc func = {
            .pName = sc_string_new((char*)pFuncName)
        };

        sc_list_add(pFile->aFuncs, func);
        ind = sc_list_count(pFile->aFuncs) - 1;
    }

    g.CurrentFunction = ind;
}

ScTestFunc*
sc_test_func_get()
{
    ScTestFile* pFile = sc_test_file_get();
    ScTestFunc* pFunc = &pFile->aFuncs[g.CurrentFunction];
    return pFunc;
}

const char*
_sc_test_create_string_expected(const char* pValue)
{
    if (*pValue == '\"')
    {
        return "expected";
    }
    return pValue;
}

void
sc_test_string_equal_ext(const char* pStr0, const char* pStr1, const char* pStr0Name, const char* pStr1Name)
{
    char* pS0 = (char*)pStr0;
    char* pS1 = (char*)pStr1;

    i64 s0Len = sc_string_get_length(pS0);
    i64 s1Len = sc_string_get_length(pS1);

    pStr0Name = _sc_test_create_string_expected(pStr0Name);
    pStr1Name = _sc_test_create_string_expected(pStr1Name);

    static i32 c_max_size = 2 * 1024;
    static i32 c_max_size_free = 256;
    char buf[c_max_size] = {};

    if (pS0 && pS1)
    {
        i32 isEqual;
        if (s0Len == s1Len)
        {
            isEqual = sc_string_compare_ext(pS0, pS1, s0Len);
        }
        else
        {
            isEqual = 0;
        }

        pS0 = sc_string_substring_length(pS0, s0Len, ScMin(c_max_size_free, s0Len));
        pS1 = sc_string_substring_length(pS1, s1Len, ScMin(c_max_size_free, s1Len));

        i32 record_value;

        if (isEqual)
        {
            snprintf(buf, c_max_size, "%s(%s) == %s(%s)", pStr0Name, pS0, pStr1Name, pS1);
            record_value = 1;
        }
        else
        {
            snprintf(buf, c_max_size, "%s(%s) == %s(%s)", pStr0Name, pS0, pStr1Name, pS1);
            record_value = 0;
        }

        char* pBufAllocated = sc_string_new(buf);
        sc_test_set_record((ScTestRecr) { record_value, pBufAllocated });
    }
    else
    {
        snprintf(buf, c_max_size, "%s%s == %s(%s)", pStr0Name, pS0, pStr1Name, pS1);
        char* pBufAllocated = sc_string_new(buf);
        sc_test_set_record((ScTestRecr) { 0, pBufAllocated });
    }
}

const char*
_sc_test_create_expected(const char* pStr)
{
    char c = *pStr;
    if (sc_char_is_integer(c) || c == '-' || c == '+')
        return "expected";
    return pStr;
}

void
sc_test_i32_equal_ext(i32 i0, i32 i1, const char* pI0Str, const char* pI1Str)
{
    char buf[1024] = {};

    pI0Str = _sc_test_create_expected(pI0Str);
    pI1Str = _sc_test_create_expected(pI1Str);

    i32 isEqual = i0 == i1;
    if (isEqual)
        snprintf(buf, 1024, "%s(%d) == %s(%d)", pI0Str, i0, pI1Str, i1);
    else
        snprintf(buf, 1024, "%s(%d) != %s(%d)", pI0Str, i0, pI1Str, i1);
    char* pBuf = sc_string_new(buf);
    sc_test_set_record((ScTestRecr) { isEqual, pBuf });
}

void
sc_test_i64_value_ext(i64 value, const char* pValueName)
{
    char buf[1024] = {};
    snprintf(buf, 1024, "%s(%lld)", pValueName, value);
    char* pBuf = sc_string_new(buf);
    sc_test_set_record((ScTestRecr) { 1, pBuf });
}

void
sc_test_set_record(ScTestRecr testRecord)
{
    ScTestFunc* pFunc = sc_test_func_get();
    sc_list_add(pFunc->aRecords, testRecord);
}

i32
sc_test_is_function_was_failed()
{
    ScTestFunc* pFunc = sc_test_func_get();
    return sc_list_index_of(pFunc->aRecords, item.Code == 0) != -1;
}

ScTestFile*
sc_test_get()
{
    return g.aFiles;
}

i32
_test_is_any_function_failed(ScTestFile file)
{
    i64 funcsCount = sc_list_count(file.aFuncs);

    for (i32 fu = 0; fu < funcsCount; ++fu)
    {
        ScTestFunc func = file.aFuncs[fu];

        sc_list_for_each(func.aRecords, pRec)
        {
            if (!pRec->Code)
            {
                return 1;
            }
        }
    }

    return 0;
}

void
sc_test_visualize(ScTestFile* aFiles, ScTestVisualizeConfig cfg)
{
    i64 maxLen = 0;
    sc_list_for_each(aFiles, pFile)
    {
        sc_list_for_each(pFile->aFuncs, pFunc)
        {
            i64 funcNameLen = sc_string_get_length(pFunc->pName);
            if (funcNameLen > maxLen)
            {
                maxLen = funcNameLen;
            }
        }
    }

    for (i32 f = 0; f < sc_list_count(aFiles); ++f)
    {
        ScTestFile file = aFiles[f];

        i32 fileFailed = _test_is_any_function_failed(file);
        if (fileFailed || !cfg.IsShort)
        {
            printf("[File] %s\n", file.pFileName);
            ScTestFunc* aFuncs;

            for (i32 fu = 0; fu < sc_list_count(file.aFuncs); ++fu)
            {
                ScTestFunc func = file.aFuncs[fu];

                i32 isSuccess = 1;
                sc_list_for_each(func.aRecords, pRec)
                {
                    if (!pRec->Code)
                    {
                        isSuccess = 0;
                        break;
                    }
                }

                printf("  [Function] %s ", func.pName);
                i64 diff = maxLen - sc_string_get_length(func.pName);
                for (i32 c = 0; c < diff; ++c)
                {
                    printf(" ");
                }

                if (isSuccess)
                    printf(" ✅\n");
                else
                    printf(" ❌\n");

                i32 should_print_long = (cfg.IsShort == 2 && isSuccess == 0) || (cfg.IsShort == 0 || (sc_list_index_of(cfg.aLongPrintFuncs, sc_string_compare(item, func.pName)) != -1));

                if (should_print_long)
                {
                    for (i32 r = 0; r < sc_list_count(func.aRecords); ++r)
                    {
                        ScTestRecr record = func.aRecords[r];

                        if (record.Code)
                        {
                            printf("    " ScTerminalGreen("%s") "\n", record.pMessage);
                        }
                        else
                        {
                            printf("    " ScTerminalRed("%s") "\n", record.pMessage);
                        }
                    }
                }
            }
        }
        else
        {
            printf("[File] %s", file.pFileName);
            i64 diff = maxLen - sc_string_get_length(file.pFileName) + 7;
            for (i32 c = 0; c < diff; ++c)
                printf(" ");
            printf(" ✅\n");
        }
    }
}
