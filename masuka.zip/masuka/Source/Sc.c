#include "Sc.h"
#include "Types.h"

#if defined(SC_PLATFORM_LINUX)
// #define _POSIX_C_SOURCE 199309L //

// Enable POSIX + BSD features (required for DT_* constants)
#define _POSIX_C_SOURCE 200809L // for clock_gettime()
#define _DEFAULT_SOURCE
#define _BSD_SOURCE // Legacy, but some systems still need it

#include "pwd.h"
#include <bits/pthreadtypes.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/random.h> // for sc_random
#include <time.h>
#include <unistd.h>

#elif defined(SC_PLATFORM_WINDOWS)

#define _WINSOCKAPI_
#include <Windows.h>
#include <bcrypt.h> // for sc_random
#include <pathcch.h>
#include <shlobj.h> // For SHGetFolderPath => Get home dir
#include <windows.h>

#endif

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*

  ###################################
  ###################################
  sc_sleep
  ###################################
  ###################################

*/

void
sc_sleep_ms(i32 ms)
{
    if (ms <= 0)
        return;

#if defined(SC_PLATFORM_WINDOWS)
    Sleep(ms);
#elif defined(SC_PLATFORM_LINUX)
    // Convert milliseconds to microseconds
    struct timespec ts;
    struct timespec rmts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000L;

    while (nanosleep(&ts, &rmts) == -1)
    {
        // note: потокобезопасно (но это не точно)
        i32 err = errno;
        if (err != EINTR)
            break;
        if (rmts.tv_sec == 0 && rmts.tv_nsec == 0)
            break;
        ts = rmts;
    }
#endif // SC_PLATFORM_LINUX
}

/*

  ###################################
  ###################################
  sc_utf8
  ###################################
  ###################################

*/

u64
sc_utf8_unicode_size(u32* aUnicodes, u64 length)
{
    u64 size = 0;

    u32* ptr = aUnicodes;
    for (u64 i = 0; i < length; ++i)
    {
        u32 codepoint = *ptr;

        if (codepoint < 0x80)
            size += 1;
        else if (codepoint < 0x800)
            size += 2;
        else if (codepoint < 0x10000)
            size += 3;
        else if (codepoint < 0x110000)
            size += 4;

        ++ptr;
    }

    return size;
}

i64
sc_utf8_length(char* pInput)
{
    u64 length = 0;
    char* ptr = (char*)pInput;
    char c = *ptr;
    while (c)
    {
        length += (c & 0xc0) != 0x80;
        ++ptr;
        c = *ptr;
    }

    return length;
}

u64
sc_utf8_size(char* pInput)
{
    u64 size = 0;
    char* ptr = (char*)pInput;
    char c = *ptr;

    while (c)
    {
        if ((c >> 7) == 0)
        {
            size += 1;
            ptr += 1;
            c = *ptr;
        }
        else if (((c & 0xF0) == 0xF0)) // 4 byte
        {
            size += 4;
            ptr += 4;
            c = *ptr;
        }
        else if ((c & 0xE0) == 0xE0) // 3 byte
        {
            size += 3;
            ptr += 3;
            c = *ptr;
        }
        else if ((c & 0xC0) == 0xC0) // 2 byte
        {
            size += 2;
            ptr += 2;
            c = *ptr;
        }
        else
        {
            // crash
            break;
        }
    }

    return size;
}

i32
sc_utf8_encode(char* pOutput, u32 codepoint)
{
    /* DOCS:
      https://www.rapidtables.org/convert/number/binary-to-decimal.html

      starts with
      0) 0 - 1 byte utf8 -> 7 bits long
      1) 110   (0xC0) - 2 byte utf8 -> 11 bits long
      2) 1110  (0xE0) - 3 byte utf8 -> 16 bits long
      3) 11110 (0XF0) - 4 byte utf8 -> 21 bits long
      4) 10 - 2nd, 3rd, 4th byte of 0) - 3)

      2 byte:
      |      5| |      6|
      0xC0 - 192|10 -> 1100 0000|2

      3 byte:
      |      4| |      6| |      6|
      1110 0000 1000 0000 1000 0000

      0xE0 - 224|10 -> 1110 0000|2

    */

    i32 bytesCount = 0;
    if (codepoint < 0x80 /* 1b / 7 bit */)
    {
        *pOutput = codepoint;

        bytesCount = 1;
    }
    else if (codepoint < 0x800 /* 2b / 11 bits */)
    {
        *pOutput = (codepoint >> 6) | 0xC0;
        ++pOutput;

        *pOutput = (codepoint & 0x3F) | 0x80;

        bytesCount = 2;
    }
    else if (codepoint < 0x10000 /* 3b / 16 bits */)
    {
        *pOutput = (codepoint >> 12) | 0xE0;
        ++pOutput;

        *pOutput = ((codepoint >> 6) & 0x3f) | 0x80;
        ++pOutput;

        *pOutput = (codepoint & 0x3F) | 0x80;

        bytesCount = 3;
    }
    else if (codepoint < 0x110000 /* 4b / 21 bits */)
    {
        *pOutput = (codepoint >> 18) | 0XF0;
        ++pOutput;

        *pOutput = ((codepoint >> 12) & 0x3F) | 0x80;
        ++pOutput;

        *pOutput = ((codepoint >> 6) & 0x3F) | 0x80;
        ++pOutput;

        *pOutput = (codepoint & 0x3F) | 0x80;

        bytesCount = 4;
    }

    return bytesCount;
}

u32
sc_utf8_decode(char* pInput, i32* pBytes)
{
    u32 codepoint;

    /*
      starts with
      0) 0 - 1 byte utf8 -> 7 bits long
      1) 110 - 2 byte utf8 -> 11 bits long
      2) 1110 - 3 byte utf8 -> 16 bits long
      3) 11110 - 4 byte utf8 -> 21 bits long
      4) 10 - 2nd, 3rd, 4th byte of 0) - 3)

      |      4| |      6| |      6|
      1110 0000 1000 0000 1000 0000

    */

    // defining what's the size

    // DOCS: fb - first byte
    char fb = *pInput;

    if ((fb >> 7) == 0)
    {
        codepoint = fb;

        if (pBytes)
            *pBytes = 1;
    }
    else if (((fb & 0xF0) == 0xF0)) // 4 byte
    {
        codepoint = ((pInput[0]) & 0x07) << 18;
        codepoint |= ((pInput[1]) & 0x3F) << 12;
        codepoint |= ((pInput[2]) & 0x3F) << 6;
        codepoint |= ((pInput[3]) & 0x3F);

        if (pBytes)
            *pBytes = 4;
    }
    else if ((fb & 0xE0) == 0xE0) // 3 byte
    {
        //   |       | |       | |       |
        // 0 xxxx 1001 1010 0000 1001 1001
        // 1 1110 1001 xx10 0000 1001 1001
        // 2 1110 1001 1010 0000 1001 1001
        //
        // r 1111 1111 1111 1111
        //

        codepoint = ((pInput[0]) & 0x0F) << 12;
        codepoint |= ((pInput[1]) & 0x3F) << 6;
        codepoint |= ((pInput[2]) & 0x3F);

        if (pBytes)
            *pBytes = 3;
    }
    else if ((fb & 0xC0) == 0xC0) // 2 byte
    {
        codepoint = ((pInput[0]) & 0x1F) << 6;
        codepoint |= ((pInput[1]) & 0x3F);

        if (pBytes)
            *pBytes = 2;
    }

    return codepoint;
}

void
sc_utf8_get_unicode_text(i32* pUnicodeText, char* pUtf8Text, i64* pTextLength)
{
    i32 size = sc_utf8_size(pUtf8Text);
    i32 unicodeTextLength = sc_utf8_length(pUtf8Text);

    for (i32 i = 0, ind = 0; i < size; ++ind)
    {
        i32 bytesCount = 0;
        u32 unicode = sc_utf8_decode(&pUtf8Text[i], &bytesCount);

        if (ind < unicodeTextLength)
            pUnicodeText[ind] = unicode;

        i += bytesCount;
    }

    if (pTextLength)
        *pTextLength = unicodeTextLength;
}

// todo: rename

/*

  ###################################
  ###################################
  sc_parse
  ###################################
  ###################################

*/

ScParsedInt
sc_parse_int_while_int(char* pInput)
{
    char* iterPtr = pInput;
    char ic = *iterPtr;
    while ((ic >= '0' && ic <= '9'))
    {
        ++iterPtr;
        ic = *iterPtr;
    }

    i64 intValueLength = (i64)(u64)(iterPtr - pInput);
    if (intValueLength <= 0)
    {
        return (ScParsedInt) {
            .IntValue = 0,
            .pInput = pInput,
            .pOutput = NULL,
        };
    }

    i64 intValue = sc_parse_int(pInput, intValueLength);

    ScParsedInt intParsed = {
        .IntValue = intValue,
        .pInput = pInput,
        .pOutput = iterPtr,
    };

    return intParsed;
}

// DOCS: Parse from string to int.
i64
sc_parse_int(char* pBuffer, i64 bufferLength)
{
    i64 result = 0;
    i64 lastInd = bufferLength - 1;
    i64 multiplier = 1;
    char* ptr = pBuffer + lastInd;

    for (i64 i = lastInd; i >= 0; --i)
    {
        char c = *ptr;
        if (c >= '0' && c <= '9')
        {
            i32 intValue = (i32)(c - '0');
            result = intValue * multiplier + result;
            multiplier *= 10;
        }
        else
        {
            sc_guard(0);
        }

        --ptr;
    }

    return result;
}

// DOCS: Parse from string to float.

f64
sc_parse_float(char* pBuffer, i64 bufferLength)
{
    f64 result = 0;
    i64 lastInd = bufferLength - 1;
    i64 multiplier = *pBuffer == '-' ? -1 : 1;
    i32 flag = 0;
    i64 ind = 0;
    i64 i = 0;
    char* ptr = pBuffer;

    if (multiplier == -1)
    {
        ++ptr;
        --bufferLength;
    }

    while (ptr[i] == '0')
        ++i;

    // DOCS: Parse int value
    for (; i < bufferLength; ++i)
    {
        char c = ptr[i];
        i32 intValue = (i32)(c - '0');

        if (c == '.')
        {
            ++i;
            break;
        }
        else if (c < '0' || c > '9')
        {
            return result;
        }

        result *= 10;
        result += intValue;
    }

    // DOCS: Parse float value
    f64 divider = 10.0f;
    for (; i < bufferLength; ++i)
    {
        char c = ptr[i];
        i32 intValue = (i32)(c - '0');
        result += intValue / divider;
        divider *= 10;
    }

    result *= multiplier;

    return result;
}

char*
sc_parse_skip_space(char* pString)
{
    if (!pString)
        return pString;

    char c = *pString;
    while (c != '\0')
    {
        switch (c)
        {
        case ' ':
        case '\t':
        case '\n':
        case '\v':
        case '\r':
            break;
        default:
            return pString;
        }

        ++pString;
        c = *pString;
    }

    return pString;
}

char*
sc_parse_skip_while(char* pString, char* aSymbols, i32 symbolsCount)
{
    if (!pString || !aSymbols || symbolsCount <= 0)
        return pString;

    char c = *pString;

    while (c != '\0')
    {
        i32 isSkipping = 0;
        for (i32 s = 0; s < symbolsCount; ++s)
        {
            char symbolToSkip = aSymbols[s];
            if (c == symbolToSkip)
            {
                isSkipping = 1;
                break;
            }
        }

        if (!isSkipping)
            break;

        ++pString;
        c = *pString;
    }

    return pString;
}

/*

  ###################################
  ###################################
  sc_to_string
  ###################################
  ###################################

*/

i64
sc_int_to_string(char* pBuffer, i64 bufferLength, i64 intValue)
{
    i32 isNumberNegative = ((intValue < 0) ? 1 : 0);
    i64 i,
        rank = sc_get_int_digit(intValue) - 1,
        numberLength = rank + isNumberNegative + 1;

    if (isNumberNegative)
    {
        pBuffer[0] = '-';
        intValue = -intValue;
    }

    /*
      DOCS: 12937 -> "12937"; number = 12937; simple_core_get_int_digit(number) == 5;
    */

    for (i = isNumberNegative; i < numberLength; ++i)
    {
        if (i >= bufferLength)
            break;

        i64 divider = sc_int_power(10, rank);
        if (divider == -1)
            break;
        i32 value = intValue / divider % 10;
        char cvalue = ((char)value) + '0';

        pBuffer[i] = cvalue;
        --rank;
    }

    return numberLength;
}

i64
sc_float_to_string_ext(char* pBuffer, i64 bufferLength, f64 floatValue, f64 threshold)
{
    i64 intPart = (i64)floatValue;
    f64 floatPart = floatValue - intPart;

    // sc_log_info("intPart: %lld\n", intPart);
    // sc_log_info("floatPart: %f\n", floatPart);

    i64 bytesWritten = sc_int_to_string(pBuffer, bufferLength, intPart);
    i64 ind = 0;

    if (threshold == 0)
        goto ParseFloatExtReturnLabel;

    char* pFloatBuffer = pBuffer + bytesWritten;
    pFloatBuffer[ind] = '.';
    ++ind;

    i32 shouldContinue = (floatPart > threshold);
    if (!shouldContinue)
    {
        while (threshold < 1)
        {
            pFloatBuffer[ind] = '0';
            ++ind;
            threshold *= 10;
        }

        goto ParseFloatExtReturnLabel;
    }

    while (shouldContinue)
    {
        if (bytesWritten + ind >= bufferLength)
        {
            break;
        }

        floatPart *= 10;
        i32 ivalue = (i32)floatPart;
        sc_int_to_string(&pFloatBuffer[ind], 1, ivalue);
        ++ind;

        floatPart -= ivalue;
        threshold *= 10;

        shouldContinue = (floatPart > threshold);
    }

ParseFloatExtReturnLabel:
    return bytesWritten + ind;
}

i64
sc_float_to_string(char* pBuffer, i64 bufferLength, f64 floatValue)
{
    return sc_float_to_string_ext(pBuffer, bufferLength, floatValue, 1E-12);
}

i32
sc_v_to_string(char* pBuf, u64 bufSize, real* pArr, i32 arrCount, f64 accuracy)
{
    if (accuracy == 0)
        accuracy = 0.1;

    i64 ind = 0;
    pBuf[ind] = '{';
    ++ind;

    i32 lastInd = arrCount - 1;

    for (i32 i = 0; i < arrCount; ++i)
    {
        f32 v = pArr[i];
        char buf[64] = {};
        i32 bytesWritten = sc_float_to_string_ext(buf, 64, v, accuracy);
        i64 bufLen = sc_utf8_length(buf);
        memcpy(&pBuf[ind], buf, bufLen);
        ind += bytesWritten;

        if (i < lastInd)
        {
            pBuf[ind] = ',';
            ++ind;
            pBuf[ind] = ' ';
            ++ind;
        }
    }

    pBuf[ind] = '}';
    ++ind;

    return ind;
}

i32
sc_v2_to_string(char* pBuf, u64 bufSize, v2 v, f64 accuracy)
{
    real* pValues = v.V;
    i32 bytesWritten = sc_v_to_string(pBuf, bufSize, pValues, 2, accuracy);
    return bytesWritten;
}

i32
sc_v3_to_string(char* pBuf, u64 bufSize, v3 v, f64 accuracy)
{
    real* pValues = v.V;
    i32 bytesWritten = sc_v_to_string(pBuf, bufSize, pValues, 3, accuracy);
    return bytesWritten;
}

i32
sc_v4_to_string(char* pBuf, u64 bufSize, v4 v, f64 accuracy)
{
    real* pValues = v.V;
    i32 bytesWritten = sc_v_to_string(pBuf, bufSize, pValues, 4, accuracy);
    return bytesWritten;
}

i32
sc_quat_to_string(char* pBuf, u64 bufSize, quat q, f64 accuracy)
{
    real* pValues = q.V;
    i32 bytesWritten = sc_v_to_string(pBuf, bufSize, pValues, 4, accuracy);
    return bytesWritten;
}

/*

  ###################################
  ###################################
  sc_string
  ###################################
  ###################################

*/

i64
sc_string_get_length_ext_r(char* pStr)
{
    if (!pStr)
        return 0;

    char* ptr;
    for (ptr = pStr; *ptr != '\0'; ++ptr)
        ;

    i64 len = (i64)((u64)(ptr - pStr));
    return len;
}

u64
sc_string_get_length_to_delimiters_ext_r(char* pStr, char aDelimeters[], u64 delimetersLength)
{
    char* ptr = (char*)pStr;
    char c = *ptr;

    while (c != '\0')
    {
        i32 interrupt = 0;
        for (i32 i = 0; i < delimetersLength; ++i)
        {
            if (c == aDelimeters[i])
            {
                interrupt = 1;
                break;
            }
        }

        if (interrupt)
            break;

        ++ptr;
        c = *ptr;
    }

    i64 length = (i64)((u64)(ptr - pStr));
    return length;
}

i64
sc_string_hash_ext_r(char* pString, i32 stringLength)
{
    u64 hash = 5381;
    char* pEnd = pString + stringLength;
    for (char* pIter = pString; pIter != pEnd; ++pIter)
        hash = ((hash << 5) + hash) + *pIter;
    return hash;
}

i32
sc_string_compare_ext_ext_r(char* pString0, char* pString1, i64 string0Length)
{
    if (string0Length == 0)
        return 0;

    char* pIter0 = (char*)pString0;
    char* pIter1 = (char*)pString1;
    char* pEnd = pIter0 + string0Length;

    do
    {
        char c0 = *pIter0;
        char c1 = *pIter1;
        if (c0 != c1)
            return 0;

        ++pIter0;
        ++pIter1;
    }
    while (pIter0 != pEnd);

    return 1;
}

i32
sc_string_compare_ext_r(char* pString0, char* pString1)
{
    sc_assert_not_null(pString0);
    sc_assert_not_null(pString1);

    i64 string0Length = sc_string_get_length(pString0),
        string1Length = sc_string_get_length(pString1);

    if ((string0Length != string1Length) || (string0Length == 0) || (string1Length == 0))
    {
        return 0;
    }

    char* pIter0 = (char*)pString0;
    char* pIter1 = (char*)pString1;
    for (char* pEnd = pIter0 + string0Length;
        pIter0 != pEnd;
        ++pIter0, ++pIter1)
    {
        if (*pIter0 != *pIter1)
            return 0;
    }

    return 1;
}

i64
sc_string_index_of_ext_r(char* pString, char character)
{
    sc_assert_not_null(pString);

    char* pIter = pString;
    char* pEnd = pString + sc_string_get_length(pString);

    while (pIter != pEnd)
    {
        char c = *pIter;
        if (c == character)
            return (i64)(u64)(pIter - pString);
        ++pIter;
    }

    return -1;
}

i64
sc_string_index_of_string_ext_r(char* pInput, char* pString)
{
    sc_assert_not_null(pInput);
    sc_assert_not_null(pString);

    i64 inputLength = sc_string_get_length(pInput);
    i64 stringLength = sc_string_get_length(pString);

    if (inputLength <= 0 || stringLength <= 0 || stringLength > inputLength)
        return -1;

    char fc = *pString;
    char* pEnd = pInput + inputLength;

    for (char* pIter = pInput; pIter != pEnd; ++pIter)
    {
        char c = *pIter;
        if (c == fc && sc_string_compare_ext(pIter, pString, stringLength))
        {
            return (i64)(u64)(pIter - pInput);
        }
    }

    return -1;
}

i64
sc_string_last_index_of_ext_r(char* pString, char character)
{
    if (!pString)
    {
#if defined(SC_BUILD_DEBUG)
        sc_log_warn("pString is null!\n");
#endif
        sc_assert(pString && "Input string can't be NULL!!!");
    }

    char* pEnd = pString + sc_string_get_length(pString);
    char* pIter = pEnd;
    char c = *pIter;

    do
    {
        --pIter;
        c = *pIter;

        if (c == character)
        {
            i64 len = pEnd - pString;
            u64 diff = (u64)(len - (pEnd - pIter));
            return (i64)diff;
        }
    }
    while (pIter != pString);

    return -1;
}

char*
sc_string_substring_length_ext_r(char* pInput, u64 inputLength, i32 lengthToCut)
{
    sc_assert_not_null(pInput);
    sc_assert(lengthToCut <= inputLength);

    char* result = sc_memory_allocate(lengthToCut + 1);
    memcpy(result, pInput, lengthToCut);
    result[lengthToCut] = '\0';

    return result;
}

char*
sc_string_copy_ext_r(char* pString, i64 stringLength)
{
    char* pCopy = sc_memory_allocate(stringLength + 1);
    memcpy(pCopy, pString, stringLength);
    pCopy[stringLength] = '\0';
    return pCopy;
}

char*
sc_string_to_upper_ext_r(char* pString, i64 stringLength)
{
    char* pUpper = sc_memory_allocate(stringLength + 1);
    char* pStart = pUpper;
    pUpper[stringLength] = '\0';
    char* pPtr = pString;
    char* pEnd = pString + stringLength;

    for (; pPtr != pEnd;)
    {
        *pUpper = sc_char_to_upper(*pPtr);
        ++pUpper;
        ++pPtr;
    }

    return pStart;
}

char*
sc_string_to_lower_ext_r(char* pString, i64 stringLength)
{
    char* pLower = sc_memory_allocate(stringLength + 1);
    char* pStart = pLower;
    pLower[stringLength] = '\0';
    char* pPtr = pString;
    char* pEnd = pString + stringLength;

    for (; pPtr != pEnd;)
    {
        *pLower = sc_char_to_lower(*pPtr);
        ++pLower;
        ++pPtr;
    }

    return pStart;
}

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

i64
sc_string_get_length_ext_d(char* pStr, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pStr)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_get_length(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return 0;
    }

    return sc_string_get_length_ext_r(pStr);
}

u64
sc_string_get_length_to_delimiters_ext_d(char* pStr, char aDelimeters[], u64 delimetersLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pStr)
    {
        sc_log_warn("[%s:%d -> %s] string_get_length_to_delimiters(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return 0;
    }

    if (!aDelimeters)
    {
        sc_log_warn("[%s:%d -> %s] string_get_length_to_delimiters(aDelimeters <- is null or undefined)\n",
            pFile,
            line,
            pFunction);
        return 0;
    }

    if (delimetersLength <= 0)
    {

        sc_log_warn("[%s:%d -> %s] string_get_length_to_delimiters(delimetersLength <- is less or equal 0)\n",
            pFile,
            line,
            pFunction);
        return 0;
    }

    return sc_string_get_length_to_delimiters_ext_r(pStr, aDelimeters, delimetersLength);
}

i64
sc_string_hash_ext_d(char* pString, i32 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_hash(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return 0;
    }

    if (stringLength < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_hash(%s length %d is negative)\n",
            pFile,
            line,
            pFunction,
            pExpression,
            stringLength);
        return 0;
    }

    return sc_string_hash_ext_r(pString, stringLength);
}

i32
sc_string_compare_ext_ext_d(char* pString0, char* pString1, i64 string0Length, const char* pExpression0, const char* pExpression1, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_compare_ext(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression0);
        return 0;
    }

    if (!pString1)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_compare_ext(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression1);
        return 0;
    }

    if (string0Length < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_compare_ext(%s length %lld is negative)\n",
            pFile,
            line,
            pFunction,
            pExpression0,
            string0Length);
        return 0;
    }

    return sc_string_compare_ext_ext_r(pString0, pString1, string0Length);
}

i32
sc_string_compare_ext_d(char* pString0, char* pString1, const char* pExpression0, const char* pExpression1, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_compare(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression0);
        return 0;
    }

    if (!pString1)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_compare(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression1);
        return 0;
    }

    return sc_string_compare_ext_r(pString0, pString1);
}

i64
sc_string_index_of_ext_d(char* pString, char character, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_index_of(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return -1;
    }

    return sc_string_index_of_ext_r(pString, character);
}

i64
sc_string_index_of_string_ext_d(char* pInput, char* pString, const char* pExpression0, const char* pExpression1, const char* pFile, i32 line, const char* pFunction)
{
    if (!pInput)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_index_of_string(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression0);
        return -1;
    }

    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_index_of_string(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression1);
        return -1;
    }

    return sc_string_index_of_string_ext_r(pInput, pString);
}

i64
sc_string_last_index_of_ext_d(char* pString, char character, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_last_index_of(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return -1;
    }

    return sc_string_last_index_of_ext_r(pString, character);
}

char*
sc_string_substring_length_ext_d(char* pInput, u64 inputLength, i32 lengthToCut, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pInput)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_substring_length(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return ScNull;
    }

    if (lengthToCut < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_substring_length(%s lengthToCut %d is negative)\n",
            pFile,
            line,
            pFunction,
            pExpression,
            lengthToCut);
        return ScNull;
    }

    if ((u32)lengthToCut > inputLength)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_substring_length(%s lengthToCut %d exceeds inputLength %llu)\n",
            pFile,
            line,
            pFunction,
            pExpression,
            lengthToCut,
            inputLength);
        return ScNull;
    }

    return sc_string_substring_length_ext_r(pInput, inputLength, lengthToCut);
}

char*
sc_string_copy_ext_d(char* pString, i64 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_copy(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return ScNull;
    }

    if (stringLength <= 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_copy(%s, stringLength %ld <= 0)\n",
            pFile,
            line,
            pFunction,
            pExpression,
            stringLength);
        return ScNull;
    }

    return sc_string_copy_ext_r(pString, stringLength);
}

char*
sc_string_to_upper_ext_d(char* pString, i64 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_to_upper(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return ScNull;
    }

    if (stringLength < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_to_upper(%s length %lld is negative)\n",
            pFile,
            line,
            pFunction,
            pExpression,
            stringLength);
        return ScNull;
    }

    return sc_string_to_upper_ext_r(pString, stringLength);
}

char*
sc_string_to_lower_ext_d(char* pString, i64 stringLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_to_lower(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return ScNull;
    }

    if (stringLength < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_to_lower(%s length %lld is negative)\n",
            pFile,
            line,
            pFunction,
            pExpression,
            stringLength);
        return ScNull;
    }

    return sc_string_to_lower_ext_r(pString, stringLength);
}

/*

  ###################################
  ###################################
  sc_string (object)
  ###################################
  ###################################

*/

char*
sc_string_new_ext_r(char* pString)
{
    if (!pString)
        return ScNull;

    i64 len = sc_utf8_length(pString);
    i64 siz = sc_utf8_size(pString);
    char* pScString = sc_string_new_ext_ext_r(pString, len, siz);
    return pScString;
}

char*
sc_string_new_ext_ext_r(char* pString, i64 length, i64 size)
{
    if (!pString)
        return ScNull;

    ScString* pHeader = sc_memory_allocate(sizeof(ScString) + size + 1);
    pHeader->pData = ((char*)pHeader) + sizeof(ScString);
    memcpy(pHeader->pData, pString, size);
    pHeader->pData[size] = '\0';

    pHeader->Length = length;
    pHeader->Size = size;

    return pHeader->pData;
}

char*
sc_string_new_trimed_ext_r(char* pString)
{
    if (!pString)
        return ScNull;

    i64 len = sc_utf8_length(pString);
    i64 siz = sc_utf8_size(pString);

    i64 lenWoSpaces = sc_string_get_length_wo_whitespaces_ext_ext_r(pString, siz);
    ScString* pHeader = sc_memory_allocate(sizeof(ScString) + lenWoSpaces + 1);
    pHeader->pData = ((char*)pHeader) + sizeof(ScString);
    pHeader->pData[siz] = '\0';
    pHeader->Length = len;
    pHeader->Size = siz;

    char* pWrite = pHeader->pData;
    char* pRead = pString;

    for (i64 c = 0; c < siz; ++c)
    {
        if (sc_char_is_whitespace(*pRead) == 0)
        {
            *pWrite = *pRead;
            ++pWrite;
        }
        ++pRead;
    }

    return pHeader->pData;
}

void
sc_string_destroy_ext_r(char* pString)
{
    if (!pString)
        return;

    ScString* pHeader = sc_string_header_ext_r(pString);
    sc_memory_free(pHeader);
}

i64
sc_string_get_length_wo_whitespaces_ext_ext_r(char* pString, i64 size)
{
    i64 lenWoSpaces = 0;
    char* ptr = pString;
    for (i64 i = 0; i < size; ++i)
    {
        if (!sc_char_is_whitespace(*ptr))
            ++lenWoSpaces;
        ++ptr;
    }
    return lenWoSpaces;
}

char*
sc_string_replace_ext_r(char* pString, char* pOldValue, i64 oldValueLength, char* pNewValue, i64 newValueLength)
{
    i64 strLength = sc_string_length(pString);

    char oc = pOldValue[0];

    char* pSb = sc_builder_new();

    for (i64 i = 0; i < strLength; ++i)
    {
        char c = pString[i];

        if (c == oc && sc_string_compare_ext(&pString[i], pOldValue, oldValueLength))
        {
            sc_builder_append_string(pSb, pNewValue, newValueLength);
        }
        else
        {
            sc_builder_append_char(pSb, c);
        }
    }

    i64 sbCnt = sc_builder_count(pSb);
    char* pReplacedStr = sc_string_new_ext_ext_r(pSb, sbCnt, sbCnt);
    return pReplacedStr;
}

char*
sc_string_replace_string_to_char_ext_r(char* pString, char* pOldValue, i64 oldValueLength, char newValue)
{
    i64 strLength = sc_string_length(pString);

    char oc = pOldValue[0];

    char* pSb = sc_builder_new();

    for (i64 i = 0; i < strLength; ++i)
    {
        char c = pString[i];

        if (c == oc && sc_string_compare_ext(&pString[i], pOldValue, oldValueLength))
        {
            sc_builder_append_char(pSb, newValue);
        }
    }

    i64 sbCnt = sc_builder_count(pSb);
    char* pReplacedStr = sc_string_new_ext_ext_r(pSb, sbCnt, sbCnt);
    return pReplacedStr;
}

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

ScString*
sc_string_header_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_header(%s <- is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
    }
    return sc_string_header_ext_r(pString);
}

i64
sc_string_length_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_length(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return 0;
    }
    return sc_string_length_ext_r(pString);
}

i64
sc_string_size_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_size(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return 0;
    }
    return sc_string_size_ext_r(pString);
}

char*
sc_string_new_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_new(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    return sc_string_new_ext_r(pString);
}

char*
sc_string_new_ext_ext_d(char* pString, i64 length, i64 size, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_new_ext(%s <- pString is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    if (length < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_new_ext(%s <- length = %lld, must be >= 0)\n", pFile, line, pFunction, pExpression, length);
        return ScNull;
    }
    if (size < length)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_new_ext(%s <- size = %lld is less than length = %lld)\n", pFile, line, pFunction, pExpression, size, length);
        return ScNull;
    }
    return sc_string_new_ext_ext_r(pString, length, size);
}

char*
sc_string_new_trimed_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_new_trimed(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    return sc_string_new_trimed_ext_r(pString);
}

void
sc_string_destroy_ext_d(char* pString, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_destroy(%s <- is null or undefined)\n", pFile, line, pFunction, pExpression);
        return;
    }
    sc_string_destroy_ext_r(pString);
}

i64
sc_string_get_length_wo_whitespaces_ext_ext_d(char* pString, i64 size, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_get_length_wo_whitespaces(%s <- pString is null or undefined)\n", pFile, line, pFunction, pExpression);
        return 0;
    }
    if (size <= 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_get_length_wo_whitespaces(%s <- size = %lld, must be > 0)\n", pFile, line, pFunction, pExpression, size);
        return 0;
    }
    return sc_string_get_length_wo_whitespaces_ext_ext_r(pString, size);
}

char*
sc_string_replace_ext_d(char* pString, char* pOldValue, i64 oldValueLength, char* pNewValue, i64 newValueLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace(%s <- pString is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    if (!pOldValue)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace(%s <- pOldValue is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    if (!pNewValue)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace(%s <- pNewValue is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    if (oldValueLength <= 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace(%s <- oldValueLength = %lld, must be > 0)\n", pFile, line, pFunction, pExpression, oldValueLength);
        return ScNull;
    }
    if (newValueLength < 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace(%s <- newValueLength = %lld, must be >= 0)\n", pFile, line, pFunction, pExpression, newValueLength);
        return ScNull;
    }
    return sc_string_replace_ext_r(pString, pOldValue, oldValueLength, pNewValue, newValueLength);
}

char*
sc_string_replace_string_to_char_ext_d(char* pString, char* pOldValue, i64 oldValueLength, char newValue, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pString)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace_string_to_char(%s <- pString is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    if (!pOldValue)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace_string_to_char(%s <- pOldValue is null or undefined)\n", pFile, line, pFunction, pExpression);
        return ScNull;
    }
    if (oldValueLength <= 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_string_replace_string_to_char(%s <- oldValueLength = %lld, must be > 0)\n", pFile, line, pFunction, pExpression, oldValueLength);
        return ScNull;
    }
    return sc_string_replace_string_to_char_ext_r(pString, pOldValue, oldValueLength, newValue);
}

/*

  ###################################
  ###################################
  sc_string_view (object)
  ###################################
  ###################################

*/

ScStringView
sc_string_view_new(char* pData, i64 length)
{
    return sc_string_view_new_ext(pData, length, length);
}

ScStringView
sc_string_view_new_ext(char* pData, i64 length, i64 size)
{
    ScStringView view = {
        .pData = pData,
        .Length = length,
        .Size = size
    };
    return view;
}

/*

  ###################################
  ###################################
  sc_format
  ###################################
  ###################################

*/

ScFormatResult
sc_format_ext_ext_r(char* pBuf, u64 bufSize, const char* pFormat, va_list valist)
{
    ScFormatResult res = {};

    char* ptr = (char*)pFormat;
    char c = *ptr;
    i32 isFormat = 0;
    i32 ind = 0;
    i32 isLong = 0;

    // todo: check for buffer overflow
    i64 formatLength = sc_string_get_length((char*)pFormat);
    i64 bufOverflowInd = bufSize; // - formatLength;
    if (bufOverflowInd <= 0)
    {
        return res;
    }

    while (c != '\0' && (ind + 1) < bufSize)
    {
        if (c == '%')
        {
            isFormat = !isFormat;
            goto ScFormatExtIter;
        }

        if (!isFormat)
        {
            pBuf[ind] = c;
            ++ind;
            goto ScFormatExtIter;
        }

        if (ind >= bufOverflowInd)
        {
            res.IsFinished = 1;
            goto ScFormatSetResult;
        }

        // parse it
        switch (c)
        {

        case 'c':
            isFormat = 0;
            pBuf[ind] = c;
            ++ind;
            goto ScFormatExtIter;

        case 's':
        {
            isFormat = 0;
            char* pStr = va_arg(valist, char*);
            if (pStr == NULL)
            {
                memcpy(&pBuf[ind], "<NULL>", 6);
                ind += 6;
                goto ScFormatExtIter;
            }

            i64 strLen;
            i32 isSimpleString = (*(ptr + 1) == 's');
            if (isSimpleString)
                strLen = sc_string_length(pStr);
            else
                strLen = sc_utf8_length((char*)pStr);
            memcpy(&pBuf[ind], pStr, strLen);
            ind += strLen;

            goto ScFormatExtIter;
        }

        case 'l':
        {
            isFormat = 0;
            isLong = 1;
            goto ScFormatExtIter;
        }

        case 'd':
        {
            isFormat = 0;
            char buf[64] = {};
            if (isLong)
                sc_int_to_string(buf, 64, va_arg(valist, i64));
            else
                sc_int_to_string(buf, 64, va_arg(valist, i32));
            i64 bufLen = sc_utf8_length(buf);
            memcpy(&pBuf[ind], buf, bufLen);
            ind += bufLen;

            goto ScFormatExtIter;
        }

        case 'f':
        {
            isFormat = 0;
            char buf[64] = {};
            sc_float_to_string(buf, 64, va_arg(valist, f64));
            i64 bufLen = sc_utf8_length(buf);
            memcpy(&pBuf[ind], buf, bufLen);
            ind += bufLen;

            goto ScFormatExtIter;
        }

        case 'v':
        {
            isFormat = 0;
            ++ptr;
            c = *ptr;

            f64 accuracy = 0;
            i64 bytesWritten = 0;
            char buf[64] = {};

            switch (c)
            {
            case '2':
            {
                v2 v = va_arg(valist, v2);
                bytesWritten = sc_v2_to_string(buf, 64, v, accuracy);
                break;
            }

            case '3':
            {
                v3 v = va_arg(valist, v3);
                bytesWritten = sc_v3_to_string(buf, 64, v, accuracy);
                break;
            }
            case '4':
            {
                v4 v = va_arg(valist, v4);
                bytesWritten = sc_v4_to_string(buf, 64, v, accuracy);
                break;
            } // c == '2', in str "%v2" "%v3" "%v4"
            }

            memcpy(&pBuf[ind], buf, bytesWritten);
            ind += bytesWritten;

            goto ScFormatExtIter;
        }

            // case todo: m2, m3, m4

        case 'p':
        {
            isFormat = 0;
            void* pPointer = va_arg(valist, void*);
            char buf[128] = {};
            i64 bytesWritten = snprintf(buf, 128, "%p", pPointer);
            memcpy(&pBuf[ind], buf, bytesWritten);
            ind += bytesWritten;

            goto ScFormatExtIter;
        }

        default:
            // log an error
            break;
        }

    ScFormatExtIter:
        ++ptr;
        c = *ptr;
    }

    res.IsFinished = 1;

ScFormatSetResult:
    res.Size = ind;
    res.pFormat = ptr;
    res.IsFinished = (ptr == (pFormat + bufSize)) ? 1 : res.IsFinished;

    return res;
}

ScFormatResult
sc_format_ext_r(char* pBuf, u64 bufSize, const char* pFormat, ...)
{
    va_list valist;
    va_start(valist, pFormat);
    ScFormatResult res = sc_format_ext_ext_r(pBuf, bufSize, pFormat, valist);
    va_end(valist);
    return res;
}

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

ScFormatResult
sc_format_ext_ext_d(char* pBuf, u64 bufSize, const char* pFormat, va_list valist, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pBuf)
    {
        sc_log_warn("[%s:%d -> %s] sc_format_ext(%s <- pBuf is null or undefined)\n", pFile, line, pFunction, pExpression);
        ScFormatResult res = {};
        return res;
    }
    if (bufSize <= 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_format_ext(%s <- bufSize = %llu, must be > 0)\n", pFile, line, pFunction, pExpression, bufSize);
        ScFormatResult res = {};
        return res;
    }
    if (!pFormat)
    {
        sc_log_warn("[%s:%d -> %s] sc_format_ext(%s <- pFormat is null or undefined)\n", pFile, line, pFunction, pExpression);
        ScFormatResult res = {};
        return res;
    }
    return sc_format_ext_ext_r(pBuf, bufSize, pFormat, valist);
}

ScFormatResult
sc_format_ext_d(char* pBuf, u64 bufSize, const char* pFormat, const char* pExpression, const char* pFile, i32 line, const char* pFunction, ...)
{
    if (!pBuf)
    {
        sc_log_warn("[%s:%d -> %s] sc_format(%s <- pBuf is null or undefined)\n", pFile, line, pFunction, pExpression);
        ScFormatResult res = {};
        return res;
    }
    if (bufSize <= 0)
    {
        sc_log_warn("[%s:%d -> %s] sc_format(%s <- bufSize = %llu, must be > 0)\n", pFile, line, pFunction, pExpression, bufSize);
        ScFormatResult res = {};
        return res;
    }
    if (!pFormat)
    {
        sc_log_warn("[%s:%d -> %s] sc_format(%s <- pFormat is null or undefined)\n", pFile, line, pFunction, pExpression);
        ScFormatResult res = {};
        return res;
    }
    va_list valist;
    va_start(valist, pFunction);
    ScFormatResult res = sc_format_ext_ext_r(pBuf, bufSize, pFormat, valist);
    va_end(valist);
    return res;
}

/*

  ###################################
  ###################################
  sc_other
  ###################################
  ###################################

*/

i32
sc_get_int_digit(i64 intValue)
{
    /*
      I32_MAX == 2147483647, digit == 10
      I64_MAX 9223372036854775807LL, digit == 19 // 9 223 372 036 854 775 807=9e+18
    */

    if (intValue < 0)
        intValue = -intValue;

    if (intValue < 10)
        return 1;
    if (intValue < 100)
        return 2;
    if (intValue < 1000)
        return 3;
    if (intValue < 10000)
        return 4;
    if (intValue < 100000)
        return 5;
    if (intValue < 1000000)
        return 6;
    if (intValue < 10000000)
        return 7;
    if (intValue < 100000000)
        return 8;
    if (intValue < 1000000000)
        return 9;
    if (intValue < 10000000000)
        return 10;
    if (intValue < 100000000000)
        return 11;
    if (intValue < 1000000000000)
        return 12;
    if (intValue < 10000000000000)
        return 13;
    if (intValue < 100000000000000)
        return 14;
    if (intValue < 1000000000000000)
        return 15;
    if (intValue < 10000000000000000)
        return 16;
    if (intValue < 100000000000000000)
        return 17;
    if (intValue < 1000000000000000000)
        return 18;

    return 19;
}

i64
sc_int_power(i64 intValue, i32 powerValue)
{
    if (powerValue == 0)
        return 1;
    else if (powerValue < 0)
        return -1;

    i64 result = intValue;
    --powerValue;
    while (powerValue)
    {
        result *= intValue;
        --powerValue;
    }

    return result;
}

f64
sc_float_npow(i32 exponent)
{
    f64 v = 1.0;
    while (exponent > 0)
    {
        v /= 10;
        --exponent;
    }
    return v;
}

/*

  ###################################
  ###################################
  sc_list
  ###################################
  ###################################

*/

void
sc_list_free(void* pList)
{
    if (!pList)
        return;

    ScListHeader* pHdr = sc_list_header(pList);
    sc_memory_free(pHdr);
}

void*
sc_list_add_ext(void* pList, void* pData, i32 stride)
{
    // DOCS: Create new
    if (pList == NULL)
    {
        ScListHeader* pHdr = (ScListHeader*)sc_memory_allocate(sizeof(ScListHeader) + stride);
        pHdr->Count = 1;
        pHdr->Capacity = 1;
        pHdr->pData = ((void*)pHdr) + sizeof(ScListHeader);
        memcpy(pHdr->pData, pData, stride);
        return pHdr->pData;
    }

    // DOCS: Realloc
    ScListHeader* pHdr = sc_list_header(pList);
    if (pHdr->Count >= pHdr->Capacity)
    {
        i64 newCapacity = 2 * pHdr->Capacity + 1;
        ScListHeader* pNewHdr = (ScListHeader*)sc_memory_allocate(sizeof(ScListHeader) + newCapacity * stride);
        pNewHdr->Count = pHdr->Count + 1;
        pNewHdr->Capacity = newCapacity;
        pNewHdr->pData = ((void*)pNewHdr) + sizeof(ScListHeader);
        memcpy(pNewHdr->pData, pHdr->pData, pHdr->Count * stride);
        memcpy(pNewHdr->pData + pHdr->Count * stride, pData, stride);
        sc_memory_free(pHdr);
        return pNewHdr->pData;
    }

    // DOCS: Just add new data
    memcpy(pHdr->pData + pHdr->Count * stride, pData, stride);
    ++pHdr->Count;

    return pHdr->pData;
}

void*
sc_list_add_multiple_ext(void* pList, void* pData, i32 stride, i64 count)
{
    if (pList == NULL)
    {
        u64 size = stride * count;
        ScListHeader* pHdr = (ScListHeader*)sc_memory_allocate(sizeof(ScListHeader) + size);
        pHdr->Count = count;
        pHdr->Capacity = count;
        pHdr->pData = ((char*)pHdr) + sizeof(ScListHeader);
        memcpy(pHdr->pData, pData, size);
        return pHdr->pData;
    }

    ScListHeader* pHdr = sc_list_header(pList);
    if ((pHdr->Count + count) >= pHdr->Capacity)
    {
        i64 metricCount = ScMax(count, pHdr->Capacity);
        i64 newCapacity = 2 * metricCount + 1;
        ScListHeader* pNewHdr = (ScListHeader*)sc_memory_allocate(sizeof(ScListHeader) + newCapacity * stride);
        pNewHdr->Count = pHdr->Count;
        pNewHdr->Capacity = newCapacity;
        pNewHdr->pData = ((char*)pNewHdr) + sizeof(ScListHeader);
        memcpy(pNewHdr->pData, pHdr->pData, pHdr->Count * stride);
        sc_memory_free(pHdr);
        pHdr = pNewHdr;
    }

    u32 itemSize = stride * count;
    memcpy((char*)pHdr->pData + pHdr->Count * stride, pData, itemSize);
    pHdr->Count += count;

    return pHdr->pData;
}

void*
sc_list_remove_ext(void* pList, void* pItem, i32 stride)
{
    ScListHeader* pHdr = sc_list_header(pList);

    void* pRead = pList;
    i64 i;
    for (i = 0; i < pHdr->Count; ++i)
    {
        void* pIterItem = pRead;
        if (memcmp(pIterItem, pItem, stride) == 0)
            break;
        pRead += stride;
    }

    pList = sc_list_remove_index_ext(pList, i, stride);
    return pList;
}

void*
sc_list_remove_index_ext(void* pList, i32 ind, i32 stride)
{
    ScListHeader* pHdr = sc_list_header(pList);
    if (ind < 0 || ind >= pHdr->Count)
        return pList;

    i64 lastInd = pHdr->Count - 1;
    i64 itemsLeft = lastInd - ind;

    // DOCS: Ind pointing not to last item
    if (itemsLeft > 0)
    {
        // DOCS: Items left
        // DOCS: Copy items left
        void* pWritePtr = pList + ind * stride;
        void* pReadPtr = pWritePtr + stride;
        i64 copySize = itemsLeft * stride;

        memcpy(pWritePtr, pReadPtr, copySize);
    }

    // DOCS: set last item to 0|null
    memset(pList + lastInd * stride, 0, stride);
    --sc_list_header(pList)->Count;

    return pList;
}

void*
sc_list_reserve_ext(void* pList, i32 stride, i64 count)
{
    ScListHeader* pHdr = (ScListHeader*)sc_memory_allocate(sizeof(ScListHeader) + stride * count);
    pHdr->Count = 0;
    pHdr->Capacity = count;
    pHdr->pData = ((void*)pHdr) + sizeof(ScListHeader);
    return pHdr->pData;
}

void*
sc_list_clear_ext(void* pList, i32 stride)
{
    if (!pList)
        return ScNull;
    ScListHeader* pHdr = sc_list_header(pList);
    memset(pHdr->pData, '\0', pHdr->Capacity * stride);
    pHdr->Count = 0;
    return pHdr->pData;
}

void*
sc_list_deep_copy_ext(void* pList, i32 stride)
{
    if (!pList || stride == 0)
        return ScNull;

    ScListHeader* pHdr = sc_list_header(pList);
    u64 oldArrSize = pHdr->Capacity * stride;
    ScListHeader* pNewHdr = (ScListHeader*)sc_memory_allocate(sizeof(ScListHeader) + oldArrSize);
    *pNewHdr = *pHdr;
    pNewHdr->pData = ((void*)pNewHdr) + sizeof(ScListHeader);
    memcpy(pNewHdr->pData, pHdr->pData, oldArrSize);

    return pNewHdr->pData;
}

void*
sc_list_pop_ext(void* pList, i32 stride)
{
    ScListHeader* pHdr = sc_list_header(pList);
    --pHdr->Count;
    i32 lastIndex = pHdr->Count;
    void* pWrite = pList;
    void* pRead = ((char*)pList) + stride;
    u64 copySize = lastIndex * stride;
    memcpy(pWrite, pRead, copySize);
    memset(((char*)pList) + lastIndex * stride, 0, stride);
    return pList;
}

/*

  ###################################
  ###################################
  sc_dict / sc_dict_s / sc_dict_i
  ###################################
  ###################################

*/

static struct
{
    i32 aPrimes[38];
} gSvt = {
    .aPrimes = {
        7,
        11,
        13,
        17,
        19,
        23,
        29,
        31,
        37,
        41,
        43,
        47,
        53,
        97,
        193,
        389,
        769,
        1543,
        3079,
        6151,
        12289,
        24593,
        49157,
        98317,
        196613,
        393241,
        786433,
        1572869,
        3145739,
        6291469,
        12582917,
        25165843,
        50331653,
        100663319,
        201326611,
        402653189,
        805306457,
        1610612741 }
};

void
_sc_dict_set_int_storage_to_default(void* pStorage, i64 capacity, i64 itemSize)
{
    char* pIter = (char*)pStorage;

    for (i32 i = 0; i < capacity; ++i)
    {
        *(i64*)pIter = SC_DICT_EMPTY_KEY;
        pIter += itemSize;
    }
}

typedef enum
{
    ScDictFlag_Empty = 0,
    ScDictFlag_Freed,
    ScDictFlag_Exist,
} ScDictFlag;

/*
Ну хз, мы не удаляем флаги, а по факту переиспользуем один массив ..
*/
i8*
_sc_dict_flags_extend(i8* aFlags, i64 newCount)
{
    if (!aFlags)
    {
        sc_list_reserve(aFlags, newCount);
        sc_list_header(aFlags)->Count = newCount;
        for (i32 i = 0; i < newCount; ++i)
            aFlags[i] = ScDictFlag_Empty;
    }
    else
    {
        i64 current = sc_list_count(aFlags);
        if (newCount <= current)
        {
            sc_log_erro("Fatal error _sc_dict_flags_extend(.., newCount(%d)<current(%d))", newCount, current);
            sc_assert_break();
        }

        for (i32 d = current; d < newCount; ++d)
            sc_list_add(aFlags, ScDictFlag_Empty);
    }
    return aFlags;
}

void*
sc_dict_init(u32 recordSize, u32 valueOffset, ScDictKeyType type, u32 startInd)
{
    i32 prime = gSvt.aPrimes[startInd];
    u64 totalSize = prime * recordSize;
    ScDictHeader* pHdr = (ScDictHeader*)sc_memory_allocate(totalSize + sizeof(ScDictHeader));
    pHdr->Index = SC_DICT_EMPTY_KEY;
    pHdr->Count = 0;
    pHdr->Capacity = prime;
    pHdr->ItemSize = recordSize;
    pHdr->Type = type;
    pHdr->ValueOffset = valueOffset;
    pHdr->aStorage = (void*)(((char*)pHdr) + sizeof(ScDictHeader));
    if (type == ScDictKeyType_String)
    {
        memset(pHdr->aStorage, 0, totalSize);
    }
    else
    {
        _sc_dict_set_int_storage_to_default(pHdr->aStorage, pHdr->Capacity, pHdr->ItemSize);
    }

    if (startInd == 0)
        pHdr->aFlags = _sc_dict_flags_extend(NULL, prime);

    return pHdr->aStorage;
}

void
sc_dict_free(void* pDict)
{
    if (!pDict)
        return;

    ScDictHeader* pHdr = sc_dict_header(pDict);
    sc_list_free(pHdr->aFlags);
    sc_memory_free(pHdr);
}

void
sc_dict_clear(void* pDict)
{
    if (!pDict)
        return;

    ScDictHeader* pHdr = sc_dict_header(pDict);
    u64 totalSize = (u64)pHdr->Capacity * pHdr->ItemSize;

    if (pHdr->Type == ScDictKeyType_String)
        memset(pHdr->aStorage, 0, totalSize);
    else
    {
        // todo: TEST IT (use pointer to set it to default value)
        _sc_dict_set_int_storage_to_default(pHdr->aStorage, pHdr->Capacity, pHdr->ItemSize);
    }
    pHdr->Count = 0;

    memset(pHdr->aFlags, ScDictFlag_Empty, sc_list_count(pHdr->aFlags));
}

void*
sc_dict_grow_ext(void* pDict)
{
    // DOCS: Ищем индекс текущего ключа в списке простых чисел.
    i32 prevPrime = sc_dict_capacity(pDict);
    i32 ind = -1;
    for (i32 i = 0; i < ScArrayCount(gSvt.aPrimes); ++i)
    {
        i32 iterPrime = gSvt.aPrimes[i];
        if (prevPrime == iterPrime)
        {
            ind = i;
            break;
        }
    }

    // DOCS: Мы здесь не шутим.. @ КВН
    if (ind == -1)
    {
        sc_guard(0 && "[sc_dict_grow] Wrong index for prime number.");
    }

    // DOCS: Сохраняем предыдущее состояние
    ScDictHeader* pPrevHdr = sc_dict_header(pDict);
    i32 recordSize = pPrevHdr->ItemSize;
    i32 valueOffset = pPrevHdr->ValueOffset;
    i64 prevCount = pPrevHdr->Count;
    void* aPrevStorage = pPrevHdr->aStorage;

    // DOCS: Новый день - новая таблица.
    void* hNewTable = sc_dict_init(recordSize, valueOffset, pPrevHdr->Type, ind + 1);
    ScDictHeader* pHdr = sc_dict_header(hNewTable);

    // DOCS: Extend flags array, set every flag to empty.
    pHdr->aFlags = _sc_dict_flags_extend(pPrevHdr->aFlags, gSvt.aPrimes[ind + 1]);
    for (i32 i = 0; i < sc_list_count(pHdr->aFlags); ++i)
        pHdr->aFlags[i] = ScDictFlag_Empty;

    // DOCS: Проходимся по всей выделенной области и
    // находим старые ключи, записываем их в новую
    // таблицу, попутно формируя массив флагов.
    for (i32 i = 0; i < pPrevHdr->Capacity; ++i)
    {
        void* pWrite = aPrevStorage + i * recordSize;

        void* pKey;
        ScDictKeyType type = pHdr->Type;
        i32 isDefault = 0;

        switch (type)
        {
        case ScDictKeyType_String:
        {
            pKey = *(void**)pWrite;
            isDefault = (pKey == NULL);
            break;
        }
        case ScDictKeyType_Long:
        {
            i64 key = *((i64*)pWrite);
            isDefault = (key == SC_DICT_EMPTY_KEY);
            pKey = pWrite;
            break;
        }
        default:
        {
            sc_assert_break();
            break;
        }
        }

        if (isDefault)
            continue;

        i64 ind = sc_dict_calc_ind(pHdr->aStorage, pKey);
        void* pWriteNew = pHdr->aStorage + ind * recordSize;
        memcpy(pWriteNew, pWrite, recordSize);

        pHdr->aFlags[ind] = ScDictFlag_Exist;
    }

    sc_dict_header(pHdr->aStorage)->Count = prevCount;

    // DOCS: Чистим-чистим трубочиста, чтобы было..
    // NOTE: Проставляю в NULL -> не отчистить флаги раньше времени.
    pPrevHdr->aFlags = NULL;
    sc_dict_free(pPrevHdr->aStorage);

    return pHdr->aStorage;
}

void*
sc_dict_add_ext(void* pDict, void* pKey, void* pValue, u32 recordSize, u32 valueOffset, ScDictKeyType type)
{
    if (!pDict)
    {
        pDict = sc_dict_init(recordSize, valueOffset, type, 0);
    }
    else if (sc_dict_should_grow(pDict))
    {
        pDict = sc_dict_grow_ext(pDict);
    }

    sc_dict_header(pDict)->Type = type;

    i64 ind = sc_dict_calc_ind(pDict, pKey);

    ScDictHeader* pHdr = sc_dict_header(pDict);
    char* pWrite = (char*)pDict + ind * recordSize;
    char* pOffset = (char*)pWrite + valueOffset;

    switch (type)
    {
    case ScDictKeyType_String:
    {
        memcpy(pWrite, &pKey, sizeof(char*));
        break;
    }
    case ScDictKeyType_Long:
    {
        memcpy(pWrite, pKey, sizeof(i64));
        break;
    }
    default:
    {
        sc_assert_break();
        break;
    }
    }

    i32 isNotUpdate = !(pHdr->aFlags[ind] == ScDictFlag_Exist);
    pHdr->aFlags[ind] = ScDictFlag_Exist;
    memcpy(pOffset, pValue, recordSize - valueOffset);

    pHdr->Index = ind;

    if (isNotUpdate)
        pHdr->Count += 1;

    return pDict;
}

void*
sc_dict_remove_key(void* pDict, void* pKey)
{
    // todo: implement debug extension pattern
    if (!pDict)
        return pDict;

    ScDictHeader* pHdr = sc_dict_header(pDict);

    char* pStorage = pHdr->aStorage;
    u32 itemSize = pHdr->ItemSize;
    i64 ind;
    ScDictFlag flag;

    switch (pHdr->Type)
    {
    case ScDictKeyType_String:
    {
        ind = sc_dict_calc_ind_string(pHdr, pKey, 1);
        flag = pHdr->aFlags[ind];

        if (flag == ScDictFlag_Exist)
        {
            char* pWriteKey = pStorage + ind * itemSize;
            memset(pWriteKey, 0, sizeof(char*));
            memset(pWriteKey + sizeof(char*), 0, itemSize - sizeof(char*));
            pHdr->aFlags[ind] = ScDictFlag_Freed;
            --pHdr->Count;
        }

        break;
    }

    case ScDictKeyType_Long:
    {
        i64 key = *(i64*)pKey;
        ind = sc_dict_calc_ind_long(pHdr, key, 1);
        flag = pHdr->aFlags[ind];

        if (flag == ScDictFlag_Exist)
        {
            // DOCS: Set key to SC_DICT_EMPTY_KEY and value to 0.
            char* pWriteKey = pStorage + ind * itemSize;
            *((i64*)pWriteKey) = SC_DICT_EMPTY_KEY;
            memset(pWriteKey + sizeof(i64), 0, itemSize - sizeof(i64));
            pHdr->aFlags[ind] = ScDictFlag_Freed;
            --pHdr->Count;
        }

        break;
    }

    default:
    {
        // todo: implement debug extension pattern
        sc_assert_break();
        break;
    }
    }

    return pDict;
}

i64
sc_dict_calc_ind_long(ScDictHeader* pHdr, i64 key, i8 isGetFunc)
{
    i64 i;
    u64 index;

    u64 hash0 = sc_u64_hash((u64)key);
    u64 hash1 = 1 + (hash0 % (pHdr->Capacity - 1));
    char* pTable = (char*)pHdr->aStorage;

    for (i = 0; i < pHdr->Capacity; ++i)
    {
        index = (hash0 + i * hash1) % pHdr->Capacity;
        char* pAddr = (pTable + index * pHdr->ItemSize);
        i64 itemsKey = *((i64*)pAddr);

        // DOCS: либо тут пусто, либо мы нашли исмкомый ключ
        if (itemsKey == SC_DICT_EMPTY_KEY)
        {
            // DOCS: Изъятие существующего
            if (isGetFunc)
            {
                if (pHdr->aFlags[index] == ScDictFlag_Empty)
                {
                    pHdr->Index = index;
                    return index;
                }
            }
            // DOCS: Добавление ключа
            else if (pHdr->aFlags[index] != ScDictFlag_Exist)
            {
                pHdr->Index = index;
                return index;
            }
        }
        else if (itemsKey == key)
        {
            pHdr->Index = index;
            return index;
        }
    }

    pHdr->Index = -1;
    return -1;
}

i64
sc_dict_calc_ind_string(ScDictHeader* pHdr, char* pKey, i8 isGetFunc)
{
    i64 cap = pHdr->Capacity;
    u32 itemSize = pHdr->ItemSize;
    char* hTable = pHdr->aStorage;

    i32 i,
        index = -1,
        keyLength = sc_string_get_length(pKey);

    u64 hash0 = sc_string_hash(pKey, keyLength);
    u64 hash1 = 1 + (hash0 % (cap - 1));

    for (i = 0; i < cap; ++i)
    {
        index = (hash0 + i * hash1) % cap;
        char* pAddr = (char*)hTable + index * itemSize;
        char* pItemsKey;
        memcpy(&pItemsKey, pAddr, sizeof(char*));

        // DOCS: Пустая ячейка, ключ не найден?
        if (pItemsKey == NULL)
        {
            // NOTE: мы не обхеденяем флаги, чтобы не
            // передавать NULL в sc_string_compare()

            // DOCS: Изъятие существующего
            if (isGetFunc)
            {
                if (pHdr->aFlags[index] == ScDictFlag_Empty)
                {
                    pHdr->Index = index;
                    return index;
                }
            }
            // DOCS: Добавление ключа
            else if (pHdr->aFlags[index] != ScDictFlag_Exist)
            {
                pHdr->Index = index;
                return index;
            }
        }
        else if (sc_string_compare(pItemsKey, pKey))
        {
            pHdr->Index = index;
            return index;
        }
    }

    pHdr->Index = -1;
    return -1;
}

i64
sc_dict_calc_ind(void* pDict, void* pKey)
{
    if (!pDict || !pKey)
        return -1;

    // DOCS: String
    ScDictHeader* pHdr = sc_dict_header(pDict);

    switch (pHdr->Type)
    {
    case ScDictKeyType_Long:
        return sc_dict_calc_ind_long(pHdr, *(i64*)pKey, 0);

    case ScDictKeyType_String:
        return sc_dict_calc_ind_string(pHdr, (char*)pKey, 0);
    }

    return -1;
}

/*

  ###################################
  ###################################
  sc_grid
  ###################################
  ###################################

*/

ScGrid*
sc_grid_reserve_ext(i32 itemSize, i32 x, i32 y, i32 z)
{
    u64 dataSize = x * y * z * itemSize;
    ScGrid* pGrid = (ScGrid*)sc_memory_allocate(dataSize + sizeof(ScGrid));
    pGrid->X = x;
    pGrid->Y = y;
    pGrid->Z = z;
    pGrid->ItemSize = itemSize;
    pGrid->pData = (void*)pGrid + sizeof(ScGrid);
    memset(pGrid->pData, 0, dataSize);
    return pGrid;
}

void
sc_grid_set(ScGrid* pGrid, i32 x, i32 y, i32 z, void* pData)
{
    void* pValue = sc_grid_get(pGrid, x, y, z);
    memcpy(pValue, pData, pGrid->ItemSize);
}

void*
sc_grid_get(ScGrid* pGrid, i32 x, i32 y, i32 z)
{
#if defined(SC_BUILD_DEBUG)
    if (x < 0 || y < 0 || z < 0 || x > pGrid->X || y > pGrid->Y || z > pGrid->Z)
    {
        sc_log_erro("sc_grid_get(%p, %d, %d, %d): Out of bound!\n", pGrid, x, y, z);
        sc_assert_break();
    }
#endif // SC_BUILD_DEBUG
    return (char*)pGrid->pData + (x * pGrid->Y * pGrid->Z + y * pGrid->Z + z) * pGrid->ItemSize;
}

void
sc_grid_free(ScGrid* pGrid)
{
    sc_memory_free(pGrid);
}

/*

  ###################################
  ###################################
  sc_builder
  ###################################
  ###################################

*/

char*
sc_builder_new()
{
    char* pSb = ScNull;
    sc_list_reserve(pSb, sc_builder_new_size);
    memset(pSb, '\0', sc_builder_new_size);
    return pSb;
}

void
sc_builder_destroy(char* pSb)
{
    sc_list_free(pSb);
}

i32
sc_builder_should_grow(char* pSb, i64 appendLength)
{
    i64 cnt = sc_builder_count(pSb) + appendLength;
    i64 cap = sc_builder_capacity(pSb) - 1;
    if (cnt >= cap)
        return 1;
    return 0;
}

void
sc_builder_set_rest_to_zero(char* pSb)
{
    i64 cnt = sc_builder_count(pSb);
    i64 cap = sc_builder_capacity(pSb);
    memset(pSb + cnt, '\0', cap - cnt);
}

char*
sc_builder_append_char_ext(char* pSb, char c)
{
    if (!pSb)
        pSb = sc_builder_new();
    i32 shouldGrow = sc_builder_should_grow(pSb, 1);
    pSb = sc_list_add(pSb, c);
    if (shouldGrow)
        sc_builder_set_rest_to_zero(pSb);
    return pSb;
}

char*
sc_builder_append_string_ext(char* pSb, char* pString, i64 stringLength)
{
    if (!pSb)
        pSb = sc_builder_new();
    i32 shouldGrow = sc_builder_should_grow(pSb, stringLength);
    pSb = sc_list_add_multiple(pSb, pString, 1, stringLength);
    if (shouldGrow)
        sc_builder_set_rest_to_zero(pSb);
    return pSb;
}

char*
sc_builder_append_format_ext(char* pSb, char* pFormat, ...)
{
#define buf_size 1024
    char buf[buf_size] = {};

    va_list valist;
    va_start(valist, pFormat);
    ScFormatResult formatResult;

    do
    {
        formatResult = sc_format_ext(buf, buf_size, pFormat, valist);
        i32 shouldGrow = sc_builder_should_grow(pSb, formatResult.Size);
        sc_list_add_multiple(pSb, buf, 1, formatResult.Size);
        if (shouldGrow)
            sc_builder_set_rest_to_zero(pSb);
    }
    while (formatResult.IsFinished != 1);

#undef buf_size

    return pSb;
}

/*

  ###################################
  ###################################
  sc_file
  ###################################
  ###################################

*/

/*

  ###################################
  ###################################
  sc_file
  ###################################
  ###################################

*/

#if defined(SC_PLATFORM_LINUX)
#include <stdio.h>
#include <sys/stat.h>  // mkdir
#include <sys/types.h> // mkdir
#endif

ScResult
sc_file_delete_ext_r(const char* pPath)
{
#if defined(SC_PLATFORM_WINDOWS)
    if (!DeleteFile(pPath))
        return ScResult_Error;
#else  // defined(SC_PLATFORM_LINUX)
    if (remove(pPath) != 0)
        return ScResult_Error;
#endif // SC_PLATFORM_LINUX
    return ScResult_Success;
}

ScFileTime
sc_file_get_time_ext_r(const char* pPath)
{
#if defined(SC_PLATFORM_WINDOWS)
    HANDLE file = CreateFileA(pPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE)
    {
        sc_log_erro("Can't open file: %s\n", pPath);
        sc_assert_break();
    }
    FILETIME ct, at, wt;
    BOOL result = GetFileTime(file, &ct, &at, &wt);
    if (result == FALSE)
    {
        sc_log_erro("Can't get file time: %s\n", pPath);
        sc_assert_break();
    }

    SYSTEMTIME systemAccessTime;
    FileTimeToSystemTime(&at, &systemAccessTime);
    SYSTEMTIME systemCreationTime;
    FileTimeToSystemTime(&ct, &systemCreationTime);
    SYSTEMTIME systemWriteTime;
    FileTimeToSystemTime(&wt, &systemWriteTime);

    /* DOCS: Upstream bug: the handle was never closed, keeping the file
       locked (no FILE_SHARE_WRITE) for the lifetime of the process - a
       compiler could not rewrite its output object afterwards. */
    CloseHandle(file);

    /* DOCS: Upstream bug: only wSecond (0-59) was stored, so timestamps
       seconds apart compare equal and incremental rebuild checks misfire.
       Store the full FILETIME (100ns ticks since 1601) instead: comparable,
       monotonic and cheap. */
    ScFileTime scFileTime = {
        .LastAccessTime = systemAccessTime.wSecond,
        .LastCreateTime = systemCreationTime.wSecond,
        .LastModificationTime = (((u64)wt.dwHighDateTime) << 32) | wt.dwLowDateTime
    };

    return scFileTime;
#else // defined(SC_PLATFORM_LINUX)
    struct stat fileItemInfo;
    stat(pPath, &fileItemInfo);

    ScFileTime scFileTime = {
        .LastAccessTime = fileItemInfo.st_atime,
        .LastCreateTime = fileItemInfo.st_ctime,
        .LastModificationTime = fileItemInfo.st_mtime
    };

    return scFileTime;
#endif
}

u64
sc_file_get_size_ext_r(const char* pPath)
{
#if defined(SC_PLATFORM_WINDOWS)
    HANDLE fileHandle = CreateFileA(pPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (fileHandle == INVALID_HANDLE_VALUE)
        return 0;

    LARGE_INTEGER byteSize;
    BOOL isSucessed = GetFileSizeEx(fileHandle, &byteSize);
    if (!isSucessed)
    {
        CloseHandle(fileHandle);
        return 0;
    }

    // DOCS: Upstream bug: the handle was never closed (leaked the descriptor).
    CloseHandle(fileHandle);
    return byteSize.QuadPart;
#else  // defined(SC_PLATFORM_LINUX)
    FILE* file = fopen(pPath, "rb");
    if (file)
    {
        fseek(file, 0, SEEK_END);
        i32 fileLength = (i32)ftell(file);
        fclose(file);
        return fileLength;
    }

    return 0;
#endif // SC_PLATFORM_LINUX
}

char*
sc_file_read_ext_ext_r(const char* pFilePath, i64* pLength)
{
    FILE* pFile = fopen(pFilePath, "r");
    if (!pFile)
    {
        if (pLength)
            *pLength = 0;
        return ScNull;
    }

    fseek(pFile, 0, SEEK_END);
    i32 fileLength = ftell(pFile);
    fseek(pFile, 0, SEEK_SET);

    char* pResult = (char*)sc_memory_allocate(fileLength + 1);
    fread(pResult, sizeof(char), (fileLength), pFile);
    pResult[fileLength] = '\0';

    fclose(pFile);

    if (pLength)
        *pLength = fileLength;

    return ((char*)pResult);
}

char*
sc_file_read_ext_r(const char* pFilePath)
{
    return sc_file_read_ext_ext_r(pFilePath, NULL);
}

void
sc_file_write_ext_r(const char* pFilePath, void* pData, u64 dataLength)
{
    FILE* pFile = fopen(pFilePath, "w");
    sc_assert_not_null(pFile);
    if (!pFile)
        return;
    fwrite(pData, 1, dataLength, pFile);
    fclose(pFile);
}

void
sc_file_append_string_ext_r(const char* pFilePath, char* pData, u64 dataLength)
{
    FILE* pFile = fopen(pFilePath, "a+");
    fwrite(pData, 1, dataLength, pFile);
    fclose(pFile);
}

/*###################################
  ###################################
   debug extension pattern functions
  ###################################
  ###################################*/

ScResult
sc_file_delete_ext_d(const char* pPath, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pPath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_delete(%s <- pPath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return ScResult_Error;
    }
    return sc_file_delete_ext_r(pPath);
}

ScFileTime
sc_file_get_time_ext_d(const char* pPath, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pPath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_get_time(%s <- pPath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        ScFileTime zero = { 0 };
        return zero;
    }
    return sc_file_get_time_ext_r(pPath);
}

u64
sc_file_get_size_ext_d(const char* pPath, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pPath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_get_size(%s <- pPath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return 0;
    }
    return sc_file_get_size_ext_r(pPath);
}

char*
sc_file_read_ext_d(const char* pFilePath, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pFilePath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_read(%s <- pFilePath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return ScNull;
    }
    return sc_file_read_ext_r(pFilePath);
}

char*
sc_file_read_ext_ext_d(const char* pFilePath, i64* pLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pFilePath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_read_ext(%s <- pFilePath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        if (pLength)
            *pLength = 0;
        return ScNull;
    }
    return sc_file_read_ext_ext_r(pFilePath, pLength);
}

void
sc_file_write_ext_d(const char* pFilePath, void* pData, u64 dataLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pFilePath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_write(%s <- pFilePath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return;
    }
    if (!pData)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_write(%s <- pData is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return;
    }
    sc_file_write_ext_r(pFilePath, pData, dataLength);
}

void
sc_file_append_string_ext_d(const char* pFilePath, char* pData, u64 dataLength, const char* pExpression, const char* pFile, i32 line, const char* pFunction)
{
    if (!pFilePath)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_append_string(%s <- pFilePath is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return;
    }
    if (!pData)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_append_string(%s <- pData is null or undefined)\n",
            pFile,
            line,
            pFunction,
            pExpression);
        return;
    }
    sc_file_append_string_ext_r(pFilePath, pData, dataLength);
}

i32
sc_file_compare_ext_r(char* p0, char* p1)
{
    i32 result = 0;

    i64 len0 = 0;
    char* pFile0 = sc_file_read_ext_ext_r(p0, &len0);
    if (!pFile0)
        return 0;

    i64 len1 = 0;
    char* pFile1 = sc_file_read_ext_ext_r(p1, &len1);
    if (!pFile1)
    {
        sc_memory_free(pFile0);
        return 0;
    }

    if (len0 > 0 && len0 == len1)
    {
        for (i64 i = 0; i < len0; ++i)
        {
            char c0 = pFile0[i];
            char c1 = pFile1[i];
            if (c0 != c1)
            {
                break;
            }
        }

        result = 1;
    }

ScFileCompareExtREndLabel:
    sc_memory_free(pFile0);
    sc_memory_free(pFile1);

    return result;
}

i32
sc_file_compare_ext_d(char* p0, char* p1, const char* p0Expression, const char* p1Expression, const char* pFile, i32 line, const char* pFunction)
{
    if (!p0)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_compare(%s <- p0 is null or undefined)\n",
            pFile,
            line,
            pFunction,
            p0Expression);
        return 0;
    }
    if (!p1)
    {
        sc_log_warn("[%s:%d -> %s] sc_file_compare(%s <- p1 is null or undefined)\n",
            pFile,
            line,
            pFunction,
            p1Expression);
        return 0;
    }
    return sc_file_compare_ext_r(p0, p1);
}

/*

  ###################################
  ###################################
  sc_directory
  ###################################
  ###################################

*/

ScResult
sc_directory_create(const char* pPath)
{
#if defined(SC_PLATFORM_WINDOWS)
    if (!CreateDirectoryA(pPath, NULL))
        return ScResult_Error;
#else  // defined(SC_PLATFORM_LINUX)
    /*
          #define S_IRWXU 0000700    RWX mask for owner
          #define S_IRUSR 0000400    R for owner
          #define S_IWUSR 0000200    W for owner
          #define S_IXUSR 0000100    X for owner

          #define S_IRWXG 0000070    RWX mask for group
          #define S_IRGRP 0000040    R for group
          #define S_IWGRP 0000020    W for group
          #define S_IXGRP 0000010    X for group

          #define S_IRWXO 0000007    RWX mask for other
          #define S_IROTH 0000004    R for other
          #define S_IWOTH 0000002    W for other
          #define S_IXOTH 0000001    X for other

          #define S_ISUID 0004000    set user id on execution
          #define S_ISGID 0002000    set group id on execution
          #define S_ISVTX 0001000    save swapped text even after use
        */
    i32 result = mkdir(pPath, S_IRWXU);
    if (result != 0)
        return ScResult_Error;
#endif // SC_PLATFORM_LINUX

    return ScResult_Success;
}

ScResult
sc_directory_create_recursive(const char* pPath)
{
    char* sc_parent_dir = sc_path_get_directory((char*)pPath);
    // sc_log_info("Path=%s ParentDir=%s\n", pPath, sc_parent_dir);

    if (sc_parent_dir)
    {
        if (sc_path(sc_parent_dir) == ScPathItemType_Undefined)
        {
            ScResult root_dir_result = sc_directory_create_recursive(sc_parent_dir);
            if (root_dir_result != ScResult_Success)
            {
#if defined(SC_BUILD_DEBUG)
                sc_log_erro("Failed at parent dir creation!\n");
                sc_assert_break();
#endif // SC_BUILD_DEBUG

                sc_memory_free(sc_parent_dir);
                return ScResult_Error;
            }
        }
        sc_memory_free(sc_parent_dir);
    }

    // sc_log_info("Create dir %s\n", pPath);
    ScResult ok;
    if (sc_path(pPath) == ScPathItemType_Undefined)
        ok = sc_directory_create(pPath);
    else
        ok = ScResult_Success;

    return ok;
}

ScResult
sc_directory_set_current(const char* pPath)
{
    if (!pPath || pPath[0] == '\0')
        return ScResult_Error;

#if defined(SC_PLATFORM_WINDOWS)
    if (!SetCurrentDirectoryA(pPath))
        return ScResult_Error;
#else  // defined(SC_PLATFORM_LINUX)
    if (chdir(pPath) != 0)
        return ScResult_Error;
#endif // SC_PLATFORM_LINUX

    return ScResult_Success;
}

char*
sc_directory_get_current()
{
#if defined(SC_PLATFORM_WINDOWS)
    DWORD size = GetCurrentDirectoryA(0, NULL);
    if (size == 0)
        return NULL;

    char* pPath = sc_memory_allocate(size);
    if (!pPath)
        return NULL;

    DWORD written = GetCurrentDirectoryA(size, pPath);
    if (written == 0 || written >= size)
    {
        sc_memory_free(pPath);
        return NULL;
    }

    return pPath;
#else  // defined(SC_PLATFORM_LINUX)
    size_t size = 256;

    for (;;)
    {
        char* pPath = sc_memory_allocate(size);
        if (!pPath)
            return NULL;

        if (getcwd(pPath, size))
            return pPath;

        sc_memory_free(pPath);

        if (errno != ERANGE)
            return NULL;

        size *= 2;
    }
#endif // SC_PLATFORM_LINUX
}

ScResult
sc_directory_delete_recursive(const char* pPath)
{
    if (!pPath || pPath[0] == '\0')
        return ScResult_Error;

    ScPathItemType type = sc_path(pPath);

    if (type == ScPathItemType_Undefined)
        return ScResult_Error;

    if (type == ScPathItemType_File)
        return sc_file_delete(pPath);

    ScResult result = ScResult_Success;

#if defined(SC_PLATFORM_WINDOWS)
    char aPattern[MAX_PATH] = {};
    snprintf(aPattern, MAX_PATH, "%s\\*", pPath);

    WIN32_FIND_DATAA findData = {};
    HANDLE hFind = FindFirstFileA(aPattern, &findData);
    if (hFind == INVALID_HANDLE_VALUE)
        return ScResult_Error;

    do
    {
        if (sc_string_compare(findData.cFileName, ".") || sc_string_compare(findData.cFileName, ".."))
            continue;

        char aChild[MAX_PATH] = {};
        snprintf(aChild, MAX_PATH, "%s\\%s", pPath, findData.cFileName);

        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            if (sc_directory_delete_recursive(aChild) != ScResult_Success)
                result = ScResult_Error;
        }
        else if (sc_file_delete(aChild) != ScResult_Success)
        {
            result = ScResult_Error;
        }
    }
    while (FindNextFileA(hFind, &findData));

    FindClose(hFind);

    if (result == ScResult_Success && !RemoveDirectoryA(pPath))
        result = ScResult_Error;
#else  // defined(SC_PLATFORM_LINUX)
    ScDirectoryGetConfig cfg = {
        .IsAbsolutePath = 1,
        .Type = ScDirectoryItemType_None
    };
    ScDirectoryItem* aItems = sc_directory_get_items(pPath, cfg);

    for (i32 i = 0; i < sc_list_count(aItems); ++i)
    {
        ScDirectoryItem item = aItems[i];

        if (item.Type == ScDirectoryItemType_Directory)
        {
            if (sc_directory_delete_recursive(item.pPath) != ScResult_Success)
                result = ScResult_Error;
        }
        else if (sc_file_delete(item.pPath) != ScResult_Success)
        {
            result = ScResult_Error;
        }

        sc_memory_free(item.pPath);
    }

    sc_list_free(aItems);

    if (result == ScResult_Success && rmdir(pPath) != 0)
        result = ScResult_Error;
#endif // SC_PLATFORM_LINUX

    return result;
}

ScDirectoryItem*
sc_directory_get_items(const char* pPath, ScDirectoryGetConfig config)
{
#if defined(SC_PLATFORM_WINDOWS)
    // DOCS: FindFirstFileA mirrors the Linux readdir loop: the same item types,
    // DOCS: the same "IsAbsolutePath" semantics (relative items are file names only).
    // DOCS: Without this the Masuka workspace scan finds no *.masuka on Windows.
    ScDirectoryItem* aItems = NULL;

    char aPattern[MAX_PATH] = {};
    snprintf(aPattern, sizeof(aPattern), "%s\\*", pPath);

    WIN32_FIND_DATAA findData = {};
    HANDLE hFind = FindFirstFileA(aPattern, &findData);
    if (hFind == INVALID_HANDLE_VALUE)
        return NULL;

    do
    {
        if (sc_string_compare(findData.cFileName, ".") || sc_string_compare(findData.cFileName, ".."))
            continue;

        ScDirectoryItemType type = ScDirectoryItemType_None;

        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            type = ScDirectoryItemType_Directory;
        else
            type = ScDirectoryItemType_File;

        if (config.Type != ScDirectoryItemType_None && config.Type != type)
            continue;

        char* pItemPath;
        if (config.IsAbsolutePath)
            pItemPath = sc_path_combine((char*)pPath, findData.cFileName);
        else
            pItemPath = sc_string_copy(findData.cFileName, sc_string_get_length(findData.cFileName));

        ScDirectoryItem item = {
            .Type = type,
            .pPath = pItemPath
        };
        sc_list_add(aItems, item);
    }
    while (FindNextFileA(hFind, &findData));

    FindClose(hFind);

    return aItems;
#elif defined(SC_PLATFORM_LINUX)
    ScDirectoryItem* aItems = NULL;

    DIR* pDir = opendir(pPath);

    if (!pDir)
    {
        printf("Error opening '%s'\n", pPath);
        return NULL;
    }

    i8 isEnabled[DT_WHT] = {
        [DT_DIR] = config.Type == ScDirectoryItemType_Directory || config.Type == ScDirectoryItemType_None,
        [DT_REG] = config.Type == ScDirectoryItemType_File || config.Type == ScDirectoryItemType_None,
        [DT_LNK] = config.Type == ScDirectoryItemType_Symlink || config.Type == ScDirectoryItemType_None
    };

    struct dirent* pEntry;

    while ((pEntry = readdir(pDir)))
    {
        i8 shouldProcess = isEnabled[pEntry->d_type];
        if (!shouldProcess)
            continue;

        if (sc_string_compare(pEntry->d_name, ".") || sc_string_compare(pEntry->d_name, ".."))
        {
            continue;
        }

        char* pItemPath;
        if (config.IsAbsolutePath)
            pItemPath = sc_path_combine((char*)pPath, pEntry->d_name);
        else
            pItemPath = (char*)pEntry->d_name;

        switch (pEntry->d_type)
        {
        case DT_DIR:
        {
            ScDirectoryItem item = {
                .Type = ScDirectoryItemType_Directory,
                .pPath = pItemPath
            };
            sc_list_add(aItems, item);
            break;
        }

        case DT_REG:
        {
            ScDirectoryItem item = {
                .Type = ScDirectoryItemType_File,
                .pPath = pItemPath
            };
            sc_list_add(aItems, item);
            break;
        }

        case DT_LNK:
        {
            ScDirectoryItem item = {
                .Type = ScDirectoryItemType_Symlink,
                .pPath = pItemPath
            };
            sc_list_add(aItems, item);
            break;
        }
        }
    }

    return aItems;
#endif
}

char**
sc_directory_get_directories(const char* pPath, i32 isAbsolute)
{
    ScDirectoryGetConfig cfg = (ScDirectoryGetConfig) {
        .IsAbsolutePath = isAbsolute,
        .Type = ScDirectoryItemType_Directory
    };
    ScDirectoryItem* aItems = sc_directory_get_items(pPath, cfg);
    char** aDirectories = sc_list_select(aItems, pPath);
    sc_list_free(aItems);
    return aDirectories;
}

char**
sc_directory_get_files(const char* pPath, i32 isAbsolute)
{
    ScDirectoryGetConfig cfg = (ScDirectoryGetConfig) {
        .IsAbsolutePath = isAbsolute,
        .Type = ScDirectoryItemType_File
    };
    ScDirectoryItem* aItems = sc_directory_get_items(pPath, cfg);
    char** aFile = sc_list_select(aItems, pPath);
    sc_list_free(aItems);
    return aFile;
}

/*

  ###################################
  ###################################
  sc_path
  ###################################
  ###################################

*/

ScPathItemType
sc_path(const char* pPath)
{
#if defined(SC_PLATFORM_WINDOWS)

    DWORD fileAttribute = GetFileAttributes(pPath);
    if (fileAttribute == INVALID_FILE_ATTRIBUTES)
        return ScPathItemType_Undefined;

    if (fileAttribute == FILE_ATTRIBUTE_DIRECTORY)
        return ScPathItemType_Directory;
    return ScPathItemType_File;

#else  // defined(SC_PLATFORM_LINUX)
    struct stat fileInfo;

    if (stat(pPath, &fileInfo) != 0)
        return ScPathItemType_Undefined;

    if (S_ISDIR(fileInfo.st_mode))
        return ScPathItemType_Directory;
    else if (S_ISREG(fileInfo.st_mode))
        return ScPathItemType_File;
    return ScPathItemType_Undefined;
#endif // defined(SC_PLATFORM_LINUX)
}

char*
sc_path_get_home_directory_wo_alloc()
{
#if defined(SC_PLATFORM_WINDOWS)
    static char pPath[MAX_PATH] = {};

    if (pPath[0] != 0)
        return (char*)pPath;

    if (!SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_PROFILE, NULL, 0, pPath)))
    {
        sc_char_array_set(pPath, "C:/Users");
    }
    return pPath;
#else  // defined(SC_PLATFORM_LINUX)
    static char* pHomeDir = NULL;
    if (pHomeDir)
        goto GetHomeDirReturnLabel;

    if (!pHomeDir)
    {
        pHomeDir = getenv("HOME");
        if (pHomeDir)
            goto GetHomeDirReturnLabel;
    }

    struct passwd* pw = getpwuid(getuid());
    if (pw && pw->pw_dir)
    {
        pHomeDir = (char*)pw->pw_dir;
        if (pHomeDir)
            goto GetHomeDirReturnLabel;
    }

    pw = getpwnam("root");
    if (pw && pw->pw_dir)
    {
        pHomeDir = pw->pw_dir;
    }

GetHomeDirReturnLabel:
    return pHomeDir;
#endif // defined(SC_PLATFORM_LINUX)
}

// DOCS(typedef): this("path/to/file.txt") -> ".txt"
char*
sc_path_get_extension_wo_alloc(char* pPath)
{
    i64 extensionIndex = sc_string_last_index_of(pPath, '.');
    return (char*)(pPath + extensionIndex);
}

// DOCS(typedef): this("path/to/file.txt") -> "file.txt"
char*
sc_path_get_name_wo_alloc(char* pPath)
{
    i64 extensionIndex = sc_string_last_index_of(pPath, '/');
    return (char*)(pPath + extensionIndex + 1);
}

char*
sc_path_get_name_wo_extension(char* path)
{
    char* nameWithExt = sc_path_get_name_wo_alloc(path);
    i64 nameWithExtLen = sc_string_get_length(nameWithExt);
    i32 ind = sc_string_last_index_of(nameWithExt, '.');
    char* nameWoExt = sc_string_substring_length(
        nameWithExt,
        nameWithExtLen,
        ind);
    return nameWoExt;
}

ScStringView
sc_path_get_name_view_wo_extension(char* path)
{
    char* nameWithExt = sc_path_get_name_wo_alloc(path);
    i32 ind = sc_string_last_index_of(nameWithExt, '.');
    ScStringView view = sc_string_view_new(nameWithExt, ind);
    return view;
}

char*
sc_path_get_directory(char* pPath)
{
    //;"path/one/t"; -> "path/one"
    //;;0123456789;;
    i32 extensionIndex = sc_string_last_index_of(pPath, '/');
    i32 backslashIndex = sc_string_last_index_of(pPath, '\\');

    // DOCS: Windows paths come with '\' separators (sc_path_combine -> PathCchCombineEx):
    // DOCS: the directory is cut at the last separator of any kind.
    if (backslashIndex > extensionIndex)
        extensionIndex = backslashIndex;

    if (extensionIndex == -1)
        return NULL;

    char* pNewPath = (char*)sc_memory_allocate(extensionIndex + 1);
    pNewPath[extensionIndex] = '\0';
    memcpy(pNewPath, pPath, extensionIndex);

    return pNewPath;
}

#if defined(SC_PLATFORM_WINDOWS)

char*
sc_path_combine(char* left, char* right)
{
    sc_assert_not_null(left);
    sc_assert_not_null(right);

    wchar_t wleft[MAX_PATH], wright[MAX_PATH], woutPath[MAX_PATH];

    // Конвертация
    MultiByteToWideChar(CP_UTF8, 0, left, -1, wleft, MAX_PATH);
    MultiByteToWideChar(CP_UTF8, 0, right, -1, wright, MAX_PATH);

    // Windows API
    PathCchCombineEx(woutPath, MAX_PATH, wleft, wright, 0);

    // Обратная конвертация
    char outPath[MAX_PATH * 4];
    WideCharToMultiByte(CP_UTF8, 0, woutPath, -1, outPath, sizeof(outPath), NULL, NULL);

    i64 len = sc_string_get_length(outPath);
    char* result = sc_memory_allocate(len + 1);
    memcpy(result, outPath, len + 1);
    return result;
}

#else // defined(SC_PLATFORM_LINUX)

char*
sc_path_combine(char* pLeft, char* pRight)
{
    sc_assert_not_null(pLeft);
    sc_assert_not_null(pRight);

    i64 leftLength = sc_string_get_length(pLeft);
    i64 rightLength = sc_string_get_length(pRight);

    i32 isRightBegSlash = pRight[0] == '/';
    i32 isLeftEndSlash = pLeft[leftLength - 1] == '/';
    i32 isRightEndSlash = pRight[rightLength - 1] == '/';

    i64 leftStartInd = 0;
    i64 rightStartInd = 0;
    i64 leftToCopyCount = leftLength;
    i64 rightToCopyCount = rightLength;

    if (isRightBegSlash)
    {
        char* ptr;
        for (ptr = pRight; *ptr != '/'; ++ptr)
        {
        }
        rightStartInd += to_u64(ptr - pRight);
        rightToCopyCount -= rightStartInd;
    }

    i32 isSeparatorNeeded = !isLeftEndSlash && !isRightBegSlash;
    i64 totalSize = leftToCopyCount + rightToCopyCount + isSeparatorNeeded + 1;

    char* pCombined = sc_memory_allocate(totalSize);
    char* pWrite = pCombined;

    // left part
    memcpy(pWrite, pLeft + leftStartInd, leftToCopyCount);
    pWrite += leftToCopyCount + leftStartInd;

    // separator part
    if (!isLeftEndSlash && !isRightBegSlash)
    {
        memcpy(pWrite, "/", 1);
        ++pWrite;
    }

    // right part
    memcpy(pWrite, pRight + rightStartInd, rightToCopyCount);

    // zero part
    pWrite += rightToCopyCount;
    *pWrite = '\0';

    return pCombined;
}

char*
sc_path_get_random(char* pBuf, u64 bufSize, i32 minLen, i32 maxLen)
{
    i32 size = maxLen - minLen;
    i32 len = sc_random() % size + minLen;
    len = ScMinMax(len, 1, bufSize - 1);

    i32 charMin0 = 'A';
    i32 charMax0 = 'Z' - charMin0 + 1;
    i32 charMin1 = 'a';
    i32 charMax1 = 'z' - charMin1 + 1;

    for (i32 i = 0; i < len; ++i)
    {
        i32 rv = sc_random() % 100;
        char c;
        if (rv > 50)
            c = sc_random() % charMax0 + charMin0;
        else
            c = sc_random() % charMax1 + charMin1;
        pBuf[i] = c;
    }

    pBuf[len] = '\0';

    return (char*)pBuf;
#undef buf_size
}

char*
sc_path_get_random_temp()
{
    return sc_path_get_random_temp_ext(3, 11);
}

char*
sc_path_get_random_temp_ext(i64 min, i64 max)
{
    const char* pTempDir = "/tmp";
    char buf[256] = {};
    char* pRand = sc_path_get_random(buf, 256, min, max);
    char* pTempRand = sc_path_combine((char*)pTempDir, pRand);
    return pTempRand;
}

#endif

/*

  ###################################
  ###################################
  sc_memory
  ###################################
  ###################################

*/

typedef struct
{
    i64 Count;
    i64 Capacity;
    void* pData;
} EarrHeader;

force_inline EarrHeader*
earr_header(void* pList)
{
    EarrHeader* pHdr = (EarrHeader*)(((char*)pList) - sizeof(EarrHeader));
    return pHdr;
}

force_inline i64
earr_count(void* pList)
{
    if (pList == NULL)
        return 0;
    return earr_header(pList)->Count;
}

void* earr_add_ext(void* pData, void* pItem, u64 size);
#define earr_add(pList, item) pList = earr_add_ext(pList, &item, sizeof(item));

typedef struct
{
    void* pBuffer;
    u64 Size;
    const char* pFile;
    const char* pFunction;
    i32 Line;
} ScMemoryItem;

typedef struct
{
    const char* pFile;
    const char* pFunction;
    i32 Line;
} ScMemoryFreeRecord;

typedef struct
{
    ScMemoryItem Info;
    i32 FreeCount;
    ScMemoryFreeRecord* aRecs;
} ScFreeMemoryItem;

typedef enum
{
    SmMemoryDebugDefaults_DefaultValue = 0xCD,
    SmMemoryDebugDefaults_MemoryOffset = ScKb(1),
    SmMemoryDebugDefaults_MemoryOverwriteSize = 2 * SmMemoryDebugDefaults_MemoryOffset,
} SmMemoryDebugDefaults;

#define SmArenasStackSize 32
// note:  make it bigger if SmArenasStackSize > 127
typedef i8 ait;

typedef struct
{
    ScArena* aArenas[SmArenasStackSize];
    i64 Magic;
    ait Current;
    ScMutex Mutex;
} ScArenaStack;

// Make it variable that setup in user-space
struct SmGlobal
{
    // RecordHeader* pArray;
    ScArenaStack ArenaStack;
    i64 ArenaNextId;
    i32 IsMemoryDebug;

    ScMemoryItem* aItems;
    ScFreeMemoryItem* aFreedItems;

    ScMutex DebugMutex;
} gSm = {};

void*
sc_memory_allocate_ext(u64 size, i32 line, const char* pFile)
{
#if 0
    ScArena* pArena = sc_arena_get();
    if (pArena == NULL)
    {
        SmRecord* pRecord = (SmRecord*)malloc(sizeof(SmRecord) + size);
        pRecord->Line = line;
        pRecord->Size = size;
        pRecord->pFile = pFile;
        pRecord->pData = (void*)(((char*)pRecord) + sizeof(SmRecord));

        if (gSm.IsMemoryDebug)
            sm_records_add(pRecord);

        return pRecord->pData;
    }

    void* pAllocatedMemory = sm_arena_allocate(pArena, size);
    return pAllocatedMemory;
#else
    ScArena* pArena = sc_arena_get();
    if (pArena == NULL)
    {
        return malloc(size);
    }

    void* pAllocatedMemory = sc_arena_allocate(pArena, size);
    return pAllocatedMemory;
#endif
}

void
sc_memory_free_ext(void* pMemory, i32 line, const char* pFile)
{
    if (!pMemory)
        return;

    if (sc_arena_get() != NULL)
        return;

#if 0
    SmRecord* pRecord = (SmRecord*)(((char*)pMemory) - sizeof(SmRecord));

    if (gSm.IsMemoryDebug)
        sm_record_remove(pRecord);
    free(pRecord);
#else
    free(pMemory);
#endif
}

/*

  ###################################
  ###################################
  sc_arena
  ###################################
  ###################################

*/

ScArena*
sc_arena_get()
{
    if (gSm.ArenaStack.Current > 0)
        return gSm.ArenaStack.aArenas[gSm.ArenaStack.Current - 1];
    return NULL;
}

ScArena*
sc_arena_new_ext(ScArenaConfig config)
{
    ScArena* pArena = (ScArena*)malloc(config.Size + sizeof(ScArena));
    pArena->Id = gSm.ArenaNextId;
    pArena->Offset = 0;
    pArena->Size = config.Size;
    pArena->Line = config.Line;
    pArena->pFile = config.pFile;
    pArena->pData = ((void*)pArena) + sizeof(ScArena);

    ++gSm.ArenaNextId;

    return pArena;
}

void
sc_arena_destroy(ScArena* pArena)
{
    sc_arena_clear(pArena);
    free(pArena);
}

void
sc_arena_clear(ScArena* pArena)
{
    pArena->Offset = 0;
    if (pArena->Flag == ScArenaFlag_DeepClean)
        memset(pArena->pData, 0, pArena->Size);
}

void*
sc_arena_allocate(ScArena* pArena, u64 size)
{
    if ((pArena->Offset + size) > pArena->Size)
    {
        sc_guard(0 && "Run out of memory in arena, make arena bigger!");
        return NULL;
    }

    void* pAllocateMemory = pArena->pData + pArena->Offset;
    pArena->Offset += size;
    return pAllocateMemory;
}

void
sc_arena_bind(ScArena* pArena)
{
    if (gSm.ArenaStack.Current >= SmArenasStackSize)
    {
        sc_guard(0 && "Out of arenas, make SmArenasStackSize bigger");
        return;
    }

    if (gSm.ArenaStack.Magic != 1337)
    {
        gSm.ArenaStack.Magic = 1337;
        gSm.ArenaStack.Mutex = sc_mutex_create();
    }

    sc_mutex_lock(gSm.ArenaStack.Mutex);
    gSm.ArenaStack.aArenas[gSm.ArenaStack.Current] = pArena;
    gSm.ArenaStack.Current += 1;
    sc_mutex_unlock(gSm.ArenaStack.Mutex);
}

void
sc_arena_unbind()
{
    if (gSm.ArenaStack.Current <= 0)
        return;

    sc_mutex_lock(gSm.ArenaStack.Mutex);
    gSm.ArenaStack.Current -= 1;
    gSm.ArenaStack.aArenas[gSm.ArenaStack.Current] = NULL;
    sc_mutex_unlock(gSm.ArenaStack.Mutex);
}

ScMemoryItem*
_sc_memory_item_get(void* pBuffer)
{
    i64 cnt = earr_count(gSm.aItems);
    for (i64 i = 0; i < cnt; ++i)
    {
        ScMemoryItem item = gSm.aItems[i];
        if (item.pBuffer == pBuffer)
            return &gSm.aItems[i];
    }
    return NULL;
}

ScFreeMemoryItem*
_sc_free_memory_item_get(void* pBuffer)
{
    i64 cnt = earr_count(gSm.aFreedItems);
    for (i64 i = 0; i < cnt; ++i)
    {
        ScFreeMemoryItem freeItem = gSm.aFreedItems[i];
        if (freeItem.Info.pBuffer == pBuffer)
            return &gSm.aFreedItems[i];
    }
    return NULL;
}

void
sc_memory_debug_lock()
{
    if (!gSm.DebugMutex)
        gSm.DebugMutex = sc_mutex_create();
    sc_mutex_lock(gSm.DebugMutex);
}

void
sc_memory_debug_unlock()
{
    sc_mutex_unlock(gSm.DebugMutex);
}

void*
sc_memory_debug_allocate(u64 size, const char* pFile, const char* pFunction, i32 line)
{
    u64 totalSize = size + SmMemoryDebugDefaults_MemoryOverwriteSize;
    void* pBuffer = malloc(totalSize);
    memset(pBuffer, SmMemoryDebugDefaults_DefaultValue, totalSize);

    sc_memory_debug_lock();
    ScMemoryItem item = {
        .pBuffer = pBuffer,
        .Size = size,
        .pFile = pFile,
        .pFunction = pFunction,
        .Line = line
    };
    earr_add(gSm.aItems, item);
    sc_memory_debug_unlock();

    void* pData = pBuffer + SmMemoryDebugDefaults_MemoryOffset;
    return pData;
}

void
sc_memory_debug_free(void* pData, const char* pFile, const char* pFunction, i32 line)
{
    void* pBuffer = pData - SmMemoryDebugDefaults_MemoryOffset;
    ScMemoryFreeRecord rec = {
        .pFile = pFile,
        .pFunction = pFunction,
        .Line = line
    };

    sc_memory_debug_lock();

    ScFreeMemoryItem* pFreeItem = _sc_free_memory_item_get(pBuffer);
    if (pFreeItem == NULL)
    {
        // CREATE
        ScMemoryItem item = *_sc_memory_item_get(pBuffer);
        ScFreeMemoryItem memItem = {
            .FreeCount = 1,
            .Info = item,
        };
        earr_add(memItem.aRecs, rec);
        earr_add(gSm.aFreedItems, memItem);
        memset(pData, SmMemoryDebugDefaults_DefaultValue, item.Size);
    }
    else
    {
        // MODIFY
        earr_add(pFreeItem->aRecs, rec);
        ++pFreeItem->FreeCount;
    }

    sc_memory_debug_unlock();
}

i64
_is_buffer_override(ScMemoryItem item)
{
    u8* pData = (u8*)item.pBuffer + SmMemoryDebugDefaults_MemoryOffset;
    u8* pEnd = pData + item.Size;

    i64 isOverride = 0;
    for (i64 k = 0; k < SmMemoryDebugDefaults_MemoryOffset; ++k)
    {
        u8 byte = *pEnd;
        if (byte != SmMemoryDebugDefaults_DefaultValue)
            ++isOverride;
        ++pEnd;
    }

    return isOverride;
}

i64
_is_buffer_underride(ScMemoryItem item)
{
    u8* pData = (u8*)item.pBuffer;

    i64 isUnderride = 0;
    for (i64 k = 0; k < SmMemoryDebugDefaults_MemoryOffset; ++k)
    {
        u8 byte = *pData;
        if (byte != SmMemoryDebugDefaults_DefaultValue)
            ++isUnderride;
        ++pData;
    }

    return isUnderride;
}

void
sc_memory_debug_validate_buffer_overflow()
{
    i64 cnt = earr_count(gSm.aItems);
    for (i64 i = 0; i < cnt; ++i)
    {
        ScMemoryItem item = gSm.aItems[i];
        i64 isBufferOverride = _is_buffer_override(item);
        if (isBufferOverride)
        {
            printf("\x1B[93m[ WARN ]\033[0m Buffer override  on +%lld/%lld bytes %s:%s:%d\n", isBufferOverride, item.Size, item.pFile, item.pFunction, item.Line);
        }
    }
}

void
sc_memory_debug_validate_buffer_underflow()
{
    i64 cnt = earr_count(gSm.aItems);
    for (i64 i = 0; i < cnt; ++i)
    {
        ScMemoryItem item = gSm.aItems[i];
        i64 isBufferUnderride = _is_buffer_underride(item);
        if (isBufferUnderride)
        {
            printf("\x1B[93m[ WARN ]\033[0m Buffer underride on -%lld/%lld bytes %s:%s:%d\n", isBufferUnderride, item.Size, item.pFile, item.pFunction, item.Line);
        }
    }
}

void
sc_memory_debug_validate_double_free()
{
    i64 cnt = earr_count(gSm.aFreedItems);
    for (i64 i = 0; i < cnt; ++i)
    {
        ScFreeMemoryItem memItem = gSm.aFreedItems[i];
        if (memItem.FreeCount > 1)
        {
            ScMemoryItem item = memItem.Info;
            printf("\x1B[93m[ WARN ]\033[0m Free %d times for address %p allocated there %s:%s:%d\n", memItem.FreeCount, item.pBuffer, item.pFile, item.pFunction, item.Line);

            i32 recCount = earr_count(memItem.aRecs);
            for (i32 m = 0; m < recCount; ++m)
            {
                ScMemoryFreeRecord rec = memItem.aRecs[m];
                printf("   \x1B[93m[ * ]\033[0m freed here %s:%s:%d\n", rec.pFile, rec.pFunction, rec.Line);
            }
        }
    }
}

void
sc_memory_debug_validate_writing_to_free()
{
    i64 cnt = earr_count(gSm.aFreedItems);
    for (i64 i = 0; i < cnt; ++i)
    {
        ScFreeMemoryItem memItem = gSm.aFreedItems[i];
        ScMemoryItem item = memItem.Info;

        char* pData = (char*)item.pBuffer + SmMemoryDebugDefaults_MemoryOffset;
        u8* pEnd = (u8*)(pData + item.Size);

        for (u8* pRead = (u8*)pData; pRead != pEnd; ++pRead)
        {
            u8 b = *pRead;
            if (b != SmMemoryDebugDefaults_DefaultValue)
            {
                printf("\x1B[93m[ WARN ]\033[0m Write into freed memory for address %p allocated there %s:%s:%d\n", item.pBuffer, item.pFile, item.pFunction, item.Line);
                break;
            }
        }
    }
}

void
sc_memory_debug_validate()
{
    sc_memory_debug_lock();
    sc_memory_debug_validate_buffer_overflow();
    sc_memory_debug_validate_buffer_underflow();
    sc_memory_debug_validate_double_free();
    sc_memory_debug_validate_writing_to_free();
    sc_memory_debug_unlock();
}

void*
earr_add_ext(void* pList, void* pData, u64 stride)
{
    if (pList == NULL)
    {
        EarrHeader* pHdr = (EarrHeader*)malloc(sizeof(EarrHeader) + stride);
        pHdr->Count = 1;
        pHdr->Capacity = 1;
        pHdr->pData = ((void*)pHdr) + sizeof(EarrHeader);
        memcpy(pHdr->pData, pData, stride);
        return pHdr->pData;
    }

    // DOCS: Realloc
    EarrHeader* pHdr = earr_header(pList);
    if (pHdr->Count >= pHdr->Capacity)
    {
        i64 newCapacity = 2 * pHdr->Capacity + 1;
        EarrHeader* pNewHdr = (EarrHeader*)malloc(sizeof(EarrHeader) + newCapacity * stride);
        pNewHdr->Count = pHdr->Count + 1;
        pNewHdr->Capacity = newCapacity;
        pNewHdr->pData = ((void*)pNewHdr) + sizeof(EarrHeader);
        memcpy(pNewHdr->pData, pHdr->pData, pHdr->Count * stride);
        memcpy(pNewHdr->pData + pHdr->Count * stride, pData, stride);
        free(pHdr);
        return pNewHdr->pData;
    }

    // DOCS: Just add new data
    memcpy(pHdr->pData + pHdr->Count * stride, pData, stride);
    ++pHdr->Count;

    return pHdr->pData;
}

/*

  ###################################
  ###################################
  sc_thread
  ###################################
  ###################################

*/

ScThread
sc_thread_create(ScThreadDelegate threadFunction, u64 stackSize, void* pData)
{
#if defined(SC_PLATFORM_WINDOWS)

    ScThread thread;
    typedef unsigned long (*WinCallback)(void*);
    HANDLE id = CreateThread(NULL, stackSize, (WinCallback)threadFunction, pData, 0, NULL);
    ScThread scThread = (ScThread)id;
    return scThread;

#else // if defined(SC_PLATFORM_LINUX)

    pthread_t id;
    pthread_attr_t threadAttributes;
    pthread_attr_init(&threadAttributes);
    i32 result = pthread_attr_setguardsize(&threadAttributes, stackSize);
    i32 status = pthread_create(&id, &threadAttributes, threadFunction, pData);
    if (status == -1)
    {
        // perror("Mutex error: ");
        sc_assert(0 && "Thread creation error!");
    }
    pthread_attr_destroy(&threadAttributes);
    ScThread scThread = (ScThread)id;
    return scThread;

#endif
}

void
sc_thread_attach(ScThread thread)
{
#if defined(SC_PLATFORM_WINDOWS)
    // NOTE(typedef): INFINITE -> no time interval
    DWORD result = WaitForSingleObject((HANDLE)thread, INFINITE);
    if (result == WAIT_FAILED)
    {
        sc_assert(0 && "Thread can't join!");
    }
#else // defined(SC_PLATFORM_LINUX)
    i32 status = pthread_join((pthread_t)thread, NULL);
    if (status != 0)
    {
        sc_assert(0 && "Thread can't join!");
    }
#endif
}

ScResult
sc_thread_cancel(ScThread thread)
{
#if defined(SC_PLATFORM_WINDOWS)
    BOOL result = TerminateThread((HANDLE)thread, 0);
    if (result)
    {
        return ScResult_Success;
    }
    return ScResult_Error;
#else // if defined(PLATFORM_LINUX)
    i32 result = pthread_cancel((pthread_t)thread);
    if (result == 0)
    {
        return ScResult_Success;
    }
    return ScResult_Error;
#endif
}

/*

  ###################################
  ###################################
  sc_mutex
  ###################################
  ###################################

*/

typedef struct
{
    i8 IsLocked;
#if defined(SC_PLATFORM_WINDOWS)
    CRITICAL_SECTION CriticalSection;
#elif defined(SC_PLATFORM_LINUX)
    pthread_mutex_t Mutex;
#endif // SC_PLATFORM_WINDOWS
} ScMutexInternal;

ScMutex
sc_mutex_create()
{
    ScMutexInternal* pMutexInternal = sc_memory_allocate(sizeof(ScMutexInternal));

#if defined(SC_PLATFORM_WINDOWS)

    InitializeCriticalSection(&pMutexInternal->CriticalSection);

#else // if defined(SC_PLATFORM_LINUX)

    i32 result = pthread_mutex_init(&pMutexInternal->Mutex, NULL);
    if (result != 0)
    {
        sc_log_warn("Can't create mutex!\n");
        sc_assert_break();
    }

#endif

    return pMutexInternal;
}

ScResult
sc_mutex_destroy(ScMutex scMutex)
{
    ScMutexInternal* pMutexInternal = (ScMutexInternal*)scMutex;

#if defined(SC_PLATFORM_WINDOWS)

    DeleteCriticalSection(&pMutexInternal->CriticalSection);

#else // defined(SC_PLATFORM_LINUX)

    if (pthread_mutex_destroy(&pMutexInternal->Mutex) != 0)
    {
        sc_assert("Can't destroy mutex!");
        sc_memory_free(pMutexInternal);
        return ScResult_Error;
    }

#endif

    sc_memory_free(pMutexInternal);
    return ScResult_Success;
}

ScResult
sc_mutex_lock(ScMutex scMutex)
{
    ScMutexInternal* pMutexInternal = (ScMutexInternal*)scMutex;
    pMutexInternal->IsLocked = 1;

#if defined(SC_PLATFORM_WINDOWS)

    EnterCriticalSection(&pMutexInternal->CriticalSection);

#else // if defined(SC_PLATFORM_LINUX)

    if (pthread_mutex_lock(&pMutexInternal->Mutex) != 0)
    {
        sc_assert(0 && "Thread can't lock!");
        pMutexInternal->IsLocked = 0;
        return ScResult_Error;
    }

#endif

    return ScResult_Success;
}

ScResult
sc_mutex_unlock(ScMutex scMutex)
{
    ScMutexInternal* pMutexInternal = (ScMutexInternal*)scMutex;
    pMutexInternal->IsLocked = 0;

#if defined(SC_PLATFORM_WINDOWS)

    LeaveCriticalSection(&pMutexInternal->CriticalSection);

#else // if defined(SC_PLATFORM_LINUX)

    if (pthread_mutex_unlock(&pMutexInternal->Mutex) != 0)
    {
        sc_assert(0 && "Thread can't unlock!");
        pMutexInternal->IsLocked = 1;
        return ScResult_Error;
    }

#endif

    return ScResult_Success;
}

i32
sc_mutex_is_locked(ScMutex scMutex)
{
    ScMutexInternal* pMutexInternal = (ScMutexInternal*)scMutex;
    return pMutexInternal->IsLocked;
}

/*

  ###################################
  ###################################
  sc_condition
  ###################################
  ###################################

*/

ScCondition
sc_condition_create(void)
{
#if defined(SC_PLATFORM_WINDOWS)

    CONDITION_VARIABLE* pCond = (CONDITION_VARIABLE*)sc_memory_allocate(sizeof(CONDITION_VARIABLE));
    InitializeConditionVariable(pCond);

    ScCondition scCon = {
        .pHandle = pCond
    };

    return scCon;

#elif defined(SC_PLATFORM_LINUX)

    pthread_cond_t* pCondition = (pthread_cond_t*)sc_memory_allocate(sizeof(pthread_cond_t));
    if (pthread_cond_init(pCondition, NULL) != 0)
    {
        sc_log_erro("Can't create condition variable!\n");
        sc_memory_free(pCondition);
        sc_assert_break();
        return (ScCondition) {};
    }

    ScCondition scCon = {
        .pHandle = pCondition,
    };

    return scCon;

#endif
}

void
sc_condition_destroy(ScCondition condition)
{
    if (!condition.pHandle)
        return;

#if defined(SC_PLATFORM_WINDOWS)

    // DOCS: CONDITION_VARIABLE не требует деинициализации в Windows. Просто освобождаем память.

#elif defined(SC_PLATFORM_LINUX)

    if (pthread_cond_destroy((pthread_cond_t*)condition.pHandle) != 0)
    {
        sc_log_erro("Can't create condition variable!\n");
        sc_assert_break();
    }

#endif

    sc_memory_free(condition.pHandle);
}

void
sc_condition_wait(ScCondition* pCondition, ScMutex scMutex)
{
    if (!sc_mutex_is_locked(scMutex))
    {
        sc_log_warn("Mutex is not locked!\n");
        sc_assert_break();
        return;
    }

    ScMutexInternal* pMutexInternal = (ScMutexInternal*)scMutex;

#if defined(SC_PLATFORM_WINDOWS)

    /*  DOCS: SleepConditionVariableCS:
        1. Разблокирует CriticalSection
        2. Ждет сигнал на Cond
        3. При пробуждении ЗАНОВО захватывает CriticalSection */
    BOOL result = SleepConditionVariableCS(
        (CONDITION_VARIABLE*)pCondition->pHandle,
        &pMutexInternal->CriticalSection,
        INFINITE);

    if (!result)
    {
        // TODO: GetLastError() - покажет|(может показать) причину оишбки
        sc_assert(0 && "sc_condition_wait: SleepConditionVariableCS failed!");
    }

#elif defined(SC_PLATFORM_LINUX)

    if (pthread_cond_wait((pthread_cond_t*)pCondition->pHandle, (pthread_mutex_t*)&pMutexInternal->Mutex) != 0)
    {
        sc_assert(0 && "sc_condition_wait: SleepConditionVariableCS failed!");
    }

#endif
}

void
sc_condition_signal(ScCondition* pCondition)
{
#if defined(SC_PLATFORM_WINDOWS)

    WakeConditionVariable((CONDITION_VARIABLE*)pCondition->pHandle);

#elif defined(SC_PLATFORM_LINUX)

    pthread_cond_signal((pthread_cond_t*)pCondition->pHandle);

#endif
}

void
sc_condition_broadcast(ScCondition* pCondition)
{
#if defined(SC_PLATFORM_WINDOWS)

    WakeAllConditionVariable((CONDITION_VARIABLE*)pCondition->pHandle);

#elif defined(SC_PLATFORM_LINUX)

    pthread_cond_broadcast((pthread_cond_t*)pCondition->pHandle);

#endif
}

/*

  ###################################
  ###################################
  sc_rwlock
  ###################################
  ###################################

*/

#if defined(SC_PLATFORM_WINDOWS)
typedef struct
{
    SRWLOCK SrwLock;
} ScRWLockInternal;
#elif defined(SC_PLATFORM_LINUX)
typedef struct
{
    pthread_rwlock_t RwLock;
} ScRWLockInternal;
#endif

ScRwLock
sc_rwlock_create(void)
{
    ScRWLockInternal* pLock = sc_memory_allocate(sizeof(ScRWLockInternal));

#if defined(SC_PLATFORM_WINDOWS)
    InitializeSRWLock(&pLock->SrwLock);
#elif defined(SC_PLATFORM_LINUX)
    i32 result = pthread_rwlock_init(&pLock->RwLock, NULL);
    if (result != 0)
    {
        sc_log_warn("Can't create rwlock!\n");
        sc_assert_break();
        sc_memory_free(pLock);
        return NULL;
    }
#endif

    return (ScRwLock)pLock;
}

ScResult
sc_rwlock_destroy(ScRwLock lock)
{
    if (!lock)
        return ScResult_Error;

    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;

#if defined(SC_PLATFORM_WINDOWS)
    // SRWLOCK не требует явного удаления, просто освобождаем память
#elif defined(SC_PLATFORM_LINUX)
    if (pthread_rwlock_destroy(&pLock->RwLock) != 0)
    {
        sc_log_warn("Can't destroy rwlock!\n");
        sc_memory_free(pLock);
        return ScResult_Error;
    }
#endif

    sc_memory_free(pLock);
    return ScResult_Success;
}

ScResult
sc_rwlock_read_lock(ScRwLock lock)
{
    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;

#if defined(SC_PLATFORM_WINDOWS)
    AcquireSRWLockShared(&pLock->SrwLock);
#elif defined(SC_PLATFORM_LINUX)
    if (pthread_rwlock_rdlock(&pLock->RwLock) != 0)
    {
        sc_assert(0 && "Read lock failed!");
        return ScResult_Error;
    }
#endif
    return ScResult_Success;
}

ScResult
sc_rwlock_read_unlock(ScRwLock lock)
{
    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;

#if defined(SC_PLATFORM_WINDOWS)
    ReleaseSRWLockShared(&pLock->SrwLock);
#elif defined(SC_PLATFORM_LINUX)
    if (pthread_rwlock_unlock(&pLock->RwLock) != 0)
    {
        sc_assert(0 && "Read unlock failed!");
        return ScResult_Error;
    }
#endif
    return ScResult_Success;
}

ScResult
sc_rwlock_write_lock(ScRwLock lock)
{
    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;

#if defined(SC_PLATFORM_WINDOWS)
    AcquireSRWLockExclusive(&pLock->SrwLock);
#elif defined(SC_PLATFORM_LINUX)
    if (pthread_rwlock_wrlock(&pLock->RwLock) != 0)
    {
        sc_assert(0 && "Write lock failed!");
        return ScResult_Error;
    }
#endif
    return ScResult_Success;
}

ScResult
sc_rwlock_write_unlock(ScRwLock lock)
{
    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;

#if defined(SC_PLATFORM_WINDOWS)
    ReleaseSRWLockExclusive(&pLock->SrwLock);
#elif defined(SC_PLATFORM_LINUX)
    if (pthread_rwlock_unlock(&pLock->RwLock) != 0)
    {
        sc_assert(0 && "Write unlock failed!");
        return ScResult_Error;
    }
#endif

    return ScResult_Success;
}

ScResult
sc_rwlock_try_read_lock(ScRwLock lock)
{
    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;
#if defined(SC_PLATFORM_WINDOWS)
    if (TryAcquireSRWLockShared(&pLock->SrwLock))
        return ScResult_Success;
    return ScResult_Error;
#elif defined(SC_PLATFORM_LINUX)
    i32 result = pthread_rwlock_tryrdlock(&pLock->RwLock);
    if (result == 0)
        return ScResult_Success;
    return ScResult_Error;
#endif
}

ScResult
sc_rwlock_try_write_lock(ScRwLock lock)
{
    ScRWLockInternal* pLock = (ScRWLockInternal*)lock;
#if defined(SC_PLATFORM_WINDOWS)
    if (TryAcquireSRWLockExclusive(&pLock->SrwLock))
        return ScResult_Success;
    return ScResult_Error;
#elif defined(SC_PLATFORM_LINUX)
    i32 result = pthread_rwlock_trywrlock(&pLock->RwLock);
    if (result == 0)
        return ScResult_Success;
    return ScResult_Error;
#endif
}

/*

  ###################################
  ###################################
  sc_job
  ###################################
  ###################################

*/

typedef struct
{
    i8 IsRunning;
    i8 IsBusy;
    ScThread Thread;
} ScJob;

typedef struct
{
    i8 IsRunning;
    ScJob* aJobs;
    ScMutex WorkToDoMutex;
    ScCondition WorkToDoCondition;
    ScJobAction* aWorkToDo;
} ScJobStorage;

static ScJobStorage gJobStorage = {};

void*
sc_job_processor(void* pVoidJob)
{
    ScJob* pJob = (ScJob*)pVoidJob;

    while (pJob->IsRunning)
    {
        ScJobAction jobAction;

        sc_mutex_lock(gJobStorage.WorkToDoMutex);

        // DOCS: No work to do yet.
        pJob->IsBusy = 0;

        while (sc_list_count(gJobStorage.aWorkToDo) == 0 && pJob->IsRunning)
        {
            sc_condition_wait(&gJobStorage.WorkToDoCondition, gJobStorage.WorkToDoMutex);
        }

        if (!pJob->IsRunning)
        {
            sc_mutex_unlock(gJobStorage.WorkToDoMutex);
            break;
        }

        // DOCS: Now we are busy
        pJob->IsBusy = 1;

        jobAction = sc_list_pop(gJobStorage.aWorkToDo);
        sc_mutex_unlock(gJobStorage.WorkToDoMutex);

        if (jobAction)
        {
            jobAction();
        }
    }

    return NULL;
}

void
sc_job_init(ScJobConfig cfg)
{
    if (cfg.JobsCount <= 0)
    {
        sc_log_erro("failed job init: cfg values are wrong!\n");
        sc_assert_break();
        return;
    }

    const i32 c_jobs_count = cfg.JobsCount;
    const i32 c_stack_size = ScKb(1);

    sc_list_reserve(gJobStorage.aJobs, c_jobs_count);
    sc_list_header(gJobStorage.aJobs)->Count = c_jobs_count;

    for (i32 j = 0; j < cfg.JobsCount; ++j)
    {
        ScJob* pJob = &gJobStorage.aJobs[j];
        pJob->IsRunning = 1;
        pJob->IsBusy = 0;
        ScThread scThread = sc_thread_create(sc_job_processor, c_stack_size, &gJobStorage.aJobs[j]);
        pJob->Thread = scThread;
    }

#if defined(SC_BUILD_DEBUG)
    sc_log_info("Job system run with %d jobs\n", c_jobs_count);
#endif // SC_BUILD_DEBUG
}

void
sc_job_deinit()
{
    gJobStorage.IsRunning = 0;

    sc_mutex_lock(gJobStorage.WorkToDoMutex);

    for (i32 j = 0; j < sc_list_count(gJobStorage.aJobs); ++j)
    {
        gJobStorage.aJobs[j].IsRunning = 0;
    }

    // DOCS: Wake up everybody
    sc_condition_broadcast(&gJobStorage.WorkToDoCondition);

    sc_mutex_unlock(gJobStorage.WorkToDoMutex);

    for (i32 j = 0; j < sc_list_count(gJobStorage.aJobs); ++j)
        sc_thread_attach(gJobStorage.aJobs[j].Thread);

    sc_condition_destroy(gJobStorage.WorkToDoCondition);
    sc_mutex_destroy(gJobStorage.WorkToDoMutex);

    sc_list_free(gJobStorage.aJobs);
    sc_list_free(gJobStorage.aWorkToDo);
}

void
sc_job_new(ScJobAction jobAction)
{
    if (!jobAction)
        return;
    sc_mutex_lock(gJobStorage.WorkToDoMutex);
    sc_list_add(gJobStorage.aWorkToDo, jobAction);
    sc_condition_signal(&gJobStorage.WorkToDoCondition);
    sc_mutex_unlock(gJobStorage.WorkToDoMutex);
}

/*

  ###################################
  ###################################
  sc_profiler
  ###################################
  ###################################

*/

void
sc_profiler_start(ScProfiler* pProfiler)
{
#if defined(SC_PLATFORM_WINDOWS)
    // DOCS: Result holds raw QPC ticks here; sc_profiler_end converts the
    // DOCS: difference into nanoseconds through QueryPerformanceFrequency.
    LARGE_INTEGER li = {};
    QueryPerformanceCounter(&li);
    pProfiler->Result = (i64)li.QuadPart;
#else // SC_PLATFORM_LINUX
    struct timespec start = {};
    clock_gettime(CLOCK_REALTIME, &start);
    i64 nanosec = 1000 * 1000 * 1000 * start.tv_sec + start.tv_nsec;
    pProfiler->Result = nanosec;
#endif
}

void
sc_profiler_end(ScProfiler* pProfiler)
{
#if defined(SC_PLATFORM_WINDOWS)
    LARGE_INTEGER end = {};
    QueryPerformanceCounter(&end);

    LARGE_INTEGER frequency = {};
    QueryPerformanceFrequency(&frequency);

    // DOCS: QPC ticks are converted into nanoseconds: without the frequency
    // DOCS: the difference would stay in ticks and NsToMs() would divide it
    // DOCS: as if it were nanoseconds (10x error on a 10 MHz counter).
    i64 ticks = end.QuadPart - pProfiler->Result;
    pProfiler->Result = (i64)(ticks * 1000000000LL / frequency.QuadPart);
#else // defined(SC_PLATFORM_LINUX)
    struct timespec end = {};
    clock_gettime(CLOCK_REALTIME, &end);
    i64 nanosecEnd = 1000 * 1000 * 1000 * end.tv_sec + end.tv_nsec;
    pProfiler->Result = nanosecEnd - pProfiler->Result;
#endif
}

ScProfilerTimeType
sc_profiler_get_time_type(ScProfiler* pProfiler)
{
    if (NsToS(pProfiler->Result))
        return ScProfilerTimeType_S;
    else if (NsToMs(pProfiler->Result))
        return ScProfilerTimeType_Ms;
    else if (NsToMcs(pProfiler->Result))
        return ScProfilerTimeType_Mcs;
    else if (pProfiler->Result)
        return ScProfilerTimeType_Ns;

    sc_assert(0 && "");
    return ScProfilerTimeType_Ns;
}

i64
sc_profiler_get_nanoseconds(ScProfiler* pProfiler)
{
    return pProfiler->Result;
}

i64
sc_profiler_get_microseconds(ScProfiler* pProfiler)
{
    return NsToMcs(pProfiler->Result);
}

i64
sc_profiler_get_milliseconds(ScProfiler* pProfiler)
{
    return NsToMs(pProfiler->Result);
}

i64
sc_profiler_get_seconds(ScProfiler* pProfiler)
{
    return NsToS(pProfiler->Result);
}

f64
sc_profiler_get_microseconds_as_float(ScProfiler* pProfiler)
{
    return NsToMcsFloat(pProfiler->Result);
}

f64
sc_profiler_get_milliseconds_as_float(ScProfiler* pProfiler)
{
    return NsToMsFloat(pProfiler->Result);
}

f64
sc_profiler_get_seconds_as_float(ScProfiler* pProfiler)
{
    return NsToSFloat(pProfiler->Result);
}

void
sc_profiler_print(ScProfiler* pProfiler)
{
    ScProfilerTimeType timeType = sc_profiler_get_time_type(pProfiler);
    switch (timeType)
    {
    case ScProfilerTimeType_Ns:
        printf("%lld %s\n", sc_profiler_get_nanoseconds(pProfiler), "ns");
        break;
    case ScProfilerTimeType_Mcs:
        printf("%lld %s\n", sc_profiler_get_microseconds(pProfiler), "mcs");
        break;
    case ScProfilerTimeType_Ms:
        printf("%lld %s\n", sc_profiler_get_milliseconds(pProfiler), "ms");
        break;
    case ScProfilerTimeType_S:
        printf("%lld %s\n", sc_profiler_get_seconds(pProfiler), "s");
        break;
    default:
        sc_assert(0 && "Just a thing to delete compiler warning message, this code never ever ll be executed!");
        break;
    }
}

void
sc_profiler_print_as_float(ScProfiler* pProfiler)
{
    ScProfilerTimeType timeType = sc_profiler_get_time_type(pProfiler);

    switch (timeType)
    {
    case ScProfilerTimeType_Ns:
        printf("%lld %s\n", sc_profiler_get_nanoseconds(pProfiler), "ns");
        break;
    case ScProfilerTimeType_Mcs:
        printf("%.4f %s\n", sc_profiler_get_microseconds_as_float(pProfiler), "mcs");
        break;
    case ScProfilerTimeType_Ms:
        printf("%.4f %s\n", sc_profiler_get_milliseconds_as_float(pProfiler), "ms");
        break;
    case ScProfilerTimeType_S:
        printf("%.4f %s\n", sc_profiler_get_seconds_as_float(pProfiler), "s");
        break;
    default:
        sc_assert(0 && "Just a thing to delete compiler warning message, this code never ever ll be executed!");
        break;
    }
}

char*
sc_profiler_get_string(ScProfiler* pProfiler)
{
    static char g_TimeString[512] = {};
    ScProfilerTimeType timeType = sc_profiler_get_time_type(pProfiler);

    switch (timeType)
    {
    case ScProfilerTimeType_Ns:
        snprintf(g_TimeString, 512, "%lld %s", sc_profiler_get_nanoseconds(pProfiler), "ns");
        break;
    case ScProfilerTimeType_Mcs:
        snprintf(g_TimeString, 512, "%lld %s", sc_profiler_get_microseconds(pProfiler), "mcs");
        break;
    case ScProfilerTimeType_Ms:
        snprintf(g_TimeString, 512, "%lld %s", sc_profiler_get_milliseconds(pProfiler), "ms");
        break;
    case ScProfilerTimeType_S:
        snprintf(g_TimeString, 512, "%lld %s", sc_profiler_get_seconds(pProfiler), "s");
        break;
    default:
        sc_assert(0 && "Just a thing to delete compiler warning message, this code never ever ll be executed!");
        break;
    }

    return (char*)g_TimeString;
}

char*
sc_profiler_get_string_as_float(ScProfiler* pProfiler)
{
    static char timeBuf[512] = {};
    ScProfilerTimeType timeType = sc_profiler_get_time_type(pProfiler);

    switch (timeType)
    {
    case ScProfilerTimeType_Ns:
    {
        f64 temp = sc_profiler_get_nanoseconds(pProfiler);
        snprintf(timeBuf, 512, "%f %s\n", temp, "ns");
        break;
    }
    case ScProfilerTimeType_Mcs:
    {
        f64 temp = sc_profiler_get_microseconds_as_float(pProfiler);
        snprintf(timeBuf, 512, "%f %s\n", temp, "mcs");
        break;
    }
    case ScProfilerTimeType_Ms:
    {
        f64 temp = sc_profiler_get_milliseconds_as_float(pProfiler);
        snprintf(timeBuf, 512, "%f %s\n", temp, "ms");
        break;
    }
    case ScProfilerTimeType_S:
    {
        f64 temp = sc_profiler_get_seconds_as_float(pProfiler);
        snprintf(timeBuf, 512, "%f %s\n", temp, "s");
        break;
    }
    default:
    {
        sc_assert(0 && "Just a thing to delete compiler warning message, this code never ever ll be executed!");
        break;
    }
    }

    return (char*)timeBuf;
}

/*

  ###################################
  ###################################
  sc_date_time
  ###################################
  ###################################

*/

i64
sc_date_time_now_seconds()
{
    return (i64)time(NULL);
}

ScDateTime
sc_date_time_now()
{
    ScDateTime dt = {};

    time_t rawtime = time(NULL);
    if (rawtime == -1)
    {
        printf("Raw time is -1 simple_time_now()\n");
        // handle error
        return dt;
    }

    struct tm* ptr = localtime(&rawtime);

    dt.DayOfTheWeek = ptr->tm_wday;
    dt.Seconds = ptr->tm_sec;
    dt.Minutes = ptr->tm_min;
    dt.Hours = ptr->tm_hour;
    dt.Day = ptr->tm_mday;
    dt.Month = ptr->tm_mon + 1;
    dt.Year = 1900 + ptr->tm_year;

    return dt;
}

static i32
sc_date_time_days_in_month(i32 month, i32 year)
{
    static const i32 aDaysInMonth[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    i32 days = aDaysInMonth[month - 1];
    // DOCS: февраль високосного года
    if (month == 2 && ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0))
    {
        days = 29;
    }

    return days;
}

void
sc_date_time_add_seconds(ScDateTime* pDt, f32 seconds)
{
    if (pDt == NULL || seconds <= 0.0f)
    {
        return;
    }

    // DOCS: добавляются только целые секунды, дробная часть отбрасывается
    i64 totalSeconds = (i64)seconds + pDt->Seconds;
    pDt->Seconds = (u8)(totalSeconds % 60);

    i64 totalMinutes = totalSeconds / 60 + pDt->Minutes;
    pDt->Minutes = (u8)(totalMinutes % 60);

    i64 totalHours = totalMinutes / 60 + pDt->Hours;
    pDt->Hours = (u8)(totalHours % 24);

    // DOCS: остаток часов переходит в дни
    i64 extraDays = totalHours / 24;
    while (extraDays > 0)
    {
        i32 daysInMonth = sc_date_time_days_in_month(pDt->Month, pDt->Year);
        i32 daysLeft = daysInMonth - pDt->Day;
        if (extraDays <= daysLeft)
        {
            pDt->Day = (u8)(pDt->Day + extraDays);
            break;
        }

        // DOCS: избыток дней переходит в месяцы, месяцы — в годы
        extraDays -= daysLeft + 1;
        pDt->Day = 1;
        ++pDt->Month;
        if (pDt->Month > 12)
        {
            pDt->Month = 1;
            ++pDt->Year;
        }
    }
}

const char*
sc_date_time_to_string(ScDateTime dt)
{
    static char buf[64] = {};
    snprintf(buf, 64, "%2.2d:%2.2d:%2.2d %2.2d.%2.2d.%4.4d", dt.Hours, dt.Minutes, dt.Seconds, dt.Day, dt.Month, dt.Year);
    return (char*)buf;
}

const char*
sc_date_time_to_date_string(ScDateTime dt)
{
    static char buf[64] = {};
    snprintf(buf, 64, "%2.2d:%2.2d:%2.2d", dt.Day, dt.Month, dt.Year);
    return (char*)buf;
}

const char*
sc_date_time_to_time_string(ScDateTime dt)
{
    static char buf[64] = {};
    snprintf(buf, 64, "%2.2d:%2.2d:%2.2d", dt.Hours, dt.Minutes, dt.Seconds);
    return (char*)buf;
}

/*

  ###################################
  ###################################
  sc_timer
  ###################################
  ###################################

*/

ScTimer
sc_timer_new(f32 secondsToWait)
{
    ScTimer scTimer = { .SecondsToWait = secondsToWait };
    return scTimer;
}

i32
sc_timer_interval(ScTimer* pTimer, f32 timestep)
{
    pTimer->SecondsToWait -= timestep;
    if (pTimer->SecondsToWait <= 0)
    {
        pTimer->SecondsToWait = 0;
        return 1;
    }
    return 0;
}

void
sc_timer_reset(ScTimer* pTimer, f32 secondsToWait)
{
    pTimer->SecondsToWait = secondsToWait;
}

/*

  ###################################
  ###################################
  sc_log
  ###################################
  ###################################

*/

static struct
{
    i32 BackendsCount;
    ScLogBackend* aBackends;
} gScLog = {};

void
sc_log_init(ScLogConfig config)
{
    if (gScLog.aBackends)
    {
        sc_log_warn("sc_log is already initialized!\n");
        return;
    }

    gScLog.BackendsCount = config.BackendsCount;

    ScLogBackend* aBacks = NULL;
    for (i32 i = 0; i < config.BackendsCount; ++i)
    {
        ScLogBackend back = config.aBackends[i];
        sc_list_add(aBacks, back);
    }

    gScLog.aBackends = aBacks;
}

void
sc_log_init_default()
{
    ScLogBackend* aBacks = NULL;

    ScLogBackend terminalBack = sc_log_get_terminal_backend();
    sc_list_add(aBacks, terminalBack);

    ScLogBackend fileBack = sc_log_get_file_backend();
    sc_list_add(aBacks, fileBack);

    gScLog.BackendsCount = 2;
    gScLog.aBackends = aBacks;
}

void
sc_log_deinit()
{
    sc_list_free(gScLog.aBackends);
}

const char*
sc_log_level_to_color(ScLogLevel level)
{
    switch (level)
    {
    case ScLogLevel_Info:
        return "\x1B[95m";
    case ScLogLevel_Debug:
        return "\x1B[37m";
    case ScLogLevel_Success:
        return "\x1B[92m";
    case ScLogLevel_Warn:
        return "\x1B[93m";
    case ScLogLevel_Error:
        return "\x1B[31m";

    default:
        return "\x1B[33m";
    }
}

const char*
sc_log_level_to_string(ScLogLevel level)
{
    switch (level)
    {
    case ScLogLevel_Info:
        return "[ INFO ]";
    case ScLogLevel_Debug:
        return "[ DEBG ]";
    case ScLogLevel_Success:
        return "[ SUCS ]";
    case ScLogLevel_Warn:
        return "[ WARN ]";
    case ScLogLevel_Error:
        return "[ ERRO ]";
    default:
        return "";
    }
}

void
sc_log_terminal_action(ScLogItem item, ScLogFormat* aFormats, u32 formatsCount)
{
    for (i32 i = 0; i < formatsCount; ++i)
    {
        ScLogFormat format = aFormats[i];
        switch (format)
        {
        case ScLogFormat_File:
        {
            printf("%s ", item.pFile);
            break;
        }
        case ScLogFormat_File_Short:
        {
            printf("%s ", sc_path_get_name_wo_alloc((char*)item.pFile));
            break;
        }

        case ScLogFormat_Function:
        {
            printf("%s ", item.pFunction);
            break;
        }
        case ScLogFormat_Function_Line:
        {
            printf("%s:%d ", item.pFunction, item.Line);
            break;
        }

        case ScLogFormat_Line:
        {
            printf("%d ", item.Line);
            break;
        }

        case ScLogFormat_Level:
        {
            const char* pColor = sc_log_level_to_color(item.Level);
            const char* pLevel = sc_log_level_to_string(item.Level);
            printf("%s%s\033[0m ", pColor, pLevel);
            break;
        }

        case ScLogFormat_Time:
        {
            const char* pTime = sc_date_time_to_time_string(item.DateTime);
            printf("%s ", pTime);
            break;
        }

        case ScLogFormat_Message:
        {
            printf("%s", item.pMessage);
            break;
        }

        default:
            break;
        }
    }
}

void
sc_log_file_action(ScLogItem item, ScLogFormat* aFormats, u32 formatsCount)
{
    char* pSb = NULL;

    for (i32 i = 0; i < formatsCount; ++i)
    {
        ScLogFormat format = aFormats[i];
        switch (format)
        {
        case ScLogFormat_File:
        {
            sc_builder_append_format(pSb, "%s ", item.pFile);
            break;
        }
        case ScLogFormat_File_Short:
        {
            sc_builder_append_format(pSb, "%s ", sc_path_get_name_wo_alloc((char*)item.pFile));
            break;
        }

        case ScLogFormat_Function:
        {
            sc_builder_append_format(pSb, "%s ", item.pFunction);
            break;
        }
        case ScLogFormat_Function_Line:
        {
            sc_builder_append_format(pSb, "%s:%d ", item.pFunction, item.Line);
            break;
        }

        case ScLogFormat_Line:
        {
            sc_builder_append_format(pSb, "%d ", item.Line);
            break;
        }

        case ScLogFormat_Level:
        {
            const char* pLevel = sc_log_level_to_string(item.Level);
            sc_builder_append_format(pSb, "%s ", pLevel);
            break;
        }

        case ScLogFormat_Time:
        {
            const char* pTime = sc_date_time_to_time_string(item.DateTime);
            sc_builder_append_format(pSb, "%s ", pTime);
            break;
        }

        case ScLogFormat_Message:
        {
            sc_builder_append_format(pSb, "%s", item.pMessage);
            break;
        }

        default:
            break;
        }
    }

    sc_file_append_string("sc.log", pSb, sc_builder_count(pSb));
}

ScLogBackend
sc_log_get_terminal_backend()
{
    ScLogBackend back = {
        .aFormats = {
            ScLogFormat_Level,
            ScLogFormat_Time,
            ScLogFormat_File_Short,
            ScLogFormat_Function_Line,
            ScLogFormat_Message,
        },
        .FormatsCount = 5,
        .Action = sc_log_terminal_action
    };
    return back;
}

ScLogBackend
sc_log_get_file_backend()
{
    ScLogBackend back = {
        .aFormats = {
            ScLogFormat_Level,
            ScLogFormat_Time,
            ScLogFormat_File_Short,
            ScLogFormat_Function_Line,
            ScLogFormat_Message,
        },
        .FormatsCount = 5,
        .Action = sc_log_file_action
    };
    return back;
}

void
sc_log_base(ScLogLevel level, const char* pFile, i32 line, const char* pFunction, const char* pFormat, ...)
{
#define buf_size ScKb(5)
    char buf[buf_size] = {};

    va_list list;
    va_start(list, pFormat);
    ScFormatResult res = sc_format_ext(buf, buf_size, pFormat, list);
    va_end(list);

    ScLogItem item = {
        .Level = level,
        .pFile = pFile,
        .Line = line,
        .pMessage = buf,
        .MessageSize = res.Size,
        .pFunction = (char*)pFunction,
        .DateTime = sc_date_time_now()
    };

    for (i32 i = 0; i < gScLog.BackendsCount; ++i)
    {
        ScLogBackend logBackend = gScLog.aBackends[i];
        logBackend.Action(item, logBackend.aFormats, logBackend.FormatsCount);
    }
#undef buf_size
}

/*

  ###################################
  ###################################
  sc_bitset
  ###################################
  ###################################

*/

void
sc_bitset_set_0(u64* pBitset, u16 bitSetSize, u16 bit)
{
    sc_bitset_validate(bitSetSize, bit);
    u64 index = sc_bitset_get_bit_index(bit);
    u64 bitMask = sc_bitset_get_bit_mask(bit);
    // Устанавливаем бит в 0 (AND с инвертированной маской)
    pBitset[index] &= ~bitMask;
}

void
sc_bitset_set_1(u64* pBitset, u16 bitSetSize, u16 bit)
{
    sc_bitset_validate(bitSetSize, bit);
    u64 index = sc_bitset_get_bit_index(bit);
    u64 bitMask = sc_bitset_get_bit_mask(bit);
    // Устанавливаем бит в 1 (OR операция)
    pBitset[index] |= bitMask;
}

u8
sc_bitset_get(const u64* pBitset, u16 bitSetSize, u16 bit)
{
    sc_bitset_validate(bitSetSize, bit);
    if (bit >= bitSetSize)
        return 0;
    u64 index = sc_bitset_get_bit_index(bit);
    u64 bitMask = sc_bitset_get_bit_mask(bit);
    u64 value = pBitset[index] & bitMask;
    return value != 0;
}

i32
sc_bitset_contains(u64* pBitset0, u16 bitset0Size, u64* pBitset1, u16 bitset1Size)
{
    if (bitset0Size == 0 || bitset1Size == 0)
        return 0;

    // DOCS: Bits are stored as u64 array, [0] holds bits 0-63, [1] - 64-127, etc.
    u16 wordCount = (bitset1Size + 63) / 64;
    for (u16 i = 0; i < wordCount; ++i)
    {
        // DOCS: pBitset0 should contain every bit set in pBitset1.
        // pBitset0 may have more flags set - those are ignored.
        u64 b0 = pBitset0[i];
        u64 b1 = pBitset1[i];
        if ((b0 & b1) != b1)
            return 0;
    }

    return 1;
}

void
sc_bitset_concrete(u64* pBitset, u16 bitsetSize, i32* aBitsToCheck, i32 bitsToCheckCount)
{
    printf("\nBitset test for Bitset%d\n", bitsetSize);

    for (i32 b = 0; b < bitsToCheckCount; ++b)
    {
        sc_bitset_set_1(pBitset, bitsetSize, aBitsToCheck[b]);
    }

    for (i32 b = 0; b < bitsToCheckCount; ++b)
    {
        u8 bitValue = sc_bitset_get(pBitset, bitsetSize, aBitsToCheck[b]);
        printf("Bitset%d[%d] = %d\n", bitsetSize, aBitsToCheck[b], bitValue);
    }
}

void
sc_bitset_test()
{
    {
        u64 bitset[4] = {};
        i32 aBitsToValidate[] = { 0, 32, 64, 65, 128, 255 };
        sc_bitset_concrete(bitset, sc_bits_count(bitset), aBitsToValidate, ScArrayCount(aBitsToValidate));
        printf("Bits Count: %d\n", sc_bits_count(bitset));
    }

    {
        u64 bitset512[8] = {};
        i32 aBitsToValidate[] = { 0, 32, 64, 65, 128, 255, 354, 500 };
        sc_bitset_concrete(bitset512, sc_bits_count(bitset512), aBitsToValidate, ScArrayCount(aBitsToValidate));
        printf("Bits Count: %d\n", sc_bits_count(bitset512));
    }

    {
        bitset256 bitset256 = {};
        i32 aBitsToValidate[] = { 0, 32, 64, 65, 128, 255 };
        sc_bitset_concrete(bitset256.Mask, sc_bits_count(bitset256), aBitsToValidate, ScArrayCount(aBitsToValidate));
        printf("Bits Count: %d\n", sc_bits_count(bitset256));
    }
}

/*

  ###################################
  ###################################
  sc_random
  ###################################
  ###################################

*/

#if defined(SC_PLATFORM_LINUX)

u64
sc_random()
{
    return sc_random_ext(GRND_NONBLOCK);
}

u64
sc_random_ext(u32 flags)
{
    u64 rv;
    ssize_t result = getrandom(&rv, sizeof(rv), flags);
    return rv;
}

#elif defined(SC_PLATFORM_WINDOWS)

u64
sc_random()
{
    return sc_random_ext(0);
}

u64
sc_random_ext(u32 flags)
{
    // #pragma comment(lib, "bcrypt.lib") // need this lib on windows
    u64 rv;

    // BCRYPT_USE_SYSTEM_PREFERRED_RNG (0x00000002) использует системный CSPRNG
    NTSTATUS status = BCryptGenRandom(
        NULL, // Не нужно открывать алгоритм
        (PUCHAR)&rv,
        sizeof(rv),
        BCRYPT_USE_SYSTEM_PREFERRED_RNG // Используем системный RNG
    );
    return rv;
}

#endif // SC_PLATFORM_WINDOWS
