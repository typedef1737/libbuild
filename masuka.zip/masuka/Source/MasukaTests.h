#ifndef MSK_TESTS_H
#define MSK_TESTS_H

#include "Types.h"

/*
   DOCS: MasukaTests - unit tests of the Masuka build system.
   Standalone executable (masuka-test, see masuka-test.masuka): CLI parsing,
   language parsers, preprocessor, project graph, script generator, compiler.

   DOCS: The old --self-test flag of masuka was removed: a build system must
   DOCS: not test itself. Tests are a separate project of the workspace.
*/

// DOCS: Run the whole test suite. Returns 0 when everything passed, 1 otherwise.
i32 msk_tests_run(void);

#endif // MSK_TESTS_H
