#ifndef SC_TEST_H
#define SC_TEST_H

#include "Sc.h"

/*

   USAGE:

   sc_test_file();
   sc_test_func(test_sc_string_get_length());
*/

// how to visualize pMessage when it multiple line?
typedef struct
{
    i64 Code;
    char* pMessage;
} ScTestRecr;

typedef struct
{
    char* pName;
    ScTestRecr* aRecords;
} ScTestFunc;

typedef struct
{
    char* pFileName;
    ScTestFunc* aFuncs;
} ScTestFile;

typedef struct
{
    // 0 - long for everything, 1 - short for everything except exceptions, 2 - long for errors otherwise short
    i8 IsShort;
    char** aLongPrintFuncs;
} ScTestVisualizeConfig;

#define sc_test_file() sc_test_set_file(__FILE__)
#define sc_test_func(func)   \
    sc_test_set_func(#func); \
    func

#define sc_test_condition(cond)                             \
    ({                                                      \
        i32 isTrue = (cond);                                \
        sc_test_set_record((ScTestRecr) { isTrue, #cond }); \
    })

#define sc_test_string_equals(s0, s1) \
    sc_test_string_equal_ext((const char*)s0, (const char*)s1, #s0, #s1)
void sc_test_string_equal_ext(const char* pStr0, const char* pStr1, const char* pStr0Name, const char* pStr1Name);

#define sc_test_string_value(str)                   \
    ({                                              \
        sc_test_set_record((ScTestRecr) {           \
            1,                                      \
            str ? sc_string_new(str) : "<NULL>" }); \
    })

void sc_test_i64_value_ext(i64 value, const char* pValueName);

#define sc_test_i32_value(i32val)               \
    ({                                          \
        sc_test_i64_value_ext(i32val, #i32val); \
    })

#define sc_test_f32_value(f32val)                                   \
    ({                                                              \
        char buf[128] = {};                                         \
        sc_float_to_string(buf, 128, f32val);                       \
        sc_test_set_record((ScTestRecr) { 1, sc_string_new(buf) }); \
    })

#define sc_test_v2_value(v2val)                                     \
    ({                                                              \
        char buf[128] = {};                                         \
        sc_v2_to_string(buf, 128, v2val);                           \
        sc_test_set_record((ScTestRecr) { 1, sc_string_new(buf) }); \
    })

#define sc_test_v3_value(v3val)                                     \
    ({                                                              \
        char buf[128] = {};                                         \
        sc_v3_to_string(buf, 128, v3val);                           \
        sc_test_set_record((ScTestRecr) { 1, sc_string_new(buf) }); \
    })

#define sc_test_v4_value(v4val)                                     \
    ({                                                              \
        char buf[128] = {};                                         \
        sc_v4_to_string(buf, 128, v4val);                           \
        sc_test_set_record((ScTestRecr) { 1, sc_string_new(buf) }); \
    })

#define sc_test_quat_value(qVal)                                    \
    ({                                                              \
        char buf[128] = {};                                         \
        sc_quat_to_string(buf, 128, qVal);                          \
        sc_test_set_record((ScTestRecr) { 1, sc_string_new(buf) }); \
    })

void sc_test_i32_equal_ext(i32 i0, i32 i1, const char* pI0Str, const char* pI1Str);
#define sc_test_i32_equal(i0, i1)                \
    ({                                           \
        sc_test_i32_equal_ext(i0, i1, #i0, #i1); \
    })

#define sc_test_f32_equal(f0, f1)                                     \
    ({                                                                \
        i32 isEqual = f32_equal(f0, f1);                              \
        sc_test_set_record((ScTestRecr) { isEqual, #f0 " == " #f1 }); \
    })

#define sc_test_v2_equal(v0, v1)                                      \
    ({                                                                \
        i32 isEqual = v2_equal(v0, v1);                               \
        sc_test_set_record((ScTestRecr) { isEqual, #v0 " == " #v1 }); \
    })

#define sc_test_v3_equal(v0, v1)                                      \
    ({                                                                \
        i32 isEqual = v3_equal(v0, v1);                               \
        sc_test_set_record((ScTestRecr) { isEqual, #v0 " == " #v1 }); \
    })

#define sc_test_v4_equal(v0, v1)                                      \
    ({                                                                \
        i32 isEqual = v3_equal(v0, v1);                               \
        sc_test_set_record((ScTestRecr) { isEqual, #v0 " == " #v1 }); \
    })

#define sc_test_quat_equal(q0, q1)                                    \
    ({                                                                \
        i32 isEqual = quat_equal(q0, q1);                             \
        sc_test_set_record((ScTestRecr) { isEqual, #q0 " == " #q1 }); \
    })

void sc_test_set_file(const char* pFilePath);
void sc_test_set_func(const char* pFunction);
void sc_test_set_record(ScTestRecr testRecord);
i32 sc_test_is_function_was_failed();

ScTestFile* sc_test_get();

void sc_test_visualize(ScTestFile* aFiles, ScTestVisualizeConfig cfg);

#endif // SC_TEST_H
