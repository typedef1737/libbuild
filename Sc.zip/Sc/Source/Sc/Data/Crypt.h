#ifndef SC_CRYPT_H
#define SC_CRYPT_H

#endif // SC_CRYPT_H
