#include "Engine/Assety/MrqlAssety.h"
#include "Engine/MrqlApplication.h"
#include "Engine/Observy/MrqlObserver.h"
#include "Engine/Rendy/MrqlRenderer.h"
#include "Sc/Font.h"
#include "Sc/Math.h"
#include "Sc/Sc.h"
#include <math.h>

typedef struct
{
    v3 Position;
    v4 Color;
} PrimitiveVertex;

typedef struct
{
    v3 Position;
    v4 Color;
    v2 Uv;
} PrimitiveTextVertex;

static struct
{
    ScVk* pScVk;
    i32 PassId;
    i32 PipeId;
    i32 PointPipeId;
    i32 TextPipeId;

    PrimitiveVertex* aVertices;
    u32* aIndices;

    PrimitiveVertex* aPoints;
    u32* aPointIndices;

    PrimitiveTextVertex* aTexts;
    u32* aTextIndices;

} g = {};

void primitive_create_pass();
void primitive_create_pipe(MrqlRendererPrimitiveConfig cfg);
void primitive_create_points_pipe(MrqlRendererPrimitiveConfig cfg);
void primitive_create_text_pipe(MrqlRendererPrimitiveConfig cfg);

void
mrql_renderer_primitive_init(MrqlRendererPrimitiveConfig cfg)
{
    g.pScVk = cfg.pScVk;
    primitive_create_pass();
    primitive_create_pipe(cfg);
    primitive_create_points_pipe(cfg);
    primitive_create_text_pipe(cfg);

    ScVkRenderPass* pPass = sc_vk_get_render_pass(g.pScVk, g.PassId);
    sc_vk_render_pass_create_buffers(g.pScVk, pPass->Id);

    MrqlObserverSubscriber sub = {
        .pName = "MrqlRenderer-Primitive",
        .CameraUpdate = mrql_renderer_primitive_set_camera
    };
    mrql_observer_add_camera_sub(sub);
}

void
mrql_renderer_primitive_deinit()
{
    sc_vk_pipeline_destroy_by_id(g.pScVk, g.PipeId);
    sc_vk_pipeline_destroy_by_id(g.pScVk, g.PointPipeId);
    sc_vk_pipeline_destroy_by_id(g.pScVk, g.TextPipeId);
    sc_vk_render_pass_destroy(g.pScVk, g.PassId);
    sc_list_remove_index(g.pScVk->aPipelines, g.PipeId);
    sc_list_remove_index(g.pScVk->aPipelines, g.PointPipeId);
    sc_list_remove_index(g.pScVk->aPipelines, g.TextPipeId);
    sc_list_remove_index(g.pScVk->aRenderPasses, g.PassId);
}

void
primitive_create_pass()
{
    ScVk* pScVk = g.pScVk;
    v2 windowSize = mrql_application_get_window_size();

    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
    VkFormat depthAttachmentFormat = VK_FORMAT_D32_SFLOAT;

    VkAttachmentDescription colorDescr = {
        .format = pScVk->Swap.SurfaceFormat.format,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
    };
    ScVkAttachment color = {
        .Type = ScVkAttachmentType_Color,
        .Description = colorDescr,
        .Reference = { .attachment = 0, .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL }
    };

    VkAttachmentDescription depthDescr = {
        .format = depthAttachmentFormat,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL
    };
    ScVkAttachment depth = {
        .Type = ScVkAttachmentType_Depth,
        .Description = depthDescr,
        .Reference = { .attachment = 1, .layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL }
    };

    ScVkAttachment aAttachments[] = {
        color, depth
    };

    VkSubpassDependency subpassDependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .srcAccessMask = 0,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
        .dependencyFlags = 0,
    };

    ScVkRenderPassConfig renderPassCfg = {
        .aAttachments = aAttachments,
        .Dependency = subpassDependency,
        .Resolution = windowSize,
        .AttachmentsCount = 2,
        .BufferingType = ScVkRenderPassBufferingType_Single
    };

    g.PassId = sc_vk_render_pass_new(pScVk, renderPassCfg);
}

void
primitive_create_pipe(MrqlRendererPrimitiveConfig cfg)
{
    ScVk* pScVk = g.pScVk;
    i64 renderPassId = g.PassId;

    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = sizeof(m4) },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/PrimitivePipe.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = ScArrayCount(aDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/PrimitivePipe.frag",
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveVertex, Color),
        },
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 1,
        .Topology = ScVkTopologyType_TriangleList,
        .Blend = {
            .State = ScVkBlendState_Enabled },
        .RenderPassId = renderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .Stride = sizeof(PrimitiveVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = cfg.VerticesCount,
        .IndicesCount = 6 * cfg.VerticesCount });
    sc_vk_pipeline_config_print(pScVk, pipeCfg);

    g.PipeId = sc_vk_pipeline_new(pScVk, pipeCfg);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, g.PassId);
    sc_vk_render_pass_create_buffers(pScVk, pPass->Id);
}

void
primitive_create_points_pipe(MrqlRendererPrimitiveConfig cfg)
{
    ScVk* pScVk = g.pScVk;
    i64 renderPassId = g.PassId;

    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = sizeof(m4) },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/PrimitivePointPipe.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = ScArrayCount(aDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/PrimitivePointPipe.frag",
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveVertex, Color),
        },
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 1,
        .Topology = ScVkTopologyType_PointList,
        .Blend = {
            .State = ScVkBlendState_Disabled },
        .RenderPassId = renderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .Stride = sizeof(PrimitiveVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = cfg.VerticesCount,
        .IndicesCount = 0 });
    sc_vk_pipeline_config_print(pScVk, pipeCfg);

    g.PointPipeId = sc_vk_pipeline_new(pScVk, pipeCfg);
}

void
primitive_create_text_pipe(MrqlRendererPrimitiveConfig cfg)
{
    ScVk* pScVk = g.pScVk;
    i64 renderPassId = g.PassId;
    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = sizeof(m4) },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/PrimitiveTextPipe.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = ScArrayCount(aDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkDescriptorConfig aFragDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_FontTexture",
            .Type = ScVkDescriptorType_Image,
            .Binding = 1,
            .Count = 1 },
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/PrimitiveTextPipe.frag",
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk),
        .aDescriptors = aFragDescriptors,
        .DescriptorsCount = ScArrayCount(aFragDescriptors),
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveTextVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveTextVertex, Color),
        },
        [2] = {
            .Format = VK_FORMAT_R32G32_SFLOAT,
            .Offset = ScOffsetOf(PrimitiveTextVertex, Uv),
        }
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 1,
        .Topology = ScVkTopologyType_PointList,
        .Blend = {
            .State = ScVkBlendState_Disabled },
        .RenderPassId = renderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .Stride = sizeof(PrimitiveVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = cfg.VerticesCount,
        .IndicesCount = 0 });
    sc_vk_pipeline_config_print(pScVk, pipeCfg);

    g.TextPipeId = sc_vk_pipeline_new(pScVk, pipeCfg);

    { // DOCS: Seting font texture
        i64 fontId = mrql_assety_load_font_id(resource_font("MartianMono-sWdRg.ttf"), 32, 0, 127);
        Sc2dTexture* pTexture = (Sc2dTexture*)mrql_assety_get_vk_texture(fontId);

        VkDescriptorImageInfo imageInfo = {
            .sampler = pTexture->Sampler,
            .imageView = pTexture->View,
            .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
        };

        ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.TextPipeId);

        ScVkDescriptorConfig* pTextures = sc_vk_pipeline_get_descriptor(pPipe, "u_FontTexture");
        VkWriteDescriptorSet writeDescrSet = {
            .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
            .dstSet = pPipe->ShaderBridge.Set,
            .dstBinding = pTextures->Binding, // 3
            .dstArrayElement = 0,
            .descriptorCount = 1,
            .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
            .pImageInfo = &imageInfo,
        };
        vkUpdateDescriptorSets(g.pScVk->Device, 1, &writeDescrSet, 0, NULL);
    }
}

void
mrql_renderer_primitive_set_camera(m4 viewProjection)
{
    sc_vk_pipeline_set_uniform(g.pScVk, g.PipeId, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
    sc_vk_pipeline_set_uniform(g.pScVk, g.PointPipeId, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
    sc_vk_pipeline_set_uniform(g.pScVk, g.TextPipeId, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
}

void
mrql_renderer_primivity_draw_plane_ext(v3 pos, v2 size, v4 aColors[4])
{
    PrimitiveVertex pv0 = {
        .Position = pos,
        .Color = aColors[0]
    };
    PrimitiveVertex pv1 = {
        .Position = v3_new(pos.X + size.Width, pos.Y, pos.Z),
        .Color = aColors[1]
    };
    PrimitiveVertex pv2 = {
        .Position = v3_new(pos.X + size.Width, pos.Y, pos.Z + size.Height),
        .Color = aColors[2]
    };
    PrimitiveVertex pv3 = {
        .Position = v3_new(pos.X, pos.Y, pos.Z + size.Height),
        .Color = aColors[3]
    };

    i64 verticesCount = sc_list_count(g.aVertices);
    sc_list_add(g.aVertices, pv0);
    sc_list_add(g.aVertices, pv1);
    sc_list_add(g.aVertices, pv2);
    sc_list_add(g.aVertices, pv3);

    sc_list_add(g.aIndices, verticesCount + 0);
    sc_list_add(g.aIndices, verticesCount + 1);
    sc_list_add(g.aIndices, verticesCount + 2);
    sc_list_add(g.aIndices, verticesCount + 2);
    sc_list_add(g.aIndices, verticesCount + 3);
    sc_list_add(g.aIndices, verticesCount + 0);
}

void
mrql_renderer_primitive_draw_cube_ext(v3 pos, v3 size, v4 aColors[3])
{
    // front
    v3 fbl = pos;
    v3 fbr = v3_new(pos.X + size.X, pos.Y, pos.Z);
    v3 fur = v3_new(pos.X + size.X, pos.Y + size.Y, pos.Z);
    v3 ful = v3_new(pos.X, pos.Y + size.Y, pos.Z);

    // back
    v3 bbl = v3_new(pos.X, pos.Y, pos.Z + size.Z);
    v3 bbr = v3_new(pos.X + size.X, pos.Y, pos.Z + size.Z);
    v3 bur = v3_new(pos.X + size.X, pos.Y + size.Y, pos.Z + size.Z);
    v3 bul = v3_new(pos.X, pos.Y + size.Y, pos.Z + size.Z);

    PrimitiveVertex aVertices[] = {
        // DOCS: Bot
        (PrimitiveVertex) { fbl, aColors[0] },
        (PrimitiveVertex) { fbr, aColors[0] },
        (PrimitiveVertex) { bbr, aColors[0] },
        (PrimitiveVertex) { bbl, aColors[0] },
        // DOCS: Top
        (PrimitiveVertex) { ful, aColors[0] },
        (PrimitiveVertex) { fur, aColors[0] },
        (PrimitiveVertex) { bur, aColors[0] },
        (PrimitiveVertex) { bul, aColors[0] },

        // DOCS: Front
        (PrimitiveVertex) { ful, aColors[1] },
        (PrimitiveVertex) { fbl, aColors[1] },
        (PrimitiveVertex) { fbr, aColors[1] },
        (PrimitiveVertex) { fur, aColors[1] },
        // DOCS: Backward
        (PrimitiveVertex) { bul, aColors[1] },
        (PrimitiveVertex) { bbl, aColors[1] },
        (PrimitiveVertex) { bbr, aColors[1] },
        (PrimitiveVertex) { bur, aColors[1] },

        // DOCS: Left
        (PrimitiveVertex) { bul, aColors[2] },
        (PrimitiveVertex) { bbl, aColors[2] },
        (PrimitiveVertex) { fbl, aColors[2] },
        (PrimitiveVertex) { ful, aColors[2] },
        // DOCS: Right
        (PrimitiveVertex) { bur, aColors[2] },
        (PrimitiveVertex) { bbr, aColors[2] },
        (PrimitiveVertex) { fbr, aColors[2] },
        (PrimitiveVertex) { fur, aColors[2] },
    };

    i64 verticesCount = sc_list_count(g.aVertices);
    for (i32 i = 0; i < ScArrayCount(aVertices); ++i)
    {
        sc_list_add(g.aVertices, aVertices[i]);
    }

    // DOCS: Bot
    sc_list_add(g.aIndices, verticesCount + 0);
    sc_list_add(g.aIndices, verticesCount + 1);
    sc_list_add(g.aIndices, verticesCount + 2);
    sc_list_add(g.aIndices, verticesCount + 2);
    sc_list_add(g.aIndices, verticesCount + 3);
    sc_list_add(g.aIndices, verticesCount + 0);
    // DOCS: Top
    sc_list_add(g.aIndices, verticesCount + 0 + 4);
    sc_list_add(g.aIndices, verticesCount + 1 + 4);
    sc_list_add(g.aIndices, verticesCount + 2 + 4);
    sc_list_add(g.aIndices, verticesCount + 2 + 4);
    sc_list_add(g.aIndices, verticesCount + 3 + 4);
    sc_list_add(g.aIndices, verticesCount + 0 + 4);

    // DOCS: Front
    sc_list_add(g.aIndices, verticesCount + 0 + 8);
    sc_list_add(g.aIndices, verticesCount + 1 + 8);
    sc_list_add(g.aIndices, verticesCount + 2 + 8);
    sc_list_add(g.aIndices, verticesCount + 2 + 8);
    sc_list_add(g.aIndices, verticesCount + 3 + 8);
    sc_list_add(g.aIndices, verticesCount + 0 + 8);
    // DOCS: Backward
    sc_list_add(g.aIndices, verticesCount + 0 + 12);
    sc_list_add(g.aIndices, verticesCount + 1 + 12);
    sc_list_add(g.aIndices, verticesCount + 2 + 12);
    sc_list_add(g.aIndices, verticesCount + 2 + 12);
    sc_list_add(g.aIndices, verticesCount + 3 + 12);
    sc_list_add(g.aIndices, verticesCount + 0 + 12);

    // DOCS: Left
    sc_list_add(g.aIndices, verticesCount + 0 + 16);
    sc_list_add(g.aIndices, verticesCount + 1 + 16);
    sc_list_add(g.aIndices, verticesCount + 2 + 16);
    sc_list_add(g.aIndices, verticesCount + 2 + 16);
    sc_list_add(g.aIndices, verticesCount + 3 + 16);
    sc_list_add(g.aIndices, verticesCount + 0 + 16);
    // DOCS: Right
    sc_list_add(g.aIndices, verticesCount + 0 + 20);
    sc_list_add(g.aIndices, verticesCount + 1 + 20);
    sc_list_add(g.aIndices, verticesCount + 2 + 20);
    sc_list_add(g.aIndices, verticesCount + 2 + 20);
    sc_list_add(g.aIndices, verticesCount + 3 + 20);
    sc_list_add(g.aIndices, verticesCount + 0 + 20);
}

void
mrql_renderer_primitive_draw_point(v3 pos, v4 color)
{
    i64 pointsCount = sc_list_count(g.aPoints);
    PrimitiveVertex pv0 = { pos, color };
    sc_list_add(g.aPoints, pv0);
    sc_list_add(g.aPointIndices, pointsCount + 0);
}

void
mrql_renderer_primivity_draw_plane(v3 pos, v2 size, v4 color)
{
    v4 aColors[4] = {
        color, color, color, color
    };
    mrql_renderer_primivity_draw_plane_ext(pos, size, aColors);
}

void
mrql_renderer_primitive_draw_cube(v3 pos, v3 size, v4 color)
{
    v4 aColors[] = { color, color, color, color };
    mrql_renderer_primitive_draw_cube_ext(pos, size, aColors);
}

void
mrql_renderer_primitive_plane_flush()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);

    i64 count = sc_list_count(g.aVertices);
    if (!pPipe->IsEnabled || count <= 0)
        return;

    // NOTE: Set Vertices
    u64 verticesSize = count * sizeof(PrimitiveVertex);
    sc_vk_pipeline_set_vertices(g.pScVk, pPipe, g.aVertices, verticesSize);

    // NOTE: Set Indices
    i64 indicesCount = sc_list_count(g.aIndices);
    u64 totalIndexBufferSize = indicesCount * sizeof(u32);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(g.pScVk, g.PassId);
    sc_vk_shared_buffer_set_data(g.pScVk, &pPass->Index, g.aIndices, 0, totalIndexBufferSize);
    sc_vk_get_pipeline(g.pScVk, g.PipeId)->State.IndicesCount = indicesCount;

    sc_list_clear(g.aVertices);
    sc_list_clear(g.aIndices);
}

void
mrql_renderer_primitive_points_flush()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PointPipeId);
    i64 count = sc_list_count(g.aPoints);
    if (!pPipe->IsEnabled || count <= 0)
        return;

    // NOTE: Set Vertices
    u64 verticesSize = count * sizeof(PrimitiveVertex);
    sc_vk_pipeline_set_vertices(g.pScVk, pPipe, g.aPoints, verticesSize);

    // NOTE: Set Indices
    i64 indicesCount = sc_list_count(g.aPointIndices);
    u64 totalIndexBufferSize = indicesCount * sizeof(u32);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(g.pScVk, g.PassId);
    sc_vk_shared_buffer_set_data(g.pScVk, &pPass->Index, g.aPointIndices, 0, totalIndexBufferSize);
    pPipe->State.IndicesCount = indicesCount;

    sc_list_clear(g.aPoints);
    sc_list_clear(g.aPointIndices);
}

void
mrql_renderer_primitive_flush_text()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.TextPipeId);
    i64 count = sc_list_count(g.aTexts);
    if (!pPipe->IsEnabled || count <= 0)
        return;

    // NOTE: Set Vertices
    u64 verticesSize = count * sizeof(PrimitiveTextVertex);
    sc_vk_pipeline_set_vertices(g.pScVk, pPipe, g.aTexts, verticesSize);

    // NOTE: Set Indices
    i64 indicesCount = sc_list_count(g.aTextIndices);
    u64 totalIndexBufferSize = indicesCount * sizeof(u32);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(g.pScVk, g.PassId);
    sc_vk_shared_buffer_set_data(g.pScVk, &pPass->Index, g.aTextIndices, 0, totalIndexBufferSize);
    pPipe->State.IndicesCount = indicesCount;

    sc_list_clear(g.aTexts);
    sc_list_clear(g.aTextIndices);
}

void
mrql_renderer_primitive_flush()
{
    mrql_renderer_primitive_plane_flush();
    mrql_renderer_primitive_points_flush();
    mrql_renderer_primitive_flush_text();
}

void*
mrql_renderer_primitive_get_render_pass()
{
    return sc_vk_get_render_pass(g.pScVk, g.PassId);
}

i64
mrql_renderer_primitive_get_render_pass_id()
{
    return g.PassId;
}

void
mrql_renderer_primitive_draw_text(char* pText, v3 position, v4 color)
{
    ScFont* pFont = (ScFont*)mrql_assety_get_font(0);

    i64 textLength = sc_string_get_length(pText);

    f32 c_width_multiplier = 1.0f / pFont->Size.Width;
    f32 c_height_multiplier = 1.0f / pFont->Size.Height;

    m4 transform = m4_transform(position, v3_new(0, 0, 0), v3_new(1, 1, 1));

    v2 offset = { .X = position.X };
    for (i32 i = 0; i < textLength; ++i)
    {
        i32 charCode = (i32)pText[i];

        ScFontChar fontChar = {};
        if (charCode == ' ')
        {
            v2 spaceMetrics = sc_font_get_space_metrics(*pFont);
            offset.X += spaceMetrics.X;
            continue;
        }
        else
        {
            i32 contains = sc_dict_i_contains(pFont->hCharTable, charCode);
            if (contains)
            {
                fontChar = sc_dict_get_current(pFont->hCharTable);
            }
            else
            {
                sc_log_erro("Unknown font character %lc %d!\n", charCode, charCode);
                continue;
            }
        }

        i32 roundX = (i32)floor(offset.X + fontChar.Xoff + 0.5f);
        i32 roundY = (i32)floor(position.Y - fontChar.Yoff /* - 0.5f */);
        offset.X += fontChar.Xadvance;

        f32 cw = fontChar.X1 - fontChar.X0;
        f32 ch = fontChar.Y1 - fontChar.Y0;

        f32 x0 = roundX;
        f32 x1 = x0 + cw;
        f32 y1 = roundY;
        f32 y0 = roundY - ch;

        v3 p0 = /* 0 0 */ v3_new(x0, y0, position.Z);
        v3 p1 = /* 0 1 */ v3_new(x0, y1, position.Z);
        v3 p2 = /* 1 1 */ v3_new(x1, y1, position.Z);
        v3 p3 = /* 1 0 */ v3_new(x1, y0, position.Z);

        sc_log_info("p0 %v3\n", p0);
        sc_log_info("p1 %v3\n", p1);
        sc_log_info("p2 %v3\n", p2);
        sc_log_info("p3 %v3\n", p3);

        p0 = m4_mul_v3(transform, p0);
        p1 = m4_mul_v3(transform, p1);
        p2 = m4_mul_v3(transform, p2);
        p3 = m4_mul_v3(transform, p3);

        sc_log_info("p0 %v3\n", p0);
        sc_log_info("p1 %v3\n", p1);
        sc_log_info("p2 %v3\n", p2);
        sc_log_info("p3 %v3\n", p3);

        return;
        // DOCS: Uvs
        f32 startX = fontChar.X0 * c_width_multiplier,
            startY = fontChar.Y1 * c_width_multiplier,
            endX = fontChar.X1 * c_height_multiplier,
            endY = fontChar.Y0 * c_height_multiplier;

        v2 uv0 = v2_new(startX, startY);
        v2 uv1 = v2_new(startX, endY);
        v2 uv2 = v2_new(endX, endY);
        v2 uv3 = v2_new(endX, startY);

        PrimitiveTextVertex v0 = {
            .Position = p0,
            .Color = color,
            .Uv = uv0
        };

        PrimitiveTextVertex v1 = {
            .Position = p1,
            .Color = color,
            .Uv = uv1
        };

        PrimitiveTextVertex v2 = {
            .Position = p2,
            .Color = color,
            .Uv = uv2
        };

        PrimitiveTextVertex v3 = {
            .Position = p3,
            .Color = color,
            .Uv = uv3
        };

        i64 indexOffset = sc_list_count(g.aTexts);
        sc_list_add(g.aTexts, v0);
        sc_list_add(g.aTexts, v1);
        sc_list_add(g.aTexts, v2);
        sc_list_add(g.aTexts, v3);

        sc_list_add(g.aTextIndices, 0 + indexOffset);
        sc_list_add(g.aTextIndices, 1 + indexOffset);
        sc_list_add(g.aTextIndices, 2 + indexOffset);
        sc_list_add(g.aTextIndices, 2 + indexOffset);
        sc_list_add(g.aTextIndices, 3 + indexOffset);
        sc_list_add(g.aTextIndices, 0 + indexOffset);

        sc_vk_get_pipeline(g.pScVk, g.TextPipeId)->State.IndicesCount += 6;
    }
}
