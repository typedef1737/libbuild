#include "MrqlRenderer.h"
#include "Engine/Assety/MrqlAssety.h"
#include "Engine/MrqlApplication.h"
#include "Engine/Observy/MrqlObserver.h"
#include "Sc/Math.h"
#include "Sc/Sc.h"
#include "Sc/Window.h"
#include <Sc/Vk.h>
#include <stdio.h>

typedef struct
{
    u64 Offset;
    u64 Size;
    u64 Count;
} MrqlBufferView;

typedef struct
{
    ScVkRenderPass* pRenderPass;
    ScVk* pScVk;
    MrqlRenderer2dConfig Config;

    MrqlBufferView Vertex;
    MrqlBufferView Index;
} MrqlPipeConfig;

typedef struct
{
    ScVkSwapObject Swap;
    u64 DestroyOnFrame;
} MrqlDestroyableSwap;

typedef struct
{
    ScVk* pScVk;

    i32 SyncIndex;

    // ScVkRenderPass FinalPass;
    // ScVkPipeline FinalPipe;

    VkSampler DefaultLinearSampler;

    struct
    {
        i8 IsResizePending;
        f64 LastResizeTime;
    } ResizeMemory;
} MrqlRenderer2D;

static MrqlRenderer2D g = {};

extern ScVkRenderPass mrql_renderer_2d_create_render_pass(ScVk* pScVk, v2 windowSize);
static i32 _resize(ScWindowResizeEvent* pEvent);

/*


 mrql_renderer_add_init({.Init = primitive_init});


*/

void
mrql_renderer_init(MrqlRendererConfig cfg)
{
    g.pScVk = cfg.pScVk;

    g.SyncIndex = -1;
    g.ResizeMemory.IsResizePending = 0;

    // 2d part conf
    MrqlRenderer2dConfig mrqlCfg = {
        .MaxRectsCount = 20000,
        .pScVk = cfg.pScVk,
    };
    // todo: continue here
    mqrl_renderer_2d_init(mrqlCfg);

    mrql_renderer_primitive_init((MrqlRendererPrimitiveConfig) { .pScVk = cfg.pScVk, .VerticesCount = 100 });

    // i64 terrainWidth = 2560;
    // i64 terrainHeight = 2117;
    // MrqlRendererTerrainConfig terrainCfg = {
    //     .pScVk = cfg.pScVk,
    //     .VerticesCount = terrainWidth * terrainHeight
    // };
    // mrql_renderer_terrain_init(terrainCfg);

    g.DefaultLinearSampler = sc_vk_sampler_create(g.pScVk, VK_FILTER_LINEAR, VK_FILTER_LINEAR, 1);
    printf("Default Sampler: %p\n", g.DefaultLinearSampler);

    sc_vk_uniform_buffer_allocate(cfg.pScVk);

    Sc2dTexture image2d = *(Sc2dTexture*)mrql_assety_load_texture("Resources/Images/3D.png");
    Sc2dTexture image3d = *(Sc2dTexture*)mrql_assety_load_texture("Resources/Images/3D.png");
    Sc2dTexture images[] = { image2d, image3d };
    sc_vk_set_passes_images(g.pScVk, images, ScArrayCount(images));

    // mrql_renderer_terrain_set(v2_new(terrainWidth, terrainHeight));

    v2 winSize = g.pScVk->WindowSize;
    m4 viewProjection = m4_orthographic(0, winSize.X, 0, winSize.Y, 0.1, 100);
    mrql_renderer_2d_set_camera(viewProjection);

    mrql_application_add_event_sub("Rendy", _resize, ScEventType_WindowResized);
}

void
mrql_renderer_deinit()
{
    vkDeviceWaitIdle(g.pScVk->Device);
    sc_vk_uniform_buffer_free(g.pScVk);
    sc_vk_sampler_destroy(g.pScVk, g.DefaultLinearSampler);

    // mrql_renderer_terrain_deinit();
    mrql_renderer_primitive_deinit();
    mqrl_renderer_2d_deinit();
}

void
mrql_renderer_request_resize()
{
    g.ResizeMemory.IsResizePending = 1;
    g.ResizeMemory.LastResizeTime = mrql_application_get_uptime();
}

i32
mrql_renderer_resize(v2 newSize)
{
    f64 uptime = mrql_application_get_uptime();
    // note(king): 1 second is enough to not
    // crash on fast resize operations.
    f64 diff = uptime - g.ResizeMemory.LastResizeTime;
    if (uptime - g.ResizeMemory.LastResizeTime < 1.0)
        return 0;

    sc_log_warn("mrql_renderer_resize!\n");

    ScVk* pScVk = g.pScVk;

    // note(king): re-create all sync primitives
    vkDeviceWaitIdle(pScVk->Device);

    mrql_renderer_deinit();

    sc_log_erro("[0] Count : %d \n", sc_list_count(pScVk->aImageAvailableSemaphores));
    for (i32 i = 0; i < sc_list_count(pScVk->aImageAvailableSemaphores); ++i)
    {
        vkDestroySemaphore(pScVk->Device, pScVk->aImageAvailableSemaphores[i], pScVk->pAllocator);
        vkDestroySemaphore(pScVk->Device, pScVk->aRenderFinishedSemaphores[i], pScVk->pAllocator);
        vkDestroyFence(pScVk->Device, pScVk->aFrameFences[i], pScVk->pAllocator);
        pScVk->aImageAvailableSemaphores[i] = VK_NULL_HANDLE;
        pScVk->aRenderFinishedSemaphores[i] = VK_NULL_HANDLE;
        pScVk->aFrameFences[i] = VK_NULL_HANDLE;
    }

    vkDeviceWaitIdle(pScVk->Device);

    VkSurfaceCapabilitiesKHR caps = sc_vk_get_surface_capabilities(pScVk);
    VkExtent2D newResolution = caps.currentExtent;
    if (caps.currentExtent.width == SC_U32_MAX)
    {
        newResolution = (VkExtent2D) {
            .width = ScMinMax(newSize.X, caps.minImageExtent.width, caps.maxImageExtent.width),
            .height = ScMinMax(newSize.Y, caps.minImageExtent.height, caps.maxImageExtent.height)
        };
    }
    v2 realNewSize = v2_new(newResolution.width, newResolution.height);
    pScVk->WindowSize = realNewSize;

    ScVkSwapObject oldSwap = pScVk->Swap;
    ScVkSwapchainConfig cfg = {
        .IsVsync = 1,
        .Resolution = newResolution,
        .SurfaceFormat = pScVk->Swap.SurfaceFormat,
        .PrevSwapchain = pScVk->Swap.Swapchain
    };
    pScVk->Swap = sc_vk_swapchain_new(pScVk, cfg);

    sc_vk_swapchain_destroy(pScVk, oldSwap);

    // note(king): re-create all sync primitives
    sc_log_erro("[1] Count : %d \n", sc_list_count(pScVk->aImageAvailableSemaphores));
    for (i32 i = 0; i < sc_list_count(pScVk->aImageAvailableSemaphores); ++i)
    {
        pScVk->aImageAvailableSemaphores[i] = sc_vk_sync_semaphore_new(pScVk, 0);
        pScVk->aRenderFinishedSemaphores[i] = sc_vk_sync_semaphore_new(pScVk, 0);
        pScVk->aFrameFences[i] = sc_vk_fence_new(pScVk, VK_FENCE_CREATE_SIGNALED_BIT);
    }

    mrql_renderer_init((MrqlRendererConfig) { pScVk });
    mrql_observer_update_current_camera(realNewSize);

    return 1;
}

i32
mrql_renderer_is_resize_pending()
{
    return g.ResizeMemory.IsResizePending;
}

void
mrql_renderer_draw_new(ScVk* pScVk)
{
    u32 s_image_index = 0;
    static u64 noTime = SC_U64_MAX;

    if (g.ResizeMemory.IsResizePending)
    {
        sc_log_warn("Resize is pending not rendering anything!\n");
        return;
    }

    ScVkRenderPass* pFinalPass = sc_vk_get_render_pass(pScVk, pScVk->FinalPassId);
    g.SyncIndex = (g.SyncIndex + 1) % sc_list_count(pFinalPass->aFramebuffers);
    ScVkPipeline* pFinalPipe = sc_vk_get_pipeline(pScVk, pScVk->FinalPipeId);

    // todo: Put inside finalPass.
    VkSemaphore* pAvailableSemaphore = &pScVk->aImageAvailableSemaphores[g.SyncIndex];
    VkSemaphore* pFinishedSemaphore = &pScVk->aRenderFinishedSemaphores[g.SyncIndex];
    VkFence* pFrameFence = &pScVk->aFrameFences[g.SyncIndex];

    // DOCS: Ждем завершения предыдущего кадра
    vkWaitForFences(pScVk->Device, 1, pFrameFence, VK_TRUE, noTime);
    vkResetFences(pScVk->Device, 1, pFrameFence);

    // DOCS: Получаем следующее изображение от swapchain
    VkResult accuireNextImageResult = vkAcquireNextImageKHR(pScVk->Device, pScVk->Swap.Swapchain, noTime, *pAvailableSemaphore, VK_NULL_HANDLE, &s_image_index);

    if (accuireNextImageResult == VK_ERROR_OUT_OF_DATE_KHR || accuireNextImageResult == VK_SUBOPTIMAL_KHR)
    {
        mrql_renderer_request_resize();
        sc_log_warn("AcquireNextImage out of date or suboptimal!\n");
        return;
    }
    else if (accuireNextImageResult != VK_SUCCESS)
    {
        printf("Failed to acquire next image: %d\n", accuireNextImageResult);
        return;
    }

    // DOCS: Начинаем запись командного буфера
    VkCommandBuffer drawCmd = pScVk->Cmd.aList[s_image_index];
    vkResetCommandBuffer(drawCmd, 0);

    VkCommandBufferBeginInfo bi = {
        .sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT
    };

    VkResult beginResult = vkBeginCommandBuffer(drawCmd, &bi);
    if (beginResult != VK_SUCCESS)
    {
        sc_log_erro("Failed to begin command buffer: %d\n", beginResult);
        return;
    }

    if (1)
    {
        ScVkRenderPass* pRenderPass2d = (ScVkRenderPass*)mrql_renderer_2d_get_render_pass();
        // ScVkRenderPass* pRenderPassTerrain = (ScVkRenderPass*)mrql_renderer_terrain_get_render_pass();
        ScVkRenderPass* pRenderPassPrimitive = (ScVkRenderPass*)mrql_renderer_primitive_get_render_pass();

        // sc_vk_render_pass_draw_v2(pScVk, pRenderPassTerrain, drawCmd);
        sc_vk_render_pass_draw_v2(pScVk, pRenderPass2d, drawCmd);
        sc_vk_render_pass_draw_v2(pScVk, pRenderPassPrimitive, drawCmd);

        // Sc2dTexture txtTerrain = sc_vk_render_pass_get_current_image_as_texture(pRenderPassTerrain, g.DefaultLinearSampler);
        Sc2dTexture txtPrimitive = sc_vk_render_pass_get_current_image_as_texture(pRenderPassPrimitive, g.DefaultLinearSampler);
        Sc2dTexture txt2d = sc_vk_render_pass_get_current_image_as_texture(pRenderPass2d, g.DefaultLinearSampler);

        Sc2dTexture aImages[] = {
            txtPrimitive, txt2d
        };
        sc_vk_set_passes_images(g.pScVk, aImages, ScArrayCount(aImages));
    }

    VkClearValue clearValue = {
        .color = { 0.01f, 0.01f, 0.05f, 1.0f }
    };

    VkRenderPassBeginInfo renderPassBeginInfo = {
        .sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
        .renderPass = pFinalPass->Handle,
        .framebuffer = pFinalPass->aFramebuffers[s_image_index].Framebuffer,
        .renderArea = {
            .offset = { 0, 0 },
            .extent = pScVk->Swap.Resolution },
        .clearValueCount = 1,
        .pClearValues = &clearValue
    };

    vkCmdBeginRenderPass(drawCmd, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);

    VkViewport viewport = {
        .x = 0,
        .y = 0,
        .width = (float)pScVk->Swap.Resolution.width,
        .height = (float)pScVk->Swap.Resolution.height,
        .minDepth = 0,
        .maxDepth = 1
    };
    vkCmdSetViewport(drawCmd, 0, 1, &viewport);

    VkRect2D scissor = {
        .offset = { 0, 0 },
        .extent = pScVk->Swap.Resolution
    };
    vkCmdSetScissor(drawCmd, 0, 1, &scissor);

    vkCmdBindPipeline(drawCmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pFinalPipe->Handle);
    vkCmdBindDescriptorSets(drawCmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pFinalPipe->Layout, 0, 1, &pFinalPipe->ShaderBridge.Set, 0, NULL);
    vkCmdDraw(drawCmd, 6, 1, 0, 0);

    vkCmdEndRenderPass(drawCmd);

    VkResult vkEndCmdBufferResult = vkEndCommandBuffer(drawCmd);
    if (vkEndCmdBufferResult != VK_SUCCESS)
    {
        sc_log_erro("Failed to end command buffer: %d\n", vkEndCmdBufferResult);
        return;
    }

    // DOCS: Отправляем команды в очередь
    VkPipelineStageFlags pipelineStageFlag = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkPipelineStageFlags aWaitStages[] = { VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT };

    VkSubmitInfo cmdSubmitInfo = {
        .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = pAvailableSemaphore,
        .pWaitDstStageMask = &pipelineStageFlag,
        .commandBufferCount = 1,
        .pCommandBuffers = &drawCmd,
        .signalSemaphoreCount = 1,
        .pSignalSemaphores = pFinishedSemaphore
    };

    VkResult queueSubmitResult = vkQueueSubmit(pScVk->GraphicsQueue, 1, &cmdSubmitInfo, *pFrameFence);
    if (queueSubmitResult != VK_SUCCESS)
    {
        sc_log_erro("Failed to submit queue: %d\n", queueSubmitResult);
        return;
    }

    // DOCS: Представляем изображение
    VkPresentInfoKHR presentInfoKhr = {
        .sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
        .waitSemaphoreCount = 1,
        .pWaitSemaphores = pFinishedSemaphore,
        .swapchainCount = 1,
        .pSwapchains = &pScVk->Swap.Swapchain,
        .pImageIndices = &s_image_index
    };

    VkResult queuePresentKhr = vkQueuePresentKHR(pScVk->PresentationQueue, &presentInfoKhr);
    if (queuePresentKhr == VK_ERROR_OUT_OF_DATE_KHR || queuePresentKhr == VK_SUBOPTIMAL_KHR)
    {
        sc_log_warn("QueuePresent out of date or suboptimal!\n");
        g.ResizeMemory.IsResizePending = 1;
        return;
    }
    else if (queuePresentKhr != VK_SUCCESS)
    {
        sc_log_erro("Failed to present queue: %d\n", queuePresentKhr);
        return;
    }
}

i32
_resize(ScWindowResizeEvent* pEvent)
{
    v2 newSize = mrql_application_get_window_size();
    newSize = v2_new(pEvent->Width, pEvent->Height);
    while (!mrql_renderer_resize(newSize))
    {
        const i32 ms = 500;
        sc_log_warn("Sleep for %d ms\n", ms);
        sc_sleep_ms(ms);
    }
    g.ResizeMemory.IsResizePending = 0;
    return 1;
}
