#include "Engine/MrqlApplication.h"
#include "Engine/Observy/MrqlObserver.h"
#include "Engine/Rendy/MrqlRenderer.h"
#include "Sc/Sc.h"
#include "Sc/Types.h"

typedef struct
{
    v3 Position;
    v4 Color;
} TerrainVertex;

typedef struct __attribute__((aligned(16)))
{
    f32 HeightScale; // масштаб высот (например 50.0)
    f32 Temp;
    v2 TerrainSize; // размер карты в мире
} TerrainConfig;

static struct
{
    ScVk* pScVk;
    i32 PassId;
    i32 PipeId;

    TerrainVertex* aVertices;
    u32* aIndices;
} g = {};

void terrain_create_pass();
void terrain_create_pipe(MrqlRendererTerrainConfig cfg);

void
mrql_renderer_terrain_init(MrqlRendererTerrainConfig cfg)
{
    g.pScVk = cfg.pScVk;

    terrain_create_pass();
    cfg.PolygonMode = VK_POLYGON_MODE_FILL;
    terrain_create_pipe(cfg);
    //cfg.PolygonMode = VK_POLYGON_MODE_LINE;
    //terrain_create_pipe(cfg);

    MrqlObserverSubscriber sub = {
        .pName = "MrqlRenderer-Terrain",
        .CameraUpdate = mrql_renderer_terrain_set_camera
    };
    mrql_observer_add_camera_sub(sub);
}

void
mrql_renderer_terrain_set(v2 size)
{
    i32 width = (i32)size.Width;
    i32 height = (i32)size.Height;

    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);
    if (!pPipe)
    {
        return;
    }

    const f32 c_tile_size = 10;
    TerrainConfig terrainCfg = {
        .HeightScale = 100 * c_tile_size,
        .TerrainSize = { width * c_tile_size, height * c_tile_size }
    };
    ScVkUniform* pTerrainConfig = sc_vk_pipeline_get_uniform(pPipe, "u_TerrainConfig");
    if (!sc_vk_uniform_set(g.pScVk, pTerrainConfig, &terrainCfg, 0, sizeof(TerrainConfig)))
    {
        sc_log_warn("Can't setup u_Visible uniform!!!\n");
        // sc_assert_break();
    }

    i64 verticesCount = width * height;
    g.aVertices = sc_list_reserve(g.aVertices, verticesCount);

    for (int z = 0; z < height; z++)
    {
        for (int x = 0; x < width; x++)
        {
            TerrainVertex vertex = {
                .Position = { x * c_tile_size, 0.0f, z * c_tile_size },
                .Color = { 0.3f, 0.8f, 0.3f, 1.0f }
            };
            sc_list_add(g.aVertices, vertex);
        }
    }
    sc_list_header(g.aVertices)->Count = verticesCount;

    u32* aIndices = NULL;
    for (i32 z = 0; z < (height - 1); ++z)
    {
        for (i32 x = 0; x < (width - 1); ++x)
        {
            u32 i0 = x + z * width;
            u32 i1 = i0 + 1;
            u32 i2 = i0 + width;
            u32 i3 = i2 + 1;

            sc_list_add(aIndices, i0);
            sc_list_add(aIndices, i2);
            sc_list_add(aIndices, i3);
            sc_list_add(aIndices, i3);
            sc_list_add(aIndices, i1);
            sc_list_add(aIndices, i0);
        }
    }

    g.aIndices = aIndices;
}

void
terrain_create_pass()
{
    // create render pass
    // register render pass
    ScVk* pScVk = g.pScVk;
    v2 windowSize = mrql_application_get_window_size();

    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
    VkFormat depthAttachmentFormat = VK_FORMAT_D32_SFLOAT;

    VkAttachmentDescription colorDescr = {
        .format = pScVk->Swap.SurfaceFormat.format,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
    };
    ScVkAttachment color = {
        .Type = ScVkAttachmentType_Color,
        .Description = colorDescr,
        .Reference = { .attachment = 0, .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL }
    };

    VkAttachmentDescription depthDescr = {
        .format = depthAttachmentFormat,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL
    };
    ScVkAttachment depth = {
        .Type = ScVkAttachmentType_Depth,
        .Description = depthDescr,
        .Reference = { .attachment = 1, .layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL }
    };

    ScVkAttachment aAttachments[] = {
        color, depth
    };

    VkSubpassDependency subpassDependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .srcAccessMask = 0,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
        .dependencyFlags = 0,
    };

    ScVkRenderPassConfig renderPassCfg = {
        .aAttachments = aAttachments,
        .Dependency = subpassDependency,
        .Resolution = windowSize,
        .AttachmentsCount = 2,
        .BufferingType = ScVkRenderPassBufferingType_Single
    };

    // printf("Render pass samples count: %s\n", sc_vk_sample_count_to_string(renderPass.Samples));

    g.PassId = sc_vk_render_pass_new(pScVk, renderPassCfg);
}

void
mrql_renderer_terrain_deinit()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);
    sc_vk_pipeline_destroy(g.pScVk, *pPipe);
    sc_vk_render_pass_destroy(g.pScVk, g.PassId);
    sc_list_remove_index(g.pScVk->aPipelines, g.PipeId);
    sc_list_remove_index(g.pScVk->aRenderPasses, g.PassId);
}

void
terrain_create_pipe(MrqlRendererTerrainConfig cfg)
{
    ScVk* pScVk = g.pScVk;
    i64 renderPassId = g.PassId;

    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = sizeof(m4) },
        [1] = (ScVkDescriptorConfig) { .pName = "u_TerrainConfig", .Type = ScVkDescriptorType_Uniform, .Binding = 1, .Count = 1, .Size = sizeof(TerrainConfig) },
        [2] = (ScVkDescriptorConfig) { .pName = "t_Heightmap", .Type = ScVkDescriptorType_Image, .Binding = 2, .Count = 1 },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/Terrain.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = ScArrayCount(aDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/Terrain.frag",
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig tesselationControlCfg = {
        .Type = ScVkStageType_Tesselation_Control,
        .pShaderPath = "Resources/Shaders/Pipes/Terrain.tesc",
        .PatchControlPoints = 3,
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig tesselationEvaluationCfg = {
        .Type = ScVkStageType_Tesselation_Evaluation,
        .pShaderPath = "Resources/Shaders/Pipes/Terrain.tese",
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg, tesselationControlCfg, tesselationEvaluationCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(TerrainVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(TerrainVertex, Color),
        },
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 1,
        .Topology = ScVkTopologyType_PatchList,
        .RenderPassId = renderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = cfg.PolygonMode,
        .Stride = sizeof(TerrainVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = cfg.VerticesCount,
        .IndicesCount = 6 * cfg.VerticesCount });
    sc_vk_pipeline_config_print(pScVk, pipeCfg);

    g.PipeId = sc_vk_pipeline_new(pScVk, pipeCfg);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, g.PassId);
    sc_vk_render_pass_create_buffers(pScVk, pPass->Id);
}

void
mrql_renderer_terrain_draw()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);

    if (!pPipe->IsEnabled || !g.aVertices)
        return;

    i64 count = sc_list_count(g.aVertices);
    if (count <= 0)
        return;

    u64 verticesSize = count * sizeof(TerrainVertex);
    sc_vk_pipeline_set_vertices(g.pScVk, pPipe, g.aVertices, verticesSize);

    i64 indicesCount = sc_list_count(g.aIndices);
    u64 totalIndexBufferSize = indicesCount * sizeof(u32);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(g.pScVk, g.PassId);
    sc_vk_shared_buffer_set_data(g.pScVk, &pPass->Index, g.aIndices, 0, totalIndexBufferSize);
    sc_vk_get_pipeline(g.pScVk, g.PipeId)->State.IndicesCount = indicesCount;
}

void*
mrql_renderer_terrain_get_render_pass()
{
    return (void*)sc_vk_get_render_pass(g.pScVk, g.PassId);
}

i64
mrql_renderer_terrain_get_render_pass_id()
{
    return g.PassId;
}

void
mrql_renderer_terrain_set_camera(m4 viewProjection)
{
    sc_vk_pipeline_set_uniform(g.pScVk, g.PipeId, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
}

// todo: написать функцию которая сетапит текстуры
// я всегда забываю поменять dstBinding.
void
mrql_renderer_terrain_set_height_map(Sc2dTexture heightMap)
{
    ScVk* pScVk = g.pScVk;
    ScVkPipeline* pPipe = sc_vk_get_pipeline(pScVk, g.PipeId);

    VkDescriptorImageInfo imageInfo2d = {
        .sampler = heightMap.Sampler,
        .imageView = heightMap.View,
        .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
    };

    VkWriteDescriptorSet aWriteSets[] = {
        [0] = {
            .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
            .dstSet = pPipe->ShaderBridge.Set,
            .dstBinding = 2,
            .dstArrayElement = 0,
            .descriptorCount = 1,
            .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
            .pImageInfo = &imageInfo2d,
        }
    };

    vkUpdateDescriptorSets(pScVk->Device, ScArrayCount(aWriteSets), aWriteSets, 0, NULL);
}

void
mrql_renderer_terrain_flush()
{
    ScVk* pScVk = g.pScVk;
    ScVkPipeline* pPipe = sc_vk_get_pipeline(pScVk, g.PipeId);
    pPipe->State.IndicesCount = sc_list_count(g.aIndices);
}
