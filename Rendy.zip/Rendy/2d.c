#include "Engine/Assety/MrqlAssety.h"
#include "MrqlRenderer.h"
#include "Sc/Font.h"
#include "Sc/Sc.h"
#include <Sc/Vk.h>
#include <math.h>
#include <stdlib.h>

typedef struct
{
    i32 RenderPassId;
    ScVk* pScVk;
    MrqlRenderer2dConfig Config;
} MrqlPipeConfig;

typedef struct
{
    v3 Position; // 12 bytes
    v4 Color;    // 16 bytes
} MrqlUiRectVertex;

typedef struct
{
    v3 Position; // 12 bytes
    v4 Color;    // 16 bytes
    v2 Uv;
    i32 TextureIndex;
    i32 ViewportIndex;
} MrqlUiVertex;

typedef struct
{
    v3 Position; // 12 bytes
    v4 Color;    // 16 bytes
    v2 Uv;
    i32 Index;
} MrqlUiFontVertex;

typedef struct
{
    v2 Min;
    v2 Max;
} VisibleViewport;

typedef struct
{
    VisibleViewport Viewport;
    MrqlUiVertex* aVertices;
} ViewGroup;

typedef struct
{
    VisibleViewport Viewport;
    MrqlUiRectVertex* aVertices;
} RectViewGroup;

typedef struct
{
    i32 IsScissorsDebug;
} SettingsUbo;

typedef struct
{
    ScVk* pScVk;

    i32 RenderPass2dId;

    struct // DOCS: Ui struct
    {
        i32 Id;
        ViewGroup* aGroups;
        i64* aUsedTextureIds;
        struct
        {
            i64 Id;
        } DefaultFont;
    } Ui;

    struct
    {
        i32 Id;
        RectViewGroup* aGroups;
    } Rect;

    struct
    {
        i32 Id;
        ViewGroup* aGroups;
        i64* aUsedTextureIds;
    } Image;

} MrqlRenderer2D;

static MrqlRenderer2D g = {};

#define GetViewGroup(aGroups)                                          \
    ({                                                                 \
        i32 ind = sc_list_count(aGroups) - 1;                          \
        if (ind < 0)                                                   \
        {                                                              \
            sc_log_warn("Wtf ind for aGroups is less then zero!!!\n"); \
            sc_assert_break();                                         \
        }                                                              \
        &aGroups[ind];                                                 \
    })

i32 mrql_renderer_2d_create_render_pass(ScVk* pScVk, v2 windowSize);
i64 mrql_renderer_2d_ui_init(MrqlPipeConfig cfg);
i64 mrql_renderer_2d_ui_rect_init(MrqlPipeConfig cfg);
i64 mrql_renderer_2d_ui_image_init(MrqlPipeConfig cfg);
void mrql_renderer_2d_ui_font_init(MrqlPipeConfig cfg);
void mrql_renderer_2d_set_viewport(v2 min, v2 max);

void
mqrl_renderer_2d_init(MrqlRenderer2dConfig cfg)
{
    v2 windowSize = cfg.pScVk->WindowSize; // get from cfg
    ScVk* pScVk = cfg.pScVk;               // get from "graphics_layer"
    g.pScVk = pScVk;

    mrql_renderer_2d_set_viewport((v2) {}, windowSize);

    u64 rectSize = cfg.MaxRectsCount * 4 * sizeof(MrqlUiRectVertex);
    u64 totalVertexBufferSize = rectSize;

    sc_log_warn("Vertex size: %d\n", rectSize);

    g.RenderPass2dId = mrql_renderer_2d_create_render_pass(pScVk, windowSize);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, g.RenderPass2dId);

    MrqlPipeConfig mrqlUiRectCfg = {
        .RenderPassId = pPass->Id,
        .pScVk = pScVk,
        .Config = cfg
    };

    if (cfg.IsRectEnabled)
    {
        g.Rect.Id = mrql_renderer_2d_ui_rect_init(mrqlUiRectCfg);
        sc_vk_get_pipeline(g.pScVk, g.Rect.Id)->IsEnabled = 1;
    }
    else
    {
        g.Rect.Id = -1;
    }

    if (cfg.IsUiEnabled)
    {
        g.Ui.Id = mrql_renderer_2d_ui_init(mrqlUiRectCfg);
        sc_vk_get_pipeline(g.pScVk, g.Ui.Id)->IsEnabled = 1;
    }
    else
    {
        g.Ui.Id = -1;
    }

    if (cfg.IsImageEnabled)
    {
        g.Image.Id = mrql_renderer_2d_ui_image_init(mrqlUiRectCfg);
        sc_vk_get_pipeline(g.pScVk, g.Image.Id)->IsEnabled = 1;
    }
    else
    {
        g.Image.Id = -1;
    }

    sc_vk_render_pass_create_buffers(pScVk, pPass->Id);

    u64 totalIndicesCount = cfg.MaxRectsCount * 6;
    u64 totalIndexBufferSize = totalIndicesCount * sizeof(u32);
    sc_log_warn("Index size: %d\n", totalIndexBufferSize);
    u32* aIndices = NULL;
    sc_list_reserve(aIndices, totalIndicesCount);
    for (i32 ind = 0, i = 0; ind < totalIndicesCount; ind += 6, i += 4)
    {
        aIndices[ind] = i;
        aIndices[ind + 1] = i + 1;
        aIndices[ind + 2] = i + 2;
        aIndices[ind + 3] = i + 2;
        aIndices[ind + 4] = i + 3;
        aIndices[ind + 5] = i;
    }
    sc_vk_shared_buffer_set_data(g.pScVk, &pPass->Index, aIndices, 0, totalIndexBufferSize);

    sc_list_free(aIndices);

    g.Ui.DefaultFont.Id = mrql_assety_load_font_id("Resources/Fonts/MartianMono-sWdRg.ttf", 32, 0, 127);
}

void
mrql_renderer_2d_set_camera(m4 viewProjection)
{
    sc_vk_pipeline_set_uniform(g.pScVk, g.Ui.Id, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
    sc_vk_pipeline_set_uniform(g.pScVk, g.Image.Id, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
    sc_vk_pipeline_set_uniform(g.pScVk, g.Rect.Id, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
}

void
mqrl_renderer_2d_deinit()
{
    ScVkPipeline* pRectPipe = sc_vk_get_pipeline(g.pScVk, g.Rect.Id);
    ScVkPipeline* pImagePipe = sc_vk_get_pipeline(g.pScVk, g.Image.Id);
    ScVkPipeline* pUiPipe = sc_vk_get_pipeline(g.pScVk, g.Ui.Id);
    sc_vk_pipeline_destroy(g.pScVk, *pRectPipe);
    sc_vk_pipeline_destroy(g.pScVk, *pImagePipe);
    sc_vk_pipeline_destroy(g.pScVk, *pUiPipe);
    sc_vk_render_pass_destroy(g.pScVk, g.RenderPass2dId);
    sc_list_remove_index(g.pScVk->aPipelines, g.Rect.Id);
    sc_list_remove_index(g.pScVk->aPipelines, g.Image.Id);
    sc_list_remove_index(g.pScVk->aPipelines, g.Ui.Id);
    sc_list_remove_index(g.pScVk->aRenderPasses, g.RenderPass2dId);
}

i64
mrql_renderer_2d_get_render_pass_id()
{
    return g.RenderPass2dId;
}

void*
mrql_renderer_2d_get_render_pass()
{
    return (void*)sc_vk_get_render_pass(g.pScVk, g.RenderPass2dId);
}

i32
mrql_renderer_2d_create_render_pass(ScVk* pScVk, v2 windowSize)
{
    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
    VkFormat depthAttachmentFormat = VK_FORMAT_D32_SFLOAT;

    VkAttachmentDescription colorDescr = {
        .format = pScVk->Swap.SurfaceFormat.format,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
    };
    ScVkAttachment color = {
        .Type = ScVkAttachmentType_Color,
        .Description = colorDescr,
        .Reference = { .attachment = 0, .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL }
    };

    VkAttachmentDescription depthDescr = {
        .format = depthAttachmentFormat,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL
    };
    ScVkAttachment depth = {
        .Type = ScVkAttachmentType_Depth,
        .Description = depthDescr,
        .Reference = { .attachment = 1, .layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL }
    };

    ScVkAttachment aAttachments[] = {
        color, depth
    };

    VkSubpassDependency subpassDependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .srcAccessMask = 0,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
        .dependencyFlags = 0,
    };

    ScVkRenderPassConfig renderPassCfg = {
        .aAttachments = aAttachments,
        .Dependency = subpassDependency,
        .Resolution = windowSize,
        .AttachmentsCount = 2,
        .BufferingType = ScVkRenderPassBufferingType_Single
    };

    i32 renderPassId = sc_vk_render_pass_new(pScVk, renderPassCfg);
    // printf("Render pass samples count: %s\n", sc_vk_sample_count_to_string(renderPass.Samples));

    return renderPassId;
}

i64
mrql_renderer_2d_ui_image_init(MrqlPipeConfig cfg)
{
    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = 64 },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/UiImagePipe.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = 1,
        .PipelineIndex = sc_vk_get_next_pipeline_index(g.pScVk)
    };

    ScVkDescriptorConfig aFragDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_Settings",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 1,
            .Size = sizeof(SettingsUbo),
            .Count = 1,
        },
        [1] = (ScVkDescriptorConfig) {
            .pName = "u_Visible",
            .Type = ScVkDescriptorType_Uniform,
            .Size = sizeof(VisibleViewport),
            .Binding = 2,
            .Count = 10,
        },
        [2] = (ScVkDescriptorConfig) {
            .pName = "u_Textures",
            .Type = ScVkDescriptorType_Image,
            .Binding = 3,
            .Count = 10,
        }
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/UiImagePipe.frag",
        .aDescriptors = aFragDescriptors,
        .DescriptorsCount = ScArrayCount(aFragDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(g.pScVk)
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiVertex, Color),
        },
        [2] = {
            .Format = VK_FORMAT_R32G32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiVertex, Uv),
        },
        [3] = {
            .Format = VK_FORMAT_R32_SINT,
            .Offset = ScOffsetOf(MrqlUiVertex, TextureIndex),
        },
        [4] = {
            .Format = VK_FORMAT_R32_SINT,
            .Offset = ScOffsetOf(MrqlUiVertex, ViewportIndex),
        }
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 0,
        .RenderPassId = cfg.RenderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .Stride = sizeof(MrqlUiVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = 4 * cfg.Config.MaxRectsCount,
        .IndicesCount = 6 * cfg.Config.MaxRectsCount });
    sc_vk_pipeline_config_print(cfg.pScVk, pipeCfg);

    return sc_vk_pipeline_new(cfg.pScVk, pipeCfg);
}

i64
mrql_renderer_2d_ui_init(MrqlPipeConfig cfg)
{
    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = 64 },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/UiFontPipe.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = 1,
        .PipelineIndex = sc_vk_get_next_pipeline_index(g.pScVk)
    };

    ScVkDescriptorConfig aFragDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_Settings",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 1,
            .Size = sizeof(SettingsUbo),
            .Count = 1,
        },
        [1] = (ScVkDescriptorConfig) {
            .pName = "u_Visible",
            .Type = ScVkDescriptorType_Uniform,
            .Size = sizeof(VisibleViewport),
            .Binding = 2,
            .Count = 10,
        },
        [2] = (ScVkDescriptorConfig) {
            .pName = "u_Textures",
            .Type = ScVkDescriptorType_Image,
            .Binding = 3,
            .Count = 10,
        }
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/UiFontPipe.frag",
        .aDescriptors = aFragDescriptors,
        .DescriptorsCount = ScArrayCount(aFragDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(g.pScVk)
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiVertex, Color),
        },
        [2] = {
            .Format = VK_FORMAT_R32G32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiVertex, Uv),
        },
        [3] = {
            .Format = VK_FORMAT_R32_SINT,
            .Offset = ScOffsetOf(MrqlUiVertex, TextureIndex),
        },
        [4] = {
            .Format = VK_FORMAT_R32_SINT,
            .Offset = ScOffsetOf(MrqlUiVertex, ViewportIndex),
        }
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 0,
        .RenderPassId = cfg.RenderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .Stride = sizeof(MrqlUiVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = 4 * cfg.Config.MaxRectsCount,
        .IndicesCount = 6 * cfg.Config.MaxRectsCount });
    sc_vk_pipeline_config_print(cfg.pScVk, pipeCfg);

    return sc_vk_pipeline_new(cfg.pScVk, pipeCfg);
}

i64
mrql_renderer_2d_ui_rect_init(MrqlPipeConfig cfg)
{
    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = 64 },
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/UiRectPipe.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = 1,
        .PipelineIndex = sc_vk_get_next_pipeline_index(g.pScVk)
    };

    ScVkDescriptorConfig aFragDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_Visible",
            .Type = ScVkDescriptorType_Uniform,
            .Size = sizeof(VisibleViewport),
            .Binding = 1,
            .Count = 10,
        }
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/UiRectPipe.frag",
        .aDescriptors = aFragDescriptors,
        .DescriptorsCount = ScArrayCount(aFragDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(g.pScVk)
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiRectVertex, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(MrqlUiRectVertex, Color),
        },
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 1,
        .RenderPassId = cfg.RenderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .PolygonMode = VK_POLYGON_MODE_FILL,
        .Stride = sizeof(MrqlUiRectVertex),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = 4 * cfg.Config.MaxRectsCount,
        .IndicesCount = 6 * cfg.Config.MaxRectsCount });
    sc_vk_pipeline_config_print(cfg.pScVk, pipeCfg);

    return sc_vk_pipeline_new(cfg.pScVk, pipeCfg);
}

void
mrql_renderer_2d_set_viewport(v2 min, v2 max)
{
    ViewGroup group = {
        .Viewport = {
            .Min = min,
            .Max = max,
        }
    };
    sc_list_add(g.Ui.aGroups, group);
    sc_list_add(g.Image.aGroups, group);

    RectViewGroup rectViewGroup = {
        .Viewport = {
            .Min = min,
            .Max = max,
        }
    };
    sc_list_add(g.Rect.aGroups, rectViewGroup);
}

static RectViewGroup*
get_rect_view_group(void* aGroups)
{
    i32 ind = sc_list_count(aGroups) - 1;
    if (ind < 0)
    {
        sc_log_warn("Wtf ind for aGroups is less then zero!!!\n");
        sc_assert_break();
    }
    return &aGroups[ind];
}

void
mrql_renderer_2d_draw_rect(v3 p, v2 s, v4 color)
{
    MrqlUiRectVertex v0 = {
        .Position = p,
        .Color = color,
    };
    MrqlUiRectVertex v1 = {
        .Position = { p.X, p.Y - s.Y, p.Z },
        .Color = color,
    };
    MrqlUiRectVertex v2 = {
        .Position = { p.X + s.X, p.Y - s.Y, p.Z },
        .Color = color,
    };
    MrqlUiRectVertex v3 = {
        .Position = { p.X + s.X, p.Y, p.Z },
        .Color = color,
    };

    RectViewGroup* pViewGroup = GetViewGroup(g.Rect.aGroups);
    sc_list_add(pViewGroup->aVertices, v0);
    sc_list_add(pViewGroup->aVertices, v1);
    sc_list_add(pViewGroup->aVertices, v2);
    sc_list_add(pViewGroup->aVertices, v3);

    sc_vk_get_pipeline(g.pScVk, g.Rect.Id)->State.IndicesCount += 6;
}

i64
register_texture(i64 id)
{
    i32 textureInd = sc_list_index_of(g.Ui.aUsedTextureIds, item == id);
    if (textureInd == -1)
    {
        textureInd = sc_list_count(g.Ui.aUsedTextureIds);
        sc_list_add(g.Ui.aUsedTextureIds, id);
    }
    return textureInd;
}
i64
image_register_texture(i64 id)
{
    i32 textureInd = sc_list_index_of(g.Image.aUsedTextureIds, item == id);
    if (textureInd == -1)
    {
        textureInd = sc_list_count(g.Image.aUsedTextureIds);
        sc_list_add(g.Image.aUsedTextureIds, id);
    }
    return textureInd;
}

void
mrql_renderer_2d_draw_image(v3 p, v2 size, v4 color, i64 id)
{
    i32 ind = image_register_texture(id);

    MrqlUiVertex v0 = {
        .Position = p,
        .Color = color,
        .Uv = v2_new(0, 0),
        .TextureIndex = ind,
    };

    MrqlUiVertex v1 = {
        .Position = { p.X, p.Y - size.Y, p.Z },
        .Color = color,
        .Uv = v2_new(0, 1),
        .TextureIndex = ind,
    };

    MrqlUiVertex v2 = {
        .Position = { p.X + size.X, p.Y - size.Y, p.Z },
        .Color = color,
        .Uv = { 1, 1 },
        .TextureIndex = ind
    };

    MrqlUiVertex v3 = {
        .Position = { p.X + size.X, p.Y, p.Z },
        .Color = color,
        .Uv = { 1, 0 },
        .TextureIndex = ind,
    };

    ViewGroup* pViewGroup = GetViewGroup(g.Image.aGroups);
    sc_list_add(pViewGroup->aVertices, v0);
    sc_list_add(pViewGroup->aVertices, v1);
    sc_list_add(pViewGroup->aVertices, v2);
    sc_list_add(pViewGroup->aVertices, v3);

    sc_vk_get_pipeline(g.pScVk, g.Image.Id)->State.IndicesCount += 6;
}

void
mrql_renderer_2d_draw_text_wrap_ext_2(v3 position, v4 color, char* pText, i32 textLength, i64 fontId, v2 wrapWindow)
{
    ScFont* pFont = (ScFont*)mrql_assety_get_font(fontId);
    i32 ind = register_texture(fontId);
    f32 c_width_multiplier = 1.0f / pFont->Size.Width;
    f32 c_height_multiplier = 1.0f / pFont->Size.Height;

    v2 offset = { .X = position.X };
    for (i32 i = 0; i < textLength; ++i)
    {
        i32 charCode = (i32)pText[i];
        i32 needsNewFont = (charCode != 32) && (pFont == NULL || (charCode < pFont->RangeMin || charCode > pFont->RangeMax));
        if (needsNewFont)
        {
            ScFont* aFonts = (ScFont*)mrql_assety_get_all_fonts();
            i32 newFontInd = sc_list_index_of(aFonts, charCode >= item.RangeMin && charCode <= item.RangeMax && item.FontSize == pFont->FontSize);
            if (newFontInd == -1)
                continue;
            pFont = &aFonts[newFontInd];
            c_width_multiplier = 1.0f / pFont->Size.Width;
            c_height_multiplier = 1.0f / pFont->Size.Height;
        }

        ScFontChar fontChar = {};
        if (charCode == ' ')
        {
            v2 spaceMetrics = sc_font_get_space_metrics(*pFont);
            offset.X += spaceMetrics.X;
            continue;
        }
        else
        {
            i32 contains = sc_dict_i_contains(pFont->hCharTable, charCode);
            if (contains)
            {
                fontChar = sc_dict_get_current(pFont->hCharTable);
            }
            else
            {
                sc_log_erro("Unknown font character %lc %d!\n", charCode, charCode);
                continue;
            }
        }

        i32 roundX = (i32)floor(offset.X + fontChar.Xoff + 0.5f);
        i32 roundY = (i32)floor(position.Y - fontChar.Yoff /* - 0.5f */);
        offset.X += fontChar.Xadvance;

        f32 cw = fontChar.X1 - fontChar.X0;
        f32 ch = fontChar.Y1 - fontChar.Y0;

        f32 x0 = roundX;
        f32 x1 = x0 + cw;
        f32 y1 = roundY;
        f32 y0 = roundY - ch;

        v3 p0 = /* 0 0 */ v3_new(x0, y0, position.Z);
        v3 p1 = /* 0 1 */ v3_new(x0, y1, position.Z);
        v3 p2 = /* 1 1 */ v3_new(x1, y1, position.Z);
        v3 p3 = /* 1 0 */ v3_new(x1, y0, position.Z);

        // DOCS: Uvs
        f32 startX = fontChar.X0 * c_width_multiplier,
            startY = fontChar.Y1 * c_width_multiplier,
            endX = fontChar.X1 * c_height_multiplier,
            endY = fontChar.Y0 * c_height_multiplier;

        v2 uv0 = v2_new(startX, startY);
        v2 uv1 = v2_new(startX, endY);
        v2 uv2 = v2_new(endX, endY);
        v2 uv3 = v2_new(endX, startY);

        MrqlUiVertex v0 = {
            .Position = p0,
            .Color = color,
            .Uv = uv0,
            .TextureIndex = ind,
        };

        MrqlUiVertex v1 = {
            .Position = p1,
            .Color = color,
            .Uv = uv1,
            .TextureIndex = ind,
        };

        MrqlUiVertex v2 = {
            .Position = p2,
            .Color = color,
            .Uv = uv2,
            .TextureIndex = ind,
        };

        MrqlUiVertex v3 = {
            .Position = p3,
            .Color = color,
            .Uv = uv3,
            .TextureIndex = ind,
        };

        ViewGroup* pViewGroup = GetViewGroup(g.Ui.aGroups);
        sc_list_add(pViewGroup->aVertices, v0);
        sc_list_add(pViewGroup->aVertices, v1);
        sc_list_add(pViewGroup->aVertices, v2);
        sc_list_add(pViewGroup->aVertices, v3);

        sc_vk_get_pipeline(g.pScVk, g.Ui.Id)->State.IndicesCount += 6;
    }
}

void
mrql_renderer_2d_draw_text_ext_2(v3 position, v4 color, char* pText, i32 textLength, i64 fontId)
{
    ScFont* pFont = (ScFont*)mrql_assety_get_font(fontId);
    i32 ind = register_texture(fontId);
    f32 c_width_multiplier = 1.0f / pFont->Size.Width;
    f32 c_height_multiplier = 1.0f / pFont->Size.Height;

    v2 offset = { .X = position.X };
    for (i32 i = 0; i < textLength; ++i)
    {
        i32 charCode = (i32)pText[i];
        i32 needsNewFont = (charCode != 32) && (pFont == NULL || (charCode < pFont->RangeMin || charCode > pFont->RangeMax));
        if (needsNewFont)
        {
            ScFont* aFonts = (ScFont*)mrql_assety_get_all_fonts();
            i32 newFontInd = sc_list_index_of(aFonts, charCode >= item.RangeMin && charCode <= item.RangeMax && item.FontSize == pFont->FontSize);
            if (newFontInd == -1)
                continue;
            pFont = &aFonts[newFontInd];
            c_width_multiplier = 1.0f / pFont->Size.Width;
            c_height_multiplier = 1.0f / pFont->Size.Height;
        }

        ScFontChar fontChar = {};
        if (charCode == ' ')
        {
            v2 spaceMetrics = sc_font_get_space_metrics(*pFont);
            offset.X += spaceMetrics.X;
            continue;
        }
        else
        {
            i32 contains = sc_dict_i_contains(pFont->hCharTable, charCode);
            if (contains)
            {
                fontChar = sc_dict_get_current(pFont->hCharTable);
            }
            else
            {
                sc_log_erro("Unknown font character %lc %d!\n", charCode, charCode);
                continue;
            }
        }

        i32 roundX = (i32)floor(offset.X + fontChar.Xoff + 0.5f);
        i32 roundY = (i32)floor(position.Y - fontChar.Yoff /* - 0.5f */);
        offset.X += fontChar.Xadvance;

        f32 cw = fontChar.X1 - fontChar.X0;
        f32 ch = fontChar.Y1 - fontChar.Y0;

        f32 x0 = roundX;
        f32 x1 = x0 + cw;
        f32 y1 = roundY;
        f32 y0 = roundY - ch;

        v3 p0 = /* 0 0 */ v3_new(x0, y0, position.Z);
        v3 p1 = /* 0 1 */ v3_new(x0, y1, position.Z);
        v3 p2 = /* 1 1 */ v3_new(x1, y1, position.Z);
        v3 p3 = /* 1 0 */ v3_new(x1, y0, position.Z);

        // DOCS: Uvs
        f32 startX = fontChar.X0 * c_width_multiplier,
            startY = fontChar.Y1 * c_width_multiplier,
            endX = fontChar.X1 * c_height_multiplier,
            endY = fontChar.Y0 * c_height_multiplier;

        v2 uv0 = v2_new(startX, startY);
        v2 uv1 = v2_new(startX, endY);
        v2 uv2 = v2_new(endX, endY);
        v2 uv3 = v2_new(endX, startY);

        MrqlUiVertex v0 = {
            .Position = p0,
            .Color = color,
            .Uv = uv0,
            .TextureIndex = ind,
        };

        MrqlUiVertex v1 = {
            .Position = p1,
            .Color = color,
            .Uv = uv1,
            .TextureIndex = ind,
        };

        MrqlUiVertex v2 = {
            .Position = p2,
            .Color = color,
            .Uv = uv2,
            .TextureIndex = ind,
        };

        MrqlUiVertex v3 = {
            .Position = p3,
            .Color = color,
            .Uv = uv3,
            .TextureIndex = ind,
        };

        ViewGroup* pViewGroup = GetViewGroup(g.Ui.aGroups);
        sc_list_add(pViewGroup->aVertices, v0);
        sc_list_add(pViewGroup->aVertices, v1);
        sc_list_add(pViewGroup->aVertices, v2);
        sc_list_add(pViewGroup->aVertices, v3);

        sc_vk_get_pipeline(g.pScVk, g.Ui.Id)->State.IndicesCount += 6;
    }
}

void
mrql_renderer_2d_draw_text_ext(v3 p, v4 color, char* pText, i32 textLength, char* pFontName, i32 fontSize)
{
    // note: i fogot how hard core this code in my prev code base.
    // ll simplify it later, textures/images first!

    i64 fontId;
    if (pFontName == NULL || fontSize == 0)
    {
        fontId = g.Ui.DefaultFont.Id;
    }
    else
    {
        // fontId = mrql_assety_load_font_id(pFontName, Fize, i32 rangeMin, i32 rangeMax)
        sc_assert_break();
    }

    mrql_renderer_2d_draw_text_ext_2(p, color, pText, textLength, fontId);
}

void
mrql_renderer_2d_draw_text(v3 p, v4 color, char* pText, i32 textLength)
{
    mrql_renderer_2d_draw_text_ext_2(p, color, pText, textLength, g.Ui.DefaultFont.Id);
}

/*
 */

int
mrql_ui_vertex_compare(const void* pVoid0, const void* pVoid1)
{
    MrqlUiVertex* pV0 = (MrqlUiVertex*)pVoid0;
    MrqlUiVertex* pV1 = (MrqlUiVertex*)pVoid1;
    return pV1->Position.Z - pV0->Position.Z;
}

ScVkPipeline*
GetPipe(i32 id)
{
    if (id == -1)
        return NULL;
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, id);
    if (pPipe->IsEnabled == 0)
        return NULL;
    return pPipe;
}

static void
rect_flush()
{
    ScVkPipeline* pPipe = GetPipe(g.Rect.Id);
    if (!pPipe)
        goto DestroyRectLabel;

    for (i32 i = 0; i < sc_list_count(g.Rect.aGroups); ++i)
    {
        RectViewGroup group = g.Rect.aGroups[i];
        i64 count = sc_list_count(group.aVertices);
        u64 verticesSize = count * sizeof(MrqlUiRectVertex);
        if (verticesSize != 0)
        {
            // ?? ?????
            qsort(group.aVertices, count, sizeof(MrqlUiRectVertex), mrql_ui_vertex_compare);
            sc_vk_pipeline_set_vertices(g.pScVk, pPipe, group.aVertices, verticesSize);
        }
    }

    // todo: sort vertices to optimize fragment shader

    ScVkUniform* pVisible = sc_vk_pipeline_get_uniform(pPipe, "u_Visible");
    VisibleViewport* aViewports = sc_list_select(g.Rect.aGroups, Viewport);
    u64 viewportSize = sc_list_count(aViewports) * sizeof(VisibleViewport);
    if (viewportSize == 0)
    {
        sc_log_warn("No viewport provided!\n");
        sc_assert_break();
    }
    else
    {
        if (!sc_vk_uniform_set(g.pScVk, pVisible, aViewports, 0, viewportSize))
        {
            sc_log_warn("Can't setup u_Visible uniform!!!\n");
            // sc_assert_break();
        }
    }
    sc_list_free(aViewports);

DestroyRectLabel:
    // set state variables to zero
    sc_list_clear(g.Rect.aGroups[0].aVertices);
    for (i32 i = 1; i < sc_list_count(g.Rect.aGroups); ++i)
    {
        RectViewGroup viewGroup = g.Rect.aGroups[i];
        sc_list_free(viewGroup.aVertices);
    }
    sc_list_header(g.Rect.aGroups)->Count = 1;
}

void
pipe_image_flush()
{
    ScVkPipeline* pPipe = GetPipe(g.Image.Id);
    if (!pPipe)
        goto ImageEndLabel;

    for (i32 i = 0; i < sc_list_count(g.Image.aGroups); ++i)
    {
        ViewGroup group = g.Image.aGroups[i];
        i64 count = sc_list_count(group.aVertices);
        u64 verticesSize = count * sizeof(MrqlUiVertex);
        if (verticesSize != 0)
        {
            qsort(group.aVertices, count, sizeof(MrqlUiVertex), mrql_ui_vertex_compare);
            sc_vk_pipeline_set_vertices(g.pScVk, pPipe, group.aVertices, verticesSize);
        }
    }

    // set images
    i32 textureUsedCount = sc_list_count(g.Image.aUsedTextureIds);
    if (textureUsedCount > 0)
    {
        VkDescriptorImageInfo* aImageInfos = NULL;
        for (i64 t = 0; t < textureUsedCount; ++t)
        {
            i64 id = g.Image.aUsedTextureIds[t];
            Sc2dTexture* pTexture = (Sc2dTexture*)mrql_assety_get_vk_texture(id);

            VkDescriptorImageInfo imageInfo = {
                .sampler = pTexture->Sampler,
                .imageView = pTexture->View,
                .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
            };

            sc_list_add(aImageInfos, imageInfo);
        }

        Sc2dTexture* pDefaultTexture = (Sc2dTexture*)mrql_assety_texture_get_default();
        ScVkDescriptorConfig* pTextures = sc_vk_pipeline_get_descriptor(pPipe, "u_Textures");
        i64 totalAmount = pTextures->Count;
        for (i32 t = sc_list_count(g.Image.aUsedTextureIds); t < totalAmount; ++t)
        {
            VkDescriptorImageInfo imageInfo = {
                .sampler = pDefaultTexture->Sampler,
                .imageView = pDefaultTexture->View,
                .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
            };

            sc_list_add(aImageInfos, imageInfo);
        }

        VkWriteDescriptorSet writeDescrSet = {
            .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
            .dstSet = pPipe->ShaderBridge.Set,
            .dstBinding = pTextures->Binding, // 3
            .dstArrayElement = 0,
            .descriptorCount = sc_list_count(aImageInfos),
            .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
            .pImageInfo = aImageInfos,
        };
        vkUpdateDescriptorSets(g.pScVk->Device, 1, &writeDescrSet, 0, NULL);
        sc_list_free(aImageInfos);
    }

    // todo: sort vertices to optimize fragment shader

    // set uniforms
    ScVkUniform* pSettings = sc_vk_pipeline_get_uniform(pPipe, "u_Settings");
    i32 isScissorDebug = 0;
    sc_vk_uniform_set(g.pScVk, pSettings, &isScissorDebug, 0, sizeof(i32));

    ScVkUniform* pVisible = sc_vk_pipeline_get_uniform(pPipe, "u_Visible");
    VisibleViewport* aViewports = sc_list_select(g.Image.aGroups, Viewport);
    u64 viewportSize = sc_list_count(aViewports) * sizeof(VisibleViewport);
    if (viewportSize == 0)
    {
        sc_log_warn("No viewport provided!\n");
        sc_assert_break();
    }
    else
    {
        if (!sc_vk_uniform_set(g.pScVk, pVisible, aViewports, 0, viewportSize))
        {
            sc_log_warn("Can't setup u_Visible uniform!!!\n");
            // sc_assert_break();
        }
    }

    sc_list_free(aViewports);

ImageEndLabel:
    // set state variables to zero
    sc_list_clear(g.Image.aGroups[0].aVertices);
    for (i32 i = 1; i < sc_list_count(g.Image.aGroups); ++i)
    {
        ViewGroup viewGroup = g.Image.aGroups[i];
        sc_list_free(viewGroup.aVertices);
    }
    sc_list_header(g.Image.aGroups)->Count = 1;
}

void
pipe_font_flush()
{
    ScVkPipeline* pPipe = GetPipe(g.Ui.Id);
    if (!pPipe)
        goto PipeUiFlushEndLabel;

    for (i32 i = 0; i < sc_list_count(g.Ui.aGroups); ++i)
    {
        ViewGroup group = g.Ui.aGroups[i];
        i64 count = sc_list_count(group.aVertices);
        u64 verticesSize = count * sizeof(MrqlUiVertex);
        if (verticesSize != 0)
        {
            qsort(group.aVertices, count, sizeof(MrqlUiVertex), mrql_ui_vertex_compare);
            sc_vk_pipeline_set_vertices(g.pScVk, pPipe, group.aVertices, verticesSize);
        }
    }

    // set images
    i32 textureUsedCount = sc_list_count(g.Ui.aUsedTextureIds);
    if (textureUsedCount > 0)
    {
        VkDescriptorImageInfo* aImageInfos = NULL;
        for (i64 t = 0; t < textureUsedCount; ++t)
        {
            i64 id = g.Ui.aUsedTextureIds[t];
            Sc2dTexture* pTexture = (Sc2dTexture*)mrql_assety_get_vk_texture(id);

            VkDescriptorImageInfo imageInfo = {
                .sampler = pTexture->Sampler,
                .imageView = pTexture->View,
                .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
            };

            sc_list_add(aImageInfos, imageInfo);
        }

        Sc2dTexture* pDefaultTexture = (Sc2dTexture*)mrql_assety_texture_get_default();
        ScVkDescriptorConfig* pTextures = sc_vk_pipeline_get_descriptor(pPipe, "u_Textures");
        i64 totalAmount = pTextures->Count;
        for (i32 t = sc_list_count(g.Ui.aUsedTextureIds); t < totalAmount; ++t)
        {
            VkDescriptorImageInfo imageInfo = {
                .sampler = pDefaultTexture->Sampler,
                .imageView = pDefaultTexture->View,
                .imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
            };

            sc_list_add(aImageInfos, imageInfo);
        }

        VkWriteDescriptorSet writeDescrSet = {
            .sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
            .dstSet = pPipe->ShaderBridge.Set,
            .dstBinding = pTextures->Binding, // 3
            .dstArrayElement = 0,
            .descriptorCount = sc_list_count(aImageInfos),
            .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
            .pImageInfo = aImageInfos,
        };
        vkUpdateDescriptorSets(g.pScVk->Device, 1, &writeDescrSet, 0, NULL);
        sc_list_free(aImageInfos);
    }

    // todo: sort vertices to optimize fragment shader

    // set uniforms
    ScVkUniform* pSettings = sc_vk_pipeline_get_uniform(pPipe, "u_Settings");
    i32 isScissorDebug = 0;
    sc_vk_uniform_set(g.pScVk, pSettings, &isScissorDebug, 0, sizeof(i32));

    ScVkUniform* pVisible = sc_vk_pipeline_get_uniform(pPipe, "u_Visible");
    VisibleViewport* aViewports = sc_list_select(g.Ui.aGroups, Viewport);
    u64 viewportSize = sc_list_count(aViewports) * sizeof(VisibleViewport);
    if (viewportSize == 0)
    {
        sc_log_warn("No viewport provided!\n");
        sc_assert_break();
    }
    else
    {
        if (!sc_vk_uniform_set(g.pScVk, pVisible, aViewports, 0, viewportSize))
        {
            sc_log_warn("Can't setup u_Visible uniform!!!\n");
            // sc_assert_break();
        }
    }

    sc_list_free(aViewports);

PipeUiFlushEndLabel:
    // set state variables to zero
    sc_list_clear(g.Ui.aGroups[0].aVertices);
    for (i32 i = 1; i < sc_list_count(g.Ui.aGroups); ++i)
    {
        ViewGroup viewGroup = g.Ui.aGroups[i];
        sc_list_free(viewGroup.aVertices);
    }
    sc_list_header(g.Ui.aGroups)->Count = 1;
}

void
mrql_renderer_2d_flush()
{
    rect_flush();
    pipe_image_flush();
    pipe_font_flush();
}
