#include "Engine/MrqlApplication.h"
#include "Engine/Observy/MrqlObserver.h"
#include "Engine/Rendy/MrqlRenderer.h"
#include "Engine/Terrain/Sdf2.h"
#include "Sc/Math.h"
#include "Sc/Sc.h"
#include "Sc/Types.h"

typedef struct __attribute__((aligned(16)))
{
    f32 HeightScale; // масштаб высот (например 50.0)
    f32 Temp;
    v2 TerrainSize; // размер карты в мире
} SdfTerrainConfig;

typedef struct
{
    v3 Position;
    v4 Color;
} SdfTerrainVertexLayout;

static struct
{
    ScVk* pScVk;
    i32 PassId;
    i32 PipeId;

    f32* aVertices;
    u32* aIndices;
} g = {};

void sdf_terrain_create_pass();
void sdf_terrain_create_pipe(MrqlRendererSdfTerrainConfig cfg);
void mrql_renderer_sdf_terrain_set_camera(m4 viewProjection);

void
mrql_renderer_sdf_terrain_init(MrqlRendererSdfTerrainConfig cfg)
{
    g.pScVk = cfg.pScVk;

    sdf_terrain_create_pass();
    sdf_terrain_create_pipe(cfg);
    // cfg.PolygonMode = VK_POLYGON_MODE_LINE;
    // terrain_create_pipe(cfg);

    MrqlObserverSubscriber sub = {
        .pName = "MrqlRenderer-SdfTerrain",
        .CameraUpdate = mrql_renderer_sdf_terrain_set_camera
    };
    mrql_observer_add_camera_sub(sub);
}

void
sdf_terrain_create_pass()
{
    // create render pass
    // register render pass
    ScVk* pScVk = g.pScVk;
    v2 windowSize = mrql_application_get_window_size();

    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
    VkFormat depthAttachmentFormat = VK_FORMAT_D32_SFLOAT;

    VkAttachmentDescription colorDescr = {
        .format = pScVk->Swap.SurfaceFormat.format,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
    };
    ScVkAttachment color = {
        .Type = ScVkAttachmentType_Color,
        .Description = colorDescr,
        .Reference = { .attachment = 0, .layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL }
    };

    VkAttachmentDescription depthDescr = {
        .format = depthAttachmentFormat,
        .samples = samples,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
        .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
        .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
        .finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL
    };
    ScVkAttachment depth = {
        .Type = ScVkAttachmentType_Depth,
        .Description = depthDescr,
        .Reference = { .attachment = 1, .layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL }
    };

    ScVkAttachment aAttachments[] = {
        color, depth
    };

    VkSubpassDependency subpassDependency = {
        .srcSubpass = VK_SUBPASS_EXTERNAL,
        .dstSubpass = 0,
        .srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT,
        .srcAccessMask = 0,
        .dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
        .dependencyFlags = 0,
    };

    ScVkRenderPassConfig renderPassCfg = {
        .aAttachments = aAttachments,
        .Dependency = subpassDependency,
        .Resolution = windowSize,
        .AttachmentsCount = 2,
        .BufferingType = ScVkRenderPassBufferingType_Single
    };

    // printf("Render pass samples count: %s\n", sc_vk_sample_count_to_string(renderPass.Samples));

    g.PassId = sc_vk_render_pass_new(pScVk, renderPassCfg);
}

void
mrql_renderer_sdf_terrain_deinit()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);
    sc_vk_pipeline_destroy(g.pScVk, *pPipe);
    sc_vk_render_pass_destroy(g.pScVk, g.PassId);
    sc_list_remove_index(g.pScVk->aPipelines, g.PipeId);
    sc_list_remove_index(g.pScVk->aRenderPasses, g.PassId);
}

void
sdf_terrain_create_pipe(MrqlRendererSdfTerrainConfig cfg)
{
    ScVk* pScVk = g.pScVk;
    i64 renderPassId = g.PassId;

    ScVkDescriptorConfig aDescriptors[] = {
        [0] = (ScVkDescriptorConfig) {
            .pName = "u_CameraUniform",
            .Type = ScVkDescriptorType_Uniform,
            .Binding = 0,
            .Count = 1,
            .Size = sizeof(m4) }
    };

    ScVkStageConfig vertCfg = {
        .Type = ScVkStageType_Vertex,
        .pShaderPath = "Resources/Shaders/Pipes/SdfTerrain.vert",
        .aDescriptors = aDescriptors,
        .DescriptorsCount = ScArrayCount(aDescriptors),
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig fragCfg = {
        .Type = ScVkStageType_Fragment,
        .pShaderPath = "Resources/Shaders/Pipes/SdfTerrain.frag",
        .PipelineIndex = sc_vk_get_next_pipeline_index(pScVk)
    };

    ScVkStageConfig aStages[] = { vertCfg, fragCfg };

    ScVkAttribute aAttributes[] = {
        [0] = {
            .Format = VK_FORMAT_R32G32B32_SFLOAT,
            .Offset = ScOffsetOf(SdfTerrainVertexLayout, Position),
        },
        [1] = {
            .Format = VK_FORMAT_R32G32B32A32_SFLOAT,
            .Offset = ScOffsetOf(SdfTerrainVertexLayout, Color),
        },
    };

    ScVkPipelineConfig pipeCfg = sc_vk_pipeline_config_new_ext((ScVkPipelineConfig) {
        .IsDepthWriteEnabled = 1,
        .Topology = ScVkTopologyType_TriangleList,
        .RenderPassId = renderPassId,
        .aStages = aStages,
        .aAttributes = aAttributes,
        .Stride = sizeof(SdfTerrainVertexLayout),
        .StagesCount = ScArrayCount(aStages),
        .AttributesCount = ScArrayCount(aAttributes),
        .VerticesCount = cfg.QuadsCount,
        .IndicesCount = 6 * cfg.QuadsCount });
    // sc_vk_pipeline_config_print(pScVk, pipeCfg);

    g.PipeId = sc_vk_pipeline_new(pScVk, pipeCfg);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(pScVk, g.PassId);
    sc_vk_render_pass_create_buffers(pScVk, pPass->Id);
}

void
mrql_renderer_sdf_terrain_draw_v2(Sdf2VoxelMesh meshData)
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);

    if (!pPipe->IsEnabled)
        return;

    if (sc_list_count(meshData.aVertices) <= 0)
        return;

    f32* aVertices = NULL;
    u32* aIndices = NULL;

    for (i64 v = 0; v < sc_list_count(meshData.aVertices); ++v)
    {
        Sdf2VoxelVertex vertex = meshData.aVertices[v];

        v3 rcolor = v3_new(0.7, 0.6, 0.5);
        v3 gcolor = v3_new(rcolor.B, rcolor.R, rcolor.G);
        v3 bcolor = v3_new(rcolor.G, rcolor.B, rcolor.R);

        v3 v0 = vertex.V0;
        v3 v1 = vertex.V1;
        v3 v2 = vertex.V2;
        v3 v3 = vertex.V3;

        v4 c0 = v4_v3v(v3_mul(rcolor, v0), 1.0);
        v4 c1 = v4_v3v(v3_mul(gcolor, v3_mulv(v1, 0.4)), 1.0);
        v4 c2 = v4_v3v(v3_mul(bcolor, v3_mulv(v2, 0.4)), 1.0);
        v4 c3 = v4_v3v(v3_mul(v3_mul(v3_add(rcolor, gcolor), bcolor), v3_mulv(v3, 0.4)), 1.0);

        sc_list_add(g.aVertices, v0.X);
        sc_list_add(g.aVertices, v0.Y);
        sc_list_add(g.aVertices, v0.Z);
        sc_list_add(g.aVertices, c0.R);
        sc_list_add(g.aVertices, c0.G);
        sc_list_add(g.aVertices, c0.B);
        sc_list_add(g.aVertices, c0.A);

        sc_list_add(g.aVertices, v1.X);
        sc_list_add(g.aVertices, v1.Y);
        sc_list_add(g.aVertices, v1.Z);
        sc_list_add(g.aVertices, c1.R);
        sc_list_add(g.aVertices, c1.G);
        sc_list_add(g.aVertices, c1.B);
        sc_list_add(g.aVertices, c1.A);

        sc_list_add(g.aVertices, v2.X);
        sc_list_add(g.aVertices, v2.Y);
        sc_list_add(g.aVertices, v2.Z);
        sc_list_add(g.aVertices, c2.R);
        sc_list_add(g.aVertices, c2.G);
        sc_list_add(g.aVertices, c2.B);
        sc_list_add(g.aVertices, c2.A);

        sc_list_add(g.aVertices, v3.X);
        sc_list_add(g.aVertices, v3.Y);
        sc_list_add(g.aVertices, v3.Z);
        sc_list_add(g.aVertices, c3.R);
        sc_list_add(g.aVertices, c3.G);
        sc_list_add(g.aVertices, c3.B);
        sc_list_add(g.aVertices, c3.A);

        i32 base = sc_list_count(g.aIndices) / 6 * 4;
#if 0
        sc_list_add(g.aIndices, 0 + base);
        sc_list_add(g.aIndices, 1 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 0 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 3 + base);
#else
        sc_list_add(g.aIndices, 0 + base);
        sc_list_add(g.aIndices, 1 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 3 + base);
        sc_list_add(g.aIndices, 0 + base);
#endif
    }
}

void
mrql_renderer_sdf_terrain_draw(SdfVoxelMesh meshData)
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);

    if (!pPipe->IsEnabled)
        return;

    if (sc_list_count(meshData.aVertices) <= 0)
        return;

    f32* aVertices = NULL;
    u32* aIndices = NULL;

    for (i64 v = 0; v < sc_list_count(meshData.aVertices); ++v)
    {
        SdfVoxelVertex vertex = meshData.aVertices[v];

        v3 n0 = v3_add(vertex.N0, v3_new(.25, .25, .25));
        v3 n1 = v3_add(vertex.N1, v3_new(.25, .25, .25));
        v3 n2 = v3_add(vertex.N2, v3_new(.25, .25, .25));
        v3 n3 = v3_add(vertex.N3, v3_new(.25, .25, .25));
        v3 v0 = vertex.V0;
        v3 v1 = vertex.V1;
        v3 v2 = vertex.V2;
        v3 v3 = vertex.V3;

        v4 c0 = v4_v3v(v3_mul(n0, v0), 1.0);
        v4 c1 = v4_v3v(v3_mul(n1, v3_mulv(v1, 0.4)), 1.0);
        v4 c2 = v4_v3v(v3_mul(n2, v3_mulv(v2, 0.4)), 1.0);
        v4 c3 = v4_v3v(v3_mul(n3, v3_mulv(v3, 0.4)), 1.0);

        sc_list_add(g.aVertices, v0.X);
        sc_list_add(g.aVertices, v0.Y);
        sc_list_add(g.aVertices, v0.Z);
        sc_list_add(g.aVertices, c0.R);
        sc_list_add(g.aVertices, c0.G);
        sc_list_add(g.aVertices, c0.B);
        sc_list_add(g.aVertices, c0.A);

        sc_list_add(g.aVertices, v1.X);
        sc_list_add(g.aVertices, v1.Y);
        sc_list_add(g.aVertices, v1.Z);
        sc_list_add(g.aVertices, c1.R);
        sc_list_add(g.aVertices, c1.G);
        sc_list_add(g.aVertices, c1.B);
        sc_list_add(g.aVertices, c1.A);

        sc_list_add(g.aVertices, v2.X);
        sc_list_add(g.aVertices, v2.Y);
        sc_list_add(g.aVertices, v2.Z);
        sc_list_add(g.aVertices, c2.R);
        sc_list_add(g.aVertices, c2.G);
        sc_list_add(g.aVertices, c2.B);
        sc_list_add(g.aVertices, c2.A);

        sc_list_add(g.aVertices, v3.X);
        sc_list_add(g.aVertices, v3.Y);
        sc_list_add(g.aVertices, v3.Z);
        sc_list_add(g.aVertices, c3.R);
        sc_list_add(g.aVertices, c3.G);
        sc_list_add(g.aVertices, c3.B);
        sc_list_add(g.aVertices, c3.A);

        i32 base = sc_list_count(g.aIndices) / 6 * 4;
#if 1
        sc_list_add(g.aIndices, 0 + base);
        sc_list_add(g.aIndices, 1 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 0 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 3 + base);
#else
        sc_list_add(g.aIndices, 0 + base);
        sc_list_add(g.aIndices, 1 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 2 + base);
        sc_list_add(g.aIndices, 3 + base);
        sc_list_add(g.aIndices, 0 + base);
#endif
    }
}

void
mrql_renderer_sdf_terrain_upload()
{
    ScVkPipeline* pPipe = sc_vk_get_pipeline(g.pScVk, g.PipeId);

    if (!pPipe->IsEnabled)
        return;

    i64 verticesCount = sc_list_count(g.aVertices);
    if (verticesCount <= 0)
        return;

    u64 verticesSize = verticesCount * sizeof(f32);
    sc_vk_pipeline_set_vertices(g.pScVk, pPipe, g.aVertices, verticesSize);

    i64 indicesCount = sc_list_count(g.aIndices);
    u64 totalIndexBufferSize = indicesCount * sizeof(u32);
    ScVkRenderPass* pPass = sc_vk_get_render_pass(g.pScVk, g.PassId);
    sc_vk_shared_buffer_set_data(g.pScVk, &pPass->Index, g.aIndices, 0, totalIndexBufferSize);
    sc_vk_get_pipeline(g.pScVk, g.PipeId)->State.IndicesCount = indicesCount;
}

void*
mrql_renderer_sdf_terrain_get_render_pass()
{
    return (void*)sc_vk_get_render_pass(g.pScVk, g.PassId);
}

i64
mrql_renderer_sdf_terrain_get_render_pass_id()
{
    return g.PassId;
}

void
mrql_renderer_sdf_terrain_set_camera(m4 viewProjection)
{
    sc_vk_pipeline_set_uniform(g.pScVk, g.PipeId, "u_CameraUniform", &viewProjection, 0, sizeof(m4));
}

void
mrql_renderer_sdf_terrain_flush()
{
    ScVk* pScVk = g.pScVk;
    ScVkPipeline* pPipe = sc_vk_get_pipeline(pScVk, g.PipeId);
    pPipe->State.IndicesCount = sc_list_count(g.aIndices);
}
