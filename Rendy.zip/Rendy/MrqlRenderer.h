#ifndef MRQL_RENDERER_H
#define MRQL_RENDERER_H

#include "Engine/Terrain/Sdf.h"
#include "Engine/Terrain/Sdf2.h"
#include "Sc/Types.h"
#include <Sc/Vk.h>

typedef struct
{
    i64 MaxRectsCount;
    ScVk* pScVk;

    i8 IsRectEnabled;
    i8 IsImageEnabled;
    i8 IsUiEnabled;
} MrqlRenderer2dConfig;

typedef struct
{
    ScVk* pScVk;
    i64 VerticesCount;
    VkPolygonMode PolygonMode;
} MrqlRendererTerrainConfig;

typedef struct
{
    ScVk* pScVk;
    i64 QuadsCount;
} MrqlRendererSdfTerrainConfig;

typedef struct
{
    ScVk* pScVk;
    i64 VerticesCount;
    i8 IsPointsEnabled;
} MrqlRendererPrimitiveConfig;

typedef struct
{
    ScVk* pScVk;
} MrqlRendererConfig;

void mrql_renderer_init(MrqlRendererConfig cfg);
void mrql_renderer_deinit();
void* mrql_renderer_2d_get_render_pass();
void mrql_renderer_request_resize();

// DOCS: 2d
extern void mqrl_renderer_2d_init(MrqlRenderer2dConfig cfg);
extern void mqrl_renderer_2d_deinit();
extern void mrql_renderer_2d_draw_rect(v3 pos, v2 size, v4 color);
extern void mrql_renderer_2d_draw_image(v3 p, v2 size, v4 color, i64 id);
extern void mrql_renderer_2d_draw_text(v3 p, v4 color, char* pText, i32 textLength);
extern void mrql_renderer_2d_draw_text_ext(v3 p, v4 color, char* pText, i32 textLength, char* pFontName, i32 fontSize);
extern void mrql_renderer_2d_flush();
extern void mrql_renderer_2d_set_camera(m4 viewProjection);
extern void mrql_renderer_2d_set_viewport(v2 min, v2 max);
extern void mrql_renderer_2d_add_font(i64 fontId);
extern i64 mrql_renderer_2d_get_render_pass_id();

// DOCS: Primitive (3D)
extern void mrql_renderer_primitive_init(MrqlRendererPrimitiveConfig cfg);
extern void mrql_renderer_primitive_deinit();
extern void mrql_renderer_primivity_draw_plane_ext(v3 pos, v2 size, v4 aColors[4]);
extern void mrql_renderer_primivity_draw_plane(v3 pos, v2 size, v4 color);
extern void mrql_renderer_primitive_draw_cube_ext(v3 pos, v3 size, v4 aColors[3]);
extern void mrql_renderer_primitive_draw_cube(v3 pos, v3 size, v4 color);
extern void mrql_renderer_primitive_draw_point(v3 pos, v4 color);
extern void mrql_renderer_primitive_draw_text(char* pText, v3 position, v4 color);
extern void mrql_renderer_primitive_flush();
extern void mrql_renderer_primitive_set_camera(m4 viewProjection);
extern void* mrql_renderer_primitive_get_render_pass();
extern i64 mrql_renderer_primitive_get_render_pass_id();

// DOCS: Terrain
extern void mrql_renderer_terrain_init(MrqlRendererTerrainConfig cfg);
extern void mrql_renderer_terrain_deinit();
extern void mrql_renderer_terrain_set(v2 size);
extern void mrql_renderer_terrain_draw();
extern void mrql_renderer_terrain_flush();
extern void* mrql_renderer_terrain_get_render_pass();
extern i64 mrql_renderer_terrain_get_render_pass_id();
extern void mrql_renderer_terrain_set_camera(m4 viewProjection);
extern void mrql_renderer_terrain_set_height_map(Sc2dTexture heightMap);

// DOCS: SdfTerrain
extern void mrql_renderer_sdf_terrain_init(MrqlRendererSdfTerrainConfig cfg);
extern void mrql_renderer_sdf_terrain_deinit();
extern void mrql_renderer_sdf_terrain_draw(SdfVoxelMesh meshData);
extern void mrql_renderer_sdf_terrain_draw_v2(Sdf2VoxelMesh meshData);
extern void mrql_renderer_sdf_terrain_upload();
extern void* mrql_renderer_sdf_terrain_get_render_pass();
extern i64 mrql_renderer_sdf_terrain_get_render_pass_id();
extern void mrql_renderer_sdf_terrain_set_camera(m4 viewProjection);
extern void mrql_renderer_sdf_terrain_flush();

i32 mrql_renderer_is_resize_pending();

void mrql_renderer_draw(ScVk* pScVk);
void mrql_renderer_draw_new(ScVk* pScVk);

#endif // MRQL_RENDERER_H
