# Masuka — build-система движка Miracle

> Self-hosted сборщик на C99 (стиль premake/cmake) со своим мини-языком конфигурации.
> Реализация: `Tools/Masuka.c` (~5100 строк), API: `Tools/Masuka.h`, вход: `MasukaTest.c` (`main` → `msk_cli_start`).
> Опирается на собственную библиотеку утилит `Sc/` (строки, списки, пути, логи, тесты).

## Состав репозитория

| Путь | Назначение |
|---|---|
| `MasukaTest.c` | Точка входа CLI |
| `Tools/Masuka.h` | Публичный API (структуры и функции) |
| `Tools/Masuka.c` | Вся реализация: CLI, язык, препроцессор, резолвер, генератор, компилятор, тесты |
| `Tools/vince.masuka_example` | Пример корневого конфига workspace |
| `Tools/format.masuka_example` | Краткий пример формата |
| `Sc/` | Утилитарная библиотека (Types, Sc, Test, Json, Math, ...) |

## Пайплайн сборки (`msk_cli_start`)

```
CLI (-b -p -j -d -e -a ...)
  → vince.masuka (workspace: builds, platforms, entry, let-переменные)
  → рекурсивный поиск *.masuka (проекты) в подкаталогах и в корне
  → парсинг MskFile (AST) + валидация с точными сообщениями
  → препроцессор переменных ({build}, {platform}, {project})
  → слияние платформенного блока (linux:/windows:) в проект
  → MskProject (резолв globs, provide-include, -D флаги build/platform)
  → граф зависимостей (топосорт, детект циклов, транзитивные includes)
  → генератор (vince_build.sh/.bat в корне + build_<Project>.sh/.bat в каталогах
    проектов, рядом с их .masuka + compile_commands.json)
  → компилятор: скрипты на диск пишутся только с -gb; без -gb сборка идёт из памяти
    (временные скрипты в bin/.masuka-tmp, выполняются и удаляются)
```

## CLI

```
masuka [flags]
```

### Конфигурация
| Флаг | Значение | По умолчанию |
|---|---|---|
| `-b <build>` | имя build из vince.masuka | системный build (debug/release/distribute) |
| `-p <platform>` | имя platform из vince.masuka; **определяет вид скриптов**: `-p windows` → `.bat` (clang.exe), `-p linux` → `.sh` | системная платформа (linux/windows) |
| `-d <directory>` | рабочая директория | директория exe; поднимается вверх до vince.masuka (макс. 16 уровней) |
| `-j <count>` | параллельные задачи, `0 < count <= 2*cpu` | 1 |

### Действия
| Флаг | Описание |
|---|---|
| `-c` | удалить артефакты выбранной конфигурации |
| `-gb` | записать скрипты сборки на диск (vince_build.sh/.bat в корне + build_<Project> в каталогах проектов); без `-gb` скрипты живут только в памяти (временный каталог) |
| `-rb` | clean + generate + build |
| `-gccj` | сгенерировать compile_commands.json |
| `-nc` | не компилировать |
| `-r` | запустить entry-проект workspace (**не реализовано**) |
| `-e <project>` | запустить указанный проект (**не реализовано**) |
| `-a <args>`, `-a{N} <args>` | аргументы программы для запуска (макс 1023 байта) |
| `-t` | запустить тест-проекты (**не реализовано**) |

### Прочее
- `-h` / `--help` — справка
- `--self-test` — встроенные юнит-тесты Masuka
- Выходные коды: `0` — успех, `1` — ошибка сборки/запуска, `2` — неверная конфигурация
- Дефолтное действие — сборка; **проект компилируется всегда, отключение — только `-nc`**
  (в т.ч. вместе с `-c`, `-gb`, `-gccj`, `-r`, `-e`, `-t`)

## Язык .masuka

### vince.masuka (корень workspace)

```
workspace miracle
{
    entry: "masuka"
    let KEY: "value"

    builds: [
        { name: "debug"     preprocessor: "SC_BUILD_DEBUG"     optimize: 0 }
        { name: "release"   preprocessor: "SC_BUILD_RELEASE"   optimize: 1 }
        { name: "distribute" preprocessor: "SC_BUILD_DISTRIBUTE" optimize: 1 }
    ]

    platforms: [
        { name: "linux"   preprocessor: "SC_PLATFORM_LINUX" }
        { name: "windows" preprocessor: "SC_PLATFORM_WINDOWS" }
    ]
}
```

- Валидация: обязательны `workspace <Name>`, непустые `builds` и `platforms`, уникальные имена; дубликаты и пропуски логируются с точным указанием поля.
- Дефолтные `{build}`/`{platform}` — первые объявленные в vince.masuka, системные значения — только fallback для пустого workspace.

### Проектный *.masuka (любой в дереве workspace)

```
project p1
{
    type: "StaticLib" | "Executable" | "DynamicLib"
    bin: "bin/{build}-{platform}"
    objdir: "bin/obj/{build}-{platform}/{project}"
    source: ["{project}/Source/*.c"]        // паттерны расширяются относительно каталога проекта
    dependencies: ["dep1"]                   // имена проектов, резолвятся графом
    include: ["inc"]                         // workspace-относительные
    provide-include: ["src"]                 // project-относительные, транзитивно передаются зависимым
    preprocessors: ["COMMON"]
    links: []                                // имена ("vulkan" -> -lvulkan) или сырые флаги ("-pthread")

    linux:   { ... те же поля ... }          // сливаются при -p linux
    windows: { ... те же поля ... }
}
```

- Файл без блока `project` — не проект (пропускается с warning).
- Обязательные поля: `project`, `type`, `bin`, `objdir`, непустой `source`.
- Переменные `{...}` подставляются препроцессором; `{project}` — временная переменная конкретного проекта.

## Модель данных

- `MskFile` — AST распарсенного *.masuka (сырые строки с переменными)
- `MskProject` — резолвнутый проект (пути, globs, -D флаги, зависимости)
- `MskWorkspace` — конфигурация CLI + vince.masuka + все проекты
- `MskBatch` / `MskBatchProject` — единица компиляции (TU → .o) и батч проекта
- Одна цепочка: `MskFile (AST) → MskProject (resolved) → generator`

## Граф зависимостей

- Валидация: дубликаты имён, зависимость на неизвестный проект, самозависимость — ошибки.
- Топологическая сортировка DFS (deps-first), детект циклов с выводом цепочки.
- Транзитивное распространение `provide-include` каталогов в `include` зависимых проектов.
- Уровни зависимостей (`1 + max(deps)`): проекты одного уровня независимы и собираются параллельно.

## Генератор

- Скрипты для хоста: `.sh` на Linux, `.bat` на Windows (`msk_script_kind_host`).
- На диск скрипты пишутся только с `-gb`/`-rb`: главный `vince_build.sh|.bat`
  в корне workspace + `build_<Project>.sh|.bat` в каталоге каждого проекта
  (рядом с его `.masuka` файлом). Без `-gb` скрипты существуют только в памяти
  (см. «Компиляция»).
- Главный `vince_build.sh|.bat` в корне workspace: `cd` в корень, проекты в топологическом порядке,
  параллельные волны по уровням (`pids=()` + `wait`), `-j` делится между параллельными проектами.
- `build_<Project>.sh|.bat` в каталоге проекта: `set -e`, `cd`, `mkdir -p` для объектных каталогов
  (объекты зеркалят дерево исходников: `objdir/Source/Sc/Sc.o`), компиляция TU,
  затем `ar rcs` (StaticLib, явный список объектов) или линковка (Executable/DynamicLib).
- Компиляция: `clang -std=c99 -m64` + (`-O2` | `-g -O0`) + `-fPIC` (DynamicLib) + `-D...` + `-I...`.
- Линковка: объекты явным списком, `-L` на bin-каталоги зависимостей, `-l<project>` для проектов
  workspace (транзитивно, deps-first), сырые `links` в конце, `-Wl,-rpath,$ORIGIN` при динамических
  зависимостях (только Linux).
- Выходы: `<bin>/<name>[.exe]`, `lib<name>.a`/`.so` (Linux), `<name>.lib`/`.dll` (Windows).
- Экранирование слов для shell (`'...'`, `'\''`) и batch (`"..."`, удвоение кавычек).
- `-gccj`: `compile_commands.json` в корне с абсолютными путями для clangd
  (directory/file/output/arguments, экранирование JSON-строк).
- Заголовок скриптов: "Generated by Masuka. Do not edit: `masuka -gb` rewrites this file."

## Компиляция и инкрементальность

- Запуск скриптов через `system()` (`bash`/`cmd /c`), вывод напрямую в терминал.
- Без `-gb` (режим по умолчанию): скрипты генерируются в память, пишутся во временный
  каталог `bin/.masuka-tmp`, выполняются и удаляются (даже при падении сборки) —
  рядом с исходниками ничего не остаётся.
- С `-gb`/`-rb`: скрипты записаны в каталоги проектов и в корень (`vince_build.sh|.bat`),
  сборка запускает главный скрипт.
- Инкрементальность (только shell): TU пересобирается, если
  объект отсутствует, либо исходник новее (`-nt`), либо изменились флаги компиляции
  (штамп `objdir/.masuka_flags`, `MSK_FLAGS`/`MSK_STAMP` в скрипте).
- Batch-скрипты на Windows всегда пересобирают (mtime-сравнение в cmd непортабельно — отмечено как M6).
- `-c`/`-rb`: удаляет per-project и главный скрипты, `bin/.masuka-tmp`, objdir и bin-каталоги проектов.

**Готово:** CLI с строгой валидацией, парсер языка, препроцессор переменных, граф зависимостей,
топосорт, параллелизм (волны уровней + `-j` внутри проекта), экранирование shell/batch,
`compile_commands.json`, инкрементальная сборка (Linux), `-c`/`-rb`/`-gb`/`-gccj`,
встроенные юнит-тесты (`--self-test`, 17 функций, включая end-to-end компиляцию и негативные сценарии).

**Не реализовано (заглушки):**
- `msk_runner_run_program` — запуск программ (`-r`, `-e`) — M5-1
- `msk_runner_run_tests` — запуск тестов (`-t`) — M5-3
- `-a`/`-a{N}` парсятся и валидируются, но аргументы некому передавать
- Инкрементальность на Windows (.bat) — M6

**Требования к окружению:** clang и llvm-ar в PATH.

## Тесты

`masuka --self-test` (рано, до инициализации лога; ожидаемые ошибки выводятся в silent-бэкенд):

- CLI: парсинг флагов, спец-случаи (`-h`, `--self-test`, unknown, значение-флаг), валидация `-a{N}`, `-j`
- Язык: vince.masuka, проектный файл, platform-block, name-char
- Препроцессор: подстановка, отсутствие переменных, незакрытая скобка
- Проекты: from_file (glob, provide-include, препроцессоры build/platform), resolve (топосорт,
  unknown dep, цикл)
- Генератор: object-path, shell-скрипт, batch-скрипт, json, экранирование, параллельные волны
- Компилятор: полный цикл (lib + app, сборка → запуск → повторная инкрементальная сборка →
  негативный сценарий с битым исходником, тишина через dup2 на Linux)
- Временные файлы тестов: `.tmp-masuka-tests` (создаётся и удаляется)

## Известные проблемы

1. **Glob `**.c` (критично).** `msk_file_regex_match` сканирует паттерн с конца и возвращает 1 при
   первом `*` — до проверки расширения. Маска для `Source/**.c` берётся с первого wildcard (`**.c`),
   поэтому собираются **все файлы рекурсивно, включая заголовки**. Простой `*.c` работает корректно.
   Пример из `vince.masuka_example` (строка 34) как раз использует `**.c`.
2. **Неизвестная переменная не прерывает сборку.** `msk_preprocess_string` логирует ошибку, но
   продолжает: подстановка молча пропускается, путь остаётся «битым». Стоит вернуть ошибку наверх.
3. **Мёртвый код:** `msk_parse_next_single_path` (`sc_guard_not_used`, `return NULL`);
   ~130 закомментированных строк в `MasukaTest.c`.
4. **Мелочи:** `snprintf` в буфер 1024 (`msk_script_make_executable`, `msk_tests_run_program`) —
   длинные пути молча обрежутся; `msk_language_is_identifier` создаёт 256-байтовую таблицу на вызов;
   парсер vince.masuka на switch по первой букве — хрупкий (любое слово на 'l' проверяется на "linux:").

## Поведение `-p windows` (вид скриптов)

`-p <platform>` выбирает платформенный блок (`windows: { ... }`) из `vince.masuka`,
значение переменной `{platform}` в путях (`bin/debug-windows/...`) и **вид
генерируемых скриптов** (`msk_script_kind_from_platform`):

- `-p windows` → `vince_build.bat` + `build_<Project>.bat`: `clang.exe`,
  `llvm-ar.exe`, `.exe/.lib/.dll`, `\`-разделители, batch-синтаксис;
- `-p linux` → `.sh`: `clang`, `ar`, `lib*.a`/`.so`, `/`;
- неизвестная платформа — фолбэк на вид хоста.

Скрипты исполняет шелл хоста (`bash`/`cmd`), поэтому на Linux-хосте `-p windows`
сгенерирует корректные `.bat` (запустить их там не получится без cmd — это
подготовка артефактов для Windows). Настоящая кросс-компиляция (Linux → Windows
через mingw-тулчейн) в ТЗ не входит: при необходимости её реализуют отдельным
build в `vince.masuka` со своим `preprocessor` и `links`.

## Справка по функциям (Masuka.h)

| Блок | Функции |
|---|---|
| CLI | `msk_cli_start`, `msk_cli_parse_args`, `msk_cli_apply_system_defaults`, `msk_cli_validate_args` |
| Язык | `msk_language_vince_new/_is_valid/_validate/_set_selection`, `msk_language_file_new/_from_memory/_is_valid/_validate` |
| Препроцессор | `msk_preprocessor_file`, `msk_file_apply_platform`, `msk_preprocess_string` |
| Проекты | `msk_project_from_file`, `msk_projects_from_files`, `msk_projects_resolve` |
| Генератор | `msk_generator_json_create`, `msk_generator_build_create/_create_single/_write`, `msk_generator_project_script_path`, `msk_generator_main_script_path`, `msk_script_kind_host`, `msk_project_object_path`, `msk_script_quote_word` |
| Компилятор | `msk_compiler_compile`, `msk_compiler_compile_from_scripts`, `msk_compiler_clean` |
| Раннер | `msk_runner_run_program` (заглушка), `msk_runner_run_tests` (заглушка) |
| Утилиты | `msk_parse_next_single_value/_single_path/_id/_array`, `msk_file_regex_match`, `msk_get_all_files_from_directory` |
| Тесты | `msk_tests_run` |
