#include <Sc/Sc.h>
#include <Tools/Masuka.h>
#include <stdio.h>
#include <stdlib.h>

// static void
// ext_print_array(MasukaFile* aFiles, char* pLabel)
// {
//     if (aFiles)
//     {
//         printf("\t%s: [\n", pLabel);
//         for (i32 f = 0; f < sc_list_count(aFiles); ++f)
//         {
//             MasukaFile file = aFiles[f];
//             printf("\t\t%s\n", file.pName);
//         }
//         printf("\t]\n");
//     }
//     else
//     {
//         printf("\t%s: []\n", pLabel);
//     }
// }

// void
// test(i32 argumentsCount, char** aArguments)
// {
//     sc_log_init_default();

//     // masuka stuff
//     sc_log_info("Parsing vince.masuka\n");
//     MasukaConfig mskCfg = {
//         .ArgumentsCount = argumentsCount,
//         .aArguments = aArguments
//     };
//     MasukaWorkspace mskWorkspace = masuka_parse_root(mskCfg);
//     masuka_workspace_print(mskWorkspace);

//     // todo: add startup project and auto select
//     i32 miracle_ind = sc_list_index_of(mskWorkspace.aProjects, sc_string_compare(item.pName, "Masuka"));
//     if (miracle_ind == -1)
//         return;

//     MasukaProject* pProject = &mskWorkspace.aProjects[miracle_ind];
//     MasukaCompileConfig miracleCompileCfg = {
//         .Project = *pProject,
//         .ArgumentsCount = argumentsCount,
//         .aArguments = aArguments,
//     };

//     masuka_project_compile(mskWorkspace, miracleCompileCfg);

//     printf("Project\n\tname: %s\n\ttype: %s\n\tbin: %s\n\tobj: %s\n", pProject->pName, masuka_project_type_to_string(pProject->Type), pProject->pBin, pProject->pObjDir);

//     ext_print_array(pProject->aSources, "Source");
//     ext_print_array(pProject->aDependencies, "Dependencies");
//     ext_print_array(pProject->aLinks, "Links");
//     ext_print_array(pProject->aIncludes, "Includes");
//     ext_print_array(pProject->aProvided, "Provided-Include");

// #if 0
//     sc_list_for_each(mskWorkspace.aProjects, pProject)
//     {
//         if (pProject->pName)
//         {
//             MasukaCompileConfig compile_cfg = {
//                 .Project = *pProject,
//                 .ArgumentsCount = 0,
//                 .aArguments = NULL
//             };

//             masuka_project_to_cli(mskWorkspace, compile_cfg);

//             printf("Project\n\tname: %s\n\ttype: %s\n\tbin: %s\n\tobj: %s\n", pProject->pName, masuka_project_type_to_string(pProject->Type), pProject->pBin, pProject->pObjDir);

//             ext_print_array(pProject->aSources, "Source");
//             ext_print_array(pProject->aDependencies, "Dependencies");
//             ext_print_array(pProject->aLinks, "Links");
//             ext_print_array(pProject->aIncludes, "Includes");
//             ext_print_array(pProject->aProvided, "Provided-Include");
//         }
//     }
// #endif // 0
// }



// void
// to_compile_command_json(MasukaWorkspace mskWorkspace)
// {
//     for (i32 p = 0; p < sc_list_count(mskWorkspace.aProjects); ++p)
//     {
//         MasukaProject mskProject = mskWorkspace.aProjects[p];
//         MasukaBatchProject batchProject = masuka_project_to_batch(mskWorkspace, mskProject);

//         for (i32 b = 0; b < sc_list_count(batchProject.aBatches); ++b)
//         {
//             MasukaBatch batch = batchProject.aBatches[b];

//             printf("{\n");
//             printf("\t\"file\": \"%s\",\n", batch.SourceFile.pName);
//             // todo: impl absolute path to project
//             printf("\t\"directory\": \"%s\",\n", NULL);
//             printf("\t\"output\": \"%s\",\n", batch.Object.pName);

//             printf("\t\"arguments\":[\n");
//             printf("\t\t\"/usr/bin/clang\",\n");

//             for (i32 p = 0; p < sc_list_count(batchProject.aPreprocessors); ++p)
//             {
//                 MasukaFile preproc = batchProject.aPreprocessors[p];
//                 printf("\t\t\"-D%s\",\n", preproc.pName);
//             }

//             for (i32 p = 0; p < sc_list_count(batchProject.aIncludes); ++p)
//             {
//                 MasukaFile inc = batchProject.aIncludes[p];
//                 printf("\t\t\"-I%s\",\n", inc.pName);
//             }

//             printf("\t]\n");
//             printf("}\n");
//         }
//     }
// }

/*

masuka -b debug -d "." -p linux
masuka -b debug -d "/home/tdef/Big/programming/C/other/masuka/1" -j 8 -r -e

todo:
*/

i32
main(i32 argumentsCount, char** aArguments)
{
    return msk_cli_start(argumentsCount, aArguments);
}
