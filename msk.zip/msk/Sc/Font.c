#include "Font.h"
#include "Sc/Sc.h"
#include <Deps/stb_image.h>
#include <Deps/stb_image_write.h>
#include <Deps/stb_truetype.h>
#include <math.h>
#include <string.h>

static i32 make_bitmap(unsigned char* pData, i32 offset, f32 pixel_height, unsigned char* pBitmap, i32 bitmapWidth, i32 bitmapHeight, i32 stride, ScFontCharTable** phCharTable, i32 rangeMin, i32 rangeMax, i32 c_print_debug_info);

ScFont
sc_font_new(ScFontConfig cfg)
{
    // DOCS: should always be enabled or vulkan
    // image creation process will crash.
    const i32 c_convert_to_rgba = 1;
    const i32 c_print_debug_info = 0;
    const i32 c_write_file_to_disk = 0;

    const char* pPath = cfg.pPath;
    i32 fontSize = cfg.FontSize;
    i32 minRange = cfg.RangeMin;
    i32 maxRange = cfg.RangeMax;
    void* pData = cfg.pData;

    i8 is_data_allocated = 0;
    char* pFileContent = NULL;
    if (pPath == NULL)
    {
        sc_assert_not_null(pData);
        pFileContent = pData;
    }
    else
    {
        pFileContent = sc_file_read(pPath);
        is_data_allocated = 1;
    }

    i64 symbolsCount = maxRange - minRange + 1;
    i32 half = symbolsCount / 2;
    i32 otherHalf = symbolsCount - half;
    i32 slices = (i32)ceil(sqrt(symbolsCount));

    const i32 estimated_glyph_size = fontSize + 2; // +2 для паддинга
    const f32 c_bitmap_width = slices * estimated_glyph_size;
    const f32 c_bitmap_height = slices * estimated_glyph_size;
    void* pBitmap = sc_memory_allocate(c_bitmap_width * c_bitmap_height);

    if (c_print_debug_info)
    {
        sc_log_warn("Pixel dim for bitmap is %0.0fx%0.0f\n", c_bitmap_width, c_bitmap_height);
    }

    stbtt_bakedchar* aCharDatas = NULL;
    ScFontCharTable* hCharTable = NULL;

    i32 result = make_bitmap(
        (unsigned char*)pFileContent,
        0,
        fontSize,
        pBitmap,
        c_bitmap_width,
        c_bitmap_height,
        1,
        &hCharTable,
        minRange,
        maxRange,
        c_print_debug_info);
    if (result <= 0)
    {
        if (c_print_debug_info)
            sc_log_erro("Problem with font %s\n", pPath);
        sc_guard(0);
    }

    // DOCS: 1 byte r -> 4 byte rgba
    i32 channelStride = 1;
    if (c_convert_to_rgba)
    {
        void* pRgbaBitmap = sc_memory_allocate(c_bitmap_width * c_bitmap_height * 4);
        i32 width = c_bitmap_width;
        i32 height = c_bitmap_height;

        struct Rgba
        {
            u8 R;
            u8 G;
            u8 B;
            u8 A;
        };

        struct R
        {
            u8 R;
        };

        struct R* pRead = pBitmap;
        struct Rgba* pWrite = pRgbaBitmap;

        for (i32 y = 0; y < height; ++y)
        {
            for (i32 x = 0; x < width; ++x)
            {
                u8 r = pRead->R;

                if (r == 0)
                {
                    pWrite->R = 0;
                    pWrite->G = 0;
                    pWrite->B = 0;
                    pWrite->A = 0;
                }
                else
                {
                    // GINFO("rgb (%d %d %d)\n", r, g, b);
                    pWrite->R = r;
                    pWrite->G = r;
                    pWrite->B = r;
                    pWrite->A = r;
                }

                ++pWrite;
                ++pRead;
            }
        }

        sc_memory_free(pBitmap);
        pBitmap = pRgbaBitmap;
        channelStride = 4;
    }

    if (c_write_file_to_disk)
    {
        char buf[1024] = {};
        snprintf(buf, 1024, "Resources/Fonts/Atlas-%s-%d-r-%d-%d.png", channelStride == 4 ? "alpha" : "opaque", fontSize, minRange, maxRange);
        sc_log_info(">Before write!\n");
        if (!stbi_write_png(buf, c_bitmap_width, c_bitmap_height, channelStride, pBitmap, c_bitmap_width * channelStride))
        {
            if (c_print_debug_info)
                sc_log_erro("Failed to write an image!\n");
        }
        else if (c_print_debug_info)
        {
            sc_log_succ(">After write!\n");
            sc_log_info("Write into %s\n", buf);
        }
    }

    ScFont safFont = {
        .pName = sc_string_new((char*)pPath),
        .hCharTable = hCharTable,
        .pBitmap = pBitmap,
        .Size = { c_bitmap_width, c_bitmap_height },
        .FontSize = fontSize,
        .RangeMin = minRange,
        .RangeMax = maxRange,
    };

    if (is_data_allocated)
    {
        sc_memory_free(pFileContent);
    }

    return safFont;
}

void
sc_font_destroy(ScFont scFont)
{
    sc_memory_free(scFont.pBitmap);
    sc_dict_free(scFont.hCharTable);
    sc_string_destroy(scFont.pName);
}

static i32
make_bitmap(
    unsigned char* pData,   //
    i32 offset,             // DOCS: font location (use 0 for plain .ttf)
    f32 pixel_height,       // DOCS: height of font in pixels
    unsigned char* pBitmap, //
    i32 bitmapWidth,
    i32 bitmapHeight,
    i32 stride, // bitmap to be filled in
    ScFontCharTable** phCharTable,

    i32 rangeMin,
    i32 rangeMax,
    i32 c_print_debug_info)
{
    ScFontCharTable* hCharTable = NULL;

    int x, y, bottom_y;

    stbtt_fontinfo f;
    f.userdata = NULL;

    if (!stbtt_InitFont(&f, pData, offset))
        return 0;

    // STBTT_memset(pixels, 0, pw*ph); // background of 0 around pixels
    memset(pBitmap, 0, bitmapWidth * bitmapHeight);

    x = y = 1;
    bottom_y = 1;

    f32 scale = stbtt_ScaleForPixelHeight(&f, pixel_height);

    for (i64 unicode = rangeMin; unicode <= rangeMax; ++unicode)
    {
        int advance, lsb, x0, y0, x1, y1, gw, gh;
        int g = stbtt_FindGlyphIndex(&f, unicode);

        if (unicode == 32 && g == 0)
        {
            if (c_print_debug_info)
                sc_log_erro("No space char!!!\n");
            sc_guard(0);
        }

        if (g == 0)
            continue;

        stbtt_GetGlyphHMetrics(&f, g, &advance, &lsb);
        stbtt_GetGlyphBitmapBox(&f, g, scale, scale, &x0, &y0, &x1, &y1);
        gw = x1 - x0;
        gh = y1 - y0;

        if (x + gw + 1 >= bitmapWidth) // advance to next row
        {
            y = bottom_y, x = 1;
        }
        if (y + gh + 1 >= bitmapHeight) // check if it fits vertically AFTER potentially moving to next row
        {
            if (c_print_debug_info)
                sc_log_warn("Font atlas too small, failed at codepoint %d", unicode);
            return -unicode;
        }
        // STBTT_assert(x+gw < pw);
        // STBTT_assert(y+gh < ph);

        stbtt_MakeGlyphBitmap(&f, pBitmap + x + y * bitmapWidth * stride, gw, gh, bitmapWidth * stride, scale, scale, g);

        ScFontChar scFontChar = {
            .Codepoint = unicode,

            .X0 = (u16)x,
            .Y0 = (u16)y,
            .X1 = (u16)(x + gw),
            .Y1 = (u16)(y + gh),

            .Xadvance = scale * advance,
            .Xoff = (f32)x0,
            .Yoff = (f32)y0,
        };
        sc_dict_i_add(hCharTable, unicode, scFontChar);

        x = x + gw + 1;

        if (y + gh + 1 > bottom_y)
            bottom_y = y + gh + 1;
    }

    *phCharTable = hCharTable;

    return bottom_y;
}

v2
sc_font_get_space_metrics(ScFont scFont)
{
    ScFontChar scFontChar;

    i32 key = 32;
    if (sc_dict_i_contains(scFont.hCharTable, key))
    {
        scFontChar = sc_dict_i_get(scFont.hCharTable, key);
    }
    else
    {
        scFontChar = sc_dict_i_get(scFont.hCharTable, scFont.RangeMin + 1);
    }

    v2 spaceMetrics = v2_new(scFontChar.Xadvance, to_f32(scFontChar.Y1 - scFontChar.Y0));
    return spaceMetrics;
}

v2
sc_font_get_metrics(ScFont safFont, char* pText)
{
    i64 textLength = sc_utf8_length(pText);
    i32* pAllocated = NULL;
    if (textLength <= 1024)
    {
        static i32 aUnicodeText[1024] = {};
        pAllocated = aUnicodeText;
    }
    else
    {
        pAllocated = sc_memory_allocate(textLength * sizeof(i32));
    }

    sc_utf8_get_unicode_text(pAllocated, pText, &textLength);

    // DOCS: Calc metrics
    f32 width = 0.0f;
    f32 height = 0.0f;
    const i32 is_newline_char = (i32)'\n';
    const i32 is_whitespace_char = (i32)' ';

    for (i32 i = 0; i < textLength; ++i)
    {
        i32 wc = pAllocated[i];

        ScFontChar scFontChar = sc_dict_i_get(safFont.hCharTable, (i32)wc);
        i32 tableInd = sc_dict_index(safFont.hCharTable);

        if (wc == is_newline_char)
        {
            // height += safChar.->MaxHeight + value.Offset.Y;
        }
        else if (wc != is_whitespace_char)
        {
            if (tableInd == -1)
            {
                wchar_t charBuf[2] = {
                    [0] = wc,
                    [1] = '\0'
                };
                sc_log_erro("Can't find %d symbol in hash table!\n", (i32)wc);
                sc_log_erro("i: %d ind: %d wci: %d char: %ls\n", i, tableInd, wc, charBuf);
                sc_guard(tableInd != -1 && "No char!");
            }

#if 1
            width += scFontChar.Xadvance;
#else
            width += safChar.X1 - safChar.X0;
#endif

            f32 cHeight = (scFontChar.Y1 - scFontChar.Y0);
            height = ScMax(height, cHeight);
        }
        else
        {
            v2 spaceMetrics = sc_font_get_space_metrics(safFont);
            width += spaceMetrics.X;
        }
    }

    v2 metrics = v2_new(width, height);

    if (textLength > 1024)
    {
        sc_memory_free(pAllocated);
    }

    return metrics;
}

ScFontWrapper
sc_font_wrapper_new(ScFontWrapperConfig cfg)
{
    ScFont* pFont = cfg.pFont;
    if (pFont == NULL)
    {
        sc_log_erro("cfg.pFont == NULL!\n");
        sc_assert_break();
    }

    char* pText = cfg.pFullText;
    if (pText == NULL || *pText == '\0')
    {
        sc_log_erro("cfg.pFullText == NULL or empty!\n");
        sc_assert_break();
    }

    if (cfg.WrapWidth <= 0)
    {
        sc_log_erro("cfg.WrapWidth == 0!\n");
        sc_assert_break();
    }

    ScFontWrapper wrapper = {
        .pFont = cfg.pFont,
        .pFullText = cfg.pFullText,
        .WrapWidth = cfg.WrapWidth,

        .pIterText = cfg.pFullText,
        .pPrevIterText = cfg.pFullText,
    };
    return wrapper;
}

ScFontWrapState
sc_font_wrap_text(ScFontWrapper* pWrapper)
{
#define GetIterLen(pWrap) (pWrap->pIterText - pWrap->pPrevIterText)

    ScFont* pFont = pWrapper->pFont;
    f32 wrapWidth = pWrapper->WrapWidth;
    v2 spaceMetrics = sc_font_get_space_metrics(*pFont);

    f32 currentWidth = 0;
    char* pLastSpace = NULL;

    // DOCS: Trim leading whitespace
    while (*pWrapper->pIterText == ' ' || *pWrapper->pIterText == '\t')
    {
        ++pWrapper->pIterText;
        pWrapper->pPrevIterText = pWrapper->pIterText;
    }

    while (*pWrapper->pIterText != '\0')
    {
        // DOCS: Newline — emit current line and return
        if (*pWrapper->pIterText == '\n')
        {
            pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, GetIterLen(pWrapper));
            ++pWrapper->pIterText;
            pWrapper->pPrevIterText = pWrapper->pIterText;
            return ScFontWrapState_Newline;
        }

        i32 bytesCount = 0;
        u32 codepoint = sc_utf8_decode(pWrapper->pIterText, &bytesCount);

        if (codepoint == (u32)' ')
        {
            f32 advance = spaceMetrics.X;

            if (currentWidth + advance > wrapWidth)
            {
                // DOCS: Space overflows — wrap at previous word boundary
                if (pLastSpace != NULL)
                {
                    pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, pLastSpace - pWrapper->pPrevIterText);
                    pWrapper->pPrevIterText = pLastSpace + 1;
                    pWrapper->pIterText = pWrapper->pPrevIterText;
                    return ScFontWrapState_Wrapped;
                }
                // DOCS: No previous boundary — break before this space
                pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, GetIterLen(pWrapper));
                ++pWrapper->pIterText;
                pWrapper->pPrevIterText = pWrapper->pIterText;
                return ScFontWrapState_Wrapped;
            }

            currentWidth += advance;
            pLastSpace = pWrapper->pIterText;
        }
        else
        {
            f32 advance = 0;
            i32 key = (i32)codepoint;
            if (sc_dict_i_contains(pFont->hCharTable, key))
            {
                ScFontChar fontChar = sc_dict_get_current(pFont->hCharTable);
                advance = fontChar.Xadvance;
            }

            if (currentWidth + advance > wrapWidth)
            {
                // DOCS: Non-space overflows
                if (pLastSpace != NULL)
                {
                    // DOCS: Wrap at previous word boundary
                    pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, pLastSpace - pWrapper->pPrevIterText);
                    pWrapper->pPrevIterText = pLastSpace + 1;
                    pWrapper->pIterText = pWrapper->pPrevIterText;
                    return ScFontWrapState_Wrapped;
                }

                // DOCS: Word too long, hard break
                if (GetIterLen(pWrapper) == 0)
                {
                    // DOCS: First char doesn't fit — emit it anyway
                    pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, bytesCount);
                    pWrapper->pIterText += bytesCount;
                    pWrapper->pPrevIterText = pWrapper->pIterText;
                    return ScFontWrapState_Wrapped;
                }

                // DOCS: Break mid-word at accumulated text
                pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, GetIterLen(pWrapper));
                pWrapper->pPrevIterText = pWrapper->pIterText;
                return ScFontWrapState_Wrapped;
            }

            currentWidth += advance;
        }

        pWrapper->pIterText += bytesCount;
    }

    // DOCS: End of text — emit remaining line
    if (GetIterLen(pWrapper) > 0)
    {
        pWrapper->View = sc_string_view_new(pWrapper->pPrevIterText, GetIterLen(pWrapper));
        pWrapper->pPrevIterText = pWrapper->pIterText;
        return ScFontWrapState_Wrapped;
    }

#undef GetIterLen
    return ScFontWrapState_Empty;
}
