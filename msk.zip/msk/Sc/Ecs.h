#ifndef SC_ECS_H
#define SC_ECS_H

/*
DOCS: Не защищает данные, только метаданные ecs.
При многопоточном использовании требуется доп синхронизация.
*/

#include "Types.h"

#define SC_ECS_DEBUG

// DOCS: Защита от передачи несуществующих типов.
// Как правило они передаются как опечатки в коде:
// TrasnformComponent вместо TransformComponent.
#define sc_ecs_ctos(componentType) ({ (void)sizeof(componentType); #componentType; })

#define ScEcsInvalidId (-1)
#define ScEcsComponentBeginId (0)
/*  DOCS: If we change this value, we also need to modify
bitset512 Mask; field inside ScEcsEntity struct.*/
#define ScEcsComponentEndId (512)
#define ScEcsEntityBeginId (ScEcsComponentEndId + 1)
#define ScEcsEntityEndId (SC_I32_MAX)

typedef i64 ScEcsEntityId;
typedef i16 ScEcsComponentId;

//                   World

void sc_ecs_world_create();
void sc_ecs_world_destroy();

//                   Component

#define sc_ecs_world_register_component(comp) \
    sc_ecs_world_register_component_ext(#comp, sizeof(comp))
i32 sc_ecs_world_register_component_ext(const char* pComponent, u64 componentSize);
#define sc_ecs_world_get_all_component_data(comp) \
    (comp*)sc_ecs_world_get_all_component_data_ext(#comp)
void* sc_ecs_world_get_all_component_data_ext(const char* pComponent);
#define sc_ecs_get_all_entity_ids(...) \
    sc_ecs_world_get_all_entity_ids_ext(#__VA_ARGS__)
ScEcsEntityId* sc_ecs_world_get_all_entity_ids_ext(const char* pComponent);
void* sc_ecs_world_get_all_components_ext(const char* pComponent);

//                   Entity

ScEcsEntityId sc_ecs_entity_new();
void sc_ecs_entity_destroy(ScEcsEntityId id);
#define sc_ecs_entity_set(entity, comp, ...) \
    ({                                       \
        comp temp = __VA_ARGS__;             \
        sc_ecs_entity_set_ext(               \
            entity,                          \
            sc_ecs_ctos(comp),               \
            &temp,                           \
            sizeof(temp));                   \
    })
#define sc_ecs_entity_has(entity, comp) \
    sc_ecs_entity_has_ext(entity, sc_ecs_ctos(comp))
#define sc_ecs_entity_set_by_id(entity, id, comp, ...) \
    ({                                                 \
        comp temp = __VA_ARGS__;                       \
        sc_ecs_entity_set_by_id_ext(                   \
            entity,                                    \
            id,                                        \
            &temp,                                     \
            sizeof(temp));                             \
    })
#define sc_ecs_entity_has_by_id(entity, id) \
    sc_ecs_entity_has_by_id_ext(entity, id)
#define sc_ecs_entity_get(entity, comp) \
    (comp*)sc_ecs_entity_get_ext(entity, #comp)
#define sc_ecs_entity_get_by_id(entity, compId) \
    sc_ecs_entity_get_by_id_ext(entity, compId)

#define sc_ecs_entity_remove_component(entity, comp) \
    sc_ecs_entity_remove_component_ext(entity, #comp)

i32 sc_ecs_entity_set_ext(ScEcsEntityId entity, const char* pComponentName, void* pData, u64 size);
i32 sc_ecs_entity_has_ext(ScEcsEntityId entityId, const char* pComponentName);
i32 sc_ecs_entity_set_by_id_ext(ScEcsEntityId entity, ScEcsComponentId id, void* pData, u64 size);
i32 sc_ecs_entity_has_by_id_ext(ScEcsEntityId entityId, ScEcsComponentId componentId);
void* sc_ecs_entity_get_ext(ScEcsEntityId entityId, const char* pComponent);
void* sc_ecs_entity_get_by_id_ext(ScEcsEntityId entityId, ScEcsComponentId componentId);
i32 sc_ecs_entity_remove_component_ext(ScEcsEntityId id, const char* pComponentName);

//            Component / Entities Ids

ScEcsComponentId sc_ecs_component_name_to_id(const char* pName);
const char* sc_ecs_component_id_to_name(ScEcsComponentId id);

// DOCS: Размер компонента в байтах (0, если id невалиден).
u64 sc_ecs_component_size(ScEcsComponentId id);

// DOCS: сколько компонентов зарегистрировано (граница обхода for component in Components)
i32 sc_ecs_components_count();

i32 sc_ecs_entity_id_validate(ScEcsEntityId id);
i32 sc_ecs_component_id_validate(ScEcsComponentId id);

i64 sc_ecs_entity_id_to_index(ScEcsEntityId id);
i64 sc_ecs_component_id_to_index(ScEcsComponentId id);

ScEcsEntityId sc_ecs_entity_index_to_id(i64 index);
ScEcsComponentId sc_ecs_component_index_to_id(i64 index);

#endif // SC_ECS_H
