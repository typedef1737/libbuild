#ifndef SC_JSON_H
#define SC_JSON_H

#include "Types.h"

typedef enum
{
    ScJsonTokenType_Undefined = 0,

    ScJsonTokenType_Key,

    ScJsonTokenType_Int,
    ScJsonTokenType_Int_Exp,
    ScJsonTokenType_Float,
    ScJsonTokenType_Float_Exp,
    ScJsonTokenType_String_Ascii,
    ScJsonTokenType_String_Unicode,
    ScJsonTokenType_Bool_True,
    ScJsonTokenType_Bool_False,
    ScJsonTokenType_Null,
    ScJsonTokenType_Array,
    ScJsonTokenType_Object,

    ScJsonTokenType_End,

    ScJsonTokenType_Count,
} ScJsonTokenType;

typedef enum
{
    ScJsonError_None = 0,
    ScJsonError_NotEnoughtMemory,
    ScJsonError_NotValidJson,
    ScJsonError_HexInvalid,
    ScJsonError_EscapeCharNotAllowed,
    ScJsonError_MistakeInParser,
    ScJsonError_WrongStartCharacter,
    ScJsonError_TokensArrayIsNotAllocated, // WrongInputParams
} ScJsonError;

typedef struct
{
    ScJsonTokenType Type;
    i32 Parent;
    union
    {
        i32 Start;
        i32 StartInd;
    };

    union
    {
        i32 End;
        i32 EndInd;
    };
} ScJsonToken;

typedef struct
{
    const char* pText;
    u64 TextLength;
    u64 TokensCount;
    ScJsonToken* aTokens;
    ScJsonError ErrorType;
} ScJsonConfig;

#define sc_json_token_length(token) ({ token.End - token.Start + 1; })
#define sc_json_text(pText, ind) ({ (char*)(pText + ind); })

void sc_json_parse(ScJsonConfig* pCfg);

i32 sc_json_object_token_length(ScJsonToken* aTokens, i32 objIndex, i32 tokensCount);
i32 sc_json_array_token_length(ScJsonToken* aTokens, i32 tokensCount, i32 arrayIndex);
i32 sc_json_object_token_keys_count(ScJsonToken* aTokens, i32 objIndex, i32 tokensCount);

const char* sc_json_token_type_to_string(ScJsonTokenType type);
const char* sc_json_error_to_string(ScJsonError type);

/*
    #############################
  : ###        BACK-END       ###
    #############################
*/

/* Parsing */
char* sc_json_token_string(ScJsonToken* aTokens, i32* pInd, char* pJson);
i32 sc_json_token_int(ScJsonToken* aTokens, i32* pInd, char* pJson);
f32 sc_json_token_float(ScJsonToken* aTokens, i32* pInd, char* pJson);
f32* sc_json_token_float_array(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
i32* sc_json_token_int_array(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
v3o sc_json_token_v3o(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);
v4o sc_json_token_v4o(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson);

#endif // SC_JSON_H
