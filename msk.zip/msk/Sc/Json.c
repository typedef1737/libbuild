#include "Json.h"
#include "Sc.h"
#include <string.h>

/*
    #############################
  DOCS: ###       FRONT-END       ###
    #############################
*/

static void
sc_json_add_token(ScJsonToken* aTokens, i32* pCurrentToken, ScJsonToken token)
{
    i64 current = *pCurrentToken;
    aTokens[current] = token;
    *pCurrentToken = (current + 1);
}

static u32
sc_json_str4_to_u32(const char* ptr)
{
    u32* pU32 = (u32*)ptr;
    return *pU32;
}

/* todo:
 * parse array
 * parse ascii escape char \t \r in string
 * parse unicode char inside string
 */
void
sc_json_parse(ScJsonConfig* pCfg)
{
    const char* text = pCfg->pText;
    ScJsonToken* aTokens = pCfg->aTokens;
    u64 textLength = pCfg->TextLength;
    u64 tokensCount = pCfg->TokensCount;

    i32 currentToken = 0;
    ScJsonError error = ScJsonError_None;

    u32 trueAsU32 = sc_json_str4_to_u32("true");
    u32 nullAsU32 = sc_json_str4_to_u32("null");
    // f will be known value at this time
    u32 falsAsU32 = sc_json_str4_to_u32("alse");

    // todo: validate
    if (!aTokens)
    {
        error = ScJsonError_TokensArrayIsNotAllocated;
        goto SFJParseJsonEndLabel;
    }

#define NextToken(passedPtr, passedChar) \
    ++pos;                               \
    ++passedPtr;                         \
    passedChar = *passedPtr;

#define SkipDigits(ptr, c, atLeastOne) \
    {                                  \
        u8 uc = (u8)(c - '0');         \
        while (uc < 10 && c != '\0')   \
        {                              \
            NextToken(ptr, c);         \
            uc = (u8)(c - '0');        \
            atLeastOne = 1;            \
        }                              \
    }

#define ReturnError(errType) \
    error = errType;         \
    goto SFJParseJsonEndLabel;

#define IsHex(c)                                                                                \
    ({                                                                                          \
        i32 isHex = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c > -'a' && c <= 'z'); \
        isHex;                                                                                  \
    })

    // parser state
    i32 pos = 0;
    char* ptr = (char*)text;
    char c = *ptr;
    i32 parent = -1;

    // note: skip("\t \n") and validate(first character) it should be { or [
    // otherwise return error error = SFJErrorType_NotValidJson;
    while ((c == ' ' || c == '\t' || c == '\r' || c == '\n') && c != '\0')
    {
        NextToken(ptr, c);
    }
    if (c != '{' && c != '[')
    {
        ReturnError(ScJsonError_WrongStartCharacter);
    }

    enum KeyState
    {
        KeyState_NotKey = 0,
        KeyState_Key,
        KeyState_InsideArray
    };

    enum KeyState keyState = KeyState_NotKey;
    while (c != '\0')
    {
        while (c == ' ' || c == '\t' || c == '\r')
        {
            NextToken(ptr, c);
        }

        if ((currentToken + 1) >= tokensCount)
        {
            ReturnError(ScJsonError_NotEnoughtMemory);
        }

        switch (c)
        {
        case ':':
            NextToken(ptr, c);
            keyState = KeyState_NotKey;
            break;

        case ',':
        case '\n':
            if (keyState != KeyState_InsideArray)
                keyState = KeyState_Key;
            NextToken(ptr, c);
            break;

        case '{':
        {
            ScJsonToken token = {
                .Type = ScJsonTokenType_Object,
                .StartInd = pos,
                .EndInd = -1,
                .Parent = parent,
            };

            parent = currentToken;
            sc_json_add_token(aTokens, &currentToken, token);

            NextToken(ptr, c);

            keyState = KeyState_Key;

            break;
        }

        case '}':
        {
            if (parent == -1)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            // DOCS: parent всегда указывает на текущий открытый контейнер,
            // поэтому закрываем именно его (работает и для пустого {}).
            ScJsonToken* pObjToken = &aTokens[parent];
            if (pObjToken->Type != ScJsonTokenType_Object || pObjToken->End != -1)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            pObjToken->EndInd = pos; // currentToken;
            parent = pObjToken->Parent;

            NextToken(ptr, c);

            break;
        }

        case '[':
        {
            ScJsonToken token = {
                .Type = ScJsonTokenType_Array,
                .Start = pos,
                .End = -1,
                .Parent = parent,
            };

            parent = currentToken;
            sc_json_add_token(aTokens, &currentToken, token);

            NextToken(ptr, c);

            keyState = KeyState_InsideArray;

            break;
        }

        case ']':
        {
            if (parent == -1)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            // DOCS: закрываем текущий открытый контейнер (работает и для пустого []).
            ScJsonToken* pArrObj = &aTokens[parent];
            if (pArrObj->Type != ScJsonTokenType_Array || pArrObj->End != -1)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            pArrObj->EndInd = pos; // currentToken;
            parent = pArrObj->Parent;

            NextToken(ptr, c);
            keyState = KeyState_NotKey;

            break;
        }

        case '"':
        {
            // note: skip first \"
            NextToken(ptr, c);

            i32 startPos = pos;
            ScJsonTokenType tokenType = ScJsonTokenType_String_Ascii;
            if (keyState == KeyState_Key)
            {
                tokenType = ScJsonTokenType_Key;
            }

            while (c != '\0')
            {
                if (c == '"')
                {
                    ScJsonToken token = {
                        .Type = tokenType,
                        .Start = startPos,
                        .End = pos - 1,
                        .Parent = parent
                    };

                    sc_json_add_token(aTokens, &currentToken, token);

                    break;
                }
                else if (c == '\\')
                {
                    // DOCS: escaped characters
                    NextToken(ptr, c);

                    /*
                      \0 Null;
                      \a Bell;
                      \b Backspace;
                      \t Horizontal Tabulation;
                      \n New Line;
                      \v Vertical Tabulation;
                      \f Form Feed;
                      \r Carriage Return.
                    */
                    switch (c)
                    {

                    case 't':
                    case 'n':
                    case 'r':
                    case 'b':
                    case 'v':
                    case 'f':
                    case '\"':
                    case '\'':
                    case '\\':
                    case '/':
                        break;

                    // note: handle unicode
                    case 'u':
                    {
                        for (i32 ui = 0;
                            (ui < 4 && c != '\0');
                            ++ui)
                        {
                            i32 isHex = IsHex(c);
                            if (!isHex)
                            {
                                ReturnError(ScJsonError_HexInvalid);
                            }
                        }

                        tokenType = ScJsonTokenType_String_Unicode;

                        break;
                    }

                    default:
                        ReturnError(ScJsonError_EscapeCharNotAllowed);
                        break;
                    }
                }

                NextToken(ptr, c);
            }

            // not sure we need this
            NextToken(ptr, c);

            break;
        }

        case 't':
        {
            i32 startPos = pos;

            u32 ptrU32 = sc_json_str4_to_u32(ptr);
            i32 isEqual = (ptrU32 == trueAsU32);
            if (!isEqual)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            pos += 5;
            ptr += 5;
            c = *ptr;

            ScJsonToken token = {
                .Type = ScJsonTokenType_Bool_True,
                .Start = startPos,
                .End = startPos + 3,
                .Parent = parent
            };

            sc_json_add_token(aTokens, &currentToken, token);

            break;
        }

        case 'f':
        {
            i32 startPos = pos;

            ++pos;
            ++ptr;
            u32 ptrU32 = sc_json_str4_to_u32(ptr);

            i32 isEqual = (ptrU32 == falsAsU32);
            if (!isEqual)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            pos += 5;
            ptr += 5;
            c = *ptr;

            ScJsonToken token = {
                .Type = ScJsonTokenType_Bool_False,
                .Start = startPos,
                .End = startPos + 4,
                .Parent = parent
            };

            sc_json_add_token(aTokens, &currentToken, token);

            break;
        }

        case 'n':
        {
            i32 startPos = pos;
            u32 ptrU32 = sc_json_str4_to_u32(ptr);
            i32 isEqual = ((ptrU32 ^ nullAsU32) == 0);
            if (!isEqual)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            ptr += 4;
            pos += 4;
            c = *ptr;

            ScJsonToken token = {
                .Type = ScJsonTokenType_Null,
                .Start = startPos,
                .End = pos - 1,
                .Parent = parent
            };

            sc_json_add_token(aTokens, &currentToken, token);

            break;
        }

        case '-':
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        {
            // note: cost ~300 mb/s
            i32 startPos = pos;
            ScJsonTokenType type = ScJsonTokenType_Int;

            i32 sign = 1;
            if (c == '-')
            {
                sign = -1;
                NextToken(ptr, c);
            }

            //
            /*
              at least should be 0
              1234
              1234.5
              0.5
            */

            i32 correctDigitsPart = 0;
            // note: skip int part first
            SkipDigits(ptr, c, correctDigitsPart); // 0000 1010; == 0xA 0X0A0A0A0A

            if (!correctDigitsPart)
            {
                ReturnError(ScJsonError_NotValidJson);
            }

            /* note: fraction part
               fraction:
               ""
               '.' digits
            */
            if (c == '.')
            {
                type = ScJsonTokenType_Float;
                NextToken(ptr, c);
                correctDigitsPart = 0;
                SkipDigits(ptr, c, correctDigitsPart);
            }

            /* note: exponent part
               [Ee][-+]\d+
            */
            if (c == 'E' || c == 'e')
            {
                if (type == ScJsonTokenType_Float)
                    type = ScJsonTokenType_Float_Exp;
                else
                    type = ScJsonTokenType_Int_Exp;

                NextToken(ptr, c);

                i32 isCorrectExp = (c == '-' || c == '+');
                if (!isCorrectExp)
                {
                    ReturnError(ScJsonError_NotValidJson);
                }

                NextToken(ptr, c);

                SkipDigits(ptr, c, isCorrectExp);
                if (!isCorrectExp)
                {
                    ReturnError(ScJsonError_NotValidJson);
                }
            }

            ScJsonToken token = {
                .Type = type,
                .Start = startPos,
                .End = pos - 1,
                .Parent = parent,
            };

            sc_json_add_token(aTokens, &currentToken, token);
            break;
        }

        default:
        {
            //_vbreak("never get here", __FILE__, __LINE__, "BREAK IT ALL!!!");
            NextToken(ptr, c);
            break;
        }
        }
    }

SFJParseJsonEndLabel:
    // note: maybe put it inside struct Output
    pCfg->ErrorType = error;
    pCfg->TokensCount = currentToken;

    ScJsonToken endToken = {
        .Type = ScJsonTokenType_End,
        .Parent = -1,
        .Start = -1,
        .End = -1,
    };
    sc_json_add_token(aTokens, &currentToken, endToken);

#undef NextToken
#undef SkipDigits
#undef ReturnError
#undef IsHex
}

i32
sc_json_object_token_length(ScJsonToken* aTokens, i32 objIndex, i32 tokensCount)
{
    ScJsonToken obj = aTokens[0];
    if (obj.Type != ScJsonTokenType_Object)
        return -1;

    i32 cnt = 0;
    i32 endInd = obj.EndInd;

    for (i32 i = objIndex + 1; i < tokensCount; ++i)
    {
        ScJsonToken token = aTokens[i];
        if (token.StartInd > endInd)
            break;

        ++cnt;
    }

    return cnt;
}

i32
sc_json_object_token_keys_count(ScJsonToken* aTokens, i32 objIndex, i32 tokensCount)
{
    ScJsonToken obj = aTokens[0];
    if (obj.Type != ScJsonTokenType_Object)
        return -1;

    i32 cnt = 0;
    i32 endInd = obj.EndInd;

    for (i32 i = objIndex + 1; i < tokensCount; ++i)
    {
        ScJsonToken token = aTokens[i];

        if (token.StartInd > endInd)
            break;

        if (token.Type != ScJsonTokenType_Key || token.Parent != objIndex)
            continue;

        ++cnt;
    }

    return cnt;
}

i32
sc_json_array_token_length(ScJsonToken* aTokens, i32 tokensCount, i32 arrayIndex)
{
    ScJsonToken array = aTokens[arrayIndex];
    if (array.Type != ScJsonTokenType_Array)
        return -1;

    i32 endInd = array.EndInd;
    i32 count = 0;

    for (i32 t = arrayIndex + 1; t < tokensCount; ++t)
    {
        // TODO: Skip to the end of token
        ScJsonToken token = aTokens[t];

        if (token.StartInd > endInd)
            break;

        if (token.Parent != arrayIndex)
            continue;

        ++count;
    }

    return count;
}

const char*
sc_json_token_type_to_string(ScJsonTokenType type)
{
    switch (type)
    {
    case ScJsonTokenType_Undefined:
        return "Undefined";

    case ScJsonTokenType_Key:
        return "Key";
    case ScJsonTokenType_Int:
        return "Int";
    case ScJsonTokenType_Int_Exp:
        return "Int (Exp)";
    case ScJsonTokenType_Float:
        return "Float";
    case ScJsonTokenType_Float_Exp:
        return "Float (Exp)";
    case ScJsonTokenType_String_Ascii:
        return "String (Ascii)";
    case ScJsonTokenType_String_Unicode:
        return "String (Unicode)";
    case ScJsonTokenType_Bool_True:
        return "Bool_True";
    case ScJsonTokenType_Bool_False:
        return "Bool_False";
    case ScJsonTokenType_Null:
        return "Null";
    case ScJsonTokenType_Array:
        return "Array";
    case ScJsonTokenType_Object:
        return "Object";

    case ScJsonTokenType_Count:
        return "Count";

    default:
        return ScNull;
    }
}

const char*
sc_json_error_to_string(ScJsonError type)
{
    switch (type)
    {
    case ScJsonError_None:
        return "None";
    case ScJsonError_NotEnoughtMemory:
        return "NotEnoughtMemory";
    case ScJsonError_NotValidJson:
        return "NotValidJson";
    case ScJsonError_MistakeInParser:
        return "MistakeInParser";
    case ScJsonError_TokensArrayIsNotAllocated:
        return "TokensArrayIsNotAllocated";

    default:
        return ScNull;
    }
}

/*
    #############################
  : ###        BACK-END       ###
    #############################
*/

char*
sc_json_token_string(ScJsonToken* aTokens, i32* pInd, char* pJson)
{
    i32 ind = *pInd;
    ScJsonToken token = aTokens[ind];
    i64 strLength = sc_json_token_length(token);
    char* pText = sc_json_text(pJson, token.StartInd);
    char* pGenerator = sc_string_new_ext(pText, strLength, strLength);
    *pInd = ind + 1;
    return pGenerator;
}

i32
sc_json_token_int(ScJsonToken* aTokens, i32* pInd, char* pJson)
{
    i32 ind = *pInd;
    ScJsonToken token = aTokens[ind];
    char* pIntString = sc_json_text(pJson, token.StartInd);
    i32 intLength = sc_json_token_length(token);
    i32 value = sc_parse_int(pIntString, intLength);
    *pInd = ind + 1;
    return value;
}

f32
sc_json_token_float(ScJsonToken* aTokens, i32* pInd, char* pJson)
{
    i32 ind = *pInd;
    ScJsonToken token = aTokens[ind];
    char* pIntString = sc_json_text(pJson, token.StartInd);
    i32 intLength = sc_json_token_length(token);
    f32 value = sc_parse_float(pIntString, intLength);
    *pInd = ind + 1;
    return value;
}

f32*
sc_json_token_float_array(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    i32 ind = *pInd;
    ScJsonToken arrayToken = aTokens[ind];
    i32 arrayCount = sc_json_array_token_length(aTokens, tokensCount, ind);

    f32* aValues = NULL;

    ++ind;
    for (i32 i = 0; i < arrayCount; ++i)
    {
        ScJsonToken itemToken = aTokens[ind];
        char* pValue = sc_json_text(pJson, itemToken.StartInd);
        i32 valueLength = sc_json_token_length(itemToken);
        f32 value = sc_parse_float(pValue, valueLength);
        sc_list_add(aValues, value);
        ++ind;
    }

    *pInd = ind;
    return aValues;
}

i32*
sc_json_token_int_array(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    i32 ind = *pInd;
    ScJsonToken arrayToken = aTokens[ind];
    i32 arrayCount = sc_json_array_token_length(aTokens, tokensCount, ind);

    i32* aValues = NULL;

    ++ind;
    for (i32 i = 0; i < arrayCount; ++i)
    {
        ScJsonToken itemToken = aTokens[ind];
        char* pValue = sc_json_text(pJson, itemToken.StartInd);
        i32 valueLength = sc_json_token_length(itemToken);
        i32 value = sc_parse_int(pValue, valueLength);
        sc_list_add(aValues, value);
        ++ind;
    }

    *pInd = ind;
    return aValues;
}

v3o
sc_json_token_v3o(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    v3o v = {};

    f32* aValues = sc_json_token_float_array(aTokens, tokensCount, pInd, pJson);
    i32 valuesCount = sc_list_count(aValues);
    if (valuesCount != 3)
    {
        // handle error
        sc_assert_break();
    }

    v.IsSet = 1;
    memcpy(v.Value.V, aValues, valuesCount * sizeof(f32));

    return v;
}

v4o
sc_json_token_v4o(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    v4o v = {};
    f32* aValues = sc_json_token_float_array(aTokens, tokensCount, pInd, pJson);

    if (sc_list_count(aValues) != 4)
    {
        // handle error
        sc_assert_break();
    }

    v.IsSet = 1;
    memcpy(v.Value.V, aValues, sc_list_count(aValues) * sizeof(f32));
    return v;
}
