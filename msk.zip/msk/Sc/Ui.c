#include "Ui.h"
#include "Math.h"
#include "Sc.h"
#include <stdio.h>
#include <string.h>

typedef struct
{
    struct
    {
        struct
        {
            const char* Key;
            char* Value;
        }* hAllocatedStrings;
        ScArena* pArena;
    } Allocated;

    struct
    {
        i32 WidgetBeginEndCounter;
        i32 CurrentWidgetInd;
        ScUiWidget* aWidgets;
        ScUiWidgetState* aWidgetStates;
    } WidgetCache;

    ScUiInteractive Interactive;

    struct
    {
        ScUiBackendState State;
        ScUiBackendRender Render;
        ScUiInput Input;
    } Back;
} ScUiGlobal;

static ScUiGlobal g = {};

i32 sc_ui_is_key_released(ScUiKey key);
i32 sc_ui_is_key_pressed(ScUiKey key);
void sc_ui_input_clear(ScUiInput* pInput);
i64 sc_ui_string_hash(char* pStr);
char* sc_ui_string_new(char* pStr);
char* sc_ui_frame_string_new(char* pString);
ScSid sc_ui_csid_new(char* pStr);
i32 sc_ui_panel_get_by_hash(i64 hash);
ScUiWidget* sc_ui_widget_get_current();
ScUiWidget* sc_ui_widget_get_child_by_index(ScUiWidget* pWidget, i16 childInd);
void sc_ui_widget_add_state(ScUiState state, i64 hash);
void msg_erro(ScUiWidget* pWidget, const char* pMessage);
void msg_warn(ScUiWidget* pWidget, const char* pMessage);

ScUiWidget*
sc_ui_widget_get_child_by_index(ScUiWidget* pWidget, i16 childInd)
{
#if defined(SC_BUILD_DEBUG)
    i64 widgetsCount = sc_list_count(g.WidgetCache.aWidgets);
    i64 childrenCount = sc_list_count(pWidget->aChildren);
    if (childInd < 0 || childInd >= widgetsCount || childInd >= childrenCount)
    {
        sc_log_erro("Current widget index out of bound! widgetInd=%d(cnt:%ld)\n", childInd, widgetsCount);
        sc_assert_break();
    }

    i64 childHash = pWidget->aChildren[childInd];
    for (i64 w = 0; w < widgetsCount; ++w)
    {
        ScUiWidget* pChild = &g.WidgetCache.aWidgets[w];
        if (pChild->Id.Hash == childHash)
        {
            return pChild;
        }
    }
#else
#warning "Configure for release build!"
#endif

    return NULL;
}

ScUiWidget*
sc_ui_widget_get_by_index(i64 index)
{
#if defined(SC_BUILD_DEBUG)
    i64 widgetsCount = sc_list_count(g.WidgetCache.aWidgets);
    if (index < 0 || index >= widgetsCount)
    {
        sc_log_erro("Current widget index out of bound! widgetInd=%d(cnt:%ld)\n", index, widgetsCount);
        sc_assert_break();
    }
#endif

    return &g.WidgetCache.aWidgets[index];
}

void
sc_ui_widget_print(ScUiWidget* aWidgets, i32 tab)
{
    const char* aTabs[] = {
        "",
        "  ",
        "    ",
        "      ",
        "        ",
        "          ",
        "            ",
        "              ",
        "                ",
        "                  ",
        "                    ",
        "                      ",
        "                        ",
    };

    ScUiWidget* pRoot = &aWidgets[0];
    i32 bytes = printf("%s|%s-%s| pos: {" ScTerminalRed("%0.0f") ", " ScTerminalRed("%0.0f") "} size: {" ScTerminalGreen("%0.0f") ", " ScTerminalGreen("%0.0f") "}", aTabs[tab], sc_ui_widget_type_to_string(pRoot->Config.Type), pRoot->Config.Layout.Direction == ScUiDirection_Vertical ? "V" : "H", pRoot->X, pRoot->Y, pRoot->Width, pRoot->Height);

    i32 minimal = 85;
    i32 cnt = ScMax(minimal - bytes, 1) + tab;
    for (i32 i = 0; i < cnt; ++i)
        printf(" ");
    printf("%s\n", pRoot->Id.pData);

    for (i32 c = 0; c < sc_list_count(pRoot->aChildren); ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pRoot, c);
        sc_ui_widget_print(pChild, tab + 1);
    }
}

f32
sc_ui_metric_get_value(ScUiMetric metric, i32 isX)
{
    switch (metric.Type)
    {
    case ScUiMetricType_Fixed:
    {
        if (metric.Value <= 1.0)
        {
            v2 ds = g.Back.State.DisplaySize;
            if (isX)
                return metric.Value * ds.Width;
            else
                return metric.Value * ds.Height;
        }
        return metric.Value;
    }
    default:
        return 0;
    }
}

void
sc_ui_widgets_get_position(ScUiWidget* pWidget)
{
    ScUiLayout layout = pWidget->Config.Layout;
    ScUiDirection rootDir = layout.Direction;
    ScUiPad rootPad = layout.Padding;
    i16 childGap = layout.ChildGap;

    f32 rootX = pWidget->X;
    f32 rootY = pWidget->Y;
    f32 rootWidth = pWidget->Width;
    f32 rootHeight = pWidget->Height;
    f32 x = rootX + rootPad.Left;
    f32 y = rootY - rootPad.Top;

    i64 childrenCount = sc_list_count(pWidget->aChildren);
    for (i64 c = 0; c < childrenCount; ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
        ScUiWidgetConfig childCfg = pChild->Config;

        // DOCS: Для текста делаем alignment.
        if (childCfg.Type == ScUiWidgetType_Text)
        {
            v2 metrics = g.Back.Render.GetTextMetrics(childCfg.pText, 0, NULL);
            f32 tw = metrics.Width;
            f32 th = metrics.Height;

            if (childCfg.Horizontal == ScUiTextAlign_X_Center)
                x += (rootWidth - tw) / 2;
            else if (childCfg.Horizontal == ScUiTextAlign_X_Right)
                x = (rootWidth - tw);

            if (childCfg.pText[0] == '-')
                y -= 25;
            else if (childCfg.Vertical == ScUiTextAlign_Y_Center)
                y -= ((rootHeight - th) / 2) * 0;
            else if (childCfg.Vertical == ScUiTextAlign_Y_Bot)
                y -= (rootHeight - th);
        }

        pChild->X = x;
        pChild->Y = y;

        if (pChild->aChildren != NULL)
            sc_ui_widgets_get_position(pChild);

        if (rootDir == ScUiDirection_Horizontal)
        {
            x += pChild->Width + childGap;
        }
        else
        {
            y -= (pChild->Height + childGap);
        }
    }
}

/*     #####################################
  DOCS ##           Interactive           ##
       #####################################*/

i32
sc_ui_is_hovered(v2 pos, f32 width, f32 height)
{
    v2 mousePos = g.Back.Input.MousePosition;
    if (mousePos.X >= pos.X && mousePos.X <= (pos.X + width) && mousePos.Y <= pos.Y && mousePos.Y >= (pos.Y - height))
    {
        return 1;
    }

    return 0;
}

ScUiState
sc_ui_is_pressed(i64 id)
{
    ScUiInteractive* pInteractive = &g.Interactive;

    if (pInteractive->ActiveId == 0 && pInteractive->HotId == 0)
    {
        pInteractive->HotId = id;

        // note: should it be released or pressed
        if (sc_ui_is_key_pressed(ScUiKey_Mouse_Left_Button))
        {
            pInteractive->ActiveId = id;
            pInteractive->IsLeftKeyWasPressed = 1;

            return ScUiState_Clicked;
        }

        return ScUiState_Hovered;
    }
    else if (pInteractive->ActiveId == id)
    {
        return ScUiState_Pressed;
    }

    return ScUiState_None;
}

ScUiState
sc_ui_widget_begin_ext(ScUiWidgetConfig config)
{
    ++g.WidgetCache.WidgetBeginEndCounter;
    config.Color = sc_ui_color_default(config.Color);
    if (config.pText)
        config.pText = sc_ui_frame_string_new(config.pText);

    ScUiWidget newWidget = {
        .Config = config,
        .Id = sc_ui_csid_new(config.pName),
        .Parent = g.WidgetCache.CurrentWidgetInd
    };

    i32 ind = sc_list_count(g.WidgetCache.aWidgets);
    sc_list_add(g.WidgetCache.aWidgets, newWidget);
    ScUiWidget* pWidget = &g.WidgetCache.aWidgets[ind];
    i64 hash = pWidget->Id.Hash;

    // DOCS: If we have parent, go visit it.
    ScUiWidget* pParentWidget = sc_ui_widget_get_current();
    if (pParentWidget != NULL)
    {
        sc_list_add(pParentWidget->aChildren, hash);
    }

    g.WidgetCache.CurrentWidgetInd = ind;
    i32 stateInd = sc_list_index_of(g.WidgetCache.aWidgetStates, item.Id == hash);
    if (stateInd != -1)
    {
        return g.WidgetCache.aWidgetStates[stateInd].State;
    }

    return ScUiState_None;
}

void
sc_ui_widget_end()
{
    --g.WidgetCache.WidgetBeginEndCounter;
    ScUiWidget* pThisWidget = sc_ui_widget_get_current();
    g.WidgetCache.CurrentWidgetInd = pThisWidget->Parent;
}

ScUiState
sc_ui_text_ext(ScUiWidgetConfig cfg)
{
    cfg.Type = ScUiWidgetType_Text;
    ScUiState state = sc_ui_widget_begin_ext(cfg);
    sc_ui_widget_end();
    return state;
}

ScUiState
sc_ui_image_ext(ScUiWidgetConfig cfg)
{
    cfg.Type = ScUiWidgetType_Image;
    ScUiState state = sc_ui_widget_begin_ext(cfg);
    sc_ui_widget_end();
    return state;
}

// ScUiState
// sc_ui_div_ext(ScUiWidgetConfig cfg)
// {
//     cfg.Type = ScUiWidgetType_Rectangle;
//     ScUiState state = sc_ui_widget_begin_ext(cfg);
//     sc_ui_widget_end();
//     return state;
// }

void
sc_ui_widget_unset_state(ScUiWidget* pWidget)
{
    pWidget->State = ScUiState_None;

    i64 arrCount = sc_list_count(pWidget->aChildren);
    for (i64 c = 0; c < arrCount; ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
        sc_ui_widget_unset_state(pChild);
    }
}

void
sc_ui_widget_add_state(ScUiState state, i64 hash)
{
    ScUiWidgetState st = {
        .Id = hash,
        .State = state
    };

    i32 ind = sc_list_index_of(g.WidgetCache.aWidgetStates, item.Id == hash);
    if (ind != -1)
    {
        g.WidgetCache.aWidgetStates[ind] = st;
    }
    else
    {
        sc_list_add(g.WidgetCache.aWidgetStates, st);
    }
}

ScUiState
sc_ui_widget_process_input(ScUiWidget* pWidget)
{
    f32 width = pWidget->Width;
    f32 height = pWidget->Height;
    // v2 pos = pWidget->Position;

    i32 returnValue = 0;
    i32 isAnyChildHovered = 0;
    ScUiState childState = ScUiState_None;

    i64 childrenCount = sc_list_count(pWidget->aChildren);
    for (i64 c = 0; c < childrenCount; ++c)
    {
        // BUG
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);

        v2 childPos = v2_new(pChild->X, pChild->Y);
        f32 childWidth = pChild->Width;
        f32 childHeight = pChild->Height;

        if (!sc_ui_is_hovered(childPos, childWidth, childHeight))
        {
            sc_ui_widget_unset_state(pChild);
            continue;
        }

        childState = ScUiState_Hovered;
        isAnyChildHovered = 1;

        childState = sc_ui_widget_process_input(pChild);
        if (childState == ScUiState_Clicked)
        {
            returnValue = 1;
            // note: continue for unset_state for other childrens
            continue;
        }
    }

    ScUiState globalState = childState;

    if (childState != ScUiState_None)
    {
        pWidget->State = childState;
        if (childState != ScUiState_None)
            sc_ui_widget_add_state(childState, pWidget->Id.Hash);
        return childState;
    }
    else
    {
        ScUiState widgetState = sc_ui_is_pressed(pWidget->Id.Hash);
        pWidget->State = widgetState;
        if (widgetState != ScUiState_None)
            sc_ui_widget_add_state(widgetState, pWidget->Id.Hash);
        return widgetState;
    }

    return globalState;
}

void fit_calc_width(ScUiWidget* pWidget, ScUiWidget* pParent);
// note: shrink is not implemented yet
void grow_shrink_calc_width(ScUiWidget* pWidget);
void wrap_text_pass(ScUiWidget* pWidget);
void fit_calc_height(ScUiWidget* pWidget, ScUiWidget* pParent);
void grow_shrink_calc_height(ScUiWidget* pWidget);

/*
DOCS:
[ScUiWidgetType_Text]
Calc text size based on fontPath, fontSize, pText itself.

[ScUiWidgetType_Rectangle]
[ScUiWidgetType_Image]
[ScUiWidgetType_Atlas]
Calc size bases on absolute value or based on text size inside.
*/

void
fit_calc_width(ScUiWidget* pWidget, ScUiWidget* pParent)
{
    ScUiWidgetConfig cfg = pWidget->Config;
    ScUiLayout layout = pWidget->Config.Layout;
    ScUiDirection direction = layout.Direction;
    ScUiMetric widthMetric = cfg.Size.Width;
    ScUiMetricType metricType = cfg.Size.Width.Type;
    f32 width = 0;

    if (cfg.Type == ScUiWidgetType_Text)
    {
#if defined(SC_BUILD_DEBUG)
        if (pWidget->aChildren != NULL)
        {
            msg_warn(pWidget, "aChildren is setup for text!");
        }
#endif
        // note: set width and height here for now
        v2 size = g.Back.Render.GetTextMetrics(cfg.pText, cfg.FontSize, cfg.pFontPath);
        pWidget->Width = size.X;
        pWidget->Height = size.Y;
        return;
    }

    switch (widthMetric.Type)
    {

    case ScUiMetricType_Fixed:
    {
        pWidget->Width = sc_ui_metric_get_value(widthMetric, 1);
        i64 childrenCount = sc_list_count(pWidget->aChildren);
        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            fit_calc_width(pChild, pWidget);
        }
        break;
    }
    case ScUiMetricType_Fit:
    {
        i64 childrenCount = sc_list_count(pWidget->aChildren);
        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            fit_calc_width(pChild, pWidget);
            if (direction == ScUiDirection_Horizontal)
                width += pChild->Width;
            else
                width = ScMax(width, pChild->Width);
        }

        f32 childGap = layout.ChildGap;
        if (direction == ScUiDirection_Horizontal)
            width += childGap * (childrenCount - 1);
        ScUiPad rootPad = layout.Padding;
        width += rootPad.Left + rootPad.Right;
        pWidget->Width = width;
        break;
    }

    case ScUiMetricType_Grow:
    {
        i64 childrenCount = sc_list_count(pWidget->aChildren);
        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            fit_calc_width(pChild, pWidget);
        }
        break;
    }

    default:
        break;
    }
}

void
grow_shrink_calc_width(ScUiWidget* pWidget)
{
    ScUiLayout layout = pWidget->Config.Layout;
    ScUiDirection rootDirection = layout.Direction;
    i16 width = pWidget->Width;

    i16 growCount = 0;
    i64 childrenCount = sc_list_count(pWidget->aChildren);
    for (i64 c = 0; c < childrenCount; ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
        ScUiWidgetConfig childCfg = pChild->Config;

        if (childCfg.Size.Width.Type == ScUiMetricType_Grow)
        {
            ++growCount;
        }
        else if (rootDirection == ScUiDirection_Horizontal)
        {
            width -= pChild->Width;
        }
    }

    if (growCount > 0)
    {
        ScUiPad pad = layout.Padding;
        i16 widthToGrow = 0;
        if (rootDirection == ScUiDirection_Horizontal)
        {
            width -= (layout.ChildGap * childrenCount + pad.Left + pad.Right);
            widthToGrow = width / growCount;
        }
        else
        {
            widthToGrow = width - (pad.Left + pad.Right);
        }

        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            if (pChild->Config.Size.Width.Type == ScUiMetricType_Grow)
                pChild->Width = widthToGrow;
        }
    }

    for (i64 c = 0; c < childrenCount; ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
        grow_shrink_calc_width(pChild);
    }
}

// note: not implemented
void
wrap_text_pass(ScUiWidget* pWidget)
{
    ScUiWidgetConfig cfg = pWidget->Config;
    if (cfg.Type == ScUiWidgetType_Text)
    {
        v2 size = g.Back.Render.GetTextMetrics(cfg.pText, cfg.FontSize, cfg.pFontPath);
        pWidget->Width = size.X;
        pWidget->Height = size.Y;
    }
}

void
fit_calc_height(ScUiWidget* pWidget, ScUiWidget* pParent)
{
    ScUiWidgetConfig cfg = pWidget->Config;
    ScUiMetric heightMetric = cfg.Size.Height;
    ScUiLayout layout = pWidget->Config.Layout;
    ScUiDirection direction = layout.Direction;

    if (cfg.Type == ScUiWidgetType_Text)
    {
        return;
    }

    switch (heightMetric.Type)
    {

    case ScUiMetricType_Fixed:
    {
        pWidget->Height = sc_ui_metric_get_value(heightMetric, 0);
        i64 childrenCount = sc_list_count(pWidget->aChildren);
        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            fit_calc_height(pChild, pWidget);
        }
        break;
    }

    case ScUiMetricType_Fit:
    {
        f32 height = 0;
        i64 childrenCount = sc_list_count(pWidget->aChildren);
        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            fit_calc_height(pChild, pWidget);
            if (direction == ScUiDirection_Vertical)
                height += pChild->Height;
            else
                height = ScMax(height, pChild->Height);
        }
        f32 childGap = layout.ChildGap;
        if (direction == ScUiDirection_Vertical)
            height += childGap * (childrenCount - 1);
        ScUiPad rootPad = layout.Padding;
        height += rootPad.Top + rootPad.Bot;
        pWidget->Height = height;
        break;
    }

    default:
        break;
    }
}

void
grow_shrink_calc_height(ScUiWidget* pWidget)
{
    ScUiLayout layout = pWidget->Config.Layout;
    ScUiDirection rootDirection = layout.Direction;
    i16 height = pWidget->Height;

    i16 growCount = 0;
    i64 childrenCount = sc_list_count(pWidget->aChildren);
    for (i64 c = 0; c < childrenCount; ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
        ScUiWidgetConfig childCfg = pChild->Config;

        if (childCfg.Size.Height.Type == ScUiMetricType_Grow)
        {
            ++growCount;
        }
        else if (rootDirection == ScUiDirection_Vertical)
        {
            height -= pChild->Height;
        }
    }

    if (growCount > 0)
    {
        ScUiPad pad = layout.Padding;
        i16 heightToGrow = 0;
        if (rootDirection == ScUiDirection_Vertical)
        {
            height -= (layout.ChildGap * childrenCount + pad.Top + pad.Bot);
            heightToGrow = height / growCount;
        }
        else
        {
            heightToGrow = height - (pad.Top + pad.Bot);
        }

        for (i64 c = 0; c < childrenCount; ++c)
        {
            ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
            if (pChild->Config.Size.Height.Type == ScUiMetricType_Grow)
                pChild->Height = heightToGrow;
        }
    }

    for (i64 c = 0; c < childrenCount; ++c)
    {
        ScUiWidget* pChild = sc_ui_widget_get_child_by_index(pWidget, c);
        grow_shrink_calc_height(pChild);
    }
}

void
sc_ui_layout()
{
    if (!g.WidgetCache.aWidgets)
        return;

    if (g.WidgetCache.WidgetBeginEndCounter > 0)
    {
        sc_log_warn("sc_ui_widget_end() wasn;t called for %d times\n", g.WidgetCache.WidgetBeginEndCounter);
    }
    else if (g.WidgetCache.WidgetBeginEndCounter < 0)
    {
        sc_log_warn("sc_ui_widget_end() was called more then neccessary %d times\n", -g.WidgetCache.WidgetBeginEndCounter);
    }
    g.WidgetCache.WidgetBeginEndCounter = 0;

    ScUiWidget* pRoot = &g.WidgetCache.aWidgets[0];

    /*
        // fit()
        fit: calc_width()
        grow() + shrink() for width
        wrap_text()
        fit: calc_height()
        grow() + shrink() for height
        pos() + alignment()
    */

    // DOCS: Calculate size.
    // note: We calc fixed size only there.
    fit_calc_width(pRoot, NULL);
    grow_shrink_calc_width(pRoot);
    // wrap_text_pass(pRoot);
    fit_calc_height(pRoot, NULL);
    grow_shrink_calc_height(pRoot);

    pRoot->X = sc_ui_metric_get_value(pRoot->Config.Position.X, 1);
    pRoot->Y = sc_ui_metric_get_value(pRoot->Config.Position.Y, 0);
    sc_ui_widgets_get_position(pRoot);

    // for (i32 w = 0; w < sc_list_count(g.WidgetCache.aWidgets); ++w)
    // {
    //     ScUiWidget widget = g.WidgetCache.aWidgets[w];
    //     printf("layout: P: %0.0f %0.0f | S %0.0f %0.0f\n", widget.X, widget.Y, widget.Width, widget.Height);
    // }

    // todo: mb implement alignment

    if (sc_helper_tofr())
        sc_ui_widget_print(pRoot, 0);
}

// todo: wip
i32
sc_ui_process_input()
{
    if (!g.WidgetCache.aWidgets)
        return 0;

    ScUiInteractive* pInteractive = &g.Interactive;
    pInteractive->HotId = 0;
    pInteractive->HotPanelId = 0;
    // pInteractive->ActiveId = 0;

    if (sc_ui_is_key_released(ScUiKey_Mouse_Left_Button))
    {
        // note: отжимаем элемент
        pInteractive->ActiveId = 0;
        pInteractive->IsLeftKeyWasPressed = 0;
        // slog_info("Unpress element!\n");
    }

    i32 widgetsCount = sc_list_count(g.WidgetCache.aWidgets);
    i32 isInputAlreadyProcessed = 0;
    ScUiState allUiState = ScUiState_None;

    ScUiWidget* pRoot = &g.WidgetCache.aWidgets[0];

    // todo:
#if 0
    v2 pos = pRoot->Internal.Position;
    v2 size = v2_new(pRoot->Internal.Width, pRoot->Internal.Height);
    if (sc_ui_is_hovered(pos, size.Width, size.Height) && pRoot->a)
    {
        ScUiWidget* pRoot = &pRoot->aWidgets[0];
        ScUiState state = sc_ui_widget_process_input(pRoot);
        if (state != ScUiState_None)
            allUiState = state;
        // if (state == ScUiState_Clicked)
        //     break;
    }
#endif

    sc_ui_input_clear(&g.Back.Input);

    return allUiState != ScUiState_None;
}

void
sc_ui_frame_begin()
{
    if (g.Allocated.pArena == NULL)
    {
        g.Allocated.pArena = sc_arena_new({ .Size = ScMb(1) });
    }
    g.WidgetCache.CurrentWidgetInd = -1;
}

void
sc_ui_frame_end()
{
    sc_arena_clear(g.Allocated.pArena);
    sc_list_clear(g.WidgetCache.aWidgets);
}

/*     #####################################
  DOCS ##              Input              ##
       #####################################*/

i32
sc_ui_is_key_released(ScUiKey key)
{
    ScUiKeyData keyData = g.Back.Input.aKeys[key];
    i32 isReleased = (keyData.IsHandled != 1) && (keyData.State == ScUiKeyState_Released);
    return isReleased;
}

i32
sc_ui_is_key_pressed(ScUiKey key)
{
    ScUiKeyData keyData = g.Back.Input.aKeys[key];
    i32 isPressed = (keyData.IsHandled != 1) && (keyData.State == ScUiKeyState_Pressed);
    return isPressed;
}

void
sc_ui_input_clear(ScUiInput* pInput)
{
    // todo: fix it, wrong approach
    // memset(pInput->aKeys, 0, ScUiKey_Count * sizeof(ScUiKeyData));

    for (i64 k = 0; k < ScUiKey_Count; ++k)
    {
        ScUiKeyData* pKeyData = &pInput->aKeys[k];
        if (pKeyData->State == ScUiKeyState_Released)
        {
            pKeyData->IsHandled = 0;
            pKeyData->State = ScUiKeyState_None;
        }
    }
}

/*     #####################################
  DOCS ##              Utils              ##
       #####################################*/

i64
sc_ui_string_hash(char* pStr)
{
    char* pInput = (char*)pStr;
    i64 hash = sc_string_hash(pInput, sc_utf8_length(pInput));
    return hash;
}

char*
sc_ui_string_new(char* pString)
{
    if (!pString)
        return NULL;

    if (sc_dict_s_contains(g.Allocated.hAllocatedStrings, pString) == 0)
    {
        // slog_warn("Unknown string %s\n", pString);
        char* pNewString = sc_string_new(pString);
        sc_dict_s_add(g.Allocated.hAllocatedStrings, pString, pNewString);
        // slog_warn("Table strs cnt %d\n", svt_count(g.Allocated.hAllocatedStrings));
    }

    i32 ind = sc_dict_index(g.Allocated.hAllocatedStrings);
    return g.Allocated.hAllocatedStrings[ind].Value;
}

char*
sc_ui_frame_string_new(char* pString)
{
    if (!pString)
        return NULL;

    i64 len = sc_string_get_length(pString);
    char* pAllocatedStr = (char*)sc_arena_allocate(g.Allocated.pArena, len + 1);
    pAllocatedStr[len] = '\0';
    memcpy(pAllocatedStr, pString, len);

    return pAllocatedStr;
}

ScSid
sc_ui_csid_new(char* pStr)
{
    ScSid csid = {
        .Hash = sc_ui_string_hash(pStr),
        .pData = sc_ui_string_new(pStr)
    };
#if defined(SC_BUILD_DEBUG)
    for (i32 w = 0; w < sc_list_count(g.WidgetCache.aWidgets); ++w)
    {
        if (g.WidgetCache.aWidgets[w].Id.pData == csid.pData)
        {
            // sc_log_warn("Name is used already %s for widget %d!\n", pStr, w);
        }
    }
#endif // SC_BUILD_DEBUG

    return csid;
}

ScUiWidget*
sc_ui_widget_get_current()
{
    i64 currentInd = g.WidgetCache.CurrentWidgetInd;
    if (currentInd == -1)
        return NULL;
    return sc_ui_widget_get_by_index(currentInd);
}

ScUiColor
sc_ui_color_default(ScUiColor color)
{
    if (color.ShouldUseGradient == 0)
    {
        if (color.Hovered.A == 0)
            color.Hovered = color.Idle;
        if (color.Clicked.A == 0)
            color.Clicked = color.Idle;
        return color;
    }

    v4 empty = {};
    i32 isIdleEmpty = (memcmp(&color.Idle, &empty, sizeof(v4)) == 0);

    if (!isIdleEmpty)
    {
        i32 isHoveredEmpty = memcmp(&color.Hovered, &empty, sizeof(v4)) == 0;
        i32 isClickedEmpty = memcmp(&color.Clicked, &empty, sizeof(v4)) == 0;

        v4 subValue = v4_mulv(color.Idle, 0.4);
        subValue.W = 0;
        if (isHoveredEmpty)
            color.Hovered = v4_sub(color.Idle, subValue);
        if (isClickedEmpty)
            color.Clicked = v4_sub(color.Hovered, subValue);
    }

    // slog_warn("Idle: %v4\n", color.Idle);
    // slog_warn("Hovered: %v4\n", color.Hovered);
    // slog_warn("Clicked: %v4\n", color.Clicked);

    return color;
}

ScUiWidget*
sc_ui_widgets_get()
{
    return g.WidgetCache.aWidgets;
}

const char*
sc_ui_widget_type_to_string(ScUiWidgetType type)
{
    switch (type)
    {
    case ScUiWidgetType_Rectangle:
        return "Rect";
    case ScUiWidgetType_Image:
        return "Image";
    case ScUiWidgetType_Atlas:
        return "Atlas";
    case ScUiWidgetType_Text:
        return "Text";
    default:
        return "Unknown";
    }
}

static v4
GetColorByState(ScUiState state, ScUiColor color, i64 id, ScUiFlag flag)
{
    switch (state)
    {
    case ScUiState_Hovered:
        return color.Hovered;
    case ScUiState_Clicked:
        return color.Clicked;
    case ScUiState_Pressed:
        return color.Clicked;

    default:
        if (flag == ScUiFlag_Alive_Enabled)
            return color.Clicked;
        return color.Idle;
    }
}

/*     #####################################
  DOCS ##         Core Ui Backend         ##
       #####################################*/

void sc_ui_backend_draw_widget(ScUiWidget widget, f32 zorded);

void
sc_ui_backend_new(ScUiBackendConfig config)
{
    g.Back.Render = config.Render;
}

void
sc_ui_backend_update(ScUiBackendState state)
{
    g.Back.State = state;
}

void
sc_ui_backend_render()
{
    ScUiWidget* pRoot = &g.WidgetCache.aWidgets[0];

    v2 pos = v2_new(pRoot->X, pRoot->Y);
    v2 size = v2_new(pRoot->Width, pRoot->Height);
    i32 x = to_i32(pos.X);
    i32 y = to_i32(pos.Y);
    i32 width = to_i32(size.Width);
    i32 height = to_i32(size.Height);
    // g.Back.Render.SetViewport(x, y, width, height);
    v4 panelColor = GetColorByState(pRoot->State, pRoot->Config.Color, pRoot->Id.Hash, 0);
    v3 pos3 = v3_new(pos.X, pos.Y, 30);
    g.Back.Render.DrawRect(pos3, size, panelColor);

    i64 endWidget = sc_list_count(g.WidgetCache.aWidgets) - 1;
    for (i32 w = endWidget; w >= 0; --w)
    {
        ScUiWidget widget = g.WidgetCache.aWidgets[w];
        sc_ui_backend_draw_widget(widget, 1 + (endWidget - w));
    }
}

void
sc_ui_backend_draw_widget(ScUiWidget widget, f32 zorded)
{
    ScUiWidgetConfig cfg = widget.Config;
    v3 pos = v3_new(widget.X, widget.Y, zorded);
    v2 size = v2_new(widget.Width, widget.Height);

    // sc_log_warn("Pos: %v3 Size %v2\n", pos, size);

    v4 widgetColor = GetColorByState(widget.State, cfg.Color, widget.Id.Hash, cfg.Flag);

    // if scrollable
    // add g.Back.Render.SetViewport(x, y, width, height);

    switch (cfg.Type)
    {
    case ScUiWidgetType_Rectangle:
        g.Back.Render.DrawRect(pos, size, widgetColor);
        break;

    case ScUiWidgetType_Image:
        widgetColor = v4_rgb(255, 255, 255);
        g.Back.Render.DrawImage(pos, size, widgetColor, cfg.AssetId);
        break;

    case ScUiWidgetType_Atlas:
        // if (widget.Color.Idle.A == 0)
        // widgetColor = v4_rgb(255, 255, 255);
        g.Back.Render.DrawImageAtlasItem(pos, size, widgetColor, cfg.AssetId, cfg.AssetItem);
        break;

    case ScUiWidgetType_Text:
    {
        v2 m = g.Back.Render.GetTextMetrics(cfg.pText, cfg.FontSize, NULL);
        pos.Y -= m.Height;
        pos.Z -= 0.2;
        g.Back.Render.DrawText(cfg.pText, cfg.FontSize, pos, widgetColor);
        break;
    }
    }
}

ScUiInput*
sc_ui_backend_get_input()
{
    return &g.Back.Input;
}

void
msg_erro(ScUiWidget* pWidget, const char* pMessage)
{
    ScUiWidgetConfig cfg = pWidget->Config;
    sc_log_erro("Widget[%s]: %s!\n", cfg.pName, pMessage);
}

void
msg_warn(ScUiWidget* pWidget, const char* pMessage)
{
    ScUiWidgetConfig cfg = pWidget->Config;
    sc_log_warn("Widget[%s]: %s!\n", cfg.pName, pMessage);
}
