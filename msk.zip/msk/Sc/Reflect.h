#ifndef SC_REFLECT_H
#define SC_REFLECT_H

#include "Sc/Types.h"

typedef struct ScReflectType ScReflectType;
typedef struct ScReflectFieldInfo ScReflectFieldInfo;

struct ScReflectType
{
    // DOCS: Имя структуры #StructType
    char* pName;
    // DOCS: Размер sizeof(StructType)
    // NOTE: Нельзя высчитать через aFields
    u16 Size;

    // DOCS: Поля структуры,
    // NOTE: для простых типов типо i32 -> aFileds = NULL
    ScReflectFieldInfo* aFields;
};

struct ScReflectFieldInfo
{
    // DOCS: Field name
    char* pName;
    // DOCS: Имя структуры #StructType
    ScReflectType TypeInfo;
    // DOCS: Размер в байтах
    u16 Size;
    // DOCS: Отступ от (void*)&structInstance
    u16 Offset;
};

typedef struct
{
    // DOCS: Имя типа (ключ реестра)
    char* Key;
    // DOCS: Описание типа
    ScReflectType Value;
} ScReflectEntry;

typedef struct
{
    // DOCS: Реестр: словарь ScReflectEntry (string key -> ScReflectType)
    ScReflectEntry* hReg;
} ScReflect;

typedef struct
{
    char* pName;
    u16 Size;
    i64 FieldInfoCount;
    ScReflectFieldInfo* aFieldInfos;
} ScReflectTypeConfig;

/*
  DOCS: Регистрация типа в реестре.

  USAGE:
    // Простой тип (i32, f32, ...), полей нет.
    sc_reflect_register_type(&reflect, i32);

    // Структура с полями.
    ScReflectFieldInfo aFields[] = {
        { .pName = "X", .TypeInfo = ..., .Size = sizeof(f32), .Offset = ScOffsetOf(Vec2, X) },
    };
    sc_reflect_register_type(&reflect, Vec2,
        .FieldInfoCount = ScArrayCount(aFields),
        .aFieldInfos = aFields);

  NOTE: cfg.pName должен жить дольше реестра (строка-литерал из #type живет всегда).
  NOTE: ##__VA_ARGS__ (GNU extension) позволяет вызывать макрос без полей:
        sc_reflect_register_type(&reflect, i32);
*/
#define sc_reflect_register_type(pReflect, type, ...) \
    ({                                                \
        ScReflectTypeConfig cfg = {                   \
            .pName = #type,                           \
            .Size = sizeof(type),                     \
            ##__VA_ARGS__                             \
        };                                            \
        sc_reflect_register_type_ext(pReflect, cfg);  \
    })

#define sc_reflect_get_type(pReflect, type)       \
    ({                                            \
        (void)sizeof(type);                       \
        sc_reflect_get_type_ext(pReflect, #type); \
    })

void sc_reflect_register_type_ext(ScReflect* pReflect, ScReflectTypeConfig cfg);
ScReflectType sc_reflect_get_type_ext(ScReflect* pReflect, const char* pName);
void sc_reflect_free(ScReflect* pReflect);

#endif // SC_REFLECT_H
