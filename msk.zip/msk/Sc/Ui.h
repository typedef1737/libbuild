#ifndef UI_H
#define UI_H

/*
   REFACTORING
     * use sc_ui
     * add memory_arena to this code
*/
// sc_ui

#include "Types.h"

typedef struct
{
    i64 Hash;
    char* pData;
} ScSid;

typedef struct
{
    i64 ActiveId;
    i64 HotId;

    i64 ActivePanelId;
    i64 HotPanelId;

    i8 IsLeftKeyWasPressed;
} ScUiInteractive;

typedef struct
{
    i32 ShouldUseGradient;
    v4 Idle;
    v4 Hovered;
    v4 Clicked;
} ScUiColor;

ScUiColor sc_ui_color_default(ScUiColor color);

typedef enum
{
    ScUiState_None = 0,
    ScUiState_Hovered,
    ScUiState_Clicked,
    ScUiState_Pressed
} ScUiState;

typedef enum
{
    // DOCS: Use for layout type
    ScUiMetricType_Fit = 0,
    ScUiMetricType_Grow,
    ScUiMetricType_Fixed,
} ScUiMetricType;

typedef struct
{
    f32 Value;
    ScUiMetricType Type;
} ScUiMetric;

#define Fixed(v) ({ (ScUiMetric) { .Value = v, .Type = ScUiMetricType_Fixed }; })
#define Grow(v) ({ (ScUiMetric) { .Type = ScUiMetricType_Grow }; })
#define Fit(v) ({ (ScUiMetric) { .Type = ScUiMetricType_Fit }; })

typedef struct
{
    ScUiMetric Width;
    ScUiMetric Height;
    f32 MinWidth;
    f32 MinHeight;
    f32 MaxWidth;
    f32 MaxHeight;
} ScUiSizeMetrics;

typedef struct
{
    ScUiMetric X;
    ScUiMetric Y;
} ScUiPositionMetrics;

typedef enum
{
    ScUiFlag_Dead = 0,
    ScUiFlag_Alive,
    ScUiFlag_Alive_Enabled,
} ScUiFlag;

typedef enum
{
    ScUiDirection_Vertical = 0,
    ScUiDirection_Horizontal
} ScUiDirection;

typedef struct
{
    i16 Left;
    i16 Top;
    i16 Right;
    i16 Bot;
} ScUiPad;

#define ScUiPad(l, t, r, b) ({ (ScUiPad) { .Left = l, .Top = t, .Right = r, .Bot = b }; })
#define ScUiPadAll(v) ({ (ScUiPad) { .Left = v, .Top = v, .Right = v, .Bot = v }; })

typedef struct
{
    ScUiPad Padding;
    i16 ChildGap;
    ScUiDirection Direction;
} ScUiLayout;

typedef enum
{
    ScUiWidgetType_Rectangle = 0,
    ScUiWidgetType_Image,
    ScUiWidgetType_Atlas,
    ScUiWidgetType_Text,
} ScUiWidgetType;

const char* sc_ui_widget_type_to_string(ScUiWidgetType type);

// TODO: RENAME
typedef enum
{
    ScUiTextAlign_X_Left = 0,
    ScUiTextAlign_Y_Center = 0,
    ScUiTextAlign_X_Center,
    ScUiTextAlign_X_Right,
    ScUiTextAlign_Y_Top,
    ScUiTextAlign_Y_Bot,
} ScUiTextAlign;

typedef enum
{
    ScUiPositioningMode_None = 0,
    ScUiPositioningMode_Wrap,
} ScUiPositioningMode;

typedef struct
{
    char* pName;
    ScUiFlag Flag;
    ScUiWidgetType Type;

    // DOCS: Texture related
    ScUiColor Color;
    i64 AssetId;
    i16 AssetItem;

    // DOCS: Font Related
    i16 FontSize;
    char* pText;
    char* pFontPath;

    ScUiSizeMetrics Size;
    ScUiPositionMetrics Position;

    ScUiTextAlign Horizontal;
    ScUiTextAlign Vertical;
    ScUiPositioningMode PositioningMode;

    ScUiLayout Layout;
} ScUiWidgetConfig;

typedef struct
{
    ScUiWidgetConfig Config;
    ScSid Id;

    i64* aChildren;
    ScUiState State;
    f32 X;
    f32 Y;
    f32 Width;
    f32 Height;
    i64 Parent;
} ScUiWidget;

typedef enum
{
    ScUiPanelFlag_None = 0,
    ScUiPanelFlag_Invisible,
    ScUiPanelFlag_Disabled
} ScUiPanelFlag;

typedef struct
{
    i64 Id;
    ScUiState State;
} ScUiWidgetState;

#define sc_ui_widget_begin_x(...)                                   \
    ({                                                              \
        sc_ui_widget_begin_ext((ScUiWidgetConfig) { __VA_ARGS__ }); \
    })

#define sc_ui_widget_begin(...)                   \
    ({                                            \
        sc_ui_widget_begin_ext((ScUiWidgetConfig) \
                __VA_ARGS__);                     \
    })
ScUiState sc_ui_widget_begin_ext(ScUiWidgetConfig config);
void sc_ui_widget_end();

#define sc_ui_text(...) \
    ({ sc_ui_text_ext((ScUiWidgetConfig)__VA_ARGS__); })
ScUiState sc_ui_text_ext(ScUiWidgetConfig cfg);

#define sc_ui_image(...) \
    ({ sc_ui_image_ext((ScUiWidgetConfig)__VA_ARGS__); })
ScUiState sc_ui_image_ext(ScUiWidgetConfig cfg);

void sc_ui_layout();
i32 sc_ui_process_input();
void sc_ui_frame_begin();
void sc_ui_frame_end();

ScUiWidget* sc_ui_widgets_get();
ScUiWidget* sc_ui_widget_get_child_by_index(ScUiWidget* pWidget, i16 childInd);
void sc_ui_widget_print(ScUiWidget* aWidgets, i32 tab);

typedef enum
{
    ScUiKeyState_None = 0,
    ScUiKeyState_Pressed,
    ScUiKeyState_Released,
} ScUiKeyState;

typedef struct
{
    i8 IsHandled;
    ScUiKeyState State;
} ScUiKeyData;

typedef enum
{
    ScUiKey_Undefined = 0,

    ScUiKey_Mouse_Left_Button,
    ScUiKey_Mouse_Right_Button,
    ScUiKey_Mouse_Middle_Button,

    ScUiKey_Tab,
    ScUiKey_Backspace,

    ScUiKey_LeftArrow,
    ScUiKey_RightArrow,
    ScUiKey_UpArrow,
    ScUiKey_DownArrow,
    ScUiKey_Home,
    ScUiKey_End,

    ScUiKey_Delete,

    ScUiKey_Count,
} ScUiKey;

typedef struct
{
    v2 MousePosition;
    ScUiKeyData aKeys[ScUiKey_Count];
} ScUiInput;

typedef struct
{
    void (*DrawRect)(v3 position, v2 size, v4 color);
    void (*DrawEmptyRect)(v3 position, v2 size, real thickness, v4 color);
    void (*DrawImage)(v3 position, v2 size, v4 color, i64 textureId);
    void (*DrawImageAtlasItem)(v3 position, v2 size, v4 color, i64 textureId, i32 index);
    void (*DrawText)(char* pText, i32 fontSize, v3 position, v4 glyphColor);
    void (*SetViewport)(i32 x0, i32 y0, i32 width, i32 height);
    v2 (*GetTextMetrics)(char* pText, i32 fontSize, char* pFontPath);
} ScUiBackendRender;

typedef struct
{
    ScUiBackendRender Render;
} ScUiBackendConfig;

typedef struct
{
    v2 DisplaySize;
} ScUiBackendState;

void sc_ui_backend_new(ScUiBackendConfig config);
void sc_ui_backend_update(ScUiBackendState state);
void sc_ui_backend_render();
ScUiInput* sc_ui_backend_get_input();

void try_core_ui_demo();

#endif // UI_H
