#include "Window.h"
#include "Sc/Sc.h"
#include <stdio.h>
#include <stdlib.h>

#if defined(SC_WINDOW_XCB)

#include <X11/keysym.h>
// not sure i need this
#include <X11/X.h>
#include <X11/Xutil.h>
// not sure i need this
#include <sys/select.h>

#include <xcb/bigreq.h> // Заголовочный файл для Big Requests
#include <xcb/xcb.h>
#include <xcb/xcb_icccm.h>
#include <xcb/xcb_keysyms.h> // xcb_key_symbols_t
#include <xcb/xkb.h>
#include <xcb/xproto.h>

typedef struct
{
    xcb_window_t Window;
    xcb_screen_t* pScreen;
    xcb_connection_t* pConnection;
    xcb_key_symbols_t* pSymbols;
    xcb_cursor_t BlankCursor;
} ScWindowXcbLinux;

typedef struct
{
    i32 MaxRequestSize;
    i32 BufferCurrent;
    i32 BuffersCount;
    u16 MaxWidth;
    u16 MaxHeight;
    ScWindowBuffer aBuffers[2];
    xcb_gcontext_t Gc;
    xcb_pixmap_t Pixmap;
} ScWindowXcbLinuxGraphics;

//////                               //
//            XCB Window             //
//                               //////

static void xcb_sc_window_create(ScWindow*, ScWindowConfig);
static void xcb_sc_window_destroy(ScWindow*);
static void xcb_sc_window_update(ScWindow*);
static void xcb_sc_window_set_title(ScWindow*, char*);
static void xcb_sc_window_set_headless(ScWindow*, i32);
static void xcb_sc_window_set_fullscreen(ScWindow*, i32);
static void xcb_sc_window_set_above(ScWindow*, i32);
static void xcb_sc_window_set_cursor_visibilite(ScWindow*, i32);
static void xcb_sc_window_set_cursor_position(ScWindow*, i32, i32);
static void xcb_sc_window_set_position(ScWindow* pWindow, i32 x, i32 y);
static ScKey xcb_sc_key_from_native(i32 native);
static void xcb_create_blank_cursor(ScWindowXcbLinux*);
static ScKeyMod xcb_sc_key_mod_from_native(i32);
static ScMouseKey xcb_sc_mouse_key_from_native(i32);
static xcb_atom_t xcb_get_atom(xcb_connection_t* pXcb, const char* pName);
static ScWindowXcbLinux* xcb_sc_window_get_platform(ScWindow* pWindow);
static ScWindowXcbLinuxGraphics* xcb_sc_window_get_platform_graphics(ScWindow* pWindow);

//////                               //
//           XCB Graphics            //
//                               //////

static void xcb_sc_window_graphics_init(ScWindow* pWindow);
static void xcb_sc_window_graphics_resize(ScWindow* pWindow);
static ScWindowBuffer xcb_sc_window_graphics_get_buffer(ScWindow* pWindow);
static void xcb_sc_window_graphics_swap_buffers(ScWindow* pWindow);
static void xcb_sc_window_graphics_clear_color(ScWindow* pWindow, u32 color);
static void xcb_sc_window_graphics_draw_line(ScWindow* pWindow, i32 x0, i32 y0, i32 x1, i32 y1, u32 color);

#elif defined(SC_WINDOW_WIN32) // SC_WINDOW_XCB
#endif                         // SC_WINDOW_WIN32

ScKeyMod sc_key_mod_from_native(i32 native);
ScMouseKey sc_mouse_key_from_native(i32 native);

void
sc_window_fatal(const char* pMessage)
{
    printf("Error: %s\n", pMessage);
    sc_guard(0);
}

void
sc_window_create(ScWindow* pWindow, ScWindowConfig conf)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_create(pWindow, conf);
#elif defined(SC_WINDOW_WIN32)
#endif
    pWindow->IsAlive = 1;
}

void
sc_window_destroy(ScWindow* pWindow)
{
    if (!pWindow)
        return;

#if defined(SC_WINDOW_XCB)
    xcb_sc_window_destroy(pWindow);
#elif defined(SC_WINDOW_WIN32)

#endif // SC_WINDOW_WIN32
}

void
sc_window_update(ScWindow* pWindow)
{
    if (!pWindow)
        return;

#if defined(SC_WINDOW_XCB)
    xcb_sc_window_update(pWindow);
#elif defined(SC_WINDOW_WIN32)

#endif // SC_WINDOW_WIN32
}

void
sc_window_set_event_call(ScWindow* pWindow, ScCall call)
{
    pWindow->OnEvent = call;
}

void
sc_window_set_title(ScWindow* pWindow, char* pTitle)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_title(pWindow, pTitle);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_headless(ScWindow* pWindow, i32 isSet)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_headless(pWindow, isSet);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_fullscreen(pWindow, isSet);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

// WIP
void
sc_window_set_above(ScWindow* pWindow, i32 isSet)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_above(pWindow, isSet);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_grabed_ext(ScWindow* pWindow, i32 flag)
{
    pWindow->IsGrabed = flag;
}

void
sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_cursor_visibilite(pWindow, isVisible);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_cursor_position(pWindow, x, y);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

void
sc_window_set_position(ScWindow* pWindow, i32 x, i32 y)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_set_position(pWindow, x, y);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_WINDOW_WIN32
}

ScKey
sc_key_from_native(i32 native)
{
#if defined(SC_WINDOW_XCB)
    return xcb_sc_key_from_native(native);
#elif defined(SC_WINDOW_WIN32)
    return ScKey_None;
#endif // SC_WINDOW_WIN32
}

//////                               //
//             Graphics              //
//                               //////

void
sc_window_create_pixmap_gc(ScWindow* pWindow, i32 width, i32 height)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    // Создание пиксмапа
    xcb_pixmap_t pixmap = xcb_generate_id(pXcb->pConnection);
    xcb_create_pixmap(pXcb->pConnection, pXcb->pScreen->root_depth, pixmap, pXcb->Window, width, height);
    // Создание графического контекста
    xcb_gcontext_t gc = xcb_generate_id(pXcb->pConnection);
    uint32_t gc_values = pXcb->pScreen->black_pixel;
    xcb_create_gc(pXcb->pConnection, gc, pixmap, XCB_GC_FOREGROUND, &gc_values);

    pGraphics->Pixmap = pixmap;
    pGraphics->Gc = gc;

    xcb_flush(pXcb->pConnection);
}

void
sc_window_graphics_allocate_buffers(ScWindow* pWindow)
{
#if defined(SC_WINDOW_XCB)
#elif defined(SC_WINDOW_WIN32)
#endif

    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);

    i32 width = pWindow->Size.Width;
    i32 height = pWindow->Size.Height;
    i32 max_width = pWindow->MaxSize.Width > 0 ? pWindow->MaxSize.Width : pWindow->Size.Width;
    i32 max_height = pWindow->MaxSize.Height > 0 ? pWindow->MaxSize.Height : pWindow->Size.Height;

    pGraphics->MaxWidth = max_width;
    pGraphics->MaxHeight = max_height;
    pGraphics->BuffersCount = 2;
    for (i32 b = 0; b < pGraphics->BuffersCount; ++b)
    {
        ScWindowBuffer buf = {
            .Width = width,
            .Height = height,
            .pData = sc_memory_allocate(max_width * max_height * 4)
        };
        pGraphics->aBuffers[b] = buf;
    }

    sc_window_create_pixmap_gc(pWindow, width, height);
}

void
sc_window_graphics_init(ScWindow* pWindow)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_init(pWindow);
#elif defined(SC_WINDOW_WIN32)
#endif
}

void
sc_window_graphics_resize(ScWindow* pWindow)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_resize(pWindow);
#elif defined(SC_WINDOW_WIN32)
#endif
}

ScWindowBuffer
sc_window_graphics_get_buffer(ScWindow* pWindow)
{
#if defined(SC_WINDOW_XCB)
    return xcb_sc_window_graphics_get_buffer(pWindow);
#elif defined(SC_WINDOW_WIN32)
#endif
}

void
sc_window_graphics_swap_buffers(ScWindow* pWindow)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_swap_buffers(pWindow);
#elif defined(SC_WINDOW_WIN32)
#endif
}

void
sc_window_buffer_set_pixel(ScWindowBuffer buffer, i32 x, i32 y, u32 color)
{
#if defined(SC_WINDOW_XCB)
#elif defined(SC_WINDOW_WIN32)
#endif

    if (x < 0 || y < 0)
        return;
    u32* aPixels = (u32*)buffer.pData;
    aPixels[y * buffer.Width + x] = color;
}

void
sc_window_graphics_clear_color(ScWindow* pWindow, u32 color)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_clear_color(pWindow, color);
#elif defined(SC_WINDOW_WIN32)
#endif
}

void
sc_window_graphics_draw_line(ScWindow* pWindow, i32 x0, i32 y0, i32 x1, i32 y1, u32 color)
{
#if defined(SC_WINDOW_XCB)
    xcb_sc_window_graphics_draw_line(pWindow, x0, y0, x1, y1, color);
#elif defined(SC_WINDOW_WIN32)
#endif
}

//////                               //
//       DOCS: Utils & Helpers       //
//                               //////

const char*
sc_window_key_to_string(ScKey key)
{
    switch (key)
    {

    case ScKey_None:
        return "None";

    // DOCS: Numbers
    case ScKey_0:
        return "0";
    case ScKey_1:
        return "1";
    case ScKey_2:
        return "2";
    case ScKey_3:
        return "3";
    case ScKey_4:
        return "4";
    case ScKey_5:
        return "5";
    case ScKey_6:
        return "6";
    case ScKey_7:
        return "7";
    case ScKey_8:
        return "8";
    case ScKey_9:
        return "9";

    // DOCS: Numpad Numbers
    case ScKey_NP_0:
        return "NP_0";
    case ScKey_NP_1:
        return "NP_1";
    case ScKey_NP_2:
        return "NP_2";
    case ScKey_NP_3:
        return "NP_3";
    case ScKey_NP_4:
        return "NP_4";
    case ScKey_NP_5:
        return "NP_5";
    case ScKey_NP_6:
        return "NP_6";
    case ScKey_NP_7:
        return "NP_7";
    case ScKey_NP_8:
        return "NP_8";
    case ScKey_NP_9:
        return "NP_9";

    // DOCS: Numpad Keys
    case ScKey_NP_Lock:
        return "NP_Lock";
    case ScKey_NP_Div:
        return "NP_Div";
    case ScKey_NP_Mul:
        return "NP_Mul";
    case ScKey_NP_Min:
        return "NP_Min";
    case ScKey_NP_Add:
        return "NP_Add";
    case ScKey_NP_Enter:
        return "NP_Enter";
    case ScKey_NP_Comma:
        return "NP_Comma";

    // DOCS: Upper right panel
    case ScKey_PrintScreen:
        return "PrintScreen";
    case ScKey_ScrollLock:
        return "ScrollLock";
    case ScKey_PauseBreak:
        return "PauseBreak";

    // DOCS: Mid right panel
    case ScKey_Insert:
        return "Insert";
    case ScKey_Delete:
        return "Delete";
    case ScKey_Home:
        return "Home";
    case ScKey_End:
        return "End";
    case ScKey_PageUp:
        return "PageUp";
    case ScKey_PageDown:
        return "PageDown";
    case ScKey_CapsLock:
        return "CapsLock";

    // DOCS: Lower right panel
    case ScKey_Up:
        return "Up";
    case ScKey_Left:
        return "Left";
    case ScKey_Down:
        return "Down";
    case ScKey_Right:
        return "Right";

        // DOCS: Characters

    case ScKey_Q:
        return "Q";
    case ScKey_W:
        return "W";
    case ScKey_E:
        return "E";
    case ScKey_R:
        return "R";
    case ScKey_T:
        return "T";
    case ScKey_Y:
        return "Y";
    case ScKey_U:
        return "U";
    case ScKey_I:
        return "I";
    case ScKey_O:
        return "O";
    case ScKey_P:
        return "P";

    case ScKey_A:
        return "A";
    case ScKey_S:
        return "S";
    case ScKey_D:
        return "D";
    case ScKey_F:
        return "F";
    case ScKey_G:
        return "G";
    case ScKey_H:
        return "H";
    case ScKey_J:
        return "J";
    case ScKey_K:
        return "K";
    case ScKey_L:
        return "L";

    case ScKey_Z:
        return "Z";
    case ScKey_X:
        return "X";
    case ScKey_C:
        return "C";
    case ScKey_V:
        return "V";
    case ScKey_B:
        return "B";
    case ScKey_N:
        return "N";
    case ScKey_M:
        return "M";

    // DOCS: Functional
    case ScKey_Grave:
        return "Grave";
    case ScKey_Min:
        return "Min";
    case ScKey_Equal:
        return "Equal";
    case ScKey_Tab:
        return "Tab";
    case ScKey_Shift:
        return "Shift";
    case ScKey_Ctrl:
        return "Ctrl";
    case ScKey_Alt:
        return "Alt";
    case ScKey_Super:
        return "Super";
    case ScKey_Space:
        return "Space";

    case ScKey_Comma:
        return "Comma";
    case ScKey_Dot:
        return "Dot";
    case ScKey_Slash:
        return "Slash";

    case ScKey_Shift_Right:
        return "Shift_Right";
    case ScKey_Alt_Right:
        return "Alt_Right";
    case ScKey_Ctrl_Right:
        return "Ctrl_Right";
    case ScKey_Super_Right:
        return "Super_Right";
    case ScKey_Command_Right:
        return "Command_Right";

    case ScKey_Escape:
        return "Escape";

    // DOCS: Press F
    case ScKey_F1:
        return "F1";
    case ScKey_F2:
        return "F2";
    case ScKey_F3:
        return "F3";
    case ScKey_F4:
        return "F4";
    case ScKey_F5:
        return "F5";
    case ScKey_F6:
        return "F6";
    case ScKey_F7:
        return "F7";
    case ScKey_F8:
        return "F8";
    case ScKey_F9:
        return "F9";
    case ScKey_F10:
        return "F10";
    case ScKey_F11:
        return "F11";
    case ScKey_F12:
        return "F12";

    // DOCS: Extra
    case ScKey_Bracket_Left:
        return "Bracket_Left";
    case ScKey_Bracket_Right:
        return "Bracket_Right";
    case ScKey_Semicolon:
        return "Semicolon";
    case ScKey_Apostrophe:
        return "Apostrophe";
    case ScKey_Backslash:
        return "Backslash";
    case ScKey_Enter:
        return "Enter";

    case ScKey_F13:
        return "F13";
    case ScKey_F14:
        return "F14";
    case ScKey_F15:
        return "F15";
    case ScKey_F16:
        return "F16";
    case ScKey_F17:
        return "F17";
    case ScKey_F18:
        return "F18";
    case ScKey_F19:
        return "F19";
    case ScKey_F20:
        return "F20";
    case ScKey_F21:
        return "F21";
    case ScKey_F22:
        return "F22";
    case ScKey_F23:
        return "F23";
    case ScKey_F24:
        return "F24";
    case ScKey_F25:
        return "F25";

    case ScKey_Backspace:
        return "Backspace";
    case ScKey_Menu:
        return "Menu";

    case ScKey_Count:
        return "Count";

    default:
        return "Undefined";
    }
}

ScKeyMod
sc_key_mod_from_native(i32 native)
{
#if defined(SC_WINDOW_XCB)
    return xcb_sc_key_mod_from_native(native);
#elif defined(SC_WINDOW_WIN32)
#endif // SC_PLATFORM_LINUX
}

const char*
sc_event_type_to_string(ScEventType type)
{
    switch (type)
    {
    case ScEventType_None:
        return "None";
    case ScEventType_KeyType:
        return "KeyType";
    case ScEventType_KeyPress:
        return "KeyPress";
    case ScEventType_KeyRelease:
        return "KeyRelease";
    case ScEventType_MousePress:
        return "MousePress";
    case ScEventType_MouseRelease:
        return "MouseRelease";
    case ScEventType_KeyboardMapping:
        return "KeyboardMapping";
    case ScEventType_MouseMove:
        return "MouseMove";
    case ScEventType_MouseScroll:
        return "MouseScroll";
    case ScEventType_WindowMoved:
        return "WindowMoved";
    case ScEventType_WindowResized:
        return "WindowResized";
    case ScEventType_WindowClosed:
        return "WindowClosed";
    case ScEventType_WindowMaximized:
        return "WindowMaximized";
    case ScEventType_WindowFocused:
        return "WindowFocused";
    case ScEventType_WindowEnter:
        return "WindowEnter";
    case ScEventType_WindowHidden:
        return "WindowHidden";
    case ScEventType_Count:
        return "Count";
    default:
        return "Unknown";
    }
}

i32
sc_window_key_is_printable(ScKey key)
{
    static ScKey aCheckTables[ScKey_Count] = {};
    static i32 isNotInit = 1;
    if (isNotInit)
    {
        for (i32 i = ScKey_0; i <= ScKey_9; ++i)
            aCheckTables[i] = 1;

        for (i32 i = ScKey_NP_0; i <= ScKey_NP_9; ++i)
            aCheckTables[i] = 1;

        for (i32 i = ScKey_Q; i <= ScKey_M; ++i)
            aCheckTables[i] = 1;

        aCheckTables[ScKey_NP_Div] = 1;
        aCheckTables[ScKey_NP_Mul] = 1;
        aCheckTables[ScKey_NP_Min] = 1;
        aCheckTables[ScKey_NP_Add] = 1;
        aCheckTables[ScKey_NP_Comma] = 1;

        aCheckTables[ScKey_Grave] = 1;
        aCheckTables[ScKey_Min] = 1;
        aCheckTables[ScKey_Equal] = 1;
        aCheckTables[ScKey_Comma] = 1;
        aCheckTables[ScKey_Dot] = 1;
        aCheckTables[ScKey_Slash] = 1;
        aCheckTables[ScKey_Bracket_Left] = 1;
        aCheckTables[ScKey_Bracket_Right] = 1;
        aCheckTables[ScKey_Semicolon] = 1;
        aCheckTables[ScKey_Apostrophe] = 1;
        aCheckTables[ScKey_Backslash] = 1;

        isNotInit = 0;
    }

    i32 isPrintable = aCheckTables[key];
    return isPrintable;
}

//////                               //
//            XCB Window             //
//                               //////

#if defined(SC_WINDOW_XCB)

void*
xcb_sc_window_get_window(ScWindow* pWindow)
{
    return (void*)&xcb_sc_window_get_platform(pWindow)->Window;
}

void*
xcb_sc_window_get_connection(ScWindow* pWindow)
{
    return (void*)xcb_sc_window_get_platform(pWindow)->pConnection;
}

static void
xcb_sc_window_create(ScWindow* pScWindow, ScWindowConfig conf)
{
    xcb_connection_t* pConnection = xcb_connect(NULL, NULL);
    if (xcb_connection_has_error(pConnection))
    {
        sc_window_fatal("Xcb con has error\n");
        return;
    }

    { // DOCS: init xcb
        const xcb_query_extension_reply_t* pExtReply = xcb_get_extension_data(pConnection, &xcb_xkb_id);
        if (!pExtReply || !pExtReply->present)
        {
            sc_window_fatal("XKB extension not available\n");
        }

        xcb_xkb_use_extension_cookie_t useCookie = xcb_xkb_use_extension(pConnection, XCB_XKB_MAJOR_VERSION, XCB_XKB_MINOR_VERSION);

        xcb_xkb_use_extension_reply_t* pUseReply = xcb_xkb_use_extension_reply(pConnection, useCookie, NULL);

        if (!pUseReply || !pUseReply->supported)
        {
            sc_window_fatal("XKB extension not supported!\n");
            free(pUseReply);
            return;
        }

        u16 map_parts = XCB_XKB_MAP_PART_KEY_TYPES | XCB_XKB_MAP_PART_KEY_SYMS;
        i16 events = XCB_XKB_EVENT_TYPE_NEW_KEYBOARD_NOTIFY | XCB_XKB_EVENT_TYPE_MAP_NOTIFY;

        xcb_xkb_select_events(pConnection, XCB_XKB_ID_USE_CORE_KBD, events, 0, events, map_parts, map_parts, NULL);
    }

    const xcb_setup_t* pSetup = xcb_get_setup(pConnection);
    xcb_screen_t* pScreen = xcb_setup_roots_iterator(pSetup).data;

    xcb_window_t window = xcb_generate_id(pConnection);

    u32 windowMask = XCB_CW_BACK_PIXEL | XCB_CW_EVENT_MASK;
    u32 masksList[2] = {
        [0] = pScreen->black_pixel,
        [1] = XCB_EVENT_MASK_EXPOSURE | XCB_EVENT_MASK_KEY_PRESS | XCB_EVENT_MASK_KEY_RELEASE | XCB_EVENT_MASK_FOCUS_CHANGE | XCB_EVENT_MASK_VISIBILITY_CHANGE | XCB_EVENT_MASK_POINTER_MOTION | XCB_EVENT_MASK_BUTTON_PRESS | XCB_EVENT_MASK_BUTTON_RELEASE | XCB_EVENT_MASK_ENTER_WINDOW | XCB_EVENT_MASK_LEAVE_WINDOW |
              // Конфигурация, видимость
              XCB_EVENT_MASK_STRUCTURE_NOTIFY |
              // Изменение свойств окна
              XCB_EVENT_MASK_PROPERTY_CHANGE |

              // Maybe comment
              // Перехват изменения размера
              // XCB_EVENT_MASK_RESIZE_REDIRECT |
              // События дочерних окон
              XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY
    };

    // Create borderless window
    xcb_create_window(
        pConnection,
        XCB_COPY_FROM_PARENT,
        window,
        pScreen->root,
        conf.Position.X,
        conf.Position.Y,
        conf.Size.Width,
        conf.Size.Height,
        1, // Border width = 0 for no border
        XCB_WINDOW_CLASS_INPUT_OUTPUT,
        pScreen->root_visual,
        windowMask,
        masksList);

    pScWindow->Size = conf.Size;

    xcb_atom_t normalHintAtom = xcb_get_atom(pConnection, "WM_NORMAL_HINTS");
    if (normalHintAtom != XCB_NONE)
    {
        xcb_size_hints_t hints = {};
        hints.flags = XCB_ICCCM_SIZE_HINT_P_MIN_SIZE | XCB_ICCCM_SIZE_HINT_P_MAX_SIZE;
        hints.min_width = conf.MinSize.Width;
        hints.min_height = conf.MinSize.Height;
        if (conf.MaxSize.Width > 0)
            hints.max_width = conf.MaxSize.Width;
        else
            hints.max_width = 10000;
        if (conf.MaxSize.Height > 0)
            hints.max_height = conf.MaxSize.Height;
        else
            hints.max_height = 10000;

        xcb_change_property(
            pConnection,
            XCB_PROP_MODE_REPLACE,
            window,
            normalHintAtom,
            XCB_ATOM_WM_SIZE_HINTS,
            32,
            sizeof(hints) / 4,
            &hints);

        pScWindow->MaxSize = conf.MaxSize;
    }

    u64 allocatedSize = sizeof(ScWindowXcbLinux);
    if (conf.UseGraphics)
        allocatedSize += sizeof(ScWindowXcbLinuxGraphics);

    void* pShared = sc_memory_allocate(allocatedSize);
    pScWindow->pBackend = pShared;

    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pScWindow);
    pXcbLinux->Window = window;
    pXcbLinux->pScreen = pScreen;
    pXcbLinux->pConnection = pConnection;
    pXcbLinux->pSymbols = xcb_key_symbols_alloc(pConnection);

    if (conf.UseGraphics)
    {
        pScWindow->pGraphics = ((char*)pShared) + sizeof(ScWindowXcbLinux);
        sc_window_graphics_init(pScWindow);
    }

    // 2. Устанавливаем тип окна (обычное окно)
    {
        xcb_atom_t net_wm_window_type = xcb_get_atom(pConnection, "_NET_WM_WINDOW_TYPE");
        xcb_atom_t net_wm_window_type_normal = xcb_get_atom(pConnection, "_NET_WM_WINDOW_TYPE_NORMAL");

        xcb_change_property(pConnection,
            XCB_PROP_MODE_REPLACE,
            window,
            net_wm_window_type,
            XCB_ATOM_ATOM,
            32,
            1,
            &net_wm_window_type_normal);
    }

    { // Устанавливаем протокол для x-btn to woke.
        xcb_intern_atom_cookie_t pc = xcb_intern_atom(pConnection, 1, 12, "WM_PROTOCOLS");
        xcb_intern_atom_cookie_t dc = xcb_intern_atom(pConnection, 0, 16, "WM_DELETE_WINDOW");

        xcb_intern_atom_reply_t* pProtocolRep = xcb_intern_atom_reply(pConnection, pc, NULL);
        xcb_intern_atom_reply_t* pDeleteRep = xcb_intern_atom_reply(pConnection, dc, NULL);

        xcb_change_property(pConnection, XCB_PROP_MODE_REPLACE, window, pProtocolRep->atom, XCB_ATOM_ATOM, 32, 1, &pDeleteRep->atom);
    }

    xcb_create_blank_cursor(pXcbLinux);

    xcb_map_window(pConnection, window);
    xcb_flush(pConnection);
}

static void
xcb_sc_window_destroy(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
    xcb_destroy_window(pXcbLinux->pConnection, pXcbLinux->Window);
    xcb_disconnect(pXcbLinux->pConnection);
    pWindow->IsAlive = 0;
}

static void
xcb_sc_window_update(ScWindow* pWindow)
{
    // memset(pWindow->aKeys, ScAction_None, sizeof(ScAction));
    static ScAction aStateSwitcher[] = {
        [ScAction_Press] = ScAction_Release,
        [ScAction_Release] = ScAction_None,
    };

    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);

    // Process all available events
    xcb_generic_event_t* pEvent;
    while ((pEvent = xcb_poll_for_event(pXcbLinux->pConnection)))
    {
        // printf("Event!\n");
        switch (pEvent->response_type & ~0x80)
        {

        case XCB_KEY_PRESS:
        {
            xcb_key_press_event_t* pKeyPress = (xcb_key_press_event_t*)pEvent;
            xcb_keysym_t keySymbol = xcb_key_press_lookup_keysym(pXcbLinux->pSymbols, pKeyPress, 0);

            ScKey key = sc_key_from_native((i32)keySymbol);
            ScKeyMod mod = sc_key_mod_from_native(pKeyPress->state);

            pWindow->aKeys[key] = ScAction_Press;
            pWindow->aKeyCounter[key] += 1;

            ScKeyPressEvent pressEvent = {
                .Base = (ScEvent) {
                    .IsHandled = 0,
                    .Type = ScEventType_KeyPress },
                .Key = key,
                .KeyMod = mod
            };

            if (pWindow->OnEvent)
            {
                pWindow->OnEvent((ScEvent*)&pressEvent);
            }
            break;
        }

        case XCB_KEY_RELEASE:
        {
            xcb_key_release_event_t* pKeyRelease = (xcb_key_release_event_t*)pEvent;
            xcb_keysym_t keySymbol = xcb_key_release_lookup_keysym(pXcbLinux->pSymbols, pKeyRelease, 0);

            ScKey key = sc_key_from_native((i32)keySymbol);
            ScKeyMod mod = sc_key_mod_from_native(pKeyRelease->state);

            ScKeyReleaseEvent releaseEvent = {
                .Base = (ScEvent) {
                    .IsHandled = 0,
                    .Type = ScEventType_KeyRelease },
                .Key = key,
                .KeyMod = mod
            };

            pWindow->aKeys[key] = ScAction_Release;
            pWindow->aKeyCounter[key] = 0;

            if (pWindow->OnEvent)
            {
                pWindow->OnEvent((ScEvent*)&releaseEvent);
            }
            break;
        }

        case XCB_XKB_MAP_NOTIFY:
        {
            xcb_xkb_map_notify_event_t* pMapNotify = (xcb_xkb_map_notify_event_t*)pEvent;
            printf("Keyboard mapping changed via XKB\n");

            // Обновляем key symbols
            xcb_key_symbols_free(pXcbLinux->pSymbols);
            pXcbLinux->pSymbols = xcb_key_symbols_alloc(pXcbLinux->pConnection);

            ScKeyboardMappingEvent mapEvent = { .Base.Type = ScEventType_KeyboardMapping };
            if (pWindow->OnEvent)
            {
                pWindow->OnEvent((ScEvent*)&mapEvent);
            }
            break;
        }

        case XCB_MOTION_NOTIFY:
        {
            xcb_motion_notify_event_t* pMotion = (xcb_motion_notify_event_t*)pEvent;
            pWindow->Mouse = v2_new(pMotion->event_x, pWindow->Size.Height - pMotion->event_y);

            static i16 prevX = -1;
            static i16 prevY = -1;

            if (pWindow->IsGrabed)
            {
                i16 dx = 0, dy = 0;

                if (prevX != -1 && prevY != -1)
                {
                    dx = pWindow->Mouse.X - prevX;
                    dy = pWindow->Mouse.Y - prevY;
                    if (dx == 0 && dy == 0)
                        continue;
                }

                pWindow->Mouse = v2_new(pWindow->Size.Width / 2, pWindow->Size.Height / 2);
                ScMouseMoveEvent posEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_MouseMove },
                    .X = dx,
                    .Y = -dy // make a flag for inverted Y
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&posEvent);
                }

                // === ВАЖНО: Центрируем курсор ===
                uint16_t centerX = pWindow->Size.Width / 2;
                uint16_t centerY = pWindow->Size.Height / 2;

                xcb_warp_pointer(pXcbLinux->pConnection,
                    XCB_NONE,          // from_window
                    pXcbLinux->Window, // to_window
                    0,
                    0,
                    0,
                    0, // src x,y,w,h
                    centerX,
                    centerY); // новая позиция

                xcb_flush(pXcbLinux->pConnection);

                // Обновляем предыдущую позицию — теперь она центр
                prevX = centerX;
                prevY = centerY;
            }
            else
            {

                ScMouseMoveEvent posEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_MouseMove },
                    .X = pWindow->Mouse.X,
                    .Y = pWindow->Mouse.Y
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&posEvent);
                }
            }

            break;
        }

        case XCB_CONFIGURE_NOTIFY:
        {
            xcb_configure_notify_event_t* pCfg = (xcb_configure_notify_event_t*)pEvent;
            // printf("Conf notify\n");

            // Window resize event
            v2 siz = pWindow->Size;
            v2 pos = pWindow->Position;
            if (siz.Width != pCfg->width || siz.Height != pCfg->height)
            {
                pWindow->Size = v2_new(pCfg->width, pCfg->height);
                if (pWindow->pGraphics)
                    sc_window_graphics_resize(pWindow);

                ScWindowResizeEvent resizeEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_WindowResized },
                    .Width = pCfg->width,
                    .Height = pCfg->height
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&resizeEvent);
                }
            }
            else if (pos.X != pCfg->x || pos.Y != pCfg->y)
            {
                pWindow->Position = v2_new(pCfg->x, pCfg->y);
                ScWindowPositionEvent posEvent = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_WindowMoved },
                    .Position = pWindow->Position
                };

                if (pWindow->OnEvent)
                {
                    pWindow->OnEvent((ScEvent*)&posEvent);
                }
            }
            break;
        }

        case XCB_CLIENT_MESSAGE:
        {
            xcb_client_message_event_t* pMsg = (xcb_client_message_event_t*)pEvent;

            printf("Fullscreen or hidden!\n");
            ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
            xcb_connection_t* pConnection = pXcbLinux->pConnection;

            xcb_atom_t deleteWindow = xcb_get_atom(pConnection, "WM_DELETE_WINDOW");
            xcb_atom_t wmState = xcb_get_atom(pConnection, "_NET_WM_STATE");
            xcb_atom_t wmStateFull = xcb_get_atom(pConnection, "_NET_WM_STATE_FULLSCREEN");
            xcb_atom_t wmStateHidden = xcb_get_atom(pConnection, "_NET_WM_STATE_HIDDEN");

            if (pMsg->type == wmState)
            {
                // Fullscreen toggle
                if (pMsg->data.data32[1] == wmStateFull || pMsg->data.data32[2] == wmStateFull)
                {
                    i32 is_fullscreen = (pMsg->data.data32[0] == 1); // _NET_WM_STATE_ADD

                    ScWindowMaximizedEvent maxEvent = {
                        .Base = {
                            .IsHandled = 0,
                            .Type = ScEventType_WindowMaximized },
                    };

                    if (pWindow->OnEvent)
                    {
                        pWindow->OnEvent((ScEvent*)&maxEvent);
                    }
                }
                // Minimize (window hidden)
                else if (pMsg->data.data32[1] == wmStateHidden || pMsg->data.data32[2] == wmStateHidden)
                {

                    i32 is_minimized = (pMsg->data.data32[0] == 1); // _NET_WM_STATE_ADD

                    ScWindowHiddenEvent hiddenEvent = {
                        .Base = {
                            .IsHandled = 0,
                            .Type = ScEventType_WindowHidden },
                    };

                    if (pWindow->OnEvent)
                    {
                        pWindow->OnEvent((ScEvent*)&hiddenEvent);
                    }
                }
            }
            else if (deleteWindow == pMsg->data.data32[0])
            {
                ScWindowCloseEvent close = {
                    .Base = {
                        .IsHandled = 0,
                        .Type = ScEventType_WindowClosed }
                };
                pWindow->OnEvent((ScEvent*)&close);
            }

            break;
        }

        default:
        {
            // printf("Event that doesnot have 'case'\n");
            break;
        }
        }

        free(pEvent);
    }
}

static void
xcb_sc_window_set_title(ScWindow* pWindow, char* pTitle)
{
    // First get the UTF8_STRING atom

    i64 titleLength = sc_string_get_length(pTitle);
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
    xcb_connection_t* conn = pXcbLinux->pConnection;

    xcb_intern_atom_cookie_t utf8Atom = xcb_intern_atom(conn, 0, sc_string_get_length("UTF8_STRING"), "UTF8_STRING");
    xcb_intern_atom_cookie_t wmNetNameAtom = xcb_intern_atom(conn, 0, sc_string_get_length("_NET_WM_NAME"), "_NET_WM_NAME");
    xcb_intern_atom_cookie_t wmNameAtom = xcb_intern_atom(conn, 0, sc_string_get_length("WM_NAME"), "WM_NAME");

    xcb_intern_atom_reply_t* pUtf8NameReplay = xcb_intern_atom_reply(conn, utf8Atom, NULL);
    xcb_intern_atom_reply_t* wmNameReply = xcb_intern_atom_reply(conn, wmNetNameAtom, NULL);
    xcb_intern_atom_reply_t* pWmNameReply = xcb_intern_atom_reply(conn, wmNameAtom, NULL);

    if (!pUtf8NameReplay || !wmNameReply || !pWmNameReply)
    {
        free(pUtf8NameReplay);
        free(wmNameReply);
        free(pWmNameReply);
        // handle error
        return;
    }

    // Set UTF-8 window title using _NET_WM_NAME
    xcb_change_property(pXcbLinux->pConnection,
        XCB_PROP_MODE_REPLACE,
        pXcbLinux->Window,
        wmNameReply->atom,     // _NET_WM_NAME
        pUtf8NameReplay->atom, // UTF8_STRING
        8,                     // format
        titleLength,
        pTitle);

    // Also set legacy WM_NAME property (some old apps might look for this)
    xcb_change_property(pXcbLinux->pConnection,
        XCB_PROP_MODE_REPLACE,
        pXcbLinux->Window,
        pWmNameReply->atom, // WM_NAME
        XCB_ATOM_STRING,
        8, // format
        titleLength,
        pTitle);

    free(pUtf8NameReplay);
    free(wmNameReply);
    free(pWmNameReply);

    // Flush the connection to ensure the request is sent
    xcb_flush(pXcbLinux->pConnection);
}

static void
xcb_sc_window_set_headless(ScWindow* pWindow, i32 isSet)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);

    xcb_connection_t* pConnection = pXcb->pConnection;

    // Set _MOTIF_WM_HINTS to disable decorations
    xcb_atom_t motifWmHint = xcb_get_atom(pConnection, "_MOTIF_WM_HINTS");

    if (motifWmHint == XCB_NONE)
    {
        printf("motifWmHint not found :(\n");
        return;
    }

    const u32 MWM_HINTS_DECORATIONS = (1L << 1);

    struct
    {
        u32 Flags;
        u32 Functions;
        u32 Decorations;
        i32 InputMode;
        u32 HintsStatus;
    } hints = {
        .Flags = MWM_HINTS_DECORATIONS,
        .Decorations = isSet // 0 = no decorations (borderless)
    };
    xcb_change_property(
        pConnection,
        XCB_PROP_MODE_REPLACE,
        pXcb->Window,
        motifWmHint,
        motifWmHint,
        32,
        sizeof(hints) / 4,
        &hints);

    xcb_flush(pConnection);
}

static void
xcb_sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    xcb_connection_t* pConnection = pXcb->pConnection;
    xcb_window_t window = pXcb->Window;

    xcb_atom_t wmState = xcb_get_atom(pConnection, "_NET_WM_STATE");
    xcb_atom_t wmStateHidden = xcb_get_atom(pConnection, "_NET_WM_STATE_FULLSCREEN");

    xcb_client_message_event_t event = {
        .response_type = XCB_CLIENT_MESSAGE,
        .format = 32,
        .sequence = 0,
        .window = window,
        .type = wmState,
        .data = {
            .data32 = {
                isSet, // _NET_WM_STATE_ADD/_REMOVE
                wmStateHidden,
                0,
                0,
                0 } }
    };

    xcb_send_event(pConnection, 0, xcb_setup_roots_iterator(xcb_get_setup(pConnection)).data->root, XCB_EVENT_MASK_SUBSTRUCTURE_REDIRECT | XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY, (const char*)&event);

    xcb_flush(pConnection);
}

static void
xcb_sc_window_set_above(ScWindow* pWindow, i32 isSet)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);
    xcb_atom_t wmAtom = xcb_get_atom(pXcbLinux->pConnection, "_NET_WM_STATE");
    xcb_atom_t wmAboveAtom = xcb_get_atom(pXcbLinux->pConnection, "_NET_WM_STATE_ABOVE");

    if (wmAtom == XCB_NONE || wmAboveAtom == XCB_NONE)
    {
        printf("Wtf atoms failed %d %d!\n", wmAtom == XCB_NONE, wmAboveAtom == XCB_NONE);
        sc_guard(0);
        return;
    }

    xcb_client_message_event_t event = {
        .response_type = XCB_CLIENT_MESSAGE,
        .format = 32,
        .sequence = 0,
        .window = pXcbLinux->Window,
        .type = wmAtom,
        .data = {
            .data32 = {
                isSet, // _NET_WM_STATE_ADD (1) or _NET_WM_STATE_REMOVE (0)
                wmAboveAtom,
                0, // Second property (none)
                0, // Source indication (0 = normal application)
                0 } }
    };

    // Send the event to the root window
    xcb_send_event(pXcbLinux->pConnection, 0, xcb_setup_roots_iterator(xcb_get_setup(pXcbLinux->pConnection)).data->root, XCB_EVENT_MASK_SUBSTRUCTURE_REDIRECT | XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY, (const char*)&event);

    xcb_flush(pXcbLinux->pConnection);
}

static void
xcb_sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    if (isVisible)
    {
        xcb_change_window_attributes(pXcb->pConnection, pXcb->Window, XCB_CW_CURSOR, (uint32_t[]) { XCB_NONE });
    }
    else
    {
        xcb_change_window_attributes(pXcb->pConnection, pXcb->Window, XCB_CW_CURSOR, (uint32_t[]) { pXcb->BlankCursor });
    }
    xcb_flush(pXcb->pConnection);
}

static void
xcb_sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    // Мгновенно возвращаем курсор в центр
    xcb_warp_pointer(pXcb->pConnection, XCB_NONE, pXcb->Window, 0, 0, 0, 0, x, y);
    xcb_flush(pXcb->pConnection);
}

static void
xcb_sc_window_set_position(ScWindow* pWindow, i32 x, i32 y)
{
    ScWindowXcbLinux* pXcbLinux = xcb_sc_window_get_platform(pWindow);

    // Values array for X and Y position
    u32 values[] = { (u32)x, (u32)y };

    // Configure window position
    xcb_configure_window(
        pXcbLinux->pConnection,
        pXcbLinux->Window,
        XCB_CONFIG_WINDOW_X | XCB_CONFIG_WINDOW_Y,
        values);

    // Update window's position in our struct
    pWindow->Position = v2_new(x, y);

    // Flush the request to ensure it's sent
    xcb_flush(pXcbLinux->pConnection);
}

static ScKey
xcb_sc_key_from_native(i32 native)
{
    switch (native)
    {
        // Numbers
    case XK_0:
        return ScKey_0;
    case XK_1:
        return ScKey_1;
    case XK_2:
        return ScKey_2;
    case XK_3:
        return ScKey_3;
    case XK_4:
        return ScKey_4;
    case XK_5:
        return ScKey_5;
    case XK_6:
        return ScKey_6;
    case XK_7:
        return ScKey_7;
    case XK_8:
        return ScKey_8;
    case XK_9:
        return ScKey_9;

    // Numpad Numbers
    case XK_KP_0:
        return ScKey_NP_0;
    case XK_KP_1:
        return ScKey_NP_1;
    case XK_KP_2:
        return ScKey_NP_2;
    case XK_KP_3:
        return ScKey_NP_3;
    case XK_KP_4:
        return ScKey_NP_4;
    case XK_KP_5:
        return ScKey_NP_5;
    case XK_KP_6:
        return ScKey_NP_6;
    case XK_KP_7:
        return ScKey_NP_7;
    case XK_KP_8:
        return ScKey_NP_8;
    case XK_KP_9:
        return ScKey_NP_9;

    // Numpad Keys
    case XK_Num_Lock:
        return ScKey_NP_Lock;
    case XK_KP_Divide:
        return ScKey_NP_Div;
    case XK_KP_Multiply:
        return ScKey_NP_Mul;
    case XK_KP_Subtract:
        return ScKey_NP_Min;
    case XK_KP_Add:
        return ScKey_NP_Add;
    case XK_KP_Enter:
        return ScKey_NP_Enter;
    case XK_KP_Separator:
    case XK_KP_Decimal:
        return ScKey_NP_Comma;

    // Upper right panel
    case XK_Print:
        return ScKey_PrintScreen;
    case XK_Scroll_Lock:
        return ScKey_ScrollLock;
    case XK_Pause:
        return ScKey_PauseBreak;

    // Mid right panel
    case XK_Insert:
        return ScKey_Insert;
    case XK_Delete:
        return ScKey_Delete;
    case XK_Home:
        return ScKey_Home;
    case XK_End:
        return ScKey_End;
    case XK_Page_Up:
        return ScKey_PageUp;
    case XK_Page_Down:
        return ScKey_PageDown;
    case XK_Caps_Lock:
        return ScKey_CapsLock;

    // Arrow keys
    case XK_Up:
        return ScKey_Up;
    case XK_Left:
        return ScKey_Left;
    case XK_Down:
        return ScKey_Down;
    case XK_Right:
        return ScKey_Right;

    // Letters (lowercase and uppercase map to same ScKey)
    case XK_q:
    case XK_Q:
        return ScKey_Q;
    case XK_w:
    case XK_W:
        return ScKey_W;
    case XK_e:
    case XK_E:
        return ScKey_E;
    case XK_r:
    case XK_R:
        return ScKey_R;
    case XK_t:
    case XK_T:
        return ScKey_T;
    case XK_y:
    case XK_Y:
        return ScKey_Y;
    case XK_u:
    case XK_U:
        return ScKey_U;
    case XK_i:
    case XK_I:
        return ScKey_I;
    case XK_o:
    case XK_O:
        return ScKey_O;
    case XK_p:
    case XK_P:
        return ScKey_P;

    case XK_a:
    case XK_A:
        return ScKey_A;
    case XK_s:
    case XK_S:
        return ScKey_S;
    case XK_d:
    case XK_D:
        return ScKey_D;
    case XK_f:
    case XK_F:
        return ScKey_F;
    case XK_g:
    case XK_G:
        return ScKey_G;
    case XK_h:
    case XK_H:
        return ScKey_H;
    case XK_j:
    case XK_J:
        return ScKey_J;
    case XK_k:
    case XK_K:
        return ScKey_K;
    case XK_l:
    case XK_L:
        return ScKey_L;

    case XK_z:
    case XK_Z:
        return ScKey_Z;
    case XK_x:
    case XK_X:
        return ScKey_X;
    case XK_c:
    case XK_C:
        return ScKey_C;
    case XK_v:
    case XK_V:
        return ScKey_V;
    case XK_b:
    case XK_B:
        return ScKey_B;
    case XK_n:
    case XK_N:
        return ScKey_N;
    case XK_m:
    case XK_M:
        return ScKey_M;

    // Functional keys
    case XK_grave:
    case XK_asciitilde:
        return ScKey_Grave;
    case XK_minus:
    case XK_underscore:
        return ScKey_Min;
    case XK_equal:
    case XK_plus:
        return ScKey_Equal;
    case XK_Tab:
        return ScKey_Tab;
    case XK_Shift_L:
        return ScKey_Shift;
    case XK_Control_L:
        return ScKey_Ctrl;
    case XK_Alt_L:
        return ScKey_Alt;
    case XK_Super_L:
        return ScKey_Super;
    case XK_space:
        return ScKey_Space;

    case XK_comma:
    case XK_less:
        return ScKey_Comma;
    case XK_period:
    case XK_greater:
        return ScKey_Dot;
    case XK_slash:
    case XK_question:
        return ScKey_Slash;

    case XK_Shift_R:
        return ScKey_Shift_Right;
    case XK_Alt_R:
        return ScKey_Alt_Right;
    case XK_Control_R:
        return ScKey_Ctrl_Right;
    case XK_Super_R:
        return ScKey_Super_Right;
    case XK_Menu:
        return ScKey_Menu;
    case XK_BackSpace:
        return ScKey_Backspace;

    case XK_Escape:
        return ScKey_Escape;

    // Function keys
    case XK_F1:
        return ScKey_F1;
    case XK_F2:
        return ScKey_F2;
    case XK_F3:
        return ScKey_F3;
    case XK_F4:
        return ScKey_F4;
    case XK_F5:
        return ScKey_F5;
    case XK_F6:
        return ScKey_F6;
    case XK_F7:
        return ScKey_F7;
    case XK_F8:
        return ScKey_F8;
    case XK_F9:
        return ScKey_F9;
    case XK_F10:
        return ScKey_F10;
    case XK_F11:
        return ScKey_F11;
    case XK_F12:
        return ScKey_F12;

    // Extra keys
    case XK_bracketleft:
    case XK_braceleft:
        return ScKey_Bracket_Left;
    case XK_bracketright:
    case XK_braceright:
        return ScKey_Bracket_Right;
    case XK_semicolon:
    case XK_colon:
        return ScKey_Semicolon;
    case XK_apostrophe:
    case XK_quotedbl:
        return ScKey_Apostrophe;
    case XK_backslash:
    case XK_bar:
        return ScKey_Backslash;
    case XK_Return:
        return ScKey_Enter;

    // Extended function keys
    case XK_F13:
        return ScKey_F13;
    case XK_F14:
        return ScKey_F14;
    case XK_F15:
        return ScKey_F15;
    case XK_F16:
        return ScKey_F16;
    case XK_F17:
        return ScKey_F17;
    case XK_F18:
        return ScKey_F18;
    case XK_F19:
        return ScKey_F19;
    case XK_F20:
        return ScKey_F20;
    case XK_F21:
        return ScKey_F21;
    case XK_F22:
        return ScKey_F22;
    case XK_F23:
        return ScKey_F23;
    case XK_F24:
        return ScKey_F24;
    case XK_F25:
        return ScKey_F25;

    default:
        return ScKey_None;
    }
}

static void
xcb_create_blank_cursor(ScWindowXcbLinux* pWindow)
{
    xcb_connection_t* pConnection = pWindow->pConnection;
    xcb_screen_t* pScreen = pWindow->pScreen;

    // Создаём пустой pixmap 1x1
    xcb_pixmap_t pixmap = xcb_generate_id(pConnection);
    xcb_create_pixmap(pConnection, 1, pixmap, pScreen->root, 1, 1);

    // Создаём курсор из этого pixmap (чёрный и маска — полностью прозрачные)
    xcb_cursor_t cursor = xcb_generate_id(pConnection);
    uint32_t values[] = { 0, 0 }; // fore/red, back/blue — не важно, т.к. маска пустая

    xcb_create_cursor(pConnection,
        cursor,
        pixmap, // source
        pixmap, // mask (тот же, но можно создать отдельный полностью чёрный)
        values[0],
        values[0],
        values[0], // foreground RGB
        values[1],
        values[1],
        values[1], // background RGB
        0,
        0); // x, y hotspot

    // Освобождаем pixmap (курсор держит ссылку)
    xcb_free_pixmap(pConnection, pixmap);

    pWindow->BlankCursor = cursor;
}

static ScKeyMod
xcb_sc_key_mod_from_native(i32 native)
{
    ScKeyMod mod = ScKeyMod_None;

    if (native & XCB_MOD_MASK_SHIFT)
        mod |= ScKeyMod_Shift;
    if (native & XCB_MOD_MASK_CONTROL)
        mod |= ScKeyMod_Ctrl;
    if (native & XCB_MOD_MASK_1)
        mod |= ScKeyMod_Alt;
    if (native & XCB_MOD_MASK_4)
        mod |= ScKeyMod_Super;
    if (native & XCB_MOD_MASK_LOCK)
        mod |= ScKeyMod_CapsLock;
    if (native & XCB_MOD_MASK_2)
        mod |= ScKeyMod_NumLock;
    return mod;
}

static ScMouseKey
xcb_sc_mouse_key_from_native(i32 native)
{
    static u32 aFromNative[] = {
        [1] = ScMouseKey_Left,
        [2] = ScMouseKey_Middle,
        [3] = ScMouseKey_Right,
        [6] = ScMouseKey_Ext_0,
        [7] = ScMouseKey_Ext_1,
        [8] = ScMouseKey_Ext_2,
        [9] = ScMouseKey_Ext_3,
        [10] = ScMouseKey_Ext_4,
        [11] = ScMouseKey_Ext_5,
        [12] = ScMouseKey_Ext_6,
        [13] = ScMouseKey_Ext_7,
        [14] = ScMouseKey_Ext_8,
        [15] = ScMouseKey_Ext_9,
    };

    if (native >= ScArrayCount(aFromNative))
        return ScMouseKey_None;

    ScMouseKey scMouseKey = aFromNative[native];
    return scMouseKey;
}

static xcb_atom_t
xcb_get_atom(xcb_connection_t* pXcb, const char* pName)
{
    xcb_intern_atom_cookie_t cookie = xcb_intern_atom(pXcb, 0, sc_string_get_length((char*)pName), pName);
    xcb_intern_atom_reply_t* pReply = xcb_intern_atom_reply(pXcb, cookie, NULL);

    if (!pReply)
    {
        printf("Error: Could not get %s atom\n", pName);
        return XCB_NONE;
    }

    xcb_atom_t atom = pReply->atom;
    free(pReply);
    return atom;
}

static ScWindowXcbLinux*
xcb_sc_window_get_platform(ScWindow* pWindow)
{
    return (ScWindowXcbLinux*)pWindow->pBackend;
}

static ScWindowXcbLinuxGraphics*
xcb_sc_window_get_platform_graphics(ScWindow* pWindow)
{
    return (ScWindowXcbLinuxGraphics*)pWindow->pGraphics;
}

//////                               //
//           XCB Graphics            //
//                               //////

static void
xcb_sc_window_graphics_init(ScWindow* pWindow)
{
    // DOCS: Init big request if possible,
    //  otherwise use small batches
    ScWindowXcbLinuxGraphics* pXcbGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    ScWindowXcbLinux* pXcbBackend = xcb_sc_window_get_platform(pWindow);
    const xcb_query_extension_reply_t* pExtReply = xcb_get_extension_data(pXcbBackend->pConnection, &xcb_big_requests_id);

    i32 maxReqSize = 256 * 1024;
    if (pExtReply && pExtReply->present)
    {
        xcb_big_requests_enable_cookie_t enableRequest = xcb_big_requests_enable(pXcbBackend->pConnection);

        xcb_generic_error_t* pError = NULL;
        xcb_big_requests_enable_reply_t* pReply = xcb_big_requests_enable_reply(pXcbBackend->pConnection,
            enableRequest,
            &pError);

        if (pError)
        {
            // use sc_log
            printf("BigRequests not supported!\n");
            sc_log_erro("BigRequests activation failed: %d\n", pError->error_code);
            free(pError);
        }

        if (pReply)
        {
            maxReqSize = pReply->maximum_request_length;
            printf("Max request size: %u %uKb %uMb\n", maxReqSize, maxReqSize / 1024, maxReqSize / (1024 * 1024));
            free(pReply);
        }
    }

    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);
    pGraphics->MaxRequestSize = maxReqSize;

    sc_window_graphics_allocate_buffers(pWindow);
}

static void
xcb_sc_window_graphics_resize(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);

    u16 max_width = pGraphics->MaxWidth;
    u16 max_height = pGraphics->MaxHeight;

    i32 width = ScMin(pWindow->Size.Width, max_width);
    i32 height = ScMin(pWindow->Size.Height, max_height);
    for (i32 b = 0; b < pGraphics->BuffersCount; ++b)
    {
        ScWindowBuffer* pBuf = &pGraphics->aBuffers[b];
        pBuf->Width = width;
        pBuf->Height = height;
    }

    if (pGraphics->Pixmap)
    {
        xcb_free_pixmap(pXcb->pConnection, pGraphics->Pixmap);
    }

    if (pGraphics->Gc)
    {
        xcb_free_gc(pXcb->pConnection, pGraphics->Gc);
    }

    sc_window_create_pixmap_gc(pWindow, width, height);
}

static ScWindowBuffer
xcb_sc_window_graphics_get_buffer(ScWindow* pWindow)
{
    ScWindowXcbLinuxGraphics* pGraph = xcb_sc_window_get_platform_graphics(pWindow);
    return pGraph->aBuffers[pGraph->BufferCurrent];
}

static void
xcb_sc_window_graphics_swap_buffers(ScWindow* pWindow)
{
    ScWindowXcbLinux* pXcb = xcb_sc_window_get_platform(pWindow);
    ScWindowXcbLinuxGraphics* pGraphics = xcb_sc_window_get_platform_graphics(pWindow);

    u32 chunkSize = pGraphics->MaxRequestSize;
    u16 width = pWindow->Size.Width,
        height = pWindow->Size.Height;
    u32 size = width * height * 4;

    i32 chunkHeight = chunkSize / (width * 4);
    u32 chunkDataSize = width * chunkHeight * 4;
    u32 stride = width * 4;
    u8* pRead = (u8*)pGraphics->aBuffers[pGraphics->BufferCurrent].pData;
    pGraphics->BufferCurrent = (pGraphics->BufferCurrent + 1) % pGraphics->BuffersCount;

    // printf("ChunkHeight %d height %d SIZE %d kb\n", chunkHeight, height, chunkSize/1024);

    for (i32 y = 0; y < height; y += chunkHeight)
    {
        u32 currentHeight = ScMin(chunkHeight, height - y);
        xcb_put_image(pXcb->pConnection,
            XCB_IMAGE_FORMAT_Z_PIXMAP,
            pGraphics->Pixmap,
            pGraphics->Gc,
            width,
            currentHeight,
            0,
            y,
            0,
            pXcb->pScreen->root_depth,
            currentHeight * stride,
            (const u8*)pRead);
        pRead += currentHeight * stride;
    }

    xcb_copy_area(pXcb->pConnection,
        pGraphics->Pixmap,
        pXcb->Window,
        pGraphics->Gc,
        0,
        0,
        0,
        0,
        pWindow->Size.Width,
        pWindow->Size.Height);

    xcb_flush(pXcb->pConnection);
}

static void
xcb_sc_window_graphics_clear_color(ScWindow* pWindow, u32 color)
{
    ScWindowBuffer buffer = sc_window_graphics_get_buffer(pWindow);
    u32* pWrite = (u32*)buffer.pData;

    for (i32 y = 0; y < buffer.Height; ++y)
    {
        for (i32 x = 0; x < buffer.Width; ++x)
        {
            *pWrite = color;
            ++pWrite;
        }
    }
}

static void
xcb_sc_window_graphics_draw_line(ScWindow* pWindow, i32 x0, i32 y0, i32 x1, i32 y1, u32 color)
{
    ScWindowBuffer buffer = sc_window_graphics_get_buffer(pWindow);
    u32* aPixels = (u32*)buffer.pData;

    // y0 = buffer.Height - y0;
    // y1 = buffer.Height - y1;

    i32 dx = x0 - x1;
    i32 dy = y0 - y1;

    i32 adx = sc_i32_abs(dx);
    i32 ady = sc_i32_abs(dy);
    i32 changed = ady > adx;
    if (changed)
    {
        ScSwap(x0, y0);
        ScSwap(x1, y1);
    }

    if (x0 > x1)
    {
        ScSwap(x0, x1);
        ScSwap(y0, y1);
    }

    // printf("x0: %d x1: %d y0: %d y1: %d changed %d\n", x0, x1, y0, y1, changed);

    f32 strength = 2.0f;
    f32 step = (1.0f / (x1 - x0)) / strength;
    i32 udx = x1 - x0;
    i32 udy = y1 - y0;

    if (changed)
    {
        for (f32 k = 0.0; k < 1.0f; k += step)
        {
            i32 x = x0 + k * udx;
            i32 y = y0 + k * udy;
            sc_window_buffer_set_pixel(buffer, y, x, color);
        }
    }
    else
    {
        for (f32 k = 0.0; k < 1.0f; k += step)
        {
            i32 x = x0 + k * udx;
            i32 y = y0 + k * udy;
            sc_window_buffer_set_pixel(buffer, x, y, color);
        }
    }
}

#endif // SC_WINDOW_XCB

#if defined(SC_WINDOW_WIN32)

void* win32_sc_window_get_window(ScWindow* pWindow);
void* win32_sc_window_get_connection(ScWindow* pWindow);
static void win32_sc_window_create(ScWindow* pScWindow, ScWindowConfig set);
static void win32_sc_window_destroy(ScWindow* pWindow);
static void win32_sc_window_update(ScWindow* pWindow);
static void win32_sc_window_set_event_call(ScWindow* pWindow, ScCall call);
static void win32_sc_window_set_title(ScWindow* pWindow, char* pTitle);
static void win32_sc_window_set_headless(ScWindow* pWindow, i32 isSet);
static void win32_sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet);
static void win32_sc_window_set_above(ScWindow* pWindow, i32 isSet);
static void win32_sc_window_set_grabed_ext(ScWindow* pWindow, i32 flag);
static void win32_sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible);

#endif // SC_PLATFORM_WINDOWS
