#ifndef SC_GLTF_H
#define SC_GLTF_H

#include "Types.h"

/*
TODO:
 * be more accurate with the spec.
*/

typedef struct
{
    char* pGenerator;
    char* pVersion; // major << 8 | minor
} ScGltfAsset;

typedef struct
{
    char* pName;
    i32* aNodes;
} ScGltfScene;

typedef struct
{
    char* pName;
    i32 Mesh;
    v4o Rotation;
} ScGltfNode;

typedef struct
{
    i32 Position;
    i32 Normal;
    i32 Uv0;
} ScGltfAttribute;

typedef struct
{
    ScGltfAttribute Attributes;
    i32 Indices;
} ScGltfPrimitive;

typedef struct
{
    char* pName;
    ScGltfPrimitive* aPrimitives;
} ScGltfMesh;

typedef enum
{
    ScGltfComponentType_SignedByte = 5120,
    ScGltfComponentType_UnsignedByte = 5121,
    ScGltfComponentType_SignedShort = 5122,
    ScGltfComponentType_UnsignedShort = 5123,
    ScGltfComponentType_UnsignedInt = 5125,
    ScGltfComponentType_Float = 5126,
} ScGltfComponentType;

typedef struct
{
    i32 BufferView;
    ScGltfComponentType ComponentType;
    i32 Count;
    v3o Max;
    v3o Min;
    // DOCS: "type" in gltf format
    i32 ComponentsCount;
} ScGltfAccessor;

typedef struct
{
    i32 Buffer;
    i32 ByteLength;
    i32 ByteOffset;
    i32 Target;
} ScGltfBufferView;

typedef struct
{
    i32 ByteLength;
    char* pUri;
    void* pData;
} ScGltfBuffer;

typedef struct
{
    char* pPath;
    ScGltfAsset Asset;
    i32 Scene;
    ScGltfScene* aScenes;
    ScGltfNode* aNodes;
    ScGltfMesh* aMeshes;
    ScGltfAccessor* aAccessors;
    ScGltfBufferView* aBufferViews;
    ScGltfBuffer* aBuffers;
} ScGltf;

ScGltf sc_gltf_load(const char* pPath);
void sc_gltf_unload(ScGltf gltf);
void sc_gltf_load_buffers(ScGltf* pGltf);
const char* sc_gltf_component_type_to_string(ScGltfComponentType type);

#endif // SC_GLTF_H
