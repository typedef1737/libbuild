#include "Ai.h"
#include "Sc.h"
#include <stdio.h>

const i64 c_ignore_token = -1337;

typedef struct
{
    u32* pSt0;
    u32* pSt1;
    u32* pActive;
} ScAiGlobal;

static ScAiGlobal g = {};

// mb struct ???
u32*
tokens_array_new(char* pText, i64 textLength)
{
    u32* aTokens = NULL;

    aTokens = sc_list_reserve(aTokens, textLength);
    sc_list_header(aTokens)->Count = 0;

    for (i64 i = 0; i < textLength; ++i)
    {
        char* ptr = pText + i;
        if (sc_string_compare_ext(ptr, "<EOS>", 5))
        {
            sc_list_add(aTokens, ScAiSpecialToken_Eos);
            i += 4;
        }
        else
        {
            char c = *ptr;
            switch (c)
            {
            case '\n':
            case '\t':
            case '\v':
            case '\r':
                continue;
            }
            u8 ch = c;
            sc_list_add(aTokens, ch);
        }
    }

    return aTokens;
}

ScAiBpe
sc_ai_bpe_new(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;
    u64* aPairKeys = NULL;

    struct
    {
        i64 Key;
        ScBpeTokenPair Value;
    }* hPairs = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char buf[8] = { (char)i };
        ScBpeVocabItem item = {
            .pValue = sc_string_new(buf),
        };
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < 5; ++i)
    {
        const char* names[] = { "<UNK>", "<PAD>", "<BOS>", "<EOS>", "<SEP>" };
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)names[i]) };
        sc_list_add(aVocab, item);
    }

    i64 copyCount = cfg.TextLength;
    i64 mergesCount = cfg.MergesCount;
    g.pSt0 = tokens_array_new(cfg.pText, copyCount);
    g.pSt1 = sc_list_reserve(g.pSt1, copyCount);
    g.pActive = g.pSt0;

    /* DOCS:
        Optimize plan:
        - use hash table for Pairs

        */

    for (i32 m = 0; m < mergesCount; ++m)
    {
        //
        // tokens_find_max_pair()
        //

        ScBpeTokenPair maxPair = {};
        i64 vocabCount = sc_list_count(aVocab);

        {

            u32* aTokens = g.pActive;

            i64 fptokensCount = sc_list_count(aTokens) - 1;

            for (i64 i = 0; i < fptokensCount; ++i)
            {
                // DOCS: ignore shit so we dont have to reallocate
                u32 c = aTokens[i];
                if (c >= ScAiSpecialToken_Unk && c <= ScAiSpecialToken_Sep)
                    continue;

                u32 nc = aTokens[i + 1];
                if (nc >= ScAiSpecialToken_Unk && nc <= ScAiSpecialToken_Sep)
                    continue;

                if (c >= vocabCount || nc >= vocabCount)
                    continue;

                u64 ab = (to_u64(c) << 32) | nc;
                i32 isKeyExist = sc_dict_i_contains(hPairs, ab);

                if (isKeyExist)
                {
                    // DOCS: Увеличиваем счётчик пары.
                    i64 ind = sc_dict_index(hPairs);
                    hPairs[ind].Value.Count = ++hPairs[ind].Value.Count;
                }
                else
                {
                    ScBpeTokenPair pair = {
                        .A = c,
                        .B = nc,
                        .Count = 1,
                    };
                    sc_dict_i_add(hPairs, ab, pair);
                    sc_list_add(aPairKeys, ab);
                }
            }

            i64 pairKeysCoount = sc_list_count(aPairKeys);
            sc_log_info("Pairs count: %d\n", pairKeysCoount);

            u64 pairKey = aPairKeys[0];
            maxPair = sc_dict_i_get(hPairs, pairKey);
            for (i64 p = 1; p < pairKeysCoount; ++p)
            {
                pairKey = aPairKeys[p];
                ScBpeTokenPair pair = sc_dict_i_get(hPairs, pairKey);
                if (pair.Count > maxPair.Count)
                {
                    maxPair = pair;
                }
            }

            sc_dict_clear(hPairs);
            sc_list_clear(aPairKeys);
        }

        if (maxPair.Count <= 1)
        {
            sc_log_warn("прерывание: цикла, дошли до (ручки) maxPair.Count <= 1\n");
            break;
        }
        sc_bpe_token_pair_print(maxPair, m, mergesCount);

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[maxPair.A];
        ScBpeVocabItem itemB = aVocab[maxPair.B];

        ScAiMerge merge = { .T0 = maxPair.A, .T1 = maxPair.B, .Tf = newId };
        sc_list_add(aMerges, merge);

        char buf[1024] = {};
        snprintf(buf, 1024, "%s%s", itemA.pValue, itemB.pValue);
        ScBpeVocabItem newVocabItem = { .pValue = sc_string_new(buf) };

        sc_list_add(aVocab, newVocabItem);

        // DOCS: new replacement
        u32* aCopyFrom = NULL;
        u32* aNewTokens = NULL;
        if (g.pActive == g.pSt0)
        {
            aCopyFrom = g.pSt0;
            aNewTokens = g.pSt1;
            g.pActive = g.pSt1;
        }
        else
        {
            aCopyFrom = g.pSt1;
            aNewTokens = g.pSt0;
            g.pActive = g.pSt0;
        }

        i64 copyTokensCount = sc_list_count(aCopyFrom);
        sc_list_header(aNewTokens)->Count = 0;

        // DOCS: последний элемент не может быть t, проверим на t+1
        --copyTokensCount;
        for (i64 t = 0; t < copyTokensCount; ++t)
        {
            u32 token = aCopyFrom[t];
            if (token == maxPair.A && aCopyFrom[t + 1] == maxPair.B)
            {
                sc_list_add(aNewTokens, newId);
                ++t;
            }
            else
            {
                sc_list_add(aNewTokens, token);
            }
        }
    }

    scAiBpe.aTokens = g.pActive;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;

    return scAiBpe;
}

ScAiBpe
sc_ai_bpe_load_from_disk(char* pFile)
{
    ScAiBpe bpe = {};

    // DOCS: Extension validation, only bpe files expected.
    char* pExt = sc_path_get_extension_wo_alloc(pFile);
    if (!sc_string_compare_ext(pExt, ".bpe", 4))
    {
        sc_log_erro("Invalid extension for the file %s!\n", pFile);
        return bpe;
    }

    i64 fileSize = 0;
    char* pFileData = sc_file_read_ext(pFile, &fileSize);

    bpe = sc_ai_bpe_load_from_memory(pFileData, fileSize);

    return bpe;
}

ScAiBpe
sc_ai_bpe_load_from_memory(char* pData, i64 dataSize)
{
    ScAiBpe bpe = {};

    char* ptr = pData;
    i64 ind = 0;

    char c = *ptr;

    while (c != '\0')
    {
        switch (c)
        {
        case '#':
        {
            if (sc_string_compare_ext(ptr, "# merges\n", 9))
            {
                ptr += 13;
                c = *ptr;

                while (!sc_char_is_integer(c))
                {
                    ++ptr;
                    c = *ptr;
                }

                ScAiMerge* aMerges = NULL;
                while (c != '`' && c != '\0')
                {
                    // read line
                    ScParsedInt parsedInt0 = sc_parse_int_while_int(ptr);
                    ptr = parsedInt0.pOutput;
                    ptr = sc_parse_skip_space(ptr);
                    // todo: create sc_parsed_utils

                    ScParsedInt parsedInt1 = sc_parse_int_while_int(ptr);
                    ptr = parsedInt1.pOutput;
                    ptr = sc_parse_skip_space(ptr);

                    ScParsedInt parsedInt2 = sc_parse_int_while_int(ptr);
                    ptr = parsedInt2.pOutput;

                    ScAiMerge merge = {
                        .T0 = parsedInt0.IntValue,
                        .T1 = parsedInt1.IntValue,
                        .Tf = parsedInt2.IntValue
                    };
                    sc_list_add(aMerges, merge);

                    // DOCS: stopped at next string beginning
                    ++ptr;
                    c = *ptr;
                }

                bpe.aMerges = aMerges;
            }
            else if (sc_string_compare_ext(ptr, "# vocab\n```", 12))
            {
                ptr += 12;
                c = *ptr;

                ScBpeVocabItem* aVocab = NULL;
                while (c != '`')
                {
                    ptr = sc_parse_skip_space(ptr);

                    i64 newLineIndex = sc_string_index_of(ptr, '\n');
                    ScBpeVocabItem vocabItem = {
                        .pValue = sc_string_new_ext(ptr, newLineIndex, newLineIndex)
                    };
                    sc_list_add(aVocab, vocabItem);

                    // DOCS: stopped at next string beginning
                    ptr += newLineIndex;
                    c = *ptr;
                }

                bpe.aVocab = aVocab;
            }
            else
            {
                ++ptr;
                c = *ptr;
            }
            break;
        }

        default:
        {
            ++ptr;
            c = *ptr;
            break;
        }
        }
    }

    return bpe;
}

static void
_sc_ai_write_into_file_ext(const char* pOutFile, const char* pData, i64 dataLength)
{
    sc_file_append_string(pOutFile, (char*)pData, dataLength);
}
static void
_sc_ai_write_into_file(const char* pOutFile, const char* pData)
{
    _sc_ai_write_into_file_ext(pOutFile, (char*)pData, sc_string_get_length((char*)pData));
}

void
sc_ai_bpe_save_to_disk(ScAiBpeSaveToDiskConfig cfg)
{
    if (!cfg.pFilePath)
    {
        sc_log_warn("cfg is invalid!\n");
        return;
    }

    const char* pFilePath = cfg.pFilePath;
    ScProfiler scprf = *(ScProfiler*)cfg.pProfiler;
    i64 totalTextLength = cfg.TotalTextLength;
    ScAiBpe bpe = cfg.Bpe;
    i64 totalLengthCompressed = cfg.TotalTextLengthCompressed;
    f32 ratio = (i64)(((f32)totalLengthCompressed) / totalTextLength * 100);
    i8 c_should_add_text = cfg.ShouldAddText;
    i8 c_should_add_tokens = cfg.ShouldAddTokens;

    char buf[256] = {};
    snprintf(buf, 256, "%s", pFilePath);

    char sbuf[256] = {};
    snprintf(sbuf, 256, "# processing-time: %s\n# compression: %lld/%lld (%0.1f%%)\n", sc_profiler_get_string(&scprf), totalLengthCompressed, totalTextLength, 100 - ratio);
    _sc_ai_write_into_file(buf, sbuf);

    snprintf(sbuf, 256, "# corpus-size %lld\n# vocab-size %lld\n# merges-size %lld\n# tokens-size %lld\n\n", totalTextLength, sc_list_count(bpe.aVocab), sc_list_count(bpe.aMerges), totalLengthCompressed);
    _sc_ai_write_into_file(buf, sbuf);

    _sc_ai_write_into_file(buf, "# merges\n```\n");
    sc_list_for_each(bpe.aMerges, pMerge)
    {
        char mbuf[256] = {};
        snprintf(mbuf, 256, "%d %d %d\n", pMerge->T0, pMerge->T1, pMerge->Tf);
        _sc_ai_write_into_file(buf, mbuf);
    }
    _sc_ai_write_into_file(buf, "\n```\n# end merges\n");

    _sc_ai_write_into_file(buf, "# vocab\n```\n");
    sc_list_for_each(bpe.aVocab, pVocab)
    {
        char mbuf[256] = {};
        snprintf(mbuf, 256, "%s\n", pVocab->pValue);
        _sc_ai_write_into_file(buf, mbuf);
    }
    _sc_ai_write_into_file(buf, "\n```\n# end vocab\n");

    if (c_should_add_text)
    {
        _sc_ai_write_into_file(buf, "# text\n```\n");
        _sc_ai_write_into_file_ext(buf, cfg.pText, totalTextLength);
        _sc_ai_write_into_file(buf, "\n```\n# end text\n");
    }

    if (c_should_add_tokens)
    {
        _sc_ai_write_into_file(buf, "# tokens\n```\n");
        sc_list_for_each(bpe.aTokens, pTokens)
        {
            i32 token = *pTokens;
            if (token != -1337)
            {
                if (token == 259)
                {
                    _sc_ai_write_into_file(buf, "[EOS]\n");
                }
                else
                {
                    char mbuf[256] = {};
                    snprintf(mbuf, 256, "[%d]", token);
                    _sc_ai_write_into_file(buf, mbuf);
                }
            }
        }
        _sc_ai_write_into_file(buf, "\n```\n# end tokens\n");
    }
}

// DOCS: Tokens
i32*
sc_ai_bpe_tokenize(ScAiTokenizeConfig cfg)
{

    return NULL;
}

ScAiBpe
sc_ai_bpe_new2(ScAiBpeConfig cfg)
{
    ScAiBpe scAiBpe = {};

    ScBpeVocabItem* aVocab = NULL;
    ScAiMerge* aMerges = NULL;
    u64* aPairKeys = NULL;

    struct
    {
        i64 Key;
        ScBpeTokenPair Value;
    }* hPairs = NULL;

    for (i32 i = 0; i < 256; ++i)
    {
        char buf[8] = { (char)i };
        ScBpeVocabItem item = {
            .pValue = sc_string_new(buf),
        };
        sc_list_add(aVocab, item);
    }

    for (i32 i = 0; i < 5; ++i)
    {
        const char* names[] = { "<UNK>", "<PAD>", "<BOS>", "<EOS>", "<SEP>" };
        ScBpeVocabItem item = { .pValue = sc_string_new((char*)names[i]) };
        sc_list_add(aVocab, item);
    }

    i64 copyCount = cfg.TextLength;
    i64 mergesCount = cfg.MergesCount;
    g.pSt0 = tokens_array_new(cfg.pText, copyCount);
    g.pSt1 = sc_list_reserve(g.pSt1, copyCount);
    g.pActive = g.pSt0;

    /* DOCS:
        Optimize plan:
        - use hash table for Pairs

        */

    //
    // tokens_find_max_pair()
    //

    i64 vocabCount = sc_list_count(aVocab);

    {
        u32* aTokens = g.pActive;

        i64 fptokensCount = sc_list_count(aTokens) - 1;

        for (i64 i = 0; i < fptokensCount; ++i)
        {
            // DOCS: ignore shit so we dont have to reallocate
            u32 c = aTokens[i];
            if (c >= ScAiSpecialToken_Unk && c <= ScAiSpecialToken_Sep)
                continue;

            u32 nc = aTokens[i + 1];
            if (nc >= ScAiSpecialToken_Unk && nc <= ScAiSpecialToken_Sep)
                continue;

            if (c >= vocabCount || nc >= vocabCount)
                continue;

            u64 ab = (to_u64(c) << 32) | nc;
            i32 isKeyExist = sc_dict_i_contains(hPairs, ab);

            if (isKeyExist)
            {
                // DOCS: Увеличиваем счётчик пары.
                i64 ind = sc_dict_index(hPairs);
                hPairs[ind].Value.Count = ++hPairs[ind].Value.Count;
            }
            else
            {
                ScBpeTokenPair pair = {
                    .A = c,
                    .B = nc,
                    .Count = 1,
                };
                sc_dict_i_add(hPairs, ab, pair);
                sc_list_add(aPairKeys, ab);
            }
        }

        // sc_dict_clear(hPairs);
        // sc_list_clear(aPairKeys);
    }

    for (i32 m = 0; m < mergesCount; ++m)
    {
        u64 pairKey = aPairKeys[0];

        i64 pairKeysCount = sc_list_count(aPairKeys);
        sc_log_info("Pairs count: %d\n", pairKeysCount);
        ScBpeTokenPair maxPair = sc_dict_i_get(hPairs, pairKey);
        for (i64 p = 1; p < pairKeysCount; ++p)
        {
            pairKey = aPairKeys[p];
            ScBpeTokenPair pair = sc_dict_i_get(hPairs, pairKey);
            if (pair.Count > maxPair.Count)
            {
                maxPair = pair;
            }
        }

        if (maxPair.Count <= 1)
        {
            sc_log_warn("прерывание: цикла, дошли до (ручки) maxPair.Count <= 1\n");
            break;
        }
        sc_bpe_token_pair_print(maxPair, m, mergesCount);

        i64 newId = sc_list_count(aVocab);

        ScBpeVocabItem itemA = aVocab[maxPair.A];
        ScBpeVocabItem itemB = aVocab[maxPair.B];

        ScAiMerge merge = { .T0 = maxPair.A, .T1 = maxPair.B, .Tf = newId };
        sc_list_add(aMerges, merge);

        char buf[1024] = {};
        snprintf(buf, 1024, "%s%s", itemA.pValue, itemB.pValue);
        ScBpeVocabItem newVocabItem = { .pValue = sc_string_new(buf) };

        sc_list_add(aVocab, newVocabItem);

        // DOCS: new replacement
        u32* aCopyFrom = NULL;
        u32* aNewTokens = NULL;
        if (g.pActive == g.pSt0)
        {
            aCopyFrom = g.pSt0;
            aNewTokens = g.pSt1;
            g.pActive = g.pSt1;
        }
        else
        {
            aCopyFrom = g.pSt1;
            aNewTokens = g.pSt0;
            g.pActive = g.pSt0;
        }

        i64 copyTokensCount = sc_list_count(aCopyFrom);
        sc_list_header(aNewTokens)->Count = 0;

        // DOCS: последний элемент не может быть t, проверим на t+1
        --copyTokensCount;
        for (i64 t = 0; t < copyTokensCount; ++t)
        {
            u32 token = aCopyFrom[t];
            if (token == maxPair.A && aCopyFrom[t + 1] == maxPair.B)
            {
                sc_list_add(aNewTokens, newId);
                ++t;
            }
            else
            {
                sc_list_add(aNewTokens, token);
            }
        }
    }

    scAiBpe.aTokens = g.pActive;
    scAiBpe.aMerges = aMerges;
    scAiBpe.aVocab = aVocab;

    return scAiBpe;
}

void
sc_bpe_token_pair_print(ScBpeTokenPair pair, i32 done, i32 total)
{
    // char buf[3] = { pair.A, pair.B };
    // sc_log_info("Pair: '%s' -> %d\n", buf, pair.Count);

    i32 ind = 0;
    char buf[1024] = {};

    if ((pair.A >= 32 && pair.A <= 126) || (pair.A >= 0xC0 && pair.A <= 0xFF))
    {
        buf[ind] = (char)pair.A;
        ++ind;
    }
    else
    {
        ind += snprintf(buf, 8, "\\x%02X", pair.A);
    }

    if ((pair.B >= 32 && pair.B <= 126) || (pair.B >= 0xC0 && pair.B <= 0xFF))
    {
        buf[ind] = (char)pair.B;
        ++ind;
    }

    else
    {
        snprintf(buf + ind, 8, "\\x%02X", pair.B);
    }

    ++done;
    char tbuf[32] = {};
    snprintf(tbuf, 32, "%0.1f", done / (f32)total * 100);
    printf("Pair: '%s' -> %d (%d/%d %s)\n", buf, pair.Count, done, total, tbuf);
}
