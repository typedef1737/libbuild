#ifndef SC_WINDOW_H
#define SC_WINDOW_H

#include "Types.h"

#if defined(SC_PLATFORM_LINUX)
#define SC_WINDOW_XCB
#elif defined(SC_PLATFORM_WINDOWS)
#define SC_WINDOW_WIN32
#endif

typedef enum
{
    ScKey_None = -1,

    // DOCS: Numbers
    ScKey_0 = 0,
    ScKey_1 = 1,
    ScKey_2 = 2,
    ScKey_3 = 3,
    ScKey_4 = 4,
    ScKey_5 = 5,
    ScKey_6 = 6,
    ScKey_7 = 7,
    ScKey_8 = 8,
    ScKey_9 = 9,

    // DOCS: Numpad Numbers
    ScKey_NP_0 = 10,
    ScKey_NP_1 = 11,
    ScKey_NP_2 = 12,
    ScKey_NP_3 = 13,
    ScKey_NP_4 = 14,
    ScKey_NP_5 = 15,
    ScKey_NP_6 = 16,
    ScKey_NP_7 = 17,
    ScKey_NP_8 = 18,
    ScKey_NP_9 = 19,

    // DOCS: Numpad Keys
    ScKey_NP_Lock = 20,
    ScKey_NP_Div = 21,
    ScKey_NP_Mul = 22,
    ScKey_NP_Min = 23,
    ScKey_NP_Add = 24,
    ScKey_NP_Enter = 25,
    ScKey_NP_Comma = 26,

    // DOCS: Upper right panel
    ScKey_PrintScreen = 27,
    ScKey_ScrollLock = 28,
    ScKey_PauseBreak = 29,

    // DOCS: Mid right panel
    ScKey_Insert = 30,
    ScKey_Delete = 31,
    ScKey_Home = 32,
    ScKey_End = 33,
    ScKey_PageUp = 34,
    ScKey_PageDown = 35,
    ScKey_CapsLock = 36,

    // DOCS: Lower right panel
    ScKey_Up = 37,
    ScKey_Left = 38,
    ScKey_Down = 39,
    ScKey_Right = 40,

    // DOCS: Characters

    ScKey_Q = 41,
    ScKey_W = 42,
    ScKey_E = 43,
    ScKey_R = 44,
    ScKey_T = 45,
    ScKey_Y = 46,
    ScKey_U = 47,
    ScKey_I = 48,
    ScKey_O = 49,
    ScKey_P = 50,

    ScKey_A = 51,
    ScKey_S = 52,
    ScKey_D = 53,
    ScKey_F = 54,
    ScKey_G = 55,
    ScKey_H = 56,
    ScKey_J = 57,
    ScKey_K = 58,
    ScKey_L = 59,

    ScKey_Z = 60,
    ScKey_X = 61,
    ScKey_C = 62,
    ScKey_V = 63,
    ScKey_B = 64,
    ScKey_N = 65,
    ScKey_M = 66,

    // DOCS: Functional
    ScKey_Grave = 67, /* ' */
    ScKey_Min = 68,
    ScKey_Equal = 69, // +/=
    ScKey_Tab = 70,
    ScKey_Shift = 71,
    ScKey_Ctrl = 72,
    ScKey_Alt = 73,
    ScKey_Super = 74,
    ScKey_Space = 75,

    ScKey_Comma = 76,
    ScKey_Dot = 77,
    ScKey_Slash = 78, /*/*/

    ScKey_Shift_Right = 79,
    ScKey_Alt_Right = 80,
    ScKey_Ctrl_Right = 81,
    ScKey_Super_Right = 82,
    ScKey_Command_Right = 83,

    ScKey_Escape = 84,

    // DOCS: Press F
    ScKey_F1 = 85,
    ScKey_F2 = 86,
    ScKey_F3 = 87,
    ScKey_F4 = 88,
    ScKey_F5 = 89,
    ScKey_F6 = 90,
    ScKey_F7 = 91,
    ScKey_F8 = 92,
    ScKey_F9 = 93,
    ScKey_F10 = 94,
    ScKey_F11 = 95,
    ScKey_F12 = 96,

    // DOCS: Extra
    ScKey_Bracket_Left = 97,  /* [ */
    ScKey_Bracket_Right = 98, /* ] */
    ScKey_Semicolon = 99,     /* ; */
    ScKey_Apostrophe = 100,   /* ' */
    ScKey_Backslash = 101,    /* \ */
    ScKey_Enter = 102,

    ScKey_F13 = 103,
    ScKey_F14 = 104,
    ScKey_F15 = 105,
    ScKey_F16 = 106,
    ScKey_F17 = 107,
    ScKey_F18 = 108,
    ScKey_F19 = 109,
    ScKey_F20 = 110,
    ScKey_F21 = 111,
    ScKey_F22 = 112,
    ScKey_F23 = 113,
    ScKey_F24 = 114,
    ScKey_F25 = 115,

    ScKey_Backspace = 116,
    ScKey_Menu,

    ScKey_Undefined,
    ScKey_Count
} ScKey;

typedef enum
{
    ScMouseKey_None = 0,
    ScMouseKey_Left,
    ScMouseKey_Right,
    ScMouseKey_Middle,

    ScMouseKey_Ext_0,
    ScMouseKey_Ext_1,
    ScMouseKey_Ext_2,
    ScMouseKey_Ext_3,
    ScMouseKey_Ext_4,
    ScMouseKey_Ext_5,
    ScMouseKey_Ext_6,
    ScMouseKey_Ext_7,
    ScMouseKey_Ext_8,
    ScMouseKey_Ext_9,

    ScMouseKey_Count,
} ScMouseKey;

typedef enum
{
    ScKeyMod_None = 0,

    ScKeyMod_Alt = 1 << 1,
    ScKeyMod_Super = 1 << 2,
    ScKeyMod_Ctrl = 1 << 3,
    ScKeyMod_Shift = 1 << 4,
    ScKeyMod_CapsLock = 1 << 5,
    ScKeyMod_NumLock = 1 << 6,

    ScKeyMod_Count,
} ScKeyMod;

typedef enum
{
    ScCursorMode_Normal = 0,
    ScCursorMode_Hidden = 1,
    ScCursorMode_Locked = 2,
    ScCursorMode_Count
} ScCursorMode;

typedef enum
{
    ScAction_None = -1,
    ScAction_Press = 1,
    ScAction_Release = 2,
    ScAction_Repeat = 3,
    ScAction_Count = 4,
} ScAction;

//////                               //
//              Window               //
//                               //////

typedef struct
{
    const char* pName;
    i32 NameLength;
    i32 UseGraphics;
    v2 Size;
    v2 MinSize;
    v2 MaxSize;
    v2 Position;
} ScWindowConfig;

typedef enum
{
    ScEventType_None = 0,

    ScEventType_KeyType,
    ScEventType_KeyPress,
    ScEventType_KeyRelease,
    ScEventType_MousePress,
    ScEventType_MouseRelease,
    ScEventType_KeyboardMapping,

    ScEventType_MouseMove,
    ScEventType_MouseScroll,

    ScEventType_WindowMoved,
    ScEventType_WindowResized,
    ScEventType_WindowClosed,

    ScEventType_WindowMaximized,
    ScEventType_WindowFocused,
    ScEventType_WindowEnter,
    ScEventType_WindowHidden,

    ScEventType_Count,
} ScEventType;

typedef struct
{
    i32 IsHandled;
    ScEventType Type;
} ScEvent;

typedef struct
{
    ScEvent Base;
    i32 Focused;
} ScWindowFocusedEvent;

typedef struct
{
    ScEvent Base;
    i32 IsInside;
} ScWindowEnterEvent;

typedef struct
{
    ScEvent Base;
} ScWindowMaximizedEvent;

typedef struct
{
    ScEvent Base;
} ScWindowHiddenEvent;

typedef struct
{
    ScEvent Base;
    ScKey Key;
    ScKeyMod KeyMod;
} ScKeyPressEvent;

typedef struct
{
    ScEvent Base;
    u32 CodePoint;
} ScKeyTypeEvent;

typedef struct
{
    ScEvent Base;
    ScKey Key;
    ScKeyMod KeyMod;
} ScKeyReleaseEvent;

typedef struct
{
    ScEvent Base;
    ScMouseKey Key;
} ScMousePressEvent;

typedef struct
{
    ScEvent Base;
    i32 Value;
} ScMouseScrollEvent;

typedef struct
{
    ScEvent Base;
    ScMouseKey Key;
} ScMouseReleaseEvent;

typedef struct
{
    ScEvent Base;
    i32 X;
    i32 Y;
} ScMouseMoveEvent;

typedef struct
{
    ScEvent Base;
} ScKeyboardMappingEvent;

typedef struct
{
    ScEvent Base;
    i32 Width;
    i32 Height;
} ScWindowResizeEvent;

typedef struct
{
    ScEvent Base;
    v2 Position;
} ScWindowPositionEvent;

typedef struct
{
    ScEvent Base;
} ScWindowCloseEvent;

typedef void (*ScCall)(ScEvent*);

typedef struct
{
    i32 Width;
    i32 Height;
} ScResolution;

typedef struct
{
    i32 Count;
    ScResolution* aResolutions;
} ScResolutions;

typedef struct
{
    i8 IsAlive;
    i8 IsMaximized;
    i8 IsFullscreen;
    i8 IsGrabed;
    i8 aKeyCounter[ScKey_Count];

    const char* pName;
    v2 Size;
    v2 MinSize;
    v2 MaxSize;
    v2 Position;
    v2 Mouse;
    ScCall OnEvent;
    ScAction aKeys[ScKey_Count];
    ScAction aMouseKeys[ScMouseKey_Count];
    void* pBackend;
    void* pGraphics;
} ScWindow;

// todo: ScInitSettings wo IsInitialized

typedef struct
{
    i32 IsInitialized;
    void* (*MemoryAllocate)(u64 size);
    void (*MemoryFree)(void* pData);
} ScInit;

void sc_window_create(ScWindow* pScWindow, ScWindowConfig set);
void sc_window_destroy(ScWindow* pWindow);
void sc_window_update(ScWindow* pWindow);
void sc_window_set_event_call(ScWindow* pWindow, ScCall call);
ScKey sc_key_from_native(i32 native);
void sc_window_set_title(ScWindow* pWindow, char* pTitle);
void sc_window_set_headless(ScWindow* pWindow, i32 isSet);
void sc_window_set_fullscreen(ScWindow* pWindow, i32 isSet);
/* DOCS: Set window above other, work on linux, windows wm is stupid */
void sc_window_set_above(ScWindow* pWindow, i32 isSet);
void sc_window_set_grabed_ext(ScWindow* pWindow, i32 flag);
void sc_window_set_cursor_visibilite(ScWindow* pWindow, i32 isVisible);
void sc_window_set_cursor_position(ScWindow* pWindow, i32 x, i32 y);
void sc_window_set_position(ScWindow* pWindow, i32 x, i32 y);

//////                               //
//            XCB Window             //
//                               //////

void* xcb_sc_window_get_window(ScWindow* pWindow);
void* xcb_sc_window_get_connection(ScWindow* pWindow);

//////                               //
//            WIN32 Window           //
//                               //////

void* win32_sc_window_get_window(ScWindow* pWindow);
void* win32_sc_window_get_connection(ScWindow* pWindow);

//////                               //
//             Graphics              //
//                               //////

typedef struct
{
    void* pData;
    u16 Width;
    u16 Height;
} ScWindowBuffer;

void sc_window_graphics_init(ScWindow* pWindow);
void sc_window_graphics_resize(ScWindow* pWindow);
ScWindowBuffer sc_window_graphics_get_buffer(ScWindow* pWindow);
void sc_window_graphics_swap_buffers(ScWindow* pWindow);
void sc_window_graphics_clear_color(ScWindow* pWindow, u32 color);
void sc_window_graphics_draw_line(ScWindow* pWindow, i32 x0, i32 y0, i32 x1, i32 y1, u32 color);

//////                               //
//       DOCS: Utils & Helpers       //
//                               //////

const char* sc_window_key_to_string(ScKey key);
const char* sc_mouse_key_to_string(ScMouseKey key);
ScKeyMod sc_key_mod_from_native(i32 native);
const char* sc_event_type_to_string(ScEventType type);
i32 sc_window_key_is_printable(ScKey key);

static ScKey
sc_window_key_press(ScEvent* pEvent)
{
    ScEventType type = pEvent->Type;
    if (type != ScEventType_KeyPress)
        return ScKey_None;

    ScKeyPressEvent* pKeyEvent = (ScKeyPressEvent*)pEvent;
    if (pKeyEvent->Base.IsHandled)
        return ScKey_None;

    return pKeyEvent->Key;
}

static ScKey
sc_window_key_release(ScEvent* pEvent)
{
    ScEventType type = pEvent->Type;
    if (type != ScEventType_KeyRelease)
        return ScKey_None;

    ScKeyReleaseEvent* pKeyEvent = (ScKeyReleaseEvent*)pEvent;
    if (pKeyEvent->Base.IsHandled)
        return ScKey_None;

    return pKeyEvent->Key;
}

static ScMouseKey
sc_window_mouse_press(ScEvent* pEvent)
{
    ScEventType type = pEvent->Type;
    if (type != ScEventType_MousePress)
        return ScMouseKey_None;

    ScMousePressEvent* pMouse = (ScMousePressEvent*)pEvent;
    if (pMouse->Base.IsHandled)
        return ScMouseKey_None;

    return pMouse->Key;
}

static ScMouseKey
sc_window_mouse_release(ScEvent* pEvent)
{
    ScEventType type = pEvent->Type;
    if (type != ScEventType_MouseRelease)
        return ScMouseKey_None;

    ScMouseReleaseEvent* pMouse = (ScMouseReleaseEvent*)pEvent;
    if (pMouse->Base.IsHandled)
        return ScMouseKey_None;

    return pMouse->Key;
}

#endif // SC_WINDOW_H
