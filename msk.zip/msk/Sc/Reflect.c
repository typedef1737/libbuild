#include "Reflect.h"
#include "Sc/Sc.h"

void
sc_reflect_register_type_ext(ScReflect* pReflect, ScReflectTypeConfig cfg)
{
    if (!pReflect)
    {
        sc_log_warn("sc_reflect_register_type_ext: pReflect is NULL!\n");
        return;
    }

    if (!cfg.pName)
    {
        sc_log_warn("sc_reflect_register_type_ext: type name is NULL!\n");
        return;
    }

    if (cfg.Size == 0)
    {
        sc_log_warn("sc_reflect_register_type_ext: type '%s' size is zero!\n", cfg.pName);
        return;
    }

    if (sc_dict_s_contains(pReflect->hReg, cfg.pName))
    {
        sc_log_warn("Type '%s' is already registered!\n", cfg.pName);
        return;
    }

    ScReflectType type = (ScReflectType) {
        .pName = cfg.pName,
        .Size = cfg.Size,
        .aFields = ScNull,
    };

    // DOCS: Копируем поля в список, чтобы реестр не зависел от
    // времени жизни ScReflectTypeConfig.aFieldInfos.
    // NOTE: Для простых типов (i32, f32, ...) полей нет -> aFields == NULL.
    if (cfg.aFieldInfos && cfg.FieldInfoCount > 0)
    {
        type.aFields = (ScReflectFieldInfo*)sc_list_add_multiple_ext(
            ScNull,
            cfg.aFieldInfos,
            sizeof(ScReflectFieldInfo),
            cfg.FieldInfoCount);
    }

    sc_dict_s_add(pReflect->hReg, type.pName, type);
}

ScReflectType
sc_reflect_get_type_ext(ScReflect* pReflect, const char* pName)
{
    ScReflectType empty = (ScReflectType) {};

    if (!pReflect || !pName)
    {
        sc_log_warn("sc_reflect_get_type_ext: wrong arguments!\n");
        return empty;
    }

    if (!sc_dict_s_contains(pReflect->hReg, pName))
    {
        sc_log_warn("Type '%s' is not registered!\n", pName);
        return empty;
    }

    i64 ind = sc_dict_index(pReflect->hReg);
    if (ind < 0)
    {
        sc_log_warn("Wrong index value!\n");
        return empty;
    }

    ScReflectType type = pReflect->hReg[ind].Value;
    return type;
}

void
sc_reflect_free(ScReflect* pReflect)
{
    if (!pReflect || !pReflect->hReg)
        return;

    // DOCS: Освобождаем списки полей каждого зарегистрированного типа.
    ScReflectEntry* aEntries = (ScReflectEntry*)pReflect->hReg;
    ScDictHeader* pHdr = sc_dict_header(pReflect->hReg);
    for (i32 i = 0; i < pHdr->Capacity; ++i)
    {
        if (!aEntries[i].Key)
            continue;

        sc_list_free(aEntries[i].Value.aFields);
    }

    sc_dict_free(pReflect->hReg);
    pReflect->hReg = ScNull;
}
