#include "Ecs.h"
#include "Sc.h"
#include <string.h>

typedef struct
{
    ScEcsComponentId Id;
    u64 Offset;
} ScEcsComponent;

typedef struct
{
    // NOTE: mb create bitset for many flags..
    i8 IsAlive;
    bitset512 Mask;
    ScEcsComponent* aComponents;
} ScEcsEntity;

typedef struct
{
    ScEcsEntityId NextId;
    ScEcsEntityId* aDeletedEntities;
    ScEcsEntity* aEntities;
} ScEcsEntityStorage;

typedef struct
{
    const char* pName;
    u64 Size;
    i64* aFreeOffset;
    void* pData;
} ScEcsComponentRecord;

typedef struct
{
    ScEcsComponentId NextId;
    struct
    {
        const char* Key;
        ScEcsComponentId Value;
    }* hNameToId;
    ScEcsComponentRecord* aComponentRecords;
} ScEcsComponentStorage;

typedef struct
{
    ScEcsEntityStorage EntityStorage;
    ScEcsComponentStorage ComponentStorage;
} ScEcsWorld;

static struct
{
    ScEcsWorld* pWorld;
} g = {};

static ScEcsEntity* sc_ecs_entity_by_id(ScEcsEntityId id);
static ScEcsComponentRecord* sc_ecs_component_record_by_id_and_size(ScEcsComponentId id, u64 size);

//                   World

void
sc_ecs_world_create()
{
    if (g.pWorld)
        return;

    ScEcsWorld world = {
        .EntityStorage = {
            .NextId = ScEcsEntityBeginId,
        },

        .ComponentStorage = {
            .NextId = ScEcsComponentBeginId,
        },
    };

    g.pWorld = (ScEcsWorld*)sc_memory_allocate(sizeof(ScEcsWorld));
    memcpy(g.pWorld, &world, sizeof(ScEcsWorld));
}

void
sc_ecs_world_destroy()
{
    if (!g.pWorld)
        return;

    ScEcsWorld* pWorld = g.pWorld;

    // DOCS: Free per-component data before freeing the records list.
    ScEcsComponentRecord* aComponentRecords = pWorld->ComponentStorage.aComponentRecords;
    i64 componentCount = sc_list_count(aComponentRecords);
    for (i64 c = 0; c < componentCount; ++c)
    {
        sc_list_free(aComponentRecords[c].aFreeOffset);
        sc_list_free(aComponentRecords[c].pData);
    }
    sc_list_free(aComponentRecords);

    sc_dict_free(pWorld->ComponentStorage.hNameToId);

    sc_list_free(pWorld->EntityStorage.aDeletedEntities);
    sc_list_free(pWorld->EntityStorage.aEntities);

    sc_memory_free(pWorld);
    g.pWorld = NULL;
}

i32
sc_ecs_world_register_component_ext(const char* pComponentName, u64 componentSize)
{
    if (!pComponentName)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_world_register_component_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return 0;
    }

    if (componentSize == 0)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_world_register_component_ext: Component size is zero!\n");
#endif // SC_ECS_DEBUG
        return 0;
    }

    ScEcsWorld* pWorld = g.pWorld;
    i32 isAlreadyRegistered = sc_dict_s_contains(pWorld->ComponentStorage.hNameToId, pComponentName);
    if (isAlreadyRegistered)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("Trying register component %s that already registered !\n", pComponentName);
#endif // SC_ECS_DEBUG
        return 0;
    }

    ScEcsComponentRecord component = {
        .pName = pComponentName,
        .Size = componentSize,
    };

    ScEcsComponentId nextId = pWorld->ComponentStorage.NextId;
    sc_dict_s_add(pWorld->ComponentStorage.hNameToId, pComponentName, nextId);
    sc_list_add(pWorld->ComponentStorage.aComponentRecords, component);
    ++pWorld->ComponentStorage.NextId;

    return 1;
}

void*
sc_ecs_world_get_all_components_ext(const char* pComponent)
{
    if (!pComponent)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_world_get_all_components_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return NULL;
    }

    ScEcsWorld* pWorld = g.pWorld;
    ScEcsComponentId componentId = sc_ecs_component_name_to_id(pComponent);
    if (componentId == ScEcsInvalidId)
    {
        return NULL;
    }

    // todo: validate component id
    i64 componentIndex = sc_ecs_component_id_to_index(componentId);
    ScEcsComponentRecord* pRecord = &pWorld->ComponentStorage.aComponentRecords[componentIndex];
    void* pData = pRecord->pData;

    return pData;
}

// DOCS: trim logic, ignoring whitespaces
static void
_ecs_component_trim(char* pBuf, char* pStr, i32 len)
{
    i32 cind = 0;
    for (i32 c = 0; c < len; ++c)
    {
        char ch = pStr[c];
        // note: skip double comma "comp0,,comp1"
        if (!sc_char_is_whitespace(ch) && ch != ',')
        {
            pBuf[cind] = ch;
            ++cind;
        }
    }
}

static bitset512
sc_ecs_components_with_separator_to_ids(const char* pComponentsWithSeparator)
{
    bitset512 bitset = {};
    char* pBuf = (char*)pComponentsWithSeparator;
    i32 ind = 0;

    while (1)
    {
        ind = sc_string_index_of(pBuf, ',');
        if (ind != -1)
        {
            // todo: Add max length of component name to api..
            char buf[1024] = {};
            _ecs_component_trim(buf, pBuf, ind);

            ScEcsComponentId componentId = sc_ecs_component_name_to_id(buf);
            if (componentId != ScEcsInvalidId)
            {
                i64 componentIndex = sc_ecs_component_id_to_index(componentId);
                sc_bitset_set_1(bitset.Mask, sc_bits_count(bitset), componentIndex);
            }

            pBuf += ind + 1;
        }
        else
        {
            char buf[1024] = {};
            _ecs_component_trim(buf, pBuf, sc_string_get_length(pBuf));
            ScEcsComponentId componentId = sc_ecs_component_name_to_id(buf);
            if (componentId != ScEcsInvalidId)
            {
                i64 componentIndex = sc_ecs_component_id_to_index(componentId);
                sc_bitset_set_1(bitset.Mask, sc_bits_count(bitset), componentIndex);
            }
            break;
        }
    }

    return bitset;
}

void*
sc_ecs_world_get_all_component_data_ext(const char* pComponent)
{
    if (!pComponent)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_world_get_all_component_data_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return NULL;
    }

    ScEcsWorld* pWorld = g.pWorld;

    ScEcsComponentId componentId = sc_ecs_component_name_to_id(pComponent);
    if (componentId == ScEcsInvalidId)
    {
        return NULL;
    }

    i64 componentIndex = sc_ecs_component_id_to_index(componentId);
    ScEcsComponentRecord componentRecord = pWorld->ComponentStorage.aComponentRecords[componentIndex];

    void* pData = componentRecord.pData;

    return pData;
}

ScEcsEntityId*
sc_ecs_world_get_all_entity_ids_ext(const char* pComponentsWithSeparator)
{
    if (!pComponentsWithSeparator)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_world_get_all_entity_ids_ext: Components list is NULL!\n");
#endif // SC_ECS_DEBUG
        return NULL;
    }

    ScEcsEntityId* aEntities = NULL;

    bitset512 componentBitset = sc_ecs_components_with_separator_to_ids(pComponentsWithSeparator);
    i32 bitsCount = sc_bits_count(componentBitset);

    ScEcsWorld* pWorld = g.pWorld;
    i64 entitiesCount = sc_list_count(pWorld->EntityStorage.aEntities);

    for (i64 e = 0; e < entitiesCount; ++e)
    {
        ScEcsEntity* pEntity = &pWorld->EntityStorage.aEntities[e];

        if (!pEntity->IsAlive)
            continue;

        if (!sc_bitset_contains(pEntity->Mask.Mask, bitsCount, componentBitset.Mask, bitsCount))
            continue;

        ScEcsEntityId entityId = sc_ecs_entity_index_to_id(e);
        sc_list_add(aEntities, entityId);
    }

    return aEntities;
}

//                   Entity

ScEcsEntityId
sc_ecs_entity_new()
{
    ScEcsWorld* pWorld = g.pWorld;

    ScEcsEntityId scEntityId = pWorld->EntityStorage.NextId;
    if (scEntityId >= ScEcsEntityEndId)
    {
        sc_log_erro("End of entity id!\n");
        return ScEcsInvalidId;
    }

    ScEcsEntity emptyEntity = {
        .IsAlive = 1,
    };
    sc_list_add(pWorld->EntityStorage.aEntities, emptyEntity);
    ++pWorld->EntityStorage.NextId;

    return scEntityId;
}

void
sc_ecs_entity_destroy(ScEcsEntityId id)
{
    ScEcsWorld* pWorld = g.pWorld;
    ScEcsEntity* pEntity = sc_ecs_entity_by_id(id);
    if (!pEntity)
    {
        return;
    }

    if (!pEntity->IsAlive)
    {
        return;
    }

    // DOCS: Reclaim component data offsets and free the components list.
    i64 componentsCount = sc_list_count(pEntity->aComponents);
    for (i64 c = 0; c < componentsCount; ++c)
    {
        ScEcsComponent component = pEntity->aComponents[c];
        i64 componentIndex = sc_ecs_component_id_to_index(component.Id);
        ScEcsComponentRecord* pComponentRecord = &pWorld->ComponentStorage.aComponentRecords[componentIndex];
        sc_list_add(pComponentRecord->aFreeOffset, component.Offset / pComponentRecord->Size);
    }
    sc_list_free(pEntity->aComponents);

    memset(pEntity, 0, sizeof(ScEcsEntity));
    sc_list_add(pWorld->EntityStorage.aDeletedEntities, id);
}

i32
sc_ecs_entity_set_ext(ScEcsEntityId entity, const char* pComponentName, void* pData, u64 size)
{
    if (!pComponentName)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_set_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return 0;
    }

    ScEcsComponentId compId = sc_ecs_component_name_to_id(pComponentName);
    return sc_ecs_entity_set_by_id_ext(entity, compId, pData, size);
}

i32
sc_ecs_entity_has_ext(ScEcsEntityId entityId, const char* pComponentName)
{
    if (!pComponentName)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_has_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return 0;
    }

    ScEcsComponentId componentId = sc_ecs_component_name_to_id(pComponentName);
    return sc_ecs_entity_has_by_id_ext(entityId, componentId);
}

i32
sc_ecs_entity_set_by_id_ext(ScEcsEntityId entityId, ScEcsComponentId componentId, void* pData, u64 size)
{
    ScEcsWorld* pWorld = g.pWorld;

    // DOCS: Validate id before ussage
    if (sc_ecs_component_id_validate(componentId) == 0)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_set_by_id_ext: Id validation was failed entity: %ld component: %ld!\n", entityId, componentId);
#endif // SC_ECS_DEBUG
        return 0;
    }

    // DOCS: Validate data only. Size is validated inside sc_ecs_component_record_by_id_and_size
    if (pData == NULL)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_set_by_id_ext: Component data is NULL!\n");
#endif // SC_ECS_DEBUG
        return 0;
    }

    // DOCS: Get entity + Validation
    ScEcsEntity* pEntity = sc_ecs_entity_by_id(entityId);
    if (!pEntity)
    {
        return 0;
    }

    if (!pEntity->IsAlive)
    {
        return 0;
    }

    // DOCS: Get component + Validation
    ScEcsComponentRecord* pComponentRecord = sc_ecs_component_record_by_id_and_size(componentId, size);
    if (!pComponentRecord)
    {
        return 0;
    }

    i64 componentIndex = sc_ecs_component_id_to_index(componentId);

    // DOCS: Component already exists - update data at existing offset
    if (sc_bitset_get(pEntity->Mask.Mask, sc_bits_count(pEntity->Mask), componentIndex))
    {
        i32 ind = sc_list_index_of(pEntity->aComponents, item.Id == componentId);
        if (ind != -1)
        {
            u64 offset = pEntity->aComponents[ind].Offset;
            memcpy((char*)pComponentRecord->pData + offset, pData, size);
            return 1;
        }
    }

    // DOCS: Add record about this new component to Component's Records storage.
    i64 componentOffset = 0;
    i64 cnt = sc_list_count(pComponentRecord->aFreeOffset);
    if (cnt > 0)
    {
        componentOffset = sc_list_pop(pComponentRecord->aFreeOffset);
        memcpy((char*)pComponentRecord->pData + componentOffset*size, pData, size);
    }
    else
    {
        componentOffset = sc_list_count(pComponentRecord->pData);
        pComponentRecord->pData = sc_list_add_ext(pComponentRecord->pData, pData, size);
    }

    // DOCS: Add component to entity.
    ScEcsComponent component = {
        .Id = componentId,
        .Offset = componentOffset * size
    };
    sc_list_add(pEntity->aComponents, component);

    // DOCS: Setting bitmask for optimization
    sc_bitset_set_1(pEntity->Mask.Mask, sc_bits_count(pEntity->Mask), componentIndex);

    return 1;
}

i32
sc_ecs_entity_has_by_id_ext(ScEcsEntityId entityId, ScEcsComponentId componentId)
{
    if (sc_ecs_component_id_validate(componentId) == 0)
    {
        return 0;
    }

    ScEcsEntity* pEntity = sc_ecs_entity_by_id(entityId);
    if (!pEntity)
    {
        return 0;
    }

    if (!pEntity->IsAlive)
    {
        return 0;
    }
    i64 componentIndex = sc_ecs_component_id_to_index(componentId);
    u8 bit = sc_bitset_get(pEntity->Mask.Mask, sc_bits_count(pEntity->Mask), componentIndex);
    return bit;
}

void*
sc_ecs_entity_get_ext(ScEcsEntityId entityId, const char* pComponent)
{
    if (!pComponent)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_get_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return NULL;
    }

    ScEcsComponentId componentId = sc_ecs_component_name_to_id(pComponent);
    return sc_ecs_entity_get_by_id_ext(entityId, componentId);
}

void*
sc_ecs_entity_get_by_id_ext(ScEcsEntityId entityId, ScEcsComponentId componentId)
{
    if (sc_ecs_component_id_validate(componentId) == 0)
    {
        return NULL;
    }

    ScEcsWorld* pWorld = g.pWorld;
    ScEcsEntity* pEntity = sc_ecs_entity_by_id(entityId);
    if (!pEntity)
    {
        return NULL;
    }

    if (!pEntity->IsAlive)
    {
        return NULL;
    }

    i64 componentIndex = sc_ecs_component_id_to_index(componentId);
    i32 ind = sc_list_index_of(pEntity->aComponents, item.Id == componentId);
    if (ind == -1)
    {
#if defined SC_ECS_DEBUG
        sc_log_warn("sc_ecs_entity_get_by_id_ext: entity %ld has no component %s with id %d\n", entityId, pWorld->ComponentStorage.aComponentRecords[componentIndex].pName, componentId);
        sc_assert_break();
#endif // SC_ECS_DEBUG
        return NULL;
    }

    ScEcsComponentRecord componentRecord = pWorld->ComponentStorage.aComponentRecords[componentIndex];
    u64 componentOffset = pEntity->aComponents[ind].Offset;
    void* pData = (void*)((char*)componentRecord.pData + componentOffset);
    return pData;
}

i32
sc_ecs_entity_remove_component_ext(ScEcsEntityId id, const char* pComponentName)
{
    if (!pComponentName)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_remove_component_ext: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return 0;
    }

    ScEcsWorld* pWorld = g.pWorld;

    if (!sc_ecs_entity_id_validate(id))
    {
        return 0;
    }

    i64 entityIndex = sc_ecs_entity_id_to_index(id);
    ScEcsEntity* pEntity = &pWorld->EntityStorage.aEntities[entityIndex];
    if (!pEntity->IsAlive)
    {
        return 0;
    }

    ScEcsComponentId componentId = sc_ecs_component_name_to_id(pComponentName);
    if (componentId == ScEcsInvalidId)
    {
        return 0;
    }

    i64 componentIndex = sc_ecs_component_id_to_index(componentId);
    if (!sc_bitset_get(pEntity->Mask.Mask, sc_bits_count(pEntity->Mask), componentIndex))
    {
        return 0;
    }

    i64 entityCompIndex = sc_list_index_of(pEntity->aComponents, item.Id == componentId);
    if (entityCompIndex == -1)
    {
        return 0;
    }
    u64 componentOffset = pEntity->aComponents[entityCompIndex].Offset;

    ScEcsComponentRecord* pComponentRecord = &pWorld->ComponentStorage.aComponentRecords[componentIndex];

    // DOCS: set data to 0;
    u64 componentSize = pComponentRecord->Size;
    void* pComponentData = pComponentRecord->pData + componentOffset;
    memset(pComponentData, 0, componentSize);

    // DOCS: add to recycle list
    sc_list_add(pComponentRecord->aFreeOffset, componentOffset / componentSize);

    // DOCS: remove from entity
    sc_bitset_set_0(pEntity->Mask.Mask, sc_bits_count(pEntity->Mask), componentIndex);
    sc_list_remove_index(pEntity->aComponents, entityCompIndex);

    return 1;
}

static ScEcsEntity*
sc_ecs_entity_by_id(ScEcsEntityId id)
{
    if (sc_ecs_entity_id_validate(id) == 0)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_by_id: Id validation was failed %ld!\n", id);
#endif // SC_ECS_DEBUG
        return NULL;
    }

    i64 entityIndex = sc_ecs_entity_id_to_index(id);
    ScEcsEntity* pEntity = &g.pWorld->EntityStorage.aEntities[entityIndex];
    return pEntity;
}

static ScEcsComponentRecord*
sc_ecs_component_record_by_id_and_size(ScEcsComponentId id, u64 size)
{
    // DOCS: Validate id before ussage
    if (sc_ecs_component_id_validate(id) == 0)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_component_by_id: Id validation was failed %ld!\n", id);
#endif // SC_ECS_DEBUG
        return NULL;
    }

    i64 componentIndex = sc_ecs_component_id_to_index(id);
    ScEcsEntity validationEntity = {};
    if (componentIndex >= sc_bits_count(validationEntity.Mask))
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_entity_set_by_id_ext: Component Index out of bound of ScEcsEntity.Mask, you should increase mask size and change ScEcsComponentEndId preprocessor value to bigger one!\n");
#endif
        return NULL;
    }

    ScEcsComponentRecord* pComponentRecord = &g.pWorld->ComponentStorage.aComponentRecords[componentIndex];
    // DOCS: Validate size of passed component.
    if (pComponentRecord->Size != size)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_component_record_by_id_and_size(..., u64 size <- invalid size!!!)\n");
#endif
        return NULL;
    }

    return pComponentRecord;
}

//            Component / Entities Ids

ScEcsComponentId
sc_ecs_component_name_to_id(const char* pName)
{
    if (!pName)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_component_name_to_id: Component name is NULL!\n");
#endif // SC_ECS_DEBUG
        return ScEcsInvalidId;
    }

    ScEcsWorld* pWorld = g.pWorld;

    i64 contains = sc_dict_s_contains(pWorld->ComponentStorage.hNameToId, (char*)pName);
    if (!contains)
    {
        sc_log_warn("Component(%s) not registered!\n", pName);
        return ScEcsInvalidId;
    }

    i32 ind = sc_dict_index(pWorld->ComponentStorage.hNameToId);
    ScEcsComponentId id = pWorld->ComponentStorage.hNameToId[ind].Value;

    return id;
}

const char*
sc_ecs_component_id_to_name(ScEcsComponentId id)
{
    if (sc_ecs_component_id_validate(id) == 0)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_component_id_to_name: Id validation was failed %ld!\n", id);
#endif // SC_ECS_DEBUG
        return NULL;
    }

    ScEcsWorld* pWorld = g.pWorld;

    i64 ind = sc_ecs_component_id_to_index(id);
    ScEcsComponentRecord* aRecs = pWorld->ComponentStorage.aComponentRecords;
    i64 cnt = sc_list_count(aRecs);

    if (ind < 0 || ind >= cnt)
    {
        sc_log_warn("Component(%d) not registered!\n", id);
        return NULL;
    }

    ScEcsComponentRecord rec = aRecs[ind];
    const char* pName = rec.pName;

    return pName;
}

u64
sc_ecs_component_size(ScEcsComponentId id)
{
    if (sc_ecs_component_id_validate(id) == 0)
    {
#if defined(SC_ECS_DEBUG)
        sc_log_warn("sc_ecs_component_size: Id validation was failed %ld!\n", id);
#endif // SC_ECS_DEBUG
        return 0;
    }

    ScEcsWorld* pWorld = g.pWorld;

    i64 ind = sc_ecs_component_id_to_index(id);
    i64 cnt = sc_list_count(pWorld->ComponentStorage.aComponentRecords);

    if (ind < 0 || ind >= cnt)
    {
        sc_log_warn("Component(%d) not registered!\n", id);
        return 0;
    }

    return pWorld->ComponentStorage.aComponentRecords[ind].Size;
}

i32
sc_ecs_components_count()
{
    if (!g.pWorld)
    {
        return 0;
    }

    return (i32)sc_list_count(g.pWorld->ComponentStorage.aComponentRecords);
}

i32
sc_ecs_entity_id_validate(ScEcsEntityId id)
{
    return ((id >= ScEcsEntityBeginId) && (id < ScEcsEntityEndId));
}

i32
sc_ecs_component_id_validate(ScEcsComponentId id)
{
    return ((id >= ScEcsComponentBeginId) && (id < ScEcsComponentEndId));
}

i64
sc_ecs_entity_id_to_index(ScEcsEntityId id)
{
#if defined(SC_ECS_DEBUG)
    sc_assert(sc_ecs_entity_id_validate(id) && "Entity id validation!");
#endif
    return id - ScEcsEntityBeginId;
}

i64
sc_ecs_component_id_to_index(ScEcsComponentId id)
{
#if defined(SC_ECS_DEBUG)
    sc_assert(sc_ecs_component_id_validate(id) && "Component id validation!");
#endif
    return id - ScEcsComponentBeginId;
}

ScEcsEntityId
sc_ecs_entity_index_to_id(i64 index)
{
#if defined(SC_ECS_DEBUG)
    i32 validIndex = ((index >= 0) && (index < sc_list_count(g.pWorld->EntityStorage.aEntities)));
    sc_assert(validIndex && "sc_ecs_entity_index_to_id: Entity id validation!");
#endif
    return index + ScEcsEntityBeginId;
}

ScEcsComponentId
sc_ecs_component_index_to_id(i64 index)
{
#if defined(SC_ECS_DEBUG)
    i32 validIndex = ((index >= 0) && (index < sc_list_count(g.pWorld->ComponentStorage.aComponentRecords)));
    sc_assert(validIndex && "sc_ecs_component_index_to_id: Component id validation!");
#endif
    return index + ScEcsComponentBeginId;
}

/*

1. Working with get_all_entities API:

Entities* aEntities = get_all_entities();
for (entity in aEntities) {
   for (component in entity.aComponents) {
     if (component.Id == g.PozyId){
       Pozy* pPozy = (Pozy*) get_component(component);
       // do the work
     }

   }
   get_component_by(entity.a, ...)
}

Get/GetAll - for all or single
sc_ecs_world_get_entity()
sc_ecs_world_get_entities()
Usage:
```c
ScEcsEntity* pEntity = sc_ecs_world_get_entity(playerEntity);
```

Filter - for array with condition
sc_ecs_world_where_entities()
Usage:
```c
ScEcsEntity* aEntities = sc_ecs_world_where_entities(Pozy, HumanComponent);
```
*/
