#ifndef SC_AI_H
#define SC_AI_H

#include "Types.h"

/*
- Токенизация методом BPE

*/

typedef struct
{
    char* pText;
    i64 TextLength;
    i64 MergesCount;
} ScAiBpeConfig;

typedef struct
{
    char* pValue;
} ScBpeVocabItem;

typedef struct
{
    u32 A;
    u32 B;
    i32 Count;
} ScBpeTokenPair;

typedef struct
{
    u32 T0;
    u32 T1;
    u32 Tf;
} ScAiMerge;

typedef enum
{
    ScAiSpecialToken_Unk = 256,
    ScAiSpecialToken_Pad = 257,
    ScAiSpecialToken_Bos = 258,
    ScAiSpecialToken_Eos = 259,
    ScAiSpecialToken_Sep = 260
} ScAiSpecialToken;

typedef struct
{
    u32* aTokens;
    ScAiMerge* aMerges;
    ScBpeVocabItem* aVocab;
} ScAiBpe;

typedef struct
{
    ScAiBpe Bpe;
    void* pProfiler;
    i64 TotalTextLength;
    i64 TotalTextLengthCompressed;
    char* pFilePath;

    char* pText;
    i8 ShouldAddText;
    i8 ShouldAddTokens;
} ScAiBpeSaveToDiskConfig;

typedef struct
{
    char* pText;
    i64 TextLength;
    ScAiBpe Bpe;
} ScAiTokenizeConfig;

// DOCS: Create and learn bpe-tokenizer
ScAiBpe sc_ai_bpe_new(ScAiBpeConfig cfg);
// DOCS: More optimized tokenizer, wip (Create and learn bpe-tokenizer)
ScAiBpe sc_ai_bpe_new2(ScAiBpeConfig cfg);

// DOCS: save to disk
void sc_ai_bpe_save_to_disk(ScAiBpeSaveToDiskConfig cfg);
// DOCS: Load *.bpe file from disk
ScAiBpe sc_ai_bpe_load_from_disk(char* pFile);
// DOCS: Load bpe data from memory
ScAiBpe sc_ai_bpe_load_from_memory(char* pData, i64 dataSize);

// DOCS: Debug utils
void sc_bpe_token_pair_print(ScBpeTokenPair pair, i32 done, i32 total);

#endif // SC_AI_H
