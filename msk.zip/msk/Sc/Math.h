#ifndef SC_MATH_H
#define SC_MATH_H

#include "Types.h"
#include <math.h>

// DOCS: Include for debug printing
#if defined(SC_BUILD_DEBUG)
#include <stdio.h>
#endif // SC_BUILD_DEBUG

// NOTE: not sure we need this hack for Windows.
#if defined(SC_PLATFORM_WINDOWS)
#undef near
#undef far
#endif // SC_PLATFORM_WINDOWS

/*
  DOCS:  CONSTANTS
*/

#define REAL_CUSTOM_EPSILON 1E-5f

// e
#define ScMathE 2.71828182845904523536028747135266250
// log2(e)
#define ScMathLog2E 1.44269504088896340735992468100189214
// log10(e)
#define ScmathLog10E 0.434294481903251827651128918916605082
// loge(2)
#define ScMathLn2 0.693147180559945309417232121458176568
// loge(10)
#define ScMathLn10 2.30258509299404568401799145468436421
// pi
#define ScMathPi 3.14159265358979323846264338327950288
// pi/2
#define ScMathPiDiv2 1.57079632679489661923132169163975144
// pi/4
#define ScMathPiDiv4 0.785398163397448309615660845819875721
#define ScMathPiDiv5 0.628318530717958647692528676655900576
// 1/pi
#define ScMath1DivPi 0.318309886183790671537767526745028724
// 2/pi
#define ScMath2DivPi 0.636619772367581343075535053490057448
// 2/sqrt(pi)
#define ScMath2DivSqrtPi 1.12837916709551257389615890312154517
// sqrt(2)
#define ScMathSqrt2 1.41421356237309504880168872420969808
// 1/sqrt(2)
#define ScMath1DivSqrt2 0.707106781186547524400844362104849039

#define ScMathRad360 (2 * ScMathPi)
#define ScMathRad180 ScMathPi
#define ScMathRad90 ScMathPiDiv2

force_inline i32
i32_pow(i32 x, i32 n)
{
    if (n == 0 || x == 1)
        return 1;
    i32 result;
    for (result = 1; n > 0; --n)
        result *= x;
    return result;
}

#define real_pow2(x) ({ x* x; })
#define sc_is_sign_equal(x, y) ({ ((x * y) >= 0) ? 1 : 0; })

/*
  DOCS(typedef): isqrt(x) = 1/sqrt(x)

  v2 v;
  v.X *= isqrt(v.X);
  v.Y *= isqrt(v.Y);
*/
force_inline real
isqrt(real number)
{
    const real threehalfs = 1.5f;

    real x2 = number * 0.5f;
    real y = number;
    /*
      NOTE(typedef): getting bit representation of float
      it's equals to log(y) + error_rate (very small, can ignore this)
    */
    i32 i = *((i32*)&y);
    /*
      NOTE(): calc -1/2 * log(y)
    */
    i = -(i >> 1);
    /*
      NOTE(): bitshift ratio
    */
    i = 0x5f3759df + i;

    y = *((real*)&i);

    /*
      NOTE(): newton's method for approximation, it's get y,
      calculate f(y), f'(y), then to calculate offset from result
      real result = y - f(y)/f'(y)

      x - original number

      f(y) = 1/y^2 - x
      f'(y) = -2/y^3
      y_new = y - f(y)/f'(y)
      = y + (1/y^2 - x)*y^3/2
      = 1.5*y - 0.5*xy^3
      = y*(1.5 - 0.5*xy^2)
    */
    y = y * (threehalfs - (x2 * y * y));

    return y;
}

force_inline real
real_abs(real value)
{
#if defined(SC_FLOAT_32_BIT)
    value = sc_f32_abs(value);
    return value;
#else
    return fabs(value);
#endif
}

force_inline i32
real_equal(real a, real b)
{
    return (real_abs(a - b) <= REAL_CUSTOM_EPSILON);
}
force_inline i32
real_equal_epsilon(real a, real b, real eps)
{
    return (real_abs(a - b) <= eps);
}

force_inline real
real_sqrt(real v)
{
#if defined(SC_FLOAT_32_BIT)
    v = sqrtf(v);
    return v;
#else
    v = sqrt(v);
    return v;
#endif
}

force_inline real
sc_math_radians_to_degrees(real radians)
{
    const real c_radians_to_degrees = (180.0 / ScMathPi);
    return c_radians_to_degrees * radians;
}

force_inline real
sc_math_degrees_to_radians(real degrees)
{
    const real c_degrees_to_radians = (ScMathPi / 180.0);
    return c_degrees_to_radians * degrees;
}

force_inline i32
ROUND_MAX(real value)
{
    return (i32)(value + 1);
}
force_inline i32
ROUND_MIN(real value)
{
    return (i32)(value - 1);
}

/*

  ###################################
  ###################################
  V2.h
  ###################################
  ###################################

*/

force_inline i32
v2_equal_zero(v2 v)
{
    return v.X == 0 && v.Y == 0;
}

force_inline real
v2_dot(v2 a, v2 b)
{
    return a.X * b.X + a.Y * b.Y;
}

force_inline real
v2_skew(v2 a, v2 b)
{
    return a.X * b.Y + a.Y * b.X;
}

force_inline v2
v2_perpendicular_clock_wise(v2 a)
{
    return v2_new(a.Y, -a.X);
}
force_inline v2
v2_perpendicular_counter_clock_wise(v2 a)
{
    return v2_new(-a.Y, a.X);
}

force_inline real
v2_length(v2 v)
{
    return real_sqrt(v2_dot(v, v));
}

force_inline real
v2_distance2(v2 a, v2 b)
{
    real distance = real_pow2(a.X - b.X) + real_pow2(a.Y - b.Y);
    return distance;
}

force_inline real
v2_distance(v2 a, v2 b)
{
    real distance = real_sqrt(v2_distance2(a, b));
    return distance;
}

force_inline real
v2_distance_pow(v2 a, v2 b)
{
    real distance = real_pow2(a.X - b.X) + real_pow2(a.Y - b.Y);
    return distance;
}

force_inline v2
v2_normalize(v2 v)
{
    real length = v2_length(v);
    if (length == 0.0f)
    {
        return v;
    }
    v.X /= length;
    v.Y /= length;
    return v;
}

force_inline v2
v2_copy(v2 b)
{
    v2 result;
    result.X = b.X;
    result.Y = b.Y;
    return result;
}

force_inline v2
v2_add(v2 a, v2 b)
{
    return v2_new(a.X + b.X, a.Y + b.Y);
}
force_inline v2
v2_add_x(v2 a, real x)
{
    return v2_new(a.X + x, a.Y);
}
force_inline v2
v2_add_y(v2 a, real y)
{
    return v2_new(a.X, a.Y + y);
}

force_inline v2
v2_addi(v2 a, v2i b)
{
    return v2_new(a.X + b.X, a.Y + b.Y);
}

force_inline v2
v2_sub(v2 a, v2 b)
{
    v2 result;
    result.X = a.X - b.X;
    result.Y = a.Y - b.Y;
    return result;
}

force_inline v2
v2_sub_x(v2 a, real x)
{
    return v2_new(a.X - x, a.Y);
}

force_inline v2
v2_sub_y(v2 a, real y)
{
    return v2_new(a.X, a.Y - y);
}

force_inline v2
v2_sub_yr(v2 a, real y)
{
    return v2_new(a.X, y - a.Y);
}

force_inline v2
v2_mul(v2 a, v2 b)
{
    v2 result;
    result.X = a.X * b.X;
    result.Y = a.Y * b.Y;
    return result;
}

force_inline v2
v2_div(v2 a, v2 b)
{
    v2 result;
    result.X = a.X / b.X;
    result.Y = a.Y / b.Y;
    return result;
}

force_inline v2
v2_addv(v2 a, real num)
{
    v2 result;
    result.X = a.X - num;
    result.Y = a.Y - num;
    return result;
}

force_inline v2
v2_subv(v2 a, real num)
{
    v2 result;
    result.X = a.X - num;
    result.Y = a.Y - num;
    return result;
}

force_inline v2
v2_mulv(v2 a, real num)
{
    a.X *= num;
    a.Y *= num;
    return a;
}

force_inline v2
v2_divv(v2 a, real num)
{
    v2 result;
    result.X = a.X / num;
    result.Y = a.Y / num;
    return result;
}

/* Convertation */
force_inline v2
v2_v4(v4 a)
{
    v2 v;
    v.X = a.X;
    v.Y = a.Y;
    return v;
}

force_inline i32
v2_equal_epsilon(v2 a, v2 b, real epsilon)
{
    real dx = (a.X - b.X);
    real dy = (a.Y - b.Y);
    if (dx < 0)
        dx = -dx;
    if (dy < 0)
        dy = -dy;

    return (dx < epsilon) && (dy < epsilon);
}

force_inline i32
v2_not_equal_epsilon(v2 a, v2 b, real epsilon)
{
    i32 result = (v2_equal_epsilon(a, b, epsilon) == 0);
    return result;
}

/*
  NOTE(bies):
  Description:
  Get direction of OBJECT relative to EYE, by using EYE.FORWARD

  Args:
  Object  - position in world space of object
  Eye     - position that is origin
  Forward - normalized v2 forward vector

  Return:
  1  - forward
  -1 - backward
  0  - on one line
*/
force_inline i32
v2_get_direction(v2 object, v2 eye, v2 forward)
{
    v2 distance = v2_sub(object, eye);
    i32 isInForward = v2_dot(distance, forward) > 0;
    return isInForward;
}

/*
  NOTE(bies):
  Description:
  Get direction of OBJECT relative to EYE, by using EYE.PERPENDECULAR_CW

  Args:
  Object  - position in world space of object
  Eye     - position that is origin

  Return:
  1  - right
  -1 - left
  0  - forward
*/
force_inline i32
v2_is_right_direction(v2 object, v2 eye)
{
    v2 distance = v2_sub(object, eye);
    i32 isInRight = v2_dot(distance, v2_perpendicular_clock_wise(eye)) > 0;
    return isInRight;
}

force_inline v2
v2_lerpx(v2 start, v2 end, real percent)
{
    real sx = start.X;
    real ex = end.X;

    real diff;
    if (sx > ex)
    {
        diff = sx - ex;
    }
    else
    {
        diff = ex - sx;
    }

    v2 v = v2_new(diff * percent, start.Y);
    return v;
}

/*

  ###################################
  ###################################
  V3.h
  ###################################
  ###################################

*/

force_inline i32
v3_equal_zero(v3 v)
{
    return v.X == 0 && v.Y == 0 && v.Z == 0;
}

// DOCS: Checked and corrected
force_inline v3
v3_to_degree(v3 v)
{
    v.X = sc_math_radians_to_degrees(v.X);
    v.Y = sc_math_radians_to_degrees(v.Y);
    v.Z = sc_math_radians_to_degrees(v.Z);
    return v;
}

force_inline v3
v3_array_negative(real* arr)
{
    v3 v;
    v.X = -arr[0];
    v.Y = -arr[1];
    v.Z = -arr[2];
    return v;
}

force_inline v3
v3_invert(v3 v)
{
    v.X = -v.X;
    v.Y = -v.Y;
    v.Z = -v.Z;
    return v;
}

force_inline real
v3_length(v3 v)
{
    return real_sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
}
force_inline real
v3_length_array(real v[3])
{
    return real_sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

force_inline real
v3_dot(v3 a, v3 b)
{
    return a.X * b.X + a.Y * b.Y + a.Z * b.Z;
}

force_inline v3
v3_cross(v3 a, v3 b)
{
    v3 dest;
    dest.X = a.Y * b.Z - a.Z * b.Y;
    dest.Y = a.Z * b.X - a.X * b.Z;
    dest.Z = a.X * b.Y - a.Y * b.X;
    return dest;
}

force_inline v3
v3_normalize(v3 v)
{
    real length = v3_length(v);
    if (length == 0.0f)
    {
        return v;
    }

    v3 dest;
    dest.X = v.X / length;
    dest.Y = v.Y / length;
    dest.Z = v.Z / length;
    return dest;
}
force_inline v3
v3_cross_normalized(v3 a, v3 b)
{
    v3 cross = v3_cross(a, b);
    v3 normalizedCross = v3_normalize(cross);
    return normalizedCross;
}

force_inline real
v3_distance(v3 a, v3 b)
{
    real distance = real_sqrt(real_pow2(a.X - b.X) + real_pow2(a.Y - b.Y) + real_pow2(a.Z - b.Z));
    return distance;
}

force_inline real
v3_distance2(v3 a, v3 b)
{
    real distance = real_pow2(a.X - b.X) + real_pow2(a.Y - b.Y) + real_pow2(a.Z - b.Z);
    return distance;
}
force_inline real
v3_distance_pow(v3 a, v3 b)
{
    return v3_distance2(a, b);
}

force_inline v3
v3_negative(v3 v)
{
    v3 dest;
    dest.X = -v.X;
    dest.Y = -v.Y;
    dest.Z = -v.Z;
    return dest;
}
force_inline v3
v3_negativec(real x, real y, real z)
{
    v3 dest;
    dest.X = -x;
    dest.Y = -y;
    dest.Z = -z;
    return dest;
}

force_inline v3
v3_negative_to(v3 v)
{
    v3 dest;
    dest.X = -v.X;
    dest.Y = -v.Y;
    dest.Z = -v.Z;
    return dest;
}

force_inline v3
v3_copy(v3 b)
{
    v3 dest;
    dest.X = b.X;
    dest.Y = b.Y;
    dest.Z = b.Z;
    return dest;
}

/*
  Arithmetic's operations
*/
force_inline v3
v3_add(v3 a, v3 b)
{
    v3 v;
    v.X = a.X + b.X;
    v.Y = a.Y + b.Y;
    v.Z = a.Z + b.Z;
    return v;
}

force_inline v3
v3_addx(v3 a, real x)
{
    return v3_new(a.X + x, a.Y, a.Z);
}

force_inline v3
v3_addy(v3 a, real y)
{
    return v3_new(a.X, a.Y + y, a.Z);
}

force_inline v3
v3_addz(v3 a, real z)
{
    return v3_new(a.X, a.Y, a.Z + z);
}

force_inline v3
v3_sub(v3 a, v3 b)
{
    v3 v;
    v.X = a.X - b.X;
    v.Y = a.Y - b.Y;
    v.Z = a.Z - b.Z;
    return v;
}

force_inline v3
v3_sub_x(v3 a, real x)
{
    v3 v;
    v.X = a.X - x;
    v.Y = a.Y;
    v.Z = a.Z;
    return v;
}
force_inline v3
v3_sub_y(v3 a, real y)
{
    v3 v;
    v.X = a.X;
    v.Y = a.Y - y;
    v.Z = a.Z;
    return v;
}
force_inline v3
v3_sub_z(v3 a, real z)
{
    v3 v;
    v.X = a.X;
    v.Y = a.Y;
    v.Z = a.Z - z;
    return v;
}

force_inline v3
v3_mul(v3 a, v3 b)
{
    v3 v;
    v.X = a.X * b.X;
    v.Y = a.Y * b.Y;
    v.Z = a.Z * b.Z;
    return v;
}
force_inline v3
v3_scale(v3 a, real num)
{
    v3 v;
    v.X = a.X * num;
    v.Y = a.Y * num;
    v.Z = a.Z * num;
    return v;
}

force_inline v3
v3_div(v3 a, v3 b)
{
    v3 v;
    v.X = a.X / b.X;
    v.Y = a.Y / b.Y;
    v.Z = a.Z / b.Z;
    return v;
}

force_inline v3
v3_addv(v3 b, real num)
{
    v3 v;
    v.X = b.X + num;
    v.Y = b.Y + num;
    v.Z = b.Z + num;
    return v;
}

force_inline v3
v3_subv(v3 b, real num)
{
    v3 v;
    v.X = b.X - num;
    v.Y = b.Y - num;
    v.Z = b.Z - num;
    return v;
}

force_inline v3
v3_mulv(v3 b, real num)
{
    v3 v;
    v.X = b.X * num;
    v.Y = b.Y * num;
    v.Z = b.Z * num;
    return v;
}
force_inline v4
v3_mulv_as_v4(v3 b, real num)
{
    v4 v;
    v.X = b.X * num;
    v.Y = b.Y * num;
    v.Z = b.Z * num;
    v.W = 0.0f;
    return v;
}
force_inline void
v3_mulv_ref(real dest[3], v3 b, real num)
{
    dest[0] = b.X * num;
    dest[1] = b.Y * num;
    dest[2] = b.Z * num;
}

force_inline v3
v3_divv(v3 b, real num)
{
    v3 v;
    v.X = b.X - num;
    v.Y = b.Y - num;
    v.Z = b.Z - num;
    return v;
}

force_inline v3
v3_negate(v3 v)
{
    v.X = -v.X;
    v.Y = -v.Y;
    v.Z = -v.Z;
    return v;
}

/*

  ###################################
  ###################################
  V4.h
  ###################################
  ###################################

*/

force_inline i32
v4_is_direction(v4 v)
{
    return (v.W == 0) ? 1 : 0;
}

force_inline i32
v4_is_position(v4 v)
{
    return (v.W == 1) ? 1 : 0;
}

force_inline v4
v4_copy(v4 src)
{
    v4 dest;
    dest.X = src.X;
    dest.Y = src.Y;
    dest.Z = src.Z;
    dest.W = src.W;
    return dest;
}
force_inline void
v4a_copy(v4a dest, v4a src)
{
    dest[0] = src[0];
    dest[1] = src[1];
    dest[2] = src[2];
    dest[3] = src[3];
}

force_inline void
v4_assignv(v4 a, real x, real y, real z, real w)
{
    a.X = x;
    a.Y = y;
    a.Z = z;
    a.W = w;
}

force_inline real
v4_length(v4 v)
{
    return real_sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
}

force_inline real
v4_distance(v4 a, v4 b)
{
    real distance = real_sqrt(real_pow2(a.X - b.X) + real_pow2(a.Y - b.Y) + real_pow2(a.Z - b.Z) + real_pow2(a.W - b.W));
    return distance;
}

force_inline real
v4_distance2(v4 a, v4 b)
{
    real distance2 = real_pow2(a.X - b.X) + real_pow2(a.Y - b.Y) + real_pow2(a.Z - b.Z) + real_pow2(a.W - b.W);
    return distance2;
}

force_inline v4
v4_negative(v4 v)
{
    v4 dest;
    dest.X = -v.X;
    dest.Y = -v.Y;
    dest.Z = -v.Z;
    dest.W = -v.W;
    return dest;
}

force_inline v4
v4_normalize(v4 v)
{
    v4 dest = {};
    real length = v4_length(v);
    if (length == 0.0f)
        return dest;

    dest.X = v.X / length;
    dest.Y = v.Y / length;
    dest.Z = v.Z / length;
    dest.W = v.W / length;

    return dest;
}

force_inline v4
v4_add(v4 a, v4 b)
{
    v4 v;
    v.X = a.X + b.X;
    v.Y = a.Y + b.Y;
    v.Z = a.Z + b.Z;
    v.W = a.W + b.W;
    return v;
}

force_inline v4
v4_addv(v4 a, real num)
{
    v4 v;
    v.X = a.X + num;
    v.Y = a.Y + num;
    v.Z = a.Z + num;
    v.W = a.W + num;
    return v;
}

force_inline v4
v4_sub(v4 a, v4 b)
{
    v4 v;
    v.X = a.X - b.X;
    v.Y = a.Y - b.Y;
    v.Z = a.Z - b.Z;
    v.W = a.W - b.W;
    return v;
}

force_inline v4
v4_subv(v4 a, real num)
{
    v4 v;
    v.X = a.X - num;
    v.Y = a.Y - num;
    v.Z = a.Z - num;
    v.W = a.W - num;
    return v;
}

force_inline v4
v4_mul(v4 a, v4 b)
{
    v4 v;
    v.X = a.X * b.X;
    v.Y = a.Y * b.Y;
    v.Z = a.Z * b.Z;
    v.W = a.W * b.W;
    return v;
}

force_inline v4
v4_mulv(v4 a, real num)
{
    v4 v;
    v.X = a.X * num;
    v.Y = a.Y * num;
    v.Z = a.Z * num;
    v.W = a.W * num;
    return v;
}

force_inline v4
v4_scale(v4 dest, real num)
{
    return v4_mulv(dest, num);
}
force_inline void
v4a_scale(real a[4], real num, real dest[4])
{
    dest[0] = a[0] * num;
    dest[1] = a[1] * num;
    dest[2] = a[2] * num;
    dest[3] = a[3] * num;
}
force_inline v4
v4_scale_array(real v[4], real num)
{
    v4 r;
    r.X = v[0] * num;
    r.Y = v[1] * num;
    r.Z = v[2] * num;
    r.W = v[3] * num;
    return r;
}

force_inline v4
v4_div(v4 a, v4 b)
{
    v4 v;
    v.X = a.X / b.X;
    v.Y = a.Y / b.Y;
    v.Z = a.Z / b.Z;
    v.W = a.W / b.W;
    return v;
}

force_inline real
v4_dot(v4 a, v4 b)
{
    return a.X * b.X + a.Y * b.Y + a.Z * b.Z + a.W * b.W;
}

force_inline v4
v4_negate(v4 v)
{
    v.X = -v.X;
    v.Y = -v.Y;
    v.Z = -v.Z;
    v.W = -v.W;
    return v;
}

force_inline v4
v4_lerp(v4 from, v4 to, real t)
{
    /* from + s * (to - from) */
    real val = ScMinMax(t, 0.0, 1.0f);
    v4 diff = v4_sub(to, from);
    diff = v4_scale(diff, val);
    v4 offsetFrom = v4_add(from, diff);

    return offsetFrom;
}

force_inline v4
v4_rgba(u8 r, u8 g, u8 b, u8 a)
{
    f32 ratio = 1 / 255.0f;
    return v4_new(r * ratio, g * ratio, b * ratio, a * ratio);
}
force_inline v4
v4_rgb(u8 r, u8 g, u8 b)
{
    f32 ratio = 1 / 255.0f;
    return v4_new(r * ratio, g * ratio, b * ratio, 1);
}

force_inline v4
v4_v(f32 s)
{
    f32 ratio = 1 / 255.0f;
    f32 sv = s * ratio;
    return v4_new(sv, sv, sv, 1);
}

/*

  ###################################
  ###################################
  M3.h
  ###################################
  ###################################

*/
force_inline m3
m3_array(real* array)
{
    m3 m;
    m.M00 = array[0];
    m.M01 = array[1];
    m.M02 = array[2];
    m.M10 = array[4];
    m.M11 = array[5];
    m.M12 = array[6];
    m.M20 = array[8];
    m.M21 = array[9];
    m.M22 = array[10];
    return m;
}
force_inline m3
m3_double_array(m3a array)
{
    m3 m;
    m.M00 = array[0][0];
    m.M01 = array[0][1];
    m.M02 = array[0][2];
    m.M10 = array[1][0];
    m.M11 = array[1][1];
    m.M12 = array[1][2];
    m.M20 = array[2][0];
    m.M21 = array[2][1];
    m.M22 = array[2][2];
    return m;
}
force_inline m3
m3_m4(m4 a)
{
    m3 m;
    m.M00 = a.M[0][0];
    m.M01 = a.M[0][1];
    m.M02 = a.M[0][2];
    m.M10 = a.M[1][0];
    m.M11 = a.M[1][1];
    m.M12 = a.M[1][2];
    m.M20 = a.M[2][0];
    m.M21 = a.M[2][1];
    m.M22 = a.M[2][2];
    return m;
}

force_inline m3
m3_t(m3 a)
{
    m3 r;

    r.M00 = a.M00;
    r.M01 = a.M10;
    r.M02 = a.M20;

    r.M10 = a.M01;
    r.M11 = a.M11;
    r.M12 = a.M21;

    r.M20 = a.M02;
    r.M21 = a.M12;
    r.M22 = a.M22;

    return r;
}

force_inline m3
m3_mul(m3 m1, m3 m2)
{
    m3 r;
    real l00 = m1.M00, l01 = m1.M01, l02 = m1.M02,
         l10 = m1.M10, l11 = m1.M11, l12 = m1.M12,
         l20 = m1.M20, l21 = m1.M21, l22 = m1.M22,
         r00 = m2.M00, r01 = m2.M01, r02 = m2.M02,
         r10 = m2.M10, r11 = m2.M11, r12 = m2.M12,
         r20 = m2.M20, r21 = m2.M21, r22 = m2.M22;

    r.M00 = l00 * r00 + l10 * r01 + l20 * r02;
    r.M01 = l01 * r00 + l11 * r01 + l21 * r02;
    r.M02 = l02 * r00 + l12 * r01 + l22 * r02;
    r.M10 = l00 * r10 + l10 * r11 + l20 * r12;
    r.M11 = l01 * r10 + l11 * r11 + l21 * r12;
    r.M12 = l02 * r10 + l12 * r11 + l22 * r12;
    r.M20 = l00 * r20 + l10 * r21 + l20 * r22;
    r.M21 = l01 * r20 + l11 * r21 + l21 * r22;
    r.M22 = l02 * r20 + l12 * r21 + l22 * r22;
    return r;
}

force_inline v3
m3_mul_v3(m3 m1, v3 v)
{
    v3 r;
    real l00 = m1.M00, l01 = m1.M01, l02 = m1.M02,
         l10 = m1.M10, l11 = m1.M11, l12 = m1.M12,
         l20 = m1.M20, l21 = m1.M21, l22 = m1.M22;

    r.X = l00 * v.X + l10 * v.Y + l20 * v.Z;
    r.Y = l01 * v.X + l11 * v.Y + l21 * v.Z;
    r.Z = l02 * v.X + l12 * v.Y + l22 * v.Z;
    return r;
}

force_inline m3
m3_mul_v(m3 m, real v)
{
    m3 r;

    r.M00 = v * m.M00;
    r.M01 = v * m.M01;
    r.M02 = v * m.M02;

    r.M10 = v * m.M10;
    r.M11 = v * m.M11;
    r.M12 = v * m.M12;

    r.M20 = v * m.M20;
    r.M21 = v * m.M21;
    r.M22 = v * m.M22;

    return r;
}

force_inline m3
m3_copy(m3 a)
{
    m3 b;
    b.M00 = a.M00;
    b.M01 = a.M01;
    b.M02 = a.M02;
    b.M10 = a.M10;
    b.M11 = a.M11;
    b.M12 = a.M12;
    b.M20 = a.M20;
    b.M21 = a.M21;
    b.M22 = a.M22;
    return b;
}

force_inline real
m3_det(m3 a)
{
    real result;

    /*
        |a00 a01 a02|
      a33 = |a10 a11 a12|
        |a20 a21 a22|
    */

    // DOCS: Calculate minors
    real m00 = a.M00 * ((a.M11 * a.M22) - (a.M12 * a.M21));
    real m01 = (-1 * a.M01) * ((a.M10 * a.M22) - (a.M12 * a.M20));
    real m02 = a.M02 * ((a.M10 * a.M21) - (a.M11 * a.M20));

    result = m00 + m01 + m02;

    return result;
}

force_inline m3
m3_adj(m3 a)
{
    m3 r = (m3) {
        +1,
        -1,
        +1,
        -1,
        +1,
        -1,
        +1,
        -1,
        +1,
    };

    /*
      DOCS: Signs
           |m00 m01 m02|   |+ - +|
      adj(a) = |m10 m11 m12| * |- + -|
           |m20 m21 m22|   |+ - +|
           , where m00 - is det minor00

      m00 = |m11 m12| = (m11 * m22) - (m12 * m21)
        |m21 m22|
    */

    real m00 = (a.M11 * a.M22) - (a.M12 * a.M21);
    real m01 = (a.M10 * a.M22) - (a.M12 * a.M20);
    real m02 = (a.M10 * a.M21) - (a.M11 * a.M20);
    real m10 = (a.M01 * a.M22) - (a.M02 * a.M21);
    real m11 = (a.M00 * a.M22) - (a.M02 * a.M20);
    real m12 = (a.M00 * a.M21) - (a.M01 * a.M20);
    real m20 = (a.M01 * a.M12) - (a.M02 * a.M11);
    real m21 = (a.M00 * a.M12) - (a.M02 * a.M10);
    real m22 = (a.M00 * a.M11) - (a.M01 * a.M10);

    r.M00 *= m00;
    r.M01 *= m01;
    r.M02 *= m02;
    r.M10 *= m10;
    r.M11 *= m11;
    r.M12 *= m12;
    r.M20 *= m20;
    r.M21 *= m21;
    r.M22 *= m22;

    return r;
}

force_inline m3
m3_inverse(m3 a)
{
    m3 r;

    real det = m3_det(a);
    if (real_equal(det, 0.0f))
        return a;

    m3 aT = m3_t(a);
    m3 adj = m3_adj(aT);

    r = m3_mul_v(adj, 1 / det);

    return r;
}

/*

  ###################################
  ###################################
  M4.h
  ###################################
  ###################################

*/
force_inline m4
m4_m3_array(real array[4][4])
{
    m4 m;
    m.M00 = array[0][0];
    m.M01 = array[0][1];
    m.M02 = array[0][2];
    m.M03 = 0.0f;
    m.M10 = array[1][0];
    m.M11 = array[1][1];
    m.M12 = array[1][2];
    m.M13 = 0.0f;
    m.M20 = array[2][0];
    m.M21 = array[2][1];
    m.M22 = array[2][2];
    m.M23 = 0.0f;
    m.M30 = 0.0f;
    m.M31 = 0.0f;
    m.M32 = 0.0f;
    m.M33 = 1.0f;
    return m;
}
force_inline m4
m4_array(real* array)
{
    m4 m;
    m.M00 = array[0];
    m.M01 = array[1];
    m.M02 = array[2];
    m.M03 = array[3];
    m.M10 = array[4];
    m.M11 = array[5];
    m.M12 = array[6];
    m.M13 = array[7];
    m.M20 = array[8];
    m.M21 = array[9];
    m.M22 = array[10];
    m.M23 = array[11];
    m.M30 = array[12];
    m.M31 = array[13];
    m.M32 = array[14];
    m.M33 = array[15];
    return m;
}
force_inline m4
m4_double_array(m4a a)
{
    m4 m;
    m.M00 = a[0][0];
    m.M01 = a[0][1];
    m.M02 = a[0][2];
    m.M03 = a[0][3];
    m.M10 = a[1][0];
    m.M11 = a[1][1];
    m.M12 = a[1][2];
    m.M13 = a[1][3];
    m.M20 = a[2][0];
    m.M21 = a[2][1];
    m.M22 = a[2][2];
    m.M23 = a[2][3];
    m.M30 = a[3][0];
    m.M31 = a[3][1];
    m.M32 = a[3][2];
    m.M33 = a[3][3];
    return m;
}

force_inline m4
m4_identity()
{
    m4 m;
    m.M00 = 1.0f;
    m.M01 = 0.0f;
    m.M02 = 0.0f;
    m.M03 = 0.0f;
    m.M10 = 0.0f;
    m.M11 = 1.0f;
    m.M12 = 0.0f;
    m.M13 = 0.0f;
    m.M20 = 0.0f;
    m.M21 = 0.0f;
    m.M22 = 1.0f;
    m.M23 = 0.0f;
    m.M30 = 0.0f;
    m.M31 = 0.0f;
    m.M32 = 0.0f;
    m.M33 = 1.0f;
    return m;
}

force_inline m4
m4_copy(m4 a)
{
    m4 b;
    b.M00 = a.M00;
    b.M01 = a.M01;
    b.M02 = a.M02;
    b.M03 = a.M03;
    b.M10 = a.M10;
    b.M11 = a.M11;
    b.M12 = a.M12;
    b.M13 = a.M13;
    b.M20 = a.M20;
    b.M21 = a.M21;
    b.M22 = a.M22;
    b.M23 = a.M23;
    b.M30 = a.M30;
    b.M31 = a.M31;
    b.M32 = a.M32;
    b.M33 = a.M33;
    return b;
}
force_inline m4
m4_copy_array(real array[16])
{
    m4 b;
    b.M00 = array[0];
    b.M01 = array[1];
    b.M02 = array[2];
    b.M03 = array[3];
    b.M10 = array[4];
    b.M11 = array[5];
    b.M12 = array[6];
    b.M13 = array[7];
    b.M20 = array[8];
    b.M21 = array[9];
    b.M22 = array[10];
    b.M23 = array[11];
    b.M30 = array[12];
    b.M31 = array[13];
    b.M32 = array[14];
    b.M33 = array[15];
    return b;
}

// NOTE(bies): don't think we ever need m4_set_value function
force_inline m4
m4_zero()
{
    m4 m = {};
    return m;
}

force_inline m4
m4_rotation_matrix(v3 axis, real angle)
{
    m4 m;

    real angleCos = cosf(angle);
    real angleSin = sinf(angle);
    v3 axisNormalized = v3_normalize(axis);

    v3 vCos = v3_mulv(axisNormalized, 1.0f - angleCos);
    m.V[0] = v3_mulv_as_v4(axisNormalized, vCos.X);
    m.V[1] = v3_mulv_as_v4(axisNormalized, vCos.Y);
    m.V[2] = v3_mulv_as_v4(axisNormalized, vCos.Z);

    v3 vSin = v3_mulv(axisNormalized, angleSin);
    m.M00 += angleCos;
    m.M01 += vSin.Z;
    m.M02 -= vSin.Y;
    m.M03 = 0.0f;
    m.M10 -= vSin.Z;
    m.M11 += angleCos;
    m.M12 += vSin.X;
    m.M13 = 0.0f;
    m.M20 += vSin.Y;
    m.M21 -= vSin.X;
    m.M22 += angleCos;
    m.M23 = 0.0f;
    m.M30 = 0.0f;
    m.M31 = 0.0f;
    m.M32 = 0.0f;
    m.M33 = 1.0f;
    return m;
}

force_inline m4
m4_mul_real(m4 m, real v)
{
    m4 r;
    r.M00 = v * m.M00;
    r.M01 = v * m.M01;
    r.M02 = v * m.M02;
    r.M03 = v * m.M03;

    r.M10 = v * m.M10;
    r.M11 = v * m.M11;
    r.M12 = v * m.M12;
    r.M13 = v * m.M13;

    r.M20 = v * m.M20;
    r.M21 = v * m.M21;
    r.M22 = v * m.M22;
    r.M23 = v * m.M23;

    r.M30 = v * m.M30;
    r.M31 = v * m.M31;
    r.M32 = v * m.M32;
    r.M33 = v * m.M33;
    return r;
}

force_inline void
m4_mul_v4a(m4 m, v4 v, v4a r)
{
    r[0] = m.M00 * v.X + m.M10 * v.Y + m.M20 * v.Z + m.M30 * v.W;
    r[1] = m.M01 * v.X + m.M11 * v.Y + m.M21 * v.Z + m.M31 * v.W;
    r[2] = m.M02 * v.X + m.M12 * v.Y + m.M22 * v.Z + m.M32 * v.W;
    r[3] = m.M03 * v.X + m.M13 * v.Y + m.M23 * v.Z + m.M33 * v.W;
}
force_inline v4
m4_mul_v4(m4 m, v4 v)
{
    v4 r;
    r.X = m.M00 * v.X + m.M10 * v.Y + m.M20 * v.Z + m.M30 * v.W;
    r.Y = m.M01 * v.X + m.M11 * v.Y + m.M21 * v.Z + m.M31 * v.W;
    r.Z = m.M02 * v.X + m.M12 * v.Y + m.M22 * v.Z + m.M32 * v.W;
    r.W = m.M03 * v.X + m.M13 * v.Y + m.M23 * v.Z + m.M33 * v.W;
    return r;
}

force_inline void
m4_mul_v3a(m4 m, v3 v, real r[3])
{
    v4 xyzw = v4_new(v.X, v.Y, v.Z, 1.0f);
    v4 rv = m4_mul_v4(m, xyzw);

    r[0] = rv.X;
    r[1] = rv.Y;
    r[2] = rv.Z;
}
force_inline v3
m4_mul_v3(m4 m, v3 v)
{
    v3 r;
    v4 xyzw = v4_new(v.X, v.Y, v.Z, 1.0f);
    v4 rv = m4_mul_v4(m, xyzw);

    r.X = rv.X;
    r.Y = rv.Y;
    r.Z = rv.Z;
    return r;
}

// DOCS: Checked and corrected
force_inline m4
m4_mul(m4 a, m4 b)
{
    m4 r = {};

    r.M00 = a.M00 * b.M00 + a.M01 * b.M10 + a.M02 * b.M20 + a.M03 * b.M30;
    r.M01 = a.M00 * b.M01 + a.M01 * b.M11 + a.M02 * b.M21 + a.M03 * b.M31;
    r.M02 = a.M00 * b.M02 + a.M01 * b.M12 + a.M02 * b.M22 + a.M03 * b.M32;
    r.M03 = a.M00 * b.M03 + a.M01 * b.M13 + a.M02 * b.M23 + a.M03 * b.M33;

    r.M10 = a.M10 * b.M00 + a.M11 * b.M10 + a.M12 * b.M20 + a.M13 * b.M30;
    r.M11 = a.M10 * b.M01 + a.M11 * b.M11 + a.M12 * b.M21 + a.M13 * b.M31;
    r.M12 = a.M10 * b.M02 + a.M11 * b.M12 + a.M12 * b.M22 + a.M13 * b.M32;
    r.M13 = a.M10 * b.M03 + a.M11 * b.M13 + a.M12 * b.M23 + a.M13 * b.M33;

    r.M20 = a.M20 * b.M00 + a.M21 * b.M10 + a.M22 * b.M20 + a.M23 * b.M30;
    r.M21 = a.M20 * b.M01 + a.M21 * b.M11 + a.M22 * b.M21 + a.M23 * b.M31;
    r.M22 = a.M20 * b.M02 + a.M21 * b.M12 + a.M22 * b.M22 + a.M23 * b.M32;
    r.M23 = a.M20 * b.M03 + a.M21 * b.M13 + a.M22 * b.M23 + a.M23 * b.M33;

    r.M30 = a.M30 * b.M00 + a.M31 * b.M10 + a.M32 * b.M20 + a.M33 * b.M30;
    r.M31 = a.M30 * b.M01 + a.M31 * b.M11 + a.M32 * b.M21 + a.M33 * b.M31;
    r.M32 = a.M30 * b.M02 + a.M31 * b.M12 + a.M32 * b.M22 + a.M33 * b.M32;
    r.M33 = a.M30 * b.M03 + a.M31 * b.M13 + a.M32 * b.M23 + a.M33 * b.M33;

    return r;
}

force_inline m4
m4_mul_rot(m4 a, m4 b)
{
    m4 dest;
    real a00 = a.M00, a01 = a.M01, a02 = a.M02, a03 = a.M03,
         a10 = a.M10, a11 = a.M11, a12 = a.M12, a13 = a.M13,
         a20 = a.M20, a21 = a.M21, a22 = a.M22, a23 = a.M23,
         a30 = a.M30, a31 = a.M31, a32 = a.M32, a33 = a.M33,

         b00 = b.M00, b01 = b.M01, b02 = b.M02,
         b10 = b.M10, b11 = b.M11, b12 = b.M12,
         b20 = b.M20, b21 = b.M21, b22 = b.M22;

    dest.M00 = a00 * b00 + a10 * b01 + a20 * b02;
    dest.M01 = a01 * b00 + a11 * b01 + a21 * b02;
    dest.M02 = a02 * b00 + a12 * b01 + a22 * b02;
    dest.M03 = a03 * b00 + a13 * b01 + a23 * b02;

    dest.M10 = a00 * b10 + a10 * b11 + a20 * b12;
    dest.M11 = a01 * b10 + a11 * b11 + a21 * b12;
    dest.M12 = a02 * b10 + a12 * b11 + a22 * b12;
    dest.M13 = a03 * b10 + a13 * b11 + a23 * b12;

    dest.M20 = a00 * b20 + a10 * b21 + a20 * b22;
    dest.M21 = a01 * b20 + a11 * b21 + a21 * b22;
    dest.M22 = a02 * b20 + a12 * b21 + a22 * b22;
    dest.M23 = a03 * b20 + a13 * b21 + a23 * b22;

    dest.M30 = a30;
    dest.M31 = a31;
    dest.M32 = a32;
    dest.M33 = a33;

    return dest;
}

/* Object transformation operation */

force_inline m4
m4_translate(m4 m, v3 translation)
{
    v4 v1 = v4_scale(m.V[0], translation.X);
    v4 v2 = v4_scale(m.V[1], translation.Y);
    v4 v3 = v4_scale(m.V[2], translation.Z);

    m.V[3] = v4_add(v1, m.V[3]);
    m.V[3] = v4_add(v2, m.V[3]);
    m.V[3] = v4_add(v3, m.V[3]);
    return m;
}
force_inline m4
m4_translate_identity(v3 translation)
{
    m4 identity = m4_identity();
    identity.M30 = translation.X;
    identity.M31 = translation.Y;
    identity.M32 = translation.Z;
    identity.M33 = 1.0f;
    return identity;
}

force_inline m4
m4_scale_v3(m4 m, v3 v)
{
    m4 dest;
    dest.V[0] = v4_mulv(m.V[0], v.X);
    dest.V[1] = v4_mulv(m.V[1], v.Y);
    dest.V[2] = v4_mulv(m.V[2], v.Z);
    dest.V[3] = v4_copy(m.V[3]);
    return dest;
}

force_inline m4
m4_rotate_x(m4 m, real rad)
{
    real cosV = cos(rad);
    real sinV = sin(rad);
    m4 dest = m4_identity();
    dest.M11 = cosV;
    dest.M12 = sinV;
    dest.M21 = -sinV;
    dest.M22 = cosV;
    dest = m4_mul_rot(m, dest);
    return dest;
}

force_inline m4
m4_rotate_y(m4 m, real rad)
{
    real cosV = cos(rad);
    real sinV = sin(rad);
    m4 dest = m4_identity();
    dest.M00 = cosV;
    dest.M02 = -sinV;
    dest.M20 = sinV;
    dest.M22 = cosV;
    dest = m4_mul_rot(m, dest);
    return dest;
}

force_inline m4
m4_rotate_z(m4 m, real rad)
{
    real cosV = cos(rad);
    real sinV = sin(rad);
    m4 dest = m4_identity();
    dest.M00 = cosV;
    dest.M01 = sinV;
    dest.M10 = -sinV;
    dest.M11 = cosV;
    dest = m4_mul_rot(m, dest);
    return dest;
}

// NOTE(bies): m4_rotation_matrix -> m4_rotate
force_inline m4
m4_rotate(m4 m, v3 axis, real angle)
{
    m4 rotationMatrix = m4_rotation_matrix(axis, angle);
    m4 dest = m4_mul(m, rotationMatrix);
    return dest;
}

force_inline m4
m4_rotate_at(m4 m, v3 axis, v3 pivot, real angle)
{
    v3 pivotNegative = v3_negative_to(pivot);
    m4 dest = m4_translate(m, pivot);
    dest = m4_rotate(m, axis, angle);
    dest = m4_translate(m, pivotNegative);
    return dest;
}

force_inline m4
m4_transform(v3 position, v3 rotation, v3 scale)
{
    m4 translationMat = m4_translate_identity(position);
    m4 rotationMat = m4_rotate_z(translationMat, sc_math_radians_to_degrees(rotation.Z));
    m4 transform = m4_scale_v3(rotationMat, scale);

    return transform;
}

force_inline m4
m4_transform_wo_rotation(v3 position, v3 scale)
{
    m4 translationMat = m4_translate_identity(position);
    m4 transform = m4_scale_v3(translationMat, scale);

    return transform;
}

force_inline m4
m4_inverse(m4 m)
{
    m4 r;

    real det;
    real t[6];
    real m00 = m.M00, m01 = m.M01, m02 = m.M02, m03 = m.M03,
         m10 = m.M10, m11 = m.M11, m12 = m.M12, m13 = m.M13,
         m20 = m.M20, m21 = m.M21, m22 = m.M22, m23 = m.M23,
         m30 = m.M30, m31 = m.M31, m32 = m.M32, m33 = m.M33;

    t[0] = m22 * m33 - m32 * m23;
    t[1] = m21 * m33 - m31 * m23;
    t[2] = m21 * m32 - m31 * m22;
    t[3] = m20 * m33 - m30 * m23;
    t[4] = m20 * m32 - m30 * m22;
    t[5] = m20 * m31 - m30 * m21;

    r.M00 = m11 * t[0] - m12 * t[1] + m13 * t[2];
    r.M10 = -(m10 * t[0] - m12 * t[3] + m13 * t[4]);
    r.M20 = m10 * t[1] - m11 * t[3] + m13 * t[5];
    r.M30 = -(m10 * t[2] - m11 * t[4] + m12 * t[5]);

    r.M01 = -(m01 * t[0] - m02 * t[1] + m03 * t[2]);
    r.M11 = m00 * t[0] - m02 * t[3] + m03 * t[4];
    r.M21 = -(m00 * t[1] - m01 * t[3] + m03 * t[5]);
    r.M31 = m00 * t[2] - m01 * t[4] + m02 * t[5];

    t[0] = m12 * m33 - m32 * m13;
    t[1] = m11 * m33 - m31 * m13;
    t[2] = m11 * m32 - m31 * m12;
    t[3] = m10 * m33 - m30 * m13;
    t[4] = m10 * m32 - m30 * m12;
    t[5] = m10 * m31 - m30 * m11;

    r.M02 = m01 * t[0] - m02 * t[1] + m03 * t[2];
    r.M12 = -(m00 * t[0] - m02 * t[3] + m03 * t[4]);
    r.M22 = m00 * t[1] - m01 * t[3] + m03 * t[5];
    r.M32 = -(m00 * t[2] - m01 * t[4] + m02 * t[5]);

    t[0] = m12 * m23 - m22 * m13;
    t[1] = m11 * m23 - m21 * m13;
    t[2] = m11 * m22 - m21 * m12;
    t[3] = m10 * m23 - m20 * m13;
    t[4] = m10 * m22 - m20 * m12;
    t[5] = m10 * m21 - m20 * m11;

    r.M03 = -(m01 * t[0] - m02 * t[1] + m03 * t[2]);
    r.M13 = m00 * t[0] - m02 * t[3] + m03 * t[4];
    r.M23 = -(m00 * t[1] - m01 * t[3] + m03 * t[5]);
    r.M33 = m00 * t[2] - m01 * t[4] + m02 * t[5];

    det = 1.0f / (m00 * r.M00 + m01 * r.M10 + m02 * r.M20 + m03 * r.M30);

    // glm_mat4_scale_p(dest, det);
    r = m4_mul_real(r, det);

    return r;
}

force_inline real
m4_determinant(m4 m)
{
    real det = m.M00 * m.M11 * m.M22 + m.M01 * m.M12 * m.M20 + m.M02 * m.M10 * m.M21 - m.M02 * m.M11 * m.M20 - m.M01 * m.M10 * m.M22 - m.M00 * m.M12 * m.M21;

    return det;
}

force_inline m4
m4_t(m4 c)
{
    m4 r;

    r.M00 = c.M00;
    r.M10 = c.M01;
    r.M20 = c.M02;
    r.M30 = c.M03;

    r.M01 = c.M10;
    r.M11 = c.M11;
    r.M21 = c.M12;
    r.M31 = c.M13;

    r.M02 = c.M20;
    r.M12 = c.M21;
    r.M22 = c.M22;
    r.M32 = c.M23;

    r.M03 = c.M30;
    r.M13 = c.M31;
    r.M23 = c.M32;
    r.M33 = c.M33;

    return r;
}

// TODO: Check for vk-rh inverse y
force_inline m4
m4_orthographic(real l, real r, real b, real t, real n, real f)
{
#if 1
    m4 rm = {};

    rm.M00 = 2.f / (r - l);
    rm.M11 = 2.f / (b - t);
    rm.M22 = 1.f / (f - n);
    rm.M30 = -(r + l) / (r - l);
    rm.M31 = -(b + t) / (b - t);
    rm.M32 = -n / (f - n);
    rm.M33 = 1.f;
#else

    m4 rm = {};
    rm.M00 = 2.f / (r - l);
    rm.M11 = 2.f / (t - b);
    rm.M22 = 2.f / (n - f);
    rm.M30 = (l + r) / (l - r);
    rm.M31 = (b + t) / (b - t);
    rm.M32 = (n) / (n - f);
    rm.M33 = 1.f;

#endif

    return rm;
}

/* DOCS: По умолчанию Vulkan - Right Hand + inverse Y. */
force_inline m4
m4_perspective(real n, real f, real aspect, real fovRadians)
{
    m4 r = {};
    real focalLength = 1.0f / tanf(0.5f * fovRadians);

    r.M00 = focalLength / aspect; // Масштаб X
    r.M11 = -focalLength;         // Инверсия Y для Vulkan clip space
    r.M22 = f / (n - f);          // Right-hand Z: n→0, f→1
    r.M23 = -1.0f;                // w = -z_eye (LH actually)
    r.M32 = (n * f) / (n - f);    // Сдвиг Z

    return r;
}

force_inline m4
m4_perspective_lh_opengl(real n, real f, real aspect, real fovRadians)
{
    m4 r = {};
    real focalLength = 1.0f / tanf(0.5f * fovRadians);
    // Standard left-handed perspective projection (like OpenGL)
    r.M00 = focalLength / aspect;
    r.M11 = focalLength; // Положительное значение (Y вверх)
    r.M23 = -1.0f;       // Отрицательное! w = z_eye (для левой системы)
    // Преобразование Z в диапазон [-1, 1] для OpenGL
    // Используем: z_clip = A*z_eye + B*w, где w = z_eye
    // При z_eye = n: z_ndc = -1
    // При z_eye = f: z_ndc = 1
    // Решение: A = (f + n)/(n - f), B = (2fn)/(n - f)
    r.M22 = (f + n) / (n - f); // Для диапазона [-1, 1]
    r.M32 = (2.0f * n * f) / (n - f);
    return r;
}

force_inline m4
m4_look_at(v3 eye, v3 center, v3 up)
{
    m4 dest = {};

    // eye.Y = -eye.Y;
    // center.Y = -center.Y;

    // Right-hand: направление камеры = eye → center
    v3 direction = v3_normalize(v3_sub(center, eye));
    // Right-hand: right = up × direction (порядок важен!)
    v3 right = v3_cross_normalized(up, direction);
    // Up = direction × right (восстанавливаем перпендикулярный up)
    v3 newUp = v3_cross(direction, right);

    // Row-Major матрица: каждая строка = dot product с basis vector

    /*
    [ right.x          newUp.x          -direction.x          0 ]
    [ right.y          newUp.y          -direction.y          0 ]
    [ right.z          newUp.z          -direction.z          0 ]
    [ dot(right,-eye)  dot(newUp,-eye)  dot(-direction,-eye)  1 ]
    */

    dest.M00 = right.X;
    dest.M01 = newUp.X;
    dest.M02 = direction.X;
    dest.M03 = 0;

    dest.M10 = right.Y;
    dest.M11 = newUp.Y;
    dest.M12 = direction.Y;
    dest.M13 = 0;

    dest.M20 = right.Z;
    dest.M21 = newUp.Z;
    dest.M22 = direction.Z;
    dest.M23 = 0;

    dest.M30 = -v3_dot(right, eye);
    dest.M31 = -v3_dot(newUp, eye);
    dest.M32 = +v3_dot(direction, eye);
    dest.M33 = 1;

    return dest;
}

/*

  ###################################
  ###################################
  Quaternion.h
  ###################################
  ###################################

*/

force_inline quat
quat_new(real angle, v3 axis)
{
    v3 normalizedAxis = v3_normalize(axis);
    real halfAngle = 0.5f * angle;
    real cosAngle = cosf(halfAngle);
    real sinAngle = sinf(halfAngle);

    quat q = {
        .X = sinAngle * normalizedAxis.X,
        .Y = sinAngle * normalizedAxis.Y,
        .Z = sinAngle * normalizedAxis.Z,
        .W = cosAngle
    };

    return q;
}

force_inline quat
quat_v3(v3 v)
{
    quat q;
    q.X = (v.X);
    q.Y = (v.Y);
    q.Z = (v.Z);
    q.W = 1.0f;
    return q;
}

force_inline quat
quat_xyz(real x, real y, real z)
{
    quat q;
    q.X = x;
    q.Y = y;
    q.Z = z;
    q.W = 1.0f;
    return q;
}
force_inline quat
quat_xyzw(real x, real y, real z, real w)
{
    quat q;
    q.X = x;
    q.Y = y;
    q.Z = z;
    q.W = w;
    return q;
}
force_inline quat
quat_array(real* arr)
{
    quat q;
    q.X = arr[0];
    q.Y = arr[1];
    q.Z = arr[2];
    q.W = arr[3];
    return q;
}
force_inline quat
quat_array_negative(real* arr)
{
    quat q;
    q.X = -arr[0];
    q.Y = -arr[1];
    q.Z = -arr[2];
    q.W = arr[3];
    return q;
}

force_inline quat
quat_pitch_yaw_roll(real pitch, real yaw, real roll)
{
    real yaw05 = yaw * 0.5f;
    real pitch05 = pitch * 0.5f;
    real roll05 = roll * 0.5f;

    real cy = cosf(yaw05);
    real sy = sinf(yaw05);
    real cp = cosf(pitch05);
    real sp = sinf(pitch05);
    real cr = cosf(roll05);
    real sr = sinf(roll05);

    quat q = {
        .X = sr * cp * cy - cr * sp * sy,
        .Y = cr * sp * cy + sr * cp * sy,
        .Z = cr * cp * sy - sr * sp * cy,
        .W = cr * cp * cy + sr * sp * sy
    };

    return q;
}

force_inline v3
quat_to_euler_angles(quat q)
{
    real x = q.X;
    real y = q.Y;
    real z = q.Z;
    real w = q.W;

    // pitch
    real sinp = 2 * (w * y - z * x);
    // yaw
    real siny_cosp = 2 * (w * z + x * y);
    real cosy_cosp = 1 - 2 * (y * y + z * z);
    // roll
    real sinr_cosp = 2 * (x + y * z * w);
    real cosr_cosp = 1 - 2 * (x * x + y * y);

    v3 r = {
        /* use 90 degrees if out of range */
        .Pitch =
#if 0
	asinf(sinp),
#else
            ((fabs(sinp) >= 1.0f) ? (real)ScMathPiDiv2 : (real)asinf(sinp)),
#endif
        .Yaw = atan2f(siny_cosp, cosy_cosp),
        .Roll = atan2f(sinr_cosp, cosr_cosp)
    };

    return r;
}

force_inline quat
quat_euler(v3 v)
{
    quat result = quat_pitch_yaw_roll(v.Pitch, v.Yaw, v.Roll);
    return result;
}

force_inline quat
quat_identity()
{
    return (quat) { .X = 0, .Y = 0, .Z = 0, .W = 1 };
}

force_inline real
quat_dot(quat a, quat b)
{
    return a.X * b.X + a.Y * b.Y + a.Z * b.Z + a.W * b.W;
}

force_inline real
quat_length(quat src)
{
    real length = real_sqrt(quat_dot(src, src));
    return length;
}

force_inline real
quat_magnitude(quat src)
{
    real length = real_sqrt(quat_dot(src, src));
    return length;
}

force_inline quat
quat_normalize(quat src)
{
    real dot = quat_dot(src, src);
    if (dot <= 0.0f)
    {
        return quat_identity();
    }

    real scaleValue = 1.0f / real_sqrt(dot);
    src.X *= scaleValue;
    src.Y *= scaleValue;
    src.Z *= scaleValue;
    src.W *= scaleValue;

    return src;
}

/*

  res.x = a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y
  res.y = a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x
  res.z = a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w
  res.w = a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
*/

force_inline quat
quat_mul(quat a, quat b)
{
    quat dest;
    dest.X = (a.W * b.X) + (a.X * b.W) + (a.Y * b.Z) - (a.Z * b.Y);
    dest.Y = (a.W * b.Y) - (a.X * b.Z) + (a.Y * b.W) + (a.Z * b.X);
    dest.Z = (a.W * b.Z) + (a.X * b.Y) - (a.Y * b.X) + (a.Z * b.W);
    dest.W = (a.W * b.W) - (a.X * b.X) - (a.Y * b.Y) - (a.Z * b.Z);
    return dest;
}

force_inline quat
quat_add(quat a, quat b)
{
    a.X += b.X;
    a.Y += b.Y;
    a.Z += b.Z;
    a.W += b.W;
    return a;
}
force_inline quat
quat_sub(quat a, quat b)
{
    a.X -= b.X;
    a.Y -= b.Y;
    a.Z -= b.Z;
    a.W -= b.W;
    return a;
}
force_inline quat
quat_scale(quat a, real value)
{
    a.X *= value;
    a.Y *= value;
    a.Z *= value;
    a.W *= value;
    return a;
}

force_inline quat
quat_negate(quat a)
{
    a.X = -a.X;
    a.Y = -a.Y;
    a.Z = -a.Z;
    a.W = -a.W;
    return a;
}

force_inline quat
quat_cross(quat q1, quat q2)
{
    quat r = {
        .X = q1.W * q2.X + q1.X * q2.W + q1.Y * q2.Z - q1.Z * q2.Y,
        .Y = q1.W * q2.Y + q1.Y * q2.W + q1.Z * q2.X - q1.X * q2.Z,
        .Z = q1.W * q2.Z + q1.Z * q2.W + q1.X * q2.Y - q1.Y * q2.X,
        .W = q1.W * q2.W - q1.X * q2.X - q1.Y * q2.Y - q1.Z * q2.Z
    };

    return r;
}

force_inline m4
quat_to_m4(quat quat)
{
    real length = quat_length(quat);
    real s = (length > 0.0f) ? (2.0f / length) : 0.0f;

    real x = quat.X;
    real y = quat.Y;
    real z = quat.Z;
    real w = quat.W;

    real xx = s * x * x;
    real xy = s * x * y;
    real wx = s * w * x;
    real yy = s * y * y;
    real yz = s * y * z;
    real wy = s * w * y;
    real zz = s * z * z;
    real xz = s * x * z;
    real wz = s * w * z;

    m4 dest = {
        .M00 = 1.0f - yy - zz, .M01 = xy + wz, .M02 = xz - wy, .M03 = 0.0f, .M10 = xy - wz, .M11 = 1.0f - xx - zz, .M12 = yz + wx, .M13 = 0.0f, .M20 = xz + wy, .M21 = yz - wx, .M22 = 1.0f - xx - yy, .M23 = 0.0f, .M30 = 0.0f, .M31 = 0.0f, .M32 = 0.0f, .M33 = 1.0f
    };

    return dest;
}

force_inline quat
quat_lerp(quat from, quat to, real t)
{
    // NOTE(bies): not implimented now
    real val = ScMinMax(t, 0.0, 1.0f);
    quat diff = quat_sub(to, from);
    diff = quat_scale(diff, val);
    quat offsetFrom = quat_add(from, diff);

    return offsetFrom;
}

force_inline quat
quat_slerp(quat from, quat to, real t)
{
    real cosTheta = quat_dot(from, to);
    if (real_abs(cosTheta) >= 1.0f)
    {
        return from;
    }

    quat q1 = from;

    if (cosTheta < 0.0f)
    {
        q1 = quat_negate(q1);
        cosTheta = -cosTheta;
    }

    real sinTheta = real_sqrt(1.0f - cosTheta * cosTheta);
    // NOTE(bies): doing quat_lerp to avoid zero division
    if (real_abs(sinTheta) < 0.001f)
    {
        return quat_lerp(from, to, t);
    }

    /* SLERP */
    real angle = acosf(cosTheta);
    q1 = quat_scale(q1, sinf((1.0f - t) * angle));
    quat q2 = quat_scale(to, sinf(t * angle));

    q1 = quat_add(q1, q2);
    quat dest = quat_scale(q1, 1.0f / sinTheta);
    return dest;
}

force_inline real
quat_float(quat q)
{
    return q.W;
}

force_inline quat
quat_conjugate(quat q)
{
    q.X = -q.X;
    q.Y = -q.Y;
    q.Z = -q.Z;
    return q;
}

force_inline quat
quat_invert(quat q)
{
    return quat_conjugate(q);
}

force_inline quat
quat_inverse(quat q)
{
    quat conjugated = quat_conjugate(q);
    real length = quat_length(q);
    return quat_scale(conjugated, length);
}

force_inline v3
quat_imaginary(quat q)
{
    v3 v;
    v.X = q.X;
    v.Y = q.Y;
    v.Z = q.Z;
    return v;
}

force_inline real
quat_imaginary_length(quat q)
{
    return q.X * q.X + q.Y * q.Y + q.Z * q.Z;
    ;
}

force_inline real
quat_angle(quat q)
{
    return 2.0f * atan2f(quat_imaginary_length(q), q.W);
}

// DOCS: q - должен быть нормализован
force_inline v3
v3_rotate_quat(v3 v, quat q)
{
#if defined(SC_BUILD_DEBUG)
    for (i32 i = 0; i < 4; ++i)
        if (q.V[i] > 1.0)
            printf(ScTerminalYellow("v3_rotate_quat:WARN") ": quat is not normalized!\n");
    ;
#endif // SC_BUILD_DEBUG

    // Оптимизированная формула:
    // v' = v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v)
    v3 qv = v3_new(q.X, q.Y, q.Z);
    v3 t = v3_cross(qv, v);
    t = v3_add(t, v3_mulv(v, q.W));
    t = v3_cross(qv, t);
    t = v3_mulv(t, 2.0f);

    return v3_add(v, t);
}

force_inline v3
quat_rotate_v3(quat q, v3 v)
{
    return v3_rotate_quat(v, q);
}

force_inline m4
quat_to_view(quat q, v3 cameraPosition)
{
    // DOCS: Нормализуем кватернион
    q = quat_normalize(q);

    // DOCS: Вычисляем базисные векторы камеры из кватерниона
    v3 forward = v3_rotate_quat((v3) { 0, 0, -1 }, q); // RH: смотрим на -Z
    v3 right = v3_rotate_quat((v3) { 1, 0, 0 }, q);
    v3 up = v3_rotate_quat((v3) { 0, 1, 0 }, q);

    // DOCS: Строим view matrix (обратную матрице преобразования камеры)
    m4 view = { 0 };

    // DOCS: Поворотная часть (transpose базисных векторов)
    view.M00 = right.X;
    view.M01 = up.X;
    view.M02 = forward.X;
    view.M10 = right.Y;
    view.M11 = up.Y;
    view.M12 = forward.Y;
    view.M20 = right.Z;
    view.M21 = up.Z;
    view.M22 = forward.Z;

    // Переносная часть
    view.M30 = -v3_dot(right, cameraPosition);
    view.M31 = -v3_dot(up, cameraPosition);
    view.M32 = -v3_dot(forward, cameraPosition);
    view.M33 = 1.0f;

    return view;
}

force_inline m4
quat_rotate_m4(quat q, m4 m)
{
    m4 rot = quat_to_m4(q);
    return m4_mul_rot(m, rot);
}

force_inline m4
quat_rotate_m4_identity(quat q)
{
    m4 rot = quat_to_m4(q);
    return m4_mul_rot(m4_identity(), rot);
}

force_inline m4
quat_look(quat q, v3 eye)
{
    m4 orientation = quat_to_m4(q); // it's view matrx
    orientation.V[3] = v4_v3v(m4_mul_v3(orientation, eye), 1.0f);
    orientation.V[3] = v4_negative(orientation.V[3]);

    return orientation;
}

force_inline m4
quat_look_at(quat q, v3 pos)
{
    /* orientation */
    m4 dest = quat_to_m4(q);

    /* translate */
    dest.V[3] = v4_v3v(m4_mul_v3(dest, pos), 1.0f);
    dest.V[3] = v4_negative(dest.V[3]);
    return dest;
#if 0
    m4 view;

    v3 v1 = (rot * v3_new(0.0f, 0.0f, 1.0f)).normalize(); // forward
    v3 v2 = (rot * v3_new(0.0f, 1.0f, 0.0f)).normalize().cross(v1); // up
    v3 v3 = v1.cross(v2);

    view.M[0][0] = v2.x;
    view.M[0][1] = v3.x;
    view.M[0][2] = v1.x;

    view.M[1][0] = v2.y;
    view.M[1][1] = v3.y;
    view.M[1][2] = v1.y;

    view.M[2][0] = v2.z;
    view.M[2][1] = v3.z;
    view.M[2][2] = v1.z;

    view.M[3][0] = -v2.dot(Pos);
    view.M[3][1] = -v3.dot(Pos);
    view.M[3][2] = -v1.dot(Pos);
    //Comment this out if you aren't using the left hand coordinate system
    view = view.transpose();
#endif
}

force_inline m4
quat_transform_short(v4 position, quat rotation)
{
    m4 r;

    real x2 = (rotation.X + rotation.X) * position.W;
    real y2 = (rotation.Y + rotation.Y) * position.W;
    real z2 = (rotation.Z + rotation.Z) * position.W;

    real xx2 = rotation.X * x2;
    real yy2 = rotation.Y * y2;
    real zz2 = rotation.Z * z2;
    real zx2 = rotation.Z * x2;
    real xy2 = rotation.X * y2;

    real yz2 = rotation.Y * z2;

    real wx2 = rotation.W * x2;
    real wy2 = rotation.W * y2;
    real wz2 = rotation.W * z2;

    r.M00 = position.W - yy2 - zz2;
    r.M01 = xy2 - wz2;
    r.M02 = zx2 + wy2;
    r.M03 = position.X;

    r.M10 = xy2 + wz2;
    r.M11 = position.W - xx2 - zz2;
    r.M12 = yz2 - wx2;
    r.M13 = position.Y;

    r.M20 = zx2 - wy2;
    r.M21 = yz2 + wx2;
    r.M22 = position.W - xx2 - yy2;
    r.M23 = position.Z;

    r.M30 = r.M31 = r.M32 = 0;
    r.M33 = 1;

    return r;
}

force_inline m4
quat_transform(v3 position, quat rotation, v3 scale)
{
    m4 translationMat = m4_translate_identity(position);
    m4 rotationMat = quat_rotate_m4(rotation, translationMat);
    m4 transform = m4_scale_v3(rotationMat, scale);

    return transform;
}

force_inline m4
quat_transform_wo_scale(v4 position, quat rotation)
{
    m4 r;

    real x2 = (rotation.X + rotation.X) * position.W;
    real y2 = (rotation.Y + rotation.Y) * position.W;
    real z2 = (rotation.Z + rotation.Z) * position.W;

    real xx2 = rotation.X * x2;
    real yy2 = rotation.Y * y2;
    real zz2 = rotation.Z * z2;

    real zx2 = rotation.Z * x2;
    real xy2 = rotation.X * y2;

    real yz2 = rotation.Y * z2;

    real wx2 = rotation.W * x2;
    real wy2 = rotation.W * y2;
    real wz2 = rotation.W * z2;

    r.M00 = position.W - yy2 - zz2;
    r.M01 = xy2 - wz2;
    r.M02 = zx2 + wy2;
    r.M03 = position.X;

    r.M10 = xy2 + wz2;
    r.M11 = position.W - xx2 - zz2;
    r.M12 = yz2 - wx2;
    r.M13 = position.Y;

    r.M20 = zx2 - wy2;
    r.M21 = yz2 + wx2;
    r.M22 = position.W - xx2 - yy2;
    r.M23 = position.Z;

    r.M30 = r.M31 = r.M32 = 0;
    r.M33 = 1;

    return r;
}

force_inline quat
quat_new_pitch_yaw(quat pitch, quat yaw)
{
    return quat_mul(yaw, pitch); // сначала рыскание, потом тангаж
}

force_inline quat
quat_new_pitch_yaw_roll(quat pitch, quat yaw, quat roll)
{
    quat rot0 = quat_mul(yaw, pitch);  // сначала рыскание, потом тангаж
    quat final = quat_mul(rot0, roll); // потом крен
    return final;
}

/*

  ###################################
  ###################################
  Helpfull Utils.h
  ###################################
  ###################################

*/
/*

  ###################################
  ###################################
  Euler Angles.h
  ###################################
  ###################################

*/

force_inline v3
v3_decompose_rotation_xyz(m3 rot)
{
    v3 r = v3_new(0, 0, 0);
    if (rot.M02 < 1.0f)
    {
        if (rot.M02 > -1.0f)
        {
            r.X = atan2(-rot.M12, rot.M22);
            r.Y = asin(rot.M02);
            r.Z = atan2(-rot.M01, rot.M00);
        }
        else
        {
            r.X = -atan2(rot.M10, rot.M11);
            r.Y = -ScMathPiDiv2;
        }
    }
    else
    {
        r.X = atan2(rot.M10, rot.M11);
        r.Y = ScMathPiDiv2;
    }

    return v3_to_degree(r);
}

force_inline m4
view_get(v3 position, real rotationX, real rotationY)
{
    m4 view = m4_translate_identity(v3_invert(position));
    quat xQuat = quat_new(rotationX, v3_new(0, 1, 0));
    quat yQuat = quat_new(rotationY, v3_new(1, 0, 0));

    m4 identity = m4_identity();
    m4 rotatedX = quat_rotate_m4(xQuat, identity);
    m4 rotatedY = quat_rotate_m4(yQuat, identity);

    view = m4_mul(rotatedX, view);
    view = m4_mul(rotatedY, view);

    return view;
}
// arcball
force_inline m4
view_get2(v3 position, quat orientation)
{
    m4 view = m4_translate_identity(v3_invert(position));
    view = quat_rotate_m4(orientation, view);
    return view;
}

/*
  dest: [left, right, bottom, top, near, far]
*/
force_inline void
view_projection_get_frustrum(m4 viewProjection, v4 dest[6])
{
    m4 t = m4_t(viewProjection);

    v4 left = v4_normalize(v4_add(t.V[3], t.V[0]));
    v4 right = v4_normalize(v4_sub(t.V[3], t.V[0]));
    v4 bot = v4_normalize(v4_add(t.V[3], t.V[1]));
    v4 top = v4_normalize(v4_sub(t.V[3], t.V[1]));
    v4 near = v4_normalize(v4_add(t.V[3], t.V[2]));
    v4 far = v4_normalize(v4_sub(t.V[3], t.V[2]));

    dest[0] = left;
    dest[1] = right;
    dest[2] = bot;
    dest[3] = top;
    dest[4] = near;
    dest[5] = far;
}

force_inline i32
m4_transform_decompose(m4 transform, v3* translation, v3* rotation, v3* scale)
{
    real zero = 0.0f;
    m4 localMatrix = transform;

    // Normalize the matrix.
    if (real_equal(localMatrix.M33, zero))
    {
        return 0;
    }

    // First, isolate perspective. This is the messiest.
    i32 shouldIsolatePerspective = (!real_equal(localMatrix.M03, zero) || !real_equal(localMatrix.M13, zero) || !real_equal(localMatrix.M23, zero));
    if (shouldIsolatePerspective)
    {
        // Clear the perspective partition
        localMatrix.M03 = 0.0f;
        localMatrix.M13 = 0.0f;
        localMatrix.M23 = 0.0f;
        localMatrix.M33 = 1.0f;
    }

    // Next take care of translation (easy).
    *translation = v3_v4(localMatrix.V[3]);

    localMatrix.V[3] = v4_new(0, 0, 0, localMatrix.V[3].W);

    v3 row[3];
    // Now get scale and shear.
    for (i32 i = 0; i < 3; ++i)
        for (i32 j = 0; j < 3; ++j)
            row[i].V[j] = localMatrix.M[i][j];

    // TODO(bies): fix it
    // Compute X scale factor and normalize first row.
    scale->X = v3_length(row[0]);
    row[0] = v3_scale(row[0], 1.0f / scale->X);
    scale->Y = v3_length(row[1]);
    row[1] = v3_scale(row[1], 1.0f / scale->Y);
    scale->Z = v3_length(row[2]);
    row[2] = v3_scale(row[2], 1.0f / scale->Z);

    rotation->Y = asin(-row[0].Z);
    if (cos(rotation->Y) != 0)
    {
        rotation->X = atan2(row[1].Z, row[2].Z);
        rotation->Z = atan2(row[0].Y, row[0].X);
    }
    else
    {
        rotation->X = atan2(-row[2].X, row[1].Y);
        rotation->Z = 0;
    }

    //*rotation = v3_scale(*rotation, RAD_TO_DEG_CONST);

    return 1;
}

force_inline i32
m4_transform_decompose_2(m4 transform, v3* translation, v3* rotation, v3* scale)
{
    scale->X = v4_length(transform.V[0]);
    scale->Y = v4_length(transform.V[1]);
    scale->Z = v4_length(transform.V[2]);

    transform.V[0] = v4_normalize(transform.V[0]);
    transform.V[1] = v4_normalize(transform.V[1]);
    transform.V[2] = v4_normalize(transform.V[2]);

    real xRadians = atan2f(transform.M[1][2], transform.M[2][2]);
    real yRadians = atan2f(-transform.M[0][2], real_sqrt(transform.M[1][2] * transform.M[1][2] + transform.M[2][2] * transform.M[2][2]));
    real zRadians = atan2f(transform.M[0][1], transform.M[0][0]);

    rotation->X = sc_math_radians_to_degrees(xRadians);
    rotation->Y = sc_math_radians_to_degrees(yRadians);
    rotation->Z = sc_math_radians_to_degrees(zRadians);

    translation->X = transform.V[3].X;
    translation->Y = transform.V[3].Y;
    translation->Z = transform.V[3].Z;

    return 1;
}

force_inline i32
m4_transform_decompose_3(m4 transform, v3* translation, v3* rotation, v3* scale)
{
    v4 t = { 0.0f, 0.0f, 0.0f, 1.0f };

    *translation = v3_v4(transform.V[3]);

    m4 r = transform;

    v3 s;
    s.X = v3_length(v3_v4(transform.V[0])); // this is write
    s.Y = v3_length(v3_v4(transform.V[1]));
    s.Z = v3_length(v3_v4(transform.V[2]));

    r.V[0] = v4_scale(r.V[0], 1.0f / s.X);
    r.V[1] = v4_scale(r.V[1], 1.0f / s.Y);
    r.V[2] = v4_scale(r.V[2], 1.0f / s.Z);

    /* Note from Apple Open Source (asume that the matrix is orthonormal):
       check for a coordinate system flip.  If the determinant
       is -1, then negate the matrix and the scaling factors. */
    v3 v = v3_cross(v3_v4(transform.V[0]), v3_v4(transform.V[1]));

    if (v3_dot(v, v3_v4(transform.V[2])) < 0.0f)
    {
        r.V[0] = v4_negate(r.V[0]);
        r.V[1] = v4_negate(r.V[1]);
        r.V[2] = v4_negate(r.V[2]);
        s = v3_negate(s);
    }

    v3 rotated = v3_decompose_rotation_xyz(m3_m4(r));
    *rotation = v3_to_degree(rotated);

    return 1;
}

#endif // SC_MATH_H
