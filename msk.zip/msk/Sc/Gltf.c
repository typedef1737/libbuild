#include "Gltf.h"
#include "Json.h"
#include "Sc.h"
#include <stdio.h>
#include <string.h>

ScGltfAttribute
sc_gltf_attribute(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    ScGltfAttribute attr = {};
    i32 ind = *pInd;

    i32 keysCount = sc_json_object_token_keys_count(aTokens, ind, tokensCount);
    ++ind; // skip to key

    while (keysCount)
    {
        ScJsonToken token = aTokens[ind];
        char* pKey = sc_json_text(pJson, token.StartInd);

        if (sc_string_compare_ext(pKey, "POSITION", 8))
        {
            ++ind;
            attr.Position = sc_json_token_int(aTokens, &ind, pJson);
        }
        else if (sc_string_compare_ext(pKey, "NORMAL", 6))
        {
            ++ind;
            attr.Normal = sc_json_token_int(aTokens, &ind, pJson);
        }
        else if (sc_string_compare_ext(pKey, "TEXCOORD_0", 10))
        {
            ++ind;
            attr.Uv0 = sc_json_token_int(aTokens, &ind, pJson);
        }

        --keysCount;
    }

    *pInd = ind;

    return attr;
}

ScGltfPrimitive*
sc_gltf_primitive(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    ScGltfPrimitive* aPrimitives = NULL;
    i32 objInd = *pInd;
    i32 primitivesCount = sc_json_array_token_length(aTokens, tokensCount, objInd);

    ++objInd; // skip array to object

    i32 iterInd = primitivesCount;
    while (iterInd)
    {
        ScGltfPrimitive gltfPrimitive = {};

        ScJsonToken primitiveObj = aTokens[objInd];
        i32 keysCount = sc_json_object_token_keys_count(aTokens, objInd, tokensCount);
        // printf("KETYS COUNT: %d\n", keysCount);
        ++objInd; // skip object to first key

        i32 keyInd = keysCount;
        while (keyInd)
        {
            ScJsonToken keyToken = aTokens[objInd];
            char* pKey = sc_json_text(pJson, keyToken.StartInd);
            // printf("[KEY]: %.*s\n", sc_json_token_length(keyToken), pKey);
            if (sc_string_compare_ext(pKey, "attributes", 10))
            {
                ++objInd;
                gltfPrimitive.Attributes = sc_gltf_attribute(aTokens, tokensCount, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "indices", 7))
            {
                ++objInd;
                gltfPrimitive.Indices = sc_json_token_int(aTokens, &objInd, pJson);
            }

            --keyInd;
        }

        sc_list_add(aPrimitives, gltfPrimitive);
        --iterInd;
    }

    *pInd = objInd;

    return aPrimitives;
}

i32
sc_gltf_type(ScJsonToken* aTokens, i32* pInd, char* pJson)
{
    i32 ind = *pInd;
    ScJsonToken token = aTokens[ind];
    i64 strLength = sc_json_token_length(token);
    char* pText = sc_json_text(pJson, token.StartInd);
    *pInd = ind + 1;

    if (strLength == 6) // "SCALAR"
        return 1;

    i64 typeHash = sc_string_hash(pText, strLength);

    static i64 aHashes[6] = {};
    static i64 aSizes[6] = {};

    if (sc_helper_tofr())
    {
        aHashes[0] = sc_string_hash("VEC2", 4);
        aHashes[1] = sc_string_hash("VEC3", 4);
        aHashes[2] = sc_string_hash("VEC4", 4);
        aHashes[3] = sc_string_hash("MAT2", 4);
        aHashes[4] = sc_string_hash("MAT3", 4);
        aHashes[5] = sc_string_hash("MAT4", 4);

        aSizes[0] = 2;
        aSizes[1] = 3;
        aSizes[2] = 4;
        aSizes[3] = 4;
        aSizes[4] = 9;
        aSizes[5] = 16;
    }

    for (i32 h = 0; h < ScArrayCount(aHashes); ++h)
        if (aHashes[h] == typeHash)
            return aSizes[h];

    sc_assert_break();
    return 0;
}

ScGltfAccessor*
sc_gltf_accessor(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    ScGltfAccessor* aAccessors = NULL;
    i32 objInd = *pInd;
    i32 accessorsCount = sc_json_array_token_length(aTokens, tokensCount, objInd);

    ++objInd; // skip array to object

    i32 iterInd = accessorsCount;
    while (iterInd)
    {
        ScGltfAccessor gltfAccessor = {};

        ScJsonToken accessorObj = aTokens[objInd];
        i32 keysCount = sc_json_object_token_keys_count(aTokens, objInd, tokensCount);
        // printf("KETYS COUNT: %d\n", keysCount);
        ++objInd; // skip object to first key
        i32 keyInd = keysCount;
        while (keyInd)
        {
            ScJsonToken keyToken = aTokens[objInd];
            char* pKey = sc_json_text(pJson, keyToken.StartInd);
            // printf("[KEY]: %.*s\n", sc_json_token_length(keyToken), pKey);

            if (sc_string_compare_ext(pKey, "bufferView", 10))
            {
                ++objInd;
                gltfAccessor.BufferView = sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "componentType", 13))
            {
                ++objInd;
                gltfAccessor.ComponentType = (ScGltfComponentType)sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "count", 5))
            {
                ++objInd;
                gltfAccessor.Count = sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "max", 3))
            {
                ++objInd;
                gltfAccessor.Max = sc_json_token_v3o(aTokens, tokensCount, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "min", 3))
            {
                // BUG: z should be -1 not 1
                ++objInd;
                gltfAccessor.Min = sc_json_token_v3o(aTokens, tokensCount, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "type", 4))
            {
                ++objInd;
                gltfAccessor.ComponentsCount = sc_gltf_type(aTokens, &objInd, pJson);
            }

            --keyInd;
        }

        sc_list_add(aAccessors, gltfAccessor);

        --iterInd;
    }

    *pInd = objInd;

    return aAccessors;
}

ScGltfBufferView*
sc_gltf_buffer_views(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    ScGltfBufferView* aBufferViews = NULL;
    i32 objInd = *pInd;
    i32 accessorsCount = sc_json_array_token_length(aTokens, tokensCount, objInd);
    ++objInd; // skip array to object
    i32 iterInd = accessorsCount;

    while (iterInd)
    {
        ScGltfBufferView gltfBufferView = {};

        ScJsonToken accessorObj = aTokens[objInd];
        i32 keysCount = sc_json_object_token_keys_count(aTokens, objInd, tokensCount);
        ++objInd; // skip object to first key
        i32 keyInd = keysCount;
        while (keyInd)
        {
            ScJsonToken keyToken = aTokens[objInd];
            char* pKey = sc_json_text(pJson, keyToken.StartInd);

            if (sc_string_compare_ext(pKey, "buffer", 6))
            {
                ++objInd;
                gltfBufferView.Buffer = sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "byteLength", 10))
            {
                ++objInd;
                gltfBufferView.ByteLength = sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "byteOffset", 10))
            {
                ++objInd;
                gltfBufferView.ByteOffset = sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "target", 6))
            {
                ++objInd;
                gltfBufferView.Target = sc_json_token_int(aTokens, &objInd, pJson);
            }

            --keyInd;
        }

        sc_list_add(aBufferViews, gltfBufferView);

        --iterInd;
    }

    *pInd = objInd;
    return aBufferViews;
}

ScGltfBuffer*
sc_gltf_buffers(ScJsonToken* aTokens, i32 tokensCount, i32* pInd, char* pJson)
{
    ScGltfBuffer* aBuffers = NULL;
    i32 objInd = *pInd;
    i32 accessorsCount = sc_json_array_token_length(aTokens, tokensCount, objInd);
    ++objInd; // skip array to object
    i32 iterInd = accessorsCount;

    while (iterInd)
    {
        ScGltfBuffer gltfBuffer = {};

        ScJsonToken accessorObj = aTokens[objInd];
        i32 keysCount = sc_json_object_token_keys_count(aTokens, objInd, tokensCount);
        ++objInd; // skip object to first key
        i32 keyInd = keysCount;
        while (keyInd)
        {
            ScJsonToken keyToken = aTokens[objInd];
            char* pKey = sc_json_text(pJson, keyToken.StartInd);

            if (sc_string_compare_ext(pKey, "byteLength", 10))
            {
                ++objInd;
                gltfBuffer.ByteLength = sc_json_token_int(aTokens, &objInd, pJson);
            }
            else if (sc_string_compare_ext(pKey, "uri", 3))
            {
                ++objInd;
                gltfBuffer.pUri = sc_json_token_string(aTokens, &objInd, pJson);
            }

            --keyInd;
        }

        sc_list_add(aBuffers, gltfBuffer);

        --iterInd;
    }

    *pInd = objInd;
    return aBuffers;
}

ScGltf
sc_gltf_load(const char* pGltfPath)
{
    ScGltf gltf = {
        .pPath = sc_string_new((char*)pGltfPath)
    };

    i64 len = 0;
    char* pContent = sc_file_read_ext(gltf.pPath, &len);

    ScJsonToken* aTokens = (ScJsonToken*)sc_memory_allocate(len * sizeof(ScJsonToken));

    ScJsonConfig cfg = {
        .pText = pContent,
        .TextLength = len,
        .TokensCount = len,
        .aTokens = aTokens,
    };

    sc_json_parse(&cfg);

    // for (i32 k = 0; k < cfg.TokensCount; ++k)
    // {
    //     ScJsonToken tok = cfg.aTokens[k];
    //     if (tok.Type == ScJsonTokenType_Float || tok.Type == ScJsonTokenType_Float_Exp || tok.Type == ScJsonTokenType_Int || tok.Type == ScJsonTokenType_Int_Exp)
    //     {
    //         printf("%.*s\n", sc_json_token_length(tok), sc_json_text(pContent, tok.StartInd));
    //     }
    // }

    i32 keysCount = sc_json_object_token_keys_count(cfg.aTokens, 0, cfg.TokensCount);

    for (i32 t = 0; t < cfg.TokensCount; ++t)
    {
        ScJsonToken token = cfg.aTokens[t];

        if (token.Parent != 0 || token.Type != ScJsonTokenType_Key)
            continue;

        char* pJson = sc_json_text(pContent, token.StartInd);
        // printf("t[%d] %s %.*s\n", t, sc_json_token_type_to_string(token.Type), sc_json_token_length(token), pJson);

        if (sc_string_compare_ext(pJson, "asset", 5))
        {
            // cfg.aTokens[t + 2]; // key: "generator"
            // cfg.aTokens[t + 4]; // key: "version"
            i32 ind = t + 3;
            char* pGenerator = sc_json_token_string(cfg.aTokens, &ind, pContent);
            ++ind;
            char* pVersion = sc_json_token_string(cfg.aTokens, &ind, pContent);
            ScGltfAsset gltfAsset = {
                .pGenerator = pGenerator,
                .pVersion = pVersion
            };

            gltf.Asset = gltfAsset;
            t = ind - 1;
        }
        else if (sc_string_compare_ext(pJson, "scenes", 6))
        {
            // printf("Scences parsing!!!!\n");
            ScJsonToken arrayToken = cfg.aTokens[t + 1]; // array
            i32 scenesCount = sc_json_array_token_length(cfg.aTokens, cfg.TokensCount, t + 1);

            i32 objInd = t + 2;
            objInd += 2; // name value

            ScGltfScene* aScenes = NULL;

            i32 ind = scenesCount;
            while (ind)
            {
                char* pSceneName = sc_json_token_string(cfg.aTokens, &objInd, pContent);
                ++objInd;
                i32* aNodes = sc_json_token_int_array(cfg.aTokens, cfg.TokensCount, &objInd, pContent);

                ScGltfScene gltfScene = {
                    .pName = pSceneName,
                    .aNodes = aNodes
                };

                sc_list_add(aScenes, gltfScene);

                --ind;
            }

            gltf.aScenes = aScenes;
            t = objInd - 1;
        }
        else if (sc_string_compare_ext(pJson, "scene", 6))
        {
            i32 ind = t + 1; // value 0
            gltf.Scene = sc_json_token_int(cfg.aTokens, &ind, pContent);
        }
        else if (sc_string_compare_ext(pJson, "nodes", 5))
        {
            // printf("Parsing nodes!\n");
            i32 objInd = t + 1;
            ScJsonToken arrToken = cfg.aTokens[objInd]; // array
            i32 nodesCount = sc_json_array_token_length(cfg.aTokens, cfg.TokensCount, objInd);

            // printf("nodes count: %d\nnode str: %.*s\n", nodesCount, sc_json_token_length(arrToken), sc_json_text(pContent, arrToken.StartInd));
            ++objInd; // first object in array

            i32 ind = nodesCount;
            while (ind)
            {
                ScGltfNode gltfNode = {};

                ScJsonToken objToken = cfg.aTokens[objInd];

                i32 objTokensLength = sc_json_object_token_length(cfg.aTokens, objInd, cfg.TokensCount);
                i32 keysCount = sc_json_object_token_keys_count(cfg.aTokens, objInd, cfg.TokensCount);

                // printf("objTokens: %d keys count: %d \n", objTokensLength, keysCount);

                ++objInd;
                for (i32 k = 0; k < keysCount; ++k)
                {
                    ScJsonToken key = cfg.aTokens[objInd];
                    char* pValue = sc_json_text(pContent, key.StartInd);

                    if (sc_string_compare_ext(pValue, "mesh", 4))
                    {
                        ++objInd;
                        gltfNode.Mesh = sc_json_token_int(cfg.aTokens, &objInd, pContent);
                    }
                    else if (sc_string_compare_ext(pValue, "name", 4))
                    {
                        ++objInd;
                        gltfNode.pName = sc_json_token_string(cfg.aTokens, &objInd, pContent);
                    }
                    else if (sc_string_compare_ext(pValue, "rotation", 8))
                    {
                        ++objInd;
                        f32* aValues = sc_json_token_float_array(cfg.aTokens, cfg.TokensCount, &objInd, pContent);

                        v4 val = {};
                        memcpy(val.V, aValues, sc_list_count(aValues) * sizeof(f32));

                        gltfNode.Rotation = (v4o) {
                            .IsSet = 1,
                            .Value = val
                        };
                    }
                }

                sc_list_add(gltf.aNodes, gltfNode);

                --ind;
            }

            t = objInd - 1;
            // printf("t=%d after nodes pass\n", t);
        }
        else if (sc_string_compare_ext(pJson, "meshes", 6))
        {
            // printf("Meshses parsing!\n");
            i32 objInd = t + 1;
            ScJsonToken arrToken = cfg.aTokens[objInd]; // array
            i64 meshesCount = sc_json_array_token_length(cfg.aTokens, cfg.TokensCount, objInd);
            ++objInd; // first object in array

            ScGltfMesh* aMeshes = NULL;
            sc_list_reserve(aMeshes, meshesCount);
            // printf("meshes count: %lld\n", meshesCount);

            i32 ind = meshesCount;
            while (ind)
            {
                ScGltfMesh gltfMesh = {};

                ScJsonToken objToken = cfg.aTokens[objInd];

                i32 objTokensLength = sc_json_object_token_length(cfg.aTokens, objInd, cfg.TokensCount);
                i32 keysCount = sc_json_object_token_keys_count(cfg.aTokens, objInd, cfg.TokensCount);

                ++objInd;
                for (i32 k = 0; k < keysCount; ++k)
                {
                    ScJsonToken key = cfg.aTokens[objInd];
                    char* pValue = sc_json_text(pContent, key.StartInd);

                    if (sc_string_compare_ext(pValue, "primitives", 10))
                    {
                        ++objInd;
                        gltfMesh.aPrimitives = sc_gltf_primitive(cfg.aTokens,
                            cfg.TokensCount, &objInd, pContent);
                    }
                    else if (sc_string_compare_ext(pValue, "name", 4))
                    {
                        ++objInd;
                        gltfMesh.pName = sc_json_token_string(cfg.aTokens, &objInd, pContent);
                    }
                }

                sc_list_add(aMeshes, gltfMesh);

                --ind;
            }

            gltf.aMeshes = aMeshes;
            t = objInd - 1;
        }
        else if (sc_string_compare_ext(pJson, "accessors", 9))
        {
            i32 objInd = t + 1;
            gltf.aAccessors = sc_gltf_accessor(cfg.aTokens, cfg.TokensCount, &objInd, pContent);
            t = objInd - 1;
        }
        else if (sc_string_compare_ext(pJson, "bufferViews", 11))
        {
            i32 objInd = t + 1;
            gltf.aBufferViews = sc_gltf_buffer_views(cfg.aTokens, cfg.TokensCount, &objInd, pContent);
            t = objInd - 1;
        }
        else if (sc_string_compare_ext(pJson, "buffers", 7))
        {
            i32 objInd = t + 1;
            gltf.aBuffers = sc_gltf_buffers(cfg.aTokens, cfg.TokensCount, &objInd, pContent);
            t = objInd - 1;
        }
    }

    return gltf;
}

void
sc_gltf_load_buffers(ScGltf* pGltf)
{
    char* pDir = sc_path_get_directory(pGltf->pPath);

    i32 cnt = sc_list_count(pGltf->aBuffers);
    for (i32 b = 0; b < cnt; ++b)
    {
        ScGltfBuffer* pBuffer = &pGltf->aBuffers[b];
        i64 length = 0;
        char* pBufferPath = sc_path_combine(pDir, pBuffer->pUri);
        pBuffer->pData = sc_file_read_ext(pBufferPath, &length);
        printf("Buffer path: %s %p\n", pBufferPath, pBuffer->pData);
        sc_memory_free(pBufferPath);
    }

    sc_memory_free(pDir);
}

void
sc_gltf_unload(ScGltf gltf)
{
    sc_string_destroy(gltf.pPath);
    sc_string_destroy(gltf.Asset.pGenerator);
    sc_string_destroy(gltf.Asset.pVersion);
    sc_list_free(gltf.aScenes);
    sc_list_free(gltf.aNodes);
    sc_list_free(gltf.aMeshes);
    sc_list_free(gltf.aAccessors);
    sc_list_free(gltf.aBufferViews);
    sc_list_free(gltf.aBuffers);
}

const char*
sc_gltf_component_type_to_string(ScGltfComponentType type)
{
    switch (type)
    {
    case ScGltfComponentType_SignedByte:
        return "SignedByte";
    case ScGltfComponentType_UnsignedByte:
        return "UnsignedByte";
    case ScGltfComponentType_SignedShort:
        return "SignedShort";
    case ScGltfComponentType_UnsignedShort:
        return "UnsignedShort";
    case ScGltfComponentType_UnsignedInt:
        return "UnsignedInt";
    case ScGltfComponentType_Float:
        return "Float";
    default:
        return NULL;
    }

    return 0;
}
