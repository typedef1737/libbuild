"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// lib/web-tree-sitter.cjs
var require_web_tree_sitter = __commonJS({
  "lib/web-tree-sitter.cjs"(exports, module) {
    "use strict";
    var Module = (() => {
      var _scriptName = typeof document != "undefined" ? document.currentScript?.src : void 0;
      return async function(moduleArg = {}) {
        var moduleRtn;
        var Module = moduleArg;
        var ENVIRONMENT_IS_WEB = typeof window == "object";
        var ENVIRONMENT_IS_WORKER = typeof WorkerGlobalScope != "undefined";
        var ENVIRONMENT_IS_NODE = typeof process == "object" && process.versions?.node && process.type != "renderer";
        var ENVIRONMENT_IS_SHELL = !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_WORKER;
        Module.currentQueryProgressCallback = null;
        Module.currentProgressCallback = null;
        Module.currentLogCallback = null;
        Module.currentParseCallback = null;
        var arguments_ = [];
        var thisProgram = "./this.program";
        var quit_ = /* @__PURE__ */ __name((status, toThrow) => {
          throw toThrow;
        }, "quit_");
        if (typeof __filename != "undefined") {
          _scriptName = __filename;
        } else if (ENVIRONMENT_IS_WORKER) {
          _scriptName = self.location.href;
        }
        var scriptDirectory = "";
        function locateFile(path) {
          if (Module["locateFile"]) {
            return Module["locateFile"](path, scriptDirectory);
          }
          return scriptDirectory + path;
        }
        __name(locateFile, "locateFile");
        var readAsync, readBinary;
        if (ENVIRONMENT_IS_NODE) {
          const isNode = typeof process == "object" && process.versions?.node && process.type != "renderer";
          if (!isNode) throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
          var nodeVersion = process.versions.node;
          var numericVersion = nodeVersion.split(".").slice(0, 3);
          numericVersion = numericVersion[0] * 1e4 + numericVersion[1] * 100 + numericVersion[2].split("-")[0] * 1;
          if (numericVersion < 16e4) {
            throw new Error("This emscripten-generated code requires node v16.0.0 (detected v" + nodeVersion + ")");
          }
          var fs = require("fs");
          scriptDirectory = __dirname + "/";
          readBinary = /* @__PURE__ */ __name((filename) => {
            filename = isFileURI(filename) ? new URL(filename) : filename;
            var ret = fs.readFileSync(filename);
            assert(Buffer.isBuffer(ret));
            return ret;
          }, "readBinary");
          readAsync = /* @__PURE__ */ __name(async (filename, binary2 = true) => {
            filename = isFileURI(filename) ? new URL(filename) : filename;
            var ret = fs.readFileSync(filename, binary2 ? void 0 : "utf8");
            assert(binary2 ? Buffer.isBuffer(ret) : typeof ret == "string");
            return ret;
          }, "readAsync");
          if (process.argv.length > 1) {
            thisProgram = process.argv[1].replace(/\\/g, "/");
          }
          arguments_ = process.argv.slice(2);
          quit_ = /* @__PURE__ */ __name((status, toThrow) => {
            process.exitCode = status;
            throw toThrow;
          }, "quit_");
        } else if (ENVIRONMENT_IS_SHELL) {
          const isNode = typeof process == "object" && process.versions?.node && process.type != "renderer";
          if (isNode || typeof window == "object" || typeof WorkerGlobalScope != "undefined") throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
        } else if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
          try {
            scriptDirectory = new URL(".", _scriptName).href;
          } catch {
          }
          if (!(typeof window == "object" || typeof WorkerGlobalScope != "undefined")) throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
          {
            if (ENVIRONMENT_IS_WORKER) {
              readBinary = /* @__PURE__ */ __name((url) => {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", url, false);
                xhr.responseType = "arraybuffer";
                xhr.send(null);
                return new Uint8Array(
                  /** @type{!ArrayBuffer} */
                  xhr.response
                );
              }, "readBinary");
            }
            readAsync = /* @__PURE__ */ __name(async (url) => {
              if (isFileURI(url)) {
                return new Promise((resolve, reject) => {
                  var xhr = new XMLHttpRequest();
                  xhr.open("GET", url, true);
                  xhr.responseType = "arraybuffer";
                  xhr.onload = () => {
                    if (xhr.status == 200 || xhr.status == 0 && xhr.response) {
                      resolve(xhr.response);
                      return;
                    }
                    reject(xhr.status);
                  };
                  xhr.onerror = reject;
                  xhr.send(null);
                });
              }
              var response = await fetch(url, {
                credentials: "same-origin"
              });
              if (response.ok) {
                return response.arrayBuffer();
              }
              throw new Error(response.status + " : " + response.url);
            }, "readAsync");
          }
        } else {
          throw new Error("environment detection error");
        }
        var out = console.log.bind(console);
        var err = console.error.bind(console);
        var IDBFS = "IDBFS is no longer included by default; build with -lidbfs.js";
        var PROXYFS = "PROXYFS is no longer included by default; build with -lproxyfs.js";
        var WORKERFS = "WORKERFS is no longer included by default; build with -lworkerfs.js";
        var FETCHFS = "FETCHFS is no longer included by default; build with -lfetchfs.js";
        var ICASEFS = "ICASEFS is no longer included by default; build with -licasefs.js";
        var JSFILEFS = "JSFILEFS is no longer included by default; build with -ljsfilefs.js";
        var OPFS = "OPFS is no longer included by default; build with -lopfs.js";
        var NODEFS = "NODEFS is no longer included by default; build with -lnodefs.js";
        assert(!ENVIRONMENT_IS_SHELL, "shell environment detected but not enabled at build time.  Add `shell` to `-sENVIRONMENT` to enable.");
        var dynamicLibraries = [];
        var wasmBinary;
        if (typeof WebAssembly != "object") {
          err("no native wasm support detected");
        }
        var ABORT = false;
        var EXITSTATUS;
        function assert(condition, text) {
          if (!condition) {
            abort("Assertion failed" + (text ? ": " + text : ""));
          }
        }
        __name(assert, "assert");
        var isFileURI = /* @__PURE__ */ __name((filename) => filename.startsWith("file://"), "isFileURI");
        function writeStackCookie() {
          var max = _emscripten_stack_get_end();
          assert((max & 3) == 0);
          if (max == 0) {
            max += 4;
          }
          LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, max >> 2, "storing") * 4, 34821223);
          LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, max + 4 >> 2, "storing") * 4, 2310721022);
        }
        __name(writeStackCookie, "writeStackCookie");
        function checkStackCookie() {
          if (ABORT) return;
          var max = _emscripten_stack_get_end();
          if (max == 0) {
            max += 4;
          }
          var cookie1 = LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, max >> 2, "loading") * 4);
          var cookie2 = LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, max + 4 >> 2, "loading") * 4);
          if (cookie1 != 34821223 || cookie2 != 2310721022) {
            abort(`Stack overflow! Stack cookie has been overwritten at ${ptrToString(max)}, expected hex dwords 0x89BACDFE and 0x2135467, but received ${ptrToString(cookie2)} ${ptrToString(cookie1)}`);
          }
        }
        __name(checkStackCookie, "checkStackCookie");
        var runtimeDebug = true;
        function dbg(...args2) {
          if (!runtimeDebug && typeof runtimeDebug != "undefined") return;
          console.warn(...args2);
        }
        __name(dbg, "dbg");
        function consumedModuleProp(prop) {
          if (!Object.getOwnPropertyDescriptor(Module, prop)) {
            Object.defineProperty(Module, prop, {
              configurable: true,
              set() {
                abort(`Attempt to set \`Module.${prop}\` after it has already been processed.  This can happen, for example, when code is injected via '--post-js' rather than '--pre-js'`);
              }
            });
          }
        }
        __name(consumedModuleProp, "consumedModuleProp");
        function makeInvalidEarlyAccess(name2) {
          return () => assert(false, `call to '${name2}' via reference taken before Wasm module initialization`);
        }
        __name(makeInvalidEarlyAccess, "makeInvalidEarlyAccess");
        function ignoredModuleProp(prop) {
          if (Object.getOwnPropertyDescriptor(Module, prop)) {
            abort(`\`Module.${prop}\` was supplied but \`${prop}\` not included in INCOMING_MODULE_JS_API`);
          }
        }
        __name(ignoredModuleProp, "ignoredModuleProp");
        function isExportedByForceFilesystem(name2) {
          return name2 === "FS_createPath" || name2 === "FS_createDataFile" || name2 === "FS_createPreloadedFile" || name2 === "FS_preloadFile" || name2 === "FS_unlink" || name2 === "addRunDependency" || // The old FS has some functionality that WasmFS lacks.
          name2 === "FS_createLazyFile" || name2 === "FS_createDevice" || name2 === "removeRunDependency";
        }
        __name(isExportedByForceFilesystem, "isExportedByForceFilesystem");
        function missingLibrarySymbol(sym) {
          unexportedRuntimeSymbol(sym);
        }
        __name(missingLibrarySymbol, "missingLibrarySymbol");
        function unexportedRuntimeSymbol(sym) {
          if (!Object.getOwnPropertyDescriptor(Module, sym)) {
            Object.defineProperty(Module, sym, {
              configurable: true,
              get() {
                var msg = `'${sym}' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)`;
                if (isExportedByForceFilesystem(sym)) {
                  msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
                }
                abort(msg);
              }
            });
          }
        }
        __name(unexportedRuntimeSymbol, "unexportedRuntimeSymbol");
        function SAFE_HEAP_INDEX(arr, idx, action) {
          const bytes = arr.BYTES_PER_ELEMENT;
          const dest = idx * bytes;
          if (idx <= 0) abort(`segmentation fault ${action} ${bytes} bytes at address ${dest}`);
          if (runtimeInitialized) {
            var brk = _sbrk(0);
            if (dest + bytes > brk) abort(`segmentation fault, exceeded the top of the available dynamic heap when ${action} ${bytes} bytes at address ${dest}. DYNAMICTOP=${brk}`);
            if (brk < _emscripten_stack_get_base()) abort(`brk >= _emscripten_stack_get_base() (brk=${brk}, _emscripten_stack_get_base()=${_emscripten_stack_get_base()})`);
            if (brk > wasmMemory.buffer.byteLength) abort(`brk <= wasmMemory.buffer.byteLength (brk=${brk}, wasmMemory.buffer.byteLength=${wasmMemory.buffer.byteLength})`);
          }
          return idx;
        }
        __name(SAFE_HEAP_INDEX, "SAFE_HEAP_INDEX");
        function segfault() {
          abort("segmentation fault");
        }
        __name(segfault, "segfault");
        function alignfault() {
          abort("alignment fault");
        }
        __name(alignfault, "alignfault");
        var readyPromiseResolve, readyPromiseReject;
        var wasmMemory;
        var HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
        var HEAP64, HEAPU64;
        var HEAP_DATA_VIEW;
        var runtimeInitialized = false;
        function updateMemoryViews() {
          var b = wasmMemory.buffer;
          Module["HEAP8"] = HEAP8 = new Int8Array(b);
          Module["HEAP16"] = HEAP16 = new Int16Array(b);
          Module["HEAPU8"] = HEAPU8 = new Uint8Array(b);
          Module["HEAPU16"] = HEAPU16 = new Uint16Array(b);
          Module["HEAP32"] = HEAP32 = new Int32Array(b);
          Module["HEAPU32"] = HEAPU32 = new Uint32Array(b);
          Module["HEAPF32"] = HEAPF32 = new Float32Array(b);
          Module["HEAPF64"] = HEAPF64 = new Float64Array(b);
          Module["HEAP64"] = HEAP64 = new BigInt64Array(b);
          Module["HEAPU64"] = HEAPU64 = new BigUint64Array(b);
          Module["HEAP_DATA_VIEW"] = HEAP_DATA_VIEW = new DataView(b);
          LE_HEAP_UPDATE();
        }
        __name(updateMemoryViews, "updateMemoryViews");
        function initMemory() {
          if (Module["wasmMemory"]) {
            wasmMemory = Module["wasmMemory"];
          } else {
            var INITIAL_MEMORY = Module["INITIAL_MEMORY"] || 33554432;
            assert(INITIAL_MEMORY >= 65536, "INITIAL_MEMORY should be larger than STACK_SIZE, was " + INITIAL_MEMORY + "! (STACK_SIZE=65536)");
            wasmMemory = new WebAssembly.Memory({
              "initial": INITIAL_MEMORY / 65536,
              // In theory we should not need to emit the maximum if we want "unlimited"
              // or 4GB of memory, but VMs error on that atm, see
              // https://github.com/emscripten-core/emscripten/issues/14130
              // And in the pthreads case we definitely need to emit a maximum. So
              // always emit one.
              "maximum": 32768
            });
          }
          updateMemoryViews();
        }
        __name(initMemory, "initMemory");
        assert(typeof Int32Array != "undefined" && typeof Float64Array !== "undefined" && Int32Array.prototype.subarray != void 0 && Int32Array.prototype.set != void 0, "JS engine does not provide full typed array support");
        var __RELOC_FUNCS__ = [];
        function preRun() {
          if (Module["preRun"]) {
            if (typeof Module["preRun"] == "function") Module["preRun"] = [Module["preRun"]];
            while (Module["preRun"].length) {
              addOnPreRun(Module["preRun"].shift());
            }
          }
          consumedModuleProp("preRun");
          callRuntimeCallbacks(onPreRuns);
        }
        __name(preRun, "preRun");
        function initRuntime() {
          assert(!runtimeInitialized);
          runtimeInitialized = true;
          checkStackCookie();
          callRuntimeCallbacks(__RELOC_FUNCS__);
          wasmExports["__wasm_call_ctors"]();
          callRuntimeCallbacks(onPostCtors);
        }
        __name(initRuntime, "initRuntime");
        function preMain() {
          checkStackCookie();
        }
        __name(preMain, "preMain");
        function postRun() {
          checkStackCookie();
          if (Module["postRun"]) {
            if (typeof Module["postRun"] == "function") Module["postRun"] = [Module["postRun"]];
            while (Module["postRun"].length) {
              addOnPostRun(Module["postRun"].shift());
            }
          }
          consumedModuleProp("postRun");
          callRuntimeCallbacks(onPostRuns);
        }
        __name(postRun, "postRun");
        function abort(what) {
          Module["onAbort"]?.(what);
          what = "Aborted(" + what + ")";
          err(what);
          ABORT = true;
          var e = new WebAssembly.RuntimeError(what);
          readyPromiseReject?.(e);
          throw e;
        }
        __name(abort, "abort");
        var FS = {
          error() {
            abort("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with -sFORCE_FILESYSTEM");
          },
          init() {
            FS.error();
          },
          createDataFile() {
            FS.error();
          },
          createPreloadedFile() {
            FS.error();
          },
          createLazyFile() {
            FS.error();
          },
          open() {
            FS.error();
          },
          mkdev() {
            FS.error();
          },
          registerDevice() {
            FS.error();
          },
          analyzePath() {
            FS.error();
          },
          ErrnoError() {
            FS.error();
          }
        };
        function createExportWrapper(name2, nargs) {
          return (...args2) => {
            assert(runtimeInitialized, `native function \`${name2}\` called before runtime initialization`);
            var f = wasmExports[name2];
            assert(f, `exported native function \`${name2}\` not found`);
            assert(args2.length <= nargs, `native function \`${name2}\` called with ${args2.length} args but expects ${nargs}`);
            return f(...args2);
          };
        }
        __name(createExportWrapper, "createExportWrapper");
        var wasmBinaryFile;
        function findWasmBinary() {
          return locateFile("web-tree-sitter.wasm");
        }
        __name(findWasmBinary, "findWasmBinary");
        function getBinarySync(file) {
          if (file == wasmBinaryFile && wasmBinary) {
            return new Uint8Array(wasmBinary);
          }
          if (readBinary) {
            return readBinary(file);
          }
          throw "both async and sync fetching of the wasm failed";
        }
        __name(getBinarySync, "getBinarySync");
        async function getWasmBinary(binaryFile) {
          if (!wasmBinary) {
            try {
              var response = await readAsync(binaryFile);
              return new Uint8Array(response);
            } catch {
            }
          }
          return getBinarySync(binaryFile);
        }
        __name(getWasmBinary, "getWasmBinary");
        async function instantiateArrayBuffer(binaryFile, imports) {
          try {
            var binary2 = await getWasmBinary(binaryFile);
            var instance2 = await WebAssembly.instantiate(binary2, imports);
            return instance2;
          } catch (reason) {
            err(`failed to asynchronously prepare wasm: ${reason}`);
            if (isFileURI(binaryFile)) {
              err(`warning: Loading from a file URI (${binaryFile}) is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing`);
            }
            abort(reason);
          }
        }
        __name(instantiateArrayBuffer, "instantiateArrayBuffer");
        async function instantiateAsync(binary2, binaryFile, imports) {
          if (!binary2 && !isFileURI(binaryFile) && !ENVIRONMENT_IS_NODE) {
            try {
              var response = fetch(binaryFile, {
                credentials: "same-origin"
              });
              var instantiationResult = await WebAssembly.instantiateStreaming(response, imports);
              return instantiationResult;
            } catch (reason) {
              err(`wasm streaming compile failed: ${reason}`);
              err("falling back to ArrayBuffer instantiation");
            }
          }
          return instantiateArrayBuffer(binaryFile, imports);
        }
        __name(instantiateAsync, "instantiateAsync");
        function getWasmImports() {
          return {
            "env": wasmImports,
            "wasi_snapshot_preview1": wasmImports,
            "GOT.mem": new Proxy(wasmImports, GOTHandler),
            "GOT.func": new Proxy(wasmImports, GOTHandler)
          };
        }
        __name(getWasmImports, "getWasmImports");
        async function createWasm() {
          function receiveInstance(instance2, module2) {
            wasmExports = instance2.exports;
            wasmExports = relocateExports(wasmExports, 1024);
            var metadata2 = getDylinkMetadata(module2);
            if (metadata2.neededDynlibs) {
              dynamicLibraries = metadata2.neededDynlibs.concat(dynamicLibraries);
            }
            mergeLibSymbols(wasmExports, "main");
            LDSO.init();
            loadDylibs();
            __RELOC_FUNCS__.push(wasmExports["__wasm_apply_data_relocs"]);
            assignWasmExports(wasmExports);
            return wasmExports;
          }
          __name(receiveInstance, "receiveInstance");
          var trueModule = Module;
          function receiveInstantiationResult(result2) {
            assert(Module === trueModule, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
            trueModule = null;
            return receiveInstance(result2["instance"], result2["module"]);
          }
          __name(receiveInstantiationResult, "receiveInstantiationResult");
          var info2 = getWasmImports();
          if (Module["instantiateWasm"]) {
            return new Promise((resolve, reject) => {
              try {
                Module["instantiateWasm"](info2, (mod, inst) => {
                  resolve(receiveInstance(mod, inst));
                });
              } catch (e) {
                err(`Module.instantiateWasm callback failed with error: ${e}`);
                reject(e);
              }
            });
          }
          wasmBinaryFile ??= findWasmBinary();
          var result = await instantiateAsync(wasmBinary, wasmBinaryFile, info2);
          var exports2 = receiveInstantiationResult(result);
          return exports2;
        }
        __name(createWasm, "createWasm");
        class ExitStatus {
          static {
            __name(this, "ExitStatus");
          }
          name = "ExitStatus";
          constructor(status) {
            this.message = `Program terminated with exit(${status})`;
            this.status = status;
          }
        }
        var GOT = {};
        var currentModuleWeakSymbols = /* @__PURE__ */ new Set([]);
        var GOTHandler = {
          get(obj, symName) {
            var rtn = GOT[symName];
            if (!rtn) {
              rtn = GOT[symName] = new WebAssembly.Global({
                "value": "i32",
                "mutable": true
              });
            }
            if (!currentModuleWeakSymbols.has(symName)) {
              rtn.required = true;
            }
            return rtn;
          }
        };
        var LE_ATOMICS_ADD = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.add(heap, offset, order(value)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_ADD");
        var LE_ATOMICS_AND = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.and(heap, offset, order(value)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_AND");
        var LE_ATOMICS_COMPAREEXCHANGE = /* @__PURE__ */ __name((heap, offset, expected, replacement) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.compareExchange(heap, offset, order(expected), order(replacement)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_COMPAREEXCHANGE");
        var LE_ATOMICS_EXCHANGE = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.exchange(heap, offset, order(value)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_EXCHANGE");
        var LE_ATOMICS_ISLOCKFREE = /* @__PURE__ */ __name((size) => Atomics.isLockFree(size), "LE_ATOMICS_ISLOCKFREE");
        var LE_ATOMICS_LOAD = /* @__PURE__ */ __name((heap, offset) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.load(heap, offset));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_LOAD");
        var LE_ATOMICS_NATIVE_BYTE_ORDER = [];
        var LE_ATOMICS_NOTIFY = /* @__PURE__ */ __name((heap, offset, count) => Atomics.notify(heap, offset, count), "LE_ATOMICS_NOTIFY");
        var LE_ATOMICS_OR = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.or(heap, offset, order(value)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_OR");
        var LE_ATOMICS_STORE = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          Atomics.store(heap, offset, order(value));
        }, "LE_ATOMICS_STORE");
        var LE_ATOMICS_SUB = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.sub(heap, offset, order(value)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_SUB");
        var LE_ATOMICS_WAIT = /* @__PURE__ */ __name((heap, offset, value, timeout) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          return Atomics.wait(heap, offset, order(value), timeout);
        }, "LE_ATOMICS_WAIT");
        var LE_ATOMICS_WAITASYNC = /* @__PURE__ */ __name((heap, offset, value, timeout) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          return Atomics.waitAsync(heap, offset, order(value), timeout);
        }, "LE_ATOMICS_WAITASYNC");
        var LE_ATOMICS_XOR = /* @__PURE__ */ __name((heap, offset, value) => {
          const order = LE_ATOMICS_NATIVE_BYTE_ORDER[heap.BYTES_PER_ELEMENT - 1];
          const res = order(Atomics.xor(heap, offset, order(value)));
          return heap.unsigned ? heap.unsigned(res) : res;
        }, "LE_ATOMICS_XOR");
        var LE_HEAP_LOAD_F32 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getFloat32(byteOffset, true), "LE_HEAP_LOAD_F32");
        var LE_HEAP_LOAD_F64 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getFloat64(byteOffset, true), "LE_HEAP_LOAD_F64");
        var LE_HEAP_LOAD_I16 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getInt16(byteOffset, true), "LE_HEAP_LOAD_I16");
        var LE_HEAP_LOAD_I32 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getInt32(byteOffset, true), "LE_HEAP_LOAD_I32");
        var LE_HEAP_LOAD_I64 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getBigInt64(byteOffset, true), "LE_HEAP_LOAD_I64");
        var LE_HEAP_LOAD_U16 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getUint16(byteOffset, true), "LE_HEAP_LOAD_U16");
        var LE_HEAP_LOAD_U32 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getUint32(byteOffset, true), "LE_HEAP_LOAD_U32");
        var LE_HEAP_LOAD_U64 = /* @__PURE__ */ __name((byteOffset) => HEAP_DATA_VIEW.getBigUint64(byteOffset, true), "LE_HEAP_LOAD_U64");
        var LE_HEAP_STORE_F32 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setFloat32(byteOffset, value, true), "LE_HEAP_STORE_F32");
        var LE_HEAP_STORE_F64 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setFloat64(byteOffset, value, true), "LE_HEAP_STORE_F64");
        var LE_HEAP_STORE_I16 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setInt16(byteOffset, value, true), "LE_HEAP_STORE_I16");
        var LE_HEAP_STORE_I32 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setInt32(byteOffset, value, true), "LE_HEAP_STORE_I32");
        var LE_HEAP_STORE_I64 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setBigInt64(byteOffset, value, true), "LE_HEAP_STORE_I64");
        var LE_HEAP_STORE_U16 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setUint16(byteOffset, value, true), "LE_HEAP_STORE_U16");
        var LE_HEAP_STORE_U32 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setUint32(byteOffset, value, true), "LE_HEAP_STORE_U32");
        var LE_HEAP_STORE_U64 = /* @__PURE__ */ __name((byteOffset, value) => HEAP_DATA_VIEW.setBigUint64(byteOffset, value, true), "LE_HEAP_STORE_U64");
        var callRuntimeCallbacks = /* @__PURE__ */ __name((callbacks) => {
          while (callbacks.length > 0) {
            callbacks.shift()(Module);
          }
        }, "callRuntimeCallbacks");
        var onPostRuns = [];
        var addOnPostRun = /* @__PURE__ */ __name((cb) => onPostRuns.push(cb), "addOnPostRun");
        var onPreRuns = [];
        var addOnPreRun = /* @__PURE__ */ __name((cb) => onPreRuns.push(cb), "addOnPreRun");
        var UTF8Decoder = typeof TextDecoder != "undefined" ? new TextDecoder() : void 0;
        var findStringEnd = /* @__PURE__ */ __name((heapOrArray, idx, maxBytesToRead, ignoreNul) => {
          var maxIdx = idx + maxBytesToRead;
          if (ignoreNul) return maxIdx;
          while (heapOrArray[idx] && !(idx >= maxIdx)) ++idx;
          return idx;
        }, "findStringEnd");
        var warnOnce = /* @__PURE__ */ __name((text) => {
          warnOnce.shown ||= {};
          if (!warnOnce.shown[text]) {
            warnOnce.shown[text] = 1;
            if (ENVIRONMENT_IS_NODE) text = "warning: " + text;
            err(text);
          }
        }, "warnOnce");
        var UTF8ArrayToString = /* @__PURE__ */ __name((heapOrArray, idx = 0, maxBytesToRead, ignoreNul) => {
          var endPtr = findStringEnd(heapOrArray, idx, maxBytesToRead, ignoreNul);
          if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) {
            return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
          }
          var str = "";
          while (idx < endPtr) {
            var u0 = heapOrArray[idx++];
            if (!(u0 & 128)) {
              str += String.fromCharCode(u0);
              continue;
            }
            var u1 = heapOrArray[idx++] & 63;
            if ((u0 & 224) == 192) {
              str += String.fromCharCode((u0 & 31) << 6 | u1);
              continue;
            }
            var u2 = heapOrArray[idx++] & 63;
            if ((u0 & 240) == 224) {
              u0 = (u0 & 15) << 12 | u1 << 6 | u2;
            } else {
              if ((u0 & 248) != 240) warnOnce("Invalid UTF-8 leading byte " + ptrToString(u0) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!");
              u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63;
            }
            if (u0 < 65536) {
              str += String.fromCharCode(u0);
            } else {
              var ch = u0 - 65536;
              str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
            }
          }
          return str;
        }, "UTF8ArrayToString");
        var getDylinkMetadata = /* @__PURE__ */ __name((binary2) => {
          var offset = 0;
          var end = 0;
          function getU8() {
            return binary2[offset++];
          }
          __name(getU8, "getU8");
          function getLEB() {
            var ret = 0;
            var mul = 1;
            while (1) {
              var byte = binary2[offset++];
              ret += (byte & 127) * mul;
              mul *= 128;
              if (!(byte & 128)) break;
            }
            return ret;
          }
          __name(getLEB, "getLEB");
          function getString() {
            var len = getLEB();
            offset += len;
            return UTF8ArrayToString(binary2, offset - len, len);
          }
          __name(getString, "getString");
          function getStringList() {
            var count2 = getLEB();
            var rtn = [];
            while (count2--) rtn.push(getString());
            return rtn;
          }
          __name(getStringList, "getStringList");
          function failIf(condition, message) {
            if (condition) throw new Error(message);
          }
          __name(failIf, "failIf");
          if (binary2 instanceof WebAssembly.Module) {
            var dylinkSection = WebAssembly.Module.customSections(binary2, "dylink.0");
            failIf(dylinkSection.length === 0, "need dylink section");
            binary2 = new Uint8Array(dylinkSection[0]);
            end = binary2.length;
          } else {
            var int32View = new Uint32Array(new Uint8Array(binary2.subarray(0, 24)).buffer);
            var magicNumberFound = int32View[0] == 1836278016 || int32View[0] == 6386541;
            failIf(!magicNumberFound, "need to see wasm magic number");
            failIf(binary2[8] !== 0, "need the dylink section to be first");
            offset = 9;
            var section_size = getLEB();
            end = offset + section_size;
            var name2 = getString();
            failIf(name2 !== "dylink.0");
          }
          var customSection = {
            neededDynlibs: [],
            tlsExports: /* @__PURE__ */ new Set(),
            weakImports: /* @__PURE__ */ new Set(),
            runtimePaths: []
          };
          var WASM_DYLINK_MEM_INFO = 1;
          var WASM_DYLINK_NEEDED = 2;
          var WASM_DYLINK_EXPORT_INFO = 3;
          var WASM_DYLINK_IMPORT_INFO = 4;
          var WASM_DYLINK_RUNTIME_PATH = 5;
          var WASM_SYMBOL_TLS = 256;
          var WASM_SYMBOL_BINDING_MASK = 3;
          var WASM_SYMBOL_BINDING_WEAK = 1;
          while (offset < end) {
            var subsectionType = getU8();
            var subsectionSize = getLEB();
            if (subsectionType === WASM_DYLINK_MEM_INFO) {
              customSection.memorySize = getLEB();
              customSection.memoryAlign = getLEB();
              customSection.tableSize = getLEB();
              customSection.tableAlign = getLEB();
            } else if (subsectionType === WASM_DYLINK_NEEDED) {
              customSection.neededDynlibs = getStringList();
            } else if (subsectionType === WASM_DYLINK_EXPORT_INFO) {
              var count = getLEB();
              while (count--) {
                var symname = getString();
                var flags2 = getLEB();
                if (flags2 & WASM_SYMBOL_TLS) {
                  customSection.tlsExports.add(symname);
                }
              }
            } else if (subsectionType === WASM_DYLINK_IMPORT_INFO) {
              var count = getLEB();
              while (count--) {
                var modname = getString();
                var symname = getString();
                var flags2 = getLEB();
                if ((flags2 & WASM_SYMBOL_BINDING_MASK) == WASM_SYMBOL_BINDING_WEAK) {
                  customSection.weakImports.add(symname);
                }
              }
            } else if (subsectionType === WASM_DYLINK_RUNTIME_PATH) {
              customSection.runtimePaths = getStringList();
            } else {
              err("unknown dylink.0 subsection:", subsectionType);
              offset += subsectionSize;
            }
          }
          var tableAlign = Math.pow(2, customSection.tableAlign);
          assert(tableAlign === 1, `invalid tableAlign ${tableAlign}`);
          assert(offset == end);
          return customSection;
        }, "getDylinkMetadata");
        function getValue(ptr, type = "i8") {
          if (type.endsWith("*")) type = "*";
          switch (type) {
            case "i1":
              return HEAP8[SAFE_HEAP_INDEX(HEAP8, ptr, "loading")];
            case "i8":
              return HEAP8[SAFE_HEAP_INDEX(HEAP8, ptr, "loading")];
            case "i16":
              return LE_HEAP_LOAD_I16(SAFE_HEAP_INDEX(HEAP16, ptr >> 1, "loading") * 2);
            case "i32":
              return LE_HEAP_LOAD_I32(SAFE_HEAP_INDEX(HEAP32, ptr >> 2, "loading") * 4);
            case "i64":
              return LE_HEAP_LOAD_I64(SAFE_HEAP_INDEX(HEAP64, ptr >> 3, "loading") * 8);
            case "float":
              return LE_HEAP_LOAD_F32(SAFE_HEAP_INDEX(HEAPF32, ptr >> 2, "loading") * 4);
            case "double":
              return LE_HEAP_LOAD_F64(SAFE_HEAP_INDEX(HEAPF64, ptr >> 3, "loading") * 8);
            case "*":
              return LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, ptr >> 2, "loading") * 4);
            default:
              abort(`invalid type for getValue: ${type}`);
          }
        }
        __name(getValue, "getValue");
        var newDSO = /* @__PURE__ */ __name((name2, handle2, syms) => {
          var dso = {
            refcount: Infinity,
            name: name2,
            exports: syms,
            global: true
          };
          LDSO.loadedLibsByName[name2] = dso;
          if (handle2 != void 0) {
            LDSO.loadedLibsByHandle[handle2] = dso;
          }
          return dso;
        }, "newDSO");
        var LDSO = {
          loadedLibsByName: {},
          loadedLibsByHandle: {},
          init() {
            assert(wasmImports);
            newDSO("__main__", 0, wasmImports);
          }
        };
        var ___heap_base = 82240;
        var alignMemory = /* @__PURE__ */ __name((size, alignment) => {
          assert(alignment, "alignment argument is required");
          return Math.ceil(size / alignment) * alignment;
        }, "alignMemory");
        var getMemory = /* @__PURE__ */ __name((size) => {
          if (runtimeInitialized) {
            return _calloc(size, 1);
          }
          var ret = ___heap_base;
          var end = ret + alignMemory(size, 16);
          assert(end <= HEAP8.length, "failure to getMemory - memory growth etc. is not supported there, call malloc/sbrk directly or increase INITIAL_MEMORY");
          ___heap_base = end;
          GOT["__heap_base"].value = end;
          return ret;
        }, "getMemory");
        var isInternalSym = /* @__PURE__ */ __name((symName) => ["__cpp_exception", "__c_longjmp", "__wasm_apply_data_relocs", "__dso_handle", "__tls_size", "__tls_align", "__set_stack_limits", "_emscripten_tls_init", "__wasm_init_tls", "__wasm_call_ctors", "__start_em_asm", "__stop_em_asm", "__start_em_js", "__stop_em_js"].includes(symName) || symName.startsWith("__em_js__"), "isInternalSym");
        var uleb128EncodeWithLen = /* @__PURE__ */ __name((arr) => {
          const n = arr.length;
          assert(n < 16384);
          return [n % 128 | 128, n >> 7, ...arr];
        }, "uleb128EncodeWithLen");
        var wasmTypeCodes = {
          "i": 127,
          // i32
          "p": 127,
          // i32
          "j": 126,
          // i64
          "f": 125,
          // f32
          "d": 124,
          // f64
          "e": 111
        };
        var generateTypePack = /* @__PURE__ */ __name((types) => uleb128EncodeWithLen(Array.from(types, (type) => {
          var code = wasmTypeCodes[type];
          assert(code, `invalid signature char: ${type}`);
          return code;
        })), "generateTypePack");
        var convertJsFunctionToWasm = /* @__PURE__ */ __name((func2, sig) => {
          var bytes = Uint8Array.of(
            0,
            97,
            115,
            109,
            // magic ("\0asm")
            1,
            0,
            0,
            0,
            // version: 1
            1,
            ...uleb128EncodeWithLen([
              1,
              // count: 1
              96,
              // param types
              ...generateTypePack(sig.slice(1)),
              // return types (for now only supporting [] if `void` and single [T] otherwise)
              ...generateTypePack(sig[0] === "v" ? "" : sig[0])
            ]),
            // The rest of the module is static
            2,
            7,
            // import section
            // (import "e" "f" (func 0 (type 0)))
            1,
            1,
            101,
            1,
            102,
            0,
            0,
            7,
            5,
            // export section
            // (export "f" (func 0 (type 0)))
            1,
            1,
            102,
            0,
            0
          );
          var module2 = new WebAssembly.Module(bytes);
          var instance2 = new WebAssembly.Instance(module2, {
            "e": {
              "f": func2
            }
          });
          var wrappedFunc = instance2.exports["f"];
          return wrappedFunc;
        }, "convertJsFunctionToWasm");
        var wasmTableMirror = [];
        var wasmTable = new WebAssembly.Table({
          "initial": 31,
          "element": "anyfunc"
        });
        var getWasmTableEntry = /* @__PURE__ */ __name((funcPtr) => {
          var func2 = wasmTableMirror[funcPtr];
          if (!func2) {
            wasmTableMirror[funcPtr] = func2 = wasmTable.get(funcPtr);
          }
          assert(wasmTable.get(funcPtr) == func2, "JavaScript-side Wasm function table mirror is out of date!");
          return func2;
        }, "getWasmTableEntry");
        var updateTableMap = /* @__PURE__ */ __name((offset, count) => {
          if (functionsInTableMap) {
            for (var i2 = offset; i2 < offset + count; i2++) {
              var item = getWasmTableEntry(i2);
              if (item) {
                functionsInTableMap.set(item, i2);
              }
            }
          }
        }, "updateTableMap");
        var functionsInTableMap;
        var getFunctionAddress = /* @__PURE__ */ __name((func2) => {
          if (!functionsInTableMap) {
            functionsInTableMap = /* @__PURE__ */ new WeakMap();
            updateTableMap(0, wasmTable.length);
          }
          return functionsInTableMap.get(func2) || 0;
        }, "getFunctionAddress");
        var freeTableIndexes = [];
        var getEmptyTableSlot = /* @__PURE__ */ __name(() => {
          if (freeTableIndexes.length) {
            return freeTableIndexes.pop();
          }
          try {
            return wasmTable["grow"](1);
          } catch (err2) {
            if (!(err2 instanceof RangeError)) {
              throw err2;
            }
            abort("Unable to grow wasm table. Set ALLOW_TABLE_GROWTH.");
          }
        }, "getEmptyTableSlot");
        var setWasmTableEntry = /* @__PURE__ */ __name((idx, func2) => {
          wasmTable.set(idx, func2);
          wasmTableMirror[idx] = wasmTable.get(idx);
        }, "setWasmTableEntry");
        var addFunction = /* @__PURE__ */ __name((func2, sig) => {
          assert(typeof func2 != "undefined");
          var rtn = getFunctionAddress(func2);
          if (rtn) {
            return rtn;
          }
          var ret = getEmptyTableSlot();
          try {
            setWasmTableEntry(ret, func2);
          } catch (err2) {
            if (!(err2 instanceof TypeError)) {
              throw err2;
            }
            assert(typeof sig != "undefined", "Missing signature argument to addFunction: " + func2);
            var wrapped = convertJsFunctionToWasm(func2, sig);
            setWasmTableEntry(ret, wrapped);
          }
          functionsInTableMap.set(func2, ret);
          return ret;
        }, "addFunction");
        var updateGOT = /* @__PURE__ */ __name((exports2, replace) => {
          for (var symName in exports2) {
            if (isInternalSym(symName)) {
              continue;
            }
            var value = exports2[symName];
            GOT[symName] ||= new WebAssembly.Global({
              "value": "i32",
              "mutable": true
            });
            if (replace || GOT[symName].value == 0) {
              if (typeof value == "function") {
                GOT[symName].value = addFunction(value);
              } else if (typeof value == "number") {
                GOT[symName].value = value;
              } else {
                err(`unhandled export type for '${symName}': ${typeof value}`);
              }
            }
          }
        }, "updateGOT");
        var relocateExports = /* @__PURE__ */ __name((exports2, memoryBase2, replace) => {
          var relocated = {};
          for (var e in exports2) {
            var value = exports2[e];
            if (typeof value == "object") {
              value = value.value;
            }
            if (typeof value == "number") {
              value += memoryBase2;
            }
            relocated[e] = value;
          }
          updateGOT(relocated, replace);
          return relocated;
        }, "relocateExports");
        var isSymbolDefined = /* @__PURE__ */ __name((symName) => {
          var existing = wasmImports[symName];
          if (!existing || existing.stub) {
            return false;
          }
          return true;
        }, "isSymbolDefined");
        var dynCall = /* @__PURE__ */ __name((sig, ptr, args2 = [], promising = false) => {
          assert(!promising, "async dynCall is not supported in this mode");
          assert(getWasmTableEntry(ptr), `missing table entry in dynCall: ${ptr}`);
          var func2 = getWasmTableEntry(ptr);
          var rtn = func2(...args2);
          function convert(rtn2) {
            return rtn2;
          }
          __name(convert, "convert");
          return convert(rtn);
        }, "dynCall");
        var stackSave = /* @__PURE__ */ __name(() => _emscripten_stack_get_current(), "stackSave");
        var stackRestore = /* @__PURE__ */ __name((val) => __emscripten_stack_restore(val), "stackRestore");
        var createInvokeFunction = /* @__PURE__ */ __name((sig) => (ptr, ...args2) => {
          var sp = stackSave();
          try {
            return dynCall(sig, ptr, args2);
          } catch (e) {
            stackRestore(sp);
            if (e !== e + 0) throw e;
            _setThrew(1, 0);
            if (sig[0] == "j") return 0n;
          }
        }, "createInvokeFunction");
        var resolveGlobalSymbol = /* @__PURE__ */ __name((symName, direct = false) => {
          var sym;
          if (isSymbolDefined(symName)) {
            sym = wasmImports[symName];
          } else if (symName.startsWith("invoke_")) {
            sym = wasmImports[symName] = createInvokeFunction(symName.split("_")[1]);
          }
          return {
            sym,
            name: symName
          };
        }, "resolveGlobalSymbol");
        var onPostCtors = [];
        var addOnPostCtor = /* @__PURE__ */ __name((cb) => onPostCtors.push(cb), "addOnPostCtor");
        var UTF8ToString = /* @__PURE__ */ __name((ptr, maxBytesToRead, ignoreNul) => {
          assert(typeof ptr == "number", `UTF8ToString expects a number (got ${typeof ptr})`);
          return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead, ignoreNul) : "";
        }, "UTF8ToString");
        var loadWebAssemblyModule = /* @__PURE__ */ __name((binary, flags, libName, localScope, handle) => {
          var metadata = getDylinkMetadata(binary);
          function loadModule() {
            var originalTable = wasmTable;
            var memAlign = Math.pow(2, metadata.memoryAlign);
            var memoryBase = metadata.memorySize ? alignMemory(getMemory(metadata.memorySize + memAlign), memAlign) : 0;
            var tableBase = metadata.tableSize ? wasmTable.length : 0;
            if (handle) {
              HEAP8[SAFE_HEAP_INDEX(HEAP8, handle + 8, "storing")] = 1;
              LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, handle + 12 >> 2, "storing") * 4, memoryBase);
              LE_HEAP_STORE_I32(SAFE_HEAP_INDEX(HEAP32, handle + 16 >> 2, "storing") * 4, metadata.memorySize);
              LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, handle + 20 >> 2, "storing") * 4, tableBase);
              LE_HEAP_STORE_I32(SAFE_HEAP_INDEX(HEAP32, handle + 24 >> 2, "storing") * 4, metadata.tableSize);
            }
            if (metadata.tableSize) {
              assert(wasmTable.length == tableBase, `unexpected table size while loading ${libName}: ${wasmTable.length}`);
              wasmTable.grow(metadata.tableSize);
            }
            var moduleExports;
            function resolveSymbol(sym) {
              var resolved = resolveGlobalSymbol(sym).sym;
              if (!resolved && localScope) {
                resolved = localScope[sym];
              }
              if (!resolved) {
                resolved = moduleExports[sym];
              }
              assert(resolved, `undefined symbol '${sym}'. perhaps a side module was not linked in? if this global was expected to arrive from a system library, try to build the MAIN_MODULE with EMCC_FORCE_STDLIBS=1 in the environment`);
              return resolved;
            }
            __name(resolveSymbol, "resolveSymbol");
            var proxyHandler = {
              get(stubs, prop) {
                switch (prop) {
                  case "__memory_base":
                    return memoryBase;
                  case "__table_base":
                    return tableBase;
                }
                if (prop in wasmImports && !wasmImports[prop].stub) {
                  var res = wasmImports[prop];
                  return res;
                }
                if (!(prop in stubs)) {
                  var resolved;
                  stubs[prop] = (...args2) => {
                    resolved ||= resolveSymbol(prop);
                    return resolved(...args2);
                  };
                }
                return stubs[prop];
              }
            };
            var proxy = new Proxy({}, proxyHandler);
            currentModuleWeakSymbols = metadata.weakImports;
            var info = {
              "GOT.mem": new Proxy({}, GOTHandler),
              "GOT.func": new Proxy({}, GOTHandler),
              "env": proxy,
              "wasi_snapshot_preview1": proxy
            };
            function postInstantiation(module, instance) {
              assert(wasmTable === originalTable);
              updateTableMap(tableBase, metadata.tableSize);
              moduleExports = relocateExports(instance.exports, memoryBase);
              if (!flags.allowUndefined) {
                reportUndefinedSymbols();
              }
              function addEmAsm(addr, body) {
                var args = [];
                var arity = 0;
                for (; arity < 16; arity++) {
                  if (body.indexOf("$" + arity) != -1) {
                    args.push("$" + arity);
                  } else {
                    break;
                  }
                }
                args = args.join(",");
                var func = `(${args}) => { ${body} };`;
                ASM_CONSTS[start] = eval(func);
              }
              __name(addEmAsm, "addEmAsm");
              if ("__start_em_asm" in moduleExports) {
                var start = moduleExports["__start_em_asm"];
                var stop = moduleExports["__stop_em_asm"];
                while (start < stop) {
                  var jsString = UTF8ToString(start);
                  addEmAsm(start, jsString);
                  start = HEAPU8.indexOf(0, start) + 1;
                }
              }
              function addEmJs(name, cSig, body) {
                var jsArgs = [];
                cSig = cSig.slice(1, -1);
                if (cSig != "void") {
                  cSig = cSig.split(",");
                  for (var i in cSig) {
                    var jsArg = cSig[i].split(" ").pop();
                    jsArgs.push(jsArg.replace("*", ""));
                  }
                }
                var func = `(${jsArgs}) => ${body};`;
                moduleExports[name] = eval(func);
              }
              __name(addEmJs, "addEmJs");
              for (var name in moduleExports) {
                if (name.startsWith("__em_js__")) {
                  var start = moduleExports[name];
                  var jsString = UTF8ToString(start);
                  var parts = jsString.split("<::>");
                  addEmJs(name.replace("__em_js__", ""), parts[0], parts[1]);
                  delete moduleExports[name];
                }
              }
              var applyRelocs = moduleExports["__wasm_apply_data_relocs"];
              if (applyRelocs) {
                if (runtimeInitialized) {
                  applyRelocs();
                } else {
                  __RELOC_FUNCS__.push(applyRelocs);
                }
              }
              var init = moduleExports["__wasm_call_ctors"];
              if (init) {
                if (runtimeInitialized) {
                  init();
                } else {
                  addOnPostCtor(init);
                }
              }
              return moduleExports;
            }
            __name(postInstantiation, "postInstantiation");
            if (flags.loadAsync) {
              return (async () => {
                var instance2;
                if (binary instanceof WebAssembly.Module) {
                  instance2 = new WebAssembly.Instance(binary, info);
                } else {
                  ({ module: binary, instance: instance2 } = await WebAssembly.instantiate(binary, info));
                }
                return postInstantiation(binary, instance2);
              })();
            }
            var module = binary instanceof WebAssembly.Module ? binary : new WebAssembly.Module(binary);
            var instance = new WebAssembly.Instance(module, info);
            return postInstantiation(module, instance);
          }
          __name(loadModule, "loadModule");
          flags = {
            ...flags,
            rpath: {
              parentLibPath: libName,
              paths: metadata.runtimePaths
            }
          };
          if (flags.loadAsync) {
            return metadata.neededDynlibs.reduce((chain, dynNeeded) => chain.then(() => loadDynamicLibrary(dynNeeded, flags, localScope)), Promise.resolve()).then(loadModule);
          }
          metadata.neededDynlibs.forEach((needed) => loadDynamicLibrary(needed, flags, localScope));
          return loadModule();
        }, "loadWebAssemblyModule");
        var mergeLibSymbols = /* @__PURE__ */ __name((exports2, libName2) => {
          for (var [sym, exp] of Object.entries(exports2)) {
            const setImport = /* @__PURE__ */ __name((target) => {
              if (!isSymbolDefined(target)) {
                wasmImports[target] = exp;
              }
            }, "setImport");
            setImport(sym);
            const main_alias = "__main_argc_argv";
            if (sym == "main") {
              setImport(main_alias);
            }
            if (sym == main_alias) {
              setImport("main");
            }
          }
        }, "mergeLibSymbols");
        var asyncLoad = /* @__PURE__ */ __name(async (url) => {
          var arrayBuffer = await readAsync(url);
          assert(arrayBuffer, `Loading data file "${url}" failed (no arrayBuffer).`);
          return new Uint8Array(arrayBuffer);
        }, "asyncLoad");
        function loadDynamicLibrary(libName2, flags2 = {
          global: true,
          nodelete: true
        }, localScope2, handle2) {
          var dso = LDSO.loadedLibsByName[libName2];
          if (dso) {
            assert(dso.exports !== "loading", `Attempt to load '${libName2}' twice before the first load completed`);
            if (!flags2.global) {
              if (localScope2) {
                Object.assign(localScope2, dso.exports);
              }
            } else if (!dso.global) {
              dso.global = true;
              mergeLibSymbols(dso.exports, libName2);
            }
            if (flags2.nodelete && dso.refcount !== Infinity) {
              dso.refcount = Infinity;
            }
            dso.refcount++;
            if (handle2) {
              LDSO.loadedLibsByHandle[handle2] = dso;
            }
            return flags2.loadAsync ? Promise.resolve(true) : true;
          }
          dso = newDSO(libName2, handle2, "loading");
          dso.refcount = flags2.nodelete ? Infinity : 1;
          dso.global = flags2.global;
          function loadLibData() {
            if (handle2) {
              var data = LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, handle2 + 28 >> 2, "loading") * 4);
              var dataSize = LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, handle2 + 32 >> 2, "loading") * 4);
              if (data && dataSize) {
                var libData = HEAP8.slice(data, data + dataSize);
                return flags2.loadAsync ? Promise.resolve(libData) : libData;
              }
            }
            var libFile = locateFile(libName2);
            if (flags2.loadAsync) {
              return asyncLoad(libFile);
            }
            if (!readBinary) {
              throw new Error(`${libFile}: file not found, and synchronous loading of external files is not available`);
            }
            return readBinary(libFile);
          }
          __name(loadLibData, "loadLibData");
          function getExports() {
            if (flags2.loadAsync) {
              return loadLibData().then((libData) => loadWebAssemblyModule(libData, flags2, libName2, localScope2, handle2));
            }
            return loadWebAssemblyModule(loadLibData(), flags2, libName2, localScope2, handle2);
          }
          __name(getExports, "getExports");
          function moduleLoaded(exports2) {
            if (dso.global) {
              mergeLibSymbols(exports2, libName2);
            } else if (localScope2) {
              Object.assign(localScope2, exports2);
            }
            dso.exports = exports2;
          }
          __name(moduleLoaded, "moduleLoaded");
          if (flags2.loadAsync) {
            return getExports().then((exports2) => {
              moduleLoaded(exports2);
              return true;
            });
          }
          moduleLoaded(getExports());
          return true;
        }
        __name(loadDynamicLibrary, "loadDynamicLibrary");
        var reportUndefinedSymbols = /* @__PURE__ */ __name(() => {
          for (var [symName, entry] of Object.entries(GOT)) {
            if (entry.value == 0) {
              var value = resolveGlobalSymbol(symName, true).sym;
              if (!value && !entry.required) {
                continue;
              }
              assert(value, `undefined symbol '${symName}'. perhaps a side module was not linked in? if this global was expected to arrive from a system library, try to build the MAIN_MODULE with EMCC_FORCE_STDLIBS=1 in the environment`);
              if (typeof value == "function") {
                entry.value = addFunction(value, value.sig);
              } else if (typeof value == "number") {
                entry.value = value;
              } else {
                throw new Error(`bad export type for '${symName}': ${typeof value}`);
              }
            }
          }
        }, "reportUndefinedSymbols");
        var runDependencies = 0;
        var dependenciesFulfilled = null;
        var runDependencyTracking = {};
        var runDependencyWatcher = null;
        var removeRunDependency = /* @__PURE__ */ __name((id) => {
          runDependencies--;
          Module["monitorRunDependencies"]?.(runDependencies);
          assert(id, "removeRunDependency requires an ID");
          assert(runDependencyTracking[id]);
          delete runDependencyTracking[id];
          if (runDependencies == 0) {
            if (runDependencyWatcher !== null) {
              clearInterval(runDependencyWatcher);
              runDependencyWatcher = null;
            }
            if (dependenciesFulfilled) {
              var callback = dependenciesFulfilled;
              dependenciesFulfilled = null;
              callback();
            }
          }
        }, "removeRunDependency");
        var addRunDependency = /* @__PURE__ */ __name((id) => {
          runDependencies++;
          Module["monitorRunDependencies"]?.(runDependencies);
          assert(id, "addRunDependency requires an ID");
          assert(!runDependencyTracking[id]);
          runDependencyTracking[id] = 1;
          if (runDependencyWatcher === null && typeof setInterval != "undefined") {
            runDependencyWatcher = setInterval(() => {
              if (ABORT) {
                clearInterval(runDependencyWatcher);
                runDependencyWatcher = null;
                return;
              }
              var shown = false;
              for (var dep in runDependencyTracking) {
                if (!shown) {
                  shown = true;
                  err("still waiting on run dependencies:");
                }
                err(`dependency: ${dep}`);
              }
              if (shown) {
                err("(end of list)");
              }
            }, 1e4);
            runDependencyWatcher.unref?.();
          }
        }, "addRunDependency");
        var loadDylibs = /* @__PURE__ */ __name(async () => {
          if (!dynamicLibraries.length) {
            reportUndefinedSymbols();
            return;
          }
          addRunDependency("loadDylibs");
          for (var lib of dynamicLibraries) {
            await loadDynamicLibrary(lib, {
              loadAsync: true,
              global: true,
              nodelete: true,
              allowUndefined: true
            });
          }
          reportUndefinedSymbols();
          removeRunDependency("loadDylibs");
        }, "loadDylibs");
        var noExitRuntime = true;
        var ptrToString = /* @__PURE__ */ __name((ptr) => {
          assert(typeof ptr === "number");
          ptr >>>= 0;
          return "0x" + ptr.toString(16).padStart(8, "0");
        }, "ptrToString");
        function setValue(ptr, value, type = "i8") {
          if (type.endsWith("*")) type = "*";
          switch (type) {
            case "i1":
              HEAP8[SAFE_HEAP_INDEX(HEAP8, ptr, "storing")] = value;
              break;
            case "i8":
              HEAP8[SAFE_HEAP_INDEX(HEAP8, ptr, "storing")] = value;
              break;
            case "i16":
              LE_HEAP_STORE_I16(SAFE_HEAP_INDEX(HEAP16, ptr >> 1, "storing") * 2, value);
              break;
            case "i32":
              LE_HEAP_STORE_I32(SAFE_HEAP_INDEX(HEAP32, ptr >> 2, "storing") * 4, value);
              break;
            case "i64":
              LE_HEAP_STORE_I64(SAFE_HEAP_INDEX(HEAP64, ptr >> 3, "storing") * 8, BigInt(value));
              break;
            case "float":
              LE_HEAP_STORE_F32(SAFE_HEAP_INDEX(HEAPF32, ptr >> 2, "storing") * 4, value);
              break;
            case "double":
              LE_HEAP_STORE_F64(SAFE_HEAP_INDEX(HEAPF64, ptr >> 3, "storing") * 8, value);
              break;
            case "*":
              LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, ptr >> 2, "storing") * 4, value);
              break;
            default:
              abort(`invalid type for setValue: ${type}`);
          }
        }
        __name(setValue, "setValue");
        var ___memory_base = new WebAssembly.Global({
          "value": "i32",
          "mutable": false
        }, 1024);
        var ___stack_high = 82240;
        var ___stack_low = 16704;
        var ___stack_pointer = new WebAssembly.Global({
          "value": "i32",
          "mutable": true
        }, 82240);
        var ___table_base = new WebAssembly.Global({
          "value": "i32",
          "mutable": false
        }, 1);
        var __abort_js = /* @__PURE__ */ __name(() => abort("native code called abort()"), "__abort_js");
        __abort_js.sig = "v";
        var getHeapMax = /* @__PURE__ */ __name(() => (
          // Stay one Wasm page short of 4GB: while e.g. Chrome is able to allocate
          // full 4GB Wasm memories, the size will wrap back to 0 bytes in Wasm side
          // for any code that deals with heap sizes, which would require special
          // casing all heap size related code to treat 0 specially.
          2147483648
        ), "getHeapMax");
        var growMemory = /* @__PURE__ */ __name((size) => {
          var oldHeapSize = wasmMemory.buffer.byteLength;
          var pages = (size - oldHeapSize + 65535) / 65536 | 0;
          try {
            wasmMemory.grow(pages);
            updateMemoryViews();
            return 1;
          } catch (e) {
            err(`growMemory: Attempted to grow heap from ${oldHeapSize} bytes to ${size} bytes, but got error: ${e}`);
          }
        }, "growMemory");
        var _emscripten_resize_heap = /* @__PURE__ */ __name((requestedSize) => {
          var oldSize = HEAPU8.length;
          requestedSize >>>= 0;
          assert(requestedSize > oldSize);
          var maxHeapSize = getHeapMax();
          if (requestedSize > maxHeapSize) {
            err(`Cannot enlarge memory, requested ${requestedSize} bytes, but the limit is ${maxHeapSize} bytes!`);
            return false;
          }
          for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
            var overGrownHeapSize = oldSize * (1 + 0.2 / cutDown);
            overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
            var newSize = Math.min(maxHeapSize, alignMemory(Math.max(requestedSize, overGrownHeapSize), 65536));
            var replacement = growMemory(newSize);
            if (replacement) {
              return true;
            }
          }
          err(`Failed to grow the heap from ${oldSize} bytes to ${newSize} bytes, not enough memory!`);
          return false;
        }, "_emscripten_resize_heap");
        _emscripten_resize_heap.sig = "ip";
        var SYSCALLS = {
          varargs: void 0,
          getStr(ptr) {
            var ret = UTF8ToString(ptr);
            return ret;
          }
        };
        var _fd_close = /* @__PURE__ */ __name((fd) => {
          abort("fd_close called without SYSCALLS_REQUIRE_FILESYSTEM");
        }, "_fd_close");
        _fd_close.sig = "ii";
        var INT53_MAX = 9007199254740992;
        var INT53_MIN = -9007199254740992;
        var bigintToI53Checked = /* @__PURE__ */ __name((num) => num < INT53_MIN || num > INT53_MAX ? NaN : Number(num), "bigintToI53Checked");
        function _fd_seek(fd, offset, whence, newOffset) {
          offset = bigintToI53Checked(offset);
          return 70;
        }
        __name(_fd_seek, "_fd_seek");
        _fd_seek.sig = "iijip";
        var printCharBuffers = [null, [], []];
        var printChar = /* @__PURE__ */ __name((stream, curr) => {
          var buffer = printCharBuffers[stream];
          assert(buffer);
          if (curr === 0 || curr === 10) {
            (stream === 1 ? out : err)(UTF8ArrayToString(buffer));
            buffer.length = 0;
          } else {
            buffer.push(curr);
          }
        }, "printChar");
        var flush_NO_FILESYSTEM = /* @__PURE__ */ __name(() => {
          _fflush(0);
          if (printCharBuffers[1].length) printChar(1, 10);
          if (printCharBuffers[2].length) printChar(2, 10);
        }, "flush_NO_FILESYSTEM");
        var _fd_write = /* @__PURE__ */ __name((fd, iov, iovcnt, pnum) => {
          var num = 0;
          for (var i2 = 0; i2 < iovcnt; i2++) {
            var ptr = LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, iov >> 2, "loading") * 4);
            var len = LE_HEAP_LOAD_U32(SAFE_HEAP_INDEX(HEAPU32, iov + 4 >> 2, "loading") * 4);
            iov += 8;
            for (var j = 0; j < len; j++) {
              printChar(fd, HEAPU8[SAFE_HEAP_INDEX(HEAPU8, ptr + j, "loading")]);
            }
            num += len;
          }
          LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, pnum >> 2, "storing") * 4, num);
          return 0;
        }, "_fd_write");
        _fd_write.sig = "iippp";
        function _tree_sitter_log_callback(isLexMessage, messageAddress) {
          if (Module.currentLogCallback) {
            const message = UTF8ToString(messageAddress);
            Module.currentLogCallback(message, isLexMessage !== 0);
          }
        }
        __name(_tree_sitter_log_callback, "_tree_sitter_log_callback");
        function _tree_sitter_parse_callback(inputBufferAddress, index, row, column, lengthAddress) {
          const INPUT_BUFFER_SIZE = 10 * 1024;
          const string = Module.currentParseCallback(index, {
            row,
            column
          });
          if (typeof string === "string") {
            setValue(lengthAddress, string.length, "i32");
            stringToUTF16(string, inputBufferAddress, INPUT_BUFFER_SIZE);
          } else {
            setValue(lengthAddress, 0, "i32");
          }
        }
        __name(_tree_sitter_parse_callback, "_tree_sitter_parse_callback");
        function _tree_sitter_progress_callback(currentOffset, hasError) {
          if (Module.currentProgressCallback) {
            return Module.currentProgressCallback({
              currentOffset,
              hasError
            });
          }
          return false;
        }
        __name(_tree_sitter_progress_callback, "_tree_sitter_progress_callback");
        function _tree_sitter_query_progress_callback(currentOffset) {
          if (Module.currentQueryProgressCallback) {
            return Module.currentQueryProgressCallback({
              currentOffset
            });
          }
          return false;
        }
        __name(_tree_sitter_query_progress_callback, "_tree_sitter_query_progress_callback");
        var runtimeKeepaliveCounter = 0;
        var keepRuntimeAlive = /* @__PURE__ */ __name(() => noExitRuntime || runtimeKeepaliveCounter > 0, "keepRuntimeAlive");
        var _proc_exit = /* @__PURE__ */ __name((code) => {
          EXITSTATUS = code;
          if (!keepRuntimeAlive()) {
            Module["onExit"]?.(code);
            ABORT = true;
          }
          quit_(code, new ExitStatus(code));
        }, "_proc_exit");
        _proc_exit.sig = "vi";
        var exitJS = /* @__PURE__ */ __name((status, implicit) => {
          EXITSTATUS = status;
          checkUnflushedContent();
          if (keepRuntimeAlive() && !implicit) {
            var msg = `program exited (with status: ${status}), but keepRuntimeAlive() is set (counter=${runtimeKeepaliveCounter}) due to an async operation, so halting execution but not exiting the runtime or preventing further async execution (you can use emscripten_force_exit, if you want to force a true shutdown)`;
            readyPromiseReject?.(msg);
            err(msg);
          }
          _proc_exit(status);
        }, "exitJS");
        var handleException = /* @__PURE__ */ __name((e) => {
          if (e instanceof ExitStatus || e == "unwind") {
            return EXITSTATUS;
          }
          checkStackCookie();
          if (e instanceof WebAssembly.RuntimeError) {
            if (_emscripten_stack_get_current() <= 0) {
              err("Stack overflow detected.  You can try increasing -sSTACK_SIZE (currently set to 65536)");
            }
          }
          quit_(1, e);
        }, "handleException");
        var lengthBytesUTF8 = /* @__PURE__ */ __name((str) => {
          var len = 0;
          for (var i2 = 0; i2 < str.length; ++i2) {
            var c = str.charCodeAt(i2);
            if (c <= 127) {
              len++;
            } else if (c <= 2047) {
              len += 2;
            } else if (c >= 55296 && c <= 57343) {
              len += 4;
              ++i2;
            } else {
              len += 3;
            }
          }
          return len;
        }, "lengthBytesUTF8");
        var stringToUTF8Array = /* @__PURE__ */ __name((str, heap, outIdx, maxBytesToWrite) => {
          assert(typeof str === "string", `stringToUTF8Array expects a string (got ${typeof str})`);
          if (!(maxBytesToWrite > 0)) return 0;
          var startIdx = outIdx;
          var endIdx = outIdx + maxBytesToWrite - 1;
          for (var i2 = 0; i2 < str.length; ++i2) {
            var u = str.codePointAt(i2);
            if (u <= 127) {
              if (outIdx >= endIdx) break;
              heap[outIdx++] = u;
            } else if (u <= 2047) {
              if (outIdx + 1 >= endIdx) break;
              heap[outIdx++] = 192 | u >> 6;
              heap[outIdx++] = 128 | u & 63;
            } else if (u <= 65535) {
              if (outIdx + 2 >= endIdx) break;
              heap[outIdx++] = 224 | u >> 12;
              heap[outIdx++] = 128 | u >> 6 & 63;
              heap[outIdx++] = 128 | u & 63;
            } else {
              if (outIdx + 3 >= endIdx) break;
              if (u > 1114111) warnOnce("Invalid Unicode code point " + ptrToString(u) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
              heap[outIdx++] = 240 | u >> 18;
              heap[outIdx++] = 128 | u >> 12 & 63;
              heap[outIdx++] = 128 | u >> 6 & 63;
              heap[outIdx++] = 128 | u & 63;
              i2++;
            }
          }
          heap[outIdx] = 0;
          return outIdx - startIdx;
        }, "stringToUTF8Array");
        var stringToUTF8 = /* @__PURE__ */ __name((str, outPtr, maxBytesToWrite) => {
          assert(typeof maxBytesToWrite == "number", "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
          return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
        }, "stringToUTF8");
        var stackAlloc = /* @__PURE__ */ __name((sz) => __emscripten_stack_alloc(sz), "stackAlloc");
        var stringToUTF8OnStack = /* @__PURE__ */ __name((str) => {
          var size = lengthBytesUTF8(str) + 1;
          var ret = stackAlloc(size);
          stringToUTF8(str, ret, size);
          return ret;
        }, "stringToUTF8OnStack");
        var AsciiToString = /* @__PURE__ */ __name((ptr) => {
          var str = "";
          while (1) {
            var ch = HEAPU8[SAFE_HEAP_INDEX(HEAPU8, ptr++, "loading")];
            if (!ch) return str;
            str += String.fromCharCode(ch);
          }
        }, "AsciiToString");
        var stringToUTF16 = /* @__PURE__ */ __name((str, outPtr, maxBytesToWrite) => {
          assert(outPtr % 2 == 0, "Pointer passed to stringToUTF16 must be aligned to two bytes!");
          assert(typeof maxBytesToWrite == "number", "stringToUTF16(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
          maxBytesToWrite ??= 2147483647;
          if (maxBytesToWrite < 2) return 0;
          maxBytesToWrite -= 2;
          var startPtr = outPtr;
          var numCharsToWrite = maxBytesToWrite < str.length * 2 ? maxBytesToWrite / 2 : str.length;
          for (var i2 = 0; i2 < numCharsToWrite; ++i2) {
            var codeUnit = str.charCodeAt(i2);
            LE_HEAP_STORE_I16(SAFE_HEAP_INDEX(HEAP16, outPtr >> 1, "storing") * 2, codeUnit);
            outPtr += 2;
          }
          LE_HEAP_STORE_I16(SAFE_HEAP_INDEX(HEAP16, outPtr >> 1, "storing") * 2, 0);
          return outPtr - startPtr;
        }, "stringToUTF16");
        LE_ATOMICS_NATIVE_BYTE_ORDER = new Int8Array(new Int16Array([1]).buffer)[0] === 1 ? [
          /* little endian */
          ((x) => x),
          ((x) => x),
          void 0,
          ((x) => x)
        ] : [
          /* big endian */
          ((x) => x),
          ((x) => ((x & 65280) << 8 | (x & 255) << 24) >> 16),
          void 0,
          ((x) => x >> 24 & 255 | x >> 8 & 65280 | (x & 65280) << 8 | (x & 255) << 24)
        ];
        function LE_HEAP_UPDATE() {
          HEAPU16.unsigned = ((x) => x & 65535);
          HEAPU32.unsigned = ((x) => x >>> 0);
        }
        __name(LE_HEAP_UPDATE, "LE_HEAP_UPDATE");
        {
          initMemory();
          if (Module["noExitRuntime"]) noExitRuntime = Module["noExitRuntime"];
          if (Module["print"]) out = Module["print"];
          if (Module["printErr"]) err = Module["printErr"];
          if (Module["dynamicLibraries"]) dynamicLibraries = Module["dynamicLibraries"];
          if (Module["wasmBinary"]) wasmBinary = Module["wasmBinary"];
          Module["FS_createDataFile"] = FS.createDataFile;
          Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
          checkIncomingModuleAPI();
          if (Module["arguments"]) arguments_ = Module["arguments"];
          if (Module["thisProgram"]) thisProgram = Module["thisProgram"];
          assert(typeof Module["memoryInitializerPrefixURL"] == "undefined", "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
          assert(typeof Module["pthreadMainPrefixURL"] == "undefined", "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
          assert(typeof Module["cdInitializerPrefixURL"] == "undefined", "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
          assert(typeof Module["filePackagePrefixURL"] == "undefined", "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
          assert(typeof Module["read"] == "undefined", "Module.read option was removed");
          assert(typeof Module["readAsync"] == "undefined", "Module.readAsync option was removed (modify readAsync in JS)");
          assert(typeof Module["readBinary"] == "undefined", "Module.readBinary option was removed (modify readBinary in JS)");
          assert(typeof Module["setWindowTitle"] == "undefined", "Module.setWindowTitle option was removed (modify emscripten_set_window_title in JS)");
          assert(typeof Module["TOTAL_MEMORY"] == "undefined", "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
          assert(typeof Module["ENVIRONMENT"] == "undefined", "Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)");
          assert(typeof Module["STACK_SIZE"] == "undefined", "STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time");
          if (Module["preInit"]) {
            if (typeof Module["preInit"] == "function") Module["preInit"] = [Module["preInit"]];
            while (Module["preInit"].length > 0) {
              Module["preInit"].shift()();
            }
          }
          consumedModuleProp("preInit");
        }
        Module["setValue"] = setValue;
        Module["getValue"] = getValue;
        Module["UTF8ToString"] = UTF8ToString;
        Module["stringToUTF8"] = stringToUTF8;
        Module["lengthBytesUTF8"] = lengthBytesUTF8;
        Module["AsciiToString"] = AsciiToString;
        Module["stringToUTF16"] = stringToUTF16;
        Module["loadWebAssemblyModule"] = loadWebAssemblyModule;
        Module["LE_HEAP_STORE_I64"] = LE_HEAP_STORE_I64;
        var missingLibrarySymbols = ["writeI53ToI64", "writeI53ToI64Clamped", "writeI53ToI64Signaling", "writeI53ToU64Clamped", "writeI53ToU64Signaling", "readI53FromI64", "readI53FromU64", "convertI32PairToI53", "convertI32PairToI53Checked", "convertU32PairToI53", "getTempRet0", "setTempRet0", "zeroMemory", "withStackSave", "strError", "inetPton4", "inetNtop4", "inetPton6", "inetNtop6", "readSockaddr", "writeSockaddr", "readEmAsmArgs", "runEmAsmFunction", "runMainThreadEmAsm", "jstoi_q", "getExecutableName", "autoResumeAudioContext", "getDynCaller", "runtimeKeepalivePush", "runtimeKeepalivePop", "callUserCallback", "maybeExit", "asmjsMangle", "mmapAlloc", "HandleAllocator", "getNativeTypeSize", "getUniqueRunDependency", "addOnInit", "addOnPreMain", "addOnExit", "STACK_SIZE", "STACK_ALIGN", "POINTER_SIZE", "ASSERTIONS", "ccall", "cwrap", "removeFunction", "intArrayFromString", "intArrayToString", "stringToAscii", "UTF16ToString", "lengthBytesUTF16", "UTF32ToString", "stringToUTF32", "lengthBytesUTF32", "stringToNewUTF8", "writeArrayToMemory", "registerKeyEventCallback", "maybeCStringToJsString", "findEventTarget", "getBoundingClientRect", "fillMouseEventData", "registerMouseEventCallback", "registerWheelEventCallback", "registerUiEventCallback", "registerFocusEventCallback", "fillDeviceOrientationEventData", "registerDeviceOrientationEventCallback", "fillDeviceMotionEventData", "registerDeviceMotionEventCallback", "screenOrientation", "fillOrientationChangeEventData", "registerOrientationChangeEventCallback", "fillFullscreenChangeEventData", "registerFullscreenChangeEventCallback", "JSEvents_requestFullscreen", "JSEvents_resizeCanvasForFullscreen", "registerRestoreOldStyle", "hideEverythingExceptGivenElement", "restoreHiddenElements", "setLetterbox", "softFullscreenResizeWebGLRenderTarget", "doRequestFullscreen", "fillPointerlockChangeEventData", "registerPointerlockChangeEventCallback", "registerPointerlockErrorEventCallback", "requestPointerLock", "fillVisibilityChangeEventData", "registerVisibilityChangeEventCallback", "registerTouchEventCallback", "fillGamepadEventData", "registerGamepadEventCallback", "registerBeforeUnloadEventCallback", "fillBatteryEventData", "registerBatteryEventCallback", "setCanvasElementSize", "getCanvasElementSize", "jsStackTrace", "getCallstack", "convertPCtoSourceLocation", "getEnvStrings", "checkWasiClock", "wasiRightsToMuslOFlags", "wasiOFlagsToMuslOFlags", "initRandomFill", "randomFill", "safeSetTimeout", "setImmediateWrapped", "safeRequestAnimationFrame", "clearImmediateWrapped", "registerPostMainLoop", "registerPreMainLoop", "getPromise", "makePromise", "idsToPromises", "makePromiseCallback", "Browser_asyncPrepareDataCounter", "isLeapYear", "ydayFromDate", "arraySum", "addDays", "getSocketFromFD", "getSocketAddress", "dlopenInternal", "heapObjectForWebGLType", "toTypedArrayIndex", "webgl_enable_ANGLE_instanced_arrays", "webgl_enable_OES_vertex_array_object", "webgl_enable_WEBGL_draw_buffers", "webgl_enable_WEBGL_multi_draw", "webgl_enable_EXT_polygon_offset_clamp", "webgl_enable_EXT_clip_control", "webgl_enable_WEBGL_polygon_mode", "emscriptenWebGLGet", "computeUnpackAlignedImageSize", "colorChannelsInGlTextureFormat", "emscriptenWebGLGetTexPixelData", "emscriptenWebGLGetUniform", "webglGetUniformLocation", "webglPrepareUniformLocationsBeforeFirstUse", "webglGetLeftBracePos", "emscriptenWebGLGetVertexAttrib", "__glGetActiveAttribOrUniform", "writeGLArray", "registerWebGlEventCallback", "runAndAbortIfError", "ALLOC_NORMAL", "ALLOC_STACK", "allocate", "writeStringToMemory", "writeAsciiToMemory", "demangle", "stackTrace"];
        missingLibrarySymbols.forEach(missingLibrarySymbol);
        var unexportedSymbols = ["run", "out", "err", "callMain", "abort", "wasmMemory", "wasmExports", "writeStackCookie", "checkStackCookie", "INT53_MAX", "INT53_MIN", "bigintToI53Checked", "stackSave", "stackRestore", "stackAlloc", "ptrToString", "exitJS", "getHeapMax", "growMemory", "ENV", "ERRNO_CODES", "DNS", "Protocols", "Sockets", "timers", "warnOnce", "readEmAsmArgsArray", "dynCall", "handleException", "keepRuntimeAlive", "asyncLoad", "alignMemory", "wasmTable", "noExitRuntime", "addRunDependency", "removeRunDependency", "addOnPreRun", "addOnPostCtor", "addOnPostRun", "convertJsFunctionToWasm", "freeTableIndexes", "functionsInTableMap", "getEmptyTableSlot", "updateTableMap", "getFunctionAddress", "addFunction", "PATH", "PATH_FS", "UTF8Decoder", "UTF8ArrayToString", "stringToUTF8Array", "UTF16Decoder", "stringToUTF8OnStack", "JSEvents", "specialHTMLTargets", "findCanvasEventTarget", "currentFullscreenStrategy", "restoreOldWindowedStyle", "UNWIND_CACHE", "ExitStatus", "flush_NO_FILESYSTEM", "emSetImmediate", "emClearImmediate_deps", "emClearImmediate", "promiseMap", "Browser", "requestFullscreen", "requestFullScreen", "setCanvasSize", "getUserMedia", "createContext", "getPreloadedImageData__data", "wget", "MONTH_DAYS_REGULAR", "MONTH_DAYS_LEAP", "MONTH_DAYS_REGULAR_CUMULATIVE", "MONTH_DAYS_LEAP_CUMULATIVE", "SYSCALLS", "isSymbolDefined", "GOT", "currentModuleWeakSymbols", "LDSO", "getMemory", "mergeLibSymbols", "newDSO", "loadDynamicLibrary", "tempFixedLengthArray", "miniTempWebGLFloatBuffers", "miniTempWebGLIntBuffers", "GL", "AL", "GLUT", "EGL", "GLEW", "IDBStore", "SDL", "SDL_gfx", "allocateUTF8", "allocateUTF8OnStack", "print", "printErr", "jstoi_s", "LE_HEAP_STORE_U16", "LE_HEAP_STORE_I16", "LE_HEAP_STORE_U32", "LE_HEAP_STORE_I32", "LE_HEAP_STORE_U64", "LE_HEAP_STORE_F32", "LE_HEAP_STORE_F64", "LE_HEAP_LOAD_U16", "LE_HEAP_LOAD_I16", "LE_HEAP_LOAD_U32", "LE_HEAP_LOAD_I32", "LE_HEAP_LOAD_U64", "LE_HEAP_LOAD_I64", "LE_HEAP_LOAD_F32", "LE_HEAP_LOAD_F64", "LE_ATOMICS_NATIVE_BYTE_ORDER", "LE_ATOMICS_ADD", "LE_ATOMICS_AND", "LE_ATOMICS_COMPAREEXCHANGE", "LE_ATOMICS_EXCHANGE", "LE_ATOMICS_ISLOCKFREE", "LE_ATOMICS_LOAD", "LE_ATOMICS_NOTIFY", "LE_ATOMICS_OR", "LE_ATOMICS_STORE", "LE_ATOMICS_SUB", "LE_ATOMICS_WAIT", "LE_ATOMICS_WAITASYNC", "LE_ATOMICS_XOR"];
        unexportedSymbols.forEach(unexportedRuntimeSymbol);
        function checkIncomingModuleAPI() {
          ignoredModuleProp("fetchSettings");
        }
        __name(checkIncomingModuleAPI, "checkIncomingModuleAPI");
        var ASM_CONSTS = {};
        var _malloc = Module["_malloc"] = makeInvalidEarlyAccess("_malloc");
        var _calloc = Module["_calloc"] = makeInvalidEarlyAccess("_calloc");
        var _realloc = Module["_realloc"] = makeInvalidEarlyAccess("_realloc");
        var _free = Module["_free"] = makeInvalidEarlyAccess("_free");
        var _ts_range_edit = Module["_ts_range_edit"] = makeInvalidEarlyAccess("_ts_range_edit");
        var _ts_language_symbol_count = Module["_ts_language_symbol_count"] = makeInvalidEarlyAccess("_ts_language_symbol_count");
        var _ts_language_state_count = Module["_ts_language_state_count"] = makeInvalidEarlyAccess("_ts_language_state_count");
        var _ts_language_abi_version = Module["_ts_language_abi_version"] = makeInvalidEarlyAccess("_ts_language_abi_version");
        var _ts_language_name = Module["_ts_language_name"] = makeInvalidEarlyAccess("_ts_language_name");
        var _ts_language_field_count = Module["_ts_language_field_count"] = makeInvalidEarlyAccess("_ts_language_field_count");
        var _ts_language_next_state = Module["_ts_language_next_state"] = makeInvalidEarlyAccess("_ts_language_next_state");
        var _ts_language_symbol_name = Module["_ts_language_symbol_name"] = makeInvalidEarlyAccess("_ts_language_symbol_name");
        var _ts_language_symbol_for_name = Module["_ts_language_symbol_for_name"] = makeInvalidEarlyAccess("_ts_language_symbol_for_name");
        var _strncmp = Module["_strncmp"] = makeInvalidEarlyAccess("_strncmp");
        var _ts_language_symbol_type = Module["_ts_language_symbol_type"] = makeInvalidEarlyAccess("_ts_language_symbol_type");
        var _ts_language_field_name_for_id = Module["_ts_language_field_name_for_id"] = makeInvalidEarlyAccess("_ts_language_field_name_for_id");
        var _ts_lookahead_iterator_new = Module["_ts_lookahead_iterator_new"] = makeInvalidEarlyAccess("_ts_lookahead_iterator_new");
        var _ts_lookahead_iterator_delete = Module["_ts_lookahead_iterator_delete"] = makeInvalidEarlyAccess("_ts_lookahead_iterator_delete");
        var _ts_lookahead_iterator_reset_state = Module["_ts_lookahead_iterator_reset_state"] = makeInvalidEarlyAccess("_ts_lookahead_iterator_reset_state");
        var _ts_lookahead_iterator_reset = Module["_ts_lookahead_iterator_reset"] = makeInvalidEarlyAccess("_ts_lookahead_iterator_reset");
        var _ts_lookahead_iterator_next = Module["_ts_lookahead_iterator_next"] = makeInvalidEarlyAccess("_ts_lookahead_iterator_next");
        var _ts_lookahead_iterator_current_symbol = Module["_ts_lookahead_iterator_current_symbol"] = makeInvalidEarlyAccess("_ts_lookahead_iterator_current_symbol");
        var _ts_point_edit = Module["_ts_point_edit"] = makeInvalidEarlyAccess("_ts_point_edit");
        var _ts_parser_delete = Module["_ts_parser_delete"] = makeInvalidEarlyAccess("_ts_parser_delete");
        var _ts_parser_set_language = Module["_ts_parser_set_language"] = makeInvalidEarlyAccess("_ts_parser_set_language");
        var _ts_parser_reset = Module["_ts_parser_reset"] = makeInvalidEarlyAccess("_ts_parser_reset");
        var _ts_parser_set_included_ranges = Module["_ts_parser_set_included_ranges"] = makeInvalidEarlyAccess("_ts_parser_set_included_ranges");
        var _ts_query_new = Module["_ts_query_new"] = makeInvalidEarlyAccess("_ts_query_new");
        var _ts_query_delete = Module["_ts_query_delete"] = makeInvalidEarlyAccess("_ts_query_delete");
        var _iswspace = Module["_iswspace"] = makeInvalidEarlyAccess("_iswspace");
        var _ts_query_copy = Module["_ts_query_copy"] = makeInvalidEarlyAccess("_ts_query_copy");
        var _ts_query_pattern_count = Module["_ts_query_pattern_count"] = makeInvalidEarlyAccess("_ts_query_pattern_count");
        var _ts_query_capture_count = Module["_ts_query_capture_count"] = makeInvalidEarlyAccess("_ts_query_capture_count");
        var _ts_query_string_count = Module["_ts_query_string_count"] = makeInvalidEarlyAccess("_ts_query_string_count");
        var _ts_query_capture_name_for_id = Module["_ts_query_capture_name_for_id"] = makeInvalidEarlyAccess("_ts_query_capture_name_for_id");
        var _ts_query_capture_quantifier_for_id = Module["_ts_query_capture_quantifier_for_id"] = makeInvalidEarlyAccess("_ts_query_capture_quantifier_for_id");
        var _ts_query_string_value_for_id = Module["_ts_query_string_value_for_id"] = makeInvalidEarlyAccess("_ts_query_string_value_for_id");
        var _ts_query_predicates_for_pattern = Module["_ts_query_predicates_for_pattern"] = makeInvalidEarlyAccess("_ts_query_predicates_for_pattern");
        var _ts_query_start_byte_for_pattern = Module["_ts_query_start_byte_for_pattern"] = makeInvalidEarlyAccess("_ts_query_start_byte_for_pattern");
        var _ts_query_end_byte_for_pattern = Module["_ts_query_end_byte_for_pattern"] = makeInvalidEarlyAccess("_ts_query_end_byte_for_pattern");
        var _ts_query_is_pattern_rooted = Module["_ts_query_is_pattern_rooted"] = makeInvalidEarlyAccess("_ts_query_is_pattern_rooted");
        var _ts_query_is_pattern_non_local = Module["_ts_query_is_pattern_non_local"] = makeInvalidEarlyAccess("_ts_query_is_pattern_non_local");
        var _ts_query_is_pattern_guaranteed_at_step = Module["_ts_query_is_pattern_guaranteed_at_step"] = makeInvalidEarlyAccess("_ts_query_is_pattern_guaranteed_at_step");
        var _ts_query_disable_capture = Module["_ts_query_disable_capture"] = makeInvalidEarlyAccess("_ts_query_disable_capture");
        var _ts_query_disable_pattern = Module["_ts_query_disable_pattern"] = makeInvalidEarlyAccess("_ts_query_disable_pattern");
        var _memcmp = Module["_memcmp"] = makeInvalidEarlyAccess("_memcmp");
        var _ts_tree_copy = Module["_ts_tree_copy"] = makeInvalidEarlyAccess("_ts_tree_copy");
        var _ts_tree_delete = Module["_ts_tree_delete"] = makeInvalidEarlyAccess("_ts_tree_delete");
        var _iswalnum = Module["_iswalnum"] = makeInvalidEarlyAccess("_iswalnum");
        var _ts_init = Module["_ts_init"] = makeInvalidEarlyAccess("_ts_init");
        var _ts_parser_new_wasm = Module["_ts_parser_new_wasm"] = makeInvalidEarlyAccess("_ts_parser_new_wasm");
        var _ts_parser_enable_logger_wasm = Module["_ts_parser_enable_logger_wasm"] = makeInvalidEarlyAccess("_ts_parser_enable_logger_wasm");
        var _ts_parser_parse_wasm = Module["_ts_parser_parse_wasm"] = makeInvalidEarlyAccess("_ts_parser_parse_wasm");
        var _ts_parser_included_ranges_wasm = Module["_ts_parser_included_ranges_wasm"] = makeInvalidEarlyAccess("_ts_parser_included_ranges_wasm");
        var _ts_language_type_is_named_wasm = Module["_ts_language_type_is_named_wasm"] = makeInvalidEarlyAccess("_ts_language_type_is_named_wasm");
        var _ts_language_type_is_visible_wasm = Module["_ts_language_type_is_visible_wasm"] = makeInvalidEarlyAccess("_ts_language_type_is_visible_wasm");
        var _ts_language_metadata_wasm = Module["_ts_language_metadata_wasm"] = makeInvalidEarlyAccess("_ts_language_metadata_wasm");
        var _ts_language_supertypes_wasm = Module["_ts_language_supertypes_wasm"] = makeInvalidEarlyAccess("_ts_language_supertypes_wasm");
        var _ts_language_subtypes_wasm = Module["_ts_language_subtypes_wasm"] = makeInvalidEarlyAccess("_ts_language_subtypes_wasm");
        var _ts_tree_root_node_wasm = Module["_ts_tree_root_node_wasm"] = makeInvalidEarlyAccess("_ts_tree_root_node_wasm");
        var _ts_tree_root_node_with_offset_wasm = Module["_ts_tree_root_node_with_offset_wasm"] = makeInvalidEarlyAccess("_ts_tree_root_node_with_offset_wasm");
        var _ts_tree_edit_wasm = Module["_ts_tree_edit_wasm"] = makeInvalidEarlyAccess("_ts_tree_edit_wasm");
        var _ts_tree_included_ranges_wasm = Module["_ts_tree_included_ranges_wasm"] = makeInvalidEarlyAccess("_ts_tree_included_ranges_wasm");
        var _ts_tree_get_changed_ranges_wasm = Module["_ts_tree_get_changed_ranges_wasm"] = makeInvalidEarlyAccess("_ts_tree_get_changed_ranges_wasm");
        var _ts_tree_cursor_new_wasm = Module["_ts_tree_cursor_new_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_new_wasm");
        var _ts_tree_cursor_copy_wasm = Module["_ts_tree_cursor_copy_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_copy_wasm");
        var _ts_tree_cursor_delete_wasm = Module["_ts_tree_cursor_delete_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_delete_wasm");
        var _ts_tree_cursor_reset_wasm = Module["_ts_tree_cursor_reset_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_reset_wasm");
        var _ts_tree_cursor_reset_to_wasm = Module["_ts_tree_cursor_reset_to_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_reset_to_wasm");
        var _ts_tree_cursor_goto_first_child_wasm = Module["_ts_tree_cursor_goto_first_child_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_first_child_wasm");
        var _ts_tree_cursor_goto_last_child_wasm = Module["_ts_tree_cursor_goto_last_child_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_last_child_wasm");
        var _ts_tree_cursor_goto_first_child_for_index_wasm = Module["_ts_tree_cursor_goto_first_child_for_index_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_first_child_for_index_wasm");
        var _ts_tree_cursor_goto_first_child_for_position_wasm = Module["_ts_tree_cursor_goto_first_child_for_position_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_first_child_for_position_wasm");
        var _ts_tree_cursor_goto_next_sibling_wasm = Module["_ts_tree_cursor_goto_next_sibling_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_next_sibling_wasm");
        var _ts_tree_cursor_goto_previous_sibling_wasm = Module["_ts_tree_cursor_goto_previous_sibling_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_previous_sibling_wasm");
        var _ts_tree_cursor_goto_descendant_wasm = Module["_ts_tree_cursor_goto_descendant_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_descendant_wasm");
        var _ts_tree_cursor_goto_parent_wasm = Module["_ts_tree_cursor_goto_parent_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_goto_parent_wasm");
        var _ts_tree_cursor_current_node_type_id_wasm = Module["_ts_tree_cursor_current_node_type_id_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_node_type_id_wasm");
        var _ts_tree_cursor_current_node_state_id_wasm = Module["_ts_tree_cursor_current_node_state_id_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_node_state_id_wasm");
        var _ts_tree_cursor_current_node_is_named_wasm = Module["_ts_tree_cursor_current_node_is_named_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_node_is_named_wasm");
        var _ts_tree_cursor_current_node_is_missing_wasm = Module["_ts_tree_cursor_current_node_is_missing_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_node_is_missing_wasm");
        var _ts_tree_cursor_current_node_id_wasm = Module["_ts_tree_cursor_current_node_id_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_node_id_wasm");
        var _ts_tree_cursor_start_position_wasm = Module["_ts_tree_cursor_start_position_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_start_position_wasm");
        var _ts_tree_cursor_end_position_wasm = Module["_ts_tree_cursor_end_position_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_end_position_wasm");
        var _ts_tree_cursor_start_index_wasm = Module["_ts_tree_cursor_start_index_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_start_index_wasm");
        var _ts_tree_cursor_end_index_wasm = Module["_ts_tree_cursor_end_index_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_end_index_wasm");
        var _ts_tree_cursor_current_field_id_wasm = Module["_ts_tree_cursor_current_field_id_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_field_id_wasm");
        var _ts_tree_cursor_current_depth_wasm = Module["_ts_tree_cursor_current_depth_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_depth_wasm");
        var _ts_tree_cursor_current_descendant_index_wasm = Module["_ts_tree_cursor_current_descendant_index_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_descendant_index_wasm");
        var _ts_tree_cursor_current_node_wasm = Module["_ts_tree_cursor_current_node_wasm"] = makeInvalidEarlyAccess("_ts_tree_cursor_current_node_wasm");
        var _ts_node_symbol_wasm = Module["_ts_node_symbol_wasm"] = makeInvalidEarlyAccess("_ts_node_symbol_wasm");
        var _ts_node_field_name_for_child_wasm = Module["_ts_node_field_name_for_child_wasm"] = makeInvalidEarlyAccess("_ts_node_field_name_for_child_wasm");
        var _ts_node_field_name_for_named_child_wasm = Module["_ts_node_field_name_for_named_child_wasm"] = makeInvalidEarlyAccess("_ts_node_field_name_for_named_child_wasm");
        var _ts_node_children_by_field_id_wasm = Module["_ts_node_children_by_field_id_wasm"] = makeInvalidEarlyAccess("_ts_node_children_by_field_id_wasm");
        var _ts_node_first_child_for_byte_wasm = Module["_ts_node_first_child_for_byte_wasm"] = makeInvalidEarlyAccess("_ts_node_first_child_for_byte_wasm");
        var _ts_node_first_named_child_for_byte_wasm = Module["_ts_node_first_named_child_for_byte_wasm"] = makeInvalidEarlyAccess("_ts_node_first_named_child_for_byte_wasm");
        var _ts_node_grammar_symbol_wasm = Module["_ts_node_grammar_symbol_wasm"] = makeInvalidEarlyAccess("_ts_node_grammar_symbol_wasm");
        var _ts_node_child_count_wasm = Module["_ts_node_child_count_wasm"] = makeInvalidEarlyAccess("_ts_node_child_count_wasm");
        var _ts_node_named_child_count_wasm = Module["_ts_node_named_child_count_wasm"] = makeInvalidEarlyAccess("_ts_node_named_child_count_wasm");
        var _ts_node_child_wasm = Module["_ts_node_child_wasm"] = makeInvalidEarlyAccess("_ts_node_child_wasm");
        var _ts_node_named_child_wasm = Module["_ts_node_named_child_wasm"] = makeInvalidEarlyAccess("_ts_node_named_child_wasm");
        var _ts_node_child_by_field_id_wasm = Module["_ts_node_child_by_field_id_wasm"] = makeInvalidEarlyAccess("_ts_node_child_by_field_id_wasm");
        var _ts_node_next_sibling_wasm = Module["_ts_node_next_sibling_wasm"] = makeInvalidEarlyAccess("_ts_node_next_sibling_wasm");
        var _ts_node_prev_sibling_wasm = Module["_ts_node_prev_sibling_wasm"] = makeInvalidEarlyAccess("_ts_node_prev_sibling_wasm");
        var _ts_node_next_named_sibling_wasm = Module["_ts_node_next_named_sibling_wasm"] = makeInvalidEarlyAccess("_ts_node_next_named_sibling_wasm");
        var _ts_node_prev_named_sibling_wasm = Module["_ts_node_prev_named_sibling_wasm"] = makeInvalidEarlyAccess("_ts_node_prev_named_sibling_wasm");
        var _ts_node_descendant_count_wasm = Module["_ts_node_descendant_count_wasm"] = makeInvalidEarlyAccess("_ts_node_descendant_count_wasm");
        var _ts_node_parent_wasm = Module["_ts_node_parent_wasm"] = makeInvalidEarlyAccess("_ts_node_parent_wasm");
        var _ts_node_child_with_descendant_wasm = Module["_ts_node_child_with_descendant_wasm"] = makeInvalidEarlyAccess("_ts_node_child_with_descendant_wasm");
        var _ts_node_descendant_for_index_wasm = Module["_ts_node_descendant_for_index_wasm"] = makeInvalidEarlyAccess("_ts_node_descendant_for_index_wasm");
        var _ts_node_named_descendant_for_index_wasm = Module["_ts_node_named_descendant_for_index_wasm"] = makeInvalidEarlyAccess("_ts_node_named_descendant_for_index_wasm");
        var _ts_node_descendant_for_position_wasm = Module["_ts_node_descendant_for_position_wasm"] = makeInvalidEarlyAccess("_ts_node_descendant_for_position_wasm");
        var _ts_node_named_descendant_for_position_wasm = Module["_ts_node_named_descendant_for_position_wasm"] = makeInvalidEarlyAccess("_ts_node_named_descendant_for_position_wasm");
        var _ts_node_start_point_wasm = Module["_ts_node_start_point_wasm"] = makeInvalidEarlyAccess("_ts_node_start_point_wasm");
        var _ts_node_end_point_wasm = Module["_ts_node_end_point_wasm"] = makeInvalidEarlyAccess("_ts_node_end_point_wasm");
        var _ts_node_start_index_wasm = Module["_ts_node_start_index_wasm"] = makeInvalidEarlyAccess("_ts_node_start_index_wasm");
        var _ts_node_end_index_wasm = Module["_ts_node_end_index_wasm"] = makeInvalidEarlyAccess("_ts_node_end_index_wasm");
        var _ts_node_to_string_wasm = Module["_ts_node_to_string_wasm"] = makeInvalidEarlyAccess("_ts_node_to_string_wasm");
        var _ts_node_children_wasm = Module["_ts_node_children_wasm"] = makeInvalidEarlyAccess("_ts_node_children_wasm");
        var _ts_node_named_children_wasm = Module["_ts_node_named_children_wasm"] = makeInvalidEarlyAccess("_ts_node_named_children_wasm");
        var _ts_node_descendants_of_type_wasm = Module["_ts_node_descendants_of_type_wasm"] = makeInvalidEarlyAccess("_ts_node_descendants_of_type_wasm");
        var _ts_node_is_named_wasm = Module["_ts_node_is_named_wasm"] = makeInvalidEarlyAccess("_ts_node_is_named_wasm");
        var _ts_node_has_changes_wasm = Module["_ts_node_has_changes_wasm"] = makeInvalidEarlyAccess("_ts_node_has_changes_wasm");
        var _ts_node_has_error_wasm = Module["_ts_node_has_error_wasm"] = makeInvalidEarlyAccess("_ts_node_has_error_wasm");
        var _ts_node_is_error_wasm = Module["_ts_node_is_error_wasm"] = makeInvalidEarlyAccess("_ts_node_is_error_wasm");
        var _ts_node_is_missing_wasm = Module["_ts_node_is_missing_wasm"] = makeInvalidEarlyAccess("_ts_node_is_missing_wasm");
        var _ts_node_is_extra_wasm = Module["_ts_node_is_extra_wasm"] = makeInvalidEarlyAccess("_ts_node_is_extra_wasm");
        var _ts_node_parse_state_wasm = Module["_ts_node_parse_state_wasm"] = makeInvalidEarlyAccess("_ts_node_parse_state_wasm");
        var _ts_node_next_parse_state_wasm = Module["_ts_node_next_parse_state_wasm"] = makeInvalidEarlyAccess("_ts_node_next_parse_state_wasm");
        var _ts_query_matches_wasm = Module["_ts_query_matches_wasm"] = makeInvalidEarlyAccess("_ts_query_matches_wasm");
        var _ts_query_captures_wasm = Module["_ts_query_captures_wasm"] = makeInvalidEarlyAccess("_ts_query_captures_wasm");
        var _memset = Module["_memset"] = makeInvalidEarlyAccess("_memset");
        var _memcpy = Module["_memcpy"] = makeInvalidEarlyAccess("_memcpy");
        var _memmove = Module["_memmove"] = makeInvalidEarlyAccess("_memmove");
        var _fflush = makeInvalidEarlyAccess("_fflush");
        var _strlen = Module["_strlen"] = makeInvalidEarlyAccess("_strlen");
        var _iswalpha = Module["_iswalpha"] = makeInvalidEarlyAccess("_iswalpha");
        var _iswblank = Module["_iswblank"] = makeInvalidEarlyAccess("_iswblank");
        var _iswdigit = Module["_iswdigit"] = makeInvalidEarlyAccess("_iswdigit");
        var _iswlower = Module["_iswlower"] = makeInvalidEarlyAccess("_iswlower");
        var _iswpunct = Module["_iswpunct"] = makeInvalidEarlyAccess("_iswpunct");
        var _iswupper = Module["_iswupper"] = makeInvalidEarlyAccess("_iswupper");
        var _iswxdigit = Module["_iswxdigit"] = makeInvalidEarlyAccess("_iswxdigit");
        var _memchr = Module["_memchr"] = makeInvalidEarlyAccess("_memchr");
        var _emscripten_stack_get_end = makeInvalidEarlyAccess("_emscripten_stack_get_end");
        var _emscripten_stack_get_base = makeInvalidEarlyAccess("_emscripten_stack_get_base");
        var _strcmp = Module["_strcmp"] = makeInvalidEarlyAccess("_strcmp");
        var _strncat = Module["_strncat"] = makeInvalidEarlyAccess("_strncat");
        var _strncpy = Module["_strncpy"] = makeInvalidEarlyAccess("_strncpy");
        var _towlower = Module["_towlower"] = makeInvalidEarlyAccess("_towlower");
        var _towupper = Module["_towupper"] = makeInvalidEarlyAccess("_towupper");
        var _sbrk = makeInvalidEarlyAccess("_sbrk");
        var _emscripten_get_sbrk_ptr = makeInvalidEarlyAccess("_emscripten_get_sbrk_ptr");
        var _setThrew = makeInvalidEarlyAccess("_setThrew");
        var _emscripten_stack_set_limits = makeInvalidEarlyAccess("_emscripten_stack_set_limits");
        var _emscripten_stack_get_free = makeInvalidEarlyAccess("_emscripten_stack_get_free");
        var __emscripten_stack_restore = makeInvalidEarlyAccess("__emscripten_stack_restore");
        var __emscripten_stack_alloc = makeInvalidEarlyAccess("__emscripten_stack_alloc");
        var _emscripten_stack_get_current = makeInvalidEarlyAccess("_emscripten_stack_get_current");
        var ___wasm_apply_data_relocs = makeInvalidEarlyAccess("___wasm_apply_data_relocs");
        function assignWasmExports(wasmExports2) {
          Module["_malloc"] = _malloc = createExportWrapper("malloc", 1);
          Module["_calloc"] = _calloc = createExportWrapper("calloc", 2);
          Module["_realloc"] = _realloc = createExportWrapper("realloc", 2);
          Module["_free"] = _free = createExportWrapper("free", 1);
          Module["_ts_range_edit"] = _ts_range_edit = createExportWrapper("ts_range_edit", 2);
          Module["_ts_language_symbol_count"] = _ts_language_symbol_count = createExportWrapper("ts_language_symbol_count", 1);
          Module["_ts_language_state_count"] = _ts_language_state_count = createExportWrapper("ts_language_state_count", 1);
          Module["_ts_language_abi_version"] = _ts_language_abi_version = createExportWrapper("ts_language_abi_version", 1);
          Module["_ts_language_name"] = _ts_language_name = createExportWrapper("ts_language_name", 1);
          Module["_ts_language_field_count"] = _ts_language_field_count = createExportWrapper("ts_language_field_count", 1);
          Module["_ts_language_next_state"] = _ts_language_next_state = createExportWrapper("ts_language_next_state", 3);
          Module["_ts_language_symbol_name"] = _ts_language_symbol_name = createExportWrapper("ts_language_symbol_name", 2);
          Module["_ts_language_symbol_for_name"] = _ts_language_symbol_for_name = createExportWrapper("ts_language_symbol_for_name", 4);
          Module["_strncmp"] = _strncmp = createExportWrapper("strncmp", 3);
          Module["_ts_language_symbol_type"] = _ts_language_symbol_type = createExportWrapper("ts_language_symbol_type", 2);
          Module["_ts_language_field_name_for_id"] = _ts_language_field_name_for_id = createExportWrapper("ts_language_field_name_for_id", 2);
          Module["_ts_lookahead_iterator_new"] = _ts_lookahead_iterator_new = createExportWrapper("ts_lookahead_iterator_new", 2);
          Module["_ts_lookahead_iterator_delete"] = _ts_lookahead_iterator_delete = createExportWrapper("ts_lookahead_iterator_delete", 1);
          Module["_ts_lookahead_iterator_reset_state"] = _ts_lookahead_iterator_reset_state = createExportWrapper("ts_lookahead_iterator_reset_state", 2);
          Module["_ts_lookahead_iterator_reset"] = _ts_lookahead_iterator_reset = createExportWrapper("ts_lookahead_iterator_reset", 3);
          Module["_ts_lookahead_iterator_next"] = _ts_lookahead_iterator_next = createExportWrapper("ts_lookahead_iterator_next", 1);
          Module["_ts_lookahead_iterator_current_symbol"] = _ts_lookahead_iterator_current_symbol = createExportWrapper("ts_lookahead_iterator_current_symbol", 1);
          Module["_ts_point_edit"] = _ts_point_edit = createExportWrapper("ts_point_edit", 3);
          Module["_ts_parser_delete"] = _ts_parser_delete = createExportWrapper("ts_parser_delete", 1);
          Module["_ts_parser_set_language"] = _ts_parser_set_language = createExportWrapper("ts_parser_set_language", 2);
          Module["_ts_parser_reset"] = _ts_parser_reset = createExportWrapper("ts_parser_reset", 1);
          Module["_ts_parser_set_included_ranges"] = _ts_parser_set_included_ranges = createExportWrapper("ts_parser_set_included_ranges", 3);
          Module["_ts_query_new"] = _ts_query_new = createExportWrapper("ts_query_new", 5);
          Module["_ts_query_delete"] = _ts_query_delete = createExportWrapper("ts_query_delete", 1);
          Module["_iswspace"] = _iswspace = createExportWrapper("iswspace", 1);
          Module["_ts_query_copy"] = _ts_query_copy = createExportWrapper("ts_query_copy", 1);
          Module["_ts_query_pattern_count"] = _ts_query_pattern_count = createExportWrapper("ts_query_pattern_count", 1);
          Module["_ts_query_capture_count"] = _ts_query_capture_count = createExportWrapper("ts_query_capture_count", 1);
          Module["_ts_query_string_count"] = _ts_query_string_count = createExportWrapper("ts_query_string_count", 1);
          Module["_ts_query_capture_name_for_id"] = _ts_query_capture_name_for_id = createExportWrapper("ts_query_capture_name_for_id", 3);
          Module["_ts_query_capture_quantifier_for_id"] = _ts_query_capture_quantifier_for_id = createExportWrapper("ts_query_capture_quantifier_for_id", 3);
          Module["_ts_query_string_value_for_id"] = _ts_query_string_value_for_id = createExportWrapper("ts_query_string_value_for_id", 3);
          Module["_ts_query_predicates_for_pattern"] = _ts_query_predicates_for_pattern = createExportWrapper("ts_query_predicates_for_pattern", 3);
          Module["_ts_query_start_byte_for_pattern"] = _ts_query_start_byte_for_pattern = createExportWrapper("ts_query_start_byte_for_pattern", 2);
          Module["_ts_query_end_byte_for_pattern"] = _ts_query_end_byte_for_pattern = createExportWrapper("ts_query_end_byte_for_pattern", 2);
          Module["_ts_query_is_pattern_rooted"] = _ts_query_is_pattern_rooted = createExportWrapper("ts_query_is_pattern_rooted", 2);
          Module["_ts_query_is_pattern_non_local"] = _ts_query_is_pattern_non_local = createExportWrapper("ts_query_is_pattern_non_local", 2);
          Module["_ts_query_is_pattern_guaranteed_at_step"] = _ts_query_is_pattern_guaranteed_at_step = createExportWrapper("ts_query_is_pattern_guaranteed_at_step", 2);
          Module["_ts_query_disable_capture"] = _ts_query_disable_capture = createExportWrapper("ts_query_disable_capture", 3);
          Module["_ts_query_disable_pattern"] = _ts_query_disable_pattern = createExportWrapper("ts_query_disable_pattern", 2);
          Module["_memcmp"] = _memcmp = createExportWrapper("memcmp", 3);
          Module["_ts_tree_copy"] = _ts_tree_copy = createExportWrapper("ts_tree_copy", 1);
          Module["_ts_tree_delete"] = _ts_tree_delete = createExportWrapper("ts_tree_delete", 1);
          Module["_iswalnum"] = _iswalnum = createExportWrapper("iswalnum", 1);
          Module["_ts_init"] = _ts_init = createExportWrapper("ts_init", 0);
          Module["_ts_parser_new_wasm"] = _ts_parser_new_wasm = createExportWrapper("ts_parser_new_wasm", 0);
          Module["_ts_parser_enable_logger_wasm"] = _ts_parser_enable_logger_wasm = createExportWrapper("ts_parser_enable_logger_wasm", 2);
          Module["_ts_parser_parse_wasm"] = _ts_parser_parse_wasm = createExportWrapper("ts_parser_parse_wasm", 5);
          Module["_ts_parser_included_ranges_wasm"] = _ts_parser_included_ranges_wasm = createExportWrapper("ts_parser_included_ranges_wasm", 1);
          Module["_ts_language_type_is_named_wasm"] = _ts_language_type_is_named_wasm = createExportWrapper("ts_language_type_is_named_wasm", 2);
          Module["_ts_language_type_is_visible_wasm"] = _ts_language_type_is_visible_wasm = createExportWrapper("ts_language_type_is_visible_wasm", 2);
          Module["_ts_language_metadata_wasm"] = _ts_language_metadata_wasm = createExportWrapper("ts_language_metadata_wasm", 1);
          Module["_ts_language_supertypes_wasm"] = _ts_language_supertypes_wasm = createExportWrapper("ts_language_supertypes_wasm", 1);
          Module["_ts_language_subtypes_wasm"] = _ts_language_subtypes_wasm = createExportWrapper("ts_language_subtypes_wasm", 2);
          Module["_ts_tree_root_node_wasm"] = _ts_tree_root_node_wasm = createExportWrapper("ts_tree_root_node_wasm", 1);
          Module["_ts_tree_root_node_with_offset_wasm"] = _ts_tree_root_node_with_offset_wasm = createExportWrapper("ts_tree_root_node_with_offset_wasm", 1);
          Module["_ts_tree_edit_wasm"] = _ts_tree_edit_wasm = createExportWrapper("ts_tree_edit_wasm", 1);
          Module["_ts_tree_included_ranges_wasm"] = _ts_tree_included_ranges_wasm = createExportWrapper("ts_tree_included_ranges_wasm", 1);
          Module["_ts_tree_get_changed_ranges_wasm"] = _ts_tree_get_changed_ranges_wasm = createExportWrapper("ts_tree_get_changed_ranges_wasm", 2);
          Module["_ts_tree_cursor_new_wasm"] = _ts_tree_cursor_new_wasm = createExportWrapper("ts_tree_cursor_new_wasm", 1);
          Module["_ts_tree_cursor_copy_wasm"] = _ts_tree_cursor_copy_wasm = createExportWrapper("ts_tree_cursor_copy_wasm", 1);
          Module["_ts_tree_cursor_delete_wasm"] = _ts_tree_cursor_delete_wasm = createExportWrapper("ts_tree_cursor_delete_wasm", 1);
          Module["_ts_tree_cursor_reset_wasm"] = _ts_tree_cursor_reset_wasm = createExportWrapper("ts_tree_cursor_reset_wasm", 1);
          Module["_ts_tree_cursor_reset_to_wasm"] = _ts_tree_cursor_reset_to_wasm = createExportWrapper("ts_tree_cursor_reset_to_wasm", 2);
          Module["_ts_tree_cursor_goto_first_child_wasm"] = _ts_tree_cursor_goto_first_child_wasm = createExportWrapper("ts_tree_cursor_goto_first_child_wasm", 1);
          Module["_ts_tree_cursor_goto_last_child_wasm"] = _ts_tree_cursor_goto_last_child_wasm = createExportWrapper("ts_tree_cursor_goto_last_child_wasm", 1);
          Module["_ts_tree_cursor_goto_first_child_for_index_wasm"] = _ts_tree_cursor_goto_first_child_for_index_wasm = createExportWrapper("ts_tree_cursor_goto_first_child_for_index_wasm", 1);
          Module["_ts_tree_cursor_goto_first_child_for_position_wasm"] = _ts_tree_cursor_goto_first_child_for_position_wasm = createExportWrapper("ts_tree_cursor_goto_first_child_for_position_wasm", 1);
          Module["_ts_tree_cursor_goto_next_sibling_wasm"] = _ts_tree_cursor_goto_next_sibling_wasm = createExportWrapper("ts_tree_cursor_goto_next_sibling_wasm", 1);
          Module["_ts_tree_cursor_goto_previous_sibling_wasm"] = _ts_tree_cursor_goto_previous_sibling_wasm = createExportWrapper("ts_tree_cursor_goto_previous_sibling_wasm", 1);
          Module["_ts_tree_cursor_goto_descendant_wasm"] = _ts_tree_cursor_goto_descendant_wasm = createExportWrapper("ts_tree_cursor_goto_descendant_wasm", 2);
          Module["_ts_tree_cursor_goto_parent_wasm"] = _ts_tree_cursor_goto_parent_wasm = createExportWrapper("ts_tree_cursor_goto_parent_wasm", 1);
          Module["_ts_tree_cursor_current_node_type_id_wasm"] = _ts_tree_cursor_current_node_type_id_wasm = createExportWrapper("ts_tree_cursor_current_node_type_id_wasm", 1);
          Module["_ts_tree_cursor_current_node_state_id_wasm"] = _ts_tree_cursor_current_node_state_id_wasm = createExportWrapper("ts_tree_cursor_current_node_state_id_wasm", 1);
          Module["_ts_tree_cursor_current_node_is_named_wasm"] = _ts_tree_cursor_current_node_is_named_wasm = createExportWrapper("ts_tree_cursor_current_node_is_named_wasm", 1);
          Module["_ts_tree_cursor_current_node_is_missing_wasm"] = _ts_tree_cursor_current_node_is_missing_wasm = createExportWrapper("ts_tree_cursor_current_node_is_missing_wasm", 1);
          Module["_ts_tree_cursor_current_node_id_wasm"] = _ts_tree_cursor_current_node_id_wasm = createExportWrapper("ts_tree_cursor_current_node_id_wasm", 1);
          Module["_ts_tree_cursor_start_position_wasm"] = _ts_tree_cursor_start_position_wasm = createExportWrapper("ts_tree_cursor_start_position_wasm", 1);
          Module["_ts_tree_cursor_end_position_wasm"] = _ts_tree_cursor_end_position_wasm = createExportWrapper("ts_tree_cursor_end_position_wasm", 1);
          Module["_ts_tree_cursor_start_index_wasm"] = _ts_tree_cursor_start_index_wasm = createExportWrapper("ts_tree_cursor_start_index_wasm", 1);
          Module["_ts_tree_cursor_end_index_wasm"] = _ts_tree_cursor_end_index_wasm = createExportWrapper("ts_tree_cursor_end_index_wasm", 1);
          Module["_ts_tree_cursor_current_field_id_wasm"] = _ts_tree_cursor_current_field_id_wasm = createExportWrapper("ts_tree_cursor_current_field_id_wasm", 1);
          Module["_ts_tree_cursor_current_depth_wasm"] = _ts_tree_cursor_current_depth_wasm = createExportWrapper("ts_tree_cursor_current_depth_wasm", 1);
          Module["_ts_tree_cursor_current_descendant_index_wasm"] = _ts_tree_cursor_current_descendant_index_wasm = createExportWrapper("ts_tree_cursor_current_descendant_index_wasm", 1);
          Module["_ts_tree_cursor_current_node_wasm"] = _ts_tree_cursor_current_node_wasm = createExportWrapper("ts_tree_cursor_current_node_wasm", 1);
          Module["_ts_node_symbol_wasm"] = _ts_node_symbol_wasm = createExportWrapper("ts_node_symbol_wasm", 1);
          Module["_ts_node_field_name_for_child_wasm"] = _ts_node_field_name_for_child_wasm = createExportWrapper("ts_node_field_name_for_child_wasm", 2);
          Module["_ts_node_field_name_for_named_child_wasm"] = _ts_node_field_name_for_named_child_wasm = createExportWrapper("ts_node_field_name_for_named_child_wasm", 2);
          Module["_ts_node_children_by_field_id_wasm"] = _ts_node_children_by_field_id_wasm = createExportWrapper("ts_node_children_by_field_id_wasm", 2);
          Module["_ts_node_first_child_for_byte_wasm"] = _ts_node_first_child_for_byte_wasm = createExportWrapper("ts_node_first_child_for_byte_wasm", 1);
          Module["_ts_node_first_named_child_for_byte_wasm"] = _ts_node_first_named_child_for_byte_wasm = createExportWrapper("ts_node_first_named_child_for_byte_wasm", 1);
          Module["_ts_node_grammar_symbol_wasm"] = _ts_node_grammar_symbol_wasm = createExportWrapper("ts_node_grammar_symbol_wasm", 1);
          Module["_ts_node_child_count_wasm"] = _ts_node_child_count_wasm = createExportWrapper("ts_node_child_count_wasm", 1);
          Module["_ts_node_named_child_count_wasm"] = _ts_node_named_child_count_wasm = createExportWrapper("ts_node_named_child_count_wasm", 1);
          Module["_ts_node_child_wasm"] = _ts_node_child_wasm = createExportWrapper("ts_node_child_wasm", 2);
          Module["_ts_node_named_child_wasm"] = _ts_node_named_child_wasm = createExportWrapper("ts_node_named_child_wasm", 2);
          Module["_ts_node_child_by_field_id_wasm"] = _ts_node_child_by_field_id_wasm = createExportWrapper("ts_node_child_by_field_id_wasm", 2);
          Module["_ts_node_next_sibling_wasm"] = _ts_node_next_sibling_wasm = createExportWrapper("ts_node_next_sibling_wasm", 1);
          Module["_ts_node_prev_sibling_wasm"] = _ts_node_prev_sibling_wasm = createExportWrapper("ts_node_prev_sibling_wasm", 1);
          Module["_ts_node_next_named_sibling_wasm"] = _ts_node_next_named_sibling_wasm = createExportWrapper("ts_node_next_named_sibling_wasm", 1);
          Module["_ts_node_prev_named_sibling_wasm"] = _ts_node_prev_named_sibling_wasm = createExportWrapper("ts_node_prev_named_sibling_wasm", 1);
          Module["_ts_node_descendant_count_wasm"] = _ts_node_descendant_count_wasm = createExportWrapper("ts_node_descendant_count_wasm", 1);
          Module["_ts_node_parent_wasm"] = _ts_node_parent_wasm = createExportWrapper("ts_node_parent_wasm", 1);
          Module["_ts_node_child_with_descendant_wasm"] = _ts_node_child_with_descendant_wasm = createExportWrapper("ts_node_child_with_descendant_wasm", 1);
          Module["_ts_node_descendant_for_index_wasm"] = _ts_node_descendant_for_index_wasm = createExportWrapper("ts_node_descendant_for_index_wasm", 1);
          Module["_ts_node_named_descendant_for_index_wasm"] = _ts_node_named_descendant_for_index_wasm = createExportWrapper("ts_node_named_descendant_for_index_wasm", 1);
          Module["_ts_node_descendant_for_position_wasm"] = _ts_node_descendant_for_position_wasm = createExportWrapper("ts_node_descendant_for_position_wasm", 1);
          Module["_ts_node_named_descendant_for_position_wasm"] = _ts_node_named_descendant_for_position_wasm = createExportWrapper("ts_node_named_descendant_for_position_wasm", 1);
          Module["_ts_node_start_point_wasm"] = _ts_node_start_point_wasm = createExportWrapper("ts_node_start_point_wasm", 1);
          Module["_ts_node_end_point_wasm"] = _ts_node_end_point_wasm = createExportWrapper("ts_node_end_point_wasm", 1);
          Module["_ts_node_start_index_wasm"] = _ts_node_start_index_wasm = createExportWrapper("ts_node_start_index_wasm", 1);
          Module["_ts_node_end_index_wasm"] = _ts_node_end_index_wasm = createExportWrapper("ts_node_end_index_wasm", 1);
          Module["_ts_node_to_string_wasm"] = _ts_node_to_string_wasm = createExportWrapper("ts_node_to_string_wasm", 1);
          Module["_ts_node_children_wasm"] = _ts_node_children_wasm = createExportWrapper("ts_node_children_wasm", 1);
          Module["_ts_node_named_children_wasm"] = _ts_node_named_children_wasm = createExportWrapper("ts_node_named_children_wasm", 1);
          Module["_ts_node_descendants_of_type_wasm"] = _ts_node_descendants_of_type_wasm = createExportWrapper("ts_node_descendants_of_type_wasm", 7);
          Module["_ts_node_is_named_wasm"] = _ts_node_is_named_wasm = createExportWrapper("ts_node_is_named_wasm", 1);
          Module["_ts_node_has_changes_wasm"] = _ts_node_has_changes_wasm = createExportWrapper("ts_node_has_changes_wasm", 1);
          Module["_ts_node_has_error_wasm"] = _ts_node_has_error_wasm = createExportWrapper("ts_node_has_error_wasm", 1);
          Module["_ts_node_is_error_wasm"] = _ts_node_is_error_wasm = createExportWrapper("ts_node_is_error_wasm", 1);
          Module["_ts_node_is_missing_wasm"] = _ts_node_is_missing_wasm = createExportWrapper("ts_node_is_missing_wasm", 1);
          Module["_ts_node_is_extra_wasm"] = _ts_node_is_extra_wasm = createExportWrapper("ts_node_is_extra_wasm", 1);
          Module["_ts_node_parse_state_wasm"] = _ts_node_parse_state_wasm = createExportWrapper("ts_node_parse_state_wasm", 1);
          Module["_ts_node_next_parse_state_wasm"] = _ts_node_next_parse_state_wasm = createExportWrapper("ts_node_next_parse_state_wasm", 1);
          Module["_ts_query_matches_wasm"] = _ts_query_matches_wasm = createExportWrapper("ts_query_matches_wasm", 16);
          Module["_ts_query_captures_wasm"] = _ts_query_captures_wasm = createExportWrapper("ts_query_captures_wasm", 16);
          Module["_memset"] = _memset = createExportWrapper("memset", 3);
          Module["_memcpy"] = _memcpy = createExportWrapper("memcpy", 3);
          Module["_memmove"] = _memmove = createExportWrapper("memmove", 3);
          _fflush = createExportWrapper("fflush", 1);
          Module["_strlen"] = _strlen = createExportWrapper("strlen", 1);
          Module["_iswalpha"] = _iswalpha = createExportWrapper("iswalpha", 1);
          Module["_iswblank"] = _iswblank = createExportWrapper("iswblank", 1);
          Module["_iswdigit"] = _iswdigit = createExportWrapper("iswdigit", 1);
          Module["_iswlower"] = _iswlower = createExportWrapper("iswlower", 1);
          Module["_iswpunct"] = _iswpunct = createExportWrapper("iswpunct", 1);
          Module["_iswupper"] = _iswupper = createExportWrapper("iswupper", 1);
          Module["_iswxdigit"] = _iswxdigit = createExportWrapper("iswxdigit", 1);
          Module["_memchr"] = _memchr = createExportWrapper("memchr", 3);
          _emscripten_stack_get_end = wasmExports2["emscripten_stack_get_end"];
          _emscripten_stack_get_base = wasmExports2["emscripten_stack_get_base"];
          Module["_strcmp"] = _strcmp = createExportWrapper("strcmp", 2);
          Module["_strncat"] = _strncat = createExportWrapper("strncat", 3);
          Module["_strncpy"] = _strncpy = createExportWrapper("strncpy", 3);
          Module["_towlower"] = _towlower = createExportWrapper("towlower", 1);
          Module["_towupper"] = _towupper = createExportWrapper("towupper", 1);
          _sbrk = createExportWrapper("sbrk", 1);
          _emscripten_get_sbrk_ptr = createExportWrapper("emscripten_get_sbrk_ptr", 0);
          _setThrew = createExportWrapper("setThrew", 2);
          _emscripten_stack_set_limits = wasmExports2["emscripten_stack_set_limits"];
          _emscripten_stack_get_free = wasmExports2["emscripten_stack_get_free"];
          __emscripten_stack_restore = wasmExports2["_emscripten_stack_restore"];
          __emscripten_stack_alloc = wasmExports2["_emscripten_stack_alloc"];
          _emscripten_stack_get_current = wasmExports2["emscripten_stack_get_current"];
          ___wasm_apply_data_relocs = createExportWrapper("__wasm_apply_data_relocs", 0);
        }
        __name(assignWasmExports, "assignWasmExports");
        var wasmImports = {
          /** @export */
          __heap_base: ___heap_base,
          /** @export */
          __indirect_function_table: wasmTable,
          /** @export */
          __memory_base: ___memory_base,
          /** @export */
          __stack_high: ___stack_high,
          /** @export */
          __stack_low: ___stack_low,
          /** @export */
          __stack_pointer: ___stack_pointer,
          /** @export */
          __table_base: ___table_base,
          /** @export */
          _abort_js: __abort_js,
          /** @export */
          alignfault,
          /** @export */
          emscripten_resize_heap: _emscripten_resize_heap,
          /** @export */
          fd_close: _fd_close,
          /** @export */
          fd_seek: _fd_seek,
          /** @export */
          fd_write: _fd_write,
          /** @export */
          memory: wasmMemory,
          /** @export */
          segfault,
          /** @export */
          tree_sitter_log_callback: _tree_sitter_log_callback,
          /** @export */
          tree_sitter_parse_callback: _tree_sitter_parse_callback,
          /** @export */
          tree_sitter_progress_callback: _tree_sitter_progress_callback,
          /** @export */
          tree_sitter_query_progress_callback: _tree_sitter_query_progress_callback
        };
        var calledRun;
        function callMain(args2 = []) {
          assert(runDependencies == 0, 'cannot call main when async dependencies remain! (listen on Module["onRuntimeInitialized"])');
          assert(typeof onPreRuns === "undefined" || onPreRuns.length == 0, "cannot call main when preRun functions remain to be called");
          var entryFunction = resolveGlobalSymbol("main").sym;
          if (!entryFunction) return;
          args2.unshift(thisProgram);
          var argc = args2.length;
          var argv = stackAlloc((argc + 1) * 4);
          var argv_ptr = argv;
          args2.forEach((arg) => {
            LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, argv_ptr >> 2, "storing") * 4, stringToUTF8OnStack(arg));
            argv_ptr += 4;
          });
          LE_HEAP_STORE_U32(SAFE_HEAP_INDEX(HEAPU32, argv_ptr >> 2, "storing") * 4, 0);
          try {
            var ret = entryFunction(argc, argv);
            exitJS(
              ret,
              /* implicit = */
              true
            );
            return ret;
          } catch (e) {
            return handleException(e);
          }
        }
        __name(callMain, "callMain");
        function stackCheckInit() {
          _emscripten_stack_set_limits(82240, 16704);
          writeStackCookie();
        }
        __name(stackCheckInit, "stackCheckInit");
        function run(args2 = arguments_) {
          if (runDependencies > 0) {
            dependenciesFulfilled = run;
            return;
          }
          stackCheckInit();
          preRun();
          if (runDependencies > 0) {
            dependenciesFulfilled = run;
            return;
          }
          function doRun() {
            assert(!calledRun);
            calledRun = true;
            Module["calledRun"] = true;
            if (ABORT) return;
            initRuntime();
            preMain();
            readyPromiseResolve?.(Module);
            Module["onRuntimeInitialized"]?.();
            consumedModuleProp("onRuntimeInitialized");
            var noInitialRun = Module["noInitialRun"] || false;
            if (!noInitialRun) callMain(args2);
            postRun();
          }
          __name(doRun, "doRun");
          if (Module["setStatus"]) {
            Module["setStatus"]("Running...");
            setTimeout(() => {
              setTimeout(() => Module["setStatus"](""), 1);
              doRun();
            }, 1);
          } else {
            doRun();
          }
          checkStackCookie();
        }
        __name(run, "run");
        function checkUnflushedContent() {
          var oldOut = out;
          var oldErr = err;
          var has = false;
          out = err = /* @__PURE__ */ __name((x) => {
            has = true;
          }, "err");
          try {
            flush_NO_FILESYSTEM();
          } catch (e) {
          }
          out = oldOut;
          err = oldErr;
          if (has) {
            warnOnce("stdio streams had content in them that was not flushed. you should set EXIT_RUNTIME to 1 (see the Emscripten FAQ), or make sure to emit a newline when you printf etc.");
            warnOnce("(this may also be due to not including full filesystem support - try building with -sFORCE_FILESYSTEM)");
          }
        }
        __name(checkUnflushedContent, "checkUnflushedContent");
        var wasmExports;
        wasmExports = await createWasm();
        run();
        if (runtimeInitialized) {
          moduleRtn = Module;
        } else {
          moduleRtn = new Promise((resolve, reject) => {
            readyPromiseResolve = resolve;
            readyPromiseReject = reject;
          });
        }
        for (const prop of Object.keys(Module)) {
          if (!(prop in moduleArg)) {
            Object.defineProperty(moduleArg, prop, {
              configurable: true,
              get() {
                abort(`Access to module property ('${prop}') is no longer possible via the module constructor argument; Instead, use the result of the module constructor.`);
              }
            });
          }
        }
        return moduleRtn;
      };
    })();
    if (typeof exports === "object" && typeof module === "object") {
      module.exports = Module;
      module.exports.default = Module;
    } else if (typeof define === "function" && define["amd"])
      define([], () => Module);
  }
});

// src/index.ts
var index_exports = {};
__export(index_exports, {
  CaptureQuantifier: () => CaptureQuantifier,
  Edit: () => Edit,
  LANGUAGE_VERSION: () => LANGUAGE_VERSION,
  Language: () => Language,
  LookaheadIterator: () => LookaheadIterator,
  MIN_COMPATIBLE_VERSION: () => MIN_COMPATIBLE_VERSION,
  Node: () => Node,
  Parser: () => Parser,
  Query: () => Query,
  Tree: () => Tree,
  TreeCursor: () => TreeCursor
});
module.exports = __toCommonJS(index_exports);

// src/edit.ts
var Edit = class {
  static {
    __name(this, "Edit");
  }
  /** The start position of the change. */
  startPosition;
  /** The end position of the change before the edit. */
  oldEndPosition;
  /** The end position of the change after the edit. */
  newEndPosition;
  /** The start index of the change. */
  startIndex;
  /** The end index of the change before the edit. */
  oldEndIndex;
  /** The end index of the change after the edit. */
  newEndIndex;
  constructor({
    startIndex,
    oldEndIndex,
    newEndIndex,
    startPosition,
    oldEndPosition,
    newEndPosition
  }) {
    this.startIndex = startIndex >>> 0;
    this.oldEndIndex = oldEndIndex >>> 0;
    this.newEndIndex = newEndIndex >>> 0;
    this.startPosition = startPosition;
    this.oldEndPosition = oldEndPosition;
    this.newEndPosition = newEndPosition;
  }
  /**
   * Edit a point and index to keep it in-sync with source code that has been edited.
   *
   * This function updates a single point's byte offset and row/column position
   * based on an edit operation. This is useful for editing points without
   * requiring a tree or node instance.
   */
  editPoint(point, index) {
    let newIndex = index;
    const newPoint = { ...point };
    if (index >= this.oldEndIndex) {
      newIndex = this.newEndIndex + (index - this.oldEndIndex);
      const originalRow = point.row;
      newPoint.row = this.newEndPosition.row + (point.row - this.oldEndPosition.row);
      newPoint.column = originalRow === this.oldEndPosition.row ? this.newEndPosition.column + (point.column - this.oldEndPosition.column) : point.column;
    } else if (index > this.startIndex) {
      newIndex = this.newEndIndex;
      newPoint.row = this.newEndPosition.row;
      newPoint.column = this.newEndPosition.column;
    }
    return { point: newPoint, index: newIndex };
  }
  /**
   * Edit a range to keep it in-sync with source code that has been edited.
   *
   * This function updates a range's start and end positions based on an edit
   * operation. This is useful for editing ranges without requiring a tree
   * or node instance.
   */
  editRange(range) {
    const newRange = {
      startIndex: range.startIndex,
      startPosition: { ...range.startPosition },
      endIndex: range.endIndex,
      endPosition: { ...range.endPosition }
    };
    if (range.endIndex >= this.oldEndIndex) {
      if (range.endIndex !== Number.MAX_SAFE_INTEGER) {
        newRange.endIndex = this.newEndIndex + (range.endIndex - this.oldEndIndex);
        newRange.endPosition = {
          row: this.newEndPosition.row + (range.endPosition.row - this.oldEndPosition.row),
          column: range.endPosition.row === this.oldEndPosition.row ? this.newEndPosition.column + (range.endPosition.column - this.oldEndPosition.column) : range.endPosition.column
        };
        if (newRange.endIndex < this.newEndIndex) {
          newRange.endIndex = Number.MAX_SAFE_INTEGER;
          newRange.endPosition = { row: Number.MAX_SAFE_INTEGER, column: Number.MAX_SAFE_INTEGER };
        }
      }
    } else if (range.endIndex > this.startIndex) {
      newRange.endIndex = this.startIndex;
      newRange.endPosition = { ...this.startPosition };
    }
    if (range.startIndex >= this.oldEndIndex) {
      newRange.startIndex = this.newEndIndex + (range.startIndex - this.oldEndIndex);
      newRange.startPosition = {
        row: this.newEndPosition.row + (range.startPosition.row - this.oldEndPosition.row),
        column: range.startPosition.row === this.oldEndPosition.row ? this.newEndPosition.column + (range.startPosition.column - this.oldEndPosition.column) : range.startPosition.column
      };
      if (newRange.startIndex < this.newEndIndex) {
        newRange.startIndex = Number.MAX_SAFE_INTEGER;
        newRange.startPosition = { row: Number.MAX_SAFE_INTEGER, column: Number.MAX_SAFE_INTEGER };
      }
    } else if (range.startIndex > this.startIndex) {
      newRange.startIndex = this.startIndex;
      newRange.startPosition = { ...this.startPosition };
    }
    return newRange;
  }
};

// src/constants.ts
var SIZE_OF_SHORT = 2;
var SIZE_OF_INT = 4;
var SIZE_OF_CURSOR = 4 * SIZE_OF_INT;
var SIZE_OF_NODE = 5 * SIZE_OF_INT;
var SIZE_OF_POINT = 2 * SIZE_OF_INT;
var SIZE_OF_RANGE = 2 * SIZE_OF_INT + 2 * SIZE_OF_POINT;
var ZERO_POINT = { row: 0, column: 0 };
var INTERNAL = /* @__PURE__ */ Symbol("INTERNAL");
function assertInternal(x) {
  if (x !== INTERNAL) throw new Error("Illegal constructor");
}
__name(assertInternal, "assertInternal");
function isPoint(point) {
  return !!point && typeof point.row === "number" && typeof point.column === "number";
}
__name(isPoint, "isPoint");
function setModule(module2) {
  C = module2;
}
__name(setModule, "setModule");
var C;

// src/finalization_registry.ts
function newFinalizer(handler) {
  try {
    return new FinalizationRegistry(handler);
  } catch (e) {
    console.error("Unsupported FinalizationRegistry:", e);
    return;
  }
}
__name(newFinalizer, "newFinalizer");

// src/lookahead_iterator.ts
var finalizer = newFinalizer((address) => {
  C._ts_lookahead_iterator_delete(address);
});
var LookaheadIterator = class {
  static {
    __name(this, "LookaheadIterator");
  }
  /** @internal */
  [0] = 0;
  // Internal handle for Wasm
  /** @internal */
  language;
  /** @internal */
  positioned = false;
  /** @internal */
  constructor(internal, address, language) {
    assertInternal(internal);
    this[0] = address;
    this.language = language;
    finalizer?.register(this, address, this);
  }
  /**
   * Get the current symbol of the lookahead iterator.
   *
   * Returns `null` if the iterator is not positioned on a symbol:
   *
   * - Before the first iteration step
   * - After the iterator is exhausted
   * - After a {@link reset} or {@link resetState} call
   */
  get currentTypeId() {
    return this.positioned ? C._ts_lookahead_iterator_current_symbol(this[0]) : null;
  }
  /**
   * Get the current symbol name of the lookahead iterator.
   *
   * Returns `null` if the iterator is not positioned on a symbol.
   */
  get currentType() {
    const id = this.currentTypeId;
    if (id === null) return null;
    return this.language.types[id] ?? C.UTF8ToString(C._ts_language_symbol_name(this.language[0], id));
  }
  /** Delete the lookahead iterator, freeing its resources. */
  delete() {
    finalizer?.unregister(this);
    C._ts_lookahead_iterator_delete(this[0]);
    this[0] = 0;
  }
  /**
   * Reset the lookahead iterator.
   *
   * This returns `true` if the language was set successfully and `false`
   * otherwise.
   */
  reset(language, stateId) {
    if (C._ts_lookahead_iterator_reset(this[0], language[0], stateId)) {
      this.language = language;
      this.positioned = false;
      return true;
    }
    return false;
  }
  /**
   * Reset the lookahead iterator to another state.
   *
   * This returns `true` if the iterator was reset to the given state and
   * `false` otherwise.
   */
  resetState(stateId) {
    if (!C._ts_lookahead_iterator_reset_state(this[0], stateId)) return false;
    this.positioned = false;
    return true;
  }
  /**
   * Returns an iterator that iterates over the symbols of the lookahead iterator.
   *
   * The iterator will yield the current symbol name as a string for each step
   * until there are no more symbols to iterate over.
   */
  [Symbol.iterator]() {
    return {
      next: /* @__PURE__ */ __name(() => {
        this.positioned = Boolean(C._ts_lookahead_iterator_next(this[0]));
        const value = this.currentType;
        return value === null ? { done: true, value: "" } : { done: false, value };
      }, "next")
    };
  }
};

// src/tree.ts
function getText(tree, startIndex, endIndex, startPosition) {
  const length = endIndex - startIndex;
  let result = tree.textCallback(startIndex, startPosition);
  if (result) {
    startIndex += result.length;
    while (startIndex < endIndex) {
      const string = tree.textCallback(startIndex, startPosition);
      if (string && string.length > 0) {
        startIndex += string.length;
        result += string;
      } else {
        break;
      }
    }
    if (startIndex > endIndex) {
      result = result.slice(0, length);
    }
  }
  return result ?? "";
}
__name(getText, "getText");
var finalizer2 = newFinalizer((address) => {
  C._ts_tree_delete(address);
});
var Tree = class _Tree {
  static {
    __name(this, "Tree");
  }
  /** @internal */
  [0] = 0;
  // Internal handle for Wasm
  /** @internal */
  textCallback;
  /** The language that was used to parse the syntax tree. */
  language;
  /** @internal */
  constructor(internal, address, language, textCallback) {
    assertInternal(internal);
    this[0] = address;
    this.language = language;
    this.textCallback = textCallback;
    finalizer2?.register(this, address, this);
  }
  /** Create a shallow copy of the syntax tree. This is very fast. */
  copy() {
    const address = C._ts_tree_copy(this[0]);
    return new _Tree(INTERNAL, address, this.language, this.textCallback);
  }
  /** Delete the syntax tree, freeing its resources. */
  delete() {
    finalizer2?.unregister(this);
    C._ts_tree_delete(this[0]);
    this[0] = 0;
  }
  /** Get the root node of the syntax tree. */
  get rootNode() {
    C._ts_tree_root_node_wasm(this[0]);
    return unmarshalNode(this);
  }
  /**
   * Get the root node of the syntax tree, but with its position shifted
   * forward by the given offset.
   */
  rootNodeWithOffset(offsetBytes, offsetExtent) {
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    C.setValue(address, offsetBytes, "i32");
    marshalPoint(address + SIZE_OF_INT, offsetExtent);
    C._ts_tree_root_node_with_offset_wasm(this[0]);
    return unmarshalNode(this);
  }
  /**
   * Edit the syntax tree to keep it in sync with source code that has been
   * edited.
   *
   * You must describe the edit both in terms of byte offsets and in terms of
   * row/column coordinates.
   */
  edit(edit) {
    marshalEdit(edit);
    C._ts_tree_edit_wasm(this[0]);
  }
  /** Create a new {@link TreeCursor} starting from the root of the tree. */
  walk() {
    return this.rootNode.walk();
  }
  /**
   * Compare this old edited syntax tree to a new syntax tree representing
   * the same document, returning a sequence of ranges whose syntactic
   * structure has changed.
   *
   * For this to work correctly, this syntax tree must have been edited such
   * that its ranges match up to the new tree. Generally, you'll want to
   * call this method right after calling one of the [`Parser::parse`]
   * functions. Call it on the old tree that was passed to parse, and
   * pass the new tree that was returned from `parse`.
   */
  getChangedRanges(other) {
    if (!(other instanceof _Tree)) {
      throw new TypeError("Argument must be a Tree");
    }
    C._ts_tree_get_changed_ranges_wasm(this[0], other[0]);
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(count);
    if (count > 0) {
      let address = buffer;
      for (let i2 = 0; i2 < count; i2++) {
        result[i2] = unmarshalRange(address);
        address += SIZE_OF_RANGE;
      }
      C._free(buffer);
    }
    return result;
  }
  /** Get the included ranges that were used to parse the syntax tree. */
  getIncludedRanges() {
    C._ts_tree_included_ranges_wasm(this[0]);
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(count);
    if (count > 0) {
      let address = buffer;
      for (let i2 = 0; i2 < count; i2++) {
        result[i2] = unmarshalRange(address);
        address += SIZE_OF_RANGE;
      }
      C._free(buffer);
    }
    return result;
  }
};

// src/tree_cursor.ts
var finalizer3 = newFinalizer((address) => {
  C._ts_tree_cursor_delete_wasm(address);
});
var TreeCursor = class _TreeCursor {
  static {
    __name(this, "TreeCursor");
  }
  /** @internal */
  // @ts-expect-error: never read
  [0] = 0;
  // Internal handle for Wasm
  /** @internal */
  // @ts-expect-error: never read
  [1] = 0;
  // Internal handle for Wasm
  /** @internal */
  // @ts-expect-error: never read
  [2] = 0;
  // Internal handle for Wasm
  /** @internal */
  // @ts-expect-error: never read
  [3] = 0;
  // Internal handle for Wasm
  /** @internal */
  tree;
  /** @internal */
  constructor(internal, tree) {
    assertInternal(internal);
    this.tree = tree;
    unmarshalTreeCursor(this);
    finalizer3?.register(this, this.tree[0], this);
  }
  /** Creates a deep copy of the tree cursor. This allocates new memory. */
  copy() {
    const copy = new _TreeCursor(INTERNAL, this.tree);
    C._ts_tree_cursor_copy_wasm(this.tree[0]);
    unmarshalTreeCursor(copy);
    return copy;
  }
  /** Delete the tree cursor, freeing its resources. */
  delete() {
    finalizer3?.unregister(this);
    marshalTreeCursor(this);
    C._ts_tree_cursor_delete_wasm(this.tree[0]);
    this[0] = this[1] = this[2] = 0;
  }
  /** Get the tree cursor's current {@link Node}. */
  get currentNode() {
    marshalTreeCursor(this);
    C._ts_tree_cursor_current_node_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /**
   * Get the numerical field id of this tree cursor's current node.
   *
   * See also {@link TreeCursor#currentFieldName}.
   */
  get currentFieldId() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_field_id_wasm(this.tree[0]);
  }
  /** Get the field name of this tree cursor's current node. */
  get currentFieldName() {
    return this.tree.language.fields[this.currentFieldId];
  }
  /**
   * Get the depth of the cursor's current node relative to the original
   * node that the cursor was constructed with.
   */
  get currentDepth() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_depth_wasm(this.tree[0]);
  }
  /**
   * Get the index of the cursor's current node out of all of the
   * descendants of the original node that the cursor was constructed with.
   */
  get currentDescendantIndex() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_descendant_index_wasm(this.tree[0]);
  }
  /** Get the type of the cursor's current node. */
  get nodeType() {
    return this.tree.language.types[this.nodeTypeId] || "ERROR";
  }
  /** Get the type id of the cursor's current node. */
  get nodeTypeId() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_node_type_id_wasm(this.tree[0]);
  }
  /** Get the state id of the cursor's current node. */
  get nodeStateId() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_node_state_id_wasm(this.tree[0]);
  }
  /** Get the id of the cursor's current node. */
  get nodeId() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_node_id_wasm(this.tree[0]);
  }
  /**
   * Check if the cursor's current node is *named*.
   *
   * Named nodes correspond to named rules in the grammar, whereas
   * *anonymous* nodes correspond to string literals in the grammar.
   */
  get nodeIsNamed() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_node_is_named_wasm(this.tree[0]) === 1;
  }
  /**
   * Check if the cursor's current node is *missing*.
   *
   * Missing nodes are inserted by the parser in order to recover from
   * certain kinds of syntax errors.
   */
  get nodeIsMissing() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_current_node_is_missing_wasm(this.tree[0]) === 1;
  }
  /** Get the string content of the cursor's current node. */
  get nodeText() {
    marshalTreeCursor(this);
    const startIndex = C._ts_tree_cursor_start_index_wasm(this.tree[0]);
    const endIndex = C._ts_tree_cursor_end_index_wasm(this.tree[0]);
    C._ts_tree_cursor_start_position_wasm(this.tree[0]);
    const startPosition = unmarshalPoint(TRANSFER_BUFFER);
    return getText(this.tree, startIndex, endIndex, startPosition);
  }
  /** Get the start position of the cursor's current node. */
  get startPosition() {
    marshalTreeCursor(this);
    C._ts_tree_cursor_start_position_wasm(this.tree[0]);
    return unmarshalPoint(TRANSFER_BUFFER);
  }
  /** Get the end position of the cursor's current node. */
  get endPosition() {
    marshalTreeCursor(this);
    C._ts_tree_cursor_end_position_wasm(this.tree[0]);
    return unmarshalPoint(TRANSFER_BUFFER);
  }
  /** Get the start index of the cursor's current node. */
  get startIndex() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_start_index_wasm(this.tree[0]);
  }
  /** Get the end index of the cursor's current node. */
  get endIndex() {
    marshalTreeCursor(this);
    return C._ts_tree_cursor_end_index_wasm(this.tree[0]);
  }
  /**
   * Move this cursor to the first child of its current node.
   *
   * This returns `true` if the cursor successfully moved, and returns
   * `false` if there were no children.
   */
  gotoFirstChild() {
    marshalTreeCursor(this);
    const result = C._ts_tree_cursor_goto_first_child_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Move this cursor to the last child of its current node.
   *
   * This returns `true` if the cursor successfully moved, and returns
   * `false` if there were no children.
   *
   * Note that this function may be slower than
   * {@link TreeCursor#gotoFirstChild} because it needs to
   * iterate through all the children to compute the child's position.
   */
  gotoLastChild() {
    marshalTreeCursor(this);
    const result = C._ts_tree_cursor_goto_last_child_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Move this cursor to the parent of its current node.
   *
   * This returns `true` if the cursor successfully moved, and returns
   * `false` if there was no parent node (the cursor was already on the
   * root node).
   *
   * Note that the node the cursor was constructed with is considered the root
   * of the cursor, and the cursor cannot walk outside this node.
   */
  gotoParent() {
    marshalTreeCursor(this);
    const result = C._ts_tree_cursor_goto_parent_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Move this cursor to the next sibling of its current node.
   *
   * This returns `true` if the cursor successfully moved, and returns
   * `false` if there was no next sibling node.
   *
   * Note that the node the cursor was constructed with is considered the root
   * of the cursor, and the cursor cannot walk outside this node.
   */
  gotoNextSibling() {
    marshalTreeCursor(this);
    const result = C._ts_tree_cursor_goto_next_sibling_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Move this cursor to the previous sibling of its current node.
   *
   * This returns `true` if the cursor successfully moved, and returns
   * `false` if there was no previous sibling node.
   *
   * Note that this function may be slower than
   * {@link TreeCursor#gotoNextSibling} due to how node
   * positions are stored. In the worst case, this will need to iterate
   * through all the children up to the previous sibling node to recalculate
   * its position. Also note that the node the cursor was constructed with is
   * considered the root of the cursor, and the cursor cannot walk outside this node.
   */
  gotoPreviousSibling() {
    marshalTreeCursor(this);
    const result = C._ts_tree_cursor_goto_previous_sibling_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Move the cursor to the node that is the nth descendant of
   * the original node that the cursor was constructed with, where
   * zero represents the original node itself.
   */
  gotoDescendant(goalDescendantIndex) {
    marshalTreeCursor(this);
    C._ts_tree_cursor_goto_descendant_wasm(this.tree[0], goalDescendantIndex);
    unmarshalTreeCursor(this);
  }
  /**
   * Move this cursor to the first child of its current node that contains or
   * starts after the given byte offset.
   *
   * This returns `true` if the cursor successfully moved to a child node, and returns
   * `false` if no such child was found.
   */
  gotoFirstChildForIndex(goalIndex) {
    marshalTreeCursor(this);
    C.setValue(TRANSFER_BUFFER + SIZE_OF_CURSOR, goalIndex, "i32");
    const result = C._ts_tree_cursor_goto_first_child_for_index_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Move this cursor to the first child of its current node that contains or
   * starts after the given byte offset.
   *
   * This returns the index of the child node if one was found, and returns
   * `null` if no such child was found.
   */
  gotoFirstChildForPosition(goalPosition) {
    marshalTreeCursor(this);
    marshalPoint(TRANSFER_BUFFER + SIZE_OF_CURSOR, goalPosition);
    const result = C._ts_tree_cursor_goto_first_child_for_position_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
    return result === 1;
  }
  /**
   * Re-initialize this tree cursor to start at the original node that the
   * cursor was constructed with.
   */
  reset(node) {
    marshalNode(node);
    marshalTreeCursor(this, TRANSFER_BUFFER + SIZE_OF_NODE);
    C._ts_tree_cursor_reset_wasm(this.tree[0]);
    unmarshalTreeCursor(this);
  }
  /**
   * Re-initialize a tree cursor to the same position as another cursor.
   *
   * Unlike {@link TreeCursor#reset}, this will not lose parent
   * information and allows reusing already created cursors.
   */
  resetTo(cursor) {
    marshalTreeCursor(this, TRANSFER_BUFFER);
    marshalTreeCursor(cursor, TRANSFER_BUFFER + SIZE_OF_CURSOR);
    C._ts_tree_cursor_reset_to_wasm(this.tree[0], cursor.tree[0]);
    unmarshalTreeCursor(this);
  }
};

// src/node.ts
var Node = class {
  static {
    __name(this, "Node");
  }
  /** @internal */
  // @ts-expect-error: never read
  [0] = 0;
  // Internal handle for Wasm
  /** @internal */
  _children;
  /** @internal */
  _namedChildren;
  /** @internal */
  constructor(internal, {
    id,
    tree,
    startIndex,
    startPosition,
    other
  }) {
    assertInternal(internal);
    this[0] = other;
    this.id = id;
    this.tree = tree;
    this.startIndex = startIndex;
    this.startPosition = startPosition;
  }
  /**
   * The numeric id for this node that is unique.
   *
   * Within a given syntax tree, no two nodes have the same id. However:
   *
   * * If a new tree is created based on an older tree, and a node from the old tree is reused in
   *   the process, then that node will have the same id in both trees.
   *
   * * A node not marked as having changes does not guarantee it was reused.
   *
   * * If a node is marked as having changed in the old tree, it will not be reused.
   */
  id;
  /** The byte index where this node starts. */
  startIndex;
  /** The position where this node starts. */
  startPosition;
  /** The tree that this node belongs to. */
  tree;
  /** Get this node's type as a numerical id. */
  get typeId() {
    marshalNode(this);
    return C._ts_node_symbol_wasm(this.tree[0]);
  }
  /**
   * Get the node's type as a numerical id as it appears in the grammar,
   * ignoring aliases.
   */
  get grammarId() {
    marshalNode(this);
    return C._ts_node_grammar_symbol_wasm(this.tree[0]);
  }
  /** Get this node's type as a string. */
  get type() {
    return this.tree.language.types[this.typeId] || "ERROR";
  }
  /**
   * Get this node's symbol name as it appears in the grammar, ignoring
   * aliases as a string.
   */
  get grammarType() {
    return this.tree.language.types[this.grammarId] || "ERROR";
  }
  /**
   * Check if this node is *named*.
   *
   * Named nodes correspond to named rules in the grammar, whereas
   * *anonymous* nodes correspond to string literals in the grammar.
   */
  get isNamed() {
    marshalNode(this);
    return C._ts_node_is_named_wasm(this.tree[0]) === 1;
  }
  /**
   * Check if this node is *extra*.
   *
   * Extra nodes represent things like comments, which are not required
   * by the grammar, but can appear anywhere.
   */
  get isExtra() {
    marshalNode(this);
    return C._ts_node_is_extra_wasm(this.tree[0]) === 1;
  }
  /**
   * Check if this node represents a syntax error.
   *
   * Syntax errors represent parts of the code that could not be incorporated
   * into a valid syntax tree.
   */
  get isError() {
    marshalNode(this);
    return C._ts_node_is_error_wasm(this.tree[0]) === 1;
  }
  /**
   * Check if this node is *missing*.
   *
   * Missing nodes are inserted by the parser in order to recover from
   * certain kinds of syntax errors.
   */
  get isMissing() {
    marshalNode(this);
    return C._ts_node_is_missing_wasm(this.tree[0]) === 1;
  }
  /** Check if this node has been edited. */
  get hasChanges() {
    marshalNode(this);
    return C._ts_node_has_changes_wasm(this.tree[0]) === 1;
  }
  /**
   * Check if this node represents a syntax error or contains any syntax
   * errors anywhere within it.
   */
  get hasError() {
    marshalNode(this);
    return C._ts_node_has_error_wasm(this.tree[0]) === 1;
  }
  /** Get the byte index where this node ends. */
  get endIndex() {
    marshalNode(this);
    return C._ts_node_end_index_wasm(this.tree[0]);
  }
  /** Get the position where this node ends. */
  get endPosition() {
    marshalNode(this);
    C._ts_node_end_point_wasm(this.tree[0]);
    return unmarshalPoint(TRANSFER_BUFFER);
  }
  /** Get the string content of this node. */
  get text() {
    return getText(this.tree, this.startIndex, this.endIndex, this.startPosition);
  }
  /** Get this node's parse state. */
  get parseState() {
    marshalNode(this);
    return C._ts_node_parse_state_wasm(this.tree[0]);
  }
  /** Get the parse state after this node. */
  get nextParseState() {
    marshalNode(this);
    return C._ts_node_next_parse_state_wasm(this.tree[0]);
  }
  /** Check if this node is equal to another node. */
  equals(other) {
    return this.tree === other.tree && this.id === other.id;
  }
  /**
   * Get the node's child at the given index, where zero represents the first child.
   *
   * This method is fairly fast, but its cost is technically log(n), so if
   * you might be iterating over a long list of children, you should use
   * {@link Node#children} instead.
   */
  child(index) {
    marshalNode(this);
    C._ts_node_child_wasm(this.tree[0], index);
    return unmarshalNode(this.tree);
  }
  /**
   * Get this node's *named* child at the given index.
   *
   * See also {@link Node#isNamed}.
   * This method is fairly fast, but its cost is technically log(n), so if
   * you might be iterating over a long list of children, you should use
   * {@link Node#namedChildren} instead.
   */
  namedChild(index) {
    marshalNode(this);
    C._ts_node_named_child_wasm(this.tree[0], index);
    return unmarshalNode(this.tree);
  }
  /**
   * Get this node's child with the given numerical field id.
   *
   * See also {@link Node#childForFieldName}. You can
   * convert a field name to an id using {@link Language#fieldIdForName}.
   */
  childForFieldId(fieldId) {
    marshalNode(this);
    C._ts_node_child_by_field_id_wasm(this.tree[0], fieldId);
    return unmarshalNode(this.tree);
  }
  /**
   * Get the first child with the given field name.
   *
   * If multiple children may have the same field name, access them using
   * {@link Node#childrenForFieldName}.
   */
  childForFieldName(fieldName) {
    const fieldId = this.tree.language.fields.indexOf(fieldName);
    if (fieldId !== -1) return this.childForFieldId(fieldId);
    return null;
  }
  /** Get the field name of this node's child at the given index. */
  fieldNameForChild(index) {
    marshalNode(this);
    const address = C._ts_node_field_name_for_child_wasm(this.tree[0], index);
    if (!address) return null;
    return C.AsciiToString(address);
  }
  /** Get the field name of this node's named child at the given index. */
  fieldNameForNamedChild(index) {
    marshalNode(this);
    const address = C._ts_node_field_name_for_named_child_wasm(this.tree[0], index);
    if (!address) return null;
    return C.AsciiToString(address);
  }
  /**
   * Get an array of this node's children with a given field name.
   *
   * See also {@link Node#children}.
   */
  childrenForFieldName(fieldName) {
    const fieldId = this.tree.language.fields.indexOf(fieldName);
    if (fieldId !== -1 && fieldId !== 0) return this.childrenForFieldId(fieldId);
    return [];
  }
  /**
    * Get an array of this node's children with a given field id.
    *
    * See also {@link Node#childrenForFieldName}.
    */
  childrenForFieldId(fieldId) {
    marshalNode(this);
    C._ts_node_children_by_field_id_wasm(this.tree[0], fieldId);
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(count);
    if (count > 0) {
      let address = buffer;
      for (let i2 = 0; i2 < count; i2++) {
        result[i2] = unmarshalNode(this.tree, address);
        address += SIZE_OF_NODE;
      }
      C._free(buffer);
    }
    return result;
  }
  /** Get the node's first child that contains or starts after the given byte offset. */
  firstChildForIndex(index) {
    marshalNode(this);
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    C.setValue(address, index, "i32");
    C._ts_node_first_child_for_byte_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get the node's first named child that contains or starts after the given byte offset. */
  firstNamedChildForIndex(index) {
    marshalNode(this);
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    C.setValue(address, index, "i32");
    C._ts_node_first_named_child_for_byte_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get this node's number of children. */
  get childCount() {
    marshalNode(this);
    return C._ts_node_child_count_wasm(this.tree[0]);
  }
  /**
   * Get this node's number of *named* children.
   *
   * See also {@link Node#isNamed}.
   */
  get namedChildCount() {
    marshalNode(this);
    return C._ts_node_named_child_count_wasm(this.tree[0]);
  }
  /** Get this node's first child. */
  get firstChild() {
    return this.child(0);
  }
  /**
   * Get this node's first named child.
   *
   * See also {@link Node#isNamed}.
   */
  get firstNamedChild() {
    return this.namedChild(0);
  }
  /** Get this node's last child. */
  get lastChild() {
    return this.child(this.childCount - 1);
  }
  /**
   * Get this node's last named child.
   *
   * See also {@link Node#isNamed}.
   */
  get lastNamedChild() {
    return this.namedChild(this.namedChildCount - 1);
  }
  /**
   * Iterate over this node's children.
   *
   * If you're walking the tree recursively, you may want to use the
   * {@link TreeCursor} APIs directly instead.
   */
  get children() {
    if (!this._children) {
      marshalNode(this);
      C._ts_node_children_wasm(this.tree[0]);
      const count = C.getValue(TRANSFER_BUFFER, "i32");
      const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
      this._children = new Array(count);
      if (count > 0) {
        let address = buffer;
        for (let i2 = 0; i2 < count; i2++) {
          this._children[i2] = unmarshalNode(this.tree, address);
          address += SIZE_OF_NODE;
        }
        C._free(buffer);
      }
    }
    return this._children;
  }
  /**
   * Iterate over this node's named children.
   *
   * See also {@link Node#children}.
   */
  get namedChildren() {
    if (!this._namedChildren) {
      marshalNode(this);
      C._ts_node_named_children_wasm(this.tree[0]);
      const count = C.getValue(TRANSFER_BUFFER, "i32");
      const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
      this._namedChildren = new Array(count);
      if (count > 0) {
        let address = buffer;
        for (let i2 = 0; i2 < count; i2++) {
          this._namedChildren[i2] = unmarshalNode(this.tree, address);
          address += SIZE_OF_NODE;
        }
        C._free(buffer);
      }
    }
    return this._namedChildren;
  }
  /**
   * Get the descendants of this node that are the given type, or in the given types array.
   *
   * The types array should contain node type strings, which can be retrieved from {@link Language#types}.
   *
   * Additionally, a `startPosition` and `endPosition` can be passed in to restrict the search to a byte range.
   */
  descendantsOfType(types, startPosition = ZERO_POINT, endPosition = ZERO_POINT) {
    if (!Array.isArray(types)) types = [types];
    const symbols = [];
    const typesBySymbol = this.tree.language.types;
    for (const node_type of types) {
      if (node_type == "ERROR") {
        symbols.push(65535);
      }
    }
    for (let i2 = 0, n = typesBySymbol.length; i2 < n; i2++) {
      if (types.includes(typesBySymbol[i2])) {
        symbols.push(i2);
      }
    }
    const symbolsAddress = C._malloc(SIZE_OF_INT * symbols.length);
    for (let i2 = 0, n = symbols.length; i2 < n; i2++) {
      C.setValue(symbolsAddress + i2 * SIZE_OF_INT, symbols[i2], "i32");
    }
    marshalNode(this);
    C._ts_node_descendants_of_type_wasm(
      this.tree[0],
      symbolsAddress,
      symbols.length,
      startPosition.row,
      startPosition.column,
      endPosition.row,
      endPosition.column
    );
    const descendantCount = C.getValue(TRANSFER_BUFFER, "i32");
    const descendantAddress = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(descendantCount);
    if (descendantCount > 0) {
      let address = descendantAddress;
      for (let i2 = 0; i2 < descendantCount; i2++) {
        result[i2] = unmarshalNode(this.tree, address);
        address += SIZE_OF_NODE;
      }
    }
    C._free(descendantAddress);
    C._free(symbolsAddress);
    return result;
  }
  /** Get this node's next sibling. */
  get nextSibling() {
    marshalNode(this);
    C._ts_node_next_sibling_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get this node's previous sibling. */
  get previousSibling() {
    marshalNode(this);
    C._ts_node_prev_sibling_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /**
   * Get this node's next *named* sibling.
   *
   * See also {@link Node#isNamed}.
   */
  get nextNamedSibling() {
    marshalNode(this);
    C._ts_node_next_named_sibling_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /**
   * Get this node's previous *named* sibling.
   *
   * See also {@link Node#isNamed}.
   */
  get previousNamedSibling() {
    marshalNode(this);
    C._ts_node_prev_named_sibling_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get the node's number of descendants, including one for the node itself. */
  get descendantCount() {
    marshalNode(this);
    return C._ts_node_descendant_count_wasm(this.tree[0]);
  }
  /**
   * Get this node's immediate parent.
   * Prefer {@link Node#childWithDescendant} for iterating over this node's ancestors.
   */
  get parent() {
    marshalNode(this);
    C._ts_node_parent_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /**
   * Get the node that contains `descendant`.
   *
   * Note that this can return `descendant` itself.
   */
  childWithDescendant(descendant) {
    marshalNode(this);
    marshalNode(descendant, 1);
    C._ts_node_child_with_descendant_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get the smallest node within this node that spans the given byte range. */
  descendantForIndex(start2, end = start2) {
    if (typeof start2 !== "number" || typeof end !== "number") {
      throw new Error("Arguments must be numbers");
    }
    marshalNode(this);
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    C.setValue(address, start2, "i32");
    C.setValue(address + SIZE_OF_INT, end, "i32");
    C._ts_node_descendant_for_index_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get the smallest named node within this node that spans the given byte range. */
  namedDescendantForIndex(start2, end = start2) {
    if (typeof start2 !== "number" || typeof end !== "number") {
      throw new Error("Arguments must be numbers");
    }
    marshalNode(this);
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    C.setValue(address, start2, "i32");
    C.setValue(address + SIZE_OF_INT, end, "i32");
    C._ts_node_named_descendant_for_index_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get the smallest node within this node that spans the given point range. */
  descendantForPosition(start2, end = start2) {
    if (!isPoint(start2) || !isPoint(end)) {
      throw new Error("Arguments must be {row, column} objects");
    }
    marshalNode(this);
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    marshalPoint(address, start2);
    marshalPoint(address + SIZE_OF_POINT, end);
    C._ts_node_descendant_for_position_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /** Get the smallest named node within this node that spans the given point range. */
  namedDescendantForPosition(start2, end = start2) {
    if (!isPoint(start2) || !isPoint(end)) {
      throw new Error("Arguments must be {row, column} objects");
    }
    marshalNode(this);
    const address = TRANSFER_BUFFER + SIZE_OF_NODE;
    marshalPoint(address, start2);
    marshalPoint(address + SIZE_OF_POINT, end);
    C._ts_node_named_descendant_for_position_wasm(this.tree[0]);
    return unmarshalNode(this.tree);
  }
  /**
   * Create a new {@link TreeCursor} starting from this node.
   *
   * Note that the given node is considered the root of the cursor,
   * and the cursor cannot walk outside this node.
   */
  walk() {
    marshalNode(this);
    C._ts_tree_cursor_new_wasm(this.tree[0]);
    return new TreeCursor(INTERNAL, this.tree);
  }
  /**
   * Edit this node to keep it in-sync with source code that has been edited.
   *
   * This function is only rarely needed. When you edit a syntax tree with
   * the {@link Tree#edit} method, all of the nodes that you retrieve from
   * the tree afterward will already reflect the edit. You only need to
   * use {@link Node#edit} when you have a specific {@link Node} instance that
   * you want to keep and continue to use after an edit.
   */
  edit(edit) {
    if (this.startIndex >= edit.oldEndIndex) {
      this.startIndex = edit.newEndIndex + (this.startIndex - edit.oldEndIndex);
      let subbedPointRow;
      let subbedPointColumn;
      if (this.startPosition.row > edit.oldEndPosition.row) {
        subbedPointRow = this.startPosition.row - edit.oldEndPosition.row;
        subbedPointColumn = this.startPosition.column;
      } else {
        subbedPointRow = 0;
        subbedPointColumn = this.startPosition.column;
        if (this.startPosition.column >= edit.oldEndPosition.column) {
          subbedPointColumn = this.startPosition.column - edit.oldEndPosition.column;
        }
      }
      if (subbedPointRow > 0) {
        this.startPosition.row += subbedPointRow;
        this.startPosition.column = subbedPointColumn;
      } else {
        this.startPosition.column += subbedPointColumn;
      }
    } else if (this.startIndex > edit.startIndex) {
      this.startIndex = edit.newEndIndex;
      this.startPosition.row = edit.newEndPosition.row;
      this.startPosition.column = edit.newEndPosition.column;
    }
  }
  /** Get the S-expression representation of this node. */
  toString() {
    marshalNode(this);
    const address = C._ts_node_to_string_wasm(this.tree[0]);
    const result = C.AsciiToString(address);
    C._free(address);
    return result;
  }
};

// src/marshal.ts
function unmarshalCaptures(query, tree, address, patternIndex, result) {
  for (let i2 = 0, n = result.length; i2 < n; i2++) {
    const captureIndex = C.getValue(address, "i32");
    address += SIZE_OF_INT;
    const node = unmarshalNode(tree, address);
    address += SIZE_OF_NODE;
    result[i2] = { patternIndex, name: query.captureNames[captureIndex], node };
  }
  return address;
}
__name(unmarshalCaptures, "unmarshalCaptures");
function marshalNode(node, index = 0) {
  let address = TRANSFER_BUFFER + index * SIZE_OF_NODE;
  C.setValue(address, node.id, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, node.startIndex, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, node.startPosition.row, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, node.startPosition.column, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, node[0], "i32");
}
__name(marshalNode, "marshalNode");
function unmarshalNode(tree, address = TRANSFER_BUFFER) {
  const id = C.getValue(address, "i32");
  address += SIZE_OF_INT;
  if (id === 0) return null;
  const index = C.getValue(address, "i32");
  address += SIZE_OF_INT;
  const row = C.getValue(address, "i32");
  address += SIZE_OF_INT;
  const column = C.getValue(address, "i32");
  address += SIZE_OF_INT;
  const other = C.getValue(address, "i32");
  const result = new Node(INTERNAL, {
    id,
    tree,
    startIndex: index,
    startPosition: { row, column },
    other
  });
  return result;
}
__name(unmarshalNode, "unmarshalNode");
function marshalTreeCursor(cursor, address = TRANSFER_BUFFER) {
  C.setValue(address + 0 * SIZE_OF_INT, cursor[0], "i32");
  C.setValue(address + 1 * SIZE_OF_INT, cursor[1], "i32");
  C.setValue(address + 2 * SIZE_OF_INT, cursor[2], "i32");
  C.setValue(address + 3 * SIZE_OF_INT, cursor[3], "i32");
}
__name(marshalTreeCursor, "marshalTreeCursor");
function unmarshalTreeCursor(cursor) {
  cursor[0] = C.getValue(TRANSFER_BUFFER + 0 * SIZE_OF_INT, "i32");
  cursor[1] = C.getValue(TRANSFER_BUFFER + 1 * SIZE_OF_INT, "i32");
  cursor[2] = C.getValue(TRANSFER_BUFFER + 2 * SIZE_OF_INT, "i32");
  cursor[3] = C.getValue(TRANSFER_BUFFER + 3 * SIZE_OF_INT, "i32");
}
__name(unmarshalTreeCursor, "unmarshalTreeCursor");
function marshalPoint(address, point) {
  C.setValue(address, point.row, "i32");
  C.setValue(address + SIZE_OF_INT, point.column, "i32");
}
__name(marshalPoint, "marshalPoint");
function unmarshalPoint(address) {
  const result = {
    row: C.getValue(address, "i32") >>> 0,
    column: C.getValue(address + SIZE_OF_INT, "i32") >>> 0
  };
  return result;
}
__name(unmarshalPoint, "unmarshalPoint");
function marshalRange(address, range) {
  marshalPoint(address, range.startPosition);
  address += SIZE_OF_POINT;
  marshalPoint(address, range.endPosition);
  address += SIZE_OF_POINT;
  C.setValue(address, range.startIndex, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, range.endIndex, "i32");
  address += SIZE_OF_INT;
}
__name(marshalRange, "marshalRange");
function unmarshalRange(address) {
  const result = {};
  result.startPosition = unmarshalPoint(address);
  address += SIZE_OF_POINT;
  result.endPosition = unmarshalPoint(address);
  address += SIZE_OF_POINT;
  result.startIndex = C.getValue(address, "i32") >>> 0;
  address += SIZE_OF_INT;
  result.endIndex = C.getValue(address, "i32") >>> 0;
  return result;
}
__name(unmarshalRange, "unmarshalRange");
function marshalEdit(edit, address = TRANSFER_BUFFER) {
  marshalPoint(address, edit.startPosition);
  address += SIZE_OF_POINT;
  marshalPoint(address, edit.oldEndPosition);
  address += SIZE_OF_POINT;
  marshalPoint(address, edit.newEndPosition);
  address += SIZE_OF_POINT;
  C.setValue(address, edit.startIndex, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, edit.oldEndIndex, "i32");
  address += SIZE_OF_INT;
  C.setValue(address, edit.newEndIndex, "i32");
  address += SIZE_OF_INT;
}
__name(marshalEdit, "marshalEdit");
function unmarshalLanguageMetadata(address) {
  const major_version = C.getValue(address, "i32");
  const minor_version = C.getValue(address += SIZE_OF_INT, "i32");
  const patch_version = C.getValue(address += SIZE_OF_INT, "i32");
  return { major_version, minor_version, patch_version };
}
__name(unmarshalLanguageMetadata, "unmarshalLanguageMetadata");

// src/language.ts
var LANGUAGE_FUNCTION_REGEX = /^tree_sitter_\w+$/;
var Language = class _Language {
  static {
    __name(this, "Language");
  }
  /** @internal */
  [0] = 0;
  // Internal handle for Wasm
  /**
   * A list of all node types in the language. The index of each type in this
   * array is its node type id.
   */
  types;
  /**
   * A list of all field names in the language. The index of each field name in
   * this array is its field id.
   */
  fields;
  /** @internal */
  constructor(internal, address) {
    assertInternal(internal);
    this[0] = address;
    this.types = new Array(C._ts_language_symbol_count(this[0]));
    for (let i2 = 0, n = this.types.length; i2 < n; i2++) {
      if (C._ts_language_symbol_type(this[0], i2) < 2) {
        this.types[i2] = C.UTF8ToString(C._ts_language_symbol_name(this[0], i2));
      }
    }
    this.fields = new Array(C._ts_language_field_count(this[0]) + 1);
    for (let i2 = 0, n = this.fields.length; i2 < n; i2++) {
      const fieldName = C._ts_language_field_name_for_id(this[0], i2);
      if (fieldName !== 0) {
        this.fields[i2] = C.UTF8ToString(fieldName);
      } else {
        this.fields[i2] = null;
      }
    }
  }
  /**
   * Gets the name of the language.
   */
  get name() {
    const ptr = C._ts_language_name(this[0]);
    if (ptr === 0) return null;
    return C.UTF8ToString(ptr);
  }
  /**
   * Gets the ABI version of the language.
   */
  get abiVersion() {
    return C._ts_language_abi_version(this[0]);
  }
  /**
  * Get the metadata for this language. This information is generated by the
  * CLI, and relies on the language author providing the correct metadata in
  * the language's `tree-sitter.json` file.
  */
  get metadata() {
    C._ts_language_metadata_wasm(this[0]);
    const length = C.getValue(TRANSFER_BUFFER, "i32");
    if (length === 0) return null;
    return unmarshalLanguageMetadata(TRANSFER_BUFFER + SIZE_OF_INT);
  }
  /**
   * Gets the number of fields in the language.
   */
  get fieldCount() {
    return this.fields.length - 1;
  }
  /**
   * Gets the number of states in the language.
   */
  get stateCount() {
    return C._ts_language_state_count(this[0]);
  }
  /**
   * Get the field id for a field name.
   */
  fieldIdForName(fieldName) {
    const result = this.fields.indexOf(fieldName);
    return result !== -1 ? result : null;
  }
  /**
   * Get the field name for a field id.
   */
  fieldNameForId(fieldId) {
    return this.fields[fieldId] ?? null;
  }
  /**
   * Get the node type id for a node type name.
   */
  idForNodeType(type, named) {
    const typeLength = C.lengthBytesUTF8(type);
    const typeAddress = C._malloc(typeLength + 1);
    C.stringToUTF8(type, typeAddress, typeLength + 1);
    const result = C._ts_language_symbol_for_name(this[0], typeAddress, typeLength, named ? 1 : 0);
    C._free(typeAddress);
    return result || null;
  }
  /**
   * Gets the number of node types in the language.
   */
  get nodeTypeCount() {
    return C._ts_language_symbol_count(this[0]);
  }
  /**
   * Get the node type name for a node type id.
   */
  nodeTypeForId(typeId) {
    const name2 = C._ts_language_symbol_name(this[0], typeId);
    return name2 ? C.UTF8ToString(name2) : null;
  }
  /**
   * Check if a node type is named.
   *
   * @see {@link https://tree-sitter.github.io/tree-sitter/using-parsers/2-basic-parsing.html#named-vs-anonymous-nodes}
   */
  nodeTypeIsNamed(typeId) {
    return C._ts_language_type_is_named_wasm(this[0], typeId) ? true : false;
  }
  /**
   * Check if a node type is visible.
   */
  nodeTypeIsVisible(typeId) {
    return C._ts_language_type_is_visible_wasm(this[0], typeId) ? true : false;
  }
  /**
   * Get the supertypes ids of this language.
   *
   * @see {@link https://tree-sitter.github.io/tree-sitter/using-parsers/6-static-node-types.html?highlight=supertype#supertype-nodes}
   */
  get supertypes() {
    C._ts_language_supertypes_wasm(this[0]);
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(count);
    if (count > 0) {
      let address = buffer;
      for (let i2 = 0; i2 < count; i2++) {
        result[i2] = C.getValue(address, "i16");
        address += SIZE_OF_SHORT;
      }
    }
    return result;
  }
  /**
   * Get the subtype ids for a given supertype node id.
   */
  subtypes(supertype) {
    C._ts_language_subtypes_wasm(this[0], supertype);
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(count);
    if (count > 0) {
      let address = buffer;
      for (let i2 = 0; i2 < count; i2++) {
        result[i2] = C.getValue(address, "i16");
        address += SIZE_OF_SHORT;
      }
    }
    return result;
  }
  /**
   * Get the next state id for a given state id and node type id.
   */
  nextState(stateId, typeId) {
    return C._ts_language_next_state(this[0], stateId, typeId);
  }
  /**
   * Create a new lookahead iterator for this language and parse state.
   *
   * This returns `null` if state is invalid for this language.
   *
   * Iterating {@link LookaheadIterator} will yield valid symbols in the given
   * parse state. A newly created iterator is not positioned on a symbol, so
   * {@link LookaheadIterator#currentType} returns `null` until the first
   * iteration step.
   *
   * Lookahead iterators can be useful for generating suggestions and improving
   * syntax error diagnostics. To get symbols valid in an `ERROR` node, use the
   * lookahead iterator on its first leaf node state. For `MISSING` nodes, a
   * lookahead iterator created on the previous non-extra leaf node may be
   * appropriate.
   */
  lookaheadIterator(stateId) {
    const address = C._ts_lookahead_iterator_new(this[0], stateId);
    if (address) return new LookaheadIterator(INTERNAL, address, this);
    return null;
  }
  /**
   * Load a language from a WebAssembly module.
   * The module can be provided as a path to a file, a `URL` to a file, or as a
   * buffer.
   */
  static async load(input) {
    let binary2;
    if (input instanceof Uint8Array) {
      binary2 = input;
    } else if (globalThis.process?.versions.node) {
      const fs2 = await import("fs/promises");
      binary2 = await fs2.readFile(input);
    } else {
      const response = await fetch(input);
      if (!response.ok) {
        const body2 = await response.text();
        throw new Error(`Language.load failed with status ${response.status}.

${body2}`);
      }
      const retryResp = response.clone();
      try {
        binary2 = await WebAssembly.compileStreaming(response);
      } catch (reason) {
        console.error("wasm streaming compile failed:", reason);
        console.error("falling back to ArrayBuffer instantiation");
        binary2 = new Uint8Array(await retryResp.arrayBuffer());
      }
    }
    const mod = await C.loadWebAssemblyModule(binary2, { loadAsync: true });
    return _Language.loadFromWasmExports(mod, { sync: false });
  }
  static loadFromWasmExports(mod, { sync }) {
    const symbolNames = Object.keys(mod);
    const functionName = symbolNames.find((key) => LANGUAGE_FUNCTION_REGEX.test(key) && !key.includes("external_scanner_"));
    if (!functionName) {
      console.log(`Couldn't find language function in Wasm file. Symbols:
${JSON.stringify(symbolNames, null, 2)}`);
      throw new Error(`Language.${sync ? "loadSync" : "load"} failed: no language function found in Wasm file`);
    }
    const languageAddress = mod[functionName]();
    return new _Language(INTERNAL, languageAddress);
  }
  /**
   * Load a language synchronously from a pre-compiled WebAssembly module.
   * Use this when the host environment provides a `WebAssembly.Module` directly.
   */
  static loadSync(wasmModule) {
    const mod = C.loadWebAssemblyModule(wasmModule, { loadAsync: false });
    return _Language.loadFromWasmExports(mod, { sync: true });
  }
};

// src/bindings.ts
var import_web_tree_sitter = __toESM(require_web_tree_sitter(), 1);
var Module2 = null;
async function initializeBinding(moduleOptions) {
  return Module2 ??= await (0, import_web_tree_sitter.default)(moduleOptions);
}
__name(initializeBinding, "initializeBinding");
function checkModule() {
  return !!Module2;
}
__name(checkModule, "checkModule");

// src/parser.ts
var TRANSFER_BUFFER;
var LANGUAGE_VERSION;
var MIN_COMPATIBLE_VERSION;
var finalizer4 = newFinalizer((addresses) => {
  C._ts_parser_delete(addresses[0]);
  C._free(addresses[1]);
});
var Parser = class {
  static {
    __name(this, "Parser");
  }
  /** @internal */
  [0] = 0;
  // Internal handle for Wasm
  /** @internal */
  [1] = 0;
  // Internal handle for Wasm
  /** @internal */
  logCallback = null;
  /** The parser's current language. */
  language = null;
  /**
   * This must always be called before creating a Parser.
   *
   * You can optionally pass in options to configure the Wasm module, the most common
   * one being `locateFile` to help the module find the `.wasm` file.
   */
  static async init(moduleOptions) {
    setModule(await initializeBinding(moduleOptions));
    TRANSFER_BUFFER = C._ts_init();
    LANGUAGE_VERSION = C.getValue(TRANSFER_BUFFER, "i32");
    MIN_COMPATIBLE_VERSION = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
  }
  /**
   * Create a new parser.
   */
  constructor() {
    this.initialize();
    finalizer4?.register(this, [this[0], this[1]], this);
  }
  /** @internal */
  initialize() {
    if (!checkModule()) {
      throw new Error("cannot construct a Parser before calling `init()`");
    }
    C._ts_parser_new_wasm();
    this[0] = C.getValue(TRANSFER_BUFFER, "i32");
    this[1] = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
  }
  /** Delete the parser, freeing its resources. */
  delete() {
    finalizer4?.unregister(this);
    C._ts_parser_delete(this[0]);
    C._free(this[1]);
    this[0] = 0;
    this[1] = 0;
  }
  /**
   * Set the language that the parser should use for parsing.
   *
   * If the language was not successfully assigned, an error will be thrown.
   * This happens if the language was generated with an incompatible
   * version of the Tree-sitter CLI. Check the language's version using
   * {@link Language#version} and compare it to this library's
   * {@link LANGUAGE_VERSION} and {@link MIN_COMPATIBLE_VERSION} constants.
   */
  setLanguage(language) {
    let address;
    if (!language) {
      address = 0;
      this.language = null;
    } else if (language.constructor === Language) {
      address = language[0];
      const version = C._ts_language_abi_version(address);
      if (version < MIN_COMPATIBLE_VERSION || LANGUAGE_VERSION < version) {
        throw new Error(
          `Incompatible language version ${version}. Compatibility range ${MIN_COMPATIBLE_VERSION} through ${LANGUAGE_VERSION}.`
        );
      }
      this.language = language;
    } else {
      throw new Error("Argument must be a Language");
    }
    C._ts_parser_set_language(this[0], address);
    return this;
  }
  /**
   * Parse a slice of UTF8 text.
   *
   * @param {string | ParseCallback} callback - The UTF8-encoded text to parse or a callback function.
   *
   * @param {Tree | null} [oldTree] - A previous syntax tree parsed from the same document. If the text of the
   *   document has changed since `oldTree` was created, then you must edit `oldTree` to match
   *   the new text using {@link Tree#edit}.
   *
   * @param {ParseOptions} [options] - Options for parsing the text.
   *  This can be used to set the included ranges, or a progress callback.
   *
   * @returns {Tree | null} A {@link Tree} if parsing succeeded, or `null` if:
   *  - The parser has not yet had a language assigned with {@link Parser#setLanguage}.
   *  - The progress callback returned true.
   */
  parse(callback, oldTree, options) {
    if (typeof callback === "string") {
      C.currentParseCallback = (index) => callback.slice(index);
    } else if (typeof callback === "function") {
      C.currentParseCallback = callback;
    } else {
      throw new Error("Argument must be a string or a function");
    }
    if (options?.progressCallback) {
      C.currentProgressCallback = options.progressCallback;
    } else {
      C.currentProgressCallback = null;
    }
    if (this.logCallback) {
      C.currentLogCallback = this.logCallback;
      C._ts_parser_enable_logger_wasm(this[0], 1);
    } else {
      C.currentLogCallback = null;
      C._ts_parser_enable_logger_wasm(this[0], 0);
    }
    let rangeCount = 0;
    let rangeAddress = 0;
    if (options?.includedRanges) {
      rangeCount = options.includedRanges.length;
      rangeAddress = C._calloc(rangeCount, SIZE_OF_RANGE);
      let address = rangeAddress;
      for (let i2 = 0; i2 < rangeCount; i2++) {
        marshalRange(address, options.includedRanges[i2]);
        address += SIZE_OF_RANGE;
      }
    }
    const treeAddress = C._ts_parser_parse_wasm(
      this[0],
      this[1],
      oldTree ? oldTree[0] : 0,
      rangeAddress,
      rangeCount
    );
    if (!treeAddress) {
      C.currentParseCallback = null;
      C.currentLogCallback = null;
      C.currentProgressCallback = null;
      return null;
    }
    if (!this.language) {
      throw new Error("Parser must have a language to parse");
    }
    const result = new Tree(INTERNAL, treeAddress, this.language, C.currentParseCallback);
    C.currentParseCallback = null;
    C.currentLogCallback = null;
    C.currentProgressCallback = null;
    return result;
  }
  /**
   * Instruct the parser to start the next parse from the beginning.
   *
   * If the parser previously failed because of a callback, 
   * then by default, it will resume where it left off on the
   * next call to {@link Parser#parse} or other parsing functions.
   * If you don't want to resume, and instead intend to use this parser to
   * parse some other document, you must call `reset` first.
   */
  reset() {
    C._ts_parser_reset(this[0]);
  }
  /** Get the ranges of text that the parser will include when parsing. */
  getIncludedRanges() {
    C._ts_parser_included_ranges_wasm(this[0]);
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const buffer = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const result = new Array(count);
    if (count > 0) {
      let address = buffer;
      for (let i2 = 0; i2 < count; i2++) {
        result[i2] = unmarshalRange(address);
        address += SIZE_OF_RANGE;
      }
      C._free(buffer);
    }
    return result;
  }
  /** Set the logging callback that a parser should use during parsing. */
  setLogger(callback) {
    if (!callback) {
      this.logCallback = null;
    } else if (typeof callback !== "function") {
      throw new Error("Logger callback must be a function");
    } else {
      this.logCallback = callback;
    }
    return this;
  }
  /** Get the parser's current logger. */
  getLogger() {
    return this.logCallback;
  }
};

// src/query.ts
var PREDICATE_STEP_TYPE_CAPTURE = 1;
var PREDICATE_STEP_TYPE_STRING = 2;
var QUERY_WORD_REGEX = /[\w-]+/g;
var CaptureQuantifier = {
  Zero: 0,
  ZeroOrOne: 1,
  ZeroOrMore: 2,
  One: 3,
  OneOrMore: 4
};
var isCaptureStep = /* @__PURE__ */ __name((step) => step.type === "capture", "isCaptureStep");
var isStringStep = /* @__PURE__ */ __name((step) => step.type === "string", "isStringStep");
var QueryErrorKind = {
  Syntax: 1,
  NodeName: 2,
  FieldName: 3,
  CaptureName: 4,
  PatternStructure: 5
};
var QueryError = class _QueryError extends Error {
  constructor(kind, info2, index, length) {
    super(_QueryError.formatMessage(kind, info2));
    this.kind = kind;
    this.info = info2;
    this.index = index;
    this.length = length;
    this.name = "QueryError";
  }
  kind;
  info;
  index;
  length;
  static {
    __name(this, "QueryError");
  }
  /** Formats an error message based on the error kind and info */
  static formatMessage(kind, info2) {
    switch (kind) {
      case QueryErrorKind.NodeName:
        return `Bad node name '${info2.word}'`;
      case QueryErrorKind.FieldName:
        return `Bad field name '${info2.word}'`;
      case QueryErrorKind.CaptureName:
        return `Bad capture name @${info2.word}`;
      case QueryErrorKind.PatternStructure:
        return `Bad pattern structure at offset ${info2.suffix}`;
      case QueryErrorKind.Syntax:
        return `Bad syntax at offset ${info2.suffix}`;
    }
  }
};
function parseAnyPredicate(steps, index, operator, textPredicates) {
  if (steps.length !== 3) {
    throw new Error(
      `Wrong number of arguments to \`#${operator}\` predicate. Expected 2, got ${steps.length - 1}`
    );
  }
  if (!isCaptureStep(steps[1])) {
    throw new Error(
      `First argument of \`#${operator}\` predicate must be a capture. Got "${steps[1].value}"`
    );
  }
  const isPositive = operator === "eq?" || operator === "any-eq?";
  const matchAll = !operator.startsWith("any-");
  if (isCaptureStep(steps[2])) {
    const captureName1 = steps[1].name;
    const captureName2 = steps[2].name;
    textPredicates[index].push((captures) => {
      const nodes1 = [];
      const nodes2 = [];
      for (const c of captures) {
        if (c.name === captureName1) nodes1.push(c.node);
        if (c.name === captureName2) nodes2.push(c.node);
      }
      const compare = /* @__PURE__ */ __name((n1, n2, positive) => {
        return positive ? n1.text === n2.text : n1.text !== n2.text;
      }, "compare");
      return matchAll ? nodes1.every((n1) => nodes2.some((n2) => compare(n1, n2, isPositive))) : nodes1.some((n1) => nodes2.some((n2) => compare(n1, n2, isPositive)));
    });
  } else {
    const captureName = steps[1].name;
    const stringValue = steps[2].value;
    const matches = /* @__PURE__ */ __name((n) => n.text === stringValue, "matches");
    const doesNotMatch = /* @__PURE__ */ __name((n) => n.text !== stringValue, "doesNotMatch");
    textPredicates[index].push((captures) => {
      const nodes = [];
      for (const c of captures) {
        if (c.name === captureName) nodes.push(c.node);
      }
      const test = isPositive ? matches : doesNotMatch;
      return matchAll ? nodes.every(test) : nodes.some(test);
    });
  }
}
__name(parseAnyPredicate, "parseAnyPredicate");
function parseMatchPredicate(steps, index, operator, textPredicates) {
  if (steps.length !== 3) {
    throw new Error(
      `Wrong number of arguments to \`#${operator}\` predicate. Expected 2, got ${steps.length - 1}.`
    );
  }
  if (steps[1].type !== "capture") {
    throw new Error(
      `First argument of \`#${operator}\` predicate must be a capture. Got "${steps[1].value}".`
    );
  }
  if (steps[2].type !== "string") {
    throw new Error(
      `Second argument of \`#${operator}\` predicate must be a string. Got @${steps[2].name}.`
    );
  }
  const isPositive = operator === "match?" || operator === "any-match?";
  const matchAll = !operator.startsWith("any-");
  const captureName = steps[1].name;
  const regex = new RegExp(steps[2].value);
  textPredicates[index].push((captures) => {
    const nodes = [];
    for (const c of captures) {
      if (c.name === captureName) nodes.push(c.node.text);
    }
    const test = /* @__PURE__ */ __name((text, positive) => {
      return positive ? regex.test(text) : !regex.test(text);
    }, "test");
    if (nodes.length === 0) return !isPositive;
    return matchAll ? nodes.every((text) => test(text, isPositive)) : nodes.some((text) => test(text, isPositive));
  });
}
__name(parseMatchPredicate, "parseMatchPredicate");
function parseAnyOfPredicate(steps, index, operator, textPredicates) {
  if (steps.length < 2) {
    throw new Error(
      `Wrong number of arguments to \`#${operator}\` predicate. Expected at least 1. Got ${steps.length - 1}.`
    );
  }
  if (steps[1].type !== "capture") {
    throw new Error(
      `First argument of \`#${operator}\` predicate must be a capture. Got "${steps[1].value}".`
    );
  }
  const isPositive = operator === "any-of?";
  const captureName = steps[1].name;
  const stringSteps = steps.slice(2);
  if (!stringSteps.every(isStringStep)) {
    throw new Error(
      `Arguments to \`#${operator}\` predicate must be strings.".`
    );
  }
  const values = stringSteps.map((s) => s.value);
  textPredicates[index].push((captures) => {
    const nodes = [];
    for (const c of captures) {
      if (c.name === captureName) nodes.push(c.node.text);
    }
    if (nodes.length === 0) return !isPositive;
    return nodes.every((text) => values.includes(text)) === isPositive;
  });
}
__name(parseAnyOfPredicate, "parseAnyOfPredicate");
function parseIsPredicate(steps, index, operator, assertedProperties, refutedProperties) {
  if (steps.length < 2 || steps.length > 3) {
    throw new Error(
      `Wrong number of arguments to \`#${operator}\` predicate. Expected 1 or 2. Got ${steps.length - 1}.`
    );
  }
  if (!steps.every(isStringStep)) {
    throw new Error(
      `Arguments to \`#${operator}\` predicate must be strings.".`
    );
  }
  const properties = operator === "is?" ? assertedProperties : refutedProperties;
  if (!properties[index]) properties[index] = {};
  properties[index][steps[1].value] = steps[2]?.value ?? null;
}
__name(parseIsPredicate, "parseIsPredicate");
function parseSetDirective(steps, index, setProperties) {
  if (steps.length < 2 || steps.length > 3) {
    throw new Error(`Wrong number of arguments to \`#set!\` predicate. Expected 1 or 2. Got ${steps.length - 1}.`);
  }
  if (!steps.every(isStringStep)) {
    throw new Error(`Arguments to \`#set!\` predicate must be strings.".`);
  }
  if (!setProperties[index]) setProperties[index] = {};
  setProperties[index][steps[1].value] = steps[2]?.value ?? null;
}
__name(parseSetDirective, "parseSetDirective");
function parsePattern(index, stepType, stepValueId, captureNames, stringValues, steps, textPredicates, predicates, setProperties, assertedProperties, refutedProperties) {
  if (stepType === PREDICATE_STEP_TYPE_CAPTURE) {
    const name2 = captureNames[stepValueId];
    steps.push({ type: "capture", name: name2 });
  } else if (stepType === PREDICATE_STEP_TYPE_STRING) {
    steps.push({ type: "string", value: stringValues[stepValueId] });
  } else if (steps.length > 0) {
    if (steps[0].type !== "string") {
      throw new Error("Predicates must begin with a literal value");
    }
    const operator = steps[0].value;
    switch (operator) {
      case "any-not-eq?":
      case "not-eq?":
      case "any-eq?":
      case "eq?":
        parseAnyPredicate(steps, index, operator, textPredicates);
        break;
      case "any-not-match?":
      case "not-match?":
      case "any-match?":
      case "match?":
        parseMatchPredicate(steps, index, operator, textPredicates);
        break;
      case "not-any-of?":
      case "any-of?":
        parseAnyOfPredicate(steps, index, operator, textPredicates);
        break;
      case "is?":
      case "is-not?":
        parseIsPredicate(steps, index, operator, assertedProperties, refutedProperties);
        break;
      case "set!":
        parseSetDirective(steps, index, setProperties);
        break;
      default:
        predicates[index].push({ operator, operands: steps.slice(1) });
    }
    steps.length = 0;
  }
}
__name(parsePattern, "parsePattern");
var finalizer5 = newFinalizer((address) => {
  C._ts_query_delete(address);
});
var Query = class {
  static {
    __name(this, "Query");
  }
  /** @internal */
  [0] = 0;
  // Internal handle for Wasm
  /** @internal */
  exceededMatchLimit;
  /** @internal */
  textPredicates;
  /** The names of the captures used in the query. */
  captureNames;
  /** The quantifiers of the captures used in the query. */
  captureQuantifiers;
  /**
   * The other user-defined predicates associated with the given index.
   *
   * This includes predicates with operators other than:
   * - `match?`
   * - `eq?` and `not-eq?`
   * - `any-of?` and `not-any-of?`
   * - `is?` and `is-not?`
   * - `set!`
   */
  predicates;
  /** The properties for predicates with the operator `set!`. */
  setProperties;
  /** The properties for predicates with the operator `is?`. */
  assertedProperties;
  /** The properties for predicates with the operator `is-not?`. */
  refutedProperties;
  /** The maximum number of in-progress matches for this cursor. */
  matchLimit;
  /**
   * Create a new query from a string containing one or more S-expression
   * patterns.
   *
   * The query is associated with a particular language, and can only be run
   * on syntax nodes parsed with that language. References to Queries can be
   * shared between multiple threads.
   *
   * @link {@see https://tree-sitter.github.io/tree-sitter/using-parsers/queries}
   */
  constructor(language, source) {
    const sourceLength = C.lengthBytesUTF8(source);
    const sourceAddress = C._malloc(sourceLength + 1);
    C.stringToUTF8(source, sourceAddress, sourceLength + 1);
    const address = C._ts_query_new(
      language[0],
      sourceAddress,
      sourceLength,
      TRANSFER_BUFFER,
      TRANSFER_BUFFER + SIZE_OF_INT
    );
    if (!address) {
      const errorId = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
      const errorByte = C.getValue(TRANSFER_BUFFER, "i32");
      const errorIndex = C.UTF8ToString(sourceAddress, errorByte).length;
      const suffix = source.slice(errorIndex, errorIndex + 100).split("\n")[0];
      const word = suffix.match(QUERY_WORD_REGEX)?.[0] ?? "";
      C._free(sourceAddress);
      switch (errorId) {
        case QueryErrorKind.Syntax:
          throw new QueryError(QueryErrorKind.Syntax, { suffix: `${errorIndex}: '${suffix}'...` }, errorIndex, 0);
        case QueryErrorKind.NodeName:
          throw new QueryError(errorId, { word }, errorIndex, word.length);
        case QueryErrorKind.FieldName:
          throw new QueryError(errorId, { word }, errorIndex, word.length);
        case QueryErrorKind.CaptureName:
          throw new QueryError(errorId, { word }, errorIndex, word.length);
        case QueryErrorKind.PatternStructure:
          throw new QueryError(errorId, { suffix: `${errorIndex}: '${suffix}'...` }, errorIndex, 0);
      }
    }
    const stringCount = C._ts_query_string_count(address);
    const captureCount = C._ts_query_capture_count(address);
    const patternCount = C._ts_query_pattern_count(address);
    const captureNames = new Array(captureCount);
    const captureQuantifiers = new Array(patternCount);
    const stringValues = new Array(stringCount);
    for (let i2 = 0; i2 < captureCount; i2++) {
      const nameAddress = C._ts_query_capture_name_for_id(
        address,
        i2,
        TRANSFER_BUFFER
      );
      const nameLength = C.getValue(TRANSFER_BUFFER, "i32");
      captureNames[i2] = C.UTF8ToString(nameAddress, nameLength);
    }
    for (let i2 = 0; i2 < patternCount; i2++) {
      const captureQuantifiersArray = new Array(captureCount);
      for (let j = 0; j < captureCount; j++) {
        const quantifier = C._ts_query_capture_quantifier_for_id(address, i2, j);
        captureQuantifiersArray[j] = quantifier;
      }
      captureQuantifiers[i2] = captureQuantifiersArray;
    }
    for (let i2 = 0; i2 < stringCount; i2++) {
      const valueAddress = C._ts_query_string_value_for_id(
        address,
        i2,
        TRANSFER_BUFFER
      );
      const nameLength = C.getValue(TRANSFER_BUFFER, "i32");
      stringValues[i2] = C.UTF8ToString(valueAddress, nameLength);
    }
    const setProperties = new Array(patternCount);
    const assertedProperties = new Array(patternCount);
    const refutedProperties = new Array(patternCount);
    const predicates = new Array(patternCount);
    const textPredicates = new Array(patternCount);
    for (let i2 = 0; i2 < patternCount; i2++) {
      const predicatesAddress = C._ts_query_predicates_for_pattern(address, i2, TRANSFER_BUFFER);
      const stepCount = C.getValue(TRANSFER_BUFFER, "i32");
      predicates[i2] = [];
      textPredicates[i2] = [];
      const steps = new Array();
      let stepAddress = predicatesAddress;
      for (let j = 0; j < stepCount; j++) {
        const stepType = C.getValue(stepAddress, "i32");
        stepAddress += SIZE_OF_INT;
        const stepValueId = C.getValue(stepAddress, "i32");
        stepAddress += SIZE_OF_INT;
        parsePattern(
          i2,
          stepType,
          stepValueId,
          captureNames,
          stringValues,
          steps,
          textPredicates,
          predicates,
          setProperties,
          assertedProperties,
          refutedProperties
        );
      }
      Object.freeze(textPredicates[i2]);
      Object.freeze(predicates[i2]);
      Object.freeze(setProperties[i2]);
      Object.freeze(assertedProperties[i2]);
      Object.freeze(refutedProperties[i2]);
    }
    C._free(sourceAddress);
    this[0] = address;
    this.captureNames = captureNames;
    this.captureQuantifiers = captureQuantifiers;
    this.textPredicates = textPredicates;
    this.predicates = predicates;
    this.setProperties = setProperties;
    this.assertedProperties = assertedProperties;
    this.refutedProperties = refutedProperties;
    this.exceededMatchLimit = false;
    finalizer5?.register(this, address, this);
  }
  /** Delete the query, freeing its resources. */
  delete() {
    finalizer5?.unregister(this);
    C._ts_query_delete(this[0]);
    this[0] = 0;
  }
  /**
   * Iterate over all of the matches in the order that they were found.
   *
   * Each match contains the index of the pattern that matched, and a list of
   * captures. Because multiple patterns can match the same set of nodes,
   * one match may contain captures that appear *before* some of the
   * captures from a previous match.
   *
   * @param {Node} node - The node to execute the query on.
   *
   * @param {QueryOptions} options - Options for query execution.
   */
  matches(node, options = {}) {
    const startPosition = options.startPosition ?? ZERO_POINT;
    const endPosition = options.endPosition ?? ZERO_POINT;
    const startIndex = options.startIndex ?? 0;
    const endIndex = options.endIndex ?? 0;
    const startContainingPosition = options.startContainingPosition ?? ZERO_POINT;
    const endContainingPosition = options.endContainingPosition ?? ZERO_POINT;
    const startContainingIndex = options.startContainingIndex ?? 0;
    const endContainingIndex = options.endContainingIndex ?? 0;
    const matchLimit = options.matchLimit ?? 4294967295;
    const maxStartDepth = options.maxStartDepth ?? 4294967295;
    const progressCallback = options.progressCallback;
    if (typeof matchLimit !== "number") {
      throw new Error("Arguments must be numbers");
    }
    this.matchLimit = matchLimit;
    if (endIndex !== 0 && startIndex > endIndex) {
      throw new Error("`startIndex` cannot be greater than `endIndex`");
    }
    if (endPosition !== ZERO_POINT && (startPosition.row > endPosition.row || startPosition.row === endPosition.row && startPosition.column > endPosition.column)) {
      throw new Error("`startPosition` cannot be greater than `endPosition`");
    }
    if (endContainingIndex !== 0 && startContainingIndex > endContainingIndex) {
      throw new Error("`startContainingIndex` cannot be greater than `endContainingIndex`");
    }
    if (endContainingPosition !== ZERO_POINT && (startContainingPosition.row > endContainingPosition.row || startContainingPosition.row === endContainingPosition.row && startContainingPosition.column > endContainingPosition.column)) {
      throw new Error("`startContainingPosition` cannot be greater than `endContainingPosition`");
    }
    if (progressCallback) {
      C.currentQueryProgressCallback = progressCallback;
    }
    marshalNode(node);
    C._ts_query_matches_wasm(
      this[0],
      node.tree[0],
      startPosition.row,
      startPosition.column,
      endPosition.row,
      endPosition.column,
      startIndex,
      endIndex,
      startContainingPosition.row,
      startContainingPosition.column,
      endContainingPosition.row,
      endContainingPosition.column,
      startContainingIndex,
      endContainingIndex,
      matchLimit,
      maxStartDepth
    );
    const rawCount = C.getValue(TRANSFER_BUFFER, "i32");
    const startAddress = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const didExceedMatchLimit = C.getValue(TRANSFER_BUFFER + 2 * SIZE_OF_INT, "i32");
    const result = new Array(rawCount);
    this.exceededMatchLimit = Boolean(didExceedMatchLimit);
    let filteredCount = 0;
    let address = startAddress;
    for (let i2 = 0; i2 < rawCount; i2++) {
      const patternIndex = C.getValue(address, "i32");
      address += SIZE_OF_INT;
      const captureCount = C.getValue(address, "i32");
      address += SIZE_OF_INT;
      const captures = new Array(captureCount);
      address = unmarshalCaptures(this, node.tree, address, patternIndex, captures);
      if (this.textPredicates[patternIndex].every((p) => p(captures))) {
        result[filteredCount] = { patternIndex, captures };
        const setProperties = this.setProperties[patternIndex];
        result[filteredCount].setProperties = setProperties;
        const assertedProperties = this.assertedProperties[patternIndex];
        result[filteredCount].assertedProperties = assertedProperties;
        const refutedProperties = this.refutedProperties[patternIndex];
        result[filteredCount].refutedProperties = refutedProperties;
        filteredCount++;
      }
    }
    result.length = filteredCount;
    C._free(startAddress);
    C.currentQueryProgressCallback = null;
    return result;
  }
  /**
   * Iterate over all of the individual captures in the order that they
   * appear.
   *
   * This is useful if you don't care about which pattern matched, and just
   * want a single, ordered sequence of captures.
   *
   * @param {Node} node - The node to execute the query on.
   *
   * @param {QueryOptions} options - Options for query execution.
   */
  captures(node, options = {}) {
    const startPosition = options.startPosition ?? ZERO_POINT;
    const endPosition = options.endPosition ?? ZERO_POINT;
    const startIndex = options.startIndex ?? 0;
    const endIndex = options.endIndex ?? 0;
    const startContainingPosition = options.startContainingPosition ?? ZERO_POINT;
    const endContainingPosition = options.endContainingPosition ?? ZERO_POINT;
    const startContainingIndex = options.startContainingIndex ?? 0;
    const endContainingIndex = options.endContainingIndex ?? 0;
    const matchLimit = options.matchLimit ?? 4294967295;
    const maxStartDepth = options.maxStartDepth ?? 4294967295;
    const progressCallback = options.progressCallback;
    if (typeof matchLimit !== "number") {
      throw new Error("Arguments must be numbers");
    }
    this.matchLimit = matchLimit;
    if (endIndex !== 0 && startIndex > endIndex) {
      throw new Error("`startIndex` cannot be greater than `endIndex`");
    }
    if (endPosition !== ZERO_POINT && (startPosition.row > endPosition.row || startPosition.row === endPosition.row && startPosition.column > endPosition.column)) {
      throw new Error("`startPosition` cannot be greater than `endPosition`");
    }
    if (endContainingIndex !== 0 && startContainingIndex > endContainingIndex) {
      throw new Error("`startContainingIndex` cannot be greater than `endContainingIndex`");
    }
    if (endContainingPosition !== ZERO_POINT && (startContainingPosition.row > endContainingPosition.row || startContainingPosition.row === endContainingPosition.row && startContainingPosition.column > endContainingPosition.column)) {
      throw new Error("`startContainingPosition` cannot be greater than `endContainingPosition`");
    }
    if (progressCallback) {
      C.currentQueryProgressCallback = progressCallback;
    }
    marshalNode(node);
    C._ts_query_captures_wasm(
      this[0],
      node.tree[0],
      startPosition.row,
      startPosition.column,
      endPosition.row,
      endPosition.column,
      startIndex,
      endIndex,
      startContainingPosition.row,
      startContainingPosition.column,
      endContainingPosition.row,
      endContainingPosition.column,
      startContainingIndex,
      endContainingIndex,
      matchLimit,
      maxStartDepth
    );
    const count = C.getValue(TRANSFER_BUFFER, "i32");
    const startAddress = C.getValue(TRANSFER_BUFFER + SIZE_OF_INT, "i32");
    const didExceedMatchLimit = C.getValue(TRANSFER_BUFFER + 2 * SIZE_OF_INT, "i32");
    const result = new Array();
    this.exceededMatchLimit = Boolean(didExceedMatchLimit);
    const captures = new Array();
    let address = startAddress;
    for (let i2 = 0; i2 < count; i2++) {
      const patternIndex = C.getValue(address, "i32");
      address += SIZE_OF_INT;
      const captureCount = C.getValue(address, "i32");
      address += SIZE_OF_INT;
      const captureIndex = C.getValue(address, "i32");
      address += SIZE_OF_INT;
      captures.length = captureCount;
      address = unmarshalCaptures(this, node.tree, address, patternIndex, captures);
      if (this.textPredicates[patternIndex].every((p) => p(captures))) {
        const capture = captures[captureIndex];
        const setProperties = this.setProperties[patternIndex];
        capture.setProperties = setProperties;
        const assertedProperties = this.assertedProperties[patternIndex];
        capture.assertedProperties = assertedProperties;
        const refutedProperties = this.refutedProperties[patternIndex];
        capture.refutedProperties = refutedProperties;
        result.push(capture);
      }
    }
    C._free(startAddress);
    C.currentQueryProgressCallback = null;
    return result;
  }
  /** Get the predicates for a given pattern. */
  predicatesForPattern(patternIndex) {
    return this.predicates[patternIndex];
  }
  /**
   * Disable a certain capture within a query.
   *
   * This prevents the capture from being returned in matches, and also
   * avoids any resource usage associated with recording the capture.
   */
  disableCapture(captureName) {
    const captureNameLength = C.lengthBytesUTF8(captureName);
    const captureNameAddress = C._malloc(captureNameLength + 1);
    C.stringToUTF8(captureName, captureNameAddress, captureNameLength + 1);
    C._ts_query_disable_capture(this[0], captureNameAddress, captureNameLength);
    C._free(captureNameAddress);
  }
  /**
   * Disable a certain pattern within a query.
   *
   * This prevents the pattern from matching, and also avoids any resource
   * usage associated with the pattern. This throws an error if the pattern
   * index is out of bounds.
   */
  disablePattern(patternIndex) {
    if (patternIndex >= this.predicates.length) {
      throw new Error(
        `Pattern index is ${patternIndex} but the pattern count is ${this.predicates.length}`
      );
    }
    C._ts_query_disable_pattern(this[0], patternIndex);
  }
  /**
   * Check if, on its last execution, this cursor exceeded its maximum number
   * of in-progress matches.
   */
  didExceedMatchLimit() {
    return this.exceededMatchLimit;
  }
  /** Get the byte offset where the given pattern starts in the query's source. */
  startIndexForPattern(patternIndex) {
    if (patternIndex >= this.predicates.length) {
      throw new Error(
        `Pattern index is ${patternIndex} but the pattern count is ${this.predicates.length}`
      );
    }
    return C._ts_query_start_byte_for_pattern(this[0], patternIndex);
  }
  /** Get the byte offset where the given pattern ends in the query's source. */
  endIndexForPattern(patternIndex) {
    if (patternIndex >= this.predicates.length) {
      throw new Error(
        `Pattern index is ${patternIndex} but the pattern count is ${this.predicates.length}`
      );
    }
    return C._ts_query_end_byte_for_pattern(this[0], patternIndex);
  }
  /** Get the number of patterns in the query. */
  patternCount() {
    return C._ts_query_pattern_count(this[0]);
  }
  /** Get the index for a given capture name. */
  captureIndexForName(captureName) {
    return this.captureNames.indexOf(captureName);
  }
  /** Check if a given pattern within a query has a single root node. */
  isPatternRooted(patternIndex) {
    return C._ts_query_is_pattern_rooted(this[0], patternIndex) === 1;
  }
  /** Check if a given pattern within a query has a single root node. */
  isPatternNonLocal(patternIndex) {
    return C._ts_query_is_pattern_non_local(this[0], patternIndex) === 1;
  }
  /**
   * Check if a given step in a query is 'definite'.
   *
   * A query step is 'definite' if its parent pattern will be guaranteed to
   * match successfully once it reaches the step.
   */
  isPatternGuaranteedAtStep(byteIndex) {
    return C._ts_query_is_pattern_guaranteed_at_step(this[0], byteIndex) === 1;
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CaptureQuantifier,
  Edit,
  LANGUAGE_VERSION,
  Language,
  LookaheadIterator,
  MIN_COMPATIBLE_VERSION,
  Node,
  Parser,
  Query,
  Tree,
  TreeCursor
});
module.exports.default = module.exports;
//# sourceMappingURL=web-tree-sitter.cjs.map
